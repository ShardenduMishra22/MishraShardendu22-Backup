package main

func main() {
	// var allowedUrl []string
	// allowedUrl = append(allowedUrl, "www.linkedin.com")

	// linkedIn_posts := "https://www.linkedin.com/in/shardendumishra22/recent-activity/all"

	// c := colly.NewCollector(
	// 	colly.MaxDepth(2),
	// 	colly.Async(true),
	// 	colly.AllowURLRevisit(),
	// 	colly.Debugger(&debug.LogDebugger{}),
	// 	colly.AllowedDomains(linkedIn_posts),
	// )
}
