# Colly Web Scraping: Complete Documentation Guide

**Author**: Shardendu Mishra  
**Date**: October 3, 2025  
**Framework**: Colly (Go Web Scraping Framework)

---

## Table of Contents

1. [Introduction](#introduction)
2. [Installation & Setup](#installation--setup)
3. [Colly Overview](#colly-overview)
4. [Collector Basics](#collector-basics)
5. [Key Collector Options](#key-collector-options)
6. [Event Handlers](#event-handlers)
7. [Debugging](#debugging)
8. [Distributed Scraping](#distributed-scraping)
9. [Proxy Switchers](#proxy-switchers)
10. [Storage Backends](#storage-backends)
11. [Multiple Collectors](#multiple-collectors)
12. [Extensions](#extensions)
13. [Best Practices](#best-practices)
14. [Complete Examples](#complete-examples)
15. [References](#references)

---

## Introduction

Colly is a high-performance, production-grade web scraping framework for Go. It provides a clean API for building scrapers and crawlers with built-in support for concurrency, session management, and extensibility.

### Key Features

- **High Performance**: Handles >1000 requests/sec on a single core
- **Automatic Session Management**: Built-in cookie and session handling
- **Concurrency Control**: Per-domain rate limiting and parallelism
- **Flexible Architecture**: Event-driven with multiple callback types
- **Distributed Support**: Scale across multiple machines
- **Cache Support**: Reduce redundant requests
- **Robots.txt Compliance**: Built-in support

---

## Installation & Setup

```bash
go get github.com/gocolly/colly/v2
```

Basic import:

```go
import "github.com/gocolly/colly/v2"
```

---

## Colly Overview

Colly uses an event-driven architecture where you register callback functions that execute at different points in the scraping lifecycle.

### Basic Structure

```go
c := colly.NewCollector()

c.OnRequest(func(r *colly.Request) {
    fmt.Println("Visiting", r.URL)
})

c.OnHTML("a[href]", func(e *colly.HTMLElement) {
    e.Request.Visit(e.Attr("href"))
})

c.OnResponse(func(r *colly.Response) {
    fmt.Println("Response size:", len(r.Body))
})

c.Visit("http://example.com")
```

---

## Collector Basics

### Creating a Collector

```go
import "github.com/gocolly/colly/v2"

c := colly.NewCollector(
    colly.AllowedDomains("example.com"),
    colly.Async(true),
    colly.AllowURLRevisit(),
)
```

---

## Key Collector Options

### 1. AllowedDomains

**Purpose**: Restricts the crawler to only visit URLs from specified domains.

**Why Use It**: Prevents your scraper from wandering to external sites, keeping it focused on the target domain.

**Example**:

```go
c := colly.NewCollector(
    colly.AllowedDomains("example.com", "shop.example.com"),
)
```

**Real-World Scenario**: Scraping an e-commerce site. You only want product pages from `shop.example.com`, not ads or external links.

---

### 2. Async(true)

**Purpose**: Enables asynchronous (concurrent) request processing.

**Why Use It**: Dramatically increases scraping speed by processing multiple requests in parallel.

**Example**:

```go
c := colly.NewCollector(colly.Async(true))
c.Visit("https://example.com")
c.Wait()  // Always call Wait() when using Async
```

**Real-World Scenario**: Scraping 10,000 product pages. Sequential scraping takes hours; async mode reduces it to minutes.

**Important**: Always call `c.Wait()` at the end to ensure all goroutines complete before program exit.

---

### 3. AllowURLRevisit()

**Purpose**: Allows the collector to visit the same URL multiple times.

**Why Use It**: By default, Colly prevents duplicate visits. Enable this when you need to revisit URLs with changing content or when different handlers need to process the same resource.

**Example**:

```go
c := colly.NewCollector(colly.AllowURLRevisit())
```

**Real-World Scenario**: Monitoring price changes on a product page by scraping it multiple times throughout the day.

---

## Event Handlers

Colly provides several callback functions that execute at different stages:

### OnRequest

Fires before an HTTP request is sent.

```go
c.OnRequest(func(r *colly.Request) {
    fmt.Println("Visiting", r.URL)
    r.Headers.Set("Custom-Header", "value")
})
```

### OnResponse

Handles the HTTP response.

```go
c.OnResponse(func(r *colly.Response) {
    fmt.Println("Status:", r.StatusCode)
})
```

### OnHTML

Extracts data using CSS selectors.

```go
c.OnHTML("div.product", func(e *colly.HTMLElement) {
    title := e.ChildText("h2.title")
    price := e.ChildText("span.price")
    fmt.Println(title, price)
})
```

### OnError

Handles failed requests.

```go
c.OnError(func(r *colly.Response, err error) {
    fmt.Println("Request failed:", err)
})
```

### OnScraped

Fires after all callbacks complete.

```go
c.OnScraped(func(r *colly.Response) {
    fmt.Println("Finished scraping:", r.Request.URL)
})
```

---

## Debugging

### Why Debug?

When your scraper doesn't work as expected, debugging helps you understand what's happening at each step.

### Simple Debugging

```go
c.OnHTML("a[href]", func(e *colly.HTMLElement) {
    log.Println("Found link:", e.Attr("href"))
}
```

**Problem**: For large scraping jobs with hundreds of pages, this produces too many messages.

### Structured Debugging

Colly provides a built-in debugging system:

```
import (
    "github.com/gocolly/colly/v2"
    "github.com/gocolly/colly/debug"
)

c := colly.NewCollector(
    colly.Debugger(&debug.LogDebugger{}),
)
```

**What It Shows**:

- URLs being visited
- Request/response details
- Errors and their causes
- Execution flow

### Custom Debugger

Implement the `debug.Debugger` interface for custom logging:

```go
type MyDebugger struct{}

func (d *MyDebugger) Init() error { return nil }
func (d *MyDebugger) Event(e *debug.Event) {
    // Custom logging logic
    fmt.Printf("[%s] %s\n", e.Type, e.RequestID)
}
```

**Use Cases**:

- Send errors to monitoring services (Sentry, DataDog)
- Log to files for later analysis
- Store debug data in databases

---

## Distributed Scraping

### What Is Distributed Scraping?

Spreading scraping work across multiple machines or network connections instead of running everything from one place.

### Why Distribute?

**Speed**: 10 machines scrape 10x faster than one.  
**Avoid Blocks**: Multiple IPs prevent detection and bans.  
**Scale**: Handle millions of pages that one machine can't process.

### Two Approaches

1. **Proxy Switchers** (Easier): One scraper, multiple IPs
2. **Distributed Scrapers** (Advanced): Multiple scraper instances, shared state

---

## Proxy Switchers

### What Are Proxies?

Intermediary servers that route your requests. The target website sees the proxy's IP, not yours.

```
Your Computer → Proxy Server → Target Website
```

### Built-in Proxy Switcher

```go
import "github.com/gocolly/colly/proxy"

c := colly.NewCollector()

p, err := proxy.RoundRobinProxySwitcher(
    "socks5://127.0.0.1:1337",
    "socks5://127.0.0.1:1338",
    "http://127.0.0.1:8080",
)
if err == nil {
    c.SetProxyFunc(p)
}
```

**How It Works**: Rotates through your proxy list. Request 1 uses proxy 1, request 2 uses proxy 2, etc.

### Custom Proxy Switcher

Random selection instead of round-robin:

```go
var proxies = []*url.URL{
    {Host: "127.0.0.1:8080"},
    {Host: "127.0.0.1:8081"},
}

func randomProxySwitcher(_ *http.Request) (*url.URL, error) {
    return proxies[rand.Intn(len(proxies))], nil
}

c.SetProxyFunc(randomProxySwitcher)
```

### SSH as SOCKS5 Proxy

**Scenario**: You're in Kanpur but need to appear as if you're in Mumbai.

**Step 1**: Create SSH tunnel

```bash
ssh -D 1337 -q -C -N user@mumbai-server.com
```

**Flags Explained**:

- `-D 1337`: Opens port 1337 as SOCKS5 proxy
- `-q`: Quiet mode
- `-C`: Compress data
- `-N`: Don't execute remote commands

**Step 2**: Use in Colly

```go
c.SetProxyFunc(proxy.RoundRobinProxySwitcher("socks5://127.0.0.1:1337"))
```

**What Happens**:

```text
Your Computer (Kanpur) → SSH Tunnel → Mumbai Server → Target Website
Website sees: Mumbai IP ✓
```

### Multiple SSH Proxies

```bash
# Terminal 1
ssh -D 1337 user@mumbai-server.com

# Terminal 2
ssh -D 1338 user@delhi-server.com

# Terminal 3
ssh -D 1339 user@bangalore-server.com
```

```go
proxy.RoundRobinProxySwitcher(
    "socks5://127.0.0.1:1337",  // Mumbai
    "socks5://127.0.0.1:1338",  // Delhi
    "socks5://127.0.0.1:1339",  // Bangalore
)
```

**Benefit**: Rotates between three cities' IPs automatically.

### When to Use Proxy Switchers

- Avoiding IP bans
- Moderate scale (one machine sufficient)
- Need geo-specific access
- Simple setup preferred

---

## Distributed Scrapers (Advanced)

### Architecture

Run completely separate scraper instances on different machines, sharing state via external storage.

```text
Machine 1 (Scraper) ─┐
Machine 2 (Scraper) ─┼─→ Shared Redis Database
Machine 3 (Scraper) ─┘
```

### Why External Storage?

By default, Colly stores visited URLs and cookies in memory. Multiple machines can't share this data, leading to duplicate work.

**Solution**: Use shared storage (Redis, MongoDB, PostgreSQL) so all instances know what's been visited.

### Google App Engine Support

```go
c.Appengine(httpRequest)
```

Call this if running on App Engine standard environment.

### When to Use Distributed Scrapers

- Millions of pages
- Long-running jobs (days/weeks)
- Horizontal scaling required
- One machine's resources insufficient

---

## Storage Backends

### What Is a Storage Backend?

The system Colly uses to store:

- Visited URLs (prevent duplicates)
- Cookies and session data

### Default: In-Memory

Fast and simple, but:

- Lost on crash/restart
- Can't be shared across machines

### Available Backends

#### 1. In-Memory (Default)

```go
// No configuration needed
```

#### 2. Redis

```go
import "github.com/gocolly/redisstorage"

storage := &redisstorage.Storage{
    Address:  "localhost:6379",
    Password: "",
    DB:       0,
    Prefix:   "colly",
}
c.SetStorage(storage)
```

**Best For**: Distributed scraping, high-speed access, persistence

#### 3. PostgreSQL

```go
import "github.com/zolamk/colly-postgres-storage/colly/postgres"

storage := &postgres.Storage{
    URI: "postgres://user:pass@localhost:5432/dbname",
    VisitedTable: "colly_visited",
    CookiesTable: "colly_cookies",
}
c.SetStorage(storage)
```

**Best For**: Querying scraping history, durable storage

#### 4. MongoDB

```go
import "github.com/zolamk/colly-mongo-storage"

storage := &mongostorage.Storage{
    URI:      "mongodb://localhost:27017",
    Database: "colly",
}
c.SetStorage(storage)
```

**Best For**: Flexible schema, large distributed jobs

#### 5. SQLite3 / BoltDB

For local persistent storage without external databases.

### When to Use Which

- **In-Memory**: Small jobs, single machine, short-lived
- **Redis**: Distributed, fast, temporary persistence
- **SQL/Mongo**: Long-term storage, need to query history

### Real-World Example

Three scraper instances across different servers all connect to the same Redis. When one visits a URL, Redis records it. Others check Redis before visiting, avoiding duplicates. If one crashes, visited URLs remain in Redis.

---

## Multiple Collectors

### Why Multiple Collectors?

For complex scraping tasks with different page types or logic, using separate collectors keeps code organized.

### Example Use Case

Scraping a course platform:

- **Collector 1**: Scrapes course list, handles pagination
- **Collector 2**: Scrapes individual course details

### Creating Multiple Collectors

#### Method 1: Clone

```go
c := colly.NewCollector(
    colly.UserAgent("myUserAgent"),
    colly.AllowedDomains("foo.com", "bar.com"),
)

// c2 has same config but no callbacks
c2 := c.Clone()
```

**What Clone Does**: Copies configuration (user agent, domains, rate limits) but NOT callbacks.

#### Method 2: Separate Instances

```go
c1 := colly.NewCollector(colly.AllowedDomains("site1.com"))
c2 := colly.NewCollector(colly.AllowedDomains("site2.com"))
```

### Sharing Data Between Collectors

Use the `Context` object:

```go
c.OnResponse(func(r *colly.Response) {
    r.Ctx.Put("customData", "value")
    c2.Request("GET", "https://foo.com/", nil, r.Ctx, nil)
})

c2.OnResponse(func(r *colly.Response) {
    data := r.Ctx.Get("customData")
    fmt.Println(data) // "value"
})
```

### Debugging Multiple Collectors

Use `collector.ID` to distinguish logs:

```go
c.OnRequest(func(r *colly.Request) {
    fmt.Printf("[Collector %d] Visiting %s\n", r.Ctx.Get("collector_id"), r.URL)
})
```

### When to Use

- Multi-level sites (categories → products → reviews)
- Different rate limits per page type
- Modular, maintainable code
- Reuse configuration across similar scrapers

---

## Extensions

### What Are Extensions?

Pre-built helper functions that add common features to your scraper.

### Why Use Them?

- **Avoid Detection**: Look more like a real browser
- **Automate Tasks**: Set headers automatically
- **Cleaner Code**: No manual header management

### Available Extensions

#### 1. RandomUserAgent

Changes User-Agent for every request.

```go
import "github.com/gocolly/colly/extensions"

extensions.RandomUserAgent(c)
```

**Without Extension**:

```text
Request 1: User-Agent: Go-http-client/1.1
Request 2: User-Agent: Go-http-client/1.1
Request 3: User-Agent: Go-http-client/1.1
→ Easily detected as bot
```

**With Extension**:

```text
Request 1: User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/91.0
Request 2: User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/605.1
Request 3: User-Agent: Mozilla/5.0 (X11; Linux x86_64) Firefox/89.0
→ Looks like different users
```

#### 2. Referer

Sets the Referer header automatically.

```go
extensions.Referer(c)
```

**Why It Matters**: Some sites check if requests come from their own pages. Setting Referer makes it look like natural navigation.

**Example Flow**:

```text
Visit: https://shop.com/
Referer: (none)

Click link to: https://shop.com/products
Referer: https://shop.com/

Click link to: https://shop.com/products/123
Referer: https://shop.com/products
```

### Complete Example

```
import (
    "log"
    "github.com/gocolly/colly/v2"
    "github.com/gocolly/colly/extensions"
)

func main() {
    c := colly.NewCollector()
    visited := false

    // Enable extensions
    extensions.RandomUserAgent(c)
    extensions.Referer(c)

    c.OnResponse(func(r *colly.Response) {
        log.Println(string(r.Body))
        if !visited {
            visited = true
            r.Request.Visit("/get?q=2")
        }
    })

    c.Visit("http://httpbin.org/get")
}
```

### Real-World Scenario

**Without Extensions**:

```text
Visit 100 pages with same User-Agent
→ Site detects pattern
→ IP banned after 50 requests
```

**With Extensions**:

```text
Visit 100 pages with random User-Agent and Referer
→ Looks like 100 different users
→ No ban
```

### When to Use

- Scraping sites with anti-bot measures
- Need to mimic browser behavior
- Want to reduce detection risk

---

## Best Practices

### 1. Leave a Minimal Footprint

**Don't overload the target website**. Too many requests too fast can:

- Get your IP banned
- Slow down or crash the site
- Violate terms of service

**Solution**: Add delays and limit parallelism

```
c.Limit(&colly.LimitRule{
    DomainGlob:  "*",
    Parallelism: 2,
    Delay:       2 * time.Second,
})
```

**Real-World Example**:

**Bad**:

```go
// No limits - sends 1000 requests immediately
c := colly.NewCollector()
for i := 0; i < 1000; i++ {
    c.Visit(fmt.Sprintf("https://site.com/page%d", i))
}
→ Instant ban
```

**Good**:

```go
c := colly.NewCollector()
c.Limit(&colly.LimitRule{
    DomainGlob:  "*",
    Parallelism: 1,
    Delay:       2 * time.Second,
})
for i := 0; i < 1000; i++ {
    c.Visit(fmt.Sprintf("https://site.com/page%d", i))
}
→ Takes 33 minutes, no ban
```

### 2. Use Whitelists and Blacklists

Only visit URLs you actually need.

```
c := colly.NewCollector(
    colly.AllowedDomains("shop.com"),
    colly.URLFilters(
        regexp.MustCompile("https://shop\\.com/products/.*"),
    ),
)
```

**Example**: Scraping books from an online store. Don't waste time on `/about`, `/contact`, or external links.

### 3. Avoid Duplicate Requests

Don't visit the same URL twice unless necessary.

**Colly's Default**: Tracks visited URLs in memory.

**For Large Jobs**: Use persistent storage.

```go
import "github.com/gocolly/redisstorage"

storage := &redisstorage.Storage{Address: "localhost:6379"}
c.SetStorage(storage)
```

### 4. Respect robots.txt

Many sites publish rules for bots in `/robots.txt`.

```go
c := colly.NewCollector(
    colly.UserAgent("MyBot/1.0"),
    colly.IgnoreRobotsTxt(false), // Respect robots.txt
)
```

**Check manually**:

```text
https://example.com/robots.txt
```

### 5. Refine Your Selectors

Use precise CSS selectors to target only the data you need.

**Bad**:

```go
c.OnHTML("div", func(e *colly.HTMLElement) {
    // Too broad - matches thousands of divs
})
```

**Good**:

```go
c.OnHTML("div.product-card", func(e *colly.HTMLElement) {
    title := e.ChildText("h2.title")
    price := e.ChildText("span.price")
})
```

### 6. Handle Pagination

Scrape all pages, not just the first one.

```go
c.OnHTML(".pagination a.next", func(e *colly.HTMLElement) {
    nextPage := e.Attr("href")
    if nextPage != "" {
        e.Request.Visit(nextPage)
    }
})
```

**Real-World Example**:

```go
// Scrape all product pages
c.OnHTML("div.product", func(e *colly.HTMLElement) {
    // Extract product data
})

// Follow "Next" button
c.OnHTML("a.next-page", func(e *colly.HTMLElement) {
    e.Request.Visit(e.Attr("href"))
})

c.Visit("https://shop.com/products?page=1")
```

### 7. Handle Errors Gracefully

```go
c.OnError(func(r *colly.Response, err error) {
    log.Printf("Error: %s, URL: %s", err, r.Request.URL)
    
    // Retry logic
    if r.StatusCode == 429 { // Too Many Requests
        time.Sleep(10 * time.Second)
        r.Request.Retry()
    }
})
```

### 8. Use Rate Limiting Per Domain

```go
c.Limit(&colly.LimitRule{
    DomainGlob:  "shop.com",
    Parallelism: 2,
    Delay:       1 * time.Second,
})

c.Limit(&colly.LimitRule{
    DomainGlob:  "api.shop.com",
    Parallelism: 5,
    Delay:       500 * time.Millisecond,
})
```

Different sites tolerate different request rates. Configure accordingly.

---

## Complete Examples

### Example 1: Basic Product Scraper

```
package main

import (
    "fmt"
    "github.com/gocolly/colly/v2"
)

func main() {
    c := colly.NewCollector(
        colly.AllowedDomains("shop.com"),
    )

    c.OnHTML("div.product", func(e *colly.HTMLElement) {
        title := e.ChildText("h2.title")
        price := e.ChildText("span.price")
        fmt.Printf("Product: %s, Price: %s\n", title, price)
    })

    c.OnRequest(func(r *colly.Request) {
        fmt.Println("Visiting", r.URL)
    })

    c.Visit("https://shop.com/products")
}
```

### Example 2: Scraper with Pagination

```
package main

import (
    "fmt"
    "github.com/gocolly/colly/v2"
)

func main() {
    c := colly.NewCollector()

    c.OnHTML("div.product", func(e *colly.HTMLElement) {
        fmt.Println(e.ChildText("h2.title"))
    })

    c.OnHTML("a.next", func(e *colly.HTMLElement) {
        nextPage := e.Attr("href")
        if nextPage != "" {
            e.Request.Visit(nextPage)
        }
    })

    c.Visit("https://shop.com/products?page=1")
}
```

### Example 3: Distributed Scraper with Redis

```
package main

import (
    "github.com/gocolly/colly/v2"
    "github.com/gocolly/redisstorage"
)

func main() {
    c := colly.NewCollector()

    storage := &redisstorage.Storage{
        Address:  "localhost:6379",
        Password: "",
        DB:       0,
        Prefix:   "colly",
    }

    if err := c.SetStorage(storage); err != nil {
        panic(err)
    }

    c.OnHTML("a[href]", func(e *colly.HTMLElement) {
        e.Request.Visit(e.Attr("href"))
    })

    c.Visit("https://example.com")
}
```

### Example 4: Using Extensions

```
package main

import (
    "fmt"
    "github.com/gocolly/colly/v2"
    "github.com/gocolly/colly/extensions"
)

func main() {
    c := colly.NewCollector()

    extensions.RandomUserAgent(c)
    extensions.Referer(c)

    c.OnRequest(func(r *colly.Request) {
        fmt.Println("Visiting:", r.URL)
        fmt.Println("User-Agent:", r.Headers.Get("User-Agent"))
    })

    c.Visit("https://httpbin.org/headers")
}
```

### Example 5: Multiple Collectors

```
package main

import (
    "fmt"
    "github.com/gocolly/colly/v2"
)

func main() {
    // List page collector
    listCollector := colly.NewCollector(
        colly.AllowedDomains("courses.com"),
    )

    // Detail page collector
    detailCollector := listCollector.Clone()

    listCollector.OnHTML("a.course-link", func(e *colly.HTMLElement) {
        detailCollector.Visit(e.Attr("href"))
    })

    detailCollector.OnHTML("div.course-detail", func(e *colly.HTMLElement) {
        title := e.ChildText("h1")
        description := e.ChildText("p.description")
        fmt.Printf("Course: %s\nDescription: %s\n\n", title, description)
    })

    listCollector.Visit("https://courses.com/list")
}
```

---

## References

### Official Documentation

- [Colly Official Docs](https://go-colly.org/docs/)
- [Colly GitHub Repository](https://github.com/gocolly/colly)
- [Colly API Reference](https://pkg.go.dev/github.com/gocolly/colly/v2)

### Best Practices & Guides

- [Storage Backends](https://go-colly.org/docs/best_practices/storage/)
- [Extensions](https://go-colly.org/docs/best_practices/extensions/)
- [Debugging](https://go-colly.org/docs/best_practices/debugging/)
- [Distributed Scraping](https://go-colly.org/docs/best_practices/distributed/)
- [Web Scraping Tips](https://go-colly.org/articles/scraping_tips/)

### Storage Backend Implementations

- [Redis Storage](https://github.com/gocolly/redisstorage)
- [BoltDB Storage](https://github.com/earlzo/colly-bolt-storage)
- [SQLite3 Storage](https://github.com/velebak/colly-sqlite3-storage)
- [MongoDB Storage](https://github.com/zolamk/colly-mongo-storage)
- [PostgreSQL Storage](https://github.com/zolamk/colly-postgres-storage)

### Community Resources

- [Colly Examples](https://go-colly.org/docs/examples/)
- [GitHub Discussions](https://github.com/gocolly/colly/discussions)

---

## Summary

This documentation covers:

- ✅ Colly basics and architecture
- ✅ Collector configuration options
- ✅ Debugging techniques
- ✅ Distributed scraping strategies
- ✅ Proxy management (including SSH tunnels)
- ✅ Storage backends for persistence
- ✅ Multiple collector patterns
- ✅ Extensions for stealth and automation
- ✅ Production-ready best practices
- ✅ Complete working examples

**Next Steps**:

1. Install Colly: `go get github.com/gocolly/colly/v2`
2. Start with basic examples
3. Add rate limiting and storage as needed
4. Implement proxies for scale
5. Deploy to production with monitoring

---

**Document Version**: 1.0  
**Last Updated**: October 3, 2025  
**Maintained By**: Shardendu Mishra
