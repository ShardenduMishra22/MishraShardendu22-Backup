import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
export { default } from 'next-auth/middleware';

export const config = {
 matcher: ['/dashboard/:path*', '/sign-in', '/sign-up', '/', '/verify/:path*'],
};

export async function middleware(request: NextRequest) {
 const token = await getToken({ req: request, secret: process.env.SECRET });
 const url = request.nextUrl;
 // console.log('Token:', token);

 // Redirect to dashboard if the user is already authenticated
 // and trying to access sign-in, sign-up, or home page
 if (
  token &&
  (url.pathname.startsWith('/sign-in') ||
   url.pathname.startsWith('/sign-up') ||
   url.pathname.startsWith('/verify-code') ||
   url.pathname === '/')
 ) {
  return NextResponse.redirect(new URL('/dashboard', request.url));
 }

 if (!token && url.pathname.startsWith('/dashboard')) {
  return NextResponse.redirect(new URL('/sign-in', request.url));
 }

 return NextResponse.next();
}
