# Go Description Script

Production-ready Go agent and dashboard for improving GitHub repository descriptions and topics with OpenRouter. The platform keeps the existing CLI workflow for repository processing, and provides a separate dashboard/API server for OpenRouter health, failover visibility, metrics, and live SSE events.

## Architecture Overview

- **CLI pipeline:** discovers repositories through GitHub, snapshots README/manifest files, inspects technologies, generates metadata through OpenRouter, normalizes and validates output, writes a manifest, and optionally applies GitHub updates.
- **Worker pools:** separate pools drive discovery/inspection, LLM generation, and GitHub updates. Bounded channels provide backpressure between stages.
- **OpenRouter routing:** multiple API keys and models are selected with weighted rotation, failure-aware weight reduction, cooldowns, retry handling, and fallback routing.
- **State and observability:** key/model health, request metrics, retry/failover counters, pipeline snapshots, and live events are exposed by the backend.
- **Frontend dashboard:** a Next.js control room consumes the backend APIs and `/api/events` SSE stream with runtime validation, reconnect handling, and safe rendering for malformed events.

## Docker Startup

Docker Compose starts the dashboard platform: backend API/SSE server plus frontend. It does **not** run repository processing automatically; run the CLI separately for manifest generation or GitHub updates.

```bash
cp .env.example .env
# fill GITHUB_TOKEN and OPENROUTER_API_KEY or OPENROUTER_API_KEYS
docker compose up --build
```

Open:

- Frontend: `http://localhost:3000`
- Backend health: `http://localhost:8080/healthz`
- Backend readiness: `http://localhost:8080/readyz`
- Metrics API: `http://localhost:8080/api/openrouter/metrics`
- SSE stream: `http://localhost:8080/api/events?recent=80`

Compose uses a persistent `backend-data` volume for:

- `/app/data/repos-manifest.json`
- `/app/data/.metadata-cache.json`
- `/app/data/.openrouter-state.json`

Mounted secrets are supported with `_FILE` variables:

```bash
mkdir -p secrets
printf '%s' "$GITHUB_TOKEN" > secrets/github_token
printf '%s' "$OPENROUTER_API_KEY" > secrets/openrouter_api_key

GITHUB_TOKEN_FILE=/run/secrets/github_token \
OPENROUTER_API_KEY_FILE=/run/secrets/openrouter_api_key \
docker compose up --build
```

Direct env vars take priority over `_FILE` values.

## Local Development

Backend:

```bash
go mod download
go run main.go serve --server-addr=:8080
```

Frontend:

```bash
cd frontend
pnpm install
NEXT_PUBLIC_API_BASE=http://localhost:8080 pnpm dev
```

Run the CLI pipeline:

```bash
go run main.go --dry-run
go run main.go --generate-manifest --limit=10
go run main.go --apply-manifest=repos-manifest.json --preview-only
go run main.go --apply-manifest=repos-manifest.json
```

## Environment Variables

Core credentials:

```env
GITHUB_TOKEN=
GITHUB_TOKEN_FILE=
OPENROUTER_API_KEY=
OPENROUTER_API_KEY_FILE=
OPENROUTER_API_KEYS=
OPENROUTER_API_KEYS_FILE=
OPENROUTER_MODELS=openai/gpt-oss-120b:free
```

Pipeline and routing:

```env
WORKERS=5
LLM_WORKERS=3
GITHUB_WORKERS=2
GITHUB_RPS=1
OPENROUTER_RPS=1
OPENROUTER_MAX_CONCURRENCY=0
OPENROUTER_MAX_QUEUE=200
RETRIES=3
REPO_TIMEOUT=3m
```

Cooldown and persistence:

```env
OPENROUTER_COOLDOWN_SHORT=30s
OPENROUTER_COOLDOWN_MEDIUM=2m
OPENROUTER_COOLDOWN_LONG=10m
OPENROUTER_MAX_CONSECUTIVE_FAILS=2
OPENROUTER_STATE_FILE=.openrouter-state.json
OPENROUTER_PERSIST_INTERVAL=15s
```

Filtering and validation:

```env
REPO=
LIMIT=0
ALLOWLIST=
BLOCKLIST=
EXCLUDE_TOPIC=
LOCKED_REPOS=
CONFIDENCE_MODE=
CONFIDENCE_THRESHOLD=0.45
```

Server/frontend:

```env
SERVER_ADDR=:8080
SERVER_ALLOW_ORIGIN=*
NEXT_PUBLIC_API_BASE=http://localhost:8080
```

## OpenRouter Failover

- Keys and models are selected by weighted rotation.
- Successes, failures, active load, and latency influence effective weight.
- Rate limit, quota, timeout, invalid key, model-not-found, and server failures are classified separately.
- Cooldowns prevent retry storms after repeated failures.
- Key health and model health are persisted by `OPENROUTER_STATE_FILE` and restored on restart.
- Admin APIs can disable, enable, reload, or reset cooldowns for keys and models.

Useful APIs:

```bash
curl http://localhost:8080/api/openrouter/keys
curl http://localhost:8080/api/openrouter/models
curl http://localhost:8080/api/openrouter/metrics
curl -X POST http://localhost:8080/api/openrouter/admin \
  -H 'Content-Type: application/json' \
  -d '{"target":"model","action":"reset_cooldown","id":"openai/gpt-oss-120b:free"}'
```

## SSE Event Architecture

Events are streamed from `/api/events` as JSON Server-Sent Events. The backend keeps a bounded ring buffer and supports replay by `Last-Event-ID` plus `?recent=N`.

Current event envelope:

```json
{
  "schema_version": 1,
  "id": 42,
  "event": "worker_update",
  "timestamp": "2026-05-15T12:00:00Z",
  "worker_id": 2,
  "repo": "owner/repo",
  "stage": "llm_generation",
  "status": "started",
  "details": {}
}
```

The frontend validates event shape before rendering. Unknown event types are shown as generic events; malformed events are counted and skipped rather than crashing the dashboard.

## Worker Pools and Backpressure

- Discovery, snapshot, inspection, normalization, and validation use the general `WORKERS` pool.
- LLM generation uses `LLM_WORKERS`.
- GitHub update application uses `GITHUB_WORKERS`.
- OpenRouter concurrency is bounded by `OPENROUTER_MAX_CONCURRENCY`; `0` defaults to `LLM_WORKERS`.
- `OPENROUTER_MAX_QUEUE` caps queued plus in-flight OpenRouter work. When full, the client returns backpressure instead of growing memory unbounded.

## Scaling Guidance

- Increase `WORKERS` for repositories with many files or slow GitHub reads.
- Increase `LLM_WORKERS` only with enough OpenRouter quota and key capacity.
- Keep `OPENROUTER_RPS` conservative when using free or shared models.
- Use multiple keys with `OPENROUTER_API_KEYS` for failover, not as a way to bypass provider policy.
- Prefer higher `OPENROUTER_MAX_QUEUE` for batch throughput and lower values for interactive reliability.
- Persist `/app/data` in Docker so cooldown state survives restarts.

## Troubleshooting

- **Dashboard shows reconnecting:** check `curl http://localhost:8080/readyz` and browser access to `NEXT_PUBLIC_API_BASE`.
- **SSE connects but no events appear:** run an admin action or pipeline command; the dashboard safely waits on an empty stream.
- **OpenRouter requests fail fast:** inspect `/api/openrouter/keys`, cooldown fields, and `last_failure_type`.
- **Repeated rate limits:** lower `OPENROUTER_RPS`, reduce `LLM_WORKERS`, or increase cooldowns.
- **Queue full/backpressure:** reduce pipeline concurrency or increase `OPENROUTER_MAX_QUEUE`.
- **GitHub updates skipped:** inspect the manifest `failures`, `update_status.skip_reason`, confidence score, allowlist/blocklist, and locked repo config.
- **Docker frontend cannot reach backend:** rebuild with `NEXT_PUBLIC_API_BASE=http://localhost:8080` or the externally reachable backend URL.

## Verification Commands

```bash
GOCACHE=/tmp/go-build go test ./...
CGO_ENABLED=1 GOCACHE=/tmp/go-build-race go test -race ./...
GOCACHE=/tmp/go-build go build ./...

cd frontend
pnpm lint
pnpm exec tsc --noEmit
pnpm build

cd ..
docker compose config
docker compose build
docker compose up -d
curl http://localhost:8080/healthz
curl http://localhost:8080/api/openrouter/metrics
docker compose down
```

## Screenshot Placeholders

- Dashboard overview: `docs/screenshots/dashboard-overview.png`
- Key/model health: `docs/screenshots/routing-health.png`
- Live SSE events: `docs/screenshots/live-events.png`

## Safety Notes

- `--dry-run` and `--preview-only` are the safest ways to inspect output before updating GitHub.
- `--generate-manifest` creates a reviewable manifest without applying changes.
- `--apply-manifest` applies an existing manifest and should be used only after validation.
- Docker Compose is intentionally dashboard-only by default; it will not mutate GitHub repositories on startup.
