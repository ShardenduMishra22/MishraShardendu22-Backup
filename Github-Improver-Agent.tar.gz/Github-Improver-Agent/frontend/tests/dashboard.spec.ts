import { expect, test } from "@playwright/test";

const dashboardStatus = {
  job: {
    id: "job-1",
    running: false,
    paused: false,
    mode: "idle",
    selection: [],
    started_at: "",
    finished_at: "",
    last_error: "",
    reason: "",
  },
  run: {
    running: false,
    mode: "idle",
    started_at: "",
    finished_at: "",
    last_error: "",
  },
  snapshot: {
    queues: {},
    queue_capacity: {},
    stages: {},
    updated_at: "",
  },
  openrouter: {
    active_requests: 0,
    queued_requests: 0,
    queue_capacity: 0,
    max_concurrency: 0,
    total_requests: 0,
    successes: 0,
    failures: 0,
    retries: 0,
    failovers: 0,
    avg_latency_ms: 0,
    success_rate: 0,
    keys: [],
    models: [],
    updated_at: "",
  },
  repositories: [
    {
      owner: "acme",
      name: "dashboard-demo",
      full_name: "acme/dashboard-demo",
      clone_url: "https://github.com/acme/dashboard-demo",
      default_branch: "main",
      primary_language: "TypeScript",
      description: "Demo repo for dashboard coverage",
      topics: ["dashboard"],
      readme_content: "# Demo",
      detected_tech: ["Next.js", "Go"],
      detected_frameworks: ["Next.js"],
      important_files: ["app/page.tsx"],
      confidence_score: 0.9,
      generated_metadata: undefined,
      failures: [],
      update_status: {
        description_updated: false,
        topics_updated: false,
        skipped: false,
        skip_reason: "",
        updated_at: "",
      },
      stage_results: {},
      retries: { total: 0, by_stage: {} },
      documentation: {
        readme_generation_state: "",
        documentation_generation_state: "",
        current_readme: "",
        generated_readme: "",
        current_quality_score: 0,
        preview_only: false,
        section_changes: [],
        generated_at: "",
        applied_at: "",
        diff: "",
      },
      file_write_results: [],
      backup_path: "",
      rollback_status: {
        completed: false,
        rolled_back_at: "",
        backup_path: "",
        error: "",
      },
      original_description: "",
      original_topics: [],
      architecture_style: "",
      engineering_domain: "",
      deployment_model: "",
      project_intent: "",
      backend_frontend: "",
      infrastructure: [],
      APIs: [],
      project_category: "",
    },
  ],
  summary: {
    current_stage: "",
    current_repo: "",
    current_worker: 0,
    queue_depth: 0,
    active_workers: 0,
    repos_completed: 0,
    repos_failed: 0,
    repos_processing: 0,
    retries: 0,
    api_latency_ms: 0,
    failovers: 0,
    cooldowns: [],
    model_usage: [],
    key_usage: [],
  },
  events: [],
};

test("dashboard renders controls and stack data", async ({ page }) => {
  await page.route("**/api/pipeline/status", async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(dashboardStatus),
    });
  });

  await page.goto("/");

  await expect(
    page.getByRole("heading", { name: "Orchestration Control Plane" }),
  ).toBeVisible();
  await expect(page.getByRole("button", { name: "Run Agent" })).toBeVisible();
  await expect(page.getByText("Dashboard Metrics")).toBeVisible();
  await expect(page.getByText("Tech Stack")).toBeVisible();
  await expect(page.getByText("Next.js")).toBeVisible();
  await expect(page.getByText("acme/dashboard-demo")).toBeVisible();
});

test("run agent button sends the expected pipeline request", async ({ page }) => {
  const requests: Array<Record<string, unknown>> = [];

  await page.route("**/api/pipeline/status", async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(dashboardStatus),
    });
  });

  await page.route("**/api/pipeline/start", async (route) => {
    requests.push(route.request().postDataJSON() as Record<string, unknown>);
    await route.fulfill({
      status: 202,
      contentType: "application/json",
      body: JSON.stringify(dashboardStatus),
    });
  });

  await page.goto("/");
  await page.getByRole("button", { name: "Run Agent" }).click();

  await expect.poll(() => requests.length).toBe(1);
  expect(requests[0]).toMatchObject({
    reason: "dashboard run agent",
  });
});
