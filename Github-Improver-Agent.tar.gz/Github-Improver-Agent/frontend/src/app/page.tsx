"use client";

import type { ReactNode } from "react";
import { useCallback, useEffect, useMemo, useState } from "react";

type PipelineJobState = {
  id: string;
  running: boolean;
  paused: boolean;
  mode: string;
  selection: string[];
  started_at: string;
  finished_at: string;
  last_error: string;
  reason: string;
};

type StageSnapshot = {
  active: number;
  processed: number;
  failed: number;
  retried: number;
  avg_duration_ms: number;
};

type PipelineSnapshot = {
  queues: Record<string, number>;
  queue_capacity: Record<string, number>;
  stages: Record<string, StageSnapshot>;
  updated_at: string;
};

type PipelineRun = {
  running: boolean;
  mode: string;
  started_at: string;
  finished_at: string;
  last_error: string;
};

type KeyHealth = {
  id: string;
  masked: string;
  weight: number;
  requests: number;
  successes: number;
  failures: number;
  consecutive_failures: number;
  active: number;
  avg_latency_ms: number;
  success_rate: number;
  last_used: string;
  last_failure: string;
  last_failure_type: string;
  cooldown_until: string;
  cooldown_seconds: number;
  healthy: boolean;
  disabled: boolean;
};

type ModelHealth = {
  model: string;
  weight: number;
  requests: number;
  successes: number;
  failures: number;
  consecutive_failures: number;
  active: number;
  avg_latency_ms: number;
  success_rate: number;
  last_used: string;
  last_failure: string;
  last_failure_type: string;
  cooldown_until: string;
  cooldown_seconds: number;
  healthy: boolean;
  disabled: boolean;
};

type OpenRouterMetrics = {
  active_requests: number;
  queued_requests: number;
  queue_capacity: number;
  max_concurrency: number;
  total_requests: number;
  successes: number;
  failures: number;
  retries: number;
  failovers: number;
  avg_latency_ms: number;
  success_rate: number;
  keys: KeyHealth[];
  models: ModelHealth[];
  updated_at: string;
};

type RepoFailure = {
  stage: string;
  error: string;
};

type ValidationSummary = {
  valid: boolean;
  description_valid: boolean;
  topics_valid: boolean;
  generated_description: string;
  generated_topics: string[];
  validated_description: string;
  validated_topics: string[];
  current_description: string;
  current_topics: string[];
  added_topics: string[];
  removed_topics: string[];
  warnings: string[];
  confidence: {
    readme_quality: number;
    file_coverage: number;
    technology_accuracy: number;
    metadata_score: number;
    metadata_confidence: number;
  };
};

type GeneratedMetadata = {
  description: string;
  topics: string[];
  confidence_score: number;
  validation: ValidationSummary;
  cache_hit: boolean;
};

type DocumentationState = {
  readme_generation_state: string;
  documentation_generation_state: string;
  current_readme: string;
  generated_readme: string;
  current_quality_score: number;
  preview_only: boolean;
  section_changes: string[];
  generated_at: string;
  applied_at: string;
  diff: string;
};

type RepoManifest = {
  owner: string;
  name: string;
  full_name: string;
  clone_url: string;
  default_branch: string;
  primary_language: string;
  description: string;
  topics: string[];
  readme_content: string;
  detected_tech: string[];
  detected_frameworks: string[];
  important_files: string[];
  confidence_score: number;
  generated_metadata?: GeneratedMetadata;
  failures: RepoFailure[];
  update_status: {
    description_updated: boolean;
    topics_updated: boolean;
    skipped: boolean;
    skip_reason: string;
    updated_at: string;
  };
  stage_results: Record<string, boolean>;
  retries: { total: number; by_stage: Record<string, number> };
  documentation: DocumentationState;
  file_write_results: Array<{
    path: string;
    backup_path: string;
    status: string;
    error: string;
    dry_run: boolean;
    rolled_back: boolean;
    written_at: string;
  }>;
  backup_path: string;
  rollback_status: {
    completed: boolean;
    rolled_back_at: string;
    backup_path: string;
    error: string;
  };
  original_description: string;
  original_topics: string[];
  architecture_style: string;
  engineering_domain: string;
  deployment_model: string;
  project_intent: string;
  backend_frontend: string;
  infrastructure: string[];
  APIs: string[];
  project_category: string;
  [key: string]: unknown;
};

type PipelineSummary = {
  current_stage: string;
  current_repo: string;
  current_worker: number;
  queue_depth: number;
  active_workers: number;
  repos_completed: number;
  repos_failed: number;
  repos_processing: number;
  retries: number;
  api_latency_ms: number;
  failovers: number;
  cooldowns: Array<Record<string, unknown>>;
  model_usage: ModelHealth[];
  key_usage: KeyHealth[];
};

type PipelineStatusResponse = {
  job: PipelineJobState;
  run: PipelineRun;
  snapshot: PipelineSnapshot;
  openrouter: OpenRouterMetrics;
  repositories: RepoManifest[];
  summary: PipelineSummary;
  events: StreamEvent[];
};

type StreamEvent = {
  schema_version: number;
  id: number;
  event: string;
  timestamp: string;
  worker_id?: number;
  repo?: string;
  stage?: string;
  status?: string;
  attempt?: number;
  message?: string;
  error?: string;
  details: Record<string, unknown>;
};

type RepoActionResponse = {
  repo: string;
  action: string;
  mode: string;
  preview: {
    current: string;
    generated: string;
    diff: string;
    section_changes: string[];
    quality_score: number;
    enhance_mode: boolean;
    safe_to_write: boolean;
  };
  backup_path?: string;
  generated_readme?: string;
  manifest_updated: boolean;
  dry_run?: boolean;
  rollback?: boolean;
  queued?: boolean;
  description?: string;
  topics?: string[];
  path?: string;
};

type ActiveRepoAction = {
  action: string;
  response: RepoActionResponse;
};

function normalizeStatusResponse(
  status: Partial<PipelineStatusResponse>,
): PipelineStatusResponse {
  const job = status.job ?? emptyStatus.job;
  const run = status.run ?? emptyStatus.run;
  const snapshot = status.snapshot ?? emptyStatus.snapshot;
  const openrouter = status.openrouter ?? emptyStatus.openrouter;
  const summary = status.summary ?? emptyStatus.summary;

  return {
    job: {
      ...emptyStatus.job,
      ...job,
      selection: job.selection ?? [],
    },
    run: {
      ...emptyStatus.run,
      ...run,
    },
    snapshot: {
      ...emptyStatus.snapshot,
      ...snapshot,
      queues: snapshot.queues ?? {},
      queue_capacity: snapshot.queue_capacity ?? {},
      stages: snapshot.stages ?? {},
    },
    openrouter: {
      ...emptyStatus.openrouter,
      ...openrouter,
      keys: openrouter.keys ?? [],
      models: openrouter.models ?? [],
    },
    repositories: status.repositories ?? [],
    summary: {
      ...emptyStatus.summary,
      ...summary,
      cooldowns: summary.cooldowns ?? [],
      model_usage: summary.model_usage ?? [],
      key_usage: summary.key_usage ?? [],
    },
    events: status.events ?? [],
  };
}

function normalizeRepoManifest(repo: Partial<RepoManifest>): RepoManifest {
  const defaultDocumentation: DocumentationState = {
    readme_generation_state: "",
    documentation_generation_state: "",
    current_readme: "",
    generated_readme: "",
    current_quality_score: 0,
    preview_only: false,
    section_changes: [],
    generated_at: "",
    applied_at: "",
    diff: "",
  };

  const defaultUpdateStatus = {
    description_updated: false,
    topics_updated: false,
    skipped: false,
    skip_reason: "",
    updated_at: "",
  };

  const defaultRollbackStatus = {
    completed: false,
    rolled_back_at: "",
    backup_path: "",
    error: "",
  };

  const defaultRetries = { total: 0, by_stage: {} as Record<string, number> };

  return {
    owner: repo.owner ?? "",
    name: repo.name ?? "",
    full_name: repo.full_name ?? "",
    clone_url: repo.clone_url ?? "",
    default_branch: repo.default_branch ?? "",
    primary_language: repo.primary_language ?? "",
    description: repo.description ?? "",
    topics: repo.topics ?? [],
    readme_content: repo.readme_content ?? "",
    detected_tech: repo.detected_tech ?? [],
    detected_frameworks: repo.detected_frameworks ?? [],
    important_files: repo.important_files ?? [],
    failures: repo.failures ?? [],
    confidence_score: repo.confidence_score ?? 0,
    generated_metadata: repo.generated_metadata,
    update_status: repo.update_status ?? defaultUpdateStatus,
    original_topics: repo.original_topics ?? [],
    stage_results: repo.stage_results ?? {},
    retries: repo.retries ?? defaultRetries,
    documentation: repo.documentation ?? defaultDocumentation,
    file_write_results: repo.file_write_results ?? [],
    backup_path: repo.backup_path ?? "",
    rollback_status: repo.rollback_status ?? defaultRollbackStatus,
    original_description: repo.original_description ?? "",
    architecture_style: repo.architecture_style ?? "",
    engineering_domain: repo.engineering_domain ?? "",
    deployment_model: repo.deployment_model ?? "",
    project_intent: repo.project_intent ?? "",
    backend_frontend: repo.backend_frontend ?? "",
    infrastructure: repo.infrastructure ?? [],
    APIs: repo.APIs ?? [],
    project_category: repo.project_category ?? "",
  };
}

const apiBase =
  typeof window === "undefined"
    ? ""
    : process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8080";

const emptyStatus: PipelineStatusResponse = {
  job: {
    id: "",
    running: false,
    paused: false,
    mode: "",
    selection: [],
    started_at: "",
    finished_at: "",
    last_error: "",
    reason: "",
  },
  run: {
    running: false,
    mode: "",
    started_at: "",
    finished_at: "",
    last_error: "",
  },
  snapshot: {
    queues: {},
    queue_capacity: {},
    stages: {},
    updated_at: "",
  },
  openrouter: {
    active_requests: 0,
    queued_requests: 0,
    queue_capacity: 0,
    max_concurrency: 0,
    total_requests: 0,
    successes: 0,
    failures: 0,
    retries: 0,
    failovers: 0,
    avg_latency_ms: 0,
    success_rate: 0,
    keys: [],
    models: [],
    updated_at: "",
  },
  repositories: [],
  summary: {
    current_stage: "",
    current_repo: "",
    current_worker: 0,
    queue_depth: 0,
    active_workers: 0,
    repos_completed: 0,
    repos_failed: 0,
    repos_processing: 0,
    retries: 0,
    api_latency_ms: 0,
    failovers: 0,
    cooldowns: [],
    model_usage: [],
    key_usage: [],
  },
  events: [],
};

export default function Home() {
  const [status, setStatus] = useState<PipelineStatusResponse>(emptyStatus);
  const [events, setEvents] = useState<StreamEvent[]>([]);
  const [selectedRepo, setSelectedRepo] = useState<string>("");
  const [repoAction, setRepoAction] = useState<ActiveRepoAction | null>(null);
  const [errorText, setErrorText] = useState("");
  const [streamState, setStreamState] = useState<
    "connecting" | "live" | "reconnecting" | "offline"
  >("connecting");
  const [lastRefresh, setLastRefresh] = useState("");
  const [selectedActionMode, setSelectedActionMode] = useState<
    "preview" | "apply"
  >("preview");
  const [filter, setFilter] = useState("");

  const selectedRepoManifest = useMemo(() => {
    return (
      status.repositories.find((repo) => repo.full_name === selectedRepo) ??
      status.repositories[0] ??
      null
    );
  }, [selectedRepo, status.repositories]);

  const refreshStatus = useCallback(async () => {
    const response = await fetch(`${apiBase}/api/pipeline/status`, {
      cache: "no-store",
    });
    if (!response.ok) {
      throw new Error(`status HTTP ${response.status}`);
    }
    const next = normalizeStatusResponse(
      (await response.json()) as Partial<PipelineStatusResponse>,
    );
    next.repositories = next.repositories.map((repo) =>
      normalizeRepoManifest(repo),
    );
    setStatus(next);
    if (!selectedRepo && next.repositories.length > 0) {
      setSelectedRepo(next.repositories[0].full_name);
    }
    setLastRefresh(new Date().toLocaleTimeString());
  }, [selectedRepo]);

  useEffect(() => {
    refreshStatus().catch((error: unknown) => {
      setErrorText(
        error instanceof Error ? error.message : "failed to load status",
      );
    });
    const timer = window.setInterval(() => {
      refreshStatus().catch((error: unknown) => {
        setErrorText(
          error instanceof Error ? error.message : "failed to refresh status",
        );
      });
    }, 5000);
    return () => window.clearInterval(timer);
  }, [refreshStatus]);

  useEffect(() => {
    if (!apiBase) {
      return;
    }
    const source = new EventSource(`${apiBase}/api/events?recent=120`);
    setStreamState("connecting");
    source.onopen = () => setStreamState("live");
    source.onerror = () => setStreamState("reconnecting");
    source.onmessage = (message) => {
      const parsed = parseEvent(message.data, message.lastEventId);
      if (!parsed) {
        return;
      }
      setEvents((prev) =>
        [parsed, ...prev.filter((event) => event.id !== parsed.id)].slice(
          0,
          120,
        ),
      );
    };
    return () => source.close();
  }, []);

  const callPipeline = useCallback(
    async (path: string, payload: Record<string, unknown> = {}) => {
      setErrorText("");
      const response = await fetch(`${apiBase}${path}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      await refreshStatus();
    },
    [refreshStatus],
  );

  const callRepoAction = useCallback(
    async (action: string, mode: "preview" | "apply" = selectedActionMode) => {
      if (!selectedRepoManifest) {
        return;
      }
      setErrorText("");
      const response = await fetch(`${apiBase}/api/repos/action`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          repo: selectedRepoManifest.full_name,
          action,
          mode,
        }),
      });
      if (!response.ok) {
        throw new Error(`repo action HTTP ${response.status}`);
      }
      const next = (await response.json()) as RepoActionResponse;
      setRepoAction({ action, response: next });
      await refreshStatus();
    },
    [refreshStatus, selectedActionMode, selectedRepoManifest],
  );

  const currentStage = status.summary.current_stage || stageName(status);
  const currentRepo =
    status.summary.current_repo ||
    status.job.selection[0] ||
    selectedRepoManifest?.full_name ||
    "-";

  const filteredRepos = useMemo(() => {
    const query = filter.trim().toLowerCase();
    if (!query) {
      return status.repositories;
    }
    return status.repositories.filter((repo) => {
      return [
        repo.full_name,
        repo.name,
        repo.primary_language,
        repo.project_category,
        repo.engineering_domain,
      ]
        .filter(Boolean)
        .some((value) => value.toLowerCase().includes(query));
    });
  }, [filter, status.repositories]);

  const statusTone = status.job.running
    ? status.job.paused
      ? "warn"
      : "good"
    : "neutral";

  return (
    <main className="min-h-screen px-4 py-6 text-[15px] text-[var(--text)] md:px-8 lg:px-10">
      <header className="grid gap-6 xl:grid-cols-[minmax(0,1.2fr)_minmax(380px,0.8fr)]">
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <Badge
              tone={
                streamState === "live"
                  ? "good"
                  : streamState === "reconnecting"
                    ? "warn"
                    : "neutral"
              }
            >
              {" "}
              {streamState}{" "}
            </Badge>
            <Badge tone={statusTone}>
              {status.job.running
                ? status.job.paused
                  ? "paused"
                  : "running"
                : "idle"}
            </Badge>
            <Badge tone={status.summary.queue_depth > 0 ? "warn" : "neutral"}>
              queue {status.summary.queue_depth}
            </Badge>
            <Badge tone={status.summary.repos_failed > 0 ? "warn" : "good"}>
              failed {status.summary.repos_failed}
            </Badge>
          </div>
          <div className="space-y-3">
            <h1 className="text-3xl font-semibold tracking-tight lg:text-5xl">
              Orchestration Control Plane
            </h1>
            <p className="max-w-3xl text-sm leading-6 text-[var(--muted)]">
              Start, pause, resume, and rerun the repository metadata pipeline
              from a single control surface with live SSE updates, repo-level
              documentation preview, and safe writeback controls.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <ActionButton
              onClick={() =>
                callPipeline("/api/pipeline/start", {
                  reason: "dashboard run agent",
                })
              }
            >
              Run Agent
            </ActionButton>
            <ActionButton
              onClick={() =>
                callPipeline("/api/pipeline/start", {
                  reason: "dashboard start",
                })
              }
            >
              Start Pipeline
            </ActionButton>
            <ActionButton onClick={() => callPipeline("/api/pipeline/stop")}>
              Stop Pipeline
            </ActionButton>
            <ActionButton onClick={() => callPipeline("/api/pipeline/pause")}>
              Pause Pipeline
            </ActionButton>
            <ActionButton onClick={() => callPipeline("/api/pipeline/resume")}>
              Resume Pipeline
            </ActionButton>
            <ActionButton
              onClick={() =>
                callPipeline("/api/pipeline/retry", {
                  reason: "retry failed repositories",
                })
              }
            >
              Retry Failed Repos
            </ActionButton>
            <ActionButton
              onClick={() =>
                callPipeline("/api/pipeline/start", {
                  generate_manifest: true,
                  preview_only: true,
                  reason: "regenerate manifest",
                })
              }
            >
              Regenerate Manifest
            </ActionButton>
            <ActionButton
              onClick={() =>
                callPipeline("/api/pipeline/retry", {
                  repo: selectedRepoManifest?.full_name,
                  reason: "rerun selected repo",
                })
              }
            >
              Re-run Selected Repo
            </ActionButton>
            <ActionButton onClick={() => refreshStatus()}>
              Refresh Metrics
            </ActionButton>
          </div>
          {errorText ? (
            <div className="max-w-3xl rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
              {errorText}
            </div>
          ) : null}
        </div>
        <section className="grid gap-4 rounded-2xl border border-[var(--stroke)] bg-[var(--surface)] p-5 shadow-[0_24px_80px_rgba(0,0,0,0.28)]">
          <div className="text-xs uppercase tracking-[0.22em] text-[var(--muted)]">
            live execution state
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <Stat label="Current Stage" value={currentStage || "-"} />
            <Stat
              label="Active Workers"
              value={status.summary.active_workers}
            />
            <Stat label="Queue Depth" value={status.summary.queue_depth} />
            <Stat label="Current Repo" value={shortRepo(currentRepo)} />
            <Stat label="Completed" value={status.summary.repos_completed} />
            <Stat label="Failed" value={status.summary.repos_failed} />
            <Stat label="Processing" value={status.summary.repos_processing} />
            <Stat label="Retries" value={status.summary.retries} />
          </div>
        </section>
      </header>

      <section className="mt-8 grid gap-6 xl:grid-cols-[minmax(0,1.4fr)_minmax(380px,0.6fr)]">
        <div className="grid gap-6">
          <Panel
            title="Dashboard Metrics"
            subtitle={`Last refresh ${lastRefresh || "pending"}`}
          >
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              <MetricCard
                label="API latency"
                value={`${status.summary.api_latency_ms} ms`}
              />
              <MetricCard
                label="OpenRouter latency"
                value={`${status.openrouter.avg_latency_ms} ms`}
              />
              <MetricCard
                label="OpenRouter retries"
                value={status.openrouter.retries}
              />
              <MetricCard label="Failovers" value={status.summary.failovers} />
              <MetricCard
                label="Success rate"
                value={`${Math.round(status.openrouter.success_rate * 100)}%`}
              />
              <MetricCard
                label="Key usage"
                value={status.openrouter.keys.length}
              />
              <MetricCard
                label="Model usage"
                value={status.openrouter.models.length}
              />
              <MetricCard
                label="Cooldowns"
                value={status.summary.cooldowns.length}
              />
            </div>
          </Panel>

          <Panel
            title="Execution Timeline"
            subtitle="repo queued, analysis, generation, validation, update, completion"
          >
            <div className="space-y-3">
              {events.length === 0 ? (
                <EmptyState label="Waiting for live events" />
              ) : (
                events
                  .slice(0, 24)
                  .map((event) => <TimelineRow key={event.id} event={event} />)
              )}
            </div>
          </Panel>

          <Panel
            title="Repository Intelligence"
            subtitle="Understanding inferred from README, source tree, dependencies, and infra signals"
          >
            <div className="grid gap-4 lg:grid-cols-[280px_minmax(0,1fr)]">
              <div className="space-y-3">
                <label
                  htmlFor="repo-filter"
                  className="text-xs uppercase tracking-[0.18em] text-[var(--muted)]"
                >
                  Filter repositories
                </label>
                <input
                  id="repo-filter"
                  value={filter}
                  onChange={(event) => setFilter(event.target.value)}
                  placeholder="search repo, tech, domain"
                  className="w-full rounded-lg border border-[var(--stroke)] bg-[var(--surface-2)] px-3 py-2 outline-none focus:border-[var(--accent)]"
                />
                <div className="max-h-[420px] space-y-2 overflow-auto pr-1">
                  {filteredRepos.map((repo) => (
                    <button
                      key={repo.full_name}
                      type="button"
                      onClick={() => setSelectedRepo(repo.full_name)}
                      className={`w-full rounded-xl border px-3 py-3 text-left transition ${selectedRepo === repo.full_name ? "border-[var(--accent)] bg-[var(--surface-2)]" : "border-[var(--stroke)] bg-transparent hover:border-[var(--accent)]"}`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate font-semibold">
                          {repo.full_name}
                        </span>
                        <span className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] uppercase tracking-[0.18em] text-[var(--muted)]">
                          {repo.primary_language || "unknown"}
                        </span>
                      </div>
                      <div className="mt-1 line-clamp-2 text-xs text-[var(--muted)]">
                        {repo.project_intent ||
                          repo.description ||
                          repo.project_category ||
                          "Repository intelligence inferred from source signals."}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {selectedRepoManifest ? (
                <div className="space-y-4 rounded-2xl border border-[var(--stroke)] bg-[var(--surface-2)] p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h3 className="text-xl font-semibold">
                        {selectedRepoManifest.full_name}
                      </h3>
                      <p className="text-sm text-[var(--muted)]">
                        {selectedRepoManifest.description ||
                          "No description yet"}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Badge
                        tone={
                          selectedRepoManifest.confidence_score >= 0.7
                            ? "good"
                            : selectedRepoManifest.confidence_score >= 0.5
                              ? "warn"
                              : "neutral"
                        }
                      >
                        confidence{" "}
                        {Math.round(
                          selectedRepoManifest.confidence_score * 100,
                        )}
                        %
                      </Badge>
                      <Badge
                        tone={
                          selectedRepoManifest.documentation
                            ?.readme_generation_state
                            ? "good"
                            : "neutral"
                        }
                      >
                        {selectedRepoManifest.documentation
                          ?.readme_generation_state || "docs idle"}
                      </Badge>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                    <InfoCard
                      label="Category"
                      value={selectedRepoManifest.project_category || "unknown"}
                    />
                    <InfoCard
                      label="Architecture"
                      value={
                        selectedRepoManifest.architecture_style || "unknown"
                      }
                    />
                    <InfoCard
                      label="Domain"
                      value={
                        selectedRepoManifest.engineering_domain || "unknown"
                      }
                    />
                    <InfoCard
                      label="Deployment"
                      value={selectedRepoManifest.deployment_model || "unknown"}
                    />
                    <InfoCard
                      label="Intent"
                      value={selectedRepoManifest.project_intent || "unknown"}
                    />
                    <InfoCard
                      label="Surface"
                      value={selectedRepoManifest.backend_frontend || "unknown"}
                    />
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <StackCard
                      title="Tech Stack"
                      items={[
                        ...selectedRepoManifest.detected_frameworks,
                        ...selectedRepoManifest.detected_tech,
                        ...selectedRepoManifest.infrastructure,
                        ...selectedRepoManifest.APIs,
                      ]}
                    />
                    <StackCard
                      title="Important Files"
                      items={selectedRepoManifest.important_files}
                    />
                  </div>
                </div>
              ) : null}
            </div>
          </Panel>
        </div>

        <aside className="grid content-start gap-6">
          <Panel
            title="Repo Actions"
            subtitle="preview, approve, reject, rollback"
          >
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2">
                <ActionButton
                  onClick={() => callRepoAction("regenerate_description")}
                >
                  Regenerate Description
                </ActionButton>
                <ActionButton
                  onClick={() => callRepoAction("regenerate_topics")}
                >
                  Regenerate Topics
                </ActionButton>
                <ActionButton
                  onClick={() =>
                    callRepoAction("generate_readme", selectedActionMode)
                  }
                >
                  Generate README
                </ActionButton>
                <ActionButton
                  onClick={() =>
                    callRepoAction("enhance_readme", selectedActionMode)
                  }
                >
                  Enhance README
                </ActionButton>
                <ActionButton onClick={() => callRepoAction("retry", "apply")}>
                  Retry Repo
                </ActionButton>
                <ActionButton
                  onClick={() => callRepoAction("rollback", "apply")}
                >
                  Rollback Changes
                </ActionButton>
                <ActionButton
                  onClick={() => callRepoAction("view_diff", "preview")}
                >
                  View Diff
                </ActionButton>
              </div>
              <div className="flex items-center gap-2 text-xs text-[var(--muted)]">
                <span className="uppercase tracking-[0.18em]">write mode</span>
                <Toggle
                  value={selectedActionMode === "apply"}
                  onChange={(value) =>
                    setSelectedActionMode(value ? "apply" : "preview")
                  }
                  labels={["preview", "apply"]}
                />
              </div>
              {repoAction ? (
                <RepoActionPreview data={repoAction} />
              ) : (
                <EmptyState label="Run a repo action to inspect README diff and approval controls" />
              )}
            </div>
          </Panel>

          <Panel
            title="README Diff Viewer"
            subtitle="current vs generated markdown with safe write preview"
          >
            {repoAction ? (
              <div className="space-y-4">
                <div className="grid gap-3 md:grid-cols-2">
                  <TextBox
                    title="Current README"
                    value={
                      repoAction.response.preview.current ||
                      selectedRepoManifest?.readme_content ||
                      ""
                    }
                  />
                  <TextBox
                    title="Generated README"
                    value={repoAction.response.preview.generated || ""}
                  />
                </div>
                <TextBox
                  title="Diff"
                  value={repoAction.response.preview.diff || "No diff"}
                />
                <div className="grid gap-3 md:grid-cols-2">
                  <InfoCard
                    label="Quality score"
                    value={`${Math.round((repoAction.response.preview.quality_score || 0) * 100)}%`}
                  />
                  <InfoCard
                    label="Safe to write"
                    value={
                      repoAction.response.preview.safe_to_write ? "yes" : "no"
                    }
                  />
                </div>
                <div className="flex flex-wrap gap-2">
                  <ActionButton
                    onClick={() => callRepoAction(repoAction.action, "apply")}
                  >
                    Approve Write
                  </ActionButton>
                  <ActionButton onClick={() => setRepoAction(null)}>
                    Reject
                  </ActionButton>
                </div>
              </div>
            ) : (
              <EmptyState label="Select a repo action to render the diff viewer" />
            )}
          </Panel>

          <Panel
            title="OpenRouter Health"
            subtitle="keys, models, failovers, cooldowns"
          >
            <div className="space-y-4">
              <HealthList
                title="Keys"
                items={status.openrouter.keys.map(
                  (key) =>
                    `${key.masked || key.id} • ${Math.round(key.success_rate * 100)}% • ${key.cooldown_seconds}s`,
                )}
              />
              <HealthList
                title="Models"
                items={status.openrouter.models.map(
                  (model) =>
                    `${model.model} • ${Math.round(model.success_rate * 100)}% • ${model.cooldown_seconds}s`,
                )}
              />
            </div>
          </Panel>
        </aside>
      </section>
    </main>
  );
}

function Panel({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-[var(--stroke)] bg-[var(--surface)] p-5 shadow-[0_24px_70px_rgba(0,0,0,0.22)]">
      <div>
        <h2 className="text-lg font-semibold">{title}</h2>
        {subtitle ? (
          <p className="text-xs text-[var(--muted)]">{subtitle}</p>
        ) : null}
      </div>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="space-y-1 rounded-xl border border-[var(--stroke)] bg-[var(--surface-2)] p-3">
      <div className="text-[10px] uppercase tracking-[0.22em] text-[var(--muted)]">
        {label}
      </div>
      <div className="truncate text-sm font-semibold">{value}</div>
    </div>
  );
}

function MetricCard({
  label,
  value,
}: {
  label: string;
  value: number | string;
}) {
  return (
    <div className="rounded-xl border border-[var(--stroke)] bg-[var(--surface-2)] p-4">
      <div className="text-[10px] uppercase tracking-[0.22em] text-[var(--muted)]">
        {label}
      </div>
      <div className="mt-1 text-lg font-semibold">{value}</div>
    </div>
  );
}

function InfoCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-[var(--stroke)] bg-[var(--surface)] p-4">
      <div className="text-[10px] uppercase tracking-[0.22em] text-[var(--muted)]">
        {label}
      </div>
      <div className="mt-2 text-sm font-semibold leading-6">{value}</div>
    </div>
  );
}

function StackCard({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="rounded-xl border border-[var(--stroke)] bg-[var(--surface)] p-4">
      <div className="text-xs uppercase tracking-[0.22em] text-[var(--muted)]">
        {title}
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {items.length === 0 ? (
          <span className="text-sm text-[var(--muted)]">none</span>
        ) : (
          items.map((item) => <Pill key={item}>{item}</Pill>)
        )}
      </div>
    </div>
  );
}

function TextBox({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-xl border border-[var(--stroke)] bg-[var(--surface-2)] p-4">
      <div className="text-xs uppercase tracking-[0.22em] text-[var(--muted)]">
        {title}
      </div>
      <pre className="mt-3 max-h-80 overflow-auto whitespace-pre-wrap break-words text-xs leading-5 text-[var(--text)]">
        {value || ""}
      </pre>
    </div>
  );
}

function TimelineRow({ event }: { event: StreamEvent }) {
  const timestamp = new Date(event.timestamp);
  return (
    <article className="rounded-xl border border-[var(--stroke)] bg-[var(--surface-2)] p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-semibold">{event.event}</span>
          {event.stage ? <Pill>{event.stage}</Pill> : null}
          {event.status ? <Pill>{event.status}</Pill> : null}
          {event.repo ? <Pill>{event.repo}</Pill> : null}
        </div>
        <span className="text-xs text-[var(--muted)]">
          {Number.isNaN(timestamp.valueOf())
            ? event.timestamp
            : timestamp.toLocaleTimeString()}
        </span>
      </div>
      <div className="mt-2 text-xs text-[var(--muted)]">
        {event.worker_id !== undefined ? (
          <span>worker {event.worker_id}</span>
        ) : null}
        {event.attempt !== undefined ? (
          <span className="ml-3">attempt {event.attempt}</span>
        ) : null}
        {event.message ? <span className="ml-3">{event.message}</span> : null}
      </div>
      {event.error ? (
        <div className="mt-2 rounded-lg border border-rose-500/20 bg-rose-500/10 p-3 text-xs text-rose-100">
          {event.error}
        </div>
      ) : null}
    </article>
  );
}

function RepoActionPreview({ data }: { data: ActiveRepoAction }) {
  return (
    <div className="rounded-xl border border-[var(--stroke)] bg-[var(--surface-2)] p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="text-xs uppercase tracking-[0.22em] text-[var(--muted)]">
            {data.action}
          </div>
          <div className="mt-1 font-semibold">{data.response.repo}</div>
        </div>
        <Badge tone={data.response.preview.safe_to_write ? "good" : "warn"}>
          {data.response.preview.safe_to_write ? "safe" : "review"}
        </Badge>
      </div>
      <div className="mt-3 text-xs text-[var(--muted)]">
        {data.response.generated_readme
          ? "generated README ready"
          : "preview generated"}
      </div>
      <div className="mt-3 text-sm">
        {data.response.preview.section_changes.length > 0
          ? data.response.preview.section_changes.join(", ")
          : "no section changes detected"}
      </div>
    </div>
  );
}

function HealthList({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="rounded-xl border border-[var(--stroke)] bg-[var(--surface-2)] p-4">
      <div className="text-xs uppercase tracking-[0.22em] text-[var(--muted)]">
        {title}
      </div>
      <div className="mt-3 space-y-2">
        {items.length === 0 ? (
          <EmptyState label={`No ${title.toLowerCase()} available`} />
        ) : (
          items.map((item) => (
            <div
              key={item}
              className="rounded-lg border border-[var(--stroke)] px-3 py-2 text-xs text-[var(--muted)]"
            >
              {item}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function Toggle({
  value,
  onChange,
  labels,
}: {
  value: boolean;
  onChange: (value: boolean) => void;
  labels: [string, string];
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!value)}
      className="rounded-full border border-[var(--stroke)] bg-[var(--surface-2)] px-2 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--text)]"
    >
      {value ? labels[1] : labels[0]}
    </button>
  );
}

function Badge({
  tone,
  children,
}: {
  tone: "good" | "warn" | "neutral";
  children: ReactNode;
}) {
  const styles = {
    good: "bg-emerald-500/20 text-emerald-100",
    warn: "bg-amber-500/20 text-amber-100",
    neutral: "bg-slate-500/20 text-slate-100",
  } as const;
  return (
    <span
      className={`rounded-full px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] ${styles[tone]}`}
    >
      {children}
    </span>
  );
}

function Pill({ children }: { children: string }) {
  return (
    <span className="rounded-full border border-[var(--stroke)] px-2 py-1 text-[10px] text-[var(--muted)]">
      {children}
    </span>
  );
}

function ActionButton({
  children,
  onClick,
}: {
  children: ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="rounded-full border border-[var(--stroke)] bg-[var(--surface-2)] px-4 py-2 text-xs font-semibold text-[var(--text)] transition hover:border-[var(--accent)]"
    >
      {children}
    </button>
  );
}

function EmptyState({ label }: { label: string }) {
  return (
    <div className="rounded-xl border border-dashed border-[var(--stroke)] px-4 py-8 text-center text-sm text-[var(--muted)]">
      {label}
    </div>
  );
}

function parseEvent(raw: string, lastEventId: string): StreamEvent | null {
  try {
    const record = JSON.parse(raw) as Record<string, unknown>;
    const details = asRecord(record.details);
    return {
      schema_version: numberField(record.schema_version),
      id: numberField(record.id) || numberField(lastEventId),
      event: stringField(record.event) || stringField(record.type) || "event",
      timestamp: stringField(record.timestamp) || new Date().toISOString(),
      worker_id: optionalNumber(record.worker_id),
      repo: optionalString(record.repo),
      stage: optionalString(record.stage),
      status: optionalString(record.status),
      attempt: optionalNumber(record.attempt),
      message: optionalString(record.message),
      error: optionalString(record.error),
      details,
    };
  } catch {
    return null;
  }
}

function stageName(status: PipelineStatusResponse): string {
  const entries = Object.entries(status.snapshot.stages);
  return (
    entries.find(([, value]) => value.active > 0)?.[0] ||
    status.job.mode ||
    "idle"
  );
}

function shortRepo(value: string): string {
  if (!value) {
    return "-";
  }
  return value.length > 28 ? `${value.slice(0, 28)}…` : value;
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object"
    ? (value as Record<string, unknown>)
    : {};
}

function stringField(value: unknown): string {
  return typeof value === "string" ? value : "";
}

function optionalString(value: unknown): string | undefined {
  const result = stringField(value);
  return result || undefined;
}

function numberField(value: unknown): number {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }
  if (typeof value === "string") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }
  return 0;
}

function optionalNumber(value: unknown): number | undefined {
  const result = numberField(value);
  return result === 0 ? undefined : result;
}
