export default function Loading() {
  return (
    <main className="flex min-h-screen items-center justify-center px-6 text-[var(--text)]">
      <div className="rounded-lg border border-[var(--stroke)] bg-[var(--surface)] px-5 py-4 text-sm text-[var(--muted)]">
        Loading control room
      </div>
    </main>
  );
}
