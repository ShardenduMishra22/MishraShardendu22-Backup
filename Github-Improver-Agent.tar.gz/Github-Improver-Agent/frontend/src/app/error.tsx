"use client";

export default function DashboardError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="flex min-h-screen items-center justify-center px-6 text-[var(--text)]">
      <section className="max-w-md rounded-lg border border-rose-500/30 bg-[var(--surface)] p-5">
        <h1 className="text-lg font-semibold">Dashboard error</h1>
        <p className="mt-2 text-sm text-[var(--muted)]">
          {error.message || "The dashboard could not render safely."}
        </p>
        <button
          type="button"
          onClick={reset}
          className="mt-4 rounded-lg bg-[var(--accent)] px-4 py-2 text-sm font-semibold text-slate-950"
        >
          Retry
        </button>
      </section>
    </main>
  );
}
