package config

import "testing"

func TestResolveConfidenceThresholdModes(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		mode      string
		threshold float64
		want      float64
	}{
		{name: "default threshold", mode: "", threshold: 0, want: 0.45},
		{name: "balanced mode", mode: "balanced", threshold: 0.9, want: 0.45},
		{name: "permissive mode", mode: "permissive", threshold: 0.9, want: 0.35},
		{name: "strict mode", mode: "strict", threshold: 0.35, want: 0.65},
		{name: "explicit threshold", mode: "", threshold: 0.52, want: 0.52},
	}

	for _, tc := range tests {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			got, err := resolveConfidenceThreshold(tc.mode, tc.threshold)
			if err != nil {
				t.Fatalf("resolveConfidenceThreshold returned error: %v", err)
			}
			if got != tc.want {
				t.Fatalf("resolveConfidenceThreshold(%q, %v) = %v, want %v", tc.mode, tc.threshold, got, tc.want)
			}
		})
	}
}

func TestResolveConfidenceThresholdRejectsInvalidMode(t *testing.T) {
	t.Parallel()

	if _, err := resolveConfidenceThreshold("unknown", 0.45); err == nil {
		t.Fatal("resolveConfidenceThreshold returned nil error for invalid mode")
	}
}
