package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/joho/godotenv"
	"github.com/spf13/viper"
)

const defaultModel = "openai/gpt-oss-120b:free"
const defaultConfidenceThreshold = 0.45
const defaultCacheFile = ".metadata-cache.json"
const defaultManifestFile = "repos-manifest.json"

var confidenceModeThresholds = map[string]float64{
	"permissive": 0.35,
	"balanced":   0.45,
	"strict":     0.65,
}

type Config struct {
	DryRun                      bool
	GenerateManifest            bool
	PreviewOnly                 bool
	Verbose                     bool
	Limit                       int
	Workers                     int
	LLMWorkers                  int
	GitHubWorkers               int
	RetryAttempts               int
	GitHubRequestsPerSecond     float64
	OpenRouterRequestsPerSecond float64
	OpenRouterMaxConcurrency    int
	OpenRouterMaxQueue          int
	OpenRouterCooldownShort     time.Duration
	OpenRouterCooldownMedium    time.Duration
	OpenRouterCooldownLong      time.Duration
	OpenRouterMaxConsecutive    int
	OpenRouterStateFile         string
	OpenRouterPersistInterval   time.Duration
	ConfidenceThreshold         float64
	ConfidenceMode              string
	GitHubToken                 string
	OpenRouterAPIKey            string
	OpenRouterAPIKeys           []string
	OpenRouterModels            []string
	Model                       string
	ManifestFile                string
	ApplyManifest               string
	RepoFilter                  string
	OnlyLanguage                string
	Allowlist                   []string
	Blocklist                   []string
	ExcludeTopics               []string
	LockedRepos                 []string
	CacheFile                   string
	RepoTimeout                 time.Duration
	ServerAddr                  string
	ServerAllowOrigin           string
}

func ConfigureViper() error {
	viper.SetEnvPrefix("")
	viper.AutomaticEnv()
	viper.SetEnvKeyReplacer(strings.NewReplacer("-", "_"))

	setDefault := func(key string, value any) {
		viper.SetDefault(key, value)
	}

	setDefault("model", defaultModel)
	setDefault("dry-run", false)
	setDefault("generate-manifest", false)
	setDefault("manifest-file", defaultManifestFile)
	setDefault("apply-manifest", "")
	setDefault("preview-only", false)
	setDefault("repo", "")
	setDefault("only-language", "")
	setDefault("limit", 0)
	setDefault("verbose", false)
	setDefault("workers", 5)
	setDefault("llm-workers", 3)
	setDefault("github-workers", 2)
	setDefault("allowlist", "")
	setDefault("blocklist", "")
	setDefault("exclude-topic", "")
	setDefault("github-rps", 1.0)
	setDefault("openrouter-rps", 1.0)
	setDefault("openrouter-max-concurrency", 0)
	setDefault("openrouter-max-queue", 200)
	setDefault("openrouter-cooldown-short", "30s")
	setDefault("openrouter-cooldown-medium", "2m")
	setDefault("openrouter-cooldown-long", "10m")
	setDefault("openrouter-max-consecutive-fails", 2)
	setDefault("openrouter-state-file", ".openrouter-state.json")
	setDefault("openrouter-persist-interval", "15s")
	setDefault("openrouter-api-keys", "")
	setDefault("openrouter-models", "")
	setDefault("retries", 3)
	setDefault("repo-timeout", "3m")
	setDefault("confidence-mode", "")
	setDefault("confidence-threshold", defaultConfidenceThreshold)
	setDefault("min-confidence", 0.0)
	setDefault("cache-file", defaultCacheFile)
	setDefault("locked-repos", "")
	setDefault("metadata-config-file", "")
	setDefault("server-addr", ":8080")
	setDefault("server-allow-origin", "*")

	return nil
}

func Load() (Config, error) {
	if err := loadDotEnv(); err != nil {
		return Config{}, err
	}

	githubToken, err := stringFromEnvOrFile("github-token")
	if err != nil {
		return Config{}, err
	}
	openRouterAPIKey, err := stringFromEnvOrFile("openrouter-api-key")
	if err != nil {
		return Config{}, err
	}
	openRouterAPIKeys, err := listFromEnvOrFile("openrouter-api-keys")
	if err != nil {
		return Config{}, err
	}

	cfg := Config{
		GitHubToken:                 githubToken,
		OpenRouterAPIKey:            openRouterAPIKey,
		OpenRouterAPIKeys:           openRouterAPIKeys,
		OpenRouterModels:            parseList(viper.GetString("openrouter-models")),
		Model:                       strings.TrimSpace(viper.GetString("model")),
		ManifestFile:                strings.TrimSpace(viper.GetString("manifest-file")),
		ApplyManifest:               strings.TrimSpace(viper.GetString("apply-manifest")),
		DryRun:                      viper.GetBool("dry-run"),
		GenerateManifest:            viper.GetBool("generate-manifest"),
		PreviewOnly:                 viper.GetBool("preview-only"),
		RepoFilter:                  strings.TrimSpace(viper.GetString("repo")),
		OnlyLanguage:                strings.TrimSpace(viper.GetString("only-language")),
		Limit:                       viper.GetInt("limit"),
		Verbose:                     viper.GetBool("verbose"),
		Workers:                     viper.GetInt("workers"),
		LLMWorkers:                  viper.GetInt("llm-workers"),
		GitHubWorkers:               viper.GetInt("github-workers"),
		Allowlist:                   parseList(viper.GetString("allowlist")),
		Blocklist:                   parseList(viper.GetString("blocklist")),
		ExcludeTopics:               mergeUniqueStrings(nil, parseList(viper.GetString("exclude-topic"))),
		LockedRepos:                 parseList(viper.GetString("locked-repos")),
		CacheFile:                   strings.TrimSpace(viper.GetString("cache-file")),
		ConfidenceMode:              normalizeConfidenceMode(viper.GetString("confidence-mode")),
		GitHubRequestsPerSecond:     viper.GetFloat64("github-rps"),
		OpenRouterRequestsPerSecond: viper.GetFloat64("openrouter-rps"),
		OpenRouterMaxConcurrency:    viper.GetInt("openrouter-max-concurrency"),
		OpenRouterMaxQueue:          viper.GetInt("openrouter-max-queue"),
		OpenRouterCooldownShort:     viper.GetDuration("openrouter-cooldown-short"),
		OpenRouterCooldownMedium:    viper.GetDuration("openrouter-cooldown-medium"),
		OpenRouterCooldownLong:      viper.GetDuration("openrouter-cooldown-long"),
		OpenRouterMaxConsecutive:    viper.GetInt("openrouter-max-consecutive-fails"),
		OpenRouterStateFile:         strings.TrimSpace(viper.GetString("openrouter-state-file")),
		OpenRouterPersistInterval:   viper.GetDuration("openrouter-persist-interval"),
		RetryAttempts:               viper.GetInt("retries"),
		ConfidenceThreshold:         viper.GetFloat64("confidence-threshold"),
		RepoTimeout:                 viper.GetDuration("repo-timeout"),
		ServerAddr:                  strings.TrimSpace(viper.GetString("server-addr")),
		ServerAllowOrigin:           strings.TrimSpace(viper.GetString("server-allow-origin")),
	}

	if minConfidence := viper.GetFloat64("min-confidence"); minConfidence > 0 {
		cfg.ConfidenceThreshold = minConfidence
	}

	if cfg.Model == "" {
		cfg.Model = defaultModel
	}
	if len(cfg.OpenRouterModels) == 0 && cfg.Model != "" {
		cfg.OpenRouterModels = []string{cfg.Model}
	}
	if len(cfg.OpenRouterAPIKeys) == 0 && cfg.OpenRouterAPIKey != "" {
		cfg.OpenRouterAPIKeys = []string{cfg.OpenRouterAPIKey}
	}
	if cfg.Workers <= 0 {
		cfg.Workers = 5
	}
	if cfg.LLMWorkers <= 0 {
		cfg.LLMWorkers = 3
	}
	if cfg.GitHubWorkers <= 0 {
		cfg.GitHubWorkers = 2
	}
	if cfg.GitHubRequestsPerSecond <= 0 {
		cfg.GitHubRequestsPerSecond = 1.0
	}
	if cfg.OpenRouterRequestsPerSecond <= 0 {
		cfg.OpenRouterRequestsPerSecond = 1.0
	}
	if cfg.OpenRouterMaxConcurrency <= 0 {
		cfg.OpenRouterMaxConcurrency = cfg.LLMWorkers
	}
	if cfg.OpenRouterMaxQueue < 0 {
		cfg.OpenRouterMaxQueue = 0
	}
	if cfg.OpenRouterCooldownShort <= 0 {
		cfg.OpenRouterCooldownShort = 30 * time.Second
	}
	if cfg.OpenRouterCooldownMedium <= 0 {
		cfg.OpenRouterCooldownMedium = 2 * time.Minute
	}
	if cfg.OpenRouterCooldownLong <= 0 {
		cfg.OpenRouterCooldownLong = 10 * time.Minute
	}
	if cfg.OpenRouterMaxConsecutive <= 0 {
		cfg.OpenRouterMaxConsecutive = 2
	}
	if cfg.OpenRouterPersistInterval <= 0 {
		cfg.OpenRouterPersistInterval = 15 * time.Second
	}
	if cfg.OpenRouterStateFile == "off" || cfg.OpenRouterStateFile == "disabled" {
		cfg.OpenRouterStateFile = ""
	}
	if cfg.RetryAttempts <= 0 {
		cfg.RetryAttempts = 3
	}
	if cfg.RepoTimeout <= 0 {
		cfg.RepoTimeout = 3 * time.Minute
	}
	if cfg.CacheFile == "" {
		cfg.CacheFile = defaultCacheFile
	}
	if cfg.ManifestFile == "" {
		cfg.ManifestFile = defaultManifestFile
	}
	if cfg.ServerAddr == "" {
		cfg.ServerAddr = ":8080"
	}

	if err := mergeLocalConfig(&cfg); err != nil {
		return Config{}, err
	}

	resolvedThreshold, err := resolveConfidenceThreshold(cfg.ConfidenceMode, cfg.ConfidenceThreshold)
	if err != nil {
		return Config{}, err
	}
	cfg.ConfidenceThreshold = resolvedThreshold

	if err := cfg.Validate(); err != nil {
		return Config{}, err
	}

	return cfg, nil
}

func (c Config) Validate() error {
	if c.Limit < 0 {
		return fmt.Errorf("limit must be zero or greater")
	}
	if c.Workers < 1 {
		return fmt.Errorf("workers must be at least 1")
	}
	if c.LLMWorkers < 1 {
		return fmt.Errorf("llm workers must be at least 1")
	}
	if c.GitHubWorkers < 1 {
		return fmt.Errorf("github workers must be at least 1")
	}
	if c.ConfidenceThreshold <= 0 || c.ConfidenceThreshold > 1 {
		return fmt.Errorf("confidence threshold must be between 0 and 1")
	}
	if c.RepoTimeout <= 0 {
		return fmt.Errorf("repo timeout must be greater than zero")
	}
	if c.OpenRouterMaxQueue < 0 {
		return fmt.Errorf("openrouter max queue must be zero or greater")
	}
	return nil
}

func stringFromEnvOrFile(key string) (string, error) {
	value := strings.TrimSpace(viper.GetString(key))
	if value != "" {
		return value, nil
	}
	path := strings.TrimSpace(viper.GetString(key + "-file"))
	if path == "" {
		return "", nil
	}
	content, err := os.ReadFile(filepath.Clean(path))
	if err != nil {
		return "", fmt.Errorf("read %s: %w", key+"-file", err)
	}
	return strings.TrimSpace(string(content)), nil
}

func listFromEnvOrFile(key string) ([]string, error) {
	value := strings.TrimSpace(viper.GetString(key))
	if value != "" {
		return parseList(value), nil
	}
	path := strings.TrimSpace(viper.GetString(key + "-file"))
	if path == "" {
		return nil, nil
	}
	content, err := os.ReadFile(filepath.Clean(path))
	if err != nil {
		return nil, fmt.Errorf("read %s: %w", key+"-file", err)
	}
	return parseList(strings.ReplaceAll(string(content), "\n", ",")), nil
}

type localConfig struct {
	LockedRepos         []string `json:"locked_repos"`
	CacheFile           string   `json:"cache_file,omitempty"`
	ManifestFile        string   `json:"manifest_file,omitempty"`
	ConfidenceMode      *string  `json:"confidence_mode,omitempty"`
	ConfidenceThreshold *float64 `json:"confidence_threshold,omitempty"`
}

func mergeLocalConfig(cfg *Config) error {
	configPath, err := findLocalConfigPath()
	if err != nil {
		return err
	}
	if configPath == "" {
		return nil
	}

	content, err := os.ReadFile(configPath)
	if err != nil {
		return err
	}

	var local localConfig
	if err := json.Unmarshal(content, &local); err != nil {
		return fmt.Errorf("parse local config %s: %w", configPath, err)
	}

	cfg.LockedRepos = mergeUniqueStrings(cfg.LockedRepos, local.LockedRepos)
	if strings.TrimSpace(local.CacheFile) != "" && strings.TrimSpace(cfg.CacheFile) == defaultCacheFile {
		cfg.CacheFile = strings.TrimSpace(local.CacheFile)
	}
	if strings.TrimSpace(local.ManifestFile) != "" && strings.TrimSpace(cfg.ManifestFile) == defaultManifestFile {
		cfg.ManifestFile = strings.TrimSpace(local.ManifestFile)
	}
	if local.ConfidenceMode != nil && cfg.ConfidenceMode == "" {
		cfg.ConfidenceMode = normalizeConfidenceMode(*local.ConfidenceMode)
	}
	if local.ConfidenceThreshold != nil && cfg.ConfidenceThreshold == defaultConfidenceThreshold {
		cfg.ConfidenceThreshold = *local.ConfidenceThreshold
	}
	return nil
}

func findLocalConfigPath() (string, error) {
	candidates := []string{"metadata-agent.json", ".metadata-agent.json"}
	for _, candidate := range candidates {
		info, err := os.Stat(candidate)
		if err == nil && !info.IsDir() {
			return filepath.Clean(candidate), nil
		}
		if err != nil && !os.IsNotExist(err) {
			return "", err
		}
	}
	return "", nil
}

func mergeUniqueStrings(existing, incoming []string) []string {
	seen := make(map[string]struct{}, len(existing)+len(incoming))
	merged := make([]string, 0, len(existing)+len(incoming))
	add := func(values []string) {
		for _, value := range values {
			candidate := strings.TrimSpace(value)
			if candidate == "" {
				continue
			}
			key := strings.ToLower(candidate)
			if _, ok := seen[key]; ok {
				continue
			}
			seen[key] = struct{}{}
			merged = append(merged, candidate)
		}
	}
	add(existing)
	add(incoming)
	return merged
}

func loadDotEnv() error {
	if err := godotenv.Load(); err != nil && !os.IsNotExist(err) {
		return err
	}
	return nil
}

func parseList(raw string) []string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}

	parts := strings.Split(raw, ",")
	values := make([]string, 0, len(parts))
	for _, part := range parts {
		item := strings.TrimSpace(part)
		if item == "" {
			continue
		}
		values = append(values, item)
	}
	return values
}

func normalizeConfidenceMode(value string) string {
	return strings.ToLower(strings.TrimSpace(value))
}

func resolveConfidenceThreshold(mode string, threshold float64) (float64, error) {
	mode = normalizeConfidenceMode(mode)
	if mode == "" {
		if threshold <= 0 {
			return defaultConfidenceThreshold, nil
		}
		return threshold, nil
	}

	resolved, ok := confidenceModeThresholds[mode]
	if !ok {
		return 0, fmt.Errorf("invalid confidence mode %q: expected permissive, balanced, or strict", mode)
	}
	return resolved, nil
}
