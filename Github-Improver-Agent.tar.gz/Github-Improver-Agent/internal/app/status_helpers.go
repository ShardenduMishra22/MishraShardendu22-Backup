package app

import (
	"fmt"

	"go-description-script/internal/model"
	"go-description-script/internal/observability"
	"go-description-script/internal/openrouter"
)

func totalQueueDepth(queues map[string]int) int {
	total := 0
	for _, depth := range queues {
		total += depth
	}
	return total
}

func totalActiveWorkers(stages map[string]observability.StageSnapshot) int64 {
	var total int64
	for _, stage := range stages {
		total += stage.Active
	}
	return total
}

func countCompletedRepos(repos []model.RepoManifest) int {
	count := 0
	for _, repo := range repos {
		if repo.UpdateStatus.Completed() || repo.Documentation.GeneratedReadme != "" {
			count++
		}
	}
	return count
}

func countFailedRepos(repos []model.RepoManifest) int {
	count := 0
	for _, repo := range repos {
		if len(repo.Failures) > 0 {
			count++
		}
	}
	return count
}

func countProcessingRepos(stages map[string]observability.StageSnapshot) int64 {
	var total int64
	for _, stage := range stages {
		total += stage.Active
	}
	return total
}

func countRetries(repos []model.RepoManifest) int {
	total := 0
	for _, repo := range repos {
		total += repo.Retries.Total
	}
	return total
}

func deriveCurrentExecution(events []observability.Event) (string, string, int) {
	currentStage := ""
	currentRepo := ""
	currentWorker := 0
	for index := len(events) - 1; index >= 0; index-- {
		event := events[index]
		if currentStage == "" && event.Stage != "" {
			currentStage = event.Stage
		}
		if currentRepo == "" && event.Repo != "" {
			currentRepo = event.Repo
		}
		if event.WorkerID != nil {
			currentWorker = *event.WorkerID
		}
		if currentStage != "" && currentRepo != "" {
			break
		}
	}
	return currentStage, currentRepo, currentWorker
}

func cooldownSummary(metrics openrouter.Metrics) []map[string]any {
	out := make([]map[string]any, 0, len(metrics.Keys)+len(metrics.Models))
	for _, key := range metrics.Keys {
		out = append(out, map[string]any{"type": "key", "id": key.ID, "cooldown_seconds": key.CooldownSeconds, "healthy": key.Healthy, "disabled": key.Disabled})
	}
	for _, model := range metrics.Models {
		out = append(out, map[string]any{"type": "model", "id": model.Model, "cooldown_seconds": model.CooldownSeconds, "healthy": model.Healthy, "disabled": model.Disabled})
	}
	return out
}

func repoActionError(action, repo string) error {
	return fmt.Errorf("unsupported repo action %q for %s", action, repo)
}
