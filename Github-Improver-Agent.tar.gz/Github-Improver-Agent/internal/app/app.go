package app

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/signal"
	"sort"
	"strings"
	"syscall"

	"go-description-script/internal/analysis"
	"go-description-script/internal/config"
	"go-description-script/internal/githubsvc"
	"go-description-script/internal/model"
	"go-description-script/internal/observability"
	"go-description-script/internal/openrouter"

	"github.com/google/go-github/v86/github"
	"github.com/rs/zerolog"
	"golang.org/x/time/rate"
)

type App struct {
	cfg      config.Config
	logger   zerolog.Logger
	github   *githubsvc.Client
	llm      *openrouter.Client
	analyzer *analysis.Analyzer
	cache    *metadataCache
	events   *observability.Hub
	state    *observability.State
	pipeline *pipelineManager
}

func New(cfg config.Config, logger zerolog.Logger) (*App, error) {
	githubLimiter := rate.NewLimiter(rate.Limit(cfg.GitHubRequestsPerSecond), 1)
	cache, err := loadMetadataCache(cfg.CacheFile)
	if err != nil {
		return nil, err
	}

	var llm *openrouter.Client
	if strings.TrimSpace(cfg.ApplyManifest) == "" {
		llmLimiter := rate.NewLimiter(rate.Limit(cfg.OpenRouterRequestsPerSecond), 1)
		if len(cfg.OpenRouterAPIKeys) > 0 || len(cfg.OpenRouterModels) > 0 {
			llm = openrouter.NewMulti(cfg.OpenRouterAPIKeys, cfg.OpenRouterModels, llmLimiter, cfg.RetryAttempts, logger.With().Str("component", "openrouter").Logger())
		} else {
			llm = openrouter.New(cfg.OpenRouterAPIKey, cfg.Model, llmLimiter, cfg.RetryAttempts, logger.With().Str("component", "openrouter").Logger())
		}
		if llm != nil {
			llm.SetConcurrency(cfg.OpenRouterMaxConcurrency)
			if cfg.OpenRouterMaxQueue > 0 {
				llm.SetQueueLimit(cfg.OpenRouterMaxQueue)
			}
			llm.SetCooldowns(cfg.OpenRouterCooldownShort, cfg.OpenRouterCooldownMedium, cfg.OpenRouterCooldownLong)
			llm.SetMaxConsecutiveFails(cfg.OpenRouterMaxConsecutive)
			if cfg.OpenRouterStateFile != "" {
				llm.SetStateStore(openrouter.NewStateStore(cfg.OpenRouterStateFile))
				_ = llm.LoadState()
			}
		}
	}

	app := &App{
		cfg:      cfg,
		logger:   logger,
		github:   githubsvc.New(cfg.GitHubToken, githubLimiter, cfg.RetryAttempts, logger.With().Str("component", "github").Logger()),
		llm:      llm,
		analyzer: analysis.New(),
		cache:    cache,
	}
	app.pipeline = newPipelineManager(app)
	return app, nil
}

func (a *App) Run(ctx context.Context) error {
	ctx, stop := signal.NotifyContext(ctx, os.Interrupt, syscall.SIGTERM)
	defer stop()
	if a.llm != nil {
		a.llm.StartPersistence(ctx, a.cfg.OpenRouterPersistInterval)
	}
	return a.runPipeline(ctx)
}

func (a *App) SetObservability(state *observability.State, events *observability.Hub) {
	a.state = state
	a.events = events
	if a.llm != nil {
		a.llm.SetEventHub(events)
	}
}

func (a *App) OpenRouterKeyHealth() []openrouter.KeyHealth {
	if a.llm == nil {
		return []openrouter.KeyHealth{}
	}
	return a.llm.KeyHealth()
}

func (a *App) OpenRouterModelHealth() []openrouter.ModelHealth {
	if a.llm == nil {
		return []openrouter.ModelHealth{}
	}
	return a.llm.ModelHealth()
}

func (a *App) ReloadOpenRouterKeys(keys []string, weights []int) int {
	if a.llm == nil {
		return 0
	}
	return a.llm.ReloadKeys(keys, weights)
}

func (a *App) ReloadOpenRouterModels(models []string, weights []int) int {
	if a.llm == nil {
		return 0
	}
	return a.llm.ReloadModels(models, weights)
}

func (a *App) OpenRouterMetrics() openrouter.Metrics {
	if a.llm == nil {
		return openrouter.Metrics{
			Keys:   []openrouter.KeyHealth{},
			Models: []openrouter.ModelHealth{},
		}
	}
	return a.llm.Metrics()
}

func (a *App) OpenRouterReloadFromConfig() {
	if a.llm == nil {
		return
	}
	a.llm.ReloadKeys(a.cfg.OpenRouterAPIKeys, nil)
	a.llm.ReloadModels(a.cfg.OpenRouterModels, nil)
}

func (a *App) DisableOpenRouterKey(id string) bool {
	if a.llm == nil {
		return false
	}
	return a.llm.DisableKey(id)
}

func (a *App) EnableOpenRouterKey(id string) bool {
	if a.llm == nil {
		return false
	}
	return a.llm.EnableKey(id)
}

func (a *App) ResetOpenRouterKeyCooldown(id string) bool {
	if a.llm == nil {
		return false
	}
	return a.llm.ResetKeyCooldown(id)
}

func (a *App) DisableOpenRouterModel(name string) bool {
	if a.llm == nil {
		return false
	}
	return a.llm.DisableModel(name)
}

func (a *App) EnableOpenRouterModel(name string) bool {
	if a.llm == nil {
		return false
	}
	return a.llm.EnableModel(name)
}

func (a *App) ResetOpenRouterModelCooldown(name string) bool {
	if a.llm == nil {
		return false
	}
	return a.llm.ResetModelCooldown(name)
}

func (a *App) Events() *observability.Hub {
	return a.events
}

func (a *App) State() *observability.State {
	return a.state
}

func (a *App) manifestRepositories() []model.RepoManifest {
	manifestPath := strings.TrimSpace(a.cfg.ManifestFile)
	if manifestPath == "" {
		return nil
	}
	manifest, err := loadManifestFile(manifestPath)
	if err != nil {
		return nil
	}
	return manifest.Repositories
}

func (a *App) PipelineStatus() map[string]any {
	job := pipelineJobState{}
	if a.pipeline != nil {
		job = a.pipeline.snapshot()
	}
	run, snapshot := observability.PipelineRun{}, observability.PipelineSnapshot{}
	if a.state != nil {
		run, snapshot = a.state.Snapshot()
	}
	metrics := a.OpenRouterMetrics()
	repos := a.manifestRepositories()
	if repos == nil {
		repos = []model.RepoManifest{}
	}
	events := []observability.Event{}
	if a.events != nil {
		events = a.events.Recent(100)
	}
	if events == nil {
		events = []observability.Event{}
	}
	currentStage, currentRepo, currentWorker := deriveCurrentExecution(events)
	cooldowns := cooldownSummary(metrics)
	if cooldowns == nil {
		cooldowns = []map[string]any{}
	}
	return map[string]any{
		"job":          job,
		"run":          run,
		"snapshot":     snapshot,
		"openrouter":   metrics,
		"repositories": repos,
		"summary": map[string]any{
			"current_stage":    currentStage,
			"current_repo":     currentRepo,
			"current_worker":   currentWorker,
			"queue_depth":      totalQueueDepth(snapshot.Queues),
			"active_workers":   totalActiveWorkers(snapshot.Stages),
			"repos_completed":  countCompletedRepos(repos),
			"repos_failed":     countFailedRepos(repos),
			"repos_processing": countProcessingRepos(snapshot.Stages),
			"retries":          countRetries(repos),
			"api_latency_ms":   metrics.AvgLatencyMs,
			"failovers":        metrics.Failovers,
			"cooldowns":        cooldowns,
			"model_usage":      metrics.Models,
			"key_usage":        metrics.Keys,
		},
		"events": events,
	}
}

func (a *App) StartBackgroundPipeline(opts PipelineRunOptions) error {
	if a.pipeline == nil {
		return errors.New("pipeline manager not initialized")
	}
	return a.pipeline.start(opts)
}

func (a *App) StopBackgroundPipeline() error {
	if a.pipeline == nil {
		return errors.New("pipeline manager not initialized")
	}
	return a.pipeline.stop()
}

func (a *App) PauseBackgroundPipeline() error {
	if a.pipeline == nil {
		return errors.New("pipeline manager not initialized")
	}
	return a.pipeline.pause()
}

func (a *App) ResumeBackgroundPipeline() error {
	if a.pipeline == nil {
		return errors.New("pipeline manager not initialized")
	}
	return a.pipeline.resume()
}

func (a *App) RetryFailedBackgroundPipeline(manifestPath string) error {
	if a.pipeline == nil {
		return errors.New("pipeline manager not initialized")
	}
	return a.pipeline.retryFailed(manifestPath)
}

func (a *App) waitForPipelineSlot(done <-chan struct{}) bool {
	if a.pipeline == nil {
		return true
	}
	return a.pipeline.waitIfPaused(done)
}

func (a *App) publishPipelineEvent(event string, workerID int, repo, stage, status, message string, details map[string]any) {
	if a.events == nil {
		return
	}
	payload := map[string]any{
		"worker_id": workerID,
		"repo":      repo,
		"stage":     stage,
		"status":    status,
		"message":   message,
	}
	for key, value := range details {
		payload[key] = value
	}
	a.events.Publish(observability.Event{Type: event, Payload: payload})
}

func (a *App) processRepository(parent context.Context, repo *github.Repository) model.RepoOutcome {
	fullName := repo.GetFullName()
	log := a.logger.With().Str("repo", fullName).Logger()
	if a.isLockedRepo(repo) {
		return model.RepoOutcome{FullName: fullName, Skipped: true, SkipReason: "repository is locked in local config"}
	}

	repoCtx, cancel := context.WithTimeout(parent, a.cfg.RepoTimeout)
	defer cancel()

	snapshot, err := a.github.ReadSnapshot(repoCtx, repo)
	if err != nil {
		return model.RepoOutcome{FullName: fullName, ErrorMessage: err.Error()}
	}

	repoAnalysis := a.analyzer.Analyze(repo, snapshot)
	prompt := analysis.BuildPrompt(repoAnalysis)

	suggestion, cacheHit, err := a.loadSuggestion(repoCtx, repoAnalysis, snapshot, prompt)
	if err != nil {
		return model.RepoOutcome{FullName: fullName, ErrorMessage: err.Error()}
	}

	validated, err := analysis.ValidateMetadata(repoAnalysis, snapshot, suggestion)
	if err != nil {
		fallback := analysis.FallbackSuggestion(repoAnalysis)
		validated, err = analysis.ValidateMetadata(repoAnalysis, snapshot, fallback)
		if err != nil {
			return model.RepoOutcome{FullName: fullName, ErrorMessage: fmt.Sprintf("metadata validation failed: %v", err)}
		}
	}

	baseOutcome := model.RepoOutcome{
		FullName:            fullName,
		Confidence:          validated.Confidence,
		ConfidenceThreshold: a.cfg.ConfidenceThreshold,
		ConfidenceEvaluated: true,
	}

	if validated.Confidence.MetadataConfidence < a.cfg.ConfidenceThreshold {
		if allowLowConfidenceUpdate(validated.Confidence) {
			log.Info().
				Float64("confidence", validated.Confidence.MetadataConfidence).
				Float64("threshold", a.cfg.ConfidenceThreshold).
				Float64("tech_score", validated.Confidence.TechnologyAccuracy).
				Msg("confidence override accepted")
		} else {
			baseOutcome.Skipped = true
			baseOutcome.SkipReason = confidenceSkipReason(snapshot, validated.Confidence)
			baseOutcome.Description = validated.Suggestion.Description
			baseOutcome.Topics = validated.Suggestion.Topics
			return baseOutcome
		}
	}

	if a.cache != nil {
		a.cache.Store(fullName, snapshot.ReadmeHash, snapshot.CommitSHA, validated.Suggestion, validated.Confidence.MetadataConfidence)
	}

	if !metadataChanged(repoAnalysis, snapshot, validated.Suggestion) {
		baseOutcome.Skipped = true
		baseOutcome.SkipReason = "metadata already matches generated output"
		baseOutcome.Description = validated.Suggestion.Description
		baseOutcome.Topics = validated.Suggestion.Topics
		return baseOutcome
	}

	if a.cfg.DryRun {
		preview := analysis.BuildMetadataPreview(validated)
		log.Info().
			Bool("cache_hit", cacheHit).
			Float64("confidence", validated.Confidence.MetadataConfidence).
			Float64("threshold", a.cfg.ConfidenceThreshold).
			Float64("readme_score", validated.Confidence.ReadmeQuality).
			Float64("file_score", validated.Confidence.FileCoverage).
			Float64("tech_score", validated.Confidence.TechnologyAccuracy).
			Float64("metadata_score", validated.Confidence.MetadataScore).
			Float64("final_score", validated.Confidence.MetadataConfidence).
			Strs("topics", validated.Suggestion.Topics).
			Msg(preview)
		baseOutcome.Description = validated.Suggestion.Description
		baseOutcome.Topics = validated.Suggestion.Topics
		baseOutcome.Skipped = true
		baseOutcome.SkipReason = "dry-run"
		return baseOutcome
	}

	updated, err := a.github.UpdateMetadata(repoCtx, repo, validated.Suggestion.Description, validated.Suggestion.Topics)
	if err != nil {
		return model.RepoOutcome{FullName: fullName, ErrorMessage: err.Error()}
	}

	baseOutcome.Description = updated.GetDescription()
	baseOutcome.Topics = updated.Topics
	baseOutcome.Updated = true
	return baseOutcome
}

func (a *App) filterRepositories(repos []*github.Repository) []*github.Repository {
	filtered := make([]*github.Repository, 0, len(repos))
	for _, repo := range repos {
		if repo == nil {
			continue
		}
		if repo.GetArchived() || repo.GetFork() || repo.GetDisabled() {
			continue
		}
		if !a.matchesRepoSelection(repo) {
			continue
		}
		if !a.allowlisted(repo) || a.blocklisted(repo) {
			continue
		}
		filtered = append(filtered, repo)
	}
	return filtered
}

func (a *App) matchesRepoSelection(repo *github.Repository) bool {
	selection := strings.TrimSpace(a.cfg.RepoFilter)
	if selection == "" {
		return true
	}

	selection = strings.ToLower(selection)
	if strings.Contains(selection, "/") {
		return strings.ToLower(repo.GetFullName()) == selection
	}
	return strings.ToLower(repo.GetName()) == selection
}

func (a *App) allowlisted(repo *github.Repository) bool {
	if len(a.cfg.Allowlist) == 0 {
		return true
	}
	return matchesAny(repo, a.cfg.Allowlist)
}

func (a *App) blocklisted(repo *github.Repository) bool {
	if len(a.cfg.Blocklist) == 0 {
		return false
	}
	return matchesAny(repo, a.cfg.Blocklist)
}

func (a *App) isLockedRepo(repo *github.Repository) bool {
	if len(a.cfg.LockedRepos) == 0 {
		return false
	}
	return matchesAny(repo, a.cfg.LockedRepos)
}

func (a *App) loadSuggestion(ctx context.Context, repoAnalysis model.RepoAnalysis, snapshot model.RepoSnapshot, prompt string) (model.MetadataSuggestion, bool, error) {
	if a.cache != nil {
		if cached, ok := a.cache.Lookup(repoAnalysis.FullName, snapshot.ReadmeHash, snapshot.CommitSHA); ok {
			return analysis.CanonicalizeSuggestion(cached), true, nil
		}
	}
	if a.llm == nil {
		return model.MetadataSuggestion{}, false, errors.New("openrouter client is not configured")
	}

	suggestion, err := a.llm.GenerateMetadata(ctx, prompt)
	if err != nil {
		log := a.logger.With().Str("repo", repoAnalysis.FullName).Logger()
		log.Warn().Err(err).Msg("OpenRouter generation failed; using deterministic fallback")
		return analysis.FallbackSuggestion(repoAnalysis), false, nil
	}
	return analysis.CanonicalizeSuggestion(suggestion), false, nil
}

func allowLowConfidenceUpdate(confidence model.ConfidenceScore) bool {
	return confidence.TechnologyAccuracy > 0.85
}

func confidenceSkipReason(snapshot model.RepoSnapshot, confidence model.ConfidenceScore) string {
	if strings.TrimSpace(snapshot.README) == "" || len(strings.Fields(snapshot.README)) < 20 {
		return "low README quality"
	}
	if len(snapshot.Files) <= 1 {
		return "insufficient source structure"
	}
	if confidence.TechnologyAccuracy < 0.6 {
		return "weak technology detection"
	}
	if confidence.MetadataScore < 0.6 {
		return "weak metadata grounding"
	}
	return "low overall confidence"
}

func matchesAny(repo *github.Repository, values []string) bool {
	name := strings.ToLower(repo.GetName())
	fullName := strings.ToLower(repo.GetFullName())
	for _, value := range values {
		candidate := strings.ToLower(strings.TrimSpace(value))
		if candidate == "" {
			continue
		}
		if candidate == name || candidate == fullName {
			return true
		}
	}
	return false
}

func metadataChanged(repoAnalysis model.RepoAnalysis, snapshot model.RepoSnapshot, suggestion model.MetadataSuggestion) bool {
	currentDescription := strings.Join(strings.Fields(strings.TrimSpace(repoAnalysis.Description)), " ")
	desiredDescription := strings.Join(strings.Fields(strings.TrimSpace(suggestion.Description)), " ")
	if currentDescription != desiredDescription {
		return true
	}

	currentTopics := analysis.NormalizeSuggestion(model.MetadataSuggestion{Topics: snapshot.ExistingTopics}).Topics
	desiredTopics := analysis.NormalizeSuggestion(model.MetadataSuggestion{Topics: suggestion.Topics}).Topics
	return !sameStringSet(currentTopics, desiredTopics)
}

func sameStringSet(left, right []string) bool {
	if len(left) != len(right) {
		return false
	}
	leftCopy := append([]string(nil), left...)
	rightCopy := append([]string(nil), right...)
	sort.Strings(leftCopy)
	sort.Strings(rightCopy)
	for i := range leftCopy {
		if leftCopy[i] != rightCopy[i] {
			return false
		}
	}
	return true
}
