package app

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"
)

var ErrPipelineAlreadyRunning = errors.New("pipeline already running")

type PipelineRunOptions struct {
	Selection        []string
	GenerateManifest bool
	PreviewOnly      bool
	DryRun           bool
	ApplyManifest    string
	Mode             string
	Reason           string
}

type pipelineJobState struct {
	ID         string    `json:"id,omitempty"`
	Running    bool      `json:"running,omitempty"`
	Paused     bool      `json:"paused,omitempty"`
	Mode       string    `json:"mode,omitempty"`
	Selection  []string  `json:"selection,omitempty"`
	StartedAt  time.Time `json:"started_at,omitempty"`
	FinishedAt time.Time `json:"finished_at,omitempty"`
	LastError  string    `json:"last_error,omitempty"`
	Reason     string    `json:"reason,omitempty"`
}

type pipelineManager struct {
	mu     sync.Mutex
	app    *App
	state  pipelineJobState
	cancel context.CancelFunc
}

func newPipelineManager(app *App) *pipelineManager {
	return &pipelineManager{app: app}
}

func (m *pipelineManager) start(opts PipelineRunOptions) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.state.Running {
		return ErrPipelineAlreadyRunning
	}
	jobCtx, cancel := context.WithCancel(context.Background())
	m.state = pipelineJobState{
		ID:        fmt.Sprintf("pipeline-%d", time.Now().UTC().UnixNano()),
		Running:   true,
		Mode:      strings.TrimSpace(opts.Mode),
		Selection: append([]string(nil), opts.Selection...),
		StartedAt: time.Now().UTC(),
		Reason:    strings.TrimSpace(opts.Reason),
	}
	m.cancel = cancel
	clone := *m.app
	clone.cfg = m.app.cfg
	clone.pipeline = m
	if len(opts.Selection) > 0 {
		clone.cfg.Allowlist = append([]string(nil), opts.Selection...)
		clone.cfg.RepoFilter = ""
	}
	if opts.GenerateManifest {
		clone.cfg.GenerateManifest = true
		clone.cfg.ApplyManifest = ""
	}
	if opts.PreviewOnly {
		clone.cfg.PreviewOnly = true
	}
	if opts.DryRun {
		clone.cfg.DryRun = true
	}
	if strings.TrimSpace(opts.ApplyManifest) != "" {
		clone.cfg.ApplyManifest = strings.TrimSpace(opts.ApplyManifest)
	}
	go func() {
		err := clone.runPipeline(jobCtx)
		m.finish(err)
	}()
	return nil
}

func (m *pipelineManager) finish(err error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.state.Running = false
	m.state.Paused = false
	m.state.FinishedAt = time.Now().UTC()
	if err != nil {
		m.state.LastError = err.Error()
	} else {
		m.state.LastError = ""
	}
	if m.cancel != nil {
		m.cancel()
		m.cancel = nil
	}
}

func (m *pipelineManager) stop() error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.cancel != nil {
		m.cancel()
	}
	m.state.Running = false
	m.state.Paused = false
	m.state.FinishedAt = time.Now().UTC()
	return nil
}

func (m *pipelineManager) pause() error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if !m.state.Running {
		return nil
	}
	m.state.Paused = true
	return nil
}

func (m *pipelineManager) resume() error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if !m.state.Running {
		return nil
	}
	m.state.Paused = false
	return nil
}

func (m *pipelineManager) snapshot() pipelineJobState {
	m.mu.Lock()
	defer m.mu.Unlock()
	selection := append([]string(nil), m.state.Selection...)
	m.state.Selection = selection
	return m.state
}

func (m *pipelineManager) waitIfPaused(done <-chan struct{}) bool {
	for {
		m.mu.Lock()
		paused := m.state.Running && m.state.Paused
		m.mu.Unlock()
		if !paused {
			return true
		}
		select {
		case <-done:
			return false
		case <-time.After(200 * time.Millisecond):
		}
	}
}

func (m *pipelineManager) retryFailed(manifestPath string) error {
	if m.app == nil {
		return errors.New("pipeline manager is not attached")
	}
	path := strings.TrimSpace(manifestPath)
	if path == "" {
		path = strings.TrimSpace(m.app.cfg.ManifestFile)
	}
	manifest, err := loadManifestFile(path)
	if err != nil {
		return err
	}
	selection := make([]string, 0, len(manifest.Repositories))
	for _, entry := range manifest.Repositories {
		if len(entry.Failures) == 0 && !entry.UpdateStatus.Skipped {
			continue
		}
		if strings.TrimSpace(entry.FullName) != "" {
			selection = append(selection, entry.FullName)
		}
	}
	if len(selection) == 0 {
		return errors.New("no failed repositories found in manifest")
	}
	return m.start(PipelineRunOptions{Selection: selection, Reason: "retry failed repositories"})
}

func normalizeSelection(selection []string) []string {
	filtered := make([]string, 0, len(selection))
	seen := make(map[string]struct{}, len(selection))
	for _, item := range selection {
		candidate := strings.TrimSpace(item)
		if candidate == "" {
			continue
		}
		if _, ok := seen[candidate]; ok {
			continue
		}
		seen[candidate] = struct{}{}
		filtered = append(filtered, candidate)
	}
	return filtered
}
