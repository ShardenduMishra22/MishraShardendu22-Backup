package app

import (
	"testing"

	"go-description-script/internal/model"
	"go-description-script/internal/observability"
	"go-description-script/internal/openrouter"
)

func TestPipelineStatusNormalizesCollections(t *testing.T) {
	t.Parallel()

	got := (&App{}).PipelineStatus()

	repositories, ok := got["repositories"].([]model.RepoManifest)
	if !ok {
		t.Fatalf("repositories has unexpected type %T", got["repositories"])
	}
	if repositories == nil {
		t.Fatal("repositories is nil")
	}
	if len(repositories) != 0 {
		t.Fatalf("repositories length = %d, want 0", len(repositories))
	}

	events, ok := got["events"].([]observability.Event)
	if !ok {
		t.Fatalf("events has unexpected type %T", got["events"])
	}
	if events == nil {
		t.Fatal("events is nil")
	}
	if len(events) != 0 {
		t.Fatalf("events length = %d, want 0", len(events))
	}

	metrics, ok := got["openrouter"].(openrouter.Metrics)
	if !ok {
		t.Fatalf("openrouter has unexpected type %T", got["openrouter"])
	}
	if metrics.Keys == nil {
		t.Fatal("openrouter keys is nil")
	}
	if metrics.Models == nil {
		t.Fatal("openrouter models is nil")
	}

	summary, ok := got["summary"].(map[string]any)
	if !ok {
		t.Fatalf("summary has unexpected type %T", got["summary"])
	}

	cooldowns, ok := summary["cooldowns"].([]map[string]any)
	if !ok {
		t.Fatalf("cooldowns has unexpected type %T", summary["cooldowns"])
	}
	if cooldowns == nil {
		t.Fatal("cooldowns is nil")
	}

	modelUsage, ok := summary["model_usage"].([]openrouter.ModelHealth)
	if !ok {
		t.Fatalf("model_usage has unexpected type %T", summary["model_usage"])
	}
	if modelUsage == nil {
		t.Fatal("model_usage is nil")
	}

	keyUsage, ok := summary["key_usage"].([]openrouter.KeyHealth)
	if !ok {
		t.Fatalf("key_usage has unexpected type %T", summary["key_usage"])
	}
	if keyUsage == nil {
		t.Fatal("key_usage is nil")
	}
}

func TestOpenRouterHealthAccessorsReturnEmptySlices(t *testing.T) {
	t.Parallel()

	if got := (&App{}).OpenRouterKeyHealth(); got == nil || len(got) != 0 {
		t.Fatalf("OpenRouterKeyHealth() = %#v, want empty non-nil slice", got)
	}
	if got := (&App{}).OpenRouterModelHealth(); got == nil || len(got) != 0 {
		t.Fatalf("OpenRouterModelHealth() = %#v, want empty non-nil slice", got)
	}
}
