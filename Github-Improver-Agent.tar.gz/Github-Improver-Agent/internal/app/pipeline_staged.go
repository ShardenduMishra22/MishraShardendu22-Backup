package app

import (
	"container/heap"
	"context"
	"errors"
	"fmt"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"go-description-script/internal/analysis"
	"go-description-script/internal/model"
	"go-description-script/internal/observability"
	"go-description-script/internal/retry"

	"github.com/google/go-github/v86/github"
	"github.com/rs/zerolog"
)

const (
	stageDiscovery     = "discovery"
	stageSnapshot      = "snapshot"
	stageInspection    = "inspection"
	stageLLM           = "llm_generation"
	stageNormalization = "normalization"
	stageValidation    = "validation"
	stageManifest      = "manifest_persistence"
	stageGitHub        = "github_update"
)

type pipelineItem struct {
	index int
	repo  *github.Repository

	manifest      model.RepoManifest
	snapshot      model.RepoSnapshot
	analysis      model.RepoAnalysis
	prompt        string
	rawSuggestion model.MetadataSuggestion
	suggestion    model.MetadataSuggestion
	validation    analysis.ValidationResult
	cacheHit      bool

	attempts   map[string]int
	retries    map[string]int
	retryCount int

	updatePlan updatePlan
	completed  int32
}

func (i *pipelineItem) nextAttempt(stage string) int {
	if i.attempts == nil {
		i.attempts = make(map[string]int)
	}
	i.attempts[stage]++
	return i.attempts[stage]
}

func (i *pipelineItem) recordRetry(stage string) int {
	if i.retries == nil {
		i.retries = make(map[string]int)
	}
	i.retries[stage]++
	i.retryCount++
	return i.retries[stage]
}

func (i *pipelineItem) retrySummary() model.RetrySummary {
	if i.retryCount == 0 {
		return model.RetrySummary{}
	}
	copied := make(map[string]int, len(i.retries))
	for key, value := range i.retries {
		copied[key] = value
	}
	return model.RetrySummary{Total: i.retryCount, ByStage: copied}
}

func (i *pipelineItem) markDone(wg *sync.WaitGroup) {
	if i == nil || wg == nil {
		return
	}
	if atomic.CompareAndSwapInt32(&i.completed, 0, 1) {
		wg.Done()
	}
}

type updatePlan struct {
	allowDescription bool
	allowTopics      bool
	queueable        bool
	reason           string
}

type stageMetrics struct {
	active        int64
	processed     int64
	failed        int64
	retried       int64
	durationNanos int64
}

type pipelineMetrics struct {
	stages  map[string]*stageMetrics
	started time.Time
}

func newPipelineMetrics(stageNames ...string) *pipelineMetrics {
	stages := make(map[string]*stageMetrics, len(stageNames))
	for _, name := range stageNames {
		stages[name] = &stageMetrics{}
	}
	return &pipelineMetrics{stages: stages, started: time.Now().UTC()}
}

func (m *pipelineMetrics) begin(stage string) time.Time {
	metrics := m.stages[stage]
	if metrics == nil {
		return time.Now()
	}
	atomic.AddInt64(&metrics.active, 1)
	return time.Now()
}

func (m *pipelineMetrics) end(stage string, start time.Time, failed bool) {
	metrics := m.stages[stage]
	if metrics == nil {
		return
	}
	atomic.AddInt64(&metrics.active, -1)
	atomic.AddInt64(&metrics.processed, 1)
	if failed {
		atomic.AddInt64(&metrics.failed, 1)
	}
	atomic.AddInt64(&metrics.durationNanos, time.Since(start).Nanoseconds())
}

func (m *pipelineMetrics) retry(stage string) {
	metrics := m.stages[stage]
	if metrics == nil {
		return
	}
	atomic.AddInt64(&metrics.retried, 1)
}

type scheduledRetry struct {
	due   time.Time
	stage string
	item  *pipelineItem
}

type retryQueue []scheduledRetry

func (q retryQueue) Len() int {
	return len(q)
}

func (q retryQueue) Less(i, j int) bool {
	return q[i].due.Before(q[j].due)
}

func (q retryQueue) Swap(i, j int) {
	q[i], q[j] = q[j], q[i]
}

func (q *retryQueue) Push(x any) {
	*q = append(*q, x.(scheduledRetry))
}

func (q *retryQueue) Pop() any {
	old := *q
	n := len(old)
	item := old[n-1]
	*q = old[:n-1]
	return item
}

type retryScheduler struct {
	mu      sync.Mutex
	queue   retryQueue
	wake    chan struct{}
	out     chan scheduledRetry
	stopped chan struct{}
}

func newRetryScheduler(buffer int) *retryScheduler {
	queue := make(retryQueue, 0, buffer)
	heap.Init(&queue)
	return &retryScheduler{
		queue:   queue,
		wake:    make(chan struct{}, 1),
		out:     make(chan scheduledRetry, buffer),
		stopped: make(chan struct{}),
	}
}

func (r *retryScheduler) Schedule(stage string, item *pipelineItem, delay time.Duration) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	select {
	case <-r.stopped:
		return false
	default:
	}
	due := time.Now().Add(delay)
	heap.Push(&r.queue, scheduledRetry{due: due, stage: stage, item: item})
	select {
	case r.wake <- struct{}{}:
	default:
	}
	return true
}

func (r *retryScheduler) Run(ctx context.Context) {
	for {
		r.mu.Lock()
		if len(r.queue) == 0 {
			r.mu.Unlock()
			select {
			case <-ctx.Done():
				close(r.out)
				return
			case <-r.stopped:
				close(r.out)
				return
			case <-r.wake:
				continue
			}
		}
		next := r.queue[0]
		delay := time.Until(next.due)
		if delay < 0 {
			delay = 0
		}
		r.mu.Unlock()

		timer := time.NewTimer(delay)
		select {
		case <-ctx.Done():
			timer.Stop()
			close(r.out)
			return
		case <-r.stopped:
			timer.Stop()
			close(r.out)
			return
		case <-r.wake:
			timer.Stop()
			continue
		case <-timer.C:
		}

		r.mu.Lock()
		if len(r.queue) == 0 {
			r.mu.Unlock()
			continue
		}
		item := heap.Pop(&r.queue).(scheduledRetry)
		r.mu.Unlock()

		select {
		case r.out <- item:
		case <-ctx.Done():
			close(r.out)
			return
		case <-r.stopped:
			close(r.out)
			return
		}
	}
}

func (r *retryScheduler) Stop() {
	select {
	case <-r.stopped:
		return
	default:
		close(r.stopped)
	}
}

func (r *retryScheduler) Out() <-chan scheduledRetry {
	return r.out
}

type manifestUpdate struct {
	index int
	apply func(*model.RepoManifest)
}

type manifestWriter struct {
	updates  chan manifestUpdate
	flush    chan chan error
	done     chan error
	manifest *model.ManifestFile
	path     string
	logger   zerolog.Logger
	events   *observability.Hub
}

func startManifestWriter(ctx context.Context, manifest *model.ManifestFile, path string, logger zerolog.Logger, events *observability.Hub) *manifestWriter {
	writer := &manifestWriter{
		updates:  make(chan manifestUpdate, 64),
		flush:    make(chan chan error),
		done:     make(chan error, 1),
		manifest: manifest,
		path:     path,
		logger:   logger,
		events:   events,
	}

	go func() {
		ticker := time.NewTicker(2 * time.Second)
		defer ticker.Stop()

		dirty := false
		for {
			select {
			case <-ctx.Done():
				err := flushManifestIfNeeded(path, manifest, dirty)
				writer.done <- err
				return
			case update, ok := <-writer.updates:
				if !ok {
					err := flushManifestIfNeeded(path, manifest, dirty)
					writer.done <- err
					return
				}
				if update.apply != nil && update.index >= 0 && update.index < len(manifest.Repositories) {
					update.apply(&manifest.Repositories[update.index])
					if writer.events != nil {
						writer.events.Publish(observability.Event{Type: "repo_update", Payload: manifest.Repositories[update.index]})
					}
				}
				dirty = true
			case resp := <-writer.flush:
				err := flushManifestIfNeeded(path, manifest, dirty)
				if err == nil {
					dirty = false
				}
				resp <- err
			case <-ticker.C:
				if !dirty {
					continue
				}
				if err := flushManifestIfNeeded(path, manifest, true); err != nil {
					writer.logger.Error().Err(err).Msg("failed to persist manifest")
					continue
				}
				dirty = false
			}
		}
	}()

	return writer
}

func (w *manifestWriter) Update(ctx context.Context, update manifestUpdate) bool {
	select {
	case <-ctx.Done():
		return false
	case w.updates <- update:
		return true
	}
}

func (w *manifestWriter) Flush(ctx context.Context) error {
	response := make(chan error, 1)
	select {
	case <-ctx.Done():
		return ctx.Err()
	case w.flush <- response:
	}
	select {
	case <-ctx.Done():
		return ctx.Err()
	case err := <-response:
		return err
	}
}

func (w *manifestWriter) Close() error {
	close(w.updates)
	return <-w.done
}

func flushManifestIfNeeded(path string, manifest *model.ManifestFile, dirty bool) error {
	if !dirty {
		return nil
	}
	if manifest == nil {
		return errors.New("manifest is nil")
	}
	return saveManifestFile(path, manifest)
}

func (a *App) runStagedDiscovery(ctx context.Context, repos []*github.Repository, manifestPath string, previewOnly bool) (model.ManifestFile, error) {
	if a.state != nil {
		a.state.MarkRunning(stageDiscovery)
	}
	manifest := model.ManifestFile{
		Version:      manifestVersion,
		GeneratedAt:  time.Now().UTC(),
		Repositories: make([]model.RepoManifest, len(repos)),
	}

	for index, repo := range repos {
		manifest.Repositories[index] = newRepoManifest(repo)
	}

	writer := startManifestWriter(context.Background(), &manifest, manifestPath, a.logger.With().Str("stage", stageManifest).Logger(), a.events)
	defer func() {
		if err := writer.Close(); err != nil {
			a.logger.Error().Err(err).Msg("failed to close manifest writer")
		}
	}()

	metrics := newPipelineMetrics(stageDiscovery, stageSnapshot, stageInspection, stageLLM, stageNormalization, stageValidation)
	retryScheduler := newRetryScheduler(a.cfg.Workers * 2)
	retryCtx, retryCancel := context.WithCancel(context.Background())
	defer retryCancel()
	go retryScheduler.Run(retryCtx)

	stopCh := ctx.Done()

	discoveryCh := make(chan discoveryJob, a.cfg.Workers*2)
	snapshotCh := make(chan *pipelineItem, a.cfg.Workers*2)
	inspectionCh := make(chan *pipelineItem, a.cfg.Workers*2)
	llmCh := make(chan *pipelineItem, a.cfg.LLMWorkers*2)
	normalizeCh := make(chan *pipelineItem, a.cfg.Workers*2)
	validationCh := make(chan *pipelineItem, a.cfg.Workers*2)

	var itemWg sync.WaitGroup
	itemWg.Add(len(repos))

	doneCh := make(chan struct{})
	go func() {
		itemWg.Wait()
		close(doneCh)
	}()

	go func() {
		for retryItem := range retryScheduler.Out() {
			if retryItem.item == nil {
				continue
			}
			select {
			case <-doneCh:
				return
			default:
			}
			switch retryItem.stage {
			case stageSnapshot:
				sendPipelineItem(doneCh, snapshotCh, retryItem.item)
			case stageLLM:
				sendPipelineItem(doneCh, llmCh, retryItem.item)
			default:
			}
		}
	}()

	startProgressReporter(ctx, a.logger, metrics, map[string]int{
		stageDiscovery:     cap(discoveryCh),
		stageSnapshot:      cap(snapshotCh),
		stageInspection:    cap(inspectionCh),
		stageLLM:           cap(llmCh),
		stageNormalization: cap(normalizeCh),
		stageValidation:    cap(validationCh),
	}, map[string]func() int{
		stageDiscovery:     func() int { return len(discoveryCh) },
		stageSnapshot:      func() int { return len(snapshotCh) },
		stageInspection:    func() int { return len(inspectionCh) },
		stageLLM:           func() int { return len(llmCh) },
		stageNormalization: func() int { return len(normalizeCh) },
		stageValidation:    func() int { return len(validationCh) },
	}, a.state, a.events)

	for workerID := 0; workerID < a.cfg.Workers; workerID++ {
		go a.discoveryWorker(workerID, metrics, writer, discoveryCh, snapshotCh, doneCh, &itemWg)
	}
	for workerID := 0; workerID < a.cfg.Workers; workerID++ {
		go a.snapshotWorker(workerID, metrics, retryScheduler, snapshotCh, inspectionCh, writer, doneCh, stopCh, &itemWg)
	}
	for workerID := 0; workerID < a.cfg.Workers; workerID++ {
		go a.inspectionWorker(workerID, metrics, inspectionCh, llmCh, writer, doneCh, &itemWg)
	}
	for workerID := 0; workerID < a.cfg.LLMWorkers; workerID++ {
		go a.llmWorker(workerID, metrics, retryScheduler, llmCh, normalizeCh, writer, doneCh, stopCh, &itemWg)
	}
	for workerID := 0; workerID < a.cfg.Workers; workerID++ {
		go a.normalizationWorker(workerID, metrics, normalizeCh, validationCh, writer, doneCh, &itemWg)
	}
	for workerID := 0; workerID < a.cfg.Workers; workerID++ {
		go a.validationWorker(workerID, metrics, validationCh, nil, writer, doneCh, stopCh, &itemWg)
	}

	go func() {
		defer close(discoveryCh)
		for index, repo := range repos {
			select {
			case <-stopCh:
				return
			case <-doneCh:
				return
			default:
			}
			select {
			case <-stopCh:
				itemWg.Done()
				return
			case <-doneCh:
				itemWg.Done()
				return
			case discoveryCh <- discoveryJob{index: index, repo: repo}:
			}
		}
	}()

	<-doneCh
	retryScheduler.Stop()

	if err := writer.Flush(context.Background()); err != nil {
		if a.state != nil {
			a.state.MarkCompleted(err)
		}
		return model.ManifestFile{}, err
	}
	if err := ctx.Err(); err != nil {
		if a.state != nil {
			a.state.MarkCompleted(err)
		}
		return model.ManifestFile{}, err
	}

	processed := len(manifest.Repositories)
	failedRepos := 0
	validationFailures := 0
	for _, entry := range manifest.Repositories {
		if len(entry.Failures) > 0 {
			failedRepos++
			for _, failure := range entry.Failures {
				if strings.EqualFold(failure.Stage, stageValidation) {
					validationFailures++
				}
			}
		}
	}

	a.logger.Info().
		Int("repositories", len(manifest.Repositories)).
		Int("processed", processed).
		Int("failed_repositories", failedRepos).
		Int("validation_failures", validationFailures).
		Str("manifest_file", manifestPath).
		Msg("manifest generation completed")
	if a.state != nil {
		a.state.MarkCompleted(nil)
	}

	return manifest, nil
}

func (a *App) runStagedUpdate(ctx context.Context, manifest *model.ManifestFile, manifestPath string, previewOnly bool) error {
	if manifest == nil {
		return errors.New("manifest is required for the update phase")
	}
	if a.state != nil {
		a.state.MarkRunning(stageGitHub)
	}

	writer := startManifestWriter(context.Background(), manifest, manifestPath, a.logger.With().Str("stage", stageManifest).Logger(), a.events)
	defer func() {
		if err := writer.Close(); err != nil {
			a.logger.Error().Err(err).Msg("failed to close manifest writer")
		}
	}()

	queue := make([]updateJob, 0, len(manifest.Repositories))
	skippedCount := 0
	validationFailures := 0

	for index := range manifest.Repositories {
		entry := manifest.Repositories[index]
		plan := a.buildUpdatePlan(entry)
		if !plan.queueable {
			skippedCount++
			if strings.Contains(plan.reason, "validation") {
				validationFailures++
			}
			entry.UpdateStatus.Skipped = true
			if entry.UpdateStatus.SkipReason == "" {
				entry.UpdateStatus.SkipReason = plan.reason
			}
			updated := entry
			_ = writer.Update(context.Background(), manifestUpdate{
				index: index,
				apply: func(m *model.RepoManifest) {
					*m = updated
				},
			})
			continue
		}

		queue = append(queue, updateJob{index: index, manifest: entry})
	}

	if a.cfg.Limit > 0 && len(queue) > a.cfg.Limit {
		queue = queue[:a.cfg.Limit]
	}

	a.logger.Info().
		Int("queued_repo_count", len(queue)).
		Int("skipped_repo_count", skippedCount).
		Int("validation_failures", validationFailures).
		Str("manifest_file", manifestPath).
		Msg("update queue created")

	a.printManifestPreviewFromQueue(queue)

	if previewOnly || a.cfg.DryRun {
		err := writer.Flush(context.Background())
		if a.state != nil {
			a.state.MarkCompleted(err)
		}
		return err
	}

	if err := a.requireUpdateCredentials(); err != nil {
		if a.state != nil {
			a.state.MarkCompleted(err)
		}
		return err
	}

	if len(queue) == 0 {
		a.logger.Info().Msg("no repositories qualified for the update phase")
		err := writer.Flush(context.Background())
		if a.state != nil {
			a.state.MarkCompleted(err)
		}
		return err
	}

	metrics := newPipelineMetrics(stageGitHub)
	retryScheduler := newRetryScheduler(a.cfg.GitHubWorkers * 2)
	retryCtx, retryCancel := context.WithCancel(context.Background())
	defer retryCancel()
	go retryScheduler.Run(retryCtx)

	stopCh := ctx.Done()
	updateCh := make(chan *pipelineItem, a.cfg.GitHubWorkers*2)
	var itemWg sync.WaitGroup
	itemWg.Add(len(queue))

	doneCh := make(chan struct{})
	go func() {
		itemWg.Wait()
		close(doneCh)
	}()

	go func() {
		for retryItem := range retryScheduler.Out() {
			if retryItem.item == nil {
				continue
			}
			select {
			case <-doneCh:
				return
			default:
			}
			sendPipelineItem(doneCh, updateCh, retryItem.item)
		}
	}()

	startProgressReporter(ctx, a.logger, metrics, map[string]int{stageGitHub: cap(updateCh)}, map[string]func() int{stageGitHub: func() int { return len(updateCh) }}, a.state, a.events)

	for workerID := 0; workerID < a.cfg.GitHubWorkers; workerID++ {
		go a.updateWorker(workerID, metrics, retryScheduler, updateCh, writer, doneCh, stopCh, &itemWg)
	}

sendLoop:
	for _, job := range queue {
		item := &pipelineItem{
			index:    job.index,
			manifest: job.manifest,
		}
		item.updatePlan = a.buildUpdatePlan(job.manifest)
		select {
		case <-stopCh:
			itemWg.Done()
			break sendLoop
		case <-doneCh:
			itemWg.Done()
			break sendLoop
		case updateCh <- item:
		}
	}

	<-doneCh
	retryScheduler.Stop()

	if err := writer.Flush(context.Background()); err != nil {
		if a.state != nil {
			a.state.MarkCompleted(err)
		}
		return err
	}
	if err := ctx.Err(); err != nil {
		if a.state != nil {
			a.state.MarkCompleted(err)
		}
		return err
	}

	successfulUpdates := 0
	partialUpdates := 0
	failedUpdates := 0
	for _, job := range queue {
		entry := manifest.Repositories[job.index]
		status := entry.UpdateStatus
		switch {
		case status.DescriptionUpdated && status.TopicsUpdated:
			successfulUpdates++
		case status.DescriptionUpdated || status.TopicsUpdated:
			partialUpdates++
		default:
			failedUpdates++
		}
	}

	a.logger.Info().
		Int("queued_repo_count", len(queue)).
		Int("skipped_repo_count", skippedCount).
		Int("successful_updates", successfulUpdates).
		Int("partial_updates", partialUpdates).
		Int("failed_updates", failedUpdates).
		Str("manifest_file", manifestPath).
		Msg("metadata update phase completed")
	if a.state != nil {
		a.state.MarkCompleted(nil)
	}

	return nil
}

func (a *App) discoveryWorker(workerID int, metrics *pipelineMetrics, writer *manifestWriter, in <-chan discoveryJob, out chan<- *pipelineItem, done <-chan struct{}, itemWg *sync.WaitGroup) {
	defer a.recoverWorker(workerID, stageDiscovery)
	for {
		select {
		case <-done:
			return
		case job, ok := <-in:
			if !ok {
				return
			}
			item := &pipelineItem{index: job.index, repo: job.repo, manifest: newRepoManifest(job.repo)}
			func() {
				if !a.waitForPipelineSlot(done) {
					return
				}
				defer func() {
					if r := recover(); r != nil {
						a.handleItemPanic(workerID, stageDiscovery, item, writer, itemWg, r)
					}
				}()

				start := metrics.begin(stageDiscovery)
				repoName := repoFullName(job.repo)
				log := a.stageLogger(workerID, repoName, stageDiscovery)
				log.Info().Str("status", "started").Msg("stage started")

				if job.repo == nil {
					item.manifest.Failures = append(item.manifest.Failures, model.RepoFailure{Stage: stageSnapshot, Error: "repository was nil"})
					item.manifest.UpdateStatus.Skipped = true
					item.manifest.UpdateStatus.SkipReason = "repository was nil"
					item.manifest.StageResults.SnapshotSuccess = false
					item.manifest.Retries = item.retrySummary()
					_ = writer.Update(context.Background(), manifestUpdateFromItem(item))
					metrics.end(stageDiscovery, start, true)
					log.Warn().Str("status", "failed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("repository was nil")
					item.markDone(itemWg)
					return
				}
				if a.isLockedRepo(job.repo) {
					item.manifest.UpdateStatus.Skipped = true
					item.manifest.UpdateStatus.SkipReason = "repository is locked in local config"
					item.manifest.Retries = item.retrySummary()
					_ = writer.Update(context.Background(), manifestUpdateFromItem(item))
					metrics.end(stageDiscovery, start, false)
					log.Info().Str("status", "completed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("repository locked")
					item.markDone(itemWg)
					return
				}

				sendPipelineItem(done, out, item)
				metrics.end(stageDiscovery, start, false)
				log.Info().Str("status", "completed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("stage completed")
			}()
		}
	}
}

func (a *App) snapshotWorker(workerID int, metrics *pipelineMetrics, scheduler *retryScheduler, in <-chan *pipelineItem, out chan<- *pipelineItem, writer *manifestWriter, done <-chan struct{}, stop <-chan struct{}, itemWg *sync.WaitGroup) {
	defer a.recoverWorker(workerID, stageSnapshot)
	for {
		select {
		case <-done:
			return
		case item, ok := <-in:
			if !ok {
				return
			}
			func() {
				if !a.waitForPipelineSlot(done) {
					return
				}
				defer func() {
					if r := recover(); r != nil {
						a.handleItemPanic(workerID, stageSnapshot, item, writer, itemWg, r)
					}
				}()

				attempt := item.nextAttempt(stageSnapshot)
				start := metrics.begin(stageSnapshot)
				repoName := repoFullName(item.repo)
				log := a.stageLogger(workerID, repoName, stageSnapshot).With().Int("attempt", attempt).Logger()
				log.Info().Str("status", "started").Msg("stage started")

				stageCtx, cancel := context.WithTimeout(context.Background(), a.cfg.RepoTimeout)
				snapshot, err := a.github.ReadSnapshot(stageCtx, item.repo)
				cancel()
				if err != nil {
					if shouldRetryStage(stop, scheduler, item, stageSnapshot, attempt, err, metrics, a.cfg.RetryAttempts) {
						log.Warn().Str("status", "retry_scheduled").Err(err).Msg("snapshot retry scheduled")
						metrics.end(stageSnapshot, start, false)
						return
					}
					item.manifest.Failures = append(item.manifest.Failures, model.RepoFailure{Stage: stageSnapshot, Error: err.Error()})
					item.manifest.UpdateStatus.Skipped = true
					item.manifest.UpdateStatus.SkipReason = "snapshot failed"
					item.manifest.StageResults.SnapshotSuccess = false
					item.manifest.Retries = item.retrySummary()
					_ = writer.Update(context.Background(), manifestUpdateFromItem(item))
					metrics.end(stageSnapshot, start, true)
					log.Warn().Str("status", "failed").Int64("duration_ms", time.Since(start).Milliseconds()).Err(err).Msg("snapshot failed")
					item.markDone(itemWg)
					return
				}

				item.snapshot = snapshot
				item.manifest.StageResults.SnapshotSuccess = true
				sendPipelineItem(done, out, item)
				metrics.end(stageSnapshot, start, false)
				log.Info().Str("status", "completed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("stage completed")
			}()
		}
	}
}

func (a *App) inspectionWorker(workerID int, metrics *pipelineMetrics, in <-chan *pipelineItem, out chan<- *pipelineItem, writer *manifestWriter, done <-chan struct{}, itemWg *sync.WaitGroup) {
	defer a.recoverWorker(workerID, stageInspection)
	for {
		select {
		case <-done:
			return
		case item, ok := <-in:
			if !ok {
				return
			}
			func() {
				if !a.waitForPipelineSlot(done) {
					return
				}
				defer func() {
					if r := recover(); r != nil {
						a.handleItemPanic(workerID, stageInspection, item, writer, itemWg, r)
					}
				}()

				start := metrics.begin(stageInspection)
				repoName := repoFullName(item.repo)
				log := a.stageLogger(workerID, repoName, stageInspection)
				log.Info().Str("status", "started").Msg("stage started")

				repoAnalysis := a.analyzer.Analyze(item.repo, item.snapshot)
				item.analysis = repoAnalysis
				item.prompt = analysis.BuildPrompt(repoAnalysis)
				item.manifest.Owner = repoAnalysis.Owner
				item.manifest.Name = repoAnalysis.Name
				item.manifest.FullName = repoAnalysis.FullName
				item.manifest.CloneURL = item.repo.GetCloneURL()
				item.manifest.DefaultBranch = repoAnalysis.DefaultBranch
				item.manifest.PrimaryLanguage = repoAnalysis.PrimaryLanguage
				item.manifest.Description = strings.TrimSpace(repoAnalysis.Description)
				item.manifest.Topics = analysis.NormalizeSuggestion(model.MetadataSuggestion{Topics: item.snapshot.ExistingTopics}).Topics
				item.manifest.ReadmeContent = item.snapshot.README
				item.manifest.DetectedTech = append([]string(nil), repoAnalysis.DetectedTechnologies...)
				item.manifest.DetectedFrameworks = append([]string(nil), repoAnalysis.Frameworks...)
				item.manifest.ImportantFiles = importantFilePaths(repoAnalysis.ImportantFiles)
				item.manifest.StageResults.AnalysisSuccess = true
				item.manifest.StageResults.InspectionSuccess = true

				sendPipelineItem(done, out, item)
				metrics.end(stageInspection, start, false)
				log.Info().Str("status", "completed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("stage completed")
			}()
		}
	}
}

func (a *App) llmWorker(workerID int, metrics *pipelineMetrics, scheduler *retryScheduler, in <-chan *pipelineItem, out chan<- *pipelineItem, writer *manifestWriter, done <-chan struct{}, stop <-chan struct{}, itemWg *sync.WaitGroup) {
	defer a.recoverWorker(workerID, stageLLM)
	for {
		select {
		case <-done:
			return
		case item, ok := <-in:
			if !ok {
				return
			}
			func() {
				if !a.waitForPipelineSlot(done) {
					return
				}
				defer func() {
					if r := recover(); r != nil {
						a.handleItemPanic(workerID, stageLLM, item, writer, itemWg, r)
					}
				}()

				attempt := item.nextAttempt(stageLLM)
				start := metrics.begin(stageLLM)
				repoName := repoFullName(item.repo)
				log := a.stageLogger(workerID, repoName, stageLLM).With().Int("attempt", attempt).Logger()
				log.Info().Str("status", "started").Msg("stage started")

				if a.cache != nil {
					if cached, ok := a.cache.Lookup(item.analysis.FullName, item.snapshot.ReadmeHash, item.snapshot.CommitSHA); ok {
						item.rawSuggestion = cached
						item.cacheHit = true
						item.manifest.StageResults.LLMSuccess = true
						sendPipelineItem(done, out, item)
						metrics.end(stageLLM, start, false)
						log.Info().Str("status", "completed").Bool("cache_hit", true).Int64("duration_ms", time.Since(start).Milliseconds()).Msg("stage completed")
						return
					}
				}

				if a.llm == nil {
					item.rawSuggestion = analysis.FallbackSuggestion(item.analysis)
					item.manifest.Failures = append(item.manifest.Failures, model.RepoFailure{Stage: stageLLM, Error: "openrouter client is not configured"})
					item.manifest.StageResults.LLMSuccess = false
					metrics.end(stageLLM, start, true)
					log.Warn().Str("status", "failed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("openrouter client not configured")
					sendPipelineItem(done, out, item)
					return
				}

				stageCtx, cancel := context.WithTimeout(context.Background(), a.cfg.RepoTimeout)
				suggestion, err := a.llm.GenerateMetadata(stageCtx, item.prompt)
				cancel()
				if err != nil {
					if shouldRetryStage(stop, scheduler, item, stageLLM, attempt, err, metrics, a.cfg.RetryAttempts) {
						log.Warn().Str("status", "retry_scheduled").Err(err).Msg("llm retry scheduled")
						metrics.end(stageLLM, start, false)
						return
					}
					item.rawSuggestion = analysis.FallbackSuggestion(item.analysis)
					item.manifest.Failures = append(item.manifest.Failures, model.RepoFailure{Stage: stageLLM, Error: err.Error()})
					item.manifest.StageResults.LLMSuccess = false
					metrics.end(stageLLM, start, true)
					log.Warn().Str("status", "failed").Int64("duration_ms", time.Since(start).Milliseconds()).Err(err).Msg("llm generation failed; using fallback")
					sendPipelineItem(done, out, item)
					return
				}

				item.rawSuggestion = suggestion
				item.manifest.StageResults.LLMSuccess = true
				sendPipelineItem(done, out, item)
				metrics.end(stageLLM, start, false)
				log.Info().Str("status", "completed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("stage completed")
			}()
		}
	}
}

func (a *App) normalizationWorker(workerID int, metrics *pipelineMetrics, in <-chan *pipelineItem, out chan<- *pipelineItem, writer *manifestWriter, done <-chan struct{}, itemWg *sync.WaitGroup) {
	defer a.recoverWorker(workerID, stageNormalization)
	for {
		select {
		case <-done:
			return
		case item, ok := <-in:
			if !ok {
				return
			}
			func() {
				if !a.waitForPipelineSlot(done) {
					return
				}
				defer func() {
					if r := recover(); r != nil {
						a.handleItemPanic(workerID, stageNormalization, item, writer, itemWg, r)
					}
				}()

				start := metrics.begin(stageNormalization)
				repoName := repoFullName(item.repo)
				log := a.stageLogger(workerID, repoName, stageNormalization)
				log.Info().Str("status", "started").Msg("stage started")

				item.suggestion = analysis.CanonicalizeSuggestion(item.rawSuggestion)
				item.manifest.StageResults.NormalizationSuccess = true
				sendPipelineItem(done, out, item)
				metrics.end(stageNormalization, start, false)
				log.Info().Str("status", "completed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("stage completed")
			}()
		}
	}
}

func (a *App) validationWorker(workerID int, metrics *pipelineMetrics, in <-chan *pipelineItem, out chan<- *pipelineItem, writer *manifestWriter, done <-chan struct{}, stop <-chan struct{}, itemWg *sync.WaitGroup) {
	defer a.recoverWorker(workerID, stageValidation)
	for {
		select {
		case <-done:
			return
		case item, ok := <-in:
			if !ok {
				return
			}
			func() {
				if !a.waitForPipelineSlot(done) {
					return
				}
				defer func() {
					if r := recover(); r != nil {
						a.handleItemPanic(workerID, stageValidation, item, writer, itemWg, r)
					}
				}()

				start := metrics.begin(stageValidation)
				repoName := repoFullName(item.repo)
				log := a.stageLogger(workerID, repoName, stageValidation)
				log.Info().Str("status", "started").Msg("stage started")

				validated, err := analysis.ValidateMetadata(item.analysis, item.snapshot, item.suggestion)
				if err != nil {
					item.manifest.Failures = append(item.manifest.Failures, model.RepoFailure{Stage: stageValidation, Error: err.Error()})
					item.manifest.UpdateStatus.Skipped = true
					item.manifest.UpdateStatus.SkipReason = "validation failed"
					item.manifest.StageResults.ValidationSuccess = false
					item.manifest.Retries = item.retrySummary()
					_ = writer.Update(context.Background(), manifestUpdateFromItem(item))
					metrics.end(stageValidation, start, true)
					log.Warn().Str("status", "failed").Int64("duration_ms", time.Since(start).Milliseconds()).Err(err).Msg("validation failed")
					item.markDone(itemWg)
					return
				}

				item.validation = validated
				item.manifest.ConfidenceScore = validated.Confidence.MetadataConfidence
				item.manifest.GeneratedMetadata = &model.GeneratedMetadata{
					Description:     validated.ValidatedDescription,
					Topics:          append([]string(nil), validated.ValidatedTopics...),
					ConfidenceScore: validated.Confidence.MetadataConfidence,
					Validation: model.ValidationSummary{
						Valid:                validated.DescriptionValid || validated.TopicsValid,
						DescriptionValid:     validated.DescriptionValid,
						TopicsValid:          validated.TopicsValid,
						CurrentDescription:   validated.CurrentDescription,
						CurrentTopics:        append([]string(nil), validated.CurrentTopics...),
						GeneratedDescription: validated.GeneratedDescription,
						GeneratedTopics:      append([]string(nil), validated.GeneratedTopics...),
						ValidatedDescription: validated.ValidatedDescription,
						ValidatedTopics:      append([]string(nil), validated.ValidatedTopics...),
						AddedTopics:          append([]string(nil), validated.AddedTopics...),
						RemovedTopics:        append([]string(nil), validated.RemovedTopics...),
						AllowedTopics:        append([]string(nil), validated.AllowedTopics...),
						Warnings:             append([]string(nil), validated.Warnings...),
						Confidence:           validated.Confidence,
						ConfidenceThreshold:  a.cfg.ConfidenceThreshold,
						CacheHit:             item.cacheHit,
					},
					CacheHit: item.cacheHit,
				}
				item.manifest.StageResults.ValidationSuccess = validated.DescriptionValid || validated.TopicsValid
				item.manifest.Retries = item.retrySummary()

				if len(validated.Warnings) > 0 {
					log.Warn().Str("status", "warnings").Strs("warnings", validated.Warnings).Msg("validation warnings")
				}

				if a.cache != nil {
					a.cache.Store(item.analysis.FullName, item.snapshot.ReadmeHash, item.snapshot.CommitSHA, validated.Suggestion, validated.Confidence.MetadataConfidence)
				}

				_ = writer.Update(context.Background(), manifestUpdateFromItem(item))

				if out == nil {
					metrics.end(stageValidation, start, false)
					log.Info().Str("status", "completed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("stage completed")
					item.markDone(itemWg)
					return
				}

				plan := a.buildUpdatePlan(item.manifest)
				item.updatePlan = plan

				if !plan.queueable {
					if item.manifest.UpdateStatus.SkipReason == "" {
						item.manifest.UpdateStatus.Skipped = true
						item.manifest.UpdateStatus.SkipReason = plan.reason
						_ = writer.Update(context.Background(), manifestUpdateFromItem(item))
					}
					metrics.end(stageValidation, start, false)
					log.Info().Str("status", "completed").Str("skip_reason", plan.reason).Int64("duration_ms", time.Since(start).Milliseconds()).Msg("validation completed")
					item.markDone(itemWg)
					return
				}

				select {
				case <-done:
					return
				case <-stop:
					item.manifest.UpdateStatus.Skipped = true
					if item.manifest.UpdateStatus.SkipReason == "" {
						item.manifest.UpdateStatus.SkipReason = "shutdown"
					}
					_ = writer.Update(context.Background(), manifestUpdateFromItem(item))
					metrics.end(stageValidation, start, false)
					item.markDone(itemWg)
					return
				case out <- item:
				}

				metrics.end(stageValidation, start, false)
				log.Info().Str("status", "completed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("stage completed")
			}()
		}
	}
}

func (a *App) updateWorker(workerID int, metrics *pipelineMetrics, scheduler *retryScheduler, in <-chan *pipelineItem, writer *manifestWriter, done <-chan struct{}, stop <-chan struct{}, itemWg *sync.WaitGroup) {
	defer a.recoverWorker(workerID, stageGitHub)
	for {
		select {
		case <-done:
			return
		case item, ok := <-in:
			if !ok {
				return
			}
			func() {
				defer func() {
					if r := recover(); r != nil {
						a.handleItemPanic(workerID, stageGitHub, item, writer, itemWg, r)
					}
				}()

				attempt := item.nextAttempt(stageGitHub)
				start := metrics.begin(stageGitHub)
				repoName := item.manifest.FullName
				log := a.stageLogger(workerID, repoName, stageGitHub).With().Int("attempt", attempt).Logger()
				log.Info().Str("status", "started").Msg("stage started")

				if item.updatePlan.queueable == false {
					item.manifest.UpdateStatus.Skipped = true
					if item.manifest.UpdateStatus.SkipReason == "" {
						item.manifest.UpdateStatus.SkipReason = item.updatePlan.reason
					}
					item.manifest.Retries = item.retrySummary()
					_ = writer.Update(context.Background(), manifestUpdateFromItem(item))
					metrics.end(stageGitHub, start, false)
					log.Info().Str("status", "completed").Str("skip_reason", item.updatePlan.reason).Int64("duration_ms", time.Since(start).Milliseconds()).Msg("update skipped")
					item.markDone(itemWg)
					return
				}

				verifyCtx, cancel := context.WithTimeout(context.Background(), a.cfg.RepoTimeout)
				verifiedRepo, err := a.github.VerifyRepository(verifyCtx, item.manifest.Owner, item.manifest.Name)
				cancel()
				if err != nil {
					if shouldRetryStage(stop, scheduler, item, stageGitHub, attempt, err, metrics, a.cfg.RetryAttempts) {
						log.Warn().Str("status", "retry_scheduled").Err(err).Msg("verification retry scheduled")
						metrics.end(stageGitHub, start, false)
						return
					}
					item.manifest.Failures = append(item.manifest.Failures, model.RepoFailure{Stage: "safety", Error: err.Error()})
					item.manifest.UpdateStatus.Skipped = true
					item.manifest.UpdateStatus.SkipReason = "repository safety check failed"
					item.manifest.StageResults.DescriptionUpdateSuccess = item.manifest.UpdateStatus.DescriptionUpdated
					item.manifest.StageResults.TopicsUpdateSuccess = item.manifest.UpdateStatus.TopicsUpdated
					item.manifest.Retries = item.retrySummary()
					_ = writer.Update(context.Background(), manifestUpdateFromItem(item))
					metrics.end(stageGitHub, start, true)
					log.Warn().Str("status", "failed").Int64("duration_ms", time.Since(start).Milliseconds()).Err(err).Msg("repository verification failed")
					item.markDone(itemWg)
					return
				}

				retryNeeded := false
				updatedAt := item.manifest.UpdateStatus.UpdatedAt

				if item.updatePlan.allowDescription && !item.manifest.UpdateStatus.DescriptionUpdated {
					updateCtx, updateCancel := context.WithTimeout(context.Background(), a.cfg.RepoTimeout)
					updatedRepo, updateErr := a.github.UpdateDescription(updateCtx, verifiedRepo, item.manifest.GeneratedMetadata.Description)
					updateCancel()
					if updateErr != nil {
						if shouldRetryStage(stop, scheduler, item, stageGitHub, attempt, updateErr, metrics, a.cfg.RetryAttempts) {
							retryNeeded = true
							log.Warn().Str("status", "retry_scheduled").Err(updateErr).Msg("description update retry scheduled")
						} else {
							item.manifest.Failures = append(item.manifest.Failures, model.RepoFailure{Stage: "description_update", Error: updateErr.Error()})
						}
					} else {
						item.manifest.UpdateStatus.DescriptionUpdated = true
						item.manifest.StageResults.DescriptionUpdateSuccess = true
						if updatedRepo != nil {
							item.manifest.Description = strings.TrimSpace(updatedRepo.GetDescription())
						} else {
							item.manifest.Description = strings.TrimSpace(item.manifest.GeneratedMetadata.Description)
						}
						updatedAt = time.Now().UTC()
					}
				}

				if item.updatePlan.allowTopics && !item.manifest.UpdateStatus.TopicsUpdated {
					updateCtx, updateCancel := context.WithTimeout(context.Background(), a.cfg.RepoTimeout)
					updatedTopics, updateErr := a.github.ReplaceTopics(updateCtx, verifiedRepo, item.manifest.GeneratedMetadata.Topics)
					updateCancel()
					if updateErr != nil {
						if shouldRetryStage(stop, scheduler, item, stageGitHub, attempt, updateErr, metrics, a.cfg.RetryAttempts) {
							retryNeeded = true
							log.Warn().Str("status", "retry_scheduled").Err(updateErr).Msg("topics update retry scheduled")
						} else {
							item.manifest.Failures = append(item.manifest.Failures, model.RepoFailure{Stage: "topics_update", Error: updateErr.Error()})
						}
					} else {
						item.manifest.UpdateStatus.TopicsUpdated = true
						item.manifest.StageResults.TopicsUpdateSuccess = true
						item.manifest.Topics = append([]string(nil), updatedTopics...)
						updatedAt = time.Now().UTC()
					}
				}

				item.manifest.UpdateStatus.UpdatedAt = updatedAt
				item.manifest.StageResults.DescriptionUpdateSuccess = item.manifest.UpdateStatus.DescriptionUpdated
				item.manifest.StageResults.TopicsUpdateSuccess = item.manifest.UpdateStatus.TopicsUpdated
				item.manifest.Retries = item.retrySummary()

				_ = writer.Update(context.Background(), manifestUpdateFromItem(item))

				if retryNeeded {
					item.updatePlan.allowDescription = item.updatePlan.allowDescription && !item.manifest.UpdateStatus.DescriptionUpdated
					item.updatePlan.allowTopics = item.updatePlan.allowTopics && !item.manifest.UpdateStatus.TopicsUpdated
					metrics.end(stageGitHub, start, false)
					log.Info().Str("status", "retry_pending").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("update partially applied; retry scheduled")
					return
				}

				metrics.end(stageGitHub, start, false)
				log.Info().Str("status", "completed").Int64("duration_ms", time.Since(start).Milliseconds()).Msg("stage completed")
				item.markDone(itemWg)
			}()
		}
	}
}

func (a *App) handleItemPanic(workerID int, stage string, item *pipelineItem, writer *manifestWriter, itemWg *sync.WaitGroup, panicValue any) {
	repoName := ""
	if item != nil {
		repoName = item.manifest.FullName
	}
	a.logger.Error().Int("worker_id", workerID).Str("repo", repoName).Str("stage", stage).Interface("panic", panicValue).Msg("worker panic recovered")
	if item == nil {
		return
	}
	item.manifest.Failures = append(item.manifest.Failures, model.RepoFailure{Stage: stage, Error: fmt.Sprintf("panic recovered: %v", panicValue)})
	item.manifest.UpdateStatus.Skipped = true
	if item.manifest.UpdateStatus.SkipReason == "" {
		item.manifest.UpdateStatus.SkipReason = "worker panic"
	}
	item.manifest.Retries = item.retrySummary()
	if writer != nil {
		_ = writer.Update(context.Background(), manifestUpdateFromItem(item))
	}
	item.markDone(itemWg)
}

func (a *App) recoverWorker(workerID int, stage string) {
	if r := recover(); r != nil {
		a.logger.Error().Int("worker_id", workerID).Str("stage", stage).Interface("panic", r).Msg("worker panic recovered")
	}
}

func (a *App) stageLogger(workerID int, repo, stage string) zerolog.Logger {
	return a.logger.With().Int("worker_id", workerID).Str("repo", repo).Str("stage", stage).Logger()
}

func repoFullName(repo *github.Repository) string {
	if repo == nil {
		return ""
	}
	return repo.GetFullName()
}

func sendPipelineItem(done <-chan struct{}, out chan<- *pipelineItem, item *pipelineItem) {
	select {
	case <-done:
		return
	case out <- item:
	}
}

func manifestUpdateFromItem(item *pipelineItem) manifestUpdate {
	return manifestUpdate{
		index: item.index,
		apply: func(m *model.RepoManifest) {
			*m = item.manifest
		},
	}
}

func startProgressReporter(ctx context.Context, logger zerolog.Logger, metrics *pipelineMetrics, capacities map[string]int, queueDepth map[string]func() int, state *observability.State, events *observability.Hub) {
	if metrics == nil {
		return
	}
	go func() {
		ticker := time.NewTicker(30 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
			}

			entry := logger.Info()
			queues := make(map[string]int, len(capacities))
			queueCaps := make(map[string]int, len(capacities))
			stageSnapshots := make(map[string]observability.StageSnapshot, len(capacities))
			for stage, capValue := range capacities {
				depthFunc := queueDepth[stage]
				if depthFunc != nil {
					depth := depthFunc()
					queues[stage] = depth
					entry = entry.Int(stage+"_queue_depth", depth)
				}
				if capValue > 0 {
					queueCaps[stage] = capValue
					entry = entry.Int(stage+"_queue_capacity", capValue)
				}
				stats := metrics.stages[stage]
				if stats == nil {
					continue
				}
				processed := atomic.LoadInt64(&stats.processed)
				failed := atomic.LoadInt64(&stats.failed)
				retried := atomic.LoadInt64(&stats.retried)
				active := atomic.LoadInt64(&stats.active)
				totalDuration := atomic.LoadInt64(&stats.durationNanos)
				avgDuration := int64(0)
				if processed > 0 {
					avgDuration = totalDuration / processed
				}
				avgMs := avgDuration / int64(time.Millisecond)
				entry = entry.Int64(stage+"_processed", processed).
					Int64(stage+"_failed", failed).
					Int64(stage+"_retried", retried).
					Int64(stage+"_active", active).
					Int64(stage+"_avg_duration_ms", avgMs)
				stageSnapshots[stage] = observability.StageSnapshot{
					Active:        active,
					Processed:     processed,
					Failed:        failed,
					Retried:       retried,
					AvgDurationMs: avgMs,
				}
			}
			entry.Msg("pipeline progress")

			if state != nil {
				snapshot := observability.PipelineSnapshot{
					Queues:        queues,
					QueueCapacity: queueCaps,
					Stages:        stageSnapshots,
					UpdatedAt:     time.Now().UTC(),
				}
				state.UpdateSnapshot(snapshot)
				if events != nil {
					events.Publish(observability.Event{Type: "pipeline", Payload: snapshot})
				}
			}
		}
	}()
}

func shouldRetryStage(stop <-chan struct{}, scheduler *retryScheduler, item *pipelineItem, stage string, attempt int, err error, metrics *pipelineMetrics, maxAttempts int) bool {
	if err == nil {
		return false
	}
	select {
	case <-stop:
		return false
	default:
	}
	if !retry.IsRetryable(err) {
		return false
	}
	if maxAttempts < 1 {
		maxAttempts = 1
	}
	if attempt >= maxAttempts {
		return false
	}
	delay := retry.Backoff(attempt, err)
	item.recordRetry(stage)
	metrics.retry(stage)
	return scheduler.Schedule(stage, item, delay)
}

func (a *App) buildUpdatePlan(manifest model.RepoManifest) updatePlan {
	repo := manifestRepo(manifest)
	if !a.matchesRepoSelection(repo) {
		return updatePlan{queueable: false, reason: "repository filter mismatch"}
	}
	if !a.allowlisted(repo) || a.blocklisted(repo) {
		return updatePlan{queueable: false, reason: "repository not in allowlist or in blocklist"}
	}
	if a.isLockedRepo(repo) {
		return updatePlan{queueable: false, reason: "repository is locked in local config"}
	}
	if manifest.UpdateStatus.Completed() {
		return updatePlan{queueable: false, reason: "already updated"}
	}
	if manifest.GeneratedMetadata == nil {
		return updatePlan{queueable: false, reason: "missing generated metadata"}
	}

	validation := manifest.GeneratedMetadata.Validation
	descriptionValid := validation.DescriptionValid
	topicsValid := validation.TopicsValid
	if !descriptionValid && !topicsValid && validation.Valid {
		descriptionValid = true
		topicsValid = true
	}
	if !descriptionValid && !topicsValid {
		return updatePlan{queueable: false, reason: "validation produced no valid metadata"}
	}
	if strings.TrimSpace(a.cfg.OnlyLanguage) != "" && !strings.EqualFold(strings.TrimSpace(manifest.PrimaryLanguage), strings.TrimSpace(a.cfg.OnlyLanguage)) {
		return updatePlan{queueable: false, reason: "language filter mismatch"}
	}
	if len(a.cfg.ExcludeTopics) > 0 && hasExcludedTopic(manifest.GeneratedMetadata.Topics, a.cfg.ExcludeTopics) {
		return updatePlan{queueable: false, reason: "excluded topic filter"}
	}

	confidence := validation.Confidence
	if confidence.MetadataConfidence < a.cfg.ConfidenceThreshold && !allowLowConfidenceUpdate(confidence) {
		return updatePlan{queueable: false, reason: confidenceSkipReasonFromManifest(manifest, confidence)}
	}

	descChanged := descriptionChanged(manifest.Description, manifest.GeneratedMetadata.Description)
	topicsChanged := topicsChanged(manifest.Topics, manifest.GeneratedMetadata.Topics)

	allowDescription := descriptionValid && descChanged && !manifest.UpdateStatus.DescriptionUpdated
	allowTopics := topicsValid && topicsChanged && !manifest.UpdateStatus.TopicsUpdated
	if !allowDescription && !allowTopics {
		return updatePlan{queueable: false, reason: "metadata already matches generated output"}
	}

	return updatePlan{allowDescription: allowDescription, allowTopics: allowTopics, queueable: true}
}

func descriptionChanged(current, desired string) bool {
	current = strings.Join(strings.Fields(strings.TrimSpace(current)), " ")
	desired = strings.Join(strings.Fields(strings.TrimSpace(desired)), " ")
	return current != desired
}

func topicsChanged(current, desired []string) bool {
	currentTopics := analysis.NormalizeSuggestion(model.MetadataSuggestion{Topics: current}).Topics
	desiredTopics := analysis.NormalizeSuggestion(model.MetadataSuggestion{Topics: desired}).Topics
	return !sameStringSet(currentTopics, desiredTopics)
}
