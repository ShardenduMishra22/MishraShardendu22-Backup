package app

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"go-description-script/internal/analysis"
	"go-description-script/internal/model"

	"github.com/google/go-github/v86/github"
)

func (a *App) ExecuteRepoAction(ctx context.Context, repoFullName, action, mode string) (map[string]any, error) {
	manifest, entry, err := a.loadRepoManifestEntry(repoFullName)
	if err != nil {
		return nil, err
	}
	if strings.TrimSpace(action) == "" {
		return nil, errors.New("action is required")
	}
	if strings.TrimSpace(mode) == "" {
		mode = "preview"
	}
	repo := repoFromManifest(entry)
	repoAnalysis := analysisFromManifest(entry)
	preview := analysis.GenerateReadme(entry.ReadmeContent, repoAnalysis, entry)
	result := map[string]any{
		"repo":             entry.FullName,
		"action":           action,
		"mode":             mode,
		"preview":          preview,
		"manifest_updated": false,
	}

	switch strings.ToLower(strings.TrimSpace(action)) {
	case "preview", "view_diff":
		return result, nil
	case "generate_readme", "enhance_readme":
		return a.applyReadmeAction(ctx, manifest, entry, repo, preview, mode, result)
	case "regenerate_description", "regenerate_topics":
		return a.applyMetadataAction(ctx, manifest, entry, repo, action, result)
	case "rollback":
		return a.rollbackRepoAction(ctx, manifest, entry, repo, result)
	case "retry":
		if err := a.StartBackgroundPipeline(PipelineRunOptions{Selection: []string{entry.FullName}, Mode: "retry", Reason: "repo retry"}); err != nil {
			return nil, err
		}
		result["queued"] = true
		return result, nil
	default:
		return nil, repoActionError(action, entry.FullName)
	}
}

func (a *App) loadRepoManifestEntry(fullName string) (model.ManifestFile, model.RepoManifest, error) {
	manifestPath := strings.TrimSpace(a.cfg.ManifestFile)
	if manifestPath == "" {
		return model.ManifestFile{}, model.RepoManifest{}, errors.New("manifest file is not configured")
	}
	manifest, err := loadManifestFile(manifestPath)
	if err != nil {
		return model.ManifestFile{}, model.RepoManifest{}, err
	}
	for _, entry := range manifest.Repositories {
		if strings.EqualFold(entry.FullName, strings.TrimSpace(fullName)) {
			return manifest, entry, nil
		}
	}
	return model.ManifestFile{}, model.RepoManifest{}, fmt.Errorf("repository %s not found in manifest", fullName)
}

func (a *App) applyReadmeAction(ctx context.Context, manifest model.ManifestFile, entry model.RepoManifest, repo *github.Repository, preview analysis.ReadmePreview, mode string, result map[string]any) (map[string]any, error) {
	backupPath, err := a.writeReadmeBackup(entry, preview.Current)
	if err != nil {
		return nil, err
	}
	if strings.EqualFold(mode, "preview") || strings.EqualFold(mode, "dry-run") {
		result["backup_path"] = backupPath
		result["dry_run"] = true
		result["generated_readme"] = preview.Generated
		result["backup_path"] = backupPath
		return result, nil
	}
	if a.github == nil {
		return nil, errors.New("github client is not configured")
	}
	path, err := a.github.UpdateReadme(ctx, repo, preview.Generated, "docs: update README")
	if err != nil {
		return nil, err
	}
	entry.BackupPath = backupPath
	entry.Documentation = model.DocumentationState{
		ReadmeGenerationState:        "applied",
		DocumentationGenerationState: "applied",
		CurrentReadme:                preview.Current,
		GeneratedReadme:              preview.Generated,
		CurrentQualityScore:          preview.QualityScore,
		PreviewOnly:                  false,
		SectionChanges:               preview.SectionChanges,
		GeneratedAt:                  time.Now().UTC(),
		AppliedAt:                    time.Now().UTC(),
		Diff:                         preview.Diff,
	}
	entry.FileWriteResults = append(entry.FileWriteResults, model.FileWriteResult{Path: path, BackupPath: backupPath, Status: "written", WrittenAt: time.Now().UTC()})
	entry.BackupPath = backupPath
	entry.OriginalDescription = entry.Description
	entry.OriginalTopics = append([]string(nil), entry.Topics...)
	result["backup_path"] = backupPath
	result["generated_readme"] = preview.Generated
	result["path"] = path
	result["manifest_updated"] = true
	if err := a.updateRepoManifest(manifest, entry); err != nil {
		return nil, err
	}
	return result, nil
}

func (a *App) writeReadmeBackup(entry model.RepoManifest, content string) (string, error) {
	root := filepath.Join(filepath.Dir(strings.TrimSpace(a.cfg.ManifestFile)), ".readme-backups")
	if strings.TrimSpace(root) == "" || root == ".readme-backups" {
		root = ".readme-backups"
	}
	if err := os.MkdirAll(root, 0o755); err != nil {
		return "", err
	}
	fileName := strings.ReplaceAll(strings.TrimSpace(entry.FullName), "/", "__")
	if fileName == "" {
		fileName = "repo"
	}
	backupPath := filepath.Join(root, fmt.Sprintf("%s-%d.md", fileName, time.Now().UTC().UnixNano()))
	if err := os.WriteFile(backupPath, []byte(content), 0o644); err != nil {
		return "", err
	}
	return backupPath, nil
}

func (a *App) applyMetadataAction(ctx context.Context, manifest model.ManifestFile, entry model.RepoManifest, repo *github.Repository, action string, result map[string]any) (map[string]any, error) {
	if a.github == nil {
		return nil, errors.New("github client is not configured")
	}
	if repo == nil {
		repo = repoFromManifest(entry)
	}
	entry.OriginalDescription = entry.Description
	entry.OriginalTopics = append([]string(nil), entry.Topics...)
	preview := analysis.GenerateReadme(entry.ReadmeContent, analysisFromManifest(entry), entry)
	if strings.EqualFold(action, "regenerate_description") {
		entry.Description = descriptionFromPreview(preview.Generated, entry.Description)
	}
	if strings.EqualFold(action, "regenerate_topics") {
		entry.Topics = topicsFromPreview(preview.Generated, entry.Topics)
	}
	if _, err := a.github.UpdateMetadata(ctx, repo, entry.Description, entry.Topics); err != nil {
		return nil, err
	}
	result["manifest_updated"] = true
	result["description"] = entry.Description
	result["topics"] = entry.Topics
	entry.Documentation = model.DocumentationState{
		ReadmeGenerationState:        "metadata-applied",
		DocumentationGenerationState: "metadata-applied",
		CurrentReadme:                entry.ReadmeContent,
		GeneratedReadme:              preview.Generated,
		CurrentQualityScore:          preview.QualityScore,
		PreviewOnly:                  false,
		SectionChanges:               preview.SectionChanges,
		GeneratedAt:                  time.Now().UTC(),
		Diff:                         preview.Diff,
	}
	if err := a.updateRepoManifest(manifest, entry); err != nil {
		return nil, err
	}
	return result, nil
}

func (a *App) rollbackRepoAction(ctx context.Context, manifest model.ManifestFile, entry model.RepoManifest, repo *github.Repository, result map[string]any) (map[string]any, error) {
	if a.github == nil {
		return nil, errors.New("github client is not configured")
	}
	if repo == nil {
		repo = repoFromManifest(entry)
	}
	if strings.TrimSpace(entry.BackupPath) != "" {
		content, err := os.ReadFile(filepath.Clean(entry.BackupPath))
		if err == nil {
			if _, err := a.github.UpdateReadme(ctx, repo, string(content), "docs: rollback README"); err != nil {
				return nil, err
			}
		}
	}
	if strings.TrimSpace(entry.OriginalDescription) != "" || len(entry.OriginalTopics) > 0 {
		if _, err := a.github.UpdateMetadata(ctx, repo, entry.OriginalDescription, entry.OriginalTopics); err != nil {
			return nil, err
		}
	}
	entry.RollbackStatus = model.RollbackState{Completed: true, RolledBackAt: time.Now().UTC(), BackupPath: entry.BackupPath}
	entry.Documentation = model.DocumentationState{ReadmeGenerationState: "rolled-back", DocumentationGenerationState: "rolled-back", CurrentReadme: entry.ReadmeContent, GeneratedAt: time.Now().UTC(), AppliedAt: time.Now().UTC()}
	result["rollback"] = true
	result["manifest_updated"] = true
	if err := a.updateRepoManifest(manifest, entry); err != nil {
		return nil, err
	}
	return result, nil
}

func (a *App) updateRepoManifest(manifest model.ManifestFile, updated model.RepoManifest) error {
	manifestPath := strings.TrimSpace(a.cfg.ManifestFile)
	if manifestPath == "" {
		return nil
	}
	for index := range manifest.Repositories {
		if strings.EqualFold(manifest.Repositories[index].FullName, updated.FullName) {
			manifest.Repositories[index] = updated
			return saveManifestFile(manifestPath, &manifest)
		}
	}
	return nil
}

func analysisFromManifest(entry model.RepoManifest) model.RepoAnalysis {
	return model.RepoAnalysis{
		Name:              entry.Name,
		FullName:          entry.FullName,
		Description:       entry.Description,
		PrimaryLanguage:   entry.PrimaryLanguage,
		ProjectCategory:   "repository",
		ArchitectureStyle: "unknown",
		EngineeringDomain: "general software",
		DeploymentModel:   "unknown",
		ProjectIntent:     "repository documentation",
		BackendFrontend:   "unknown",
		Frameworks:        append([]string(nil), entry.DetectedFrameworks...),
		Infrastructure:    append([]string(nil), entry.DetectedTech...),
		InfraStack:        append([]string(nil), entry.DetectedTech...),
		APIs:              nil,
		ImportantFiles:    importantFilesFromPaths(entry.ImportantFiles),
	}
}

func repoFromManifest(entry model.RepoManifest) *github.Repository {
	return &github.Repository{Owner: &github.User{Login: github.Ptr(entry.Owner)}, Name: github.Ptr(entry.Name), FullName: github.Ptr(entry.FullName)}
}

func importantFilesFromPaths(paths []string) []model.ImportantFile {
	files := make([]model.ImportantFile, 0, len(paths))
	for _, path := range paths {
		candidate := strings.TrimSpace(path)
		if candidate == "" {
			continue
		}
		files = append(files, model.ImportantFile{Path: candidate, Summary: candidate})
	}
	return files
}

func descriptionFromPreview(generated, fallback string) string {
	for _, line := range strings.Split(generated, "\n") {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "#") || strings.HasPrefix(trimmed, "##") || trimmed == "" {
			continue
		}
		if len(trimmed) > 0 {
			return trimmed
		}
	}
	return fallback
}

func topicsFromPreview(generated string, fallback []string) []string {
	topics := make([]string, 0, len(fallback))
	for _, line := range strings.Split(generated, "\n") {
		trimmed := strings.TrimSpace(line)
		if !strings.HasPrefix(trimmed, "- ") {
			continue
		}
		value := strings.TrimSpace(strings.TrimPrefix(trimmed, "- "))
		if value != "" {
			topics = append(topics, strings.ToLower(strings.ReplaceAll(value, " ", "-")))
		}
	}
	if len(topics) == 0 {
		return fallback
	}
	return topics
}
