package app

import (
	"testing"

	"go-description-script/internal/model"
)

func TestAllowLowConfidenceUpdate(t *testing.T) {
	t.Parallel()

	if !allowLowConfidenceUpdate(model.ConfidenceScore{TechnologyAccuracy: 0.86}) {
		t.Fatal("allowLowConfidenceUpdate returned false for strong technology detection")
	}
	if allowLowConfidenceUpdate(model.ConfidenceScore{TechnologyAccuracy: 0.85}) {
		t.Fatal("allowLowConfidenceUpdate returned true at the cutoff")
	}
}

func TestConfidenceSkipReason(t *testing.T) {
	t.Parallel()

	if got := confidenceSkipReason(model.RepoSnapshot{README: ""}, model.ConfidenceScore{}); got != "low README quality" {
		t.Fatalf("confidenceSkipReason returned %q, want %q", got, "low README quality")
	}
	if got := confidenceSkipReason(model.RepoSnapshot{README: "This repository contains a clearly documented command line utility with examples, usage notes, installation steps, release information, and a small troubleshooting guide for contributors.", Files: map[string]string{"go.mod": "module example\n"}}, model.ConfidenceScore{TechnologyAccuracy: 0.4}); got != "insufficient source structure" {
		t.Fatalf("confidenceSkipReason returned %q, want %q", got, "insufficient source structure")
	}
}
