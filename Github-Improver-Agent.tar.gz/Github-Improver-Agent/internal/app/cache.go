package app

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"go-description-script/internal/model"
)

type metadataCache struct {
	mu      sync.RWMutex
	path    string
	dirty   bool
	entries map[string]metadataCacheEntry
}

type metadataCacheFile struct {
	Version int                           `json:"version"`
	Entries map[string]metadataCacheEntry `json:"entries"`
}

type metadataCacheEntry struct {
	ReadmeHash       string          `json:"readme_hash"`
	CommitSHA        string          `json:"commit_sha"`
	Description      string          `json:"description"`
	Topics           []string        `json:"topics"`
	ReasoningDetails json.RawMessage `json:"reasoning_details,omitempty"`
	Confidence       float64         `json:"confidence"`
	UpdatedAt        time.Time       `json:"updated_at"`
}

func loadMetadataCache(path string) (*metadataCache, error) {
	cache := &metadataCache{
		path:    path,
		entries: make(map[string]metadataCacheEntry),
	}

	if strings.TrimSpace(path) == "" {
		return cache, nil
	}

	content, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return cache, nil
		}
		return nil, err
	}

	var file metadataCacheFile
	if err := json.Unmarshal(content, &file); err != nil {
		return nil, err
	}
	if file.Entries != nil {
		cache.entries = file.Entries
	}
	return cache, nil
}

func (c *metadataCache) Lookup(fullName string, snapshotReadmeHash string, commitSHA string) (model.MetadataSuggestion, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	entry, ok := c.entries[cacheKey(fullName)]
	if !ok {
		return model.MetadataSuggestion{}, false
	}
	if strings.TrimSpace(entry.ReadmeHash) != strings.TrimSpace(snapshotReadmeHash) {
		return model.MetadataSuggestion{}, false
	}
	if strings.TrimSpace(entry.CommitSHA) != strings.TrimSpace(commitSHA) {
		return model.MetadataSuggestion{}, false
	}
	return model.MetadataSuggestion{
		Description:      entry.Description,
		Topics:           append([]string(nil), entry.Topics...),
		ReasoningDetails: append(json.RawMessage(nil), entry.ReasoningDetails...),
	}, true
}

func (c *metadataCache) Store(fullName string, snapshotReadmeHash string, commitSHA string, suggestion model.MetadataSuggestion, confidence float64) {
	if c == nil {
		return
	}
	c.mu.Lock()
	defer c.mu.Unlock()

	c.entries[cacheKey(fullName)] = metadataCacheEntry{
		ReadmeHash:       snapshotReadmeHash,
		CommitSHA:        commitSHA,
		Description:      suggestion.Description,
		Topics:           append([]string(nil), suggestion.Topics...),
		ReasoningDetails: append(json.RawMessage(nil), suggestion.ReasoningDetails...),
		Confidence:       confidence,
		UpdatedAt:        time.Now().UTC(),
	}
	c.dirty = true
}

func (c *metadataCache) Save() error {
	if c == nil || strings.TrimSpace(c.path) == "" {
		return nil
	}

	c.mu.RLock()
	dirty := c.dirty
	entries := make(map[string]metadataCacheEntry, len(c.entries))
	for key, entry := range c.entries {
		entries[key] = entry
	}
	c.mu.RUnlock()

	if !dirty {
		return nil
	}

	payload := metadataCacheFile{
		Version: 1,
		Entries: entries,
	}
	content, err := json.MarshalIndent(payload, "", "  ")
	if err != nil {
		return err
	}

	if err := os.MkdirAll(filepath.Dir(c.path), 0o755); err != nil && filepath.Dir(c.path) != "." {
		return err
	}

	tempPath := c.path + ".tmp"
	if err := os.WriteFile(tempPath, content, 0o644); err != nil {
		return err
	}
	if err := os.Rename(tempPath, c.path); err != nil {
		return err
	}

	c.mu.Lock()
	c.dirty = false
	c.mu.Unlock()
	return nil
}

func cacheKey(fullName string) string {
	return strings.ToLower(strings.TrimSpace(fullName))
}
