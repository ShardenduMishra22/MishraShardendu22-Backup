package app

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"go-description-script/internal/analysis"
	"go-description-script/internal/model"

	"github.com/google/go-github/v86/github"
)

const manifestVersion = 1

type discoveryJob struct {
	index int
	repo  *github.Repository
}

type discoveryResult struct {
	index    int
	manifest model.RepoManifest
}

type updateJob struct {
	index    int
	manifest model.RepoManifest
}

type updateResult struct {
	index    int
	manifest model.RepoManifest
}

type manifestPreview struct {
	Repo                 string   `json:"repo"`
	DetectedTech         []string `json:"detected_tech"`
	Confidence           float64  `json:"confidence"`
	GeneratedDescription string   `json:"generated_description"`
	GeneratedTopics      []string `json:"generated_topics"`
}

type queueDecision struct {
	queueable       bool
	reason          string
	validationIssue bool
}

func (a *App) runPipeline(ctx context.Context) error {
	if err := a.validatePipelineMode(); err != nil {
		return err
	}

	if a.cache != nil {
		defer func() {
			if err := a.cache.Save(); err != nil {
				a.logger.Error().Err(err).Msg("failed to save metadata cache")
			}
		}()
	}

	previewOnly := a.cfg.PreviewOnly || a.cfg.DryRun
	if applyManifest := strings.TrimSpace(a.cfg.ApplyManifest); applyManifest != "" {
		manifest, err := loadManifestFile(applyManifest)
		if err != nil {
			return err
		}
		return a.runStagedUpdate(ctx, &manifest, applyManifest, previewOnly)
	}

	if err := a.requireDiscoveryCredentials(); err != nil {
		return err
	}

	repos, err := a.github.ListRepositories(ctx)
	if err != nil {
		return err
	}

	filtered := a.filterRepositories(repos)
	if len(filtered) == 0 {
		a.logger.Info().Msg("no repositories matched the configured filters")
		return nil
	}

	if a.cfg.Limit > 0 && len(filtered) > a.cfg.Limit {
		filtered = filtered[:a.cfg.Limit]
	}

	manifestPath := strings.TrimSpace(a.cfg.ManifestFile)
	a.logger.Info().
		Int("repositories", len(filtered)).
		Int("analysis_workers", a.cfg.Workers).
		Int("llm_workers", a.cfg.LLMWorkers).
		Int("github_workers", a.cfg.GitHubWorkers).
		Bool("dry_run", a.cfg.DryRun).
		Bool("preview_only", previewOnly).
		Bool("generate_manifest", a.cfg.GenerateManifest).
		Str("manifest_file", manifestPath).
		Float64("confidence_threshold", a.cfg.ConfidenceThreshold).
		Str("confidence_mode", a.cfg.ConfidenceMode).
		Strs("openrouter_models", a.cfg.OpenRouterModels).
		Int("openrouter_keys", len(a.cfg.OpenRouterAPIKeys)).
		Msg("manifest generation started")

	manifest, err := a.runStagedDiscovery(ctx, filtered, manifestPath, previewOnly)
	if err != nil {
		return err
	}

	if a.cfg.GenerateManifest || previewOnly {
		a.printManifestPreview(manifest.Repositories)
		return nil
	}

	return a.runStagedUpdate(ctx, &manifest, manifestPath, previewOnly)
}

func (a *App) validatePipelineMode() error {
	if a.cfg.GenerateManifest && strings.TrimSpace(a.cfg.ApplyManifest) != "" {
		return errors.New("--generate-manifest and --apply-manifest cannot be used together")
	}
	return nil
}

func (a *App) requireDiscoveryCredentials() error {
	if strings.TrimSpace(a.cfg.GitHubToken) == "" {
		return errors.New("missing GITHUB_TOKEN for repository discovery")
	}
	if len(a.cfg.OpenRouterAPIKeys) == 0 && strings.TrimSpace(a.cfg.OpenRouterAPIKey) == "" {
		return errors.New("missing OPENROUTER_API_KEY or OPENROUTER_API_KEYS for manifest generation")
	}
	return nil
}

func (a *App) requireUpdateCredentials() error {
	if strings.TrimSpace(a.cfg.GitHubToken) == "" {
		return errors.New("missing GITHUB_TOKEN for manifest update")
	}
	return nil
}

func (a *App) runDiscoveryPhase(ctx context.Context, repos []*github.Repository, manifestPath string) (model.ManifestFile, error) {
	manifest := model.ManifestFile{
		Version:      manifestVersion,
		GeneratedAt:  time.Now().UTC(),
		Repositories: make([]model.RepoManifest, len(repos)),
	}

	for index, repo := range repos {
		manifest.Repositories[index] = newRepoManifest(repo)
	}

	jobs := make(chan discoveryJob)
	results := make(chan discoveryResult)

	var wg sync.WaitGroup
	for workerID := 0; workerID < a.cfg.Workers; workerID++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for job := range jobs {
				results <- discoveryResult{
					index:    job.index,
					manifest: a.buildRepoManifest(ctx, job.repo),
				}
			}
		}()
	}

	go func() {
		wg.Wait()
		close(results)
	}()

	go func() {
		defer close(jobs)
		for index, repo := range repos {
			select {
			case <-ctx.Done():
				return
			case jobs <- discoveryJob{index: index, repo: repo}:
			}
		}
	}()

	processed := 0
	failedRepos := 0
	validationFailures := 0
	var saveErr error

	for result := range results {
		manifest.Repositories[result.index] = result.manifest
		processed++
		if len(result.manifest.Failures) > 0 {
			failedRepos++
			for _, failure := range result.manifest.Failures {
				if strings.EqualFold(failure.Stage, "validation") {
					validationFailures++
				}
				a.logger.Warn().
					Str("repo", result.manifest.FullName).
					Str("stage", failure.Stage).
					Str("error", failure.Error).
					Msg("manifest generation failure")
			}
		}

		if saveErr == nil && strings.TrimSpace(manifestPath) != "" {
			if err := saveManifestFile(manifestPath, &manifest); err != nil {
				saveErr = err
			}
		}
	}

	if saveErr != nil {
		return model.ManifestFile{}, saveErr
	}
	if err := ctx.Err(); err != nil {
		return model.ManifestFile{}, err
	}

	a.logger.Info().
		Int("repositories", len(manifest.Repositories)).
		Int("processed", processed).
		Int("failed_repositories", failedRepos).
		Int("validation_failures", validationFailures).
		Str("manifest_file", manifestPath).
		Msg("manifest generation completed")

	return manifest, nil
}

func (a *App) runUpdatePhase(ctx context.Context, manifest *model.ManifestFile, manifestPath string, previewOnly bool) error {
	if manifest == nil {
		return errors.New("manifest is required for the update phase")
	}

	queue, skippedCount, validationFailures := a.buildUpdateQueue(manifest.Repositories)
	if a.cfg.Limit > 0 && len(queue) > a.cfg.Limit {
		queue = queue[:a.cfg.Limit]
	}
	a.logger.Info().
		Int("queued_repo_count", len(queue)).
		Int("skipped_repo_count", skippedCount).
		Int("validation_failures", validationFailures).
		Str("manifest_file", manifestPath).
		Msg("update queue created")

	a.printManifestPreviewFromQueue(queue)

	if previewOnly {
		if strings.TrimSpace(manifestPath) != "" {
			if err := saveManifestFile(manifestPath, manifest); err != nil {
				return err
			}
		}
		return nil
	}

	if err := a.requireUpdateCredentials(); err != nil {
		return err
	}

	if len(queue) == 0 {
		if strings.TrimSpace(manifestPath) != "" {
			if err := saveManifestFile(manifestPath, manifest); err != nil {
				return err
			}
		}
		a.logger.Info().Msg("no repositories qualified for the update phase")
		return nil
	}

	jobs := make(chan updateJob)
	results := make(chan updateResult)

	var wg sync.WaitGroup
	for workerID := 0; workerID < a.cfg.Workers; workerID++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for job := range jobs {
				results <- updateResult{
					index:    job.index,
					manifest: a.applyManifestEntry(ctx, job.manifest),
				}
			}
		}()
	}

	go func() {
		wg.Wait()
		close(results)
	}()

	go func() {
		defer close(jobs)
		for _, job := range queue {
			select {
			case <-ctx.Done():
				return
			case jobs <- job:
			}
		}
	}()

	successfulUpdates := 0
	partialUpdates := 0
	failedUpdates := 0
	var saveErr error

	for result := range results {
		manifest.Repositories[result.index] = result.manifest
		status := result.manifest.UpdateStatus
		switch {
		case status.DescriptionUpdated && status.TopicsUpdated:
			successfulUpdates++
		case status.DescriptionUpdated || status.TopicsUpdated:
			partialUpdates++
		default:
			failedUpdates++
		}

		a.logUpdateResult(result.manifest)

		if saveErr == nil && strings.TrimSpace(manifestPath) != "" {
			if err := saveManifestFile(manifestPath, manifest); err != nil {
				saveErr = err
			}
		}
	}

	if saveErr != nil {
		return saveErr
	}
	if err := ctx.Err(); err != nil {
		return err
	}

	a.logger.Info().
		Int("queued_repo_count", len(queue)).
		Int("skipped_repo_count", skippedCount).
		Int("successful_updates", successfulUpdates).
		Int("partial_updates", partialUpdates).
		Int("failed_updates", failedUpdates).
		Str("manifest_file", manifestPath).
		Msg("metadata update phase completed")

	return nil
}

func (a *App) buildRepoManifest(parent context.Context, repo *github.Repository) model.RepoManifest {
	manifest := newRepoManifest(repo)
	if repo == nil {
		manifest.Failures = append(manifest.Failures, model.RepoFailure{Stage: "snapshot", Error: "repository was nil"})
		manifest.UpdateStatus.Skipped = true
		manifest.UpdateStatus.SkipReason = "repository was nil"
		return manifest
	}
	if a.isLockedRepo(repo) {
		manifest.UpdateStatus.Skipped = true
		manifest.UpdateStatus.SkipReason = "repository is locked in local config"
		return manifest
	}

	repoCtx, cancel := context.WithTimeout(parent, a.cfg.RepoTimeout)
	defer cancel()

	snapshot, err := a.github.ReadSnapshot(repoCtx, repo)
	if err != nil {
		manifest.Failures = append(manifest.Failures, model.RepoFailure{Stage: "snapshot", Error: err.Error()})
		manifest.UpdateStatus.Skipped = true
		manifest.UpdateStatus.SkipReason = "snapshot failed"
		return manifest
	}

	repoAnalysis := a.analyzer.Analyze(repo, snapshot)
	manifest.Owner = repoAnalysis.Owner
	manifest.Name = repoAnalysis.Name
	manifest.FullName = repoAnalysis.FullName
	manifest.CloneURL = repo.GetCloneURL()
	manifest.DefaultBranch = repoAnalysis.DefaultBranch
	manifest.PrimaryLanguage = repoAnalysis.PrimaryLanguage
	manifest.Description = strings.TrimSpace(repoAnalysis.Description)
	manifest.Topics = analysis.NormalizeSuggestion(model.MetadataSuggestion{Topics: snapshot.ExistingTopics}).Topics
	manifest.ReadmeContent = snapshot.README
	manifest.DetectedTech = append([]string(nil), repoAnalysis.DetectedTechnologies...)
	manifest.DetectedFrameworks = append([]string(nil), repoAnalysis.Frameworks...)
	manifest.ImportantFiles = importantFilePaths(repoAnalysis.ImportantFiles)
	prompt := analysis.BuildPrompt(repoAnalysis)

	suggestion, cacheHit, err := a.loadSuggestion(repoCtx, repoAnalysis, snapshot, prompt)
	if err != nil {
		manifest.Failures = append(manifest.Failures, model.RepoFailure{Stage: "generation", Error: err.Error()})
		manifest.UpdateStatus.Skipped = true
		manifest.UpdateStatus.SkipReason = "generation failed"
		return manifest
	}

	validated, err := analysis.ValidateMetadata(repoAnalysis, snapshot, suggestion)
	if err != nil {
		fallback := analysis.FallbackSuggestion(repoAnalysis)
		validated, err = analysis.ValidateMetadata(repoAnalysis, snapshot, fallback)
		if err != nil {
			manifest.GeneratedMetadata = &model.GeneratedMetadata{
				Description:     fallback.Description,
				Topics:          append([]string(nil), fallback.Topics...),
				ConfidenceScore: 0,
				Validation: model.ValidationSummary{
					Valid:                false,
					Error:                err.Error(),
					CurrentDescription:   strings.TrimSpace(repoAnalysis.Description),
					CurrentTopics:        analysis.NormalizeSuggestion(model.MetadataSuggestion{Topics: snapshot.ExistingTopics}).Topics,
					GeneratedDescription: strings.TrimSpace(fallback.Description),
					GeneratedTopics:      append([]string(nil), fallback.Topics...),
					CacheHit:             cacheHit,
				},
				CacheHit: cacheHit,
			}
			manifest.Failures = append(manifest.Failures, model.RepoFailure{Stage: "validation", Error: err.Error()})
			manifest.UpdateStatus.Skipped = true
			manifest.UpdateStatus.SkipReason = "validation failed"
			return manifest
		}
	}

	if a.cache != nil {
		a.cache.Store(repoAnalysis.FullName, snapshot.ReadmeHash, snapshot.CommitSHA, validated.Suggestion, validated.Confidence.MetadataConfidence)
	}

	manifest.ConfidenceScore = validated.Confidence.MetadataConfidence
	manifest.GeneratedMetadata = &model.GeneratedMetadata{
		Description:     validated.Suggestion.Description,
		Topics:          append([]string(nil), validated.Suggestion.Topics...),
		ConfidenceScore: validated.Confidence.MetadataConfidence,
		Validation: model.ValidationSummary{
			Valid:                true,
			CurrentDescription:   validated.CurrentDescription,
			CurrentTopics:        append([]string(nil), validated.CurrentTopics...),
			GeneratedDescription: validated.GeneratedDescription,
			GeneratedTopics:      append([]string(nil), validated.GeneratedTopics...),
			AddedTopics:          append([]string(nil), validated.AddedTopics...),
			RemovedTopics:        append([]string(nil), validated.RemovedTopics...),
			AllowedTopics:        append([]string(nil), validated.AllowedTopics...),
			Confidence:           validated.Confidence,
			ConfidenceThreshold:  a.cfg.ConfidenceThreshold,
			CacheHit:             cacheHit,
		},
		CacheHit: cacheHit,
	}

	return manifest
}

func (a *App) applyManifestEntry(parent context.Context, manifest model.RepoManifest) model.RepoManifest {
	if manifest.GeneratedMetadata == nil {
		manifest.Failures = append(manifest.Failures, model.RepoFailure{Stage: "preflight", Error: "missing generated metadata"})
		manifest.UpdateStatus.Skipped = true
		manifest.UpdateStatus.SkipReason = "missing generated metadata"
		return manifest
	}

	if manifest.GeneratedMetadata.Validation.Valid == false {
		manifest.UpdateStatus.Skipped = true
		if manifest.UpdateStatus.SkipReason == "" {
			manifest.UpdateStatus.SkipReason = "validation failed"
		}
		return manifest
	}

	if manifest.UpdateStatus.Completed() {
		manifest.UpdateStatus.Skipped = true
		manifest.UpdateStatus.SkipReason = "already updated"
		return manifest
	}

	repoCtx, cancel := context.WithTimeout(parent, a.cfg.RepoTimeout)
	defer cancel()

	verifiedRepo, err := a.github.VerifyRepository(repoCtx, manifest.Owner, manifest.Name)
	if err != nil {
		manifest.Failures = append(manifest.Failures, model.RepoFailure{Stage: "safety", Error: err.Error()})
		manifest.UpdateStatus.Skipped = true
		manifest.UpdateStatus.SkipReason = "repository safety check failed"
		return manifest
	}

	if !manifest.UpdateStatus.DescriptionUpdated {
		updatedRepo, err := a.github.UpdateDescription(repoCtx, verifiedRepo, manifest.GeneratedMetadata.Description)
		if err != nil {
			manifest.Failures = append(manifest.Failures, model.RepoFailure{Stage: "description_update", Error: err.Error()})
		} else {
			manifest.UpdateStatus.DescriptionUpdated = true
			if updatedRepo != nil {
				manifest.Description = strings.TrimSpace(updatedRepo.GetDescription())
			} else {
				manifest.Description = strings.TrimSpace(manifest.GeneratedMetadata.Description)
			}
			manifest.UpdateStatus.UpdatedAt = time.Now().UTC()
		}
	}

	if !manifest.UpdateStatus.TopicsUpdated {
		updatedTopics, err := a.github.ReplaceTopics(repoCtx, verifiedRepo, manifest.GeneratedMetadata.Topics)
		if err != nil {
			manifest.Failures = append(manifest.Failures, model.RepoFailure{Stage: "topics_update", Error: err.Error()})
		} else {
			manifest.UpdateStatus.TopicsUpdated = true
			manifest.Topics = append([]string(nil), updatedTopics...)
			manifest.UpdateStatus.UpdatedAt = time.Now().UTC()
		}
	}

	return manifest
}

func (a *App) buildUpdateQueue(manifests []model.RepoManifest) ([]updateJob, int, int) {
	queue := make([]updateJob, 0, len(manifests))
	skipped := 0
	validationFailures := 0

	for index := range manifests {
		manifest := &manifests[index]
		decision := a.shouldQueueManifest(*manifest)
		if !decision.queueable {
			skipped++
			if decision.validationIssue {
				validationFailures++
			}
			if manifest.UpdateStatus.SkipReason == "" {
				manifest.UpdateStatus.Skipped = true
				manifest.UpdateStatus.SkipReason = decision.reason
			}
			continue
		}

		queue = append(queue, updateJob{index: index, manifest: *manifest})
	}

	return queue, skipped, validationFailures
}

func (a *App) shouldQueueManifest(manifest model.RepoManifest) queueDecision {
	repo := manifestRepo(manifest)
	if !a.matchesRepoSelection(repo) {
		return queueDecision{queueable: false, reason: "repository filter mismatch"}
	}
	if !a.allowlisted(repo) || a.blocklisted(repo) {
		return queueDecision{queueable: false, reason: "repository not in allowlist or in blocklist"}
	}
	if a.isLockedRepo(repo) {
		return queueDecision{queueable: false, reason: "repository is locked in local config"}
	}
	if manifest.UpdateStatus.Completed() {
		return queueDecision{queueable: false, reason: "already updated"}
	}
	if manifest.GeneratedMetadata == nil {
		return queueDecision{queueable: false, reason: "missing generated metadata"}
	}
	if !manifest.GeneratedMetadata.Validation.Valid {
		if strings.TrimSpace(manifest.GeneratedMetadata.Validation.Error) != "" {
			return queueDecision{queueable: false, reason: "validation failed: " + manifest.GeneratedMetadata.Validation.Error, validationIssue: true}
		}
		return queueDecision{queueable: false, reason: "validation failed", validationIssue: true}
	}
	if strings.TrimSpace(a.cfg.OnlyLanguage) != "" && !strings.EqualFold(strings.TrimSpace(manifest.PrimaryLanguage), strings.TrimSpace(a.cfg.OnlyLanguage)) {
		return queueDecision{queueable: false, reason: "language filter mismatch"}
	}
	if len(a.cfg.ExcludeTopics) > 0 && hasExcludedTopic(manifest.GeneratedMetadata.Topics, a.cfg.ExcludeTopics) {
		return queueDecision{queueable: false, reason: "excluded topic filter"}
	}

	confidence := manifest.GeneratedMetadata.Validation.Confidence
	if confidence.MetadataConfidence < a.cfg.ConfidenceThreshold && !allowLowConfidenceUpdate(confidence) {
		return queueDecision{queueable: false, reason: confidenceSkipReasonFromManifest(manifest, confidence)}
	}

	if !metadataChangedFromManifest(manifest) {
		return queueDecision{queueable: false, reason: "metadata already matches generated output"}
	}

	return queueDecision{queueable: true}
}

func (a *App) printManifestPreview(manifests []model.RepoManifest) {
	for _, manifest := range manifests {
		if manifest.GeneratedMetadata == nil {
			continue
		}
		preview := manifestPreview{
			Repo:                 manifest.FullName,
			DetectedTech:         append([]string(nil), manifest.DetectedTech...),
			Confidence:           manifest.ConfidenceScore,
			GeneratedDescription: manifest.GeneratedMetadata.Description,
			GeneratedTopics:      append([]string(nil), manifest.GeneratedMetadata.Topics...),
		}
		content, err := json.Marshal(preview)
		if err != nil {
			a.logger.Warn().Err(err).Str("repo", manifest.FullName).Msg("failed to marshal manifest preview")
			continue
		}
		fmt.Fprintln(os.Stdout, string(content))
	}
}

func (a *App) printManifestPreviewFromQueue(queue []updateJob) {
	for _, job := range queue {
		if job.manifest.GeneratedMetadata == nil {
			continue
		}
		preview := manifestPreview{
			Repo:                 job.manifest.FullName,
			DetectedTech:         append([]string(nil), job.manifest.DetectedTech...),
			Confidence:           job.manifest.ConfidenceScore,
			GeneratedDescription: job.manifest.GeneratedMetadata.Description,
			GeneratedTopics:      append([]string(nil), job.manifest.GeneratedMetadata.Topics...),
		}
		content, err := json.Marshal(preview)
		if err != nil {
			a.logger.Warn().Err(err).Str("repo", job.manifest.FullName).Msg("failed to marshal manifest preview")
			continue
		}
		fmt.Fprintln(os.Stdout, string(content))
	}
}

func (a *App) logUpdateResult(manifest model.RepoManifest) {
	log := a.logger.With().Str("repo", manifest.FullName).Logger()
	for _, failure := range manifest.Failures {
		log.Warn().Str("stage", failure.Stage).Str("error", failure.Error).Msg("manifest update failure")
	}

	status := manifest.UpdateStatus
	entry := log.Info().
		Bool("description_updated", status.DescriptionUpdated).
		Bool("topics_updated", status.TopicsUpdated)
	if status.SkipReason != "" {
		entry = entry.Str("skip_reason", status.SkipReason)
	}

	switch {
	case status.DescriptionUpdated && status.TopicsUpdated:
		entry.Msg("repository updated")
	case status.DescriptionUpdated || status.TopicsUpdated:
		entry.Msg("repository partially updated")
	case status.Skipped:
		entry.Msg("repository skipped")
	default:
		log.Error().Msg("repository update failed")
	}
}

func loadManifestFile(path string) (model.ManifestFile, error) {
	content, err := os.ReadFile(path)
	if err != nil {
		return model.ManifestFile{}, err
	}

	var manifest model.ManifestFile
	if err := json.Unmarshal(content, &manifest); err == nil {
		if manifest.Version == 0 {
			manifest.Version = manifestVersion
		}
		if manifest.GeneratedAt.IsZero() {
			manifest.GeneratedAt = time.Now().UTC()
		}
		return manifest, nil
	}

	var repos []model.RepoManifest
	if err := json.Unmarshal(content, &repos); err != nil {
		return model.ManifestFile{}, fmt.Errorf("parse manifest %s: %w", path, err)
	}

	return model.ManifestFile{
		Version:      manifestVersion,
		GeneratedAt:  time.Now().UTC(),
		Repositories: repos,
	}, nil
}

func saveManifestFile(path string, manifest *model.ManifestFile) error {
	if manifest == nil {
		return errors.New("manifest is nil")
	}
	if strings.TrimSpace(path) == "" {
		return nil
	}

	manifestCopy := *manifest
	if manifestCopy.Version == 0 {
		manifestCopy.Version = manifestVersion
	}
	if manifestCopy.GeneratedAt.IsZero() {
		manifestCopy.GeneratedAt = time.Now().UTC()
	}
	manifestCopy.UpdatedAt = time.Now().UTC()

	content, err := json.MarshalIndent(manifestCopy, "", "  ")
	if err != nil {
		return err
	}

	dir := filepath.Dir(path)
	if dir != "." {
		if err := os.MkdirAll(dir, 0o755); err != nil {
			return err
		}
	}

	tempPath := path + ".tmp"
	if err := os.WriteFile(tempPath, content, 0o644); err != nil {
		return err
	}
	if err := os.Rename(tempPath, path); err != nil {
		return err
	}

	manifest.UpdatedAt = manifestCopy.UpdatedAt
	if manifest.Version == 0 {
		manifest.Version = manifestVersion
	}
	if manifest.GeneratedAt.IsZero() {
		manifest.GeneratedAt = manifestCopy.GeneratedAt
	}

	return nil
}

func newRepoManifest(repo *github.Repository) model.RepoManifest {
	if repo == nil {
		return model.RepoManifest{}
	}

	return model.RepoManifest{
		Owner:           repo.GetOwner().GetLogin(),
		Name:            repo.GetName(),
		FullName:        repo.GetFullName(),
		CloneURL:        repo.GetCloneURL(),
		DefaultBranch:   strings.TrimSpace(repo.GetDefaultBranch()),
		PrimaryLanguage: strings.TrimSpace(repo.GetLanguage()),
		Description:     strings.TrimSpace(repo.GetDescription()),
	}
}

func manifestRepo(manifest model.RepoManifest) *github.Repository {
	return &github.Repository{
		Name:     github.Ptr(manifest.Name),
		FullName: github.Ptr(manifest.FullName),
		Owner:    &github.User{Login: github.Ptr(manifest.Owner)},
	}
}

func importantFilePaths(files []model.ImportantFile) []string {
	paths := make([]string, 0, len(files))
	for _, file := range files {
		if strings.TrimSpace(file.Path) == "" {
			continue
		}
		paths = append(paths, file.Path)
	}
	return paths
}

func metadataChangedFromManifest(manifest model.RepoManifest) bool {
	if manifest.GeneratedMetadata == nil {
		return false
	}

	currentDescription := strings.Join(strings.Fields(strings.TrimSpace(manifest.Description)), " ")
	desiredDescription := strings.Join(strings.Fields(strings.TrimSpace(manifest.GeneratedMetadata.Description)), " ")
	if currentDescription != desiredDescription {
		return true
	}

	currentTopics := analysis.NormalizeSuggestion(model.MetadataSuggestion{Topics: manifest.Topics}).Topics
	desiredTopics := analysis.NormalizeSuggestion(model.MetadataSuggestion{Topics: manifest.GeneratedMetadata.Topics}).Topics
	return !sameStringSet(currentTopics, desiredTopics)
}

func confidenceSkipReasonFromManifest(manifest model.RepoManifest, confidence model.ConfidenceScore) string {
	if strings.TrimSpace(manifest.ReadmeContent) == "" || len(strings.Fields(manifest.ReadmeContent)) < 20 {
		return "low README quality"
	}
	if len(manifest.ImportantFiles) <= 1 {
		return "insufficient source structure"
	}
	if confidence.TechnologyAccuracy < 0.6 {
		return "weak technology detection"
	}
	if confidence.MetadataScore < 0.6 {
		return "weak metadata grounding"
	}
	return "low overall confidence"
}

func hasExcludedTopic(topics, excluded []string) bool {
	if len(topics) == 0 || len(excluded) == 0 {
		return false
	}

	topicSet := make(map[string]struct{}, len(excluded))
	for _, item := range excluded {
		candidate := strings.ToLower(strings.TrimSpace(item))
		if candidate == "" {
			continue
		}
		topicSet[candidate] = struct{}{}
	}

	normalizedTopics := analysis.NormalizeSuggestion(model.MetadataSuggestion{Topics: topics}).Topics
	for _, topic := range normalizedTopics {
		if _, ok := topicSet[strings.ToLower(strings.TrimSpace(topic))]; ok {
			return true
		}
	}

	return false
}
