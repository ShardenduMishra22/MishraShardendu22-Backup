package retry

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/rs/zerolog"
)

type RetryableError struct {
	Err error
}

func (e RetryableError) Error() string {
	return e.Err.Error()
}

func (e RetryableError) Unwrap() error {
	return e.Err
}

func Retryable(err error) error {
	if err == nil {
		return nil
	}
	return RetryableError{Err: err}
}

type StatusError struct {
	Err     error
	Status  int
	Headers http.Header
}

func (e StatusError) Error() string {
	return e.Err.Error()
}

func (e StatusError) Unwrap() error {
	return e.Err
}

func WithStatus(err error, status int, headers http.Header) error {
	if err == nil {
		return nil
	}
	return StatusError{Err: err, Status: status, Headers: headers}
}

type AttemptFunc[T any] func() (T, int, http.Header, error)

func Do[T any](ctx context.Context, maxAttempts int, operation string, logger zerolog.Logger, fn AttemptFunc[T]) (T, error) {
	var zero T
	if maxAttempts < 1 {
		maxAttempts = 1
	}

	for attempt := 1; attempt <= maxAttempts; attempt++ {
		value, status, headers, err := fn()
		if err == nil {
			return value, nil
		}

		retryable := isRetryableError(err) || isRetryableStatus(status, headers)
		if !retryable || attempt == maxAttempts {
			return zero, err
		}

		delay := retryDelay(attempt, headers)
		logger.Warn().
			Str("operation", operation).
			Int("attempt", attempt).
			Int("max_attempts", maxAttempts).
			Int("status_code", status).
			Dur("sleep", delay).
			Err(err).
			Msg("retrying request")

		if delay <= 0 {
			continue
		}

		timer := time.NewTimer(delay)
		select {
		case <-ctx.Done():
			timer.Stop()
			return zero, ctx.Err()
		case <-timer.C:
		}
	}

	return zero, fmt.Errorf("%s failed after %d attempts", operation, maxAttempts)
}

func IsRetryable(err error) bool {
	if err == nil {
		return false
	}
	var statusErr StatusError
	if errors.As(err, &statusErr) {
		return isRetryableStatus(statusErr.Status, statusErr.Headers) || isRetryableError(statusErr.Err)
	}
	return isRetryableError(err)
}

func Backoff(attempt int, err error) time.Duration {
	if attempt < 1 {
		attempt = 1
	}
	var statusErr StatusError
	if errors.As(err, &statusErr) {
		return retryDelay(attempt, statusErr.Headers)
	}
	return retryDelay(attempt, nil)
}

func isRetryableError(err error) bool {
	var retryable RetryableError
	if errors.As(err, &retryable) {
		return true
	}
	var statusErr StatusError
	if errors.As(err, &statusErr) {
		return isRetryableError(statusErr.Err) || isRetryableStatus(statusErr.Status, statusErr.Headers)
	}

	var netErr net.Error
	if errors.As(err, &netErr) && netErr.Timeout() {
		return true
	}

	return errors.Is(err, context.DeadlineExceeded) || errors.Is(err, context.Canceled)
}

func isRetryableStatus(status int, headers http.Header) bool {
	switch status {
	case 0, http.StatusRequestTimeout, http.StatusTooEarly, http.StatusTooManyRequests:
		return true
	case http.StatusForbidden:
		if headers == nil {
			return false
		}
		if strings.TrimSpace(headers.Get("X-RateLimit-Remaining")) == "0" {
			return true
		}
		if headers.Get("Retry-After") != "" {
			return true
		}
		return false
	case http.StatusBadGateway, http.StatusServiceUnavailable, http.StatusGatewayTimeout:
		return true
	default:
		return false
	}
}

func retryDelay(attempt int, headers http.Header) time.Duration {
	if headers != nil {
		if retryAfter := strings.TrimSpace(headers.Get("Retry-After")); retryAfter != "" {
			if seconds, err := strconv.Atoi(retryAfter); err == nil && seconds > 0 {
				return time.Duration(seconds) * time.Second
			}
			if resetAt, err := time.Parse(http.TimeFormat, retryAfter); err == nil {
				if delay := time.Until(resetAt); delay > 0 {
					return delay
				}
			}
		}
	}

	delay := time.Duration(1<<uint(attempt-1)) * 500 * time.Millisecond
	if delay > 30*time.Second {
		delay = 30 * time.Second
	}
	return delay
}
