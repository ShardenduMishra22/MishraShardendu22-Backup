package cli

import (
	"context"
	"os"
	"os/signal"
	"syscall"

	"go-description-script/internal/app"
	"go-description-script/internal/config"
	"go-description-script/internal/server"

	"github.com/rs/zerolog"
	"github.com/spf13/cobra"
)

func newServeCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "serve",
		Short: "Run the dashboard API server",
		RunE: func(cmd *cobra.Command, args []string) error {
			cfg, err := config.Load()
			if err != nil {
				return err
			}

			logger := zerolog.New(os.Stdout).With().Timestamp().Logger()
			if cfg.Verbose {
				logger = logger.Level(zerolog.DebugLevel)
			} else {
				logger = logger.Level(zerolog.InfoLevel)
			}

			application, err := app.New(cfg, logger)
			if err != nil {
				return err
			}

			server.AttachObservability(application, logger)

			ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
			defer stop()

			return server.Start(ctx, server.New(application, cfg, logger), cfg.ServerAddr, logger)
		},
	}

	return cmd
}
