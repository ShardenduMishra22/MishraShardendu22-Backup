package cli

import (
	"os"
	"time"

	"go-description-script/internal/app"
	"go-description-script/internal/config"

	"github.com/rs/zerolog"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
	"github.com/spf13/viper"
)

func Execute() error {
	if err := config.ConfigureViper(); err != nil {
		return err
	}
	zerolog.TimeFieldFormat = time.RFC3339Nano
	return newRootCommand().Execute()
}

func newRootCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:           "go-description-script",
		Short:         "Update GitHub repository descriptions and topics using OpenRouter",
		SilenceUsage:  true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			cfg, err := config.Load()
			if err != nil {
				return err
			}

			logger := zerolog.New(os.Stdout).With().Timestamp().Logger()
			if cfg.Verbose {
				logger = logger.Level(zerolog.DebugLevel)
			} else {
				logger = logger.Level(zerolog.InfoLevel)
			}

			application, err := app.New(cfg, logger)
			if err != nil {
				return err
			}
			return application.Run(cmd.Context())
		},
	}

	flags := cmd.PersistentFlags()
	flags.Bool("dry-run", false, "print planned updates without changing GitHub")
	flags.Bool("generate-manifest", false, "generate a repository manifest without applying updates")
	flags.String("manifest-file", "repos-manifest.json", "path for writing manifest output or default manifest input")
	flags.String("apply-manifest", "", "apply updates using an existing manifest file")
	flags.Bool("preview-only", false, "print manifest preview and skip GitHub updates")
	flags.String("repo", "", "process a single repository by name or owner/name")
	flags.Int("limit", 0, "maximum number of repositories to process after filtering")
	flags.Bool("verbose", false, "enable debug logging")
	flags.String("model", "openai/gpt-oss-120b:free", "OpenRouter model to use")
	flags.String("openrouter-api-keys", "", "comma-separated OpenRouter API keys for failover")
	flags.String("openrouter-models", "", "comma-separated OpenRouter models for failover")
	flags.Int("openrouter-max-concurrency", 0, "maximum concurrent OpenRouter requests")
	flags.Int("openrouter-max-queue", 200, "maximum queued + in-flight OpenRouter requests")
	flags.Duration("openrouter-cooldown-short", 30*time.Second, "OpenRouter short cooldown duration")
	flags.Duration("openrouter-cooldown-medium", 2*time.Minute, "OpenRouter medium cooldown duration")
	flags.Duration("openrouter-cooldown-long", 10*time.Minute, "OpenRouter long cooldown duration")
	flags.Int("openrouter-max-consecutive-fails", 2, "OpenRouter max consecutive failures before long cooldown")
	flags.String("openrouter-state-file", ".openrouter-state.json", "path for OpenRouter key state persistence (set to 'off' to disable)")
	flags.Duration("openrouter-persist-interval", 15*time.Second, "interval for persisting OpenRouter key state")
	flags.Int("workers", 5, "number of concurrent analysis workers")
	flags.Int("llm-workers", 3, "number of concurrent LLM workers")
	flags.Int("github-workers", 2, "number of concurrent GitHub update workers")
	flags.String("allowlist", "", "comma-separated list of repository names or full names to include")
	flags.String("blocklist", "", "comma-separated list of repository names or full names to exclude")
	flags.String("only-language", "", "only apply updates for repositories matching this primary language")
	flags.String("exclude-topic", "", "comma-separated list of topics to exclude from updates")
	flags.Float64("github-rps", 1.0, "GitHub requests per second")
	flags.Float64("openrouter-rps", 1.0, "OpenRouter requests per second")
	flags.Int("retries", 3, "maximum retry attempts for external requests")
	flags.Duration("repo-timeout", 3*time.Minute, "timeout for processing a single repository")
	flags.String("confidence-mode", "", "confidence mode: permissive, balanced, or strict")
	flags.Float64("confidence-threshold", 0.45, "minimum final confidence required to update a repository")
	flags.Float64("min-confidence", 0.0, "alias for confidence-threshold for update filtering")
	flags.String("server-addr", ":8080", "server listen address for dashboard APIs")
	flags.String("server-allow-origin", "*", "CORS allow origin for dashboard APIs")

	mustBindFlag("dry-run", flags.Lookup("dry-run"))
	mustBindFlag("generate-manifest", flags.Lookup("generate-manifest"))
	mustBindFlag("manifest-file", flags.Lookup("manifest-file"))
	mustBindFlag("apply-manifest", flags.Lookup("apply-manifest"))
	mustBindFlag("preview-only", flags.Lookup("preview-only"))
	mustBindFlag("repo", flags.Lookup("repo"))
	mustBindFlag("limit", flags.Lookup("limit"))
	mustBindFlag("verbose", flags.Lookup("verbose"))
	mustBindFlag("model", flags.Lookup("model"))
	mustBindFlag("openrouter-api-keys", flags.Lookup("openrouter-api-keys"))
	mustBindFlag("openrouter-models", flags.Lookup("openrouter-models"))
	mustBindFlag("openrouter-max-concurrency", flags.Lookup("openrouter-max-concurrency"))
	mustBindFlag("openrouter-max-queue", flags.Lookup("openrouter-max-queue"))
	mustBindFlag("openrouter-cooldown-short", flags.Lookup("openrouter-cooldown-short"))
	mustBindFlag("openrouter-cooldown-medium", flags.Lookup("openrouter-cooldown-medium"))
	mustBindFlag("openrouter-cooldown-long", flags.Lookup("openrouter-cooldown-long"))
	mustBindFlag("openrouter-max-consecutive-fails", flags.Lookup("openrouter-max-consecutive-fails"))
	mustBindFlag("openrouter-state-file", flags.Lookup("openrouter-state-file"))
	mustBindFlag("openrouter-persist-interval", flags.Lookup("openrouter-persist-interval"))
	mustBindFlag("workers", flags.Lookup("workers"))
	mustBindFlag("llm-workers", flags.Lookup("llm-workers"))
	mustBindFlag("github-workers", flags.Lookup("github-workers"))
	mustBindFlag("allowlist", flags.Lookup("allowlist"))
	mustBindFlag("blocklist", flags.Lookup("blocklist"))
	mustBindFlag("only-language", flags.Lookup("only-language"))
	mustBindFlag("exclude-topic", flags.Lookup("exclude-topic"))
	mustBindFlag("github-rps", flags.Lookup("github-rps"))
	mustBindFlag("openrouter-rps", flags.Lookup("openrouter-rps"))
	mustBindFlag("retries", flags.Lookup("retries"))
	mustBindFlag("repo-timeout", flags.Lookup("repo-timeout"))
	mustBindFlag("confidence-mode", flags.Lookup("confidence-mode"))
	mustBindFlag("confidence-threshold", flags.Lookup("confidence-threshold"))
	mustBindFlag("min-confidence", flags.Lookup("min-confidence"))
	mustBindFlag("server-addr", flags.Lookup("server-addr"))
	mustBindFlag("server-allow-origin", flags.Lookup("server-allow-origin"))

	cmd.AddCommand(newServeCommand())

	return cmd
}

func mustBindFlag(name string, flag *pflag.Flag) {
	if flag == nil {
		panic("missing flag: " + name)
	}
	if err := viper.BindPFlag(name, flag); err != nil {
		panic(err)
	}
}
