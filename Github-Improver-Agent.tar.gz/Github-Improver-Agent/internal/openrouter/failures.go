package openrouter

import (
	"context"
	"errors"
	"net/http"
	"strings"
	"time"
)

type FailureType int

const (
	FailureUnknown FailureType = iota
	FailureTimeout
	FailureRateLimited
	FailureServerError
	FailureInvalidKey
	FailureQuotaExceeded
	FailureModelNotFound
	FailureBadRequest
)

func (f FailureType) String() string {
	switch f {
	case FailureTimeout:
		return "timeout"
	case FailureRateLimited:
		return "rate_limited"
	case FailureServerError:
		return "server_error"
	case FailureInvalidKey:
		return "invalid_key"
	case FailureQuotaExceeded:
		return "quota_exhausted"
	case FailureModelNotFound:
		return "model_not_found"
	case FailureBadRequest:
		return "bad_request"
	default:
		return "unknown"
	}
}

func isTimeoutError(err error) bool {
	if err == nil {
		return false
	}
	if errors.Is(err, http.ErrHandlerTimeout) {
		return true
	}
	return errors.Is(err, context.DeadlineExceeded) || errors.Is(err, context.Canceled)
}

func classifyFailure(status int, body string, err error) FailureType {
	if err != nil && isTimeoutError(err) {
		return FailureTimeout
	}
	if status == http.StatusTooManyRequests {
		return FailureRateLimited
	}
	if status == http.StatusRequestTimeout {
		return FailureTimeout
	}
	if status == http.StatusUnauthorized {
		return FailureInvalidKey
	}
	if status == http.StatusPaymentRequired {
		return FailureQuotaExceeded
	}
	if status == http.StatusNotFound {
		return FailureModelNotFound
	}
	if status == http.StatusBadRequest {
		return FailureBadRequest
	}
	if status >= 500 {
		return FailureServerError
	}

	lower := strings.ToLower(body)
	switch {
	case strings.Contains(lower, "invalid api key"):
		return FailureInvalidKey
	case strings.Contains(lower, "invalid key"):
		return FailureInvalidKey
	case strings.Contains(lower, "quota"):
		return FailureQuotaExceeded
	case strings.Contains(lower, "insufficient"):
		return FailureQuotaExceeded
	case strings.Contains(lower, "rate limit"):
		return FailureRateLimited
	case strings.Contains(lower, "model") && strings.Contains(lower, "not found"):
		return FailureModelNotFound
	case strings.Contains(lower, "bad request"):
		return FailureBadRequest
	default:
		return FailureUnknown
	}
}

func failureCooldown(failure FailureType, cooldowns cooldowns) time.Duration {
	switch failure {
	case FailureRateLimited:
		return cooldowns.long
	case FailureQuotaExceeded:
		return cooldowns.long
	case FailureTimeout:
		return cooldowns.medium
	case FailureServerError:
		return cooldowns.short
	case FailureInvalidKey:
		return 0
	case FailureModelNotFound:
		return cooldowns.long
	case FailureBadRequest:
		return cooldowns.short
	default:
		return cooldowns.short
	}
}
