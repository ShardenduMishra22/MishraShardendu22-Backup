package openrouter

import (
	"path/filepath"
	"testing"
	"time"
)

func TestStateStorePersistsModelHealth(t *testing.T) {
	t.Parallel()

	manager := NewModelManager([]string{"model-a"})
	selection, ok := manager.Next()
	if !ok {
		t.Fatal("expected model selection")
	}
	manager.ReportFailureState(selection.State, FailureTimeout, 25*time.Millisecond, time.Minute)

	store := NewStateStore(filepath.Join(t.TempDir(), "openrouter-state.json"))
	if err := store.Save(PersistedState{Models: manager.ExportState()}); err != nil {
		t.Fatalf("Save returned error: %v", err)
	}

	loaded, err := store.Load()
	if err != nil {
		t.Fatalf("Load returned error: %v", err)
	}
	restored := NewModelManager([]string{"model-a"})
	restored.ApplyState(loaded.Models)
	snapshot := restored.Snapshot()
	if len(snapshot) != 1 {
		t.Fatalf("Snapshot returned %d models, want 1", len(snapshot))
	}
	if snapshot[0].Failures != 1 || snapshot[0].ConsecutiveFailures != 1 {
		t.Fatalf("failure counters not restored: %#v", snapshot[0])
	}
	if snapshot[0].CooldownSeconds <= 0 {
		t.Fatalf("cooldown was not restored: %#v", snapshot[0])
	}
}
