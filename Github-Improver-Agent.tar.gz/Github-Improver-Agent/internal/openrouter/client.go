package openrouter

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"go-description-script/internal/model"
	"go-description-script/internal/observability"
	"go-description-script/internal/retry"

	"github.com/go-resty/resty/v2"
	"github.com/rs/zerolog"
	"golang.org/x/time/rate"
)

type Client struct {
	httpClient     *resty.Client
	apiKey         string
	model          string
	keys           *KeyManager
	models         *ModelManager
	limiter        *rate.Limiter
	sem            chan struct{}
	queue          chan struct{}
	maxConcurrency int
	maxQueue       int
	retries        int
	logger         zerolog.Logger
	events         *observability.Hub
	stateStore     *StateStore
	metrics        clientMetrics
}

var (
	errNoKeysAvailable   = errors.New("no OpenRouter keys available")
	errNoModelsAvailable = errors.New("no OpenRouter models available")
	errBackpressure      = errors.New("openrouter backpressure: queue full")
)

func New(apiKey, model string, limiter *rate.Limiter, retries int, logger zerolog.Logger) *Client {
	httpClient := resty.New().SetHeader("Accept", "application/json")
	modelList := normalizeModelList([]string{model})
	var modelMgr *ModelManager
	if len(modelList) > 0 {
		modelMgr = NewModelManager(modelList)
	}
	return &Client{
		httpClient: httpClient,
		apiKey:     apiKey,
		model:      model,
		keys:       NewKeyManager([]string{apiKey}),
		models:     modelMgr,
		limiter:    limiter,
		retries:    retries,
		logger:     logger,
	}
}

func NewMulti(apiKeys, models []string, limiter *rate.Limiter, retries int, logger zerolog.Logger) *Client {
	httpClient := resty.New().SetHeader("Accept", "application/json")
	modelList := normalizeModelList(models)
	var modelMgr *ModelManager
	if len(modelList) > 0 {
		modelMgr = NewModelManager(modelList)
	}
	return &Client{
		httpClient: httpClient,
		model:      "",
		keys:       NewKeyManager(apiKeys),
		models:     modelMgr,
		limiter:    limiter,
		retries:    retries,
		logger:     logger,
	}
}

func (c *Client) SetEventHub(hub *observability.Hub) {
	c.events = hub
}

func (c *Client) SetStateStore(store *StateStore) {
	c.stateStore = store
}

func (c *Client) LoadState() error {
	if c.stateStore == nil {
		return nil
	}
	state, err := c.stateStore.Load()
	if err != nil {
		return err
	}
	if c.keys != nil {
		c.keys.ApplyState(state.Keys)
	}
	if c.models != nil {
		c.models.ApplyState(state.Models)
	}
	return nil
}

func (c *Client) PersistState() error {
	if c.stateStore == nil {
		return nil
	}
	state := PersistedState{Keys: nil, Models: nil}
	if c.keys != nil {
		state.Keys = c.keys.ExportState()
	}
	if c.models != nil {
		state.Models = c.models.ExportState()
	}
	return c.stateStore.Save(state)
}

func (c *Client) StartPersistence(ctx context.Context, interval time.Duration) {
	if c.stateStore == nil || interval <= 0 {
		return
	}
	go func() {
		ticker := time.NewTicker(interval)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				_ = c.PersistState()
				return
			case <-ticker.C:
				_ = c.PersistState()
			}
		}
	}()
}

func (c *Client) SetConcurrency(limit int) {
	if limit <= 0 || c.sem != nil {
		return
	}
	c.maxConcurrency = limit
	c.sem = make(chan struct{}, limit)
}

func (c *Client) SetQueueLimit(limit int) {
	if limit <= 0 || c.queue != nil {
		return
	}
	c.maxQueue = limit
	c.queue = make(chan struct{}, limit)
}

func (c *Client) SetCooldowns(short, medium, long time.Duration) {
	if c.keys != nil {
		c.keys.SetCooldowns(short, medium, long)
	}
	if c.models != nil {
		c.models.SetCooldowns(short, medium, long)
	}
}

func (c *Client) SetMaxConsecutiveFails(limit int) {
	if c.keys != nil {
		c.keys.SetMaxConsecutiveFails(limit)
	}
	if c.models != nil {
		c.models.SetMaxConsecutiveFails(limit)
	}
}

func (c *Client) GenerateMetadata(ctx context.Context, prompt string) (model.MetadataSuggestion, error) {
	if err := c.acquire(ctx); err != nil {
		if errors.Is(err, errBackpressure) {
			c.metrics.totalFailures.Add(1)
			c.publish("openrouter_backpressure", map[string]any{
				"event":    "openrouter_backpressure",
				"queued":   c.queueDepth(),
				"capacity": c.queueCapacity(),
			})
		}
		return model.MetadataSuggestion{}, err
	}
	defer c.release()

	keyCount := 0
	if c.keys != nil {
		keyCount = c.keys.Count()
	}
	if keyCount == 0 {
		if strings.TrimSpace(c.apiKey) == "" {
			return model.MetadataSuggestion{}, fmt.Errorf("openrouter API key is not configured")
		}
		return model.MetadataSuggestion{}, errNoKeysAvailable
	}

	modelCount := 1
	if c.models != nil {
		modelCount = c.models.Count()
		if modelCount < 1 {
			modelCount = 1
		}
	}

	attemptBudget := keyCount
	if c.retries > attemptBudget {
		attemptBudget = c.retries
	}
	if attemptBudget > keyCount*2 {
		attemptBudget = keyCount * 2
	}
	if attemptBudget < 1 {
		attemptBudget = 1
	}

	lastErr := error(nil)
	lastKeyID := ""
	lastModel := ""
	lastFailure := FailureUnknown

	for modelTry := 0; modelTry < modelCount; modelTry++ {
		modelName := c.model
		var modelSelection ModelSelection
		if c.models != nil {
			selection, ok := c.models.Next()
			if !ok {
				if delay := c.models.NextAvailableDelay(); delay > 0 {
					if err := sleepWithContext(ctx, delay); err != nil {
						return model.MetadataSuggestion{}, err
					}
				}
				lastErr = errNoModelsAvailable
				continue
			}
			modelSelection = selection
			modelName = selection.Model
		}
		if strings.TrimSpace(modelName) == "" {
			return model.MetadataSuggestion{}, fmt.Errorf("openrouter model is not configured")
		}

		if lastModel != "" && lastModel != modelName {
			c.metrics.totalFailovers.Add(1)
			c.publish("model_fallback", map[string]any{
				"from": lastModel,
				"to":   modelName,
			})
			c.logger.Warn().
				Str("event", "openrouter_model_fallback").
				Str("from_model", lastModel).
				Str("to_model", modelName).
				Msg("model fallback")
		}
		lastModel = modelName

		modelStart := time.Now()
		modelFailure := FailureUnknown
		modelPenalize := false
		modelSucceeded := false

		for attempt := 0; attempt < attemptBudget; attempt++ {
			if attempt > 0 {
				c.metrics.totalRetries.Add(1)
			}
			if err := c.wait(ctx); err != nil {
				lastErr = err
				modelFailure = FailureTimeout
				break
			}
			keySelection, ok := c.keys.Next()
			if !ok {
				if delay := c.keys.NextAvailableDelay(); delay > 0 {
					if err := sleepWithContext(ctx, delay); err != nil {
						lastErr = err
						break
					}
					continue
				}
				lastErr = errNoKeysAvailable
				modelFailure = FailureRateLimited
				break
			}
			apiKey := keySelection.Key
			keyID := keySelection.ID
			keyMasked := keySelection.Masked
			if lastKeyID != "" && lastKeyID != keyID {
				c.metrics.totalFailovers.Add(1)
				c.publish("key_rotated", map[string]any{
					"from": lastKeyID,
					"to":   keyID,
				})
				c.logger.Warn().
					Str("event", "openrouter_failover").
					Str("from_key", lastKeyID).
					Str("to_key", keyID).
					Str("reason", lastFailure.String()).
					Msg("key failover")
			}
			lastKeyID = keyID

			requestStart := time.Now()
			c.metrics.totalRequests.Add(1)
			response, err := c.httpClient.R().
				SetContext(ctx).
				SetHeader("Authorization", "Bearer "+apiKey).
				SetHeader("Content-Type", "application/json").
				SetBody(map[string]interface{}{
					"model": modelName,
					"messages": []map[string]string{
						{
							"role":    "user",
							"content": prompt,
						},
					},
					"reasoning": map[string]bool{
						"enabled": true,
					},
				}).
				Post("https://openrouter.ai/api/v1/chat/completions")
			latency := time.Since(requestStart)
			c.metrics.totalLatencyNano.Add(latency.Nanoseconds())

			if err != nil {
				failure := classifyFailure(0, "", err)
				lastErr = retry.Retryable(err)
				lastFailure = failure
				c.metrics.totalFailures.Add(1)
				c.keys.ReportFailureState(keySelection.State, failure, latency, 0)
				c.logRequest(keyID, modelName, latency, "error", failure, 0)
				c.publish("key_failed", map[string]any{
					"event":            "key_failed",
					"key":              keyID,
					"masked":           keyMasked,
					"status":           0,
					"failure_type":     failure.String(),
					"cooldown_seconds": int64(c.keys.CooldownRemainingState(keySelection.State) / time.Second),
				})
				if shouldPenalizeModel(failure) {
					modelFailure = failure
					modelPenalize = true
				}
				if failure == FailureModelNotFound || failure == FailureBadRequest {
					break
				}
				if delay := retry.Backoff(attempt+1, lastErr); delay > 0 {
					if err := sleepWithContext(ctx, delay); err != nil {
						lastErr = err
						break
					}
				}
				continue
			}

			status := response.StatusCode()
			if status >= 400 {
				body := strings.TrimSpace(response.String())
				failure := classifyFailure(status, body, nil)
				lastErr = retry.WithStatus(fmt.Errorf("openrouter returned status %d: %s", status, body), status, response.Header())
				lastFailure = failure
				cooldownOverride := retryAfterDelay(response.Header())
				c.metrics.totalFailures.Add(1)
				c.keys.ReportFailureState(keySelection.State, failure, latency, cooldownOverride)
				c.logRequest(keyID, modelName, latency, "failed", failure, status)
				c.publish("key_failed", map[string]any{
					"event":            "key_failed",
					"key":              keyID,
					"masked":           keyMasked,
					"status":           status,
					"failure_type":     failure.String(),
					"cooldown_seconds": int64(c.keys.CooldownRemainingState(keySelection.State) / time.Second),
				})
				if shouldPenalizeModel(failure) {
					modelFailure = failure
					modelPenalize = true
				}
				if failure == FailureModelNotFound || failure == FailureBadRequest {
					break
				}
				if delay := retry.Backoff(attempt+1, lastErr); delay > 0 {
					if err := sleepWithContext(ctx, delay); err != nil {
						lastErr = err
						break
					}
				}
				continue
			}

			parsed, err := parseResponse(response.Body())
			if err != nil {
				failure := FailureBadRequest
				lastErr = retry.Retryable(err)
				lastFailure = failure
				c.metrics.totalFailures.Add(1)
				c.keys.ReportFailureState(keySelection.State, failure, latency, 0)
				c.logRequest(keyID, modelName, latency, "invalid_response", failure, 0)
				c.publish("key_failed", map[string]any{
					"event":            "key_failed",
					"key":              keyID,
					"masked":           keyMasked,
					"status":           0,
					"failure_type":     failure.String(),
					"cooldown_seconds": int64(c.keys.CooldownRemainingState(keySelection.State) / time.Second),
				})
				if shouldPenalizeModel(failure) {
					modelFailure = failure
					modelPenalize = true
				}
				break
			}

			c.metrics.totalSuccesses.Add(1)
			c.keys.ReportSuccessState(keySelection.State, latency)
			if c.models != nil && modelSelection.State != nil {
				c.models.ReportSuccessState(modelSelection.State, latency)
			}
			modelSucceeded = true
			c.logRequest(keyID, modelName, latency, "success", FailureUnknown, response.StatusCode())
			c.publish("openrouter_request", map[string]any{
				"event":      "openrouter_request",
				"key":        keyID,
				"masked":     keyMasked,
				"model":      modelName,
				"latency_ms": latency.Milliseconds(),
				"status":     "success",
			})
			return parsed, nil
		}

		if c.models != nil && modelSelection.State != nil {
			if modelSucceeded {
				continue
			}
			if modelPenalize {
				c.models.ReportFailureState(modelSelection.State, modelFailure, time.Since(modelStart), 0)
			} else {
				c.models.ReportAbandonState(modelSelection.State)
			}
		}
	}

	if lastErr == nil {
		lastErr = fmt.Errorf("openrouter request failed")
	}
	return model.MetadataSuggestion{}, lastErr
}

func parseResponse(body []byte) (model.MetadataSuggestion, error) {
	type message struct {
		Content          string          `json:"content"`
		ReasoningDetails json.RawMessage `json:"reasoning_details,omitempty"`
	}
	type choice struct {
		Message message `json:"message"`
	}
	type response struct {
		Choices          []choice        `json:"choices"`
		ReasoningDetails json.RawMessage `json:"reasoning_details,omitempty"`
	}

	var apiResponse response
	if err := json.Unmarshal(body, &apiResponse); err != nil {
		return model.MetadataSuggestion{}, err
	}
	if len(apiResponse.Choices) == 0 {
		return model.MetadataSuggestion{}, fmt.Errorf("openrouter response did not include choices")
	}

	content := extractJSONPayload(apiResponse.Choices[0].Message.Content)
	if content == "" {
		return model.MetadataSuggestion{}, fmt.Errorf("openrouter response content was empty")
	}

	var suggestion model.MetadataSuggestion
	if err := json.Unmarshal([]byte(content), &suggestion); err != nil {
		return model.MetadataSuggestion{}, err
	}

	if len(apiResponse.Choices[0].Message.ReasoningDetails) > 0 {
		suggestion.ReasoningDetails = append(json.RawMessage(nil), apiResponse.Choices[0].Message.ReasoningDetails...)
	} else if len(apiResponse.ReasoningDetails) > 0 {
		suggestion.ReasoningDetails = append(json.RawMessage(nil), apiResponse.ReasoningDetails...)
	}
	return suggestion, nil
}

func extractJSONPayload(content string) string {
	content = strings.TrimSpace(content)
	if content == "" {
		return ""
	}
	if strings.HasPrefix(content, "```") {
		content = strings.TrimPrefix(content, "```json")
		content = strings.TrimPrefix(content, "```")
		content = strings.TrimSuffix(content, "```")
		content = strings.TrimSpace(content)
	}
	if start := strings.Index(content, "{"); start >= 0 {
		content = content[start:]
	}
	if end := strings.LastIndex(content, "}"); end >= 0 {
		content = content[:end+1]
	}
	return strings.TrimSpace(content)
}

func (c *Client) wait(ctx context.Context) error {
	if c.limiter == nil {
		return nil
	}
	return c.limiter.Wait(ctx)
}

func (c *Client) acquire(ctx context.Context) error {
	if c.queue != nil {
		select {
		case c.queue <- struct{}{}:
		default:
			return errBackpressure
		}
	}
	if c.sem == nil {
		c.metrics.activeRequests.Add(1)
		return nil
	}
	select {
	case c.sem <- struct{}{}:
		c.metrics.activeRequests.Add(1)
		return nil
	case <-ctx.Done():
		c.releaseQueue()
		return ctx.Err()
	}
}

func (c *Client) release() {
	if c.sem == nil {
		c.metrics.activeRequests.Add(-1)
		c.releaseQueue()
		return
	}
	select {
	case <-c.sem:
		c.metrics.activeRequests.Add(-1)
	default:
	}
	c.releaseQueue()
}

func (c *Client) releaseQueue() {
	if c.queue == nil {
		return
	}
	select {
	case <-c.queue:
	default:
	}
}

func (c *Client) KeyHealth() []KeyHealth {
	if c.keys == nil {
		return nil
	}
	return c.keys.Snapshot()
}

func (c *Client) ModelHealth() []ModelHealth {
	if c.models == nil {
		return nil
	}
	return c.models.Snapshot()
}

func (c *Client) queueDepth() int {
	if c.queue == nil {
		return 0
	}
	return len(c.queue)
}

func (c *Client) queueCapacity() int {
	if c.queue == nil {
		return 0
	}
	return cap(c.queue)
}

func (c *Client) ReloadKeys(keys []string, weights []int) int {
	if c.keys == nil {
		c.keys = NewKeyManager(keys)
		return len(keys)
	}
	count := c.keys.ReloadWithWeights(keys, weights)
	c.publish("keys_reloaded", map[string]any{"count": count})
	return count
}

func (c *Client) ReloadModels(models []string, weights []int) int {
	models = normalizeModelList(models)
	if len(models) == 0 {
		return 0
	}
	if c.models == nil {
		c.models = NewModelManager(models)
		return len(models)
	}
	count := c.models.ReloadWithWeights(models, weights)
	c.publish("models_reloaded", map[string]any{"count": count})
	return count
}

func (c *Client) DisableKey(id string) bool {
	if c.keys == nil {
		return false
	}
	ok := c.keys.Disable(id)
	if ok {
		c.publish("key_disabled", map[string]any{"key": id})
	}
	return ok
}

func (c *Client) EnableKey(id string) bool {
	if c.keys == nil {
		return false
	}
	ok := c.keys.Enable(id)
	if ok {
		c.publish("key_enabled", map[string]any{"key": id})
	}
	return ok
}

func (c *Client) ResetKeyCooldown(id string) bool {
	if c.keys == nil {
		return false
	}
	ok := c.keys.ResetCooldown(id)
	if ok {
		c.publish("key_cooldown_reset", map[string]any{"key": id})
	}
	return ok
}

func (c *Client) DisableModel(name string) bool {
	if c.models == nil {
		return false
	}
	ok := c.models.Disable(name)
	if ok {
		c.publish("model_disabled", map[string]any{"model": name})
	}
	return ok
}

func (c *Client) EnableModel(name string) bool {
	if c.models == nil {
		return false
	}
	ok := c.models.Enable(name)
	if ok {
		c.publish("model_enabled", map[string]any{"model": name})
	}
	return ok
}

func (c *Client) ResetModelCooldown(name string) bool {
	if c.models == nil {
		return false
	}
	ok := c.models.ResetCooldown(name)
	if ok {
		c.publish("model_cooldown_reset", map[string]any{"model": name})
	}
	return ok
}

func (c *Client) publish(event string, payload any) {
	if c.events == nil {
		return
	}
	c.events.Publish(observability.Event{Type: event, Time: time.Now().UTC(), Payload: payload})
}

func (c *Client) logRequest(keyID, modelName string, latency time.Duration, status string, failure FailureType, statusCode int) {
	event := c.logger.Info().
		Str("event", "openrouter_request").
		Str("key", keyID).
		Str("model", modelName).
		Int64("latency_ms", latency.Milliseconds()).
		Str("status", status)
	if failure != FailureUnknown {
		event = event.Str("failure_type", failure.String())
	}
	if statusCode > 0 {
		event = event.Int("status_code", statusCode)
	}
	event.Msg("openrouter request")
}

func shouldPenalizeModel(failure FailureType) bool {
	switch failure {
	case FailureInvalidKey, FailureRateLimited, FailureQuotaExceeded:
		return false
	default:
		return true
	}
}

func retryAfterDelay(headers http.Header) time.Duration {
	if headers == nil {
		return 0
	}
	value := strings.TrimSpace(headers.Get("Retry-After"))
	if value == "" {
		return 0
	}
	if seconds, err := strconv.Atoi(value); err == nil && seconds > 0 {
		return time.Duration(seconds) * time.Second
	}
	if resetAt, err := time.Parse(http.TimeFormat, value); err == nil {
		if delay := time.Until(resetAt); delay > 0 {
			return delay
		}
	}
	return 0
}

func sleepWithContext(ctx context.Context, delay time.Duration) error {
	if delay <= 0 {
		return nil
	}
	timer := time.NewTimer(delay)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-timer.C:
		return nil
	}
}

func normalizeModelList(models []string) []string {
	if len(models) == 0 {
		return nil
	}
	seen := make(map[string]struct{}, len(models))
	out := make([]string, 0, len(models))
	for _, raw := range models {
		candidate := strings.TrimSpace(raw)
		if candidate == "" {
			continue
		}
		if _, ok := seen[candidate]; ok {
			continue
		}
		seen[candidate] = struct{}{}
		out = append(out, candidate)
	}
	return out
}
