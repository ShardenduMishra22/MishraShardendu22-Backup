package openrouter

import (
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const (
	defaultModelWeight = 100
	minModelWeight     = 1
)

type ModelHealth struct {
	Model               string    `json:"model"`
	Weight              int       `json:"weight"`
	Requests            int64     `json:"requests"`
	Successes           int64     `json:"successes"`
	Failures            int64     `json:"failures"`
	ConsecutiveFailures int64     `json:"consecutive_failures"`
	Active              int64     `json:"active"`
	AvgLatencyMs        int64     `json:"avg_latency_ms"`
	SuccessRate         float64   `json:"success_rate"`
	LastUsed            time.Time `json:"last_used"`
	LastFailure         time.Time `json:"last_failure"`
	LastFailureType     string    `json:"last_failure_type"`
	CooldownUntil       time.Time `json:"cooldown_until"`
	CooldownSeconds     int64     `json:"cooldown_seconds"`
	Healthy             bool      `json:"healthy"`
	Disabled            bool      `json:"disabled"`
}

type modelState struct {
	name   string
	weight atomic.Int64

	currentWeight int64

	disabled          atomic.Bool
	cooldownUntilNano atomic.Int64
	lastUsedNano      atomic.Int64
	lastFailureNano   atomic.Int64
	lastFailureType   atomic.Int64

	requests           atomic.Int64
	successes          atomic.Int64
	failures           atomic.Int64
	consecutiveFailure atomic.Int64
	active             atomic.Int64
	latencySumNano     atomic.Int64
	latencyCount       atomic.Int64
}

type ModelManager struct {
	mu             sync.RWMutex
	selectMu       sync.Mutex
	models         []*modelState
	cooldowns      cooldowns
	maxConsecutive int64
	defaultWeight  int
}

type ModelSelection struct {
	Model string
	State *modelState
}

func NewModelManager(models []string) *ModelManager {
	manager := &ModelManager{
		cooldowns: cooldowns{
			short:  defaultCooldownShort,
			medium: defaultCooldownMedium,
			long:   defaultCooldownLong,
		},
		maxConsecutive: defaultMaxConsecutiveFails,
		defaultWeight:  defaultModelWeight,
	}
	manager.Reload(models)
	return manager
}

func (m *ModelManager) SetCooldowns(short, medium, long time.Duration) {
	m.mu.Lock()
	if short > 0 {
		m.cooldowns.short = short
	}
	if medium > 0 {
		m.cooldowns.medium = medium
	}
	if long > 0 {
		m.cooldowns.long = long
	}
	m.mu.Unlock()
}

func (m *ModelManager) SetMaxConsecutiveFails(limit int) {
	if limit <= 0 {
		return
	}
	m.mu.Lock()
	m.maxConsecutive = int64(limit)
	m.mu.Unlock()
}

func (m *ModelManager) Next() (ModelSelection, bool) {
	models := m.snapshotModels()
	if len(models) == 0 {
		return ModelSelection{}, false
	}

	m.mu.RLock()
	defaultWeight := m.defaultWeight
	m.mu.RUnlock()

	now := time.Now().UTC()
	nowNano := now.UnixNano()

	m.selectMu.Lock()
	defer m.selectMu.Unlock()

	var chosen *modelState
	weightSum := int64(0)

	for _, entry := range models {
		if entry.disabled.Load() {
			continue
		}
		cooldownUntil := entry.cooldownUntilNano.Load()
		if cooldownUntil > 0 && cooldownUntil > nowNano {
			continue
		}
		weight := int64(m.effectiveWeightWithDefault(entry, defaultWeight))
		if weight < int64(minModelWeight) {
			continue
		}
		entry.currentWeight += weight
		weightSum += weight
		if chosen == nil || entry.currentWeight > chosen.currentWeight {
			chosen = entry
		}
	}

	if chosen == nil {
		return ModelSelection{}, false
	}

	chosen.currentWeight -= weightSum
	chosen.lastUsedNano.Store(nowNano)
	chosen.requests.Add(1)
	chosen.active.Add(1)

	return ModelSelection{Model: chosen.name, State: chosen}, true
}

func (m *ModelManager) ReportSuccess(index int, latency time.Duration) {
	entry := m.modelByIndex(index)
	if entry == nil {
		return
	}
	m.ReportSuccessState(entry, latency)
}

func (m *ModelManager) ReportSuccessState(entry *modelState, latency time.Duration) {
	if entry == nil {
		return
	}
	entry.successes.Add(1)
	entry.consecutiveFailure.Store(0)
	entry.lastFailureType.Store(int64(FailureUnknown))
	entry.cooldownUntilNano.Store(0)
	entry.active.Add(-1)
	if latency > 0 {
		entry.latencySumNano.Add(latency.Nanoseconds())
		entry.latencyCount.Add(1)
	}
}

func (m *ModelManager) ReportFailure(index int, failure FailureType, latency time.Duration) {
	entry := m.modelByIndex(index)
	if entry == nil {
		return
	}
	m.ReportFailureState(entry, failure, latency, 0)
}

func (m *ModelManager) ReportFailureState(entry *modelState, failure FailureType, latency time.Duration, cooldownOverride time.Duration) {
	if entry == nil {
		return
	}
	now := time.Now().UTC()
	nowNano := now.UnixNano()
	entry.failures.Add(1)
	entry.consecutiveFailure.Add(1)
	entry.lastFailureNano.Store(nowNano)
	entry.lastFailureType.Store(int64(failure))
	entry.active.Add(-1)
	if latency > 0 {
		entry.latencySumNano.Add(latency.Nanoseconds())
		entry.latencyCount.Add(1)
	}

	if failure == FailureModelNotFound || failure == FailureBadRequest {
		entry.disabled.Store(true)
		entry.cooldownUntilNano.Store(0)
		return
	}

	m.mu.RLock()
	cooldowns := m.cooldowns
	maxConsecutive := m.maxConsecutive
	m.mu.RUnlock()

	cooldown := failureCooldown(failure, cooldowns)
	if cooldownOverride > cooldown {
		cooldown = cooldownOverride
	}

	if maxConsecutive > 0 && entry.consecutiveFailure.Load() >= maxConsecutive {
		if cooldowns.long > cooldown {
			cooldown = cooldowns.long
		}
	}
	if cooldown > 0 {
		entry.cooldownUntilNano.Store(now.Add(cooldown).UnixNano())
	}
}

func (m *ModelManager) ReportAbandon(index int) {
	entry := m.modelByIndex(index)
	if entry == nil {
		return
	}
	m.ReportAbandonState(entry)
}

func (m *ModelManager) ReportAbandonState(entry *modelState) {
	if entry == nil {
		return
	}
	entry.active.Add(-1)
}

func (m *ModelManager) Snapshot() []ModelHealth {
	models := m.snapshotModels()
	if len(models) == 0 {
		return nil
	}

	now := time.Now().UTC()
	nowNano := now.UnixNano()

	out := make([]ModelHealth, 0, len(models))
	for _, entry := range models {
		requests := entry.requests.Load()
		successes := entry.successes.Load()
		failures := entry.failures.Load()
		latencyCount := entry.latencyCount.Load()
		latencySum := entry.latencySumNano.Load()
		avgLatencyMs := int64(0)
		if latencyCount > 0 {
			avgLatencyMs = (latencySum / latencyCount) / int64(time.Millisecond)
		}
		successRate := 0.0
		if requests > 0 {
			successRate = float64(successes) / float64(requests)
		}
		cooldownUntil := entry.cooldownUntilNano.Load()
		cooldownRemaining := int64(0)
		if cooldownUntil > nowNano {
			cooldownRemaining = int64(time.Duration(cooldownUntil-nowNano) / time.Second)
		}

		disabled := entry.disabled.Load()
		healthy := !disabled && cooldownUntil <= nowNano

		m.mu.RLock()
		maxConsecutive := m.maxConsecutive
		m.mu.RUnlock()
		if maxConsecutive > 0 && entry.consecutiveFailure.Load() >= maxConsecutive {
			healthy = false
		}

		out = append(out, ModelHealth{
			Model:               entry.name,
			Weight:              int(entry.weight.Load()),
			Requests:            requests,
			Successes:           successes,
			Failures:            failures,
			ConsecutiveFailures: entry.consecutiveFailure.Load(),
			Active:              entry.active.Load(),
			AvgLatencyMs:        avgLatencyMs,
			SuccessRate:         successRate,
			LastUsed:            nanoToTime(entry.lastUsedNano.Load()),
			LastFailure:         nanoToTime(entry.lastFailureNano.Load()),
			LastFailureType:     FailureType(entry.lastFailureType.Load()).String(),
			CooldownUntil:       nanoToTime(cooldownUntil),
			CooldownSeconds:     cooldownRemaining,
			Healthy:             healthy,
			Disabled:            disabled,
		})
	}
	return out
}

func (m *ModelManager) Reload(models []string) int {
	return m.ReloadWithWeights(models, nil)
}

func (m *ModelManager) ReloadWithWeights(models []string, weights []int) int {
	m.mu.Lock()
	defer m.mu.Unlock()

	seen := make(map[string]*modelState, len(m.models))
	for _, entry := range m.models {
		seen[entry.name] = entry
	}

	updates := make([]*modelState, 0, len(models))
	for idx, raw := range models {
		name := strings.TrimSpace(raw)
		if name == "" {
			continue
		}
		weight := m.defaultWeight
		if idx < len(weights) && weights[idx] > 0 {
			weight = weights[idx]
		}
		if existing, ok := seen[name]; ok {
			existing.weight.Store(int64(weight))
			updates = append(updates, existing)
			continue
		}
		entry := &modelState{name: name}
		entry.weight.Store(int64(weight))
		updates = append(updates, entry)
	}

	sort.Slice(updates, func(i, j int) bool { return updates[i].name < updates[j].name })
	m.models = updates
	return len(m.models)
}

func (m *ModelManager) Disable(name string) bool {
	entry := m.modelByName(name)
	if entry == nil {
		return false
	}
	entry.disabled.Store(true)
	entry.cooldownUntilNano.Store(0)
	return true
}

func (m *ModelManager) Enable(name string) bool {
	entry := m.modelByName(name)
	if entry == nil {
		return false
	}
	entry.disabled.Store(false)
	entry.consecutiveFailure.Store(0)
	return true
}

func (m *ModelManager) ResetCooldown(name string) bool {
	entry := m.modelByName(name)
	if entry == nil {
		return false
	}
	entry.cooldownUntilNano.Store(0)
	entry.consecutiveFailure.Store(0)
	return true
}

func (m *ModelManager) ApplyState(states []PersistedModelState) {
	if len(states) == 0 {
		return
	}
	byName := make(map[string]PersistedModelState, len(states))
	for _, state := range states {
		byName[state.Model] = state
	}

	models := m.snapshotModels()
	for _, entry := range models {
		state, ok := byName[entry.name]
		if !ok {
			continue
		}
		entry.successes.Store(state.Successes)
		entry.failures.Store(state.Failures)
		entry.consecutiveFailure.Store(state.ConsecutiveFailures)
		entry.requests.Store(state.Requests)
		entry.latencySumNano.Store(state.LatencySumNano)
		entry.latencyCount.Store(state.LatencyCount)
		entry.lastFailureNano.Store(state.LastFailureNano)
		entry.lastFailureType.Store(int64(state.LastFailureType))
		entry.cooldownUntilNano.Store(state.CooldownUntilNano)
		entry.disabled.Store(state.Disabled)
	}
}

func (m *ModelManager) ExportState() []PersistedModelState {
	models := m.snapshotModels()
	if len(models) == 0 {
		return nil
	}
	states := make([]PersistedModelState, 0, len(models))
	for _, entry := range models {
		states = append(states, PersistedModelState{
			Model:               entry.name,
			Successes:           entry.successes.Load(),
			Failures:            entry.failures.Load(),
			ConsecutiveFailures: entry.consecutiveFailure.Load(),
			Requests:            entry.requests.Load(),
			LatencySumNano:      entry.latencySumNano.Load(),
			LatencyCount:        entry.latencyCount.Load(),
			LastFailureNano:     entry.lastFailureNano.Load(),
			LastFailureType:     FailureType(entry.lastFailureType.Load()),
			CooldownUntilNano:   entry.cooldownUntilNano.Load(),
			Disabled:            entry.disabled.Load(),
		})
	}
	return states
}

func (m *ModelManager) UpdateWeight(name string, weight int) bool {
	if weight < minModelWeight {
		return false
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, entry := range m.models {
		if entry.name == name {
			entry.weight.Store(int64(weight))
			return true
		}
	}
	return false
}

func (m *ModelManager) NextAvailableDelay() time.Duration {
	models := m.snapshotModels()
	if len(models) == 0 {
		return 0
	}
	now := time.Now().UTC().UnixNano()
	var soonest int64
	for _, entry := range models {
		if entry.disabled.Load() {
			continue
		}
		cooldown := entry.cooldownUntilNano.Load()
		if cooldown == 0 || cooldown <= now {
			return 0
		}
		if soonest == 0 || cooldown < soonest {
			soonest = cooldown
		}
	}
	if soonest == 0 || soonest <= now {
		return 0
	}
	return time.Duration(soonest-now) * time.Nanosecond
}

func (m *ModelManager) Count() int {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return len(m.models)
}

func (m *ModelManager) snapshotModels() []*modelState {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if len(m.models) == 0 {
		return nil
	}
	models := make([]*modelState, len(m.models))
	copy(models, m.models)
	return models
}

func (m *ModelManager) modelByIndex(index int) *modelState {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if index < 0 || index >= len(m.models) {
		return nil
	}
	return m.models[index]
}

func (m *ModelManager) modelByName(name string) *modelState {
	if name == "" {
		return nil
	}
	models := m.snapshotModels()
	for _, entry := range models {
		if entry.name == name {
			return entry
		}
	}
	return nil
}

func (m *ModelManager) effectiveWeight(entry *modelState) int {
	return m.effectiveWeightWithDefault(entry, m.defaultWeight)
}

func (m *ModelManager) effectiveWeightWithDefault(entry *modelState, defaultWeight int) int {
	weight := int(entry.weight.Load())
	if weight <= 0 {
		weight = defaultWeight
	}
	consecutive := entry.consecutiveFailure.Load()
	if consecutive > 0 {
		weight = weight / (1 + int(consecutive))
	}
	weight = applyHealthWeight(weight, entry.successes.Load(), entry.failures.Load())
	weight = applyActiveWeight(weight, entry.active.Load())
	avgLatencyMs := averageModelLatencyMs(entry)
	weight = applyLatencyWeight(weight, avgLatencyMs)
	if weight < minModelWeight {
		weight = minModelWeight
	}
	return weight
}

func averageModelLatencyMs(entry *modelState) int64 {
	count := entry.latencyCount.Load()
	if count == 0 {
		return 0
	}
	sum := entry.latencySumNano.Load()
	return (sum / count) / int64(time.Millisecond)
}
