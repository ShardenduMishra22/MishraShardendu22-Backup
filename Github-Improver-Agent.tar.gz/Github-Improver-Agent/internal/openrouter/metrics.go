package openrouter

import (
	"sync/atomic"
	"time"
)

type Metrics struct {
	ActiveRequests int64         `json:"active_requests"`
	QueuedRequests int           `json:"queued_requests"`
	QueueCapacity  int           `json:"queue_capacity"`
	MaxConcurrency int           `json:"max_concurrency"`
	TotalRequests  int64         `json:"total_requests"`
	Successes      int64         `json:"successes"`
	Failures       int64         `json:"failures"`
	Retries        int64         `json:"retries"`
	Failovers      int64         `json:"failovers"`
	AvgLatencyMs   int64         `json:"avg_latency_ms"`
	SuccessRate    float64       `json:"success_rate"`
	Keys           []KeyHealth   `json:"keys"`
	Models         []ModelHealth `json:"models"`
	UpdatedAt      time.Time     `json:"updated_at"`
}

type clientMetrics struct {
	totalRequests    atomic.Int64
	totalSuccesses   atomic.Int64
	totalFailures    atomic.Int64
	totalRetries     atomic.Int64
	totalFailovers   atomic.Int64
	totalLatencyNano atomic.Int64
	activeRequests   atomic.Int64
}

func (c *Client) Metrics() Metrics {
	keys := []KeyHealth(nil)
	if c.keys != nil {
		keys = c.keys.Snapshot()
	}
	models := []ModelHealth(nil)
	if c.models != nil {
		models = c.models.Snapshot()
	}

	reqs := c.metrics.totalRequests.Load()
	successes := c.metrics.totalSuccesses.Load()
	failures := c.metrics.totalFailures.Load()
	avgLatencyMs := int64(0)
	if reqs > 0 {
		avgLatencyMs = (c.metrics.totalLatencyNano.Load() / reqs) / int64(time.Millisecond)
	}
	successRate := 0.0
	if reqs > 0 {
		successRate = float64(successes) / float64(reqs)
	}

	return Metrics{
		ActiveRequests: c.metrics.activeRequests.Load(),
		QueuedRequests: c.queueDepth(),
		QueueCapacity:  c.queueCapacity(),
		MaxConcurrency: c.maxConcurrency,
		TotalRequests:  reqs,
		Successes:      successes,
		Failures:       failures,
		Retries:        c.metrics.totalRetries.Load(),
		Failovers:      c.metrics.totalFailovers.Load(),
		AvgLatencyMs:   avgLatencyMs,
		SuccessRate:    successRate,
		Keys:           keys,
		Models:         models,
		UpdatedAt:      time.Now().UTC(),
	}
}
