package openrouter

import (
	"encoding/json"
	"os"
	"path/filepath"
	"time"
)

type PersistedKeyState struct {
	ID                  string      `json:"id"`
	Successes           int64       `json:"successes"`
	Failures            int64       `json:"failures"`
	ConsecutiveFailures int64       `json:"consecutive_failures"`
	Requests            int64       `json:"requests"`
	LatencySumNano      int64       `json:"latency_sum_nano"`
	LatencyCount        int64       `json:"latency_count"`
	LastFailureNano     int64       `json:"last_failure_nano"`
	LastFailureType     FailureType `json:"last_failure_type"`
	CooldownUntilNano   int64       `json:"cooldown_until_nano"`
	Disabled            bool        `json:"disabled"`
}

type PersistedState struct {
	Version   int                   `json:"version"`
	UpdatedAt time.Time             `json:"updated_at"`
	Keys      []PersistedKeyState   `json:"keys"`
	Models    []PersistedModelState `json:"models"`
}

type PersistedModelState struct {
	Model               string      `json:"model"`
	Successes           int64       `json:"successes"`
	Failures            int64       `json:"failures"`
	ConsecutiveFailures int64       `json:"consecutive_failures"`
	Requests            int64       `json:"requests"`
	LatencySumNano      int64       `json:"latency_sum_nano"`
	LatencyCount        int64       `json:"latency_count"`
	LastFailureNano     int64       `json:"last_failure_nano"`
	LastFailureType     FailureType `json:"last_failure_type"`
	CooldownUntilNano   int64       `json:"cooldown_until_nano"`
	Disabled            bool        `json:"disabled"`
}

type StateStore struct {
	path string
}

func NewStateStore(path string) *StateStore {
	clean := filepath.Clean(path)
	return &StateStore{path: clean}
}

func (s *StateStore) Load() (PersistedState, error) {
	var state PersistedState
	if s == nil || s.path == "" {
		return state, nil
	}
	content, err := os.ReadFile(s.path)
	if err != nil {
		if os.IsNotExist(err) {
			return state, nil
		}
		return state, err
	}
	if err := json.Unmarshal(content, &state); err != nil {
		return state, err
	}
	return state, nil
}

func (s *StateStore) Save(state PersistedState) error {
	if s == nil || s.path == "" {
		return nil
	}
	state.UpdatedAt = time.Now().UTC()
	if state.Version == 0 {
		state.Version = 1
	}
	content, err := json.MarshalIndent(state, "", "  ")
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(s.path), 0o755); err != nil {
		return err
	}
	tmpPath := s.path + ".tmp"
	if err := os.WriteFile(tmpPath, content, 0o600); err != nil {
		return err
	}
	return os.Rename(tmpPath, s.path)
}
