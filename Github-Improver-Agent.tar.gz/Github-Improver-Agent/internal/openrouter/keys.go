package openrouter

import (
	"crypto/sha256"
	"encoding/hex"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const (
	defaultCooldownShort       = 30 * time.Second
	defaultCooldownMedium      = 2 * time.Minute
	defaultCooldownLong        = 10 * time.Minute
	defaultMaxConsecutiveFails = 2
	defaultKeyWeight           = 100
	minKeyWeight               = 1
)

type KeyHealth struct {
	ID                  string    `json:"id"`
	Masked              string    `json:"masked"`
	Weight              int       `json:"weight"`
	Requests            int64     `json:"requests"`
	Successes           int64     `json:"successes"`
	Failures            int64     `json:"failures"`
	ConsecutiveFailures int64     `json:"consecutive_failures"`
	Active              int64     `json:"active"`
	AvgLatencyMs        int64     `json:"avg_latency_ms"`
	SuccessRate         float64   `json:"success_rate"`
	LastUsed            time.Time `json:"last_used"`
	LastFailure         time.Time `json:"last_failure"`
	LastFailureType     string    `json:"last_failure_type"`
	CooldownUntil       time.Time `json:"cooldown_until"`
	CooldownSeconds     int64     `json:"cooldown_seconds"`
	Healthy             bool      `json:"healthy"`
	Disabled            bool      `json:"disabled"`
}

type cooldowns struct {
	short  time.Duration
	medium time.Duration
	long   time.Duration
}

type keyState struct {
	apiKey string
	id     string
	masked string
	weight atomic.Int64

	currentWeight int64

	disabled          atomic.Bool
	cooldownUntilNano atomic.Int64
	lastUsedNano      atomic.Int64
	lastFailureNano   atomic.Int64
	lastFailureType   atomic.Int64

	requests           atomic.Int64
	successes          atomic.Int64
	failures           atomic.Int64
	consecutiveFailure atomic.Int64
	active             atomic.Int64
	latencySumNano     atomic.Int64
	latencyCount       atomic.Int64
}

type KeyManager struct {
	mu             sync.RWMutex
	selectMu       sync.Mutex
	keys           []*keyState
	cooldowns      cooldowns
	maxConsecutive int64
	defaultWeight  int
}

type KeySelection struct {
	Key    string
	ID     string
	Masked string
	State  *keyState
}

func NewKeyManager(apiKeys []string) *KeyManager {
	manager := &KeyManager{
		cooldowns: cooldowns{
			short:  defaultCooldownShort,
			medium: defaultCooldownMedium,
			long:   defaultCooldownLong,
		},
		maxConsecutive: defaultMaxConsecutiveFails,
		defaultWeight:  defaultKeyWeight,
	}
	manager.Reload(apiKeys)
	return manager
}

func (m *KeyManager) SetCooldowns(short, medium, long time.Duration) {
	m.mu.Lock()
	if short > 0 {
		m.cooldowns.short = short
	}
	if medium > 0 {
		m.cooldowns.medium = medium
	}
	if long > 0 {
		m.cooldowns.long = long
	}
	m.mu.Unlock()
}

func (m *KeyManager) SetMaxConsecutiveFails(limit int) {
	if limit <= 0 {
		return
	}
	m.mu.Lock()
	m.maxConsecutive = int64(limit)
	m.mu.Unlock()
}

func (m *KeyManager) Next() (KeySelection, bool) {
	keys := m.snapshotKeys()
	if len(keys) == 0 {
		return KeySelection{}, false
	}

	m.mu.RLock()
	defaultWeight := m.defaultWeight
	m.mu.RUnlock()

	now := time.Now().UTC()
	nowNano := now.UnixNano()

	m.selectMu.Lock()
	defer m.selectMu.Unlock()

	var chosen *keyState
	weightSum := int64(0)

	for _, entry := range keys {
		if entry.disabled.Load() {
			continue
		}
		cooldownUntil := entry.cooldownUntilNano.Load()
		if cooldownUntil > 0 && cooldownUntil > nowNano {
			continue
		}
		weight := int64(m.effectiveWeightWithDefault(entry, defaultWeight))
		if weight < int64(minKeyWeight) {
			continue
		}
		entry.currentWeight += weight
		weightSum += weight
		if chosen == nil || entry.currentWeight > chosen.currentWeight {
			chosen = entry
		}
	}

	if chosen == nil {
		return KeySelection{}, false
	}

	chosen.currentWeight -= weightSum
	chosen.lastUsedNano.Store(nowNano)
	chosen.requests.Add(1)
	chosen.active.Add(1)

	return KeySelection{
		Key:    chosen.apiKey,
		ID:     chosen.id,
		Masked: chosen.masked,
		State:  chosen,
	}, true
}

func (m *KeyManager) ReportSuccess(index int, latency time.Duration) {
	entry := m.keyByIndex(index)
	if entry == nil {
		return
	}
	m.ReportSuccessState(entry, latency)
}

func (m *KeyManager) ReportSuccessState(entry *keyState, latency time.Duration) {
	if entry == nil {
		return
	}
	entry.successes.Add(1)
	entry.consecutiveFailure.Store(0)
	entry.lastFailureType.Store(int64(FailureUnknown))
	entry.cooldownUntilNano.Store(0)
	entry.active.Add(-1)
	if latency > 0 {
		entry.latencySumNano.Add(latency.Nanoseconds())
		entry.latencyCount.Add(1)
	}
}

func (m *KeyManager) ReportFailure(index int, failure FailureType, latency time.Duration) {
	entry := m.keyByIndex(index)
	if entry == nil {
		return
	}
	m.ReportFailureState(entry, failure, latency, 0)
}

func (m *KeyManager) ReportFailureState(entry *keyState, failure FailureType, latency time.Duration, cooldownOverride time.Duration) {
	if entry == nil {
		return
	}
	now := time.Now().UTC()
	nowNano := now.UnixNano()
	entry.failures.Add(1)
	entry.consecutiveFailure.Add(1)
	entry.lastFailureNano.Store(nowNano)
	entry.lastFailureType.Store(int64(failure))
	entry.active.Add(-1)
	if latency > 0 {
		entry.latencySumNano.Add(latency.Nanoseconds())
		entry.latencyCount.Add(1)
	}

	if failure == FailureInvalidKey {
		entry.disabled.Store(true)
		entry.cooldownUntilNano.Store(0)
		return
	}

	m.mu.RLock()
	cooldowns := m.cooldowns
	maxConsecutive := m.maxConsecutive
	m.mu.RUnlock()

	cooldown := failureCooldown(failure, cooldowns)
	if cooldownOverride > cooldown {
		cooldown = cooldownOverride
	}

	if maxConsecutive > 0 && entry.consecutiveFailure.Load() >= maxConsecutive {
		if cooldowns.long > cooldown {
			cooldown = cooldowns.long
		}
	}
	if cooldown > 0 {
		entry.cooldownUntilNano.Store(now.Add(cooldown).UnixNano())
	}
}

func (m *KeyManager) Snapshot() []KeyHealth {
	keys := m.snapshotKeys()
	if len(keys) == 0 {
		return nil
	}

	now := time.Now().UTC()
	nowNano := now.UnixNano()

	out := make([]KeyHealth, 0, len(keys))
	for _, entry := range keys {
		requests := entry.requests.Load()
		successes := entry.successes.Load()
		failures := entry.failures.Load()
		latencyCount := entry.latencyCount.Load()
		latencySum := entry.latencySumNano.Load()
		avgLatencyMs := int64(0)
		if latencyCount > 0 {
			avgLatencyMs = (latencySum / latencyCount) / int64(time.Millisecond)
		}
		successRate := 0.0
		if requests > 0 {
			successRate = float64(successes) / float64(requests)
		}
		cooldownUntil := entry.cooldownUntilNano.Load()
		cooldownRemaining := int64(0)
		if cooldownUntil > nowNano {
			cooldownRemaining = int64(time.Duration(cooldownUntil-nowNano) / time.Second)
		}

		lastUsed := nanoToTime(entry.lastUsedNano.Load())
		lastFailure := nanoToTime(entry.lastFailureNano.Load())
		failureType := FailureType(entry.lastFailureType.Load()).String()
		disabled := entry.disabled.Load()
		healthy := !disabled && cooldownUntil <= nowNano

		m.mu.RLock()
		maxConsecutive := m.maxConsecutive
		m.mu.RUnlock()
		if maxConsecutive > 0 && entry.consecutiveFailure.Load() >= maxConsecutive {
			healthy = false
		}

		out = append(out, KeyHealth{
			ID:                  entry.id,
			Masked:              entry.masked,
			Weight:              int(entry.weight.Load()),
			Requests:            requests,
			Successes:           successes,
			Failures:            failures,
			ConsecutiveFailures: entry.consecutiveFailure.Load(),
			Active:              entry.active.Load(),
			AvgLatencyMs:        avgLatencyMs,
			SuccessRate:         successRate,
			LastUsed:            lastUsed,
			LastFailure:         lastFailure,
			LastFailureType:     failureType,
			CooldownUntil:       nanoToTime(cooldownUntil),
			CooldownSeconds:     cooldownRemaining,
			Healthy:             healthy,
			Disabled:            disabled,
		})
	}

	return out
}

func (m *KeyManager) Reload(apiKeys []string) int {
	return m.ReloadWithWeights(apiKeys, nil)
}

func (m *KeyManager) ReloadWithWeights(apiKeys []string, weights []int) int {
	m.mu.Lock()
	defer m.mu.Unlock()

	seen := make(map[string]*keyState, len(m.keys))
	for _, entry := range m.keys {
		seen[entry.apiKey] = entry
	}

	keys := make([]*keyState, 0, len(apiKeys))
	for idx, raw := range apiKeys {
		key := strings.TrimSpace(raw)
		if key == "" {
			continue
		}
		weight := m.defaultWeight
		if idx < len(weights) && weights[idx] > 0 {
			weight = weights[idx]
		}
		if existing, ok := seen[key]; ok {
			existing.weight.Store(int64(weight))
			keys = append(keys, existing)
			continue
		}
		keys = append(keys, newKeyState(key, weight))
	}

	sort.Slice(keys, func(i, j int) bool { return keys[i].id < keys[j].id })
	m.keys = keys
	return len(m.keys)
}

func (m *KeyManager) Disable(id string) bool {
	entry := m.keyByID(id)
	if entry == nil {
		return false
	}
	entry.disabled.Store(true)
	entry.cooldownUntilNano.Store(0)
	return true
}

func (m *KeyManager) Enable(id string) bool {
	entry := m.keyByID(id)
	if entry == nil {
		return false
	}
	entry.disabled.Store(false)
	entry.consecutiveFailure.Store(0)
	return true
}

func (m *KeyManager) ResetCooldown(id string) bool {
	entry := m.keyByID(id)
	if entry == nil {
		return false
	}
	entry.cooldownUntilNano.Store(0)
	entry.consecutiveFailure.Store(0)
	return true
}

func (m *KeyManager) UpdateWeight(id string, weight int) bool {
	if weight < minKeyWeight {
		return false
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, entry := range m.keys {
		if entry.id == id {
			entry.weight.Store(int64(weight))
			return true
		}
	}
	return false
}

func (m *KeyManager) NextAvailableDelay() time.Duration {
	keys := m.snapshotKeys()
	if len(keys) == 0 {
		return 0
	}
	now := time.Now().UTC().UnixNano()
	var soonest int64
	for _, entry := range keys {
		if entry.disabled.Load() {
			continue
		}
		cooldown := entry.cooldownUntilNano.Load()
		if cooldown == 0 || cooldown <= now {
			return 0
		}
		if soonest == 0 || cooldown < soonest {
			soonest = cooldown
		}
	}
	if soonest == 0 || soonest <= now {
		return 0
	}
	return time.Duration(soonest-now) * time.Nanosecond
}

func (m *KeyManager) Count() int {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return len(m.keys)
}

func (m *KeyManager) KeyID(index int) string {
	entry := m.keyByIndex(index)
	if entry == nil {
		return ""
	}
	return entry.id
}

func (m *KeyManager) KeyMasked(index int) string {
	entry := m.keyByIndex(index)
	if entry == nil {
		return ""
	}
	return entry.masked
}

func (m *KeyManager) CooldownRemaining(index int) time.Duration {
	entry := m.keyByIndex(index)
	if entry == nil {
		return 0
	}
	return m.CooldownRemainingState(entry)
}

func (m *KeyManager) CooldownRemainingState(entry *keyState) time.Duration {
	if entry == nil {
		return 0
	}
	now := time.Now().UTC().UnixNano()
	cooldownUntil := entry.cooldownUntilNano.Load()
	if cooldownUntil <= now {
		return 0
	}
	return time.Duration(cooldownUntil-now) * time.Nanosecond
}

func (m *KeyManager) ApplyState(states []PersistedKeyState) {
	if len(states) == 0 {
		return
	}
	byID := make(map[string]PersistedKeyState, len(states))
	for _, state := range states {
		byID[state.ID] = state
	}

	keys := m.snapshotKeys()
	for _, entry := range keys {
		state, ok := byID[entry.id]
		if !ok {
			continue
		}
		entry.successes.Store(state.Successes)
		entry.failures.Store(state.Failures)
		entry.consecutiveFailure.Store(state.ConsecutiveFailures)
		entry.requests.Store(state.Requests)
		entry.latencySumNano.Store(state.LatencySumNano)
		entry.latencyCount.Store(state.LatencyCount)
		entry.lastFailureNano.Store(state.LastFailureNano)
		entry.lastFailureType.Store(int64(state.LastFailureType))
		entry.cooldownUntilNano.Store(state.CooldownUntilNano)
		entry.disabled.Store(state.Disabled)
	}
}

func (m *KeyManager) ExportState() []PersistedKeyState {
	keys := m.snapshotKeys()
	if len(keys) == 0 {
		return nil
	}
	states := make([]PersistedKeyState, 0, len(keys))
	for _, entry := range keys {
		states = append(states, PersistedKeyState{
			ID:                  entry.id,
			Successes:           entry.successes.Load(),
			Failures:            entry.failures.Load(),
			ConsecutiveFailures: entry.consecutiveFailure.Load(),
			Requests:            entry.requests.Load(),
			LatencySumNano:      entry.latencySumNano.Load(),
			LatencyCount:        entry.latencyCount.Load(),
			LastFailureNano:     entry.lastFailureNano.Load(),
			LastFailureType:     FailureType(entry.lastFailureType.Load()),
			CooldownUntilNano:   entry.cooldownUntilNano.Load(),
			Disabled:            entry.disabled.Load(),
		})
	}
	return states
}

func (m *KeyManager) snapshotKeys() []*keyState {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if len(m.keys) == 0 {
		return nil
	}
	keys := make([]*keyState, len(m.keys))
	copy(keys, m.keys)
	return keys
}

func (m *KeyManager) keyByIndex(index int) *keyState {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if index < 0 || index >= len(m.keys) {
		return nil
	}
	return m.keys[index]
}

func (m *KeyManager) keyByID(id string) *keyState {
	if id == "" {
		return nil
	}
	keys := m.snapshotKeys()
	for _, entry := range keys {
		if entry.id == id {
			return entry
		}
	}
	return nil
}

func (m *KeyManager) effectiveWeight(entry *keyState) int {
	return m.effectiveWeightWithDefault(entry, m.defaultWeight)
}

func (m *KeyManager) effectiveWeightWithDefault(entry *keyState, defaultWeight int) int {
	weight := int(entry.weight.Load())
	if weight <= 0 {
		weight = defaultWeight
	}

	consecutive := entry.consecutiveFailure.Load()
	if consecutive > 0 {
		weight = weight / (1 + int(consecutive))
	}

	weight = applyHealthWeight(weight, entry.successes.Load(), entry.failures.Load())
	weight = applyActiveWeight(weight, entry.active.Load())

	avgLatencyMs := averageLatencyMs(entry)
	weight = applyLatencyWeight(weight, avgLatencyMs)
	if weight < minKeyWeight {
		weight = minKeyWeight
	}
	return weight
}

func newKeyState(apiKey string, weight int) *keyState {
	if weight <= 0 {
		weight = defaultKeyWeight
	}
	entry := &keyState{
		apiKey: apiKey,
		id:     keyFingerprint(apiKey),
		masked: maskAPIKey(apiKey),
	}
	entry.weight.Store(int64(weight))
	return entry
}

func keyFingerprint(value string) string {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return ""
	}
	sum := sha256.Sum256([]byte(trimmed))
	return hex.EncodeToString(sum[:6])
}

func maskAPIKey(value string) string {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return ""
	}
	if len(trimmed) <= 8 {
		return "****"
	}
	return trimmed[:4] + "..." + trimmed[len(trimmed)-4:]
}

func averageLatencyMs(entry *keyState) int64 {
	count := entry.latencyCount.Load()
	if count == 0 {
		return 0
	}
	sum := entry.latencySumNano.Load()
	return (sum / count) / int64(time.Millisecond)
}

func applyLatencyWeight(weight int, avgLatencyMs int64) int {
	switch {
	case avgLatencyMs <= 0:
		return weight
	case avgLatencyMs < 800:
		return weight + weight/5
	case avgLatencyMs < 1500:
		return weight
	case avgLatencyMs < 3000:
		return weight * 2 / 3
	case avgLatencyMs < 5000:
		return weight / 2
	default:
		return weight / 4
	}
}

func applyHealthWeight(weight int, successes, failures int64) int {
	reqs := successes + failures
	if reqs < 10 {
		return weight
	}
	rate := float64(successes) / float64(reqs)
	switch {
	case rate >= 0.98:
		return weight + weight/5
	case rate >= 0.92:
		return weight + weight/10
	case rate >= 0.8:
		return weight
	case rate >= 0.6:
		return weight * 3 / 4
	default:
		return weight / 2
	}
}

func applyActiveWeight(weight int, active int64) int {
	if active <= 0 {
		return weight
	}
	return weight / (1 + int(active))
}

func nanoToTime(nano int64) time.Time {
	if nano <= 0 {
		return time.Time{}
	}
	return time.Unix(0, nano).UTC()
}
