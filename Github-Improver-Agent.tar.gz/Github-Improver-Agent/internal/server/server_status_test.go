package server

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"go-description-script/internal/app"
	"go-description-script/internal/config"

	"github.com/rs/zerolog"
)

func TestHandlePipelineStatusReturnsEmptyCollections(t *testing.T) {
	t.Parallel()

	srv := New(&app.App{}, config.Config{}, zerolog.Nop())
	req := httptest.NewRequest(http.MethodGet, "/api/pipeline/status", nil)
	res := httptest.NewRecorder()

	srv.Handler().ServeHTTP(res, req)

	if res.Code != http.StatusOK {
		t.Fatalf("status code = %d, want %d", res.Code, http.StatusOK)
	}

	var payload struct {
		Repositories []json.RawMessage `json:"repositories"`
		Events       []json.RawMessage `json:"events"`
		OpenRouter   struct {
			Keys   []json.RawMessage `json:"keys"`
			Models []json.RawMessage `json:"models"`
		} `json:"openrouter"`
		Summary struct {
			Cooldowns  []json.RawMessage `json:"cooldowns"`
			ModelUsage []json.RawMessage `json:"model_usage"`
			KeyUsage   []json.RawMessage `json:"key_usage"`
		} `json:"summary"`
	}

	if err := json.NewDecoder(res.Body).Decode(&payload); err != nil {
		t.Fatalf("decode response: %v", err)
	}

	if payload.Repositories == nil {
		t.Fatal("repositories decoded as nil")
	}
	if payload.Events == nil {
		t.Fatal("events decoded as nil")
	}
	if payload.OpenRouter.Keys == nil {
		t.Fatal("openrouter.keys decoded as nil")
	}
	if payload.OpenRouter.Models == nil {
		t.Fatal("openrouter.models decoded as nil")
	}
	if payload.Summary.Cooldowns == nil {
		t.Fatal("summary.cooldowns decoded as nil")
	}
	if payload.Summary.ModelUsage == nil {
		t.Fatal("summary.model_usage decoded as nil")
	}
	if payload.Summary.KeyUsage == nil {
		t.Fatal("summary.key_usage decoded as nil")
	}
}
