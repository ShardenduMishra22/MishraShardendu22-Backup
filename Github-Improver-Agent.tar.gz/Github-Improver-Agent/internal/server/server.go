package server

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"go-description-script/internal/app"
	"go-description-script/internal/config"
	"go-description-script/internal/observability"

	"github.com/rs/zerolog"
)

type Server struct {
	app    *app.App
	cfg    config.Config
	logger zerolog.Logger
	mux    *http.ServeMux
}

type ReloadRequest struct {
	Keys   []string `json:"keys"`
	Models []string `json:"models"`
}

type AdminAction struct {
	Action string `json:"action"`
	ID     string `json:"id"`
	Target string `json:"target"`
}

type PipelineActionRequest struct {
	Repo             string   `json:"repo"`
	Repos            []string `json:"repos"`
	GenerateManifest bool     `json:"generate_manifest"`
	PreviewOnly      bool     `json:"preview_only"`
	DryRun           bool     `json:"dry_run"`
	Mode             string   `json:"mode"`
	Reason           string   `json:"reason"`
	ManifestPath     string   `json:"manifest_path"`
}

type RepoActionRequest struct {
	Repo   string `json:"repo"`
	Action string `json:"action"`
	Mode   string `json:"mode"`
}

func New(appRef *app.App, cfg config.Config, logger zerolog.Logger) *Server {
	s := &Server{
		app:    appRef,
		cfg:    cfg,
		logger: logger,
		mux:    http.NewServeMux(),
	}
	s.routes()
	return s
}

func (s *Server) Handler() http.Handler {
	return s.withCORS(s.mux)
}

func (s *Server) routes() {
	s.mux.HandleFunc("/healthz", s.handleHealth)
	s.mux.HandleFunc("/readyz", s.handleReady)
	s.mux.HandleFunc("/api/openrouter/keys", s.handleOpenRouterKeys)
	s.mux.HandleFunc("/api/openrouter/models", s.handleOpenRouterModels)
	s.mux.HandleFunc("/api/openrouter/metrics", s.handleOpenRouterMetrics)
	s.mux.HandleFunc("/api/openrouter/reload", s.handleOpenRouterReload)
	s.mux.HandleFunc("/api/openrouter/admin", s.handleOpenRouterAdmin)
	s.mux.HandleFunc("/api/events", s.handleEvents)
	s.mux.HandleFunc("/api/pipeline", s.handlePipeline)
	s.mux.HandleFunc("/api/pipeline/status", s.handlePipelineStatus)
	s.mux.HandleFunc("/api/pipeline/start", s.handlePipelineStart)
	s.mux.HandleFunc("/api/pipeline/stop", s.handlePipelineStop)
	s.mux.HandleFunc("/api/pipeline/pause", s.handlePipelinePause)
	s.mux.HandleFunc("/api/pipeline/resume", s.handlePipelineResume)
	s.mux.HandleFunc("/api/pipeline/retry", s.handlePipelineRetry)
	s.mux.HandleFunc("/api/repos/action", s.handleRepoAction)
}

func (s *Server) handleHealth(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

func (s *Server) handleReady(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	if s.app == nil || s.app.Events() == nil {
		writeError(w, http.StatusServiceUnavailable, "not ready")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "ready"})
}

func (s *Server) handleOpenRouterKeys(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	writeJSON(w, http.StatusOK, s.app.OpenRouterKeyHealth())
}

func (s *Server) handleOpenRouterModels(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	writeJSON(w, http.StatusOK, s.app.OpenRouterModelHealth())
}

func (s *Server) handleOpenRouterMetrics(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	writeJSON(w, http.StatusOK, s.app.OpenRouterMetrics())
}

func (s *Server) handleOpenRouterReload(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	var req ReloadRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body")
		return
	}
	if len(req.Keys) == 0 && len(req.Models) == 0 {
		writeError(w, http.StatusBadRequest, "keys or models required")
		return
	}
	countKeys := 0
	countModels := 0
	if len(req.Keys) > 0 {
		countKeys = s.app.ReloadOpenRouterKeys(req.Keys, nil)
	}
	if len(req.Models) > 0 {
		countModels = s.app.ReloadOpenRouterModels(req.Models, nil)
	}
	writeJSON(w, http.StatusOK, map[string]any{"keys": countKeys, "models": countModels})
}

func (s *Server) handleOpenRouterAdmin(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	var req AdminAction
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body")
		return
	}
	switch strings.ToLower(req.Target) {
	case "key":
		ok := s.handleKeyAdmin(req)
		if !ok {
			writeError(w, http.StatusBadRequest, "invalid key action")
			return
		}
	case "model":
		ok := s.handleModelAdmin(req)
		if !ok {
			writeError(w, http.StatusBadRequest, "invalid model action")
			return
		}
	default:
		writeError(w, http.StatusBadRequest, "invalid target")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

func (s *Server) handleKeyAdmin(req AdminAction) bool {
	switch strings.ToLower(req.Action) {
	case "disable":
		return s.app.DisableOpenRouterKey(req.ID)
	case "enable":
		return s.app.EnableOpenRouterKey(req.ID)
	case "reset_cooldown":
		return s.app.ResetOpenRouterKeyCooldown(req.ID)
	default:
		return false
	}
}

func (s *Server) handleModelAdmin(req AdminAction) bool {
	switch strings.ToLower(req.Action) {
	case "disable":
		return s.app.DisableOpenRouterModel(req.ID)
	case "enable":
		return s.app.EnableOpenRouterModel(req.ID)
	case "reset_cooldown":
		return s.app.ResetOpenRouterModelCooldown(req.ID)
	default:
		return false
	}
}

func (s *Server) handleEvents(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	if s.app.Events() == nil {
		writeError(w, http.StatusServiceUnavailable, "events not available")
		return
	}
	flusher, ok := w.(http.Flusher)
	if !ok {
		writeError(w, http.StatusBadRequest, "streaming unsupported")
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")
	w.Header().Set("X-Accel-Buffering", "no")
	flusher.Flush()

	recentLimit := 0
	if recent := r.URL.Query().Get("recent"); recent != "" {
		if limit, err := strconv.Atoi(recent); err == nil && limit > 0 {
			recentLimit = limit
		}
	}
	lastEventID := parseLastEventID(r)
	var recentEvents []observability.Event
	if lastEventID > 0 {
		recentEvents = s.app.Events().RecentAfterID(lastEventID, recentLimit)
	} else if recentLimit > 0 {
		recentEvents = s.app.Events().Recent(recentLimit)
	}
	for _, event := range recentEvents {
		if err := writeSSEEvent(w, event); err != nil {
			return
		}
	}
	flusher.Flush()

	ch := s.app.Events().Subscribe(128)
	defer s.app.Events().Unsubscribe(ch)

	ctx := r.Context()
	heartbeat := time.NewTicker(20 * time.Second)
	defer heartbeat.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-heartbeat.C:
			if _, err := w.Write([]byte(": heartbeat\n\n")); err != nil {
				return
			}
			flusher.Flush()
		case event, ok := <-ch:
			if !ok {
				return
			}
			if err := writeSSEEvent(w, event); err != nil {
				return
			}
			flusher.Flush()
		}
	}
}

func parseLastEventID(r *http.Request) uint64 {
	raw := strings.TrimSpace(r.Header.Get("Last-Event-ID"))
	if raw == "" {
		raw = strings.TrimSpace(r.URL.Query().Get("last_event_id"))
	}
	if raw == "" {
		return 0
	}
	id, err := strconv.ParseUint(raw, 10, 64)
	if err != nil {
		return 0
	}
	return id
}

func writeSSEEvent(w http.ResponseWriter, event observability.Event) error {
	payload, err := json.Marshal(event)
	if err != nil {
		return err
	}
	if _, err := w.Write([]byte("id: " + strconv.FormatUint(event.ID, 10) + "\n")); err != nil {
		return err
	}
	if _, err := w.Write([]byte("data: ")); err != nil {
		return err
	}
	if _, err := w.Write(payload); err != nil {
		return err
	}
	_, err = w.Write([]byte("\n\n"))
	return err
}

func (s *Server) handlePipeline(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	writeJSON(w, http.StatusOK, s.app.PipelineStatus())
}

func (s *Server) handlePipelineStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	writeJSON(w, http.StatusOK, s.app.PipelineStatus())
}

func (s *Server) handlePipelineStart(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	var req PipelineActionRequest
	_ = json.NewDecoder(r.Body).Decode(&req)
	if err := s.app.StartBackgroundPipeline(app.PipelineRunOptions{
		Selection:        pipelineSelection(req),
		GenerateManifest: req.GenerateManifest || strings.EqualFold(req.Mode, "manifest"),
		PreviewOnly:      req.PreviewOnly,
		DryRun:           req.DryRun,
		ApplyManifest:    req.ManifestPath,
		Mode:             pickMode(req.Mode, "start"),
		Reason:           req.Reason,
	}); err != nil {
		status := http.StatusBadRequest
		if errors.Is(err, app.ErrPipelineAlreadyRunning) {
			status = http.StatusConflict
		}
		writeError(w, status, err.Error())
		return
	}
	writeJSON(w, http.StatusAccepted, s.app.PipelineStatus())
}

func (s *Server) handlePipelineStop(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	if err := s.app.StopBackgroundPipeline(); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, s.app.PipelineStatus())
}

func (s *Server) handlePipelinePause(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	if err := s.app.PauseBackgroundPipeline(); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, s.app.PipelineStatus())
}

func (s *Server) handlePipelineResume(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	if err := s.app.ResumeBackgroundPipeline(); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, s.app.PipelineStatus())
}

func (s *Server) handlePipelineRetry(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	var req PipelineActionRequest
	_ = json.NewDecoder(r.Body).Decode(&req)
	selection := pipelineSelection(req)
	if len(selection) > 0 {
		if err := s.app.StartBackgroundPipeline(app.PipelineRunOptions{
			Selection: selection,
			Mode:      pickMode(req.Mode, "retry"),
			Reason:    req.Reason,
		}); err != nil {
			status := http.StatusBadRequest
			if errors.Is(err, app.ErrPipelineAlreadyRunning) {
				status = http.StatusConflict
			}
			writeError(w, status, err.Error())
			return
		}
		writeJSON(w, http.StatusAccepted, s.app.PipelineStatus())
		return
	}
	if err := s.app.RetryFailedBackgroundPipeline(req.ManifestPath); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusAccepted, s.app.PipelineStatus())
}

func (s *Server) handleRepoAction(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	var req RepoActionRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid request body")
		return
	}
	result, err := s.app.ExecuteRepoAction(r.Context(), req.Repo, req.Action, req.Mode)
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, result)
}

func pipelineSelection(req PipelineActionRequest) []string {
	selection := make([]string, 0, len(req.Repos)+1)
	for _, repo := range req.Repos {
		if trimmed := strings.TrimSpace(repo); trimmed != "" {
			selection = append(selection, trimmed)
		}
	}
	if trimmed := strings.TrimSpace(req.Repo); trimmed != "" {
		selection = append(selection, trimmed)
	}
	return selection
}

func pickMode(value, fallback string) string {
	if strings.TrimSpace(value) == "" {
		return fallback
	}
	return strings.TrimSpace(value)
}

func (s *Server) withCORS(next http.Handler) http.Handler {
	allow := s.cfg.ServerAllowOrigin
	if allow == "" {
		allow = "*"
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", allow)
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}

func writeJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}

func writeError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, map[string]string{"error": message})
}

func Start(ctx context.Context, server *Server, addr string, logger zerolog.Logger) error {
	if addr == "" {
		addr = ":8080"
	}
	httpServer := &http.Server{
		Addr:         addr,
		Handler:      server.Handler(),
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 0,
		IdleTimeout:  60 * time.Second,
	}

	errCh := make(chan error, 1)
	go func() {
		logger.Info().Str("addr", addr).Msg("server listening")
		errCh <- httpServer.ListenAndServe()
	}()

	select {
	case <-ctx.Done():
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		return httpServer.Shutdown(shutdownCtx)
	case err := <-errCh:
		return err
	}
}

func AttachObservability(appRef *app.App, logger zerolog.Logger) {
	state := observability.NewState()
	events := observability.NewHub(2000)
	appRef.SetObservability(state, events)
	logger.Info().Msg("observability hub attached")
}
