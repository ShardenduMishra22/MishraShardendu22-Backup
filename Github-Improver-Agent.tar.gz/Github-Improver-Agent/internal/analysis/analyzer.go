package analysis

import (
	"encoding/json"
	"errors"
	"fmt"
	"regexp"
	"sort"
	"strings"
	"unicode"

	"go-description-script/internal/model"

	"github.com/google/go-github/v86/github"
)

type keywordGroup struct {
	Label    string
	Patterns []string
}

var frameworkGroups = []keywordGroup{
	{Label: "nextjs", Patterns: []string{"next.js", "nextjs", "\"next\"", "next/font"}},
	{Label: "react", Patterns: []string{"react", "react-dom"}},
	{Label: "vue", Patterns: []string{"vue", "nuxt"}},
	{Label: "svelte", Patterns: []string{"svelte", "sveltekit"}},
	{Label: "angular", Patterns: []string{"angular", "@angular/"}},
	{Label: "vite", Patterns: []string{"vite", "vitejs"}},
	{Label: "astro", Patterns: []string{"astro"}},
	{Label: "express", Patterns: []string{"express", "expressjs"}},
	{Label: "nestjs", Patterns: []string{"nestjs", "@nestjs/"}},
	{Label: "fastify", Patterns: []string{"fastify"}},
	{Label: "gin", Patterns: []string{"gin-gonic/gin", "gin"}},
	{Label: "echo", Patterns: []string{"labstack/echo", "echo"}},
	{Label: "fiber", Patterns: []string{"gofiber/fiber", "fiber"}},
	{Label: "cobra", Patterns: []string{"spf13/cobra", "cobra"}},
	{Label: "viper", Patterns: []string{"spf13/viper", "viper"}},
	{Label: "grpc", Patterns: []string{"grpc", "google.golang.org/grpc"}},
	{Label: "gqlgen", Patterns: []string{"gqlgen"}},
	{Label: "tokio", Patterns: []string{"tokio"}},
	{Label: "axum", Patterns: []string{"axum"}},
	{Label: "actix-web", Patterns: []string{"actix-web"}},
	{Label: "rocket", Patterns: []string{"rocket"}},
	{Label: "clap", Patterns: []string{"clap"}},
	{Label: "spring-boot", Patterns: []string{"spring boot", "spring-boot"}},
	{Label: "fastapi", Patterns: []string{"fastapi"}},
	{Label: "django", Patterns: []string{"django"}},
	{Label: "flask", Patterns: []string{"flask"}},
	{Label: "pytorch", Patterns: []string{"pytorch", "torch"}},
	{Label: "tensorflow", Patterns: []string{"tensorflow"}},
	{Label: "scikit-learn", Patterns: []string{"scikit-learn", "sklearn"}},
	{Label: "langchain", Patterns: []string{"langchain"}},
	{Label: "llamaindex", Patterns: []string{"llamaindex", "llama-index"}},
	{Label: "huggingface", Patterns: []string{"huggingface", "transformers"}},
	{Label: "opencv", Patterns: []string{"opencv"}},
	{Label: "boost", Patterns: []string{"boost"}},
	{Label: "qt", Patterns: []string{"qt"}},
}

var infraGroups = []keywordGroup{
	{Label: "docker", Patterns: []string{"docker", "docker-compose", "compose.yaml", "compose.yml"}},
	{Label: "kubernetes", Patterns: []string{"kubernetes", "k8s", "helm", "kubectl"}},
	{Label: "terraform", Patterns: []string{"terraform", "opentofu"}},
	{Label: "ansible", Patterns: []string{"ansible"}},
	{Label: "github-actions", Patterns: []string{"github actions", "github/workflows", ".github/workflows"}},
	{Label: "pulumi", Patterns: []string{"pulumi"}},
	{Label: "argo", Patterns: []string{"argo", "argocd"}},
	{Label: "make", Patterns: []string{"makefile", "gnumake"}},
	{Label: "cloudformation", Patterns: []string{"cloudformation"}},
	{Label: "kustomize", Patterns: []string{"kustomize"}},
}

var aiGroups = []keywordGroup{
	{Label: "ai", Patterns: []string{"openai", "anthropic", "huggingface", "transformers", "llm", "embedding", "embeddings", "vector database", "rag", "langchain", "llamaindex", "langgraph", "crewai", "ollama", "pytorch", "tensorflow", "scikit-learn", "mlflow"}},
	{Label: "machine-learning", Patterns: []string{"machine learning", "training data", "inference", "fine-tuning"}},
}

var backendHints = []string{"gin", "echo", "fiber", "express", "nestjs", "fastify", "spring-boot", "django", "flask", "fastapi", "actix-web", "axum", "grpc"}
var frontendHints = []string{"nextjs", "react", "vue", "svelte", "angular", "vite", "astro"}

const maxDescriptionChars = 120

type packageJSON struct {
	Name             string            `json:"name"`
	Description      string            `json:"description"`
	Scripts          map[string]string `json:"scripts"`
	Dependencies     map[string]string `json:"dependencies"`
	DevDependencies  map[string]string `json:"devDependencies"`
	PeerDependencies map[string]string `json:"peerDependencies"`
}

type Analyzer struct{}

func New() *Analyzer {
	return &Analyzer{}
}

func (a *Analyzer) Analyze(repo *github.Repository, snapshot model.RepoSnapshot) model.RepoAnalysis {
	combined := strings.ToLower(strings.Join(collectTexts(snapshot), "\n"))
	language := strings.TrimSpace(detectPrimaryLanguage(snapshot, repo.GetLanguage()))
	frameworks := collectLabels(combined, frameworkGroups)
	infra := collectLabels(combined, infraGroups)
	ai := collectLabels(combined, aiGroups)
	technologyMentions := findTechnologyMentions(combined)
	detectedTechnologies := normalizeTopics(append(append(append(append(append([]string{}, frameworks...), infra...), ai...), technologyMentions...), languageTopic(language)))
	detectedTopics := normalizeTopics(append(append([]string{}, detectedTechnologies...), domainTopicCandidates(combined)...))

	readmeSummary := summarizeReadme(snapshot.README)
	importantFiles := summarizeImportantFiles(snapshot.Files)
	projectCategory := detectProjectCategory(language, combined, frameworks, infra, ai)
	backendFrontend := detectBackendFrontend(language, combined, frameworks, infra, ai, projectCategory)

	return model.RepoAnalysis{
		Owner:                repo.GetOwner().GetLogin(),
		Name:                 repo.GetName(),
		FullName:             repo.GetFullName(),
		Description:          strings.TrimSpace(repo.GetDescription()),
		DefaultBranch:        strings.TrimSpace(repo.GetDefaultBranch()),
		PrimaryLanguage:      language,
		ExistingTopics:       normalizeTopics(snapshot.ExistingTopics),
		READMEPreview:        readmeSummary,
		ImportantFiles:       importantFiles,
		Frameworks:           frameworks,
		Infrastructure:       infra,
		AITools:              ai,
		ProjectCategory:      projectCategory,
		BackendFrontend:      backendFrontend,
		DetectedTechnologies: detectedTechnologies,
		DetectedTopics:       detectedTopics,
	}
}

func BuildPrompt(analysis model.RepoAnalysis) string {
	var builder strings.Builder
	builder.Grow(4096)

	builder.WriteString("You are a senior open-source maintainer.\n")
	builder.WriteString("Generate concise, technical GitHub metadata for this repository.\n")
	builder.WriteString("Never invent technologies, frameworks, or topics.\n")
	builder.WriteString("Only mention technologies explicitly detected from the repository evidence provided below.\n")
	builder.WriteString("Avoid marketing language and buzzwords such as modern, powerful, scalable, lightweight, robust, enterprise-grade, and cutting-edge.\n")
	builder.WriteString("Prefer precise engineering terminology and functionality over adjectives.\n")
	builder.WriteString("Do not describe the repository as empty, placeholder, or lacking functionality.\n")
	builder.WriteString("If evidence is limited, write a neutral, factual description based on the language/category instead of negative phrasing.\n")
	builder.WriteString("Use sentence case and proper capitalization for common technical terms (API, AI/ML, Jupyter Notebook, Go, Node.js).\n")
	builder.WriteString("Return STRICT JSON ONLY with this schema: {\"description\":\"...\",\"topics\":[\"...\"]}.\n")
	builder.WriteString("Rules: description must be under 120 characters, start with functionality, avoid repeating the repository name, avoid vague wording, and avoid unnecessary adjectives.\n")
	builder.WriteString("Topics must be lowercase, deduplicated, precise, and no more than 10 items. Remove generic topics like web, app, backend, and frontend unless they are explicitly the best fit.\n")
	builder.WriteString("Reject description topics or metadata that contain demo, starter, test, example, sample, or boilerplate unless the repository purpose explicitly requires those words.\n")
	builder.WriteString("Use existing topics only when they are still relevant. Preserve specific nouns from the repository context.\n")

	writeSection := func(title string) {
		builder.WriteString("\n## ")
		builder.WriteString(title)
		builder.WriteString("\n")
	}

	writeSection("Repository")
	builder.WriteString("owner: ")
	builder.WriteString(valueOrPlaceholder(analysis.Owner))
	builder.WriteString("\nname: ")
	builder.WriteString(valueOrPlaceholder(analysis.Name))
	builder.WriteString("\nfull_name: ")
	builder.WriteString(valueOrPlaceholder(analysis.FullName))
	builder.WriteString("\ncurrent_description: ")
	builder.WriteString(valueOrPlaceholder(analysis.Description))
	builder.WriteString("\nprimary_language: ")
	builder.WriteString(valueOrPlaceholder(analysis.PrimaryLanguage))
	builder.WriteString("\ndefault_branch: ")
	builder.WriteString(valueOrPlaceholder(analysis.DefaultBranch))
	builder.WriteString("\nexisting_topics: ")
	builder.WriteString(formatJSONArray(analysis.ExistingTopics))
	builder.WriteString("\n")

	writeSection("Detected Signals")
	builder.WriteString("project_category: ")
	builder.WriteString(valueOrPlaceholder(analysis.ProjectCategory))
	builder.WriteString("\nbackend_frontend: ")
	builder.WriteString(valueOrPlaceholder(analysis.BackendFrontend))
	builder.WriteString("\ndetected_technologies: ")
	builder.WriteString(formatJSONArray(analysis.DetectedTechnologies))
	builder.WriteString("\ndetected_topics: ")
	builder.WriteString(formatJSONArray(analysis.DetectedTopics))
	builder.WriteString("\nframeworks: ")
	builder.WriteString(formatJSONArray(analysis.Frameworks))
	builder.WriteString("\ninfrastructure_tools: ")
	builder.WriteString(formatJSONArray(analysis.Infrastructure))
	builder.WriteString("\nai_ml_signals: ")
	builder.WriteString(formatJSONArray(analysis.AITools))
	builder.WriteString("\n")

	writeSection("README Summary")
	if strings.TrimSpace(analysis.READMEPreview) == "" {
		builder.WriteString("none\n")
	} else {
		builder.WriteString(analysis.READMEPreview)
		builder.WriteString("\n")
	}

	writeSection("Important Files")
	if len(analysis.ImportantFiles) == 0 {
		builder.WriteString("none\n")
	} else {
		for _, file := range analysis.ImportantFiles {
			builder.WriteString("- ")
			builder.WriteString(file.Path)
			builder.WriteString(": ")
			builder.WriteString(file.Summary)
			builder.WriteString("\n")
		}
	}

	writeSection("Task")
	builder.WriteString("Write one description and up to ten topics.\n")
	builder.WriteString("Description must read like a professional maintainer wrote it, not marketing copy.\n")
	builder.WriteString("Topics should reflect the repository's actual language, framework, category, and tooling.\n")
	builder.WriteString("Return JSON only. No markdown, no commentary, no code fences.\n")

	return builder.String()
}

func NormalizeSuggestion(s model.MetadataSuggestion) model.MetadataSuggestion {
	return CanonicalizeSuggestion(s)
}

func ValidateSuggestion(s model.MetadataSuggestion) error {
	if strings.TrimSpace(s.Description) == "" {
		return errors.New("description is empty")
	}
	if len([]rune(s.Description)) > maxDescriptionChars {
		return fmt.Errorf("description is longer than %d characters", maxDescriptionChars)
	}
	if isGenericDescription(s.Description) {
		return errors.New("description is too generic")
	}
	if len(s.Topics) == 0 {
		return errors.New("no topics generated")
	}
	if len(s.Topics) > 10 {
		return errors.New("more than 10 topics generated")
	}
	return nil
}

func FallbackSuggestion(analysis model.RepoAnalysis) model.MetadataSuggestion {
	return NormalizeSuggestion(model.MetadataSuggestion{
		Description: fallbackDescription(analysis),
		Topics:      fallbackTopics(analysis),
	})
}

func collectTexts(snapshot model.RepoSnapshot) []string {
	texts := []string{snapshot.README}
	for _, content := range snapshot.Files {
		texts = append(texts, content)
	}
	return texts
}

func summarizeImportantFiles(files map[string]string) []model.ImportantFile {
	ordered := []string{"package.json", "go.mod", "Cargo.toml", "requirements.txt", "CMakeLists.txt", "pom.xml", "pyproject.toml"}
	summaries := make([]model.ImportantFile, 0, len(files))
	for _, path := range ordered {
		content, ok := files[path]
		if !ok {
			continue
		}
		summary := summarizeFile(path, content)
		if strings.TrimSpace(summary) == "" {
			continue
		}
		summaries = append(summaries, model.ImportantFile{Path: path, Summary: summary})
	}
	return summaries
}

func summarizeFile(path, content string) string {
	switch strings.ToLower(path) {
	case "package.json":
		return summarizePackageJSON(content)
	case "go.mod":
		return summarizeGoMod(content)
	case "cargo.toml":
		return summarizeCargoToml(content)
	case "requirements.txt":
		return summarizeRequirements(content)
	case "cmakelists.txt":
		return summarizeCMake(content)
	case "dockerfile":
		return summarizeDockerfile(content)
	case "pom.xml":
		return summarizePom(content)
	case "pyproject.toml":
		return summarizePyProject(content)
	default:
		return collapseWhitespace(content)
	}
}

func summarizePackageJSON(content string) string {
	var pkg packageJSON
	if err := json.Unmarshal([]byte(content), &pkg); err != nil {
		return "package.json present"
	}

	deps := combineKeys(pkg.Dependencies, pkg.DevDependencies, pkg.PeerDependencies)
	frameworks := collectLabels(strings.ToLower(strings.Join(deps, " ")), frameworkGroups)
	parts := make([]string, 0, 4)
	if pkg.Name != "" {
		parts = append(parts, "name="+pkg.Name)
	}
	if pkg.Description != "" {
		parts = append(parts, "description="+collapseWhitespace(pkg.Description))
	}
	if len(frameworks) > 0 {
		parts = append(parts, "deps="+joinLimited(frameworks, 4))
	} else if len(deps) > 0 {
		parts = append(parts, "deps="+joinLimited(deps, 4))
	}
	if len(pkg.Scripts) > 0 {
		scriptNames := make([]string, 0, len(pkg.Scripts))
		for name := range pkg.Scripts {
			scriptNames = append(scriptNames, name)
		}
		sort.Strings(scriptNames)
		parts = append(parts, "scripts="+joinLimited(scriptNames, 4))
	}
	return strings.Join(parts, "; ")
}

func summarizeGoMod(content string) string {
	lines := strings.Split(content, "\n")
	moduleName := ""
	deps := make([]string, 0, 16)
	for _, rawLine := range lines {
		line := strings.TrimSpace(rawLine)
		if line == "" || strings.HasPrefix(line, "//") || strings.HasPrefix(line, "replace ") {
			continue
		}
		if strings.HasPrefix(line, "module ") {
			moduleName = strings.TrimSpace(strings.TrimPrefix(line, "module "))
			continue
		}
		fields := strings.Fields(line)
		if len(fields) == 0 {
			continue
		}
		candidate := fields[0]
		if strings.Contains(candidate, "/") || strings.Contains(candidate, ".") {
			deps = append(deps, strings.ToLower(candidate))
		}
	}
	frameworks := collectLabels(strings.ToLower(strings.Join(deps, " ")), frameworkGroups)
	parts := make([]string, 0, 3)
	if moduleName != "" {
		parts = append(parts, "module="+moduleName)
	}
	if len(frameworks) > 0 {
		parts = append(parts, "deps="+joinLimited(frameworks, 4))
	} else if len(deps) > 0 {
		parts = append(parts, "deps="+joinLimited(deps, 4))
	}
	return strings.Join(parts, "; ")
}

func summarizeCargoToml(content string) string {
	name := extractRegexValue(content, `(?m)^name\s*=\s*"([^"]+)"`)
	deps := collectKnownPackages(strings.ToLower(content), frameworkGroups)
	parts := make([]string, 0, 3)
	if name != "" {
		parts = append(parts, "crate="+name)
	}
	if len(deps) > 0 {
		parts = append(parts, "deps="+joinLimited(deps, 4))
	}
	return strings.Join(parts, "; ")
}

func summarizeRequirements(content string) string {
	pkgs := extractRequirementsPackages(content)
	deps := collectLabels(strings.ToLower(strings.Join(pkgs, " ")), frameworkGroups)
	parts := make([]string, 0, 2)
	if len(deps) > 0 {
		parts = append(parts, "packages="+joinLimited(deps, 4))
	} else if len(pkgs) > 0 {
		parts = append(parts, "packages="+joinLimited(pkgs, 4))
	}
	return strings.Join(parts, "; ")
}

func summarizeCMake(content string) string {
	projectName := extractRegexValue(content, `(?im)^\s*project\s*\(\s*([A-Za-z0-9_\-]+)`)
	deps := collectKnownPackages(strings.ToLower(content), []keywordGroup{
		{Label: "cmake", Patterns: []string{"cmake"}},
		{Label: "protobuf", Patterns: []string{"protobuf"}},
		{Label: "grpc", Patterns: []string{"grpc"}},
		{Label: "opencv", Patterns: []string{"opencv"}},
		{Label: "qt", Patterns: []string{"qt"}},
		{Label: "boost", Patterns: []string{"boost"}},
	})
	parts := make([]string, 0, 2)
	if projectName != "" {
		parts = append(parts, "project="+projectName)
	}
	if len(deps) > 0 {
		parts = append(parts, "libs="+joinLimited(deps, 4))
	}
	return strings.Join(parts, "; ")
}

func summarizePom(content string) string {
	artifact := extractRegexValue(content, `(?s)<artifactId>([^<]+)</artifactId>`)
	deps := extractPomDependencies(content)
	frameworks := collectLabels(strings.ToLower(strings.Join(deps, " ")), frameworkGroups)
	parts := make([]string, 0, 3)
	if artifact != "" {
		parts = append(parts, "artifact="+artifact)
	}
	if len(frameworks) > 0 {
		parts = append(parts, "deps="+joinLimited(frameworks, 4))
	} else if len(deps) > 0 {
		parts = append(parts, "deps="+joinLimited(deps, 4))
	}
	return strings.Join(parts, "; ")
}

func summarizePyProject(content string) string {
	deps := collectKnownPackages(strings.ToLower(content), frameworkGroups)
	parts := make([]string, 0, 2)
	if len(deps) > 0 {
		parts = append(parts, "deps="+joinLimited(deps, 4))
	}
	return strings.Join(parts, "; ")
}

func summarizeDockerfile(content string) string {
	lines := strings.Split(strings.ReplaceAll(content, "\r\n", "\n"), "\n")
	parts := make([]string, 0, 4)
	for _, rawLine := range lines {
		line := strings.TrimSpace(rawLine)
		if line == "" || strings.HasPrefix(strings.ToLower(line), "#") {
			continue
		}
		lower := strings.ToLower(line)
		if strings.HasPrefix(lower, "from ") {
			fields := strings.Fields(line)
			if len(fields) >= 2 {
				parts = append(parts, fields[1])
			}
		}
		if strings.Contains(lower, "go build") || strings.Contains(lower, "go mod") || strings.Contains(lower, "npm ") || strings.Contains(lower, "yarn ") || strings.Contains(lower, "pip ") {
			parts = appendIfMissing(parts, "build-tools")
		}
		if len(parts) >= 4 {
			break
		}
	}
	return strings.Join(parts, "; ")
}

func summarizeReadme(content string) string {
	content = strings.ReplaceAll(content, "\r\n", "\n")
	lines := strings.Split(content, "\n")
	parts := make([]string, 0, 8)
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if trimmed == "" {
			continue
		}
		if strings.HasPrefix(trimmed, "<!--") || strings.HasPrefix(trimmed, "<img") || strings.HasPrefix(trimmed, "![") || strings.HasPrefix(trimmed, "[!") {
			continue
		}
		if strings.HasPrefix(trimmed, "#") {
			trimmed = strings.TrimSpace(strings.TrimLeft(trimmed, "#"))
		}
		if trimmed == "" {
			continue
		}
		parts = append(parts, trimmed)
		if len(parts) >= 8 || len(strings.Join(parts, " ")) >= 1000 {
			break
		}
	}
	return collapseWhitespace(strings.Join(parts, " "))
}

func detectProjectCategory(language, text string, frameworks, infra, ai []string) string {
	if len(ai) > 0 {
		return "ai/ml"
	}
	if len(infra) > 0 {
		return "infrastructure/devops"
	}
	if containsAny(text, "cli", "command-line", "command line", "terminal", "cobra", "viper") {
		return "cli/tooling"
	}
	if hasAny(frameworks, frontendHints...) && hasAny(frameworks, backendHints...) {
		return "fullstack"
	}
	if hasAny(frameworks, frontendHints...) {
		return "frontend"
	}
	if hasAny(frameworks, backendHints...) {
		return "backend/service"
	}
	if containsAny(text, "sdk", "library", "package", "module", "client", "adapter", "plugin") {
		return "library/sdk"
	}
	if containsAny(text, "data science", "jupyter", "notebook", "pandas", "numpy", "matplotlib") {
		return "data science"
	}
	if strings.TrimSpace(language) != "" {
		return strings.ToLower(language) + " project"
	}
	return "software project"
}

func detectBackendFrontend(language, text string, frameworks, infra, ai []string, category string) string {
	switch {
	case len(ai) > 0:
		return "ml"
	case len(infra) > 0:
		return "infra"
	case category == "cli/tooling":
		return "cli"
	case category == "frontend":
		return "frontend"
	case category == "backend/service":
		return "backend"
	case category == "fullstack":
		return "fullstack"
	case category == "library/sdk":
		return "library"
	case strings.Contains(strings.ToLower(language), "python") && containsAny(text, "fastapi", "django", "flask"):
		return "backend"
	default:
		if hasAny(frameworks, frontendHints...) {
			return "frontend"
		}
		if hasAny(frameworks, backendHints...) {
			return "backend"
		}
		return "unknown"
	}
}

func fallbackDescription(analysis model.RepoAnalysis) string {
	language := titleCaseLanguage(analysis.PrimaryLanguage)
	category := humanizeCategory(analysis.ProjectCategory)
	if category == "" || category == "unknown" {
		category = humanizeCategory(analysis.BackendFrontend)
	}
	category = professionalizeCategoryLabel(category)
	if category == "" || category == "unknown" {
		category = "software project"
	}

	parts := make([]string, 0, 4)
	if language != "" {
		parts = append(parts, language)
	}
	parts = append(parts, category)
	if len(analysis.Frameworks) > 0 {
		parts = append(parts, "with "+joinLimited(analysis.Frameworks, 2))
	}

	description := collapseWhitespace(strings.Join(parts, " "))
	if len([]rune(description)) > maxDescriptionChars {
		description = truncateToRuneLimit(description, maxDescriptionChars)
	}
	return description
}

func fallbackTopics(analysis model.RepoAnalysis) []string {
	topics := make([]string, 0, 10)
	add := func(values ...string) {
		for _, value := range values {
			topic := normalizeTopic(value)
			if topic == "" || containsString(topics, topic) {
				continue
			}
			topics = append(topics, topic)
			if len(topics) == 10 {
				return
			}
		}
	}

	add(languageTopic(analysis.PrimaryLanguage))
	add(analysis.Frameworks...)
	add(analysis.Infrastructure...)
	add(analysis.AITools...)
	add(analysis.BackendFrontend)
	add(analysis.ProjectCategory)
	return topics
}

func normalizeTopics(topics []string) []string {
	seen := make(map[string]struct{}, len(topics))
	out := make([]string, 0, len(topics))
	for _, topic := range topics {
		normalized := normalizeTopic(topic)
		if normalized == "" {
			continue
		}
		if _, generic := genericTopicBlacklist[normalized]; generic {
			continue
		}
		if _, blacklisted := topicQualityBlacklist[normalized]; blacklisted {
			continue
		}
		if _, ok := seen[normalized]; ok {
			continue
		}
		seen[normalized] = struct{}{}
		out = append(out, normalized)
		if len(out) == 10 {
			break
		}
	}
	return out
}

func normalizeTopic(topic string) string {
	topic = strings.ToLower(strings.TrimSpace(topic))
	if topic == "" {
		return ""
	}
	topic = strings.ReplaceAll(topic, "_", "-")
	topic = strings.ReplaceAll(topic, " ", "-")
	topic = regexp.MustCompile(`[^a-z0-9+#.-]+`).ReplaceAllString(topic, "-")
	topic = regexp.MustCompile(`-+`).ReplaceAllString(topic, "-")
	topic = strings.Trim(topic, "-")
	if alias, ok := topicAliases[topic]; ok {
		topic = alias
	}
	if len(topic) > 50 {
		topic = strings.Trim(strings.TrimSpace(topic[:50]), "-")
	}
	return topic
}

func languageTopic(language string) string {
	switch strings.ToLower(strings.TrimSpace(language)) {
	case "go":
		return "golang"
	case "javascript":
		return "javascript"
	case "typescript":
		return "typescript"
	case "python":
		return "python"
	case "rust":
		return "rust"
	case "java":
		return "java"
	case "c++":
		return "cpp"
	case "c#":
		return "csharp"
	default:
		return normalizeTopic(language)
	}
}

func titleCaseLanguage(language string) string {
	language = strings.TrimSpace(language)
	if language == "" {
		return ""
	}
	switch strings.ToLower(language) {
	case "go":
		return "Go"
	case "javascript":
		return "JavaScript"
	case "typescript":
		return "TypeScript"
	case "c++":
		return "C++"
	case "c#":
		return "C#"
	default:
		return strings.ToUpper(string(language[0])) + language[1:]
	}
}

func humanizeCategory(category string) string {
	category = strings.ToLower(strings.TrimSpace(category))
	category = strings.ReplaceAll(category, "_", " ")
	category = strings.ReplaceAll(category, "/", " ")
	return collapseWhitespace(category)
}

func professionalizeCategoryLabel(category string) string {
	category = strings.TrimSpace(category)
	if category == "" {
		return ""
	}
	switch strings.ToLower(category) {
	case "ai ml":
		return "AI/ML"
	case "cli tooling":
		return "CLI tooling"
	case "library sdk":
		return "library/SDK"
	case "infrastructure devops":
		return "infrastructure/DevOps"
	default:
		return category
	}
}

func isGenericDescription(description string) bool {
	lower := strings.ToLower(collapseWhitespace(description))
	if lower == "" {
		return true
	}

	genericPhrases := []string{
		"repository",
		"project",
		"code repository",
		"sample project",
		"example project",
		"demo project",
		"personal project",
		"my project",
		"application",
		"app",
		"tool",
		"utility",
		"library",
		"service",
		"source code",
		"awesome project",
	}
	for _, phrase := range genericPhrases {
		if lower == phrase {
			return true
		}
	}
	for _, word := range buzzwordBlacklist {
		if containsWord(lower, word) {
			return true
		}
	}
	for _, word := range descriptionTopicBlacklist {
		if containsWord(lower, word) {
			return true
		}
	}

	meaningfulSignals := []string{"go", "golang", "rust", "python", "typescript", "javascript", "react", "next", "vite", "fastapi", "docker", "kubernetes", "terraform", "grpc", "cobra", "viper", "ai", "ml", "llm", "cli", "backend", "frontend", "fullstack"}
	for _, signal := range meaningfulSignals {
		if strings.Contains(lower, signal) {
			return false
		}
	}

	return len(strings.Fields(lower)) <= 3
}

func containsWord(text, word string) bool {
	text = strings.ToLower(text)
	word = strings.ToLower(strings.TrimSpace(word))
	if text == "" || word == "" {
		return false
	}
	if strings.ContainsAny(word, ".-+#/") {
		return strings.Contains(text, word)
	}
	for _, token := range strings.FieldsFunc(text, func(r rune) bool {
		return !unicode.IsLetter(r) && !unicode.IsDigit(r)
	}) {
		if token == word {
			return true
		}
	}
	return false
}

func collectLabels(text string, groups []keywordGroup) []string {
	results := make([]string, 0, len(groups))
	for _, group := range groups {
		for _, pattern := range group.Patterns {
			if strings.Contains(text, strings.ToLower(pattern)) {
				results = appendIfMissing(results, group.Label)
				break
			}
		}
	}
	return results
}

func collectKnownPackages(text string, groups []keywordGroup) []string {
	labels := collectLabels(text, groups)
	if len(labels) > 0 {
		return labels
	}
	return nil
}

func appendIfMissing(values []string, value string) []string {
	if value == "" || containsString(values, value) {
		return values
	}
	return append(values, value)
}

func containsString(values []string, candidate string) bool {
	for _, value := range values {
		if value == candidate {
			return true
		}
	}
	return false
}

func hasAny(values []string, candidates ...string) bool {
	for _, candidate := range candidates {
		if containsString(values, normalizeTopic(candidate)) || containsString(values, candidate) {
			return true
		}
	}
	return false
}

func containsAny(text string, candidates ...string) bool {
	lower := strings.ToLower(text)
	for _, candidate := range candidates {
		if strings.Contains(lower, strings.ToLower(candidate)) {
			return true
		}
	}
	return false
}

func collapseWhitespace(value string) string {
	return strings.Join(strings.Fields(value), " ")
}

func truncateToRuneLimit(value string, limit int) string {
	if limit <= 0 {
		return ""
	}
	runes := []rune(value)
	if len(runes) <= limit {
		return value
	}
	return strings.TrimSpace(string(runes[:limit]))
}

func joinLimited(values []string, limit int) string {
	if len(values) == 0 {
		return ""
	}
	if limit > 0 && len(values) > limit {
		values = values[:limit]
	}
	return strings.Join(values, ", ")
}

func formatJSONArray(values []string) string {
	if len(values) == 0 {
		return "[]"
	}
	quoted := make([]string, 0, len(values))
	for _, value := range values {
		quoted = append(quoted, fmt.Sprintf("%q", value))
	}
	return "[" + strings.Join(quoted, ", ") + "]"
}

func valueOrPlaceholder(value string) string {
	if strings.TrimSpace(value) == "" {
		return "none"
	}
	return collapseWhitespace(value)
}

func combineKeys(maps ...map[string]string) []string {
	seen := map[string]struct{}{}
	keys := make([]string, 0, 16)
	for _, m := range maps {
		for key := range m {
			candidate := strings.ToLower(strings.TrimSpace(key))
			if candidate == "" {
				continue
			}
			if _, ok := seen[candidate]; ok {
				continue
			}
			seen[candidate] = struct{}{}
			keys = append(keys, candidate)
		}
	}
	sort.Strings(keys)
	return keys
}

func extractRegexValue(content, pattern string) string {
	matches := regexp.MustCompile(pattern).FindStringSubmatch(content)
	if len(matches) < 2 {
		return ""
	}
	return strings.TrimSpace(matches[1])
}

func extractRequirementsPackages(content string) []string {
	lines := strings.Split(content, "\n")
	packages := make([]string, 0, 16)
	for _, rawLine := range lines {
		line := strings.TrimSpace(rawLine)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		line = strings.Split(line, ";")[0]
		line = strings.Split(line, "#")[0]
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		parts := strings.FieldsFunc(line, func(r rune) bool {
			return r == '=' || r == '>' || r == '<' || r == '!' || r == '[' || r == ']'
		})
		if len(parts) == 0 {
			continue
		}
		pkg := strings.Trim(strings.TrimSpace(parts[0]), `"'`)
		if pkg == "" {
			continue
		}
		packages = append(packages, strings.ToLower(pkg))
	}
	return packages
}

func extractPomDependencies(content string) []string {
	matches := regexp.MustCompile(`(?s)<dependency>.*?<artifactId>([^<]+)</artifactId>.*?</dependency>`).FindAllStringSubmatch(content, -1)
	deps := make([]string, 0, len(matches))
	for _, match := range matches {
		if len(match) < 2 {
			continue
		}
		deps = append(deps, strings.ToLower(strings.TrimSpace(match[1])))
	}
	return deps
}
