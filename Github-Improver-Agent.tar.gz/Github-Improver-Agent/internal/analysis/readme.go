package analysis

import (
	"sort"
	"strings"

	"go-description-script/internal/model"
)

type ReadmePreview struct {
	Current        string   `json:"current"`
	Generated      string   `json:"generated"`
	Diff           string   `json:"diff"`
	SectionChanges []string `json:"section_changes"`
	QualityScore   float64  `json:"quality_score"`
	EnhanceMode    bool     `json:"enhance_mode"`
	SafeToWrite    bool     `json:"safe_to_write"`
}

func ScoreReadmeQuality(readme string, repo model.RepoAnalysis) float64 {
	text := strings.TrimSpace(readme)
	if text == "" {
		return 0.15
	}
	lines := strings.Split(text, "\n")
	headings := 0
	setupHints := 0
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "#") {
			headings++
		}
		if strings.Contains(strings.ToLower(trimmed), "setup") || strings.Contains(strings.ToLower(trimmed), "usage") {
			setupHints++
		}
	}
	score := 0.2
	if len(lines) > 12 {
		score += 0.2
	}
	if headings > 0 {
		score += 0.15
	}
	if headings > 2 {
		score += 0.1
	}
	if setupHints > 0 {
		score += 0.12
	}
	if len(repo.Frameworks) > 0 || len(repo.Infrastructure) > 0 {
		score += 0.08
	}
	if len(repo.ImportantFiles) > 0 {
		score += 0.08
	}
	if len([]rune(text)) > 2000 {
		score += 0.07
	}
	if score > 1 {
		score = 1
	}
	return score
}

func GenerateReadme(current string, repo model.RepoAnalysis, manifest model.RepoManifest) ReadmePreview {
	quality := ScoreReadmeQuality(current, repo)
	generated := buildReadme(repo, manifest)
	enhanceMode := quality >= 0.65 && strings.TrimSpace(current) != ""
	final := generated
	if enhanceMode {
		final = enhanceCurrentReadme(current, generated)
	}
	return ReadmePreview{
		Current:        current,
		Generated:      final,
		Diff:           DiffMarkdown(current, final),
		SectionChanges: diffSections(current, final),
		QualityScore:   quality,
		EnhanceMode:    enhanceMode,
		SafeToWrite:    quality < 0.9 || strings.TrimSpace(current) != strings.TrimSpace(final),
	}
}

func DiffMarkdown(current, generated string) string {
	currentLines := strings.Split(strings.TrimSpace(current), "\n")
	generatedLines := strings.Split(strings.TrimSpace(generated), "\n")
	maxLines := len(currentLines)
	if len(generatedLines) > maxLines {
		maxLines = len(generatedLines)
	}
	var builder strings.Builder
	for index := 0; index < maxLines; index++ {
		var left, right string
		if index < len(currentLines) {
			left = currentLines[index]
		}
		if index < len(generatedLines) {
			right = generatedLines[index]
		}
		switch {
		case left == right:
			builder.WriteString("  ")
			builder.WriteString(left)
		case left == "":
			builder.WriteString("+ ")
			builder.WriteString(right)
		case right == "":
			builder.WriteString("- ")
			builder.WriteString(left)
		default:
			builder.WriteString("- ")
			builder.WriteString(left)
			builder.WriteString("\n+ ")
			builder.WriteString(right)
		}
		if index < maxLines-1 {
			builder.WriteString("\n")
		}
	}
	return builder.String()
}

func buildReadme(repo model.RepoAnalysis, manifest model.RepoManifest) string {
	var builder strings.Builder
	title := firstNonEmpty(manifest.Name, repo.Name, manifest.FullName)
	builder.WriteString("# ")
	builder.WriteString(title)
	builder.WriteString("\n\n")
	builder.WriteString(summarySentence(repo, manifest))
	builder.WriteString("\n\n")
	writeSection(&builder, "Overview", []string{firstNonEmpty(repo.ProjectIntent, repo.ProjectCategory, repo.EngineeringDomain, "Repository generated from source signals.")})
	writeSection(&builder, "Architecture", []string{firstNonEmpty(repo.ArchitectureStyle, "single-service")})
	writeSection(&builder, "Tech Stack", uniqueStrings(append(append([]string{}, repo.Frameworks...), repo.Infrastructure...)))
	writeSection(&builder, "APIs", uniqueStrings(repo.APIs))
	writeSection(&builder, "Repository Structure", importantFileLines(repo.ImportantFiles))
	writeSection(&builder, "Setup", []string{"Install the detected runtime and dependencies.", "Review environment variables before running local workflows."})
	writeSection(&builder, "Usage", []string{firstNonEmpty(repo.ProjectIntent, "Run the primary entrypoint and verify repository metadata or application output.")})
	writeSection(&builder, "Documentation", []string{"Preview changes before writeback.", "Preserve strong existing README sections when enhancing."})
	return strings.TrimSpace(builder.String()) + "\n"
}

func enhanceCurrentReadme(current, generated string) string {
	if strings.TrimSpace(current) == "" {
		return generated
	}
	currentSections := splitSections(current)
	generatedSections := splitSections(generated)
	for title, body := range generatedSections {
		if _, ok := currentSections[title]; !ok {
			currentSections[title] = body
		}
	}
	return joinSections(currentSections)
}

func diffSections(current, generated string) []string {
	left := splitSections(current)
	right := splitSections(generated)
	changes := make([]string, 0, len(right))
	for title := range right {
		if _, ok := left[title]; !ok {
			changes = append(changes, title)
		}
	}
	sort.Strings(changes)
	return changes
}

func splitSections(markdown string) map[string]string {
	sections := map[string]string{}
	currentTitle := ""
	currentBody := make([]string, 0, 32)
	flush := func() {
		if currentTitle != "" {
			sections[currentTitle] = strings.TrimSpace(strings.Join(currentBody, "\n"))
		}
	}
	for _, line := range strings.Split(markdown, "\n") {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "## ") || strings.HasPrefix(trimmed, "# ") {
			flush()
			currentTitle = trimmed
			currentBody = currentBody[:0]
			continue
		}
		currentBody = append(currentBody, line)
	}
	flush()
	return sections
}

func joinSections(sections map[string]string) string {
	keys := make([]string, 0, len(sections))
	for key := range sections {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	var builder strings.Builder
	for _, key := range keys {
		builder.WriteString(key)
		builder.WriteString("\n")
		if body := strings.TrimSpace(sections[key]); body != "" {
			builder.WriteString(body)
			builder.WriteString("\n")
		}
		builder.WriteString("\n")
	}
	return strings.TrimSpace(builder.String()) + "\n"
}

func writeSection(builder *strings.Builder, title string, lines []string) {
	if len(lines) == 0 {
		return
	}
	builder.WriteString("## ")
	builder.WriteString(title)
	builder.WriteString("\n")
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if trimmed == "" {
			continue
		}
		builder.WriteString("- ")
		builder.WriteString(trimmed)
		builder.WriteString("\n")
	}
	builder.WriteString("\n")
}

func summarySentence(repo model.RepoAnalysis, manifest model.RepoManifest) string {
	parts := make([]string, 0, 4)
	if strings.TrimSpace(manifest.Description) != "" {
		parts = append(parts, strings.TrimSpace(manifest.Description))
	}
	if strings.TrimSpace(repo.ProjectCategory) != "" {
		parts = append(parts, repo.ProjectCategory)
	}
	if strings.TrimSpace(repo.DeploymentModel) != "" {
		parts = append(parts, repo.DeploymentModel)
	}
	if strings.TrimSpace(repo.BackendFrontend) != "" {
		parts = append(parts, repo.BackendFrontend)
	}
	if len(parts) == 0 {
		return "Repository documentation generated from detected source signals."
	}
	return strings.Join(parts, " • ")
}

func importantFileLines(files []model.ImportantFile) []string {
	lines := make([]string, 0, len(files))
	for _, file := range files {
		if strings.TrimSpace(file.Path) == "" {
			continue
		}
		line := file.Path
		if strings.TrimSpace(file.Summary) != "" {
			line += " - " + strings.TrimSpace(file.Summary)
		}
		lines = append(lines, line)
	}
	return lines
}

func uniqueStrings(values []string) []string {
	seen := make(map[string]struct{}, len(values))
	out := make([]string, 0, len(values))
	for _, value := range values {
		candidate := strings.TrimSpace(value)
		if candidate == "" {
			continue
		}
		if _, ok := seen[candidate]; ok {
			continue
		}
		seen[candidate] = struct{}{}
		out = append(out, candidate)
	}
	return out
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}
