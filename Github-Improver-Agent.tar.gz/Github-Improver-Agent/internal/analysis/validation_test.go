package analysis

import (
	"reflect"
	"strings"
	"testing"

	"go-description-script/internal/model"

	"github.com/google/go-github/v86/github"
)

func TestCanonicalizeSuggestion_NormalizesAliasesAndRemovesGenericTopics(t *testing.T) {
	t.Parallel()

	suggestion := model.MetadataSuggestion{
		Description: "  Distributed job scheduler written in Go  ",
		Topics:      []string{"C++", "cplusplus", "node", "js", "k8s", "web", "backend", " sample ", "machine learning", "ml"},
	}

	got := CanonicalizeSuggestion(suggestion)
	wantTopics := []string{"cpp", "nodejs", "javascript", "kubernetes", "machine-learning"}

	if got.Description != "Distributed job scheduler written in Go" {
		t.Fatalf("CanonicalizeSuggestion description = %q, want %q", got.Description, "Distributed job scheduler written in Go")
	}
	if !reflect.DeepEqual(got.Topics, wantTopics) {
		t.Fatalf("CanonicalizeSuggestion topics = %#v, want %#v", got.Topics, wantTopics)
	}
}

func TestValidateMetadata_FiltersBlacklistedTopics(t *testing.T) {
	t.Parallel()

	repo := RepoAnalysis{
		Owner:                "octo",
		Name:                 "task-scheduler",
		FullName:             "octo/task-scheduler",
		Description:          "Distributed job scheduler written in Go",
		PrimaryLanguage:      "Go",
		DetectedTechnologies: []string{"go", "redis", "docker"},
		DetectedTopics:       []string{"scheduler", "queue", "automation", "go", "redis", "docker"},
	}
	snapshot := model.RepoSnapshot{
		README: "Distributed job scheduler using Redis queues and automation workflows.",
		Files: map[string]string{
			"go.mod":       "module example\nrequire github.com/redis/go-redis/v9 v9.0.0\n",
			"Dockerfile":   "FROM golang:1.22\n",
			"package.json": "{\"name\":\"task-scheduler\"}",
		},
	}
	suggestion := model.MetadataSuggestion{
		Description: "Distributed job scheduler written in Go using Redis queues",
		Topics:      []string{"go", "redis", "backend", "demo", "web", "queue", "scheduler"},
	}

	got, err := ValidateMetadata(repo, snapshot, suggestion)
	if err != nil {
		t.Fatalf("ValidateMetadata returned error: %v", err)
	}

	wantTopics := []string{"go", "redis", "queue", "scheduler"}
	if !reflect.DeepEqual(got.Suggestion.Topics, wantTopics) {
		t.Fatalf("validated topics = %#v, want %#v", got.Suggestion.Topics, wantTopics)
	}
	if strings.Contains(strings.Join(got.Suggestion.Topics, ","), "backend") {
		t.Fatalf("validated topics unexpectedly kept a generic backend topic: %#v", got.Suggestion.Topics)
	}
}

func TestValidateMetadata_RejectsBuzzwordDescription(t *testing.T) {
	t.Parallel()

	repo := RepoAnalysis{
		Owner:           "octo",
		Name:            "task-scheduler",
		FullName:        "octo/task-scheduler",
		PrimaryLanguage: "Go",
		DetectedTopics:  []string{"scheduler", "go"},
	}
	snapshot := model.RepoSnapshot{
		README: "Distributed job scheduler written in Go.",
		Files: map[string]string{
			"go.mod": "module example\n",
		},
	}
	suggestion := model.MetadataSuggestion{
		Description: "Modern scalable backend system for distributed job scheduling",
		Topics:      []string{"go", "scheduler"},
	}

	result, err := ValidateMetadata(repo, snapshot, suggestion)
	if err != nil {
		t.Fatalf("ValidateMetadata returned error: %v", err)
	}
	if result.DescriptionValid {
		t.Fatalf("ValidateMetadata unexpectedly accepted buzzword-heavy description: %#v", result)
	}
	if len(result.Warnings) == 0 {
		t.Fatalf("ValidateMetadata did not emit warnings for buzzword-heavy description")
	}
}

func TestValidateMetadata_AllowsEmptyTopicsWithWarning(t *testing.T) {
	t.Parallel()

	repo := RepoAnalysis{
		Owner:                "octo",
		Name:                 "demo-repo",
		FullName:             "octo/demo-repo",
		Description:          "Command-line helper for demos",
		PrimaryLanguage:      "Go",
		DetectedTechnologies: []string{"go"},
		DetectedTopics:       []string{"cli", "go"},
	}
	snapshot := model.RepoSnapshot{
		README: "Demo repository showcasing a small CLI tool.",
		Files: map[string]string{
			"go.mod": "module example\n",
		},
	}
	suggestion := model.MetadataSuggestion{
		Description: "Go CLI helper for demos",
		Topics:      []string{"web", "demo"},
	}

	result, err := ValidateMetadata(repo, snapshot, suggestion)
	if err != nil {
		t.Fatalf("ValidateMetadata returned error: %v", err)
	}
	if result.TopicsValid {
		t.Fatalf("expected TopicsValid=false when all topics are filtered")
	}
	if len(result.ValidatedTopics) != 0 {
		t.Fatalf("expected empty validated topics, got %#v", result.ValidatedTopics)
	}
	if len(result.Warnings) == 0 {
		t.Fatalf("expected validation warnings when topics are empty")
	}
}

func TestValidateMetadata_RejectsNegativeDescriptions(t *testing.T) {
	t.Parallel()

	repo := RepoAnalysis{
		Owner:                "octo",
		Name:                 "placeholder",
		FullName:             "octo/placeholder",
		Description:          "",
		PrimaryLanguage:      "TypeScript",
		DetectedTechnologies: []string{"typescript"},
		DetectedTopics:       []string{"typescript"},
	}
	snapshot := model.RepoSnapshot{
		README: "Small TypeScript project scaffold.",
		Files: map[string]string{
			"package.json": "{\"name\":\"placeholder\"}",
		},
	}
	suggestion := model.MetadataSuggestion{
		Description: "Provides no functionality; a placeholder TypeScript repository.",
		Topics:      []string{"typescript"},
	}

	result, err := ValidateMetadata(repo, snapshot, suggestion)
	if err != nil {
		t.Fatalf("ValidateMetadata returned error: %v", err)
	}
	if strings.Contains(strings.ToLower(result.ValidatedDescription), "placeholder") {
		t.Fatalf("expected placeholder language to be removed, got %q", result.ValidatedDescription)
	}
	if len(result.Warnings) == 0 {
		t.Fatalf("expected warnings for negative description")
	}
}

func TestScoreConfidence_UsesNeutralDefaults(t *testing.T) {
	t.Parallel()

	repo := RepoAnalysis{
		Owner:           "octo",
		Name:            "tiny-cli",
		FullName:        "octo/tiny-cli",
		PrimaryLanguage: "Go",
	}
	snapshot := model.RepoSnapshot{
		README: "",
		Files:  map[string]string{},
	}
	score := ScoreConfidence(repo, snapshot, model.MetadataSuggestion{}, nil, map[string]struct{}{})

	if score.ReadmeQuality != 0.5 {
		t.Fatalf("readme quality = %v, want neutral default 0.5", score.ReadmeQuality)
	}
	if score.FileCoverage != 0.5 {
		t.Fatalf("file coverage = %v, want neutral default 0.5", score.FileCoverage)
	}
	if score.TechnologyAccuracy != 0.5 {
		t.Fatalf("technology accuracy = %v, want neutral default 0.5", score.TechnologyAccuracy)
	}
	if score.MetadataScore != 0.5 {
		t.Fatalf("metadata score = %v, want neutral default 0.5", score.MetadataScore)
	}
	if score.MetadataConfidence != 0.5 {
		t.Fatalf("metadata confidence = %v, want neutral default 0.5", score.MetadataConfidence)
	}
}

func TestScoreConfidence_FavorsSmallRepoSignals(t *testing.T) {
	t.Parallel()

	repo := RepoAnalysis{
		Owner:                "octo",
		Name:                 "tiny-cli",
		FullName:             "octo/tiny-cli",
		PrimaryLanguage:      "Go",
		DetectedTechnologies: []string{"go"},
		DetectedTopics:       []string{"cli", "go"},
	}
	snapshot := model.RepoSnapshot{
		README: "",
		Files: map[string]string{
			"go.mod":  "module example\n",
			"main.go": "package main\nfunc main(){}\n",
		},
	}
	suggestion := model.MetadataSuggestion{
		Description: "Go CLI for repository metadata updates",
		Topics:      []string{"go", "cli"},
	}
	allowed := allowedTopicSet(repo, snapshot)
	score := ScoreConfidence(repo, snapshot, suggestion, suggestion.Topics, allowed)

	if score.ReadmeQuality < 0.5 {
		t.Fatalf("readme quality = %v, want neutral or better", score.ReadmeQuality)
	}
	if score.FileCoverage <= 0.5 {
		t.Fatalf("file coverage = %v, want source-aware boost", score.FileCoverage)
	}
	if score.TechnologyAccuracy <= 0.85 {
		t.Fatalf("technology accuracy = %v, want strong tech detection", score.TechnologyAccuracy)
	}
	if score.MetadataConfidence < 0.45 {
		t.Fatalf("metadata confidence = %v, want to clear the default threshold", score.MetadataConfidence)
	}
}

func TestAnalyze_DetectsExplicitTechnologies(t *testing.T) {
	t.Parallel()

	analyzer := New()
	repo := &github.Repository{
		Name:        github.Ptr("scheduler"),
		FullName:    github.Ptr("octo/scheduler"),
		Description: github.Ptr("Distributed job scheduler"),
		Language:    github.Ptr("Go"),
		Owner:       &github.User{Login: github.Ptr("octo")},
	}
	snapshot := model.RepoSnapshot{
		README: "Distributed job scheduler using Redis queues and Docker.",
		Files: map[string]string{
			"go.mod":           "module example\nrequire github.com/redis/go-redis/v9 v9.0.0\n",
			"Dockerfile":       "FROM golang:1.22\n",
			"requirements.txt": "redis\n",
		},
	}

	got := analyzer.Analyze(repo, snapshot)
	if got.PrimaryLanguage != "Go" {
		t.Fatalf("PrimaryLanguage = %q, want Go", got.PrimaryLanguage)
	}
	if !containsString(got.DetectedTechnologies, "go") {
		t.Fatalf("DetectedTechnologies missing go: %#v", got.DetectedTechnologies)
	}
	if !containsString(got.DetectedTechnologies, "redis") {
		t.Fatalf("DetectedTechnologies missing redis: %#v", got.DetectedTechnologies)
	}
	if !containsString(got.DetectedTechnologies, "docker") {
		t.Fatalf("DetectedTechnologies missing docker: %#v", got.DetectedTechnologies)
	}
	if containsString(got.DetectedTechnologies, "web") {
		t.Fatalf("DetectedTechnologies unexpectedly contained a generic topic: %#v", got.DetectedTechnologies)
	}
}

func TestDetectPrimaryLanguage_PrefersCPlusPlus(t *testing.T) {
	t.Parallel()

	snapshot := model.RepoSnapshot{
		Files: map[string]string{
			"CMakeLists.txt": "cmake_minimum_required(VERSION 3.22)\nproject(example CXX)\nfind_package(Boost REQUIRED)\n",
		},
	}

	got := detectPrimaryLanguage(snapshot, "C")
	if got != "C++" {
		t.Fatalf("detectPrimaryLanguage returned %q, want C++", got)
	}
}
