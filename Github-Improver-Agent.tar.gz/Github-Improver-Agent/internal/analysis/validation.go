package analysis

import (
	"fmt"
	"math"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"unicode"

	"go-description-script/internal/model"
)

type RepoAnalysis = model.RepoAnalysis

var topicAliases = map[string]string{
	"c++":        "cpp",
	"cplusplus":  "cpp",
	"node":       "nodejs",
	"golang":     "go",
	"js":         "javascript",
	"ts":         "typescript",
	"k8s":        "kubernetes",
	"ml":         "machine-learning",
	"ai-ml":      "machine-learning",
	"c#":         "csharp",
	"nodejs":     "nodejs",
	"next.js":    "nextjs",
	"postgres":   "postgresql",
	"postgresql": "postgresql",
}

var genericTopicBlacklist = map[string]struct{}{
	"web":      {},
	"app":      {},
	"backend":  {},
	"frontend": {},
}

var topicQualityBlacklist = map[string]struct{}{
	"demo":        {},
	"starter":     {},
	"test":        {},
	"example":     {},
	"sample":      {},
	"boilerplate": {},
}

var buzzwordBlacklist = []string{
	"modern",
	"powerful",
	"scalable",
	"lightweight",
	"robust",
	"enterprise-grade",
	"cutting-edge",
}

var descriptionTopicBlacklist = []string{
	"demo",
	"starter",
	"test",
	"example",
	"sample",
	"boilerplate",
}

var negativeDescriptionPhrases = []string{
	"no functionality",
	"no functional",
	"placeholder",
	"empty",
	"nothing here",
	"work in progress",
	"wip",
	"unfinished",
	"abandoned",
	"deprecated",
	"temporary",
	"stub",
	"dummy",
}

type descriptionReplacement struct {
	pattern     *regexp.Regexp
	replacement string
}

var descriptionReplacements = []descriptionReplacement{
	{pattern: regexp.MustCompile(`(?i)\bai\s*ml\b`), replacement: "AI/ML"},
	{pattern: regexp.MustCompile(`(?i)\bjupyter\s+notebook(s)?\b`), replacement: "Jupyter Notebook$1"},
	{pattern: regexp.MustCompile(`(?i)\bapi\b`), replacement: "API"},
}

var knownTechnologyMentions = []string{
	"go",
	"golang",
	"node",
	"nodejs",
	"javascript",
	"typescript",
	"python",
	"rust",
	"java",
	"cpp",
	"c++",
	"csharp",
	"react",
	"nextjs",
	"next.js",
	"vue",
	"svelte",
	"angular",
	"vite",
	"astro",
	"express",
	"nestjs",
	"fastify",
	"gin",
	"echo",
	"fiber",
	"grpc",
	"clap",
	"tokio",
	"axum",
	"actix-web",
	"rocket",
	"fastapi",
	"django",
	"flask",
	"pytorch",
	"tensorflow",
	"scikit-learn",
	"sklearn",
	"langchain",
	"llamaindex",
	"huggingface",
	"docker",
	"docker-compose",
	"kubernetes",
	"terraform",
	"ansible",
	"helm",
	"pulumi",
	"argocd",
	"cloudformation",
	"kustomize",
	"redis",
	"postgresql",
	"mysql",
	"sqlite",
	"mongodb",
	"kafka",
	"rabbitmq",
	"elasticsearch",
	"prometheus",
	"grafana",
	"protobuf",
	"graphql",
	"oauth",
	"jwt",
}

var domainTopicGroups = []keywordGroup{
	{Label: "cli", Patterns: []string{"cli", "command line", "command-line", "terminal app"}},
	{Label: "api", Patterns: []string{"api", "rest api", "http api", "graphql api"}},
	{Label: "scheduler", Patterns: []string{"scheduler", "job scheduler", "task scheduler"}},
	{Label: "queue", Patterns: []string{"queue", "queues", "job queue", "task queue"}},
	{Label: "automation", Patterns: []string{"automation", "automate", "workflow automation"}},
	{Label: "monitoring", Patterns: []string{"monitoring", "observability", "metrics", "telemetry", "logging"}},
	{Label: "database", Patterns: []string{"database", "databases", "data store", "persistence"}},
	{Label: "search", Patterns: []string{"search", "indexing", "retrieval"}},
	{Label: "crawler", Patterns: []string{"crawler", "scraper", "scraping"}},
	{Label: "parser", Patterns: []string{"parser", "parsing", "lexer", "compiler"}},
	{Label: "formatter", Patterns: []string{"formatter", "formatting", "lint", "linter"}},
	{Label: "plugin", Patterns: []string{"plugin", "extension", "extensions"}},
	{Label: "bot", Patterns: []string{"bot", "assistant", "automation bot"}},
	{Label: "webhook", Patterns: []string{"webhook", "webhooks"}},
	{Label: "microservice", Patterns: []string{"microservice", "microservices", "service mesh"}},
	{Label: "fullstack", Patterns: []string{"fullstack", "full stack"}},
	{Label: "frontend", Patterns: []string{"frontend", "front-end", "ui"}},
	{Label: "backend", Patterns: []string{"backend", "back-end", "server"}},
	{Label: "library", Patterns: []string{"library", "sdk", "client library"}},
	{Label: "devops", Patterns: []string{"devops", "infrastructure", "infra", "ci/cd", "ci cd"}},
	{Label: "data-pipeline", Patterns: []string{"data pipeline", "etl", "extract transform load"}},
	{Label: "machine-learning", Patterns: []string{"machine learning", "ml", "ai", "artificial intelligence", "llm", "embedding", "embeddings"}},
}

type ValidationResult struct {
	DescriptionValid     bool
	TopicsValid          bool
	ValidatedDescription string
	ValidatedTopics      []string
	Warnings             []string
	Suggestion           model.MetadataSuggestion
	Confidence           model.ConfidenceScore
	ConfidenceValue      float64
	CurrentDescription   string
	CurrentTopics        []string
	GeneratedDescription string
	GeneratedTopics      []string
	AddedTopics          []string
	RemovedTopics        []string
	AllowedTopics        []string
	CacheHit             bool
}

const neutralConfidenceScore = 0.5

func ValidateMetadata(repo RepoAnalysis, snapshot model.RepoSnapshot, suggestion model.MetadataSuggestion) (ValidationResult, error) {
	normalized := CanonicalizeSuggestion(suggestion)
	warnings := make([]string, 0, 4)
	allowedTopics := allowedTopicSet(repo, snapshot)
	filteredTopics := filterTopics(repo, snapshot, normalized.Topics, allowedTopics)
	topicsValid := len(filteredTopics) > 0
	if !topicsValid {
		warnings = append(warnings, "no valid topics remain after validation")
	}

	description := normalized.Description
	validatedDescription, err := validateDescription(repo, snapshot, normalized.Description)
	descriptionValid := err == nil
	if err != nil {
		warnings = append(warnings, err.Error())
		fallback := fallbackDescription(repo)
		if fallback != "" {
			fallbackDescription, fallbackErr := validateDescription(repo, snapshot, fallback)
			if fallbackErr == nil {
				validatedDescription = fallbackDescription
				warnings = append(warnings, "used fallback description after validation failure")
			}
		}
	}
	if validatedDescription != "" {
		description = validatedDescription
	}
	description = normalizeDescriptionText(description)

	if techWarnings := unexpectedTechnologyMentions(repo, description); len(techWarnings) > 0 {
		warnings = append(warnings, techWarnings...)
	}

	normalized.Description = description
	normalized.Topics = filteredTopics

	confidence := ScoreConfidence(repo, snapshot, normalized, suggestion.Topics, allowedTopics)
	currentTopics := normalizeTopics(snapshot.ExistingTopics)

	return ValidationResult{
		DescriptionValid:     descriptionValid,
		TopicsValid:          topicsValid,
		ValidatedDescription: description,
		ValidatedTopics:      filteredTopics,
		Warnings:             warnings,
		Suggestion:           normalized,
		Confidence:           confidence,
		ConfidenceValue:      confidence.MetadataConfidence,
		CurrentDescription:   collapseWhitespace(strings.TrimSpace(repo.Description)),
		CurrentTopics:        currentTopics,
		GeneratedDescription: normalized.Description,
		GeneratedTopics:      normalized.Topics,
		AddedTopics:          diffTopics(normalized.Topics, currentTopics),
		RemovedTopics:        diffTopics(currentTopics, normalized.Topics),
		AllowedTopics:        setToSortedSlice(allowedTopics),
	}, nil
}

func CanonicalizeSuggestion(suggestion model.MetadataSuggestion) model.MetadataSuggestion {
	suggestion.Description = normalizeDescriptionText(suggestion.Description)
	suggestion.Topics = normalizeTopics(suggestion.Topics)
	return suggestion
}

func ScoreConfidence(repo RepoAnalysis, snapshot model.RepoSnapshot, suggestion model.MetadataSuggestion, rawTopics []string, allowedTopics map[string]struct{}) model.ConfidenceScore {
	readmeQuality := scoreReadmeQuality(snapshot.README)
	fileCoverage := scoreFileCoverage(snapshot)
	technologyAccuracy := scoreTechnologyAccuracy(repo, suggestion, rawTopics, allowedTopics)
	metadataScore := scoreMetadataQuality(repo, snapshot, suggestion, allowedTopics)
	metadataConfidence := clamp01(readmeQuality*0.20 + fileCoverage*0.35 + technologyAccuracy*0.35 + metadataScore*0.10)
	if isShortReadme(snapshot.README) {
		if fileCoverage < 0.6 {
			metadataConfidence = math.Max(metadataConfidence-0.03, neutralConfidenceScore)
		}
	}
	if len(snapshot.Files) == 0 {
		metadataConfidence = math.Max(metadataConfidence-0.04, neutralConfidenceScore)
	}

	return model.ConfidenceScore{
		ReadmeQuality:      clamp01(readmeQuality),
		FileCoverage:       clamp01(fileCoverage),
		TechnologyAccuracy: clamp01(technologyAccuracy),
		MetadataScore:      clamp01(metadataScore),
		MetadataConfidence: clamp01(metadataConfidence),
	}
}

func BuildMetadataPreview(result ValidationResult) string {
	var builder strings.Builder
	builder.Grow(256)
	builder.WriteString("Current Description: ")
	builder.WriteString(valueOrPlaceholder(result.CurrentDescription))
	builder.WriteString("\nGenerated Description: ")
	builder.WriteString(valueOrPlaceholder(result.GeneratedDescription))
	builder.WriteString("\nAdded Topics: ")
	builder.WriteString(joinLimited(result.AddedTopics, 10))
	builder.WriteString("\nRemoved Topics: ")
	builder.WriteString(joinLimited(result.RemovedTopics, 10))
	return builder.String()
}

func allowedTopicSet(repo RepoAnalysis, snapshot model.RepoSnapshot) map[string]struct{} {
	set := make(map[string]struct{}, len(repo.DetectedTopics)+len(repo.DetectedTechnologies)+8)
	add := func(values ...string) {
		for _, value := range values {
			candidate := normalizeTopic(value)
			if candidate == "" {
				continue
			}
			if _, blocked := genericTopicBlacklist[candidate]; blocked {
				continue
			}
			if _, blocked := topicQualityBlacklist[candidate]; blocked {
				continue
			}
			set[candidate] = struct{}{}
		}
	}

	add(repo.DetectedTopics...)
	add(repo.DetectedTechnologies...)
	add(languageTopic(repo.PrimaryLanguage))
	add(domainTopicCandidates(snapshot.README)...)
	for _, content := range snapshot.Files {
		add(domainTopicCandidates(content)...)
	}
	return set
}

func filterTopics(repo RepoAnalysis, snapshot model.RepoSnapshot, topics []string, allowed map[string]struct{}) []string {
	filtered := make([]string, 0, len(topics))
	for _, topic := range topics {
		candidate := normalizeTopic(topic)
		if candidate == "" {
			continue
		}
		if _, blocked := genericTopicBlacklist[candidate]; blocked {
			continue
		}
		if _, blocked := topicQualityBlacklist[candidate]; blocked && !hasExplicitPurposeWord(candidate, repo, snapshot) {
			continue
		}
		if _, ok := allowed[candidate]; !ok && !hasExplicitPurposeWord(candidate, repo, snapshot) {
			continue
		}
		if containsString(filtered, candidate) {
			continue
		}
		filtered = append(filtered, candidate)
		if len(filtered) == 10 {
			break
		}
	}
	return filtered
}

func validateDescription(repo RepoAnalysis, snapshot model.RepoSnapshot, description string) (string, error) {
	description = collapseWhitespace(strings.TrimSpace(description))
	if description == "" {
		return "", fmt.Errorf("description is empty")
	}
	if len([]rune(description)) > 120 {
		return "", fmt.Errorf("description exceeds 120 characters")
	}
	if isGenericDescription(description) {
		return "", fmt.Errorf("description is too generic")
	}
	if hasNegativeDescription(description) {
		return "", fmt.Errorf("description contains negative or placeholder language")
	}
	if hasBuzzword(description) {
		return "", fmt.Errorf("description contains marketing buzzwords")
	}
	for _, word := range descriptionTopicBlacklist {
		if containsWholeWord(description, word) && !hasExplicitPurposeWord(word, repo, snapshot) {
			return "", fmt.Errorf("description contains blacklisted word %q", word)
		}
	}
	if repo.Name != "" && containsWholeWord(description, repo.Name) {
		return "", fmt.Errorf("description repeats repository name")
	}
	return description, nil
}

func normalizeDescriptionText(description string) string {
	text := collapseWhitespace(strings.TrimSpace(description))
	for _, rule := range descriptionReplacements {
		text = rule.pattern.ReplaceAllString(text, rule.replacement)
	}
	return collapseWhitespace(text)
}

func hasNegativeDescription(description string) bool {
	lower := strings.ToLower(description)
	for _, phrase := range negativeDescriptionPhrases {
		if strings.Contains(phrase, " ") {
			if strings.Contains(lower, phrase) {
				return true
			}
			continue
		}
		if containsWholeWord(lower, phrase) {
			return true
		}
	}
	return false
}

func unexpectedTechnologyMentions(repo RepoAnalysis, description string) []string {
	allowed := make(map[string]struct{}, len(repo.DetectedTechnologies)+len(repo.DetectedTopics)+2)
	for _, value := range repo.DetectedTechnologies {
		allowed[normalizeTopic(value)] = struct{}{}
	}
	for _, value := range repo.DetectedTopics {
		allowed[normalizeTopic(value)] = struct{}{}
	}
	if language := languageTopic(repo.PrimaryLanguage); language != "" {
		allowed[normalizeTopic(language)] = struct{}{}
	}
	warnings := make([]string, 0, 2)
	for _, mention := range findTechnologyMentions(description) {
		if _, ok := allowed[mention]; ok {
			continue
		}
		warnings = append(warnings, fmt.Sprintf("description mentions technology %q without explicit repo evidence", mention))
	}
	return warnings
}

func hasBuzzword(text string) bool {
	lower := strings.ToLower(text)
	for _, word := range buzzwordBlacklist {
		if containsWholeWord(lower, word) {
			return true
		}
	}
	return false
}

func scoreReadmeQuality(readme string) float64 {
	trimmed := strings.TrimSpace(readme)
	if trimmed == "" {
		return neutralConfidenceScore
	}

	words := len(strings.Fields(trimmed))
	score := neutralConfidenceScore
	switch {
	case words < 20:
		score += 0.00
	case words < 60:
		score += 0.10
	case words < 160:
		score += 0.18
	default:
		score += 0.25
	}
	if strings.Contains(trimmed, "#") {
		score += 0.05
	}
	if strings.Contains(trimmed, "```") {
		score += 0.04
	}
	if strings.Contains(strings.ToLower(trimmed), "usage") || strings.Contains(strings.ToLower(trimmed), "install") {
		score += 0.03
	}
	return clamp01(score)
}

func scoreFileCoverage(snapshot model.RepoSnapshot) float64 {
	score := neutralConfidenceScore
	if strings.TrimSpace(snapshot.README) != "" {
		score += 0.05
	}
	structureFiles := 0
	sourceFiles := 0
	supportFiles := 0
	for path := range snapshot.Files {
		lower := strings.ToLower(filepath.Base(path))
		switch {
		case isStructureFile(lower):
			structureFiles++
		case isSourceLikeFile(lower):
			sourceFiles++
		case strings.Contains(lower, "test") || strings.Contains(lower, "spec"):
			supportFiles++
		}
	}
	score += math.Min(0.20, float64(structureFiles)*0.06)
	score += math.Min(0.25, float64(sourceFiles)*0.04)
	score += math.Min(0.05, float64(supportFiles)*0.02)
	if len(snapshot.Files) >= 8 {
		score += 0.05
	}
	return clamp01(score)
}

func scoreTechnologyAccuracy(repo RepoAnalysis, suggestion model.MetadataSuggestion, rawTopics []string, allowed map[string]struct{}) float64 {
	if len(rawTopics) == 0 {
		return neutralConfidenceScore
	}
	accepted := 0
	confirmedTechnologies := 0
	for _, topic := range suggestion.Topics {
		normalized := normalizeTopic(topic)
		if _, ok := allowed[normalized]; ok {
			accepted++
		}
		if containsString(repo.DetectedTechnologies, normalized) {
			confirmedTechnologies++
		}
	}
	ratio := float64(accepted) / float64(len(rawTopics))
	score := neutralConfidenceScore + ratio*0.20
	if confirmedTechnologies > 0 {
		score += 0.15
	}
	if len(repo.DetectedTechnologies) > 0 && len(repo.DetectedTopics) > 0 {
		score += 0.05
	}
	return clamp01(score)
}

func scoreMetadataQuality(repo RepoAnalysis, snapshot model.RepoSnapshot, suggestion model.MetadataSuggestion, allowed map[string]struct{}) float64 {
	score := neutralConfidenceScore
	if strings.TrimSpace(suggestion.Description) != "" {
		score += 0.05
	}
	if len(suggestion.Topics) > 0 {
		score += 0.05
	}
	if len(allowed) > 0 && len(suggestion.Topics) > 0 {
		matches := 0
		for _, topic := range suggestion.Topics {
			if _, ok := allowed[normalizeTopic(topic)]; ok {
				matches++
			}
		}
		score += math.Min(0.15, (float64(matches)/float64(len(suggestion.Topics)))*0.15)
	}
	if descriptionTouchesRepositorySignals(suggestion.Description, repo, snapshot) {
		score += 0.05
	}
	return clamp01(score)
}

func descriptionTouchesRepositorySignals(description string, repo RepoAnalysis, snapshot model.RepoSnapshot) bool {
	if strings.TrimSpace(description) == "" {
		return false
	}
	sources := []string{repo.Name, repo.FullName, repo.Description, repo.PrimaryLanguage, snapshot.README}
	sources = append(sources, repo.DetectedTechnologies...)
	sources = append(sources, repo.DetectedTopics...)
	for _, content := range snapshot.Files {
		sources = append(sources, content)
	}
	for _, source := range sources {
		if containsWholeWord(description, source) {
			return true
		}
	}
	return false
}

func isShortReadme(readme string) bool {
	return len(strings.Fields(strings.TrimSpace(readme))) < 20
}

func isStructureFile(name string) bool {
	switch name {
	case "go.mod", "go.sum", "package.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "cargo.toml", "cargo.lock", "requirements.txt", "pyproject.toml", "poetry.lock", "pom.xml", "cmakelists.txt", "dockerfile", "compose.yml", "compose.yaml", "docker-compose.yml", "docker-compose.yaml", "makefile":
		return true
	default:
		return false
	}
}

func isSourceLikeFile(name string) bool {
	if strings.Contains(name, ".") {
		switch filepath.Ext(name) {
		case ".go", ".py", ".js", ".ts", ".jsx", ".tsx", ".rs", ".java", ".cpp", ".c", ".cc", ".cxx", ".h", ".hpp", ".cs", ".rb", ".php", ".swift", ".kt", ".kts", ".scala", ".sh", ".m", ".mm":
			return true
		}
	}
	return strings.Contains(name, ".") && !strings.HasSuffix(name, ".md")
}

func containsWholeWord(text, word string) bool {
	text = strings.ToLower(text)
	word = strings.ToLower(strings.TrimSpace(word))
	if word == "" {
		return false
	}
	if strings.ContainsAny(word, ".-+#/") {
		return strings.Contains(text, word)
	}
	for _, token := range strings.FieldsFunc(text, func(r rune) bool {
		return !unicode.IsLetter(r) && !unicode.IsDigit(r)
	}) {
		if token == word {
			return true
		}
	}
	return false
}

func hasExplicitPurposeWord(word string, repo RepoAnalysis, snapshot model.RepoSnapshot) bool {
	word = strings.ToLower(strings.TrimSpace(word))
	if word == "" {
		return false
	}

	sources := []string{repo.Name, repo.FullName, repo.Description, repo.READMEPreview, snapshot.README}
	for _, content := range snapshot.Files {
		sources = append(sources, content)
	}
	for _, source := range sources {
		if containsWholeWord(source, word) {
			return true
		}
	}
	return false
}

func findTechnologyMentions(text string) []string {
	lower := strings.ToLower(text)
	mentions := make([]string, 0, 8)
	for _, token := range knownTechnologyMentions {
		if containsWholeWord(lower, token) {
			canonical := normalizeTopic(token)
			if canonical == "" {
				continue
			}
			if alias, ok := topicAliases[canonical]; ok {
				canonical = alias
			}
			if !containsString(mentions, canonical) {
				mentions = append(mentions, canonical)
			}
		}
	}
	return mentions
}

func domainTopicCandidates(text string) []string {
	if strings.TrimSpace(text) == "" {
		return nil
	}
	return collectLabels(strings.ToLower(text), domainTopicGroups)
}

func clamp01(value float64) float64 {
	if math.IsNaN(value) || math.IsInf(value, 0) {
		return 0
	}
	if value < 0 {
		return 0
	}
	if value > 1 {
		return 1
	}
	return value
}

func setToSortedSlice(values map[string]struct{}) []string {
	if len(values) == 0 {
		return nil
	}
	out := make([]string, 0, len(values))
	for value := range values {
		out = append(out, value)
	}
	sort.Strings(out)
	return out
}

func diffTopics(left, right []string) []string {
	if len(left) == 0 {
		return nil
	}
	rightSet := make(map[string]struct{}, len(right))
	for _, value := range right {
		rightSet[normalizeTopic(value)] = struct{}{}
	}
	out := make([]string, 0, len(left))
	for _, value := range left {
		candidate := normalizeTopic(value)
		if _, ok := rightSet[candidate]; ok {
			continue
		}
		out = append(out, candidate)
	}
	return out
}

func detectPrimaryLanguage(snapshot model.RepoSnapshot, fallback string) string {
	type scoredLanguage struct {
		name  string
		score float64
	}

	scores := map[string]float64{}
	boost := func(name string, score float64) {
		if name == "" || score <= 0 {
			return
		}
		scores[name] += score
	}

	if strings.TrimSpace(snapshot.Files["go.mod"]) != "" {
		boost("Go", 8)
	}
	if content := snapshot.Files["Cargo.toml"]; strings.TrimSpace(content) != "" {
		boost("Rust", 8)
	}
	if content := snapshot.Files["pom.xml"]; strings.TrimSpace(content) != "" {
		boost("Java", 7)
	}
	if content := snapshot.Files["requirements.txt"]; strings.TrimSpace(content) != "" || strings.TrimSpace(snapshot.Files["pyproject.toml"]) != "" {
		boost("Python", 7)
	}
	if content := snapshot.Files["package.json"]; strings.TrimSpace(content) != "" {
		boost("JavaScript", 4)
		if looksLikeTypeScriptPackage(content) {
			boost("TypeScript", 6)
		}
	}
	if content := snapshot.Files["CMakeLists.txt"]; strings.TrimSpace(content) != "" {
		if containsAny(strings.ToLower(content), "cxx", "c++", "boost", "qt", "opencv", "constexpr", "std::") {
			boost("C++", 8)
		} else {
			boost("C", 5)
		}
	}
	if content := snapshot.Files["Dockerfile"]; strings.TrimSpace(content) != "" {
		if containsAny(strings.ToLower(content), "from node", "npm", "yarn", "pnpm") {
			boost("JavaScript", 1)
		}
		if containsAny(strings.ToLower(content), "from python", "pip ", "uv ") {
			boost("Python", 1)
		}
		if containsAny(strings.ToLower(content), "from golang", "go build", "go mod") {
			boost("Go", 1)
		}
	}
	if fallback = strings.TrimSpace(fallback); fallback != "" {
		boost(fallback, 1)
	}

	if len(scores) == 0 {
		return fallback
	}

	ordered := []string{"Go", "TypeScript", "JavaScript", "Rust", "Python", "Java", "C++", "C"}
	best := scoredLanguage{}
	for _, name := range ordered {
		if score := scores[name]; score > best.score {
			best = scoredLanguage{name: name, score: score}
		}
	}
	if best.name != "" {
		return best.name
	}
	return fallback
}

func looksLikeTypeScriptPackage(content string) bool {
	lower := strings.ToLower(content)
	return containsAny(lower, "typescript", "ts-node", "tsx", "@types/", "tsc", "tsconfig")
}
