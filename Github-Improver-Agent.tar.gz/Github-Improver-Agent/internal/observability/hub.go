package observability

import (
	"sync"
	"time"
)

const EventSchemaVersion = 1

type Event struct {
	SchemaVersion   int            `json:"schema_version"`
	ID              uint64         `json:"id"`
	Event           string         `json:"event"`
	Timestamp       time.Time      `json:"timestamp"`
	WorkerID        *int           `json:"worker_id,omitempty"`
	Repo            string         `json:"repo,omitempty"`
	Stage           string         `json:"stage,omitempty"`
	Status          string         `json:"status,omitempty"`
	Attempt         *int           `json:"attempt,omitempty"`
	Message         string         `json:"message,omitempty"`
	Error           string         `json:"error,omitempty"`
	Key             string         `json:"key,omitempty"`
	Masked          string         `json:"masked,omitempty"`
	Model           string         `json:"model,omitempty"`
	CooldownSeconds *int64         `json:"cooldown_seconds,omitempty"`
	Details         map[string]any `json:"details,omitempty"`

	Type    string    `json:"-"`
	Time    time.Time `json:"-"`
	Payload any       `json:"-"`
}

type Hub struct {
	mu       sync.RWMutex
	subs     map[chan Event]struct{}
	ring     []Event
	ringSize int
	nextID   uint64
}

func NewHub(ringSize int) *Hub {
	if ringSize <= 0 {
		ringSize = 2000
	}
	return &Hub{
		subs:     make(map[chan Event]struct{}),
		ring:     make([]Event, 0, ringSize),
		ringSize: ringSize,
	}
}

func (h *Hub) Publish(event Event) {
	event = normalizeEvent(event)

	h.mu.Lock()
	if event.ID == 0 {
		h.nextID++
		event.ID = h.nextID
	} else if event.ID > h.nextID {
		h.nextID = event.ID
	}
	if len(h.ring) >= h.ringSize {
		copy(h.ring, h.ring[1:])
		h.ring[len(h.ring)-1] = event
	} else {
		h.ring = append(h.ring, event)
	}
	for ch := range h.subs {
		select {
		case ch <- event:
		default:
		}
	}
	h.mu.Unlock()
}

func (h *Hub) Subscribe(buffer int) chan Event {
	if buffer <= 0 {
		buffer = 64
	}
	ch := make(chan Event, buffer)
	h.mu.Lock()
	h.subs[ch] = struct{}{}
	h.mu.Unlock()
	return ch
}

func (h *Hub) Unsubscribe(ch chan Event) {
	h.mu.Lock()
	if _, ok := h.subs[ch]; ok {
		delete(h.subs, ch)
		close(ch)
	}
	h.mu.Unlock()
}

func (h *Hub) Recent(limit int) []Event {
	h.mu.RLock()
	defer h.mu.RUnlock()
	if limit <= 0 || limit > len(h.ring) {
		limit = len(h.ring)
	}
	start := len(h.ring) - limit
	if start < 0 {
		start = 0
	}
	out := make([]Event, 0, limit)
	out = append(out, h.ring[start:]...)
	return out
}

func (h *Hub) RecentAfterID(afterID uint64, limit int) []Event {
	h.mu.RLock()
	defer h.mu.RUnlock()
	if limit <= 0 || limit > len(h.ring) {
		limit = len(h.ring)
	}
	out := make([]Event, 0, limit)
	for _, event := range h.ring {
		if event.ID <= afterID {
			continue
		}
		out = append(out, event)
		if len(out) == limit {
			break
		}
	}
	return out
}

func normalizeEvent(event Event) Event {
	if event.Event == "" {
		event.Event = event.Type
	}
	if event.Event == "" {
		event.Event = "event"
	}
	if event.Timestamp.IsZero() {
		if !event.Time.IsZero() {
			event.Timestamp = event.Time.UTC()
		} else {
			event.Timestamp = time.Now().UTC()
		}
	}
	event.SchemaVersion = EventSchemaVersion

	details := mapFromPayload(event.Payload)
	if len(details) > 0 {
		event.Details = mergeDetails(event.Details, details)
		if value, ok := stringValue(details["event"]); ok && (event.Event == "event" || event.Event == "log") {
			event.Event = value
		}
		if value, ok := intValue(details["worker_id"]); ok && event.WorkerID == nil {
			event.WorkerID = &value
		}
		if value, ok := stringValue(details["repo"]); ok && event.Repo == "" {
			event.Repo = value
		}
		if value, ok := stringValue(details["stage"]); ok && event.Stage == "" {
			event.Stage = value
		}
		if value, ok := stringValue(details["status"]); ok && event.Status == "" {
			event.Status = value
		}
		if value, ok := intValue(details["attempt"]); ok && event.Attempt == nil {
			event.Attempt = &value
		}
		if value, ok := stringValue(details["message"]); ok && event.Message == "" {
			event.Message = value
		}
		if value, ok := stringValue(details["error"]); ok && event.Error == "" {
			event.Error = value
		}
		if value, ok := stringValue(details["key"]); ok && event.Key == "" {
			event.Key = value
		}
		if value, ok := stringValue(details["masked"]); ok && event.Masked == "" {
			event.Masked = value
		}
		if value, ok := stringValue(details["model"]); ok && event.Model == "" {
			event.Model = value
		}
		if value, ok := int64Value(details["cooldown_seconds"]); ok && event.CooldownSeconds == nil {
			event.CooldownSeconds = &value
		}
	}
	return event
}

func mergeDetails(existing, incoming map[string]any) map[string]any {
	if len(existing) == 0 {
		return incoming
	}
	for key, value := range incoming {
		if _, ok := existing[key]; !ok {
			existing[key] = value
		}
	}
	return existing
}

func mapFromPayload(payload any) map[string]any {
	switch value := payload.(type) {
	case nil:
		return nil
	case map[string]any:
		return value
	case map[string]string:
		out := make(map[string]any, len(value))
		for key, item := range value {
			out[key] = item
		}
		return out
	default:
		return map[string]any{"value": value}
	}
}

func stringValue(value any) (string, bool) {
	text, ok := value.(string)
	return text, ok && text != ""
}

func intValue(value any) (int, bool) {
	switch typed := value.(type) {
	case int:
		return typed, true
	case int64:
		return int(typed), true
	case float64:
		return int(typed), true
	default:
		return 0, false
	}
}

func int64Value(value any) (int64, bool) {
	switch typed := value.(type) {
	case int:
		return int64(typed), true
	case int64:
		return typed, true
	case float64:
		return int64(typed), true
	default:
		return 0, false
	}
}
