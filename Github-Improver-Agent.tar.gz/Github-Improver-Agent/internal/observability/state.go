package observability

import (
	"sync"
	"time"
)

type StageSnapshot struct {
	Active        int64 `json:"active"`
	Processed     int64 `json:"processed"`
	Failed        int64 `json:"failed"`
	Retried       int64 `json:"retried"`
	AvgDurationMs int64 `json:"avg_duration_ms"`
}

type PipelineSnapshot struct {
	Queues        map[string]int           `json:"queues"`
	QueueCapacity map[string]int           `json:"queue_capacity"`
	Stages        map[string]StageSnapshot `json:"stages"`
	UpdatedAt     time.Time                `json:"updated_at"`
}

type PipelineRun struct {
	Running    bool      `json:"running"`
	Mode       string    `json:"mode"`
	StartedAt  time.Time `json:"started_at"`
	FinishedAt time.Time `json:"finished_at"`
	LastError  string    `json:"last_error,omitempty"`
}

type State struct {
	mu       sync.RWMutex
	run      PipelineRun
	snapshot PipelineSnapshot
}

func NewState() *State {
	return &State{}
}

func (s *State) MarkRunning(mode string) {
	s.mu.Lock()
	s.run = PipelineRun{
		Running:   true,
		Mode:      mode,
		StartedAt: time.Now().UTC(),
	}
	s.mu.Unlock()
}

func (s *State) MarkCompleted(err error) {
	s.mu.Lock()
	s.run.Running = false
	s.run.FinishedAt = time.Now().UTC()
	if err != nil {
		s.run.LastError = err.Error()
	} else {
		s.run.LastError = ""
	}
	s.mu.Unlock()
}

func (s *State) UpdateSnapshot(snapshot PipelineSnapshot) {
	s.mu.Lock()
	s.snapshot = snapshot
	s.mu.Unlock()
}

func (s *State) Snapshot() (PipelineRun, PipelineSnapshot) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.run, s.snapshot
}
