package observability

import "testing"

func TestHubPublishesVersionedEventsAndReplaysAfterID(t *testing.T) {
	t.Parallel()

	hub := NewHub(4)
	hub.Publish(Event{
		Type: "worker_update",
		Payload: map[string]any{
			"worker_id": float64(2),
			"repo":      "owner/repo",
			"stage":     "llm_generation",
			"status":    "started",
		},
	})
	hub.Publish(Event{Type: "pipeline", Payload: map[string]any{"status": "running"}})

	recent := hub.Recent(2)
	if len(recent) != 2 {
		t.Fatalf("Recent returned %d events, want 2", len(recent))
	}
	first := recent[0]
	if first.SchemaVersion != EventSchemaVersion {
		t.Fatalf("SchemaVersion = %d, want %d", first.SchemaVersion, EventSchemaVersion)
	}
	if first.ID == 0 {
		t.Fatalf("ID was not assigned")
	}
	if first.Event != "worker_update" {
		t.Fatalf("Event = %q, want worker_update", first.Event)
	}
	if first.WorkerID == nil || *first.WorkerID != 2 {
		t.Fatalf("WorkerID = %#v, want 2", first.WorkerID)
	}
	if first.Repo != "owner/repo" || first.Stage != "llm_generation" || first.Status != "started" {
		t.Fatalf("typed fields not populated: %#v", first)
	}

	after := hub.RecentAfterID(first.ID, 10)
	if len(after) != 1 {
		t.Fatalf("RecentAfterID returned %d events, want 1", len(after))
	}
	if after[0].ID <= first.ID {
		t.Fatalf("RecentAfterID returned event %d after %d", after[0].ID, first.ID)
	}
}
