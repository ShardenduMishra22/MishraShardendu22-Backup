package observability

import (
	"encoding/json"
	"io"
	"strings"
	"time"
)

type LogWriter struct {
	out io.Writer
	hub *Hub
}

func NewLogWriter(out io.Writer, hub *Hub) *LogWriter {
	return &LogWriter{out: out, hub: hub}
}

func (w *LogWriter) Write(p []byte) (int, error) {
	if w.hub != nil {
		payload := make(map[string]any)
		trimmed := strings.TrimSpace(string(p))
		if trimmed != "" && json.Unmarshal([]byte(trimmed), &payload) == nil {
			w.hub.Publish(Event{Type: "log", Time: time.Now().UTC(), Payload: payload})
		}
	}
	if w.out == nil {
		return len(p), nil
	}
	return w.out.Write(p)
}
