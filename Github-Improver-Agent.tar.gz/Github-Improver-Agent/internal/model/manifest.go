package model

import "time"

type RepoFailure struct {
	Stage string `json:"stage"`
	Error string `json:"error"`
}

type UpdateStatus struct {
	DescriptionUpdated bool      `json:"description_updated"`
	TopicsUpdated      bool      `json:"topics_updated"`
	Skipped            bool      `json:"skipped"`
	SkipReason         string    `json:"skip_reason,omitempty"`
	UpdatedAt          time.Time `json:"updated_at,omitempty"`
}

func (s UpdateStatus) Completed() bool {
	return s.DescriptionUpdated && s.TopicsUpdated
}

type ValidationSummary struct {
	Valid                bool            `json:"valid"`
	DescriptionValid     bool            `json:"description_valid"`
	TopicsValid          bool            `json:"topics_valid"`
	Error                string          `json:"error,omitempty"`
	CurrentDescription   string          `json:"current_description,omitempty"`
	CurrentTopics        []string        `json:"current_topics,omitempty"`
	GeneratedDescription string          `json:"generated_description,omitempty"`
	GeneratedTopics      []string        `json:"generated_topics,omitempty"`
	ValidatedDescription string          `json:"validated_description,omitempty"`
	ValidatedTopics      []string        `json:"validated_topics,omitempty"`
	AddedTopics          []string        `json:"added_topics,omitempty"`
	RemovedTopics        []string        `json:"removed_topics,omitempty"`
	AllowedTopics        []string        `json:"allowed_topics,omitempty"`
	Warnings             []string        `json:"warnings,omitempty"`
	Confidence           ConfidenceScore `json:"confidence"`
	ConfidenceThreshold  float64         `json:"confidence_threshold,omitempty"`
	CacheHit             bool            `json:"cache_hit,omitempty"`
}

type GeneratedMetadata struct {
	Description     string            `json:"description"`
	Topics          []string          `json:"topics"`
	ConfidenceScore float64           `json:"confidence_score"`
	Validation      ValidationSummary `json:"validation"`
	CacheHit        bool              `json:"cache_hit,omitempty"`
}

type StageResults struct {
	SnapshotSuccess          bool `json:"snapshot_success,omitempty"`
	AnalysisSuccess          bool `json:"analysis_success,omitempty"`
	InspectionSuccess        bool `json:"inspection_success,omitempty"`
	LLMSuccess               bool `json:"llm_success,omitempty"`
	NormalizationSuccess     bool `json:"normalization_success,omitempty"`
	ValidationSuccess        bool `json:"validation_success,omitempty"`
	DescriptionUpdateSuccess bool `json:"description_update_success,omitempty"`
	TopicsUpdateSuccess      bool `json:"topics_update_success,omitempty"`
}

type RetrySummary struct {
	Total   int            `json:"total,omitempty"`
	ByStage map[string]int `json:"by_stage,omitempty"`
}

type DocumentationState struct {
	ReadmeGenerationState        string    `json:"readme_generation_state,omitempty"`
	DocumentationGenerationState string    `json:"documentation_generation_state,omitempty"`
	CurrentReadme                string    `json:"current_readme,omitempty"`
	GeneratedReadme              string    `json:"generated_readme,omitempty"`
	CurrentQualityScore          float64   `json:"current_quality_score,omitempty"`
	PreviewOnly                  bool      `json:"preview_only,omitempty"`
	SectionChanges               []string  `json:"section_changes,omitempty"`
	GeneratedAt                  time.Time `json:"generated_at,omitempty"`
	AppliedAt                    time.Time `json:"applied_at,omitempty"`
	Diff                         string    `json:"diff,omitempty"`
}

type FileWriteResult struct {
	Path       string    `json:"path,omitempty"`
	BackupPath string    `json:"backup_path,omitempty"`
	Status     string    `json:"status,omitempty"`
	Error      string    `json:"error,omitempty"`
	DryRun     bool      `json:"dry_run,omitempty"`
	RolledBack bool      `json:"rolled_back,omitempty"`
	WrittenAt  time.Time `json:"written_at,omitempty"`
}

type RollbackState struct {
	Completed    bool      `json:"completed,omitempty"`
	RolledBackAt time.Time `json:"rolled_back_at,omitempty"`
	BackupPath   string    `json:"backup_path,omitempty"`
	Error        string    `json:"error,omitempty"`
}

type RepoManifest struct {
	Owner               string             `json:"owner"`
	Name                string             `json:"name"`
	FullName            string             `json:"full_name"`
	CloneURL            string             `json:"clone_url"`
	DefaultBranch       string             `json:"default_branch"`
	PrimaryLanguage     string             `json:"primary_language"`
	Description         string             `json:"description"`
	Topics              []string           `json:"topics"`
	ReadmeContent       string             `json:"readme_content"`
	DetectedTech        []string           `json:"detected_tech"`
	DetectedFrameworks  []string           `json:"detected_frameworks"`
	ImportantFiles      []string           `json:"important_files"`
	ConfidenceScore     float64            `json:"confidence_score"`
	GeneratedMetadata   *GeneratedMetadata `json:"generated_metadata,omitempty"`
	Failures            []RepoFailure      `json:"failures,omitempty"`
	UpdateStatus        UpdateStatus       `json:"update_status"`
	StageResults        StageResults       `json:"stage_results,omitempty"`
	Retries             RetrySummary       `json:"retries,omitempty"`
	Documentation       DocumentationState `json:"documentation,omitempty"`
	FileWriteResults    []FileWriteResult  `json:"file_write_results,omitempty"`
	BackupPath          string             `json:"backup_path,omitempty"`
	RollbackStatus      RollbackState      `json:"rollback_status,omitempty"`
	OriginalDescription string             `json:"original_description,omitempty"`
	OriginalTopics      []string           `json:"original_topics,omitempty"`
}

type ManifestFile struct {
	Version      int            `json:"version"`
	GeneratedAt  time.Time      `json:"generated_at"`
	UpdatedAt    time.Time      `json:"updated_at,omitempty"`
	Repositories []RepoManifest `json:"repositories"`
}
