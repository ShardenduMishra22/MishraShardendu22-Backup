package model

import "encoding/json"

type ImportantFile struct {
	Path    string
	Summary string
}

type RepoSnapshot struct {
	README         string
	ReadmeHash     string
	CommitSHA      string
	ExistingTopics []string
	Files          map[string]string
}

type RepoAnalysis struct {
	Owner                string
	Name                 string
	FullName             string
	Description          string
	DefaultBranch        string
	PrimaryLanguage      string
	ProjectCategory      string
	ArchitectureStyle    string
	EngineeringDomain    string
	DeploymentModel      string
	ProjectIntent        string
	READMEPreview        string
	BackendFrontend      string
	ExistingTopics       []string
	DetectedTechnologies []string
	DetectedTopics       []string
	Frameworks           []string
	Infrastructure       []string
	InfraStack           []string
	APIs                 []string
	AITools              []string
	ImportantFiles       []ImportantFile
}

type ConfidenceScore struct {
	ReadmeQuality      float64 `json:"readme_quality"`
	FileCoverage       float64 `json:"file_coverage"`
	TechnologyAccuracy float64 `json:"technology_accuracy"`
	MetadataScore      float64 `json:"metadata_score"`
	MetadataConfidence float64 `json:"metadata_confidence"`
}

type MetadataSuggestion struct {
	Description      string          `json:"description"`
	Topics           []string        `json:"topics"`
	ReasoningDetails json.RawMessage `json:"-"`
}

type RepoOutcome struct {
	Updated             bool
	Skipped             bool
	FullName            string
	Description         string
	SkipReason          string
	ErrorMessage        string
	Topics              []string
	Confidence          ConfidenceScore
	ConfidenceThreshold float64
	ConfidenceEvaluated bool
}
