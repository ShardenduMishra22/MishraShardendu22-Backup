package githubsvc

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"sync"

	"go-description-script/internal/model"
	"go-description-script/internal/retry"

	"github.com/google/go-github/v86/github"
	"github.com/rs/zerolog"
	"golang.org/x/time/rate"
)

var manifestFiles = []string{
	"package.json",
	"go.mod",
	"Cargo.toml",
	"requirements.txt",
	"CMakeLists.txt",
	"Dockerfile",
	"pom.xml",
	"pyproject.toml",
}

type Client struct {
	api     *github.Client
	limiter *rate.Limiter
	retries int
	logger  zerolog.Logger
	userMu  sync.Mutex
	user    string
}

func New(token string, limiter *rate.Limiter, retries int, logger zerolog.Logger) *Client {
	api := github.NewClient(nil).WithAuthToken(token)
	return &Client{
		api:     api,
		limiter: limiter,
		retries: retries,
		logger:  logger,
	}
}

func (c *Client) ListRepositories(ctx context.Context) ([]*github.Repository, error) {
	all := make([]*github.Repository, 0, 64)
	page := 1

	for {
		result, err := retry.Do(ctx, c.retries, "github.list_repositories", c.logger, func() (listPage, int, http.Header, error) {
			if err := c.wait(ctx); err != nil {
				return listPage{}, 0, nil, err
			}

			opts := &github.RepositoryListByAuthenticatedUserOptions{
				ListOptions: github.ListOptions{Page: page, PerPage: 100},
			}
			repos, resp, err := c.api.Repositories.ListByAuthenticatedUser(ctx, opts)
			status, headers := responseMeta(resp)
			if err != nil {
				return listPage{}, status, headers, err
			}
			return listPage{Repos: repos, NextPage: nextPage(resp)}, status, headers, nil
		})
		if err != nil {
			return nil, err
		}

		all = append(all, result.Repos...)
		if result.NextPage == 0 {
			break
		}
		page = result.NextPage
	}

	return all, nil
}

func (c *Client) ReadSnapshot(ctx context.Context, repo *github.Repository) (model.RepoSnapshot, error) {
	snapshot := model.RepoSnapshot{Files: make(map[string]string)}
	owner := repo.GetOwner().GetLogin()
	name := repo.GetName()
	ref := repo.GetDefaultBranch()
	if ref != "" {
		if err := c.wait(ctx); err != nil {
			return snapshot, err
		}
		branch, resp, err := c.api.Repositories.GetBranch(ctx, owner, name, ref, 0)
		if err != nil {
			return snapshot, wrapStatus(err, resp)
		}
		if branch != nil && branch.Commit != nil && branch.Commit.SHA != nil {
			snapshot.CommitSHA = *branch.Commit.SHA
		}
	}

	readme, err := c.fetchReadme(ctx, owner, name, ref)
	if err != nil {
		if !isNotFound(err) {
			return snapshot, err
		}
	} else if strings.TrimSpace(readme) != "" {
		snapshot.README = readme
	}

	if strings.TrimSpace(snapshot.README) == "" {
		fallbackReadme, err := c.fetchFile(ctx, owner, name, "README.md", ref)
		if err != nil {
			if !isNotFound(err) {
				return snapshot, err
			}
		} else {
			snapshot.README = fallbackReadme
		}
	}
	snapshot.ReadmeHash = hashString(snapshot.README)

	topics, err := c.fetchTopics(ctx, owner, name)
	if err != nil {
		if !isNotFound(err) {
			return snapshot, err
		}
	} else {
		snapshot.ExistingTopics = topics
	}

	for _, path := range manifestFiles {
		content, err := c.fetchFile(ctx, owner, name, path, ref)
		if err != nil {
			if isNotFound(err) {
				continue
			}
			return snapshot, err
		}
		if strings.TrimSpace(content) == "" {
			continue
		}
		snapshot.Files[path] = content
	}

	return snapshot, nil
}

func (c *Client) UpdateMetadata(ctx context.Context, repo *github.Repository, description string, topics []string) (*github.Repository, error) {
	owner := repo.GetOwner().GetLogin()
	name := repo.GetName()
	if strings.TrimSpace(owner) == "" || strings.TrimSpace(name) == "" {
		return nil, errors.New("repository owner and name are required")
	}

	updated, err := c.UpdateDescription(ctx, repo, description)
	if err != nil {
		return updated, err
	}
	_, err = c.ReplaceTopics(ctx, repo, topics)
	if err != nil {
		return updated, err
	}
	return updated, nil
}

func (c *Client) ReadmeContent(ctx context.Context, repo *github.Repository) (string, error) {
	if repo == nil {
		return "", errors.New("repository is nil")
	}
	owner := repo.GetOwner().GetLogin()
	name := repo.GetName()
	if strings.TrimSpace(owner) == "" || strings.TrimSpace(name) == "" {
		return "", errors.New("repository owner and name are required")
	}
	if err := c.wait(ctx); err != nil {
		return "", err
	}
	content, resp, err := c.api.Repositories.GetReadme(ctx, owner, name, nil)
	if err != nil {
		return "", wrapStatus(err, resp)
	}
	if content == nil {
		return "", errors.New("README response was empty")
	}
	text, err := content.GetContent()
	if err != nil {
		return "", err
	}
	return text, nil
}

func (c *Client) UpdateReadme(ctx context.Context, repo *github.Repository, content string, commitMessage string) (string, error) {
	if repo == nil {
		return "", errors.New("repository is nil")
	}
	owner := repo.GetOwner().GetLogin()
	name := repo.GetName()
	if strings.TrimSpace(owner) == "" || strings.TrimSpace(name) == "" {
		return "", errors.New("repository owner and name are required")
	}
	path := "README.md"
	message := strings.TrimSpace(commitMessage)
	if message == "" {
		message = "docs: update README"
	}
	if err := c.wait(ctx); err != nil {
		return "", err
	}
	current, _, resp, err := c.api.Repositories.GetContents(ctx, owner, name, path, nil)
	if err != nil {
		if isNotFound(err) {
			if err := c.wait(ctx); err != nil {
				return "", err
			}
			_, _, createErr := c.api.Repositories.CreateFile(ctx, owner, name, path, &github.RepositoryContentFileOptions{Message: github.Ptr(message), Content: []byte(content)})
			if createErr != nil {
				return "", wrapStatus(createErr, resp)
			}
			return path, nil
		}
		return "", wrapStatus(err, resp)
	}
	if current == nil {
		return "", errors.New("README content was empty")
	}
	if err := c.wait(ctx); err != nil {
		return "", err
	}
	_, _, err = c.api.Repositories.UpdateFile(ctx, owner, name, path, &github.RepositoryContentFileOptions{Message: github.Ptr(message), Content: []byte(content), SHA: github.Ptr(current.GetSHA())})
	if err != nil {
		return "", wrapStatus(err, resp)
	}
	return path, nil
}

func (c *Client) VerifyRepository(ctx context.Context, owner, name string) (*github.Repository, error) {
	owner = strings.TrimSpace(owner)
	name = strings.TrimSpace(name)
	if owner == "" || name == "" {
		return nil, errors.New("repository owner and name are required")
	}

	if err := c.wait(ctx); err != nil {
		return nil, err
	}
	repo, resp, err := c.api.Repositories.Get(ctx, owner, name)
	if err != nil {
		return nil, wrapStatus(err, resp)
	}
	if repo == nil {
		return nil, errors.New("repository lookup returned empty response")
	}
	if repo.GetArchived() {
		return nil, fmt.Errorf("repository %s/%s is archived", owner, name)
	}
	if repo.GetDisabled() {
		return nil, fmt.Errorf("repository %s/%s is disabled", owner, name)
	}
	ownerLogin := strings.TrimSpace(repo.GetOwner().GetLogin())
	if ownerLogin == "" {
		return nil, errors.New("repository owner is missing")
	}
	if !strings.EqualFold(ownerLogin, owner) {
		return nil, fmt.Errorf("repository owner mismatch: expected %s, got %s", owner, ownerLogin)
	}

	userLogin, err := c.currentUserLogin(ctx)
	if err != nil {
		return nil, err
	}

	if err := c.wait(ctx); err != nil {
		return nil, err
	}
	permission, resp, err := c.api.Repositories.GetPermissionLevel(ctx, owner, name, userLogin)
	if err != nil {
		return nil, wrapStatus(err, resp)
	}
	if permission == nil {
		return nil, errors.New("permission level response was empty")
	}
	permValue := strings.ToLower(strings.TrimSpace(permission.GetPermission()))
	if permValue == "" {
		return nil, errors.New("permission level was empty")
	}
	switch permValue {
	case "admin", "maintain", "write":
		return repo, nil
	default:
		return nil, fmt.Errorf("insufficient repository permission: %s", permValue)
	}
}

func (c *Client) UpdateDescription(ctx context.Context, repo *github.Repository, description string) (*github.Repository, error) {
	if repo == nil {
		return nil, errors.New("repository is nil")
	}
	owner := repo.GetOwner().GetLogin()
	name := repo.GetName()
	if strings.TrimSpace(owner) == "" || strings.TrimSpace(name) == "" {
		return nil, errors.New("repository owner and name are required")
	}

	update := &github.Repository{Description: github.Ptr(description)}
	if err := c.wait(ctx); err != nil {
		return nil, err
	}
	updated, resp, err := c.api.Repositories.Edit(ctx, owner, name, update)
	if err != nil {
		return nil, wrapStatus(err, resp)
	}
	return updated, nil
}

func (c *Client) ReplaceTopics(ctx context.Context, repo *github.Repository, topics []string) ([]string, error) {
	if repo == nil {
		return nil, errors.New("repository is nil")
	}
	owner := repo.GetOwner().GetLogin()
	name := repo.GetName()
	if strings.TrimSpace(owner) == "" || strings.TrimSpace(name) == "" {
		return nil, errors.New("repository owner and name are required")
	}

	if err := c.wait(ctx); err != nil {
		return nil, err
	}
	updated, resp, err := c.api.Repositories.ReplaceAllTopics(ctx, owner, name, topics)
	if err != nil {
		return nil, wrapStatus(err, resp)
	}
	return updated, nil
}

func (c *Client) currentUserLogin(ctx context.Context) (string, error) {
	c.userMu.Lock()
	if c.user != "" {
		login := c.user
		c.userMu.Unlock()
		return login, nil
	}
	c.userMu.Unlock()

	if err := c.wait(ctx); err != nil {
		return "", err
	}
	user, resp, err := c.api.Users.Get(ctx, "")
	if err != nil {
		return "", wrapStatus(err, resp)
	}
	if user == nil {
		return "", errors.New("current user response was empty")
	}
	login := strings.TrimSpace(user.GetLogin())
	if login == "" {
		return "", errors.New("current user login was empty")
	}

	c.userMu.Lock()
	if c.user == "" {
		c.user = login
	}
	c.userMu.Unlock()

	return login, nil
}

func (c *Client) fetchReadme(ctx context.Context, owner, repo, ref string) (string, error) {
	if err := c.wait(ctx); err != nil {
		return "", err
	}

	var opts *github.RepositoryContentGetOptions
	if strings.TrimSpace(ref) != "" {
		opts = &github.RepositoryContentGetOptions{Ref: ref}
	}

	content, resp, err := c.api.Repositories.GetReadme(ctx, owner, repo, opts)
	if err != nil {
		return "", wrapStatus(err, resp)
	}
	if content == nil {
		return "", fmt.Errorf("readme response was empty")
	}

	text, err := content.GetContent()
	if err != nil {
		return "", err
	}
	return text, nil
}

func (c *Client) fetchTopics(ctx context.Context, owner, repo string) ([]string, error) {
	if err := c.wait(ctx); err != nil {
		return nil, err
	}
	topics, resp, err := c.api.Repositories.ListAllTopics(ctx, owner, repo, nil)
	if err != nil {
		return nil, wrapStatus(err, resp)
	}
	return topics, nil
}

func (c *Client) fetchFile(ctx context.Context, owner, repo, path, ref string) (string, error) {
	if err := c.wait(ctx); err != nil {
		return "", err
	}

	var opts *github.RepositoryContentGetOptions
	if strings.TrimSpace(ref) != "" {
		opts = &github.RepositoryContentGetOptions{Ref: ref}
	}

	content, _, resp, err := c.api.Repositories.GetContents(ctx, owner, repo, path, opts)
	if err != nil {
		return "", wrapStatus(err, resp)
	}
	if content == nil {
		return "", fmt.Errorf("no file content returned for %s", path)
	}

	text, err := content.GetContent()
	if err != nil {
		return "", err
	}
	return text, nil
}

func (c *Client) wait(ctx context.Context) error {
	if c.limiter == nil {
		return nil
	}
	return c.limiter.Wait(ctx)
}

type listPage struct {
	Repos    []*github.Repository
	NextPage int
}

func responseMeta(resp *github.Response) (int, http.Header) {
	if resp == nil || resp.Response == nil {
		return 0, nil
	}
	return resp.Response.StatusCode, resp.Response.Header
}

func wrapStatus(err error, resp *github.Response) error {
	if err == nil {
		return nil
	}
	status, headers := responseMeta(resp)
	return retry.WithStatus(err, status, headers)
}

func nextPage(resp *github.Response) int {
	if resp == nil {
		return 0
	}
	return resp.NextPage
}

func isNotFound(err error) bool {
	var errResponse *github.ErrorResponse
	if errors.As(err, &errResponse) && errResponse.Response != nil {
		return errResponse.Response.StatusCode == http.StatusNotFound
	}
	return false
}

func hashString(value string) string {
	sum := sha256.Sum256([]byte(value))
	return hex.EncodeToString(sum[:])
}
