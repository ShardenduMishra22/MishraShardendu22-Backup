import React, { createContext, useContext, useEffect, useState } from 'react';
import { AUTH } from '../api/requests';
import { axios } from '../api';
import { sendReqToServer } from '../Hooks/useAxios';
import { useNavigate } from 'react-router-dom';
import { BlogsDetailsContextProvider } from './blogsContextApi.jsx';
import { NotesDetailsContextProvider } from './notesContextApi.jsx';

const appContext = createContext();

export default function AppContextProvider({ children }) {
  const [user, setuser] = useState(null);
  const [ShowLoginPopup, setShowLoginPopup] = useState(false);
  const [theme, settheme] = useState('light');
  const [filter, setfilter] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    // getting user info from backend to check his session
    const getUser = async () => {
      const token = localStorage.getItem('session');

      if (user || !token) return;

      try {
        const { response, error: _error } = await sendReqToServer({
          axiosInstance: axios,
          url: AUTH.sessionAuth,
          method: 'PUT',
          requestConfig: {
            data: {
              session: token,
            },
          },
        });

        if (response) {
          setuser(response.body.user);
        }
      } catch (error) {
        console.error(error);
        throw new Error('Error in Session Validation');
      }
    };

    getUser();
  }, [navigate, user]);

  return (
    <appContext.Provider
      value={{
        user,
        setuser,
        theme,
        settheme,
        filter,
        setfilter,
        ShowLoginPopup,
        setShowLoginPopup,
      }}
    >
      <BlogsDetailsContextProvider>
        <NotesDetailsContextProvider>{children}</NotesDetailsContextProvider>
      </BlogsDetailsContextProvider>
    </appContext.Provider>
  );
}

export const AppStates = () => {
  const { user, setuser, filter, setfilter, ShowLoginPopup, setShowLoginPopup } =
    useContext(appContext);

  return {
    user,
    setuser,
    filter,
    setfilter,
    ShowLoginPopup,
    setShowLoginPopup,
  };
};
