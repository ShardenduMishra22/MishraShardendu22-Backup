### Goal

Extract your LeetCode submission → generate a clean explanation using an LLM.

---

### What to Extract from LeetCode

From the problem page after submission:

* `title` → Problem name
* `difficulty` → Easy / Medium / Hard
* `problem_description` → optional (can skip or truncate)
* `code` → your accepted solution

---

### Prompt Design (Core)

Use this prompt for the LLM:

You are given a LeetCode problem and its accepted solution.

Generate a structured explanation.

INPUT:

* Problem Title: {title}
* Difficulty: {difficulty}
* Code:
  {code}

OUTPUT FORMAT:

1. Problem Summary (2–3 lines, concise)
2. Approach (step-by-step, no fluff)
3. Key Idea (core insight in 1–2 lines)
4. Time Complexity
5. Space Complexity

Constraints:

* Be precise and technical
* No storytelling or generic explanation
* Do not restate the code line-by-line
* Focus on reasoning and algorithm

---

### Example Output (LLM Expected)

Problem Summary:
Find two indices such that their values sum to a target.

Approach:
Traverse the array once while storing visited elements in a hashmap.
For each element, check if (target - current) exists.

Key Idea:
Use constant-time lookup to avoid nested loops.

Time Complexity:
O(n)

Space Complexity:
O(n)

---

### Minimal Flow

```text
[Content Script]
   ↓ extract data
[Send to LLM]
   ↓
[Receive explanation]
```

---

### Content Script Extraction (JS)

```javascript
// Extract title
const title = document.querySelector('div[data-cy="question-title"]')?.innerText;

// Extract difficulty
const difficulty = document.querySelector('[diff]')?.innerText;

// Extract code (Monaco editor)
const code = document.querySelector('.view-lines')?.innerText;
```

---

### Notes

* Do NOT send full problem description unless needed (saves tokens)
* Code alone is often enough for standard problems
* Ensure extraction runs only after submission is visible

---

### Key Terminology

* **DOM Scraping** = Extracting data from webpage structure
* **Prompt Template** = Fixed structure sent to LLM
* **Inference Call** = Request to LLM API
* **Monaco Editor** = Code editor used in LeetCode frontend
