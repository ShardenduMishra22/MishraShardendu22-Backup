import dotenv from "dotenv";
import path from "path";

let loaded = false;

export function loadEnvironment(forceReload = false): void {
  if (loaded && !forceReload) {
    return;
  }

  const candidates = [
    path.resolve(process.cwd(), ".env"),
    path.resolve(__dirname, "../../.env")
  ];

  for (const envPath of candidates) {
    dotenv.config({ path: envPath, override: false });
  }

  loaded = true;
}
