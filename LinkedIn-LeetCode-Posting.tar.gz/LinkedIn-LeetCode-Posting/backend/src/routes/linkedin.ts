import { Router } from "express";
import { analyzeSubmission, generateLinkedInPost, isTimeoutError } from "../services/llm";
import {
  isLinkedInApiError,
  isLinkedInAuthError,
  isLinkedInTimeoutError,
  publishLinkedInPost
} from "../services/linkedin";

interface AnalyzeRequestPayload {
  title: string;
  difficulty: string;
  code: string;
  url: string;
}

interface PostLinkedInPayload {
  linkedin_post: string;
}

const router = Router();

router.post("/post-linkedin", async (req, res) => {
  const payload = req.body as Partial<PostLinkedInPayload>;

  if (!isNonEmptyString(payload.linkedin_post)) {
    return res.status(400).json({
      error: "Invalid payload. Required field: linkedin_post"
    });
  }

  try {
    const publishResult = await publishLinkedInPost(payload.linkedin_post.trim());

    return res.json({
      status: "posted",
      linkedin_post_id: publishResult.id
    });
  } catch (error) {
    const statusCode = mapStatusCode(error);

    return res.status(statusCode).json({
      error: toErrorMessage(error)
    });
  }
});

router.post("/analyze-and-post", async (req, res) => {
  const payload = req.body as Partial<AnalyzeRequestPayload>;

  if (!isValidAnalyzePayload(payload)) {
    return res.status(400).json({
      error: "Invalid payload. Required fields: title, difficulty, code, url"
    });
  }

  const normalizedPayload: AnalyzeRequestPayload = {
    title: payload.title.trim(),
    difficulty: payload.difficulty.trim(),
    code: payload.code,
    url: payload.url.trim()
  };

  try {
    const explanation = await analyzeSubmission(normalizedPayload);

    const linkedInPost = await generateLinkedInPost({
      title: normalizedPayload.title,
      difficulty: normalizedPayload.difficulty,
      explanation
    });

    const publishResult = await publishLinkedInPost(linkedInPost);

    return res.json({
      explanation,
      linkedin_post: linkedInPost,
      linkedin_post_id: publishResult.id,
      status: "posted"
    });
  } catch (error) {
    const statusCode = mapStatusCode(error);

    return res.status(statusCode).json({
      error: toErrorMessage(error)
    });
  }
});

function mapStatusCode(error: unknown): number {
  const message = toErrorMessage(error);

  if (message.includes("is not set in environment variables")) {
    return 500;
  }

  if (isTimeoutError(error) || isLinkedInTimeoutError(error)) {
    return 504;
  }

  if (isLinkedInAuthError(error)) {
    return 401;
  }

  if (isLinkedInApiError(error)) {
    return 502;
  }

  return 502;
}

function isValidAnalyzePayload(payload: Partial<AnalyzeRequestPayload>): payload is AnalyzeRequestPayload {
  return (
    isNonEmptyString(payload.title) &&
    isNonEmptyString(payload.difficulty) &&
    isNonEmptyString(payload.code) &&
    isNonEmptyString(payload.url)
  );
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function toErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Unknown error";
}

export default router;
