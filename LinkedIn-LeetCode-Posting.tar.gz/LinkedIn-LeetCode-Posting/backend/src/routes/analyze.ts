import { Router } from "express";
import { analyzeSubmission, isTimeoutError } from "../services/llm";

interface AnalyzeRequestPayload {
  title: string;
  difficulty: string;
  code: string;
  url: string;
}

const router = Router();

router.post("/", async (req, res) => {
  const payload = req.body as Partial<AnalyzeRequestPayload>;

  if (!isValidPayload(payload)) {
    return res.status(400).json({
      error: "Invalid payload. Required fields: title, difficulty, code, url"
    });
  }

  try {
    const explanation = await analyzeSubmission({
      title: payload.title.trim(),
      difficulty: payload.difficulty.trim(),
      code: payload.code,
      url: payload.url.trim()
    });

    return res.json({
      explanation,
      model: "openai/gpt-oss-120b:free"
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    const statusCode = isTimeoutError(error) ? 504 : 502;

    return res.status(statusCode).json({
      error: message
    });
  }
});

function isValidPayload(payload: Partial<AnalyzeRequestPayload>): payload is AnalyzeRequestPayload {
  return (
    isNonEmptyString(payload.title) &&
    isNonEmptyString(payload.difficulty) &&
    isNonEmptyString(payload.code) &&
    isNonEmptyString(payload.url)
  );
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

export default router;
