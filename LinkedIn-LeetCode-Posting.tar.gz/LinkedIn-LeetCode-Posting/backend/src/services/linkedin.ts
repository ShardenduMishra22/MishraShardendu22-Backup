import { loadEnvironment } from "../config/env";

const LINKEDIN_POST_URL = "https://api.linkedin.com/v2/ugcPosts";

const linkedInTimeoutErrorSymbol = Symbol("linkedin-timeout-error");
const linkedInAuthErrorSymbol = Symbol("linkedin-auth-error");
const linkedInApiErrorSymbol = Symbol("linkedin-api-error");

type LinkedInTimeoutError = Error & { [linkedInTimeoutErrorSymbol]: true };
type LinkedInAuthError = Error & { [linkedInAuthErrorSymbol]: true };
type LinkedInApiError = Error & { [linkedInApiErrorSymbol]: true };

interface LinkedInApiResponse {
  id?: string;
  message?: string;
  serviceErrorCode?: number;
  status?: number;
}

interface PublishLinkedInPostResult {
  id: string | null;
}

export async function publishLinkedInPost(postText: string): Promise<PublishLinkedInPostResult> {
  let accessToken = process.env.LINKEDIN_ACCESS_TOKEN?.trim();
  let linkedInUserId = process.env.LINKEDIN_USER_ID?.trim();

  if (!accessToken || !linkedInUserId) {
    loadEnvironment(true);
    accessToken = process.env.LINKEDIN_ACCESS_TOKEN?.trim();
    linkedInUserId = process.env.LINKEDIN_USER_ID?.trim();
  }

  if (!accessToken) {
    throw new Error("LINKEDIN_ACCESS_TOKEN is not set in environment variables");
  }

  if (!linkedInUserId) {
    throw new Error("LINKEDIN_USER_ID is not set in environment variables");
  }

  const trimmedPostText = postText.trim();
  if (!trimmedPostText) {
    throw new Error("LinkedIn post content is empty");
  }

  const response = await withTimeout(
    fetch(LINKEDIN_POST_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "X-Restli-Protocol-Version": "2.0.0",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        author: `urn:li:person:${linkedInUserId}`,
        lifecycleState: "PUBLISHED",
        specificContent: {
          "com.linkedin.ugc.ShareContent": {
            shareCommentary: {
              text: trimmedPostText
            },
            shareMediaCategory: "NONE"
          }
        },
        visibility: {
          "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"
        }
      })
    }),
    Number(process.env.LINKEDIN_TIMEOUT_MS ?? 20000),
    "LinkedIn API request timed out"
  );

  const data = (await safeJson(response)) as LinkedInApiResponse | null;

  if (!response.ok) {
    const apiMessage = getLinkedInErrorMessage(data, response.status);

    if (response.status === 401 || response.status === 403) {
      const error = new Error(`LinkedIn authentication failed: ${apiMessage}`) as LinkedInAuthError;
      error[linkedInAuthErrorSymbol] = true;
      throw error;
    }

    const error = new Error(`LinkedIn API request failed: ${apiMessage}`) as LinkedInApiError;
    error[linkedInApiErrorSymbol] = true;
    throw error;
  }

  return {
    id: typeof data?.id === "string" ? data.id : null
  };
}

export function isLinkedInTimeoutError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    linkedInTimeoutErrorSymbol in error &&
    (error as { [linkedInTimeoutErrorSymbol]?: boolean })[linkedInTimeoutErrorSymbol] === true
  );
}

export function isLinkedInAuthError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    linkedInAuthErrorSymbol in error &&
    (error as { [linkedInAuthErrorSymbol]?: boolean })[linkedInAuthErrorSymbol] === true
  );
}

export function isLinkedInApiError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    linkedInApiErrorSymbol in error &&
    (error as { [linkedInApiErrorSymbol]?: boolean })[linkedInApiErrorSymbol] === true
  );
}

function getLinkedInErrorMessage(data: LinkedInApiResponse | null, statusCode: number): string {
  if (!data) {
    return `status ${statusCode}`;
  }

  const parts: string[] = [];

  if (typeof data.message === "string" && data.message.trim()) {
    parts.push(data.message.trim());
  }

  if (typeof data.serviceErrorCode === "number") {
    parts.push(`serviceErrorCode=${data.serviceErrorCode}`);
  }

  if (parts.length === 0) {
    parts.push(`status ${statusCode}`);
  }

  return parts.join(" | ");
}

async function safeJson(response: Response): Promise<unknown> {
  try {
    return await response.json();
  } catch {
    return null;
  }
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number, message: string): Promise<T> {
  let timeoutHandle: NodeJS.Timeout | null = null;

  const timeoutPromise = new Promise<T>((_, reject) => {
    timeoutHandle = setTimeout(() => {
      const error = new Error(message) as LinkedInTimeoutError;
      error[linkedInTimeoutErrorSymbol] = true;
      reject(error);
    }, timeoutMs);
  });

  return Promise.race([promise, timeoutPromise]).finally(() => {
    if (timeoutHandle) {
      clearTimeout(timeoutHandle);
    }
  });
}
