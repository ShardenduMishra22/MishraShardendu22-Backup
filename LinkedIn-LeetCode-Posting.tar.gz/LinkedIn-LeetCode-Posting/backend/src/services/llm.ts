import { OpenRouter } from "@openrouter/sdk";
import { loadEnvironment } from "../config/env";

interface AnalyzeRequestPayload {
  title: string;
  difficulty: string;
  code: string;
  url: string;
}

export interface StructuredExplanation {
  problemSummary: string;
  coreIdea: string;
  approach: string[];
  timeComplexity: string;
  spaceComplexity: string;
  edgeCases: string[];
}

const DEFAULT_PRIMARY_MODEL = "openai/gpt-oss-120b:free";
const DEFAULT_FALLBACK_MODELS = ["openrouter/auto"];

const timeoutErrorSymbol = Symbol("timeout-error");
type TimeoutError = Error & { [timeoutErrorSymbol]: true };

let client: OpenRouter | null = null;

export async function analyzeSubmission(payload: AnalyzeRequestPayload): Promise<StructuredExplanation> {
  const completion = await requestCompletion({
    systemPrompt:
      "You are a strict algorithm explanation engine. You only return concise, technical, structured answers.",
    userPrompt: buildExplanationPrompt(payload),
    temperature: 0.1
  });

  const content = readMessageContent(completion);

  if (!content) {
    throw new Error("OpenRouter returned an empty response");
  }

  return parseStructuredExplanation(content);
}

interface LinkedInPromptInput {
  title: string;
  difficulty: string;
  explanation: StructuredExplanation;
}

interface CompletionRequest {
  systemPrompt: string;
  userPrompt: string;
  temperature: number;
}

export async function generateLinkedInPost(input: LinkedInPromptInput): Promise<string> {
  const completion = await requestCompletion({
    systemPrompt:
      "You are a professional technical writer for software engineers. You create concise, polished posts.",
    userPrompt: buildLinkedInPrompt(input),
    temperature: 0.3
  });

  const content = readMessageContent(completion);

  if (!content) {
    throw new Error("OpenRouter returned an empty LinkedIn post response");
  }

  const cleaned = sanitizeLinkedInPost(content);

  if (!cleaned) {
    throw new Error("LinkedIn post generation returned empty content");
  }

  return cleaned;
}

export function isTimeoutError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    timeoutErrorSymbol in error &&
    (error as { [timeoutErrorSymbol]?: boolean })[timeoutErrorSymbol] === true
  );
}

async function requestCompletion(request: CompletionRequest): Promise<unknown> {
  const openRouter = getOpenRouterClient();
  const timeoutMs = Number(process.env.OPENROUTER_TIMEOUT_MS ?? 30000);

  return withTimeout(
    sendCompletion(openRouter, request),
    timeoutMs,
    "OpenRouter request timed out"
  );
}

function getOpenRouterClient(): OpenRouter {
  let apiKey = process.env.OPENROUTER_API_KEY;

  if (!apiKey) {
    loadEnvironment(true);
    apiKey = process.env.OPENROUTER_API_KEY;
  }

  if (!apiKey) {
    throw new Error("OPENROUTER_API_KEY is not set in environment variables");
  }

  if (!client) {
    client = new OpenRouter({ apiKey });
  }

  return client;
}

async function sendCompletion(openRouter: OpenRouter, request: CompletionRequest): Promise<unknown> {
  const chatApi = (openRouter as unknown as {
    chat?: {
      send?: (params: unknown) => Promise<unknown>;
      completions?: {
        create?: (params: unknown) => Promise<unknown>;
      };
    };
  }).chat;

  const baseParams = {
    messages: [
      {
        role: "system",
        content: request.systemPrompt
      },
      {
        role: "user",
        content: request.userPrompt
      }
    ],
    stream: false,
    temperature: request.temperature
  };

  if (!chatApi?.send && !chatApi?.completions?.create) {
    throw new Error("OpenRouter SDK chat API is unavailable");
  }

  const modelCandidates = resolveModelCandidates();
  let lastError: unknown = null;

  for (const model of modelCandidates) {
    const params = {
      ...baseParams,
      model
    };

    try {
      if (chatApi?.send) {
        return await chatApi.send({ chatGenerationParams: params });
      }

      if (chatApi?.completions?.create) {
        return await chatApi.completions.create(params);
      }
    } catch (error) {
      lastError = error;

      if (shouldTryNextModel(error) && model !== modelCandidates[modelCandidates.length - 1]) {
        continue;
      }

      throw enhanceOpenRouterError(error, model, modelCandidates);
    }
  }

  throw enhanceOpenRouterError(lastError, modelCandidates[0], modelCandidates);
}

function resolveModelCandidates(): string[] {
  const primary = cleanModelName(process.env.OPENROUTER_MODEL) ?? DEFAULT_PRIMARY_MODEL;

  const fallbackFromEnv = (process.env.OPENROUTER_FALLBACK_MODELS ?? DEFAULT_FALLBACK_MODELS.join(","))
    .split(",")
    .map((model) => cleanModelName(model))
    .filter((model): model is string => Boolean(model));

  return Array.from(new Set([primary, ...fallbackFromEnv]));
}

function cleanModelName(value: string | undefined): string | null {
  const trimmed = value?.trim();
  return trimmed ? trimmed : null;
}

function shouldTryNextModel(error: unknown): boolean {
  const message = toErrorMessage(error).toLowerCase();

  return (
    message.includes("no endpoints available") ||
    message.includes("provider overloaded") ||
    message.includes("service unavailable") ||
    message.includes("bad gateway") ||
    message.includes("model unavailable")
  );
}

function enhanceOpenRouterError(error: unknown, model: string, triedModels: string[]): Error {
  const message = toErrorMessage(error);

  if (message.includes("No endpoints available matching your guardrail restrictions and data policy")) {
    return new Error(
      `OpenRouter privacy/guardrail policy blocked model '${model}'. Tried models: ${triedModels.join(", ")}. ` +
        "Update OpenRouter privacy settings or set OPENROUTER_MODEL/OPENROUTER_FALLBACK_MODELS to compatible models."
    );
  }

  return new Error(message);
}

function toErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error ?? "Unknown OpenRouter error");
}

function buildExplanationPrompt(payload: AnalyzeRequestPayload): string {
  return [
    "Analyze this accepted LeetCode submission.",
    "",
    "Return ONLY valid JSON with this exact shape:",
    "{",
    '  "problemSummary": "2-3 concise lines",',
    '  "coreIdea": "1-2 concise lines",',
    '  "approach": ["step 1", "step 2", "..."],',
    '  "timeComplexity": "O(...) with short reason",',
    '  "spaceComplexity": "O(...) with short reason",',
    '  "edgeCases": ["case 1", "case 2", "..."]',
    "}",
    "",
    "Hard constraints:",
    "- No fluff",
    "- No storytelling",
    "- No code repetition",
    "- Focus only on algorithmic reasoning",
    "",
    "Submission metadata:",
    `Title: ${payload.title}`,
    `Difficulty: ${payload.difficulty}`,
    `URL: ${payload.url}`,
    "Code:",
    payload.code
  ].join("\n");
}

function buildLinkedInPrompt(input: LinkedInPromptInput): string {
  return [
    "You are generating a professional LinkedIn post.",
    "",
    "INPUT:",
    `- Problem Title: ${input.title}`,
    `- Difficulty: ${input.difficulty}`,
    "- Explanation:",
    formatExplanationForPrompt(input.explanation),
    "",
    "OUTPUT:",
    "- Strong hook (1-2 lines)",
    "- Problem summary (2-3 lines)",
    "- Approach (concise)",
    "- Time & Space complexity",
    "- Clean formatting",
    "- 3-5 relevant hashtags",
    "",
    "Constraints:",
    "- No emojis",
    "- No fluff",
    "- Max 250 words",
    "- Professional tone",
    "",
    "Return ONLY the final LinkedIn post."
  ].join("\n");
}

function formatExplanationForPrompt(explanation: StructuredExplanation): string {
  const approach = explanation.approach.map((step, index) => `${index + 1}. ${step}`).join("\n");
  const edgeCases = explanation.edgeCases.map((item) => `- ${item}`).join("\n");

  return [
    `Problem Summary: ${explanation.problemSummary}`,
    `Core Idea: ${explanation.coreIdea}`,
    "Approach:",
    approach,
    `Time Complexity: ${explanation.timeComplexity}`,
    `Space Complexity: ${explanation.spaceComplexity}`,
    "Edge Cases:",
    edgeCases
  ].join("\n");
}

function sanitizeLinkedInPost(rawText: string): string {
  const withoutCodeFence = rawText
    .replace(/^```[a-zA-Z]*\n?/, "")
    .replace(/\n?```$/, "")
    .trim();

  const withoutEmojis = withoutCodeFence.replace(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu, "");
  const words = withoutEmojis.split(/\s+/).filter(Boolean);

  if (words.length <= 250) {
    return withoutEmojis.trim();
  }

  return words.slice(0, 250).join(" ").trim();
}

function readMessageContent(completion: unknown): string {
  const typed = completion as {
    choices?: Array<{
      message?: {
        content?: unknown;
      };
    }>;
  };

  const content = typed.choices?.[0]?.message?.content;

  if (typeof content === "string") {
    return content.trim();
  }

  if (Array.isArray(content)) {
    const merged = content
      .map((part) => {
        if (typeof part === "string") {
          return part;
        }

        if (typeof part === "object" && part !== null && "text" in part) {
          return String((part as { text: unknown }).text ?? "");
        }

        return "";
      })
      .join("\n")
      .trim();

    return merged;
  }

  return "";
}

function parseStructuredExplanation(rawText: string): StructuredExplanation {
  const jsonLike = extractJson(rawText);

  let parsed: unknown;
  try {
    parsed = JSON.parse(jsonLike);
  } catch {
    throw new Error("LLM returned invalid JSON format");
  }

  if (!isStructuredExplanation(parsed)) {
    throw new Error("LLM response is missing required structured fields");
  }

  return {
    problemSummary: parsed.problemSummary.trim(),
    coreIdea: parsed.coreIdea.trim(),
    approach: parsed.approach.map((step) => step.trim()).filter(Boolean),
    timeComplexity: parsed.timeComplexity.trim(),
    spaceComplexity: parsed.spaceComplexity.trim(),
    edgeCases: parsed.edgeCases.map((item) => item.trim()).filter(Boolean)
  };
}

function isStructuredExplanation(value: unknown): value is StructuredExplanation {
  if (typeof value !== "object" || value === null) {
    return false;
  }

  const candidate = value as Partial<StructuredExplanation>;

  return (
    typeof candidate.problemSummary === "string" &&
    typeof candidate.coreIdea === "string" &&
    Array.isArray(candidate.approach) &&
    candidate.approach.every((step) => typeof step === "string") &&
    typeof candidate.timeComplexity === "string" &&
    typeof candidate.spaceComplexity === "string" &&
    Array.isArray(candidate.edgeCases) &&
    candidate.edgeCases.every((item) => typeof item === "string")
  );
}

function extractJson(rawText: string): string {
  const codeFenceMatch = rawText.match(/```json\s*([\s\S]*?)```/i);
  if (codeFenceMatch?.[1]) {
    return codeFenceMatch[1].trim();
  }

  const firstBrace = rawText.indexOf("{");
  const lastBrace = rawText.lastIndexOf("}");

  if (firstBrace === -1 || lastBrace === -1 || lastBrace <= firstBrace) {
    throw new Error("LLM response did not contain a JSON object");
  }

  return rawText.slice(firstBrace, lastBrace + 1);
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number, message: string): Promise<T> {
  let timeoutHandle: NodeJS.Timeout | null = null;

  const timeoutPromise = new Promise<T>((_, reject) => {
    timeoutHandle = setTimeout(() => {
      const error = new Error(message) as TimeoutError;
      error[timeoutErrorSymbol] = true;
      reject(error);
    }, timeoutMs);
  });

  return Promise.race([promise, timeoutPromise]).finally(() => {
    if (timeoutHandle) {
      clearTimeout(timeoutHandle);
    }
  });
}
