import express from "express";
import analyzeRouter from "./routes/analyze";
import linkedinRouter from "./routes/linkedin";
import { loadEnvironment } from "./config/env";

loadEnvironment();

const app = express();
const port = Number(process.env.PORT ?? 3000);

app.use(express.json({ limit: "1mb" }));
app.use(corsGuard);

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "leetcode-local-backend" });
});

app.use("/analyze", analyzeRouter);
app.use("/", linkedinRouter);

app.use((error: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const message = error instanceof Error ? error.message : "Unexpected server error";
  res.status(500).json({ error: message });
});

app.listen(port, () => {
  console.log(`Backend listening on http://localhost:${port}`);
});

function corsGuard(req: express.Request, res: express.Response, next: express.NextFunction): void {
  const origin = req.headers.origin;

  if (origin && !isAllowedOrigin(origin)) {
    res.status(403).json({ error: "Origin is not allowed" });
    return;
  }

  if (origin) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }

  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  next();
}

function isAllowedOrigin(origin: string): boolean {
  return (
    /^chrome-extension:\/\/[a-p]{32}$/i.test(origin) ||
    /^http:\/\/localhost(?::\d+)?$/i.test(origin) ||
    /^http:\/\/127\.0\.0\.1(?::\d+)?$/i.test(origin)
  );
}
