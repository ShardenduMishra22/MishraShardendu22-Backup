# LinkedIn API Posting

## 1. LinkedIn Post (Architecture Content)

**Title:** Browser Automation vs Official API — Architecture Perspective

Most developers start with browser automation tools like Selenium or Playwright to interact with platforms.

But in production systems, this approach breaks.

### Why?

* UI changes break selectors
* Bot detection blocks accounts
* No scalability guarantees

### Correct Architecture Approach

Use official APIs instead of simulating users.

For LinkedIn:

* Use OAuth 2.0 for authentication
* Use UGC API (`/v2/ugcPosts`) for posting
* Maintain token lifecycle (refresh/expiry)

### High-Level Flow

Client → Auth Server (OAuth) → Access Token → LinkedIn API → Post Created

### Benefits

* Stable contract (API vs UI scraping)
* Scalable (rate-limited, predictable)
* Secure (no credential automation)

### Production Insight

All enterprise systems (CRM, marketing tools, schedulers) use APIs—not browser automation—for social posting.

#SystemDesign #API #LinkedIn #Automation #Architecture

---

## 2. Brief — How API Posting Works

1. Authenticate (OAuth 2.0)
2. Get access token
3. Call `POST /v2/ugcPosts`
4. Pass content in JSON
5. LinkedIn publishes post

---

## 3. Detailed Flow

### Step 1 — Authentication

* Use OAuth 2.0
* Request scope: `w_member_social`
* Get **access token**

---

### Step 2 — Prepare Request

* Endpoint:

```
https://api.linkedin.com/v2/ugcPosts
```

* Headers:

```
Authorization: Bearer <access_token>
X-Restli-Protocol-Version: 2.0.0
Content-Type: application/json
```

---

### Step 3 — Request Body

```json id="9a3kd2"
{
  "author": "urn:li:person:YOUR_ID",
  "lifecycleState": "PUBLISHED",
  "specificContent": {
    "com.linkedin.ugc.ShareContent": {
      "shareCommentary": {
        "text": "Your architecture post content"
      },
      "shareMediaCategory": "NONE"
    }
  },
  "visibility": {
    "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"
  }
}
```

---

### Step 4 — Execute

* Send HTTP POST
* Response: `201 Created` → post published 

---

### Step 5 — (Optional)

* Add media (image/video) → upload asset → attach in request

---

## 4. Production Architecture Example

```
Frontend (React / App)
        ↓
Backend Service (Auth + Token Mgmt)
        ↓
LinkedIn OAuth Server
        ↓
LinkedIn UGC API
        ↓
Post Published
```

---

## Key Terminology

* OAuth 2.0
* Access Token
* UGC API
* REST Endpoint
* Rate Limiting
* Token Expiry
* API Contract vs UI Automation
