interface AnalyzePayload {
  title: string;
  difficulty: string;
  code: string;
  url: string;
  submissionId?: string;
  language?: string;
}

interface LeetCodePostDraft {
  title: string;
  content: string;
  autoPublish: boolean;
}

interface LeetCodePostPreparationPayload {
  postUrl: string;
}

const ACCEPTED_TEXT = "Accepted";
let lastAcceptedFingerprint = "";
let checkTimer: number | null = null;

bootstrap();

function bootstrap(): void {
  installMessageHandler();

  if (document.body) {
    installMutationObserver();
  } else {
    window.addEventListener("DOMContentLoaded", installMutationObserver, { once: true });
  }

  scheduleAcceptedCheck();
  window.addEventListener("load", scheduleAcceptedCheck, { once: true });

  // LeetCode uses SPA navigation; periodic checks cover cases where mutation hooks miss transitions.
  window.setInterval(() => {
    if (isProblemPage()) {
      scheduleAcceptedCheck();
    }
  }, 1500);
}

function installMessageHandler(): void {
  chrome.runtime.onMessage.addListener((message: unknown, _sender, sendResponse) => {
    void (async () => {
      const typed = message as { type?: string; draft?: unknown };

      if (typed.type === "EXTRACT_NOW") {
        if (!isProblemPage()) {
          sendResponse({
            ok: false,
            error: "Open a LeetCode problem page first"
          });
          return;
        }

        const payload = extractSubmissionData();

        if (!isPayloadReady(payload)) {
          sendResponse({
            ok: false,
            error: "Could not extract problem code. Keep the code panel visible and retry."
          });
          return;
        }

        sendResponse({
          ok: true,
          payload
        });
        return;
      }

      if (typed.type === "APPLY_LEETCODE_POST_DRAFT") {
        if (!isLeetCodePostPage()) {
          sendResponse({
            ok: false,
            error: "Current tab is not a LeetCode post-solution page"
          });
          return;
        }

        if (!isLeetCodePostDraft(typed.draft)) {
          sendResponse({
            ok: false,
            error: "Invalid LeetCode draft payload"
          });
          return;
        }

        try {
          await applyLeetCodePostDraft(typed.draft);
          sendResponse({ ok: true });
        } catch (error) {
          sendResponse({
            ok: false,
            error: error instanceof Error ? error.message : "Failed to apply LeetCode post draft"
          });
        }
        return;
      }

      if (typed.type === "PREPARE_LEETCODE_POST_PAGE") {
        const payload = typed as { postUrl?: unknown };

        if (!isLeetCodePostPreparationPayload(payload)) {
          sendResponse({
            ok: false,
            error: "Invalid post page preparation payload"
          });
          return;
        }

        try {
          const prepared = await prepareLeetCodePostPage(payload.postUrl);
          if (prepared) {
            sendResponse({ ok: true });
          } else {
            sendResponse({
              ok: false,
              error: "Could not navigate to LeetCode post-solution page automatically"
            });
          }
        } catch (error) {
          sendResponse({
            ok: false,
            error: error instanceof Error ? error.message : "Failed to prepare LeetCode post page"
          });
        }
        return;
      }

      sendResponse({
        ok: false,
        error: "Unsupported content-script message"
      });
    })();

    return true;
  });
}

function installMutationObserver(): void {
  const observer = new MutationObserver(() => {
    scheduleAcceptedCheck();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });
}

function scheduleAcceptedCheck(): void {
  if (checkTimer !== null) {
    window.clearTimeout(checkTimer);
  }

  checkTimer = window.setTimeout(() => {
    void detectAcceptedSubmission();
  }, 220);
}

async function detectAcceptedSubmission(): Promise<void> {
  if (!isProblemPage()) {
    return;
  }

  const acceptedFound = hasAcceptedSignal();

  if (!acceptedFound) {
    return;
  }

  const payload = extractSubmissionData();

  if (!isPayloadReady(payload)) {
    return;
  }

  const fingerprint = `${payload.url}:${hashText(payload.code.slice(0, 280))}`;
  if (fingerprint === lastAcceptedFingerprint) {
    return;
  }

  const enabled = await isExtensionEnabled();
  if (!enabled) {
    return;
  }

  lastAcceptedFingerprint = fingerprint;

  await chrome.runtime.sendMessage({
    type: "SUBMISSION_ACCEPTED",
    payload
  });
}

function hasAcceptedSignal(): boolean {
  const exactMatchSelectors = [
    '[data-e2e-locator="submission-result"]',
    '[data-e2e-locator*="result"]',
    ".text-green-s",
    ".text-success"
  ];

  for (const selector of exactMatchSelectors) {
    const nodes = document.querySelectorAll(selector);
    for (const node of nodes) {
      const text = cleanText(node.textContent);
      if (text === ACCEPTED_TEXT || text.includes(` ${ACCEPTED_TEXT} `) || text.startsWith(`${ACCEPTED_TEXT}\n`)) {
        return true;
      }
    }
  }

  const bodyText = document.body.innerText;
  return /\bAccepted\b/.test(bodyText) && /\bRuntime\b/.test(bodyText) && /\bMemory\b/.test(bodyText);
}

function extractSubmissionData(): AnalyzePayload {
  const title = extractTitle();
  const difficulty = extractDifficulty();

  const primary = normalizeCode(extractCodeFromDom());
  const monacoFallback = normalizeCode(extractCodeFromViewLines());
  const visibleFallback = normalizeCode(extractVisibleCodeText());

  let code = primary;

  if (!isReliableCode(code)) {
    code = monacoFallback;
  }

  if (!isReliableCode(code)) {
    code = visibleFallback;
  }

  if (!code) {
    code = primary || monacoFallback || visibleFallback;
  }

  return {
    title,
    difficulty,
    code,
    url: window.location.href,
    submissionId: extractSubmissionId(),
    language: extractLanguage()
  };
}

function extractTitle(): string {
  const selectors = [
    'div[data-cy="question-title"]',
    'a[href*="/problems/"][href*="/description"]',
    'a[href^="/problems/"]',
    "h1"
  ];

  for (const selector of selectors) {
    const node = document.querySelector(selector);
    const text = cleanText(node?.textContent);
    if (text) {
      return text.replace(/^\d+\.\s*/, "");
    }
  }

  const fromTitle = document.title.replace(/\s*-\s*LeetCode\s*$/, "").trim();
  if (fromTitle && !/^All Submissions$/i.test(fromTitle)) {
    return fromTitle;
  }

  return titleFromUrlSlug() ?? "Unknown Problem";
}

function extractDifficulty(): string {
  const selectors = [
    '[diff="easy"]',
    '[diff="medium"]',
    '[diff="hard"]',
    '[class*="difficulty"]',
    ".text-difficulty-easy",
    ".text-difficulty-medium",
    ".text-difficulty-hard"
  ];

  for (const selector of selectors) {
    const nodes = document.querySelectorAll(selector);
    for (const node of nodes) {
      const normalized = normalizeDifficulty(cleanText(node.textContent));
      if (normalized) {
        return normalized;
      }
    }
  }

  const textMatch = document.body.innerText.match(/\b(Easy|Medium|Hard)\b/);
  return textMatch?.[1] ?? "Unknown";
}

function extractCodeFromDom(): string {
  const selectors = [
    ".monaco-editor textarea",
    ".monaco-editor .inputarea",
    "textarea.inputarea",
    "textarea",
    "pre code",
    ".view-lines .view-line",
    ".CodeMirror-code",
    "[data-track-load='code_editor']"
  ];

  const candidates: string[] = [];

  for (const selector of selectors) {
    const nodes = document.querySelectorAll(selector);
    for (const node of nodes) {
      if (node instanceof HTMLTextAreaElement) {
        if (node.value.trim()) {
          candidates.push(node.value);
          continue;
        }
      }

      const text = node.textContent;
      if (text && text.trim()) {
        candidates.push(text);
      }
    }
  }

  return pickBestCodeCandidate(candidates);
}

function extractCodeFromViewLines(): string {
  const lineNodes = document.querySelectorAll(".monaco-editor .view-lines .view-line, .view-lines .view-line");
  if (lineNodes.length > 0) {
    const lines = Array.from(lineNodes).map((line) =>
      (line.textContent ?? "").replace(/\u00a0/g, " ").replace(/\s+$/, "")
    );

    return lines.join("\n");
  }

  const viewLines = document.querySelector(".monaco-editor .view-lines");
  return viewLines?.textContent ?? "";
}

function extractVisibleCodeText(): string {
  const selectors = [
    "pre code",
    "pre",
    ".monaco-editor",
    ".view-lines",
    "[class*='CodeMirror']",
    "[class*='monaco']"
  ];
  const candidates: string[] = [];

  for (const selector of selectors) {
    const nodes = document.querySelectorAll(selector);
    for (const node of nodes) {
      const text = normalizeCode(node.textContent ?? "");
      if (text.length >= 20) {
        candidates.push(text);
      }
    }
  }

  return pickBestCodeCandidate(candidates);
}

function normalizeDifficulty(value: string): string | null {
  const lowered = value.toLowerCase();

  if (lowered.includes("easy")) {
    return "Easy";
  }

  if (lowered.includes("medium")) {
    return "Medium";
  }

  if (lowered.includes("hard")) {
    return "Hard";
  }

  return null;
}

function isReliableCode(code: string): boolean {
  if (!code) {
    return false;
  }

  const lineCount = code.split("\n").filter((line) => line.trim().length > 0).length;
  const looksLikeCode = /[{}();=<>,\[\]]/.test(code);

  return code.length >= 40 && lineCount >= 2 && looksLikeCode;
}

function isPayloadReady(payload: AnalyzePayload): boolean {
  return (
    cleanText(payload.title).length > 0 &&
    cleanText(payload.difficulty).length > 0 &&
    normalizeCode(payload.code).length > 0 &&
    cleanText(payload.url).length > 0
  );
}

function normalizeCode(input: string): string {
  return input
    .replace(/\u00a0/g, " ")
    .replace(/\r\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function cleanText(value: string | null | undefined): string {
  return (value ?? "").replace(/\s+/g, " ").trim();
}

function hashText(value: string): string {
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) {
    hash = (hash << 5) - hash + value.charCodeAt(i);
    hash |= 0;
  }
  return String(hash);
}

function titleFromUrlSlug(): string | null {
  const match = window.location.pathname.match(/^\/problems\/([^\/]+)/i);
  if (!match?.[1]) {
    return null;
  }

  return match[1]
    .split("-")
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function pickBestCodeCandidate(candidates: string[]): string {
  const normalized = candidates
    .map((candidate) => normalizeCode(candidate))
    .filter(Boolean)
    .filter((candidate) => candidate.length >= 20);

  if (normalized.length === 0) {
    return "";
  }

  normalized.sort((a, b) => scoreCodeCandidate(b) - scoreCodeCandidate(a));
  return normalized[0];
}

function scoreCodeCandidate(value: string): number {
  const lengthWeight = Math.min(value.length, 2000);
  const lineCount = value.split("\n").length;
  const syntaxBonus = /[{}();=<>,\[\]#]/.test(value) ? 500 : 0;
  return lengthWeight + lineCount * 20 + syntaxBonus;
}

function isProblemPage(): boolean {
  return /^\/problems\//.test(window.location.pathname);
}

function isLeetCodePostPage(): boolean {
  return /^\/problems\/[^/]+\/post-solution\/?/i.test(window.location.pathname);
}

function extractSubmissionId(): string | undefined {
  const fromPath = window.location.pathname.match(/\/submissions\/(\d+)/i)?.[1];
  if (fromPath) {
    return fromPath;
  }

  const fromQuery = new URLSearchParams(window.location.search).get("submissionId");
  if (fromQuery?.trim()) {
    return fromQuery.trim();
  }

  const candidateLink = document.querySelector('a[href*="submissionId="]') as HTMLAnchorElement | null;
  if (candidateLink?.href) {
    const parsed = new URL(candidateLink.href, window.location.origin);
    const submissionId = parsed.searchParams.get("submissionId") ?? parsed.pathname.match(/\/submissions\/(\d+)/i)?.[1];
    if (submissionId?.trim()) {
      return submissionId.trim();
    }
  }

  return undefined;
}

function extractLanguage(): string | undefined {
  const selectors = [
    '[data-cy="lang-select"]',
    '[id*="lang"]',
    'button[class*="language"]',
    '[class*="language-select"]'
  ];

  for (const selector of selectors) {
    const nodes = document.querySelectorAll(selector);
    for (const node of nodes) {
      const text = cleanText(node.textContent);
      if (text && text.length <= 24 && /[A-Za-z+#]/.test(text)) {
        return text;
      }
    }
  }

  return undefined;
}

function isLeetCodePostDraft(value: unknown): value is LeetCodePostDraft {
  if (typeof value !== "object" || value === null) {
    return false;
  }

  const draft = value as Partial<LeetCodePostDraft>;

  return (
    typeof draft.title === "string" &&
    draft.title.trim().length > 0 &&
    typeof draft.content === "string" &&
    draft.content.trim().length > 0 &&
    typeof draft.autoPublish === "boolean"
  );
}

async function applyLeetCodePostDraft(draft: LeetCodePostDraft): Promise<void> {
  if (!isLeetCodePostPage()) {
    throw new Error("Current tab is not LeetCode post-solution page");
  }

  const titleElement = await waitForElement([
    'input[placeholder="Enter your title"]',
    'input[placeholder*="Enter your title" i]',
    'input[placeholder*="title" i]',
    'input[aria-label*="title" i]',
    'main input[type="text"]'
  ], 20000);

  setFormValue(titleElement, draft.title);

  const editorApplied = await setEditorContent(draft.content);
  if (!editorApplied) {
    throw new Error("Unable to populate LeetCode explanation editor automatically");
  }

  await delay(350);

  if (draft.autoPublish) {
    await clickPostButton();
  }
}

async function setEditorContent(content: string): Promise<boolean> {
  const normalized = normalizeCode(content);

  const codeMirrorRoot = document.querySelector(".cm-editor");
  if (codeMirrorRoot) {
    const cmView =
      (codeMirrorRoot as unknown as { cmView?: { view?: { state: { doc: { length: number } }; dispatch: (spec: unknown) => void } } }).cmView
        ?.view ??
      (codeMirrorRoot as unknown as { view?: { state: { doc: { length: number } }; dispatch: (spec: unknown) => void } }).view;

    if (cmView?.dispatch) {
      cmView.dispatch({
        changes: {
          from: 0,
          to: cmView.state.doc.length,
          insert: normalized
        }
      });

      await delay(120);
      return true;
    }
  }

  const textareaSelectors = [
    'textarea[placeholder*="solution" i]',
    ".monaco-editor textarea.inputarea",
    ".monaco-editor textarea",
    "textarea"
  ];

  for (const selector of textareaSelectors) {
    const textarea = document.querySelector(selector);
    if (textarea instanceof HTMLTextAreaElement) {
      setFormValue(textarea, content);
      const currentValue = textarea.value || textarea.textContent || "";
      if (normalizeCode(currentValue).length > 0) {
        return true;
      }
    }
  }

  const contentEditableSelectors = [
    ".cm-content",
    ".public-DraftEditor-content",
    '[data-lexical-editor="true"]',
    '[contenteditable="true"][role="textbox"]',
    '[contenteditable="true"]'
  ];

  for (const selector of contentEditableSelectors) {
    const element = document.querySelector(selector);
    if (element instanceof HTMLElement) {
      setContentEditableValue(element, content);
      if (normalizeCode(element.innerText || element.textContent || "").length > 0) {
        return true;
      }
    }
  }

  return false;
}

function setFormValue(element: HTMLInputElement | HTMLTextAreaElement, value: string): void {
  element.focus();

  const setter =
    element instanceof HTMLInputElement
      ? Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set
      : Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;

  if (setter) {
    setter.call(element, value);
  } else {
    element.value = value;
  }

  element.dispatchEvent(new Event("input", { bubbles: true }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
}

function setContentEditableValue(element: HTMLElement, value: string): void {
  element.focus();
  if (document.getSelection) {
    const selection = document.getSelection();
    if (selection) {
      const range = document.createRange();
      range.selectNodeContents(element);
      selection.removeAllRanges();
      selection.addRange(range);
    }
  }

  try {
    document.execCommand("selectAll", false);
    document.execCommand("insertText", false, value);
  } catch {
    element.textContent = value;
  }

  if (normalizeCode(element.innerText || element.textContent || "") !== normalizeCode(value)) {
    element.textContent = value;
  }

  element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
}

async function clickPostButton(): Promise<void> {
  const deadline = Date.now() + 15000;

  while (Date.now() < deadline) {
    const button = findPostButton();
    if (button && !isButtonDisabled(button)) {
      button.click();
      return;
    }

    await delay(300);
  }

  throw new Error("Draft is filled but Post button is disabled. Review once and click Post manually.");
}

function findPostButton(): HTMLButtonElement | null {
  const buttons = Array.from(document.querySelectorAll("main button, button"));

  for (const candidate of buttons) {
    if (!(candidate instanceof HTMLButtonElement)) {
      continue;
    }

    const text = cleanText(candidate.textContent).toLowerCase();
    if (!isElementVisible(candidate)) {
      continue;
    }

    if (text === "post" || text.endsWith(" post")) {
      return candidate;
    }
  }

  return null;
}

function isElementVisible(element: HTMLElement): boolean {
  const rect = element.getBoundingClientRect();
  const style = window.getComputedStyle(element);

  return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
}

function isButtonDisabled(button: HTMLButtonElement): boolean {
  const ariaDisabled = button.getAttribute("aria-disabled");
  return button.disabled || ariaDisabled === "true";
}

async function waitForElement(selectors: string[], timeoutMs: number): Promise<HTMLInputElement | HTMLTextAreaElement> {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
        return element;
      }
    }

    await delay(250);
  }

  throw new Error("LeetCode post title input not found");
}

function isLeetCodePostPreparationPayload(value: unknown): value is LeetCodePostPreparationPayload {
  if (typeof value !== "object" || value === null) {
    return false;
  }

  const payload = value as Partial<LeetCodePostPreparationPayload>;
  return typeof payload.postUrl === "string" && payload.postUrl.trim().length > 0;
}

async function prepareLeetCodePostPage(postUrl: string): Promise<boolean> {
  if (isLeetCodePostPage()) {
    return true;
  }

  const directLink = document.querySelector('a[href*="/post-solution/"]') as HTMLAnchorElement | null;
  if (directLink?.href) {
    window.location.href = directLink.href;
    return await waitForPostPageNavigation(12000);
  }

  const shareButton = findShareSolutionButton();
  if (shareButton) {
    shareButton.click();
    const navigatedByClick = await waitForPostPageNavigation(12000);
    if (navigatedByClick) {
      return true;
    }
  }

  try {
    const currentOrigin = window.location.origin;
    const target = new URL(postUrl, currentOrigin).toString();
    if (target.startsWith(currentOrigin)) {
      window.location.href = target;
      return await waitForPostPageNavigation(12000);
    }
  } catch {
    // Ignore malformed target URL.
  }

  return false;
}

function findShareSolutionButton(): HTMLButtonElement | null {
  const buttons = Array.from(document.querySelectorAll("button"));

  for (const candidate of buttons) {
    if (!(candidate instanceof HTMLButtonElement)) {
      continue;
    }

    const text = cleanText(candidate.textContent).toLowerCase();
    if (text.includes("share my solution") && isElementVisible(candidate)) {
      return candidate;
    }
  }

  return null;
}

async function waitForPostPageNavigation(timeoutMs: number): Promise<boolean> {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    if (isLeetCodePostPage()) {
      return true;
    }

    await delay(250);
  }

  return false;
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => {
    window.setTimeout(resolve, ms);
  });
}

async function isExtensionEnabled(): Promise<boolean> {
  const result = await chrome.storage.local.get("analysisState");
  const state = result.analysisState as { enabled?: boolean } | undefined;

  if (!state || state.enabled === undefined) {
    return true;
  }

  return Boolean(state.enabled);
}

export {};
