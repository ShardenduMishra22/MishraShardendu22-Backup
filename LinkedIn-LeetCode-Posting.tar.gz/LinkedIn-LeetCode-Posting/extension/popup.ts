type ExtensionStatus = "idle" | "extracting" | "sending" | "posting" | "done";
type LinkedInPostStatus = "idle" | "posting" | "posted" | "failed";
type LeetCodePostStatus = "idle" | "posting" | "posted" | "failed";

interface AnalyzePayload {
  title: string;
  difficulty: string;
  code: string;
  url: string;
  submissionId?: string;
  language?: string;
}

interface StructuredExplanation {
  problemSummary: string;
  coreIdea: string;
  approach: string[];
  timeComplexity: string;
  spaceComplexity: string;
  edgeCases: string[];
}

interface AnalysisState {
  enabled: boolean;
  status: ExtensionStatus;
  lastPayload: AnalyzePayload | null;
  explanation: StructuredExplanation | null;
  linkedinPost: string | null;
  linkedInPostStatus: LinkedInPostStatus;
  leetCodePostStatus: LeetCodePostStatus;
  leetCodePostUrl: string | null;
  error: string | null;
}

const STORAGE_KEY = "analysisState";

const enabledToggle = getElement<HTMLInputElement>("enabledToggle");
const generateButton = getElement<HTMLButtonElement>("generateButton");
const postLeetCodeButton = getElement<HTMLButtonElement>("postLeetCodeButton");
const postButton = getElement<HTMLButtonElement>("postButton");
const statusValue = getElement<HTMLElement>("statusValue");
const errorText = getElement<HTMLElement>("errorText");
const successText = getElement<HTMLElement>("successText");
const resultSection = getElement<HTMLElement>("resultSection");
const resultText = getElement<HTMLElement>("resultText");
const linkedinSection = getElement<HTMLElement>("linkedinSection");
const linkedinText = getElement<HTMLElement>("linkedinText");
const leetcodeSection = getElement<HTMLElement>("leetcodeSection");
const leetcodeText = getElement<HTMLElement>("leetcodeText");

void bootstrap();

async function bootstrap(): Promise<void> {
  bindEvents();
  await refreshState();

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes[STORAGE_KEY]?.newValue) {
      return;
    }

    renderState(changes[STORAGE_KEY].newValue as AnalysisState);
  });
}

function bindEvents(): void {
  enabledToggle.addEventListener("change", async () => {
    const response = (await chrome.runtime.sendMessage({
      type: "SET_ENABLED",
      enabled: enabledToggle.checked
    })) as { ok?: boolean; state?: AnalysisState; error?: string };

    if (response?.state) {
      renderState(response.state);
    }

    if (!response?.ok && response?.error) {
      setError(response.error);
    }
  });

  generateButton.addEventListener("click", async () => {
    setError("");
    setSuccess("");

    const response = (await chrome.runtime.sendMessage({
      type: "GENERATE_EXPLANATION"
    })) as { ok?: boolean; state?: AnalysisState; error?: string };

    if (response?.state) {
      renderState(response.state);
    }

    if (!response?.ok && response?.error) {
      setError(response.error);
    }
  });

  postLeetCodeButton.addEventListener("click", async () => {
    setError("");
    setSuccess("");

    const response = (await chrome.runtime.sendMessage({
      type: "GENERATE_AND_POST_LEETCODE"
    })) as { ok?: boolean; state?: AnalysisState; error?: string };

    if (response?.state) {
      renderState(response.state);
    }

    if (!response?.ok && response?.error) {
      setError(response.error);
    }
  });

  postButton.addEventListener("click", async () => {
    setError("");
    setSuccess("");

    const response = (await chrome.runtime.sendMessage({
      type: "GENERATE_AND_POST_LINKEDIN"
    })) as { ok?: boolean; state?: AnalysisState; error?: string };

    if (response?.state) {
      renderState(response.state);
    }

    if (!response?.ok && response?.error) {
      setError(response.error);
    }
  });
}

async function refreshState(): Promise<void> {
  const response = (await chrome.runtime.sendMessage({
    type: "GET_STATE"
  })) as { ok?: boolean; state?: AnalysisState; error?: string };

  if (response?.state) {
    renderState(response.state);
    return;
  }

  if (response?.error) {
    setError(response.error);
  }
}

function renderState(state: AnalysisState): void {
  const processing = state.status === "extracting" || state.status === "sending" || state.status === "posting";

  enabledToggle.checked = state.enabled;
  statusValue.textContent = state.status;
  generateButton.disabled = !state.enabled || processing;
  postLeetCodeButton.disabled = !state.enabled || processing;
  postButton.disabled = !state.enabled || processing;

  if (state.error) {
    setError(state.error);
  } else {
    setError("");
  }

  if (state.leetCodePostStatus === "posted") {
    setSuccess("LeetCode post published successfully.");
  } else if (state.leetCodePostStatus === "posting") {
    setSuccess("Posting to LeetCode...");
  } else if (state.linkedInPostStatus === "posted") {
    setSuccess("LinkedIn post published successfully.");
  } else if (state.linkedInPostStatus === "posting") {
    setSuccess("Posting to LinkedIn...");
  } else {
    setSuccess("");
  }

  if (state.explanation) {
    resultSection.classList.remove("hidden");
    resultText.textContent = formatExplanation(state.explanation, state.lastPayload?.code, state.lastPayload?.language);
  } else {
    resultSection.classList.add("hidden");
    resultText.textContent = "";
  }

  if (state.linkedinPost) {
    linkedinSection.classList.remove("hidden");
    linkedinText.textContent = state.linkedinPost;
  } else {
    linkedinSection.classList.add("hidden");
    linkedinText.textContent = "";
  }

  if (state.leetCodePostUrl) {
    leetcodeSection.classList.remove("hidden");
    leetcodeText.textContent = `Published to:\n${state.leetCodePostUrl}`;
  } else {
    leetcodeSection.classList.add("hidden");
    leetcodeText.textContent = "";
  }
}

function formatExplanation(
  explanation: StructuredExplanation,
  code: string | undefined,
  language: string | undefined
): string {
  const approach = explanation.approach.map((step, index) => `${index + 1}. ${step}`).join("\n");
  const edgeCases = explanation.edgeCases.map((item) => `- ${item}`).join("\n");

  const sections = [
    "1. Problem Summary",
    explanation.problemSummary,
    "",
    "2. Core Idea",
    explanation.coreIdea,
    "",
    "3. Approach",
    approach,
    "",
    "4. Time Complexity",
    explanation.timeComplexity,
    "",
    "5. Space Complexity",
    explanation.spaceComplexity,
    "",
    "6. Edge Cases",
    edgeCases
  ];

  if (code?.trim()) {
    const normalizedLanguage = normalizeCodeFenceLanguage(language);
    sections.push(
      "",
      "7. Code",
      `\`\`\`${normalizedLanguage}`,
      code.trim(),
      "\`\`\`"
    );
  }

  return sections.join("\n");
}

function normalizeCodeFenceLanguage(language: string | undefined): string {
  if (!language) {
    return "";
  }

  const lowered = language.toLowerCase().trim();

  if (lowered.includes("c++") || lowered === "cpp") {
    return "cpp";
  }

  if (lowered.includes("python")) {
    return "python";
  }

  if (lowered.includes("javascript")) {
    return "javascript";
  }

  if (lowered.includes("typescript")) {
    return "typescript";
  }

  if (lowered.includes("java")) {
    return "java";
  }

  return lowered.replace(/\s+/g, "");
}

function setError(message: string): void {
  if (!message.trim()) {
    errorText.textContent = "";
    errorText.classList.add("hidden");
    return;
  }

  errorText.textContent = message;
  errorText.classList.remove("hidden");
}

function setSuccess(message: string): void {
  if (!message.trim()) {
    successText.textContent = "";
    successText.classList.add("hidden");
    return;
  }

  successText.textContent = message;
  successText.classList.remove("hidden");
}

function getElement<T extends HTMLElement>(id: string): T {
  const element = document.getElementById(id);

  if (!element) {
    throw new Error(`Missing element with id: ${id}`);
  }

  return element as T;
}

export {};
