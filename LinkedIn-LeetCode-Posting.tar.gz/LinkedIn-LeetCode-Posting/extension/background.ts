type ExtensionStatus = "idle" | "extracting" | "sending" | "posting" | "done";
type LinkedInPostStatus = "idle" | "posting" | "posted" | "failed";
type LeetCodePostStatus = "idle" | "posting" | "posted" | "failed";

interface AnalyzePayload {
  title: string;
  difficulty: string;
  code: string;
  url: string;
  submissionId?: string;
  language?: string;
}

interface StructuredExplanation {
  problemSummary: string;
  coreIdea: string;
  approach: string[];
  timeComplexity: string;
  spaceComplexity: string;
  edgeCases: string[];
}

interface AnalyzeAndPostResponse {
  explanation: StructuredExplanation;
  linkedin_post: string;
  status: string;
}

interface LeetCodePostDraft {
  title: string;
  content: string;
  autoPublish: boolean;
}

interface AnalysisState {
  enabled: boolean;
  status: ExtensionStatus;
  lastPayload: AnalyzePayload | null;
  explanation: StructuredExplanation | null;
  linkedinPost: string | null;
  linkedInPostStatus: LinkedInPostStatus;
  leetCodePostStatus: LeetCodePostStatus;
  leetCodePostUrl: string | null;
  error: string | null;
  lastUpdated: number;
}

interface MessageResponse {
  ok: boolean;
  state?: AnalysisState;
  error?: string;
}

const STORAGE_KEY = "analysisState";

const DEFAULT_STATE: AnalysisState = {
  enabled: true,
  status: "idle",
  lastPayload: null,
  explanation: null,
  linkedinPost: null,
  linkedInPostStatus: "idle",
  leetCodePostStatus: "idle",
  leetCodePostUrl: null,
  error: null,
  lastUpdated: Date.now()
};

chrome.runtime.onInstalled.addListener(() => {
  void initializeState();
});

chrome.runtime.onStartup.addListener(() => {
  void initializeState();
});

chrome.runtime.onMessage.addListener((message: unknown, sender, sendResponse) => {
  void (async () => {
    try {
      const response = await handleMessage(message, sender);
      sendResponse(response);
    } catch (error) {
      const failure = await patchState({
        status: "idle",
        error: toErrorMessage(error)
      });

      sendResponse({
        ok: false,
        error: toErrorMessage(error),
        state: failure
      } satisfies MessageResponse);
    }
  })();

  return true;
});

async function handleMessage(message: unknown, sender: chrome.runtime.MessageSender): Promise<MessageResponse> {
  const typed = message as { type?: string; enabled?: boolean; payload?: unknown };

  switch (typed.type) {
    case "GET_STATE": {
      return {
        ok: true,
        state: await getState()
      };
    }

    case "SET_ENABLED": {
      const state = await patchState({
        enabled: Boolean(typed.enabled),
        error: null
      });

      return {
        ok: true,
        state
      };
    }

    case "SUBMISSION_ACCEPTED": {
      if (!isAnalyzePayload(typed.payload)) {
        return {
          ok: false,
          error: "Invalid extracted payload"
        };
      }

      const currentState = await getState();
      if (!currentState.enabled) {
        return {
          ok: false,
          error: "Extension is disabled"
        };
      }

      const state = await patchState({
        status: "idle",
        lastPayload: typed.payload,
        error: null,
        explanation: null,
        linkedinPost: null,
        linkedInPostStatus: "idle",
        leetCodePostStatus: "idle",
        leetCodePostUrl: null
      });

      return {
        ok: true,
        state
      };
    }

    case "GENERATE_EXPLANATION": {
      const state = await generateExplanation(sender);
      return {
        ok: true,
        state
      };
    }

    case "GENERATE_AND_POST_LINKEDIN": {
      const state = await generateAndPostToLinkedIn(sender);
      return {
        ok: true,
        state
      };
    }

    case "GENERATE_AND_POST_LEETCODE": {
      const state = await generateAndPostToLeetCode(sender);
      return {
        ok: true,
        state
      };
    }

    default:
      return {
        ok: false,
        error: "Unsupported message type"
      };
  }
}

async function generateExplanation(sender: chrome.runtime.MessageSender): Promise<AnalysisState> {
  const state = await getState();

  if (!state.enabled) {
    throw new Error("Enable the extension before generating explanations");
  }

  await patchState({
    status: "extracting",
    error: null,
    linkedInPostStatus: "idle",
    leetCodePostStatus: "idle",
    leetCodePostUrl: null
  });

  const targetTab = await resolveTargetTab(sender);
  const extracted = targetTab?.id !== undefined ? await extractFromTab(targetTab.id) : null;
  const payload = extracted ?? state.lastPayload;

  if (!payload) {
    throw new Error("Could not extract submission data. Refresh the LeetCode tab, keep accepted result and code visible, then retry.");
  }

  await patchState({
    status: "sending",
    error: null,
    lastPayload: payload
  });

  const explanation = await callAnalyzeBackend(payload);

  return patchState({
    status: "done",
    explanation,
    linkedinPost: null,
    linkedInPostStatus: "idle",
    leetCodePostStatus: "idle",
    leetCodePostUrl: null,
    error: null,
    lastPayload: payload
  });
}

async function generateAndPostToLinkedIn(sender: chrome.runtime.MessageSender): Promise<AnalysisState> {
  const state = await getState();

  if (!state.enabled) {
    throw new Error("Enable the extension before posting to LinkedIn");
  }

  await patchState({
    status: "extracting",
    error: null,
    linkedInPostStatus: "idle"
  });

  const targetTab = await resolveTargetTab(sender);
  const extracted = targetTab?.id !== undefined ? await extractFromTab(targetTab.id) : null;
  const payload = extracted ?? state.lastPayload;

  if (!payload) {
    throw new Error("Could not extract submission data. Refresh the LeetCode tab, keep accepted result and code visible, then retry.");
  }

  await patchState({
    status: "posting",
    linkedInPostStatus: "posting",
    error: null,
    lastPayload: payload
  });

  try {
    const result = await callAnalyzeAndPostBackend(payload);

    return patchState({
      status: "done",
      explanation: result.explanation,
      linkedinPost: result.linkedin_post,
      linkedInPostStatus: "posted",
      error: null,
      lastPayload: payload
    });
  } catch (error) {
    await patchState({
      status: "idle",
      linkedInPostStatus: "failed",
      error: toErrorMessage(error),
      lastPayload: payload
    });

    throw error;
  }
}

async function generateAndPostToLeetCode(sender: chrome.runtime.MessageSender): Promise<AnalysisState> {
  const state = await getState();

  if (!state.enabled) {
    throw new Error("Enable the extension before posting to LeetCode");
  }

  await patchState({
    status: "extracting",
    error: null,
    leetCodePostStatus: "idle",
    leetCodePostUrl: null,
    linkedInPostStatus: "idle"
  });

  const targetTab = await resolveTargetTab(sender);
  const activeTabUrl = targetTab?.url;
  const extracted = targetTab?.id !== undefined ? await extractFromTab(targetTab.id) : null;
  const payload = extracted ?? state.lastPayload;

  if (!payload) {
    throw new Error("Could not extract submission data. Refresh the LeetCode tab, keep accepted result and code visible, then retry.");
  }

  const submissionId = resolveSubmissionId(payload, activeTabUrl);
  if (!submissionId) {
    throw new Error("Submission ID not found. Open the accepted submission details page, then retry.");
  }

  await patchState({
    status: "sending",
    error: null,
    lastPayload: payload
  });

  const explanation = await callAnalyzeBackend(payload);
  const postUrl = buildLeetCodePostUrl(payload.url, submissionId);
  const draft = buildLeetCodePostDraft(payload, explanation);

  await patchState({
    status: "posting",
    leetCodePostStatus: "posting",
    leetCodePostUrl: postUrl,
    explanation,
    lastPayload: payload,
    error: null
  });

  try {
    await openLeetCodePostAndPublish(postUrl, draft);

    return patchState({
      status: "done",
      explanation,
      leetCodePostStatus: "posted",
      leetCodePostUrl: postUrl,
      error: null,
      lastPayload: payload
    });
  } catch (error) {
    await patchState({
      status: "idle",
      leetCodePostStatus: "failed",
      leetCodePostUrl: postUrl,
      error: toErrorMessage(error),
      lastPayload: payload
    });

    throw error;
  }
}

async function callAnalyzeBackend(payload: AnalyzePayload): Promise<StructuredExplanation> {
  const response = await fetch("http://localhost:3000/analyze", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const data = (await safeJson(response)) as { error?: string } | null;
    const message = data?.error ?? `Backend request failed with status ${response.status}`;
    throw new Error(message);
  }

  const data = (await safeJson(response)) as { explanation?: unknown } | null;

  if (!data?.explanation || !isStructuredExplanation(data.explanation)) {
    throw new Error("Backend returned an invalid explanation payload");
  }

  return data.explanation;
}

async function callAnalyzeAndPostBackend(payload: AnalyzePayload): Promise<AnalyzeAndPostResponse> {
  const response = await fetch("http://localhost:3000/analyze-and-post", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const data = (await safeJson(response)) as { error?: string } | null;
    const message = data?.error ?? `Analyze and post request failed with status ${response.status}`;
    throw new Error(message);
  }

  const data = (await safeJson(response)) as Partial<AnalyzeAndPostResponse> | null;

  if (!isAnalyzeAndPostResponse(data)) {
    throw new Error("Backend returned an invalid analyze-and-post response");
  }

  if (data.status !== "posted") {
    throw new Error("LinkedIn post was not published");
  }

  return data;
}

async function extractFromTab(tabId: number): Promise<AnalyzePayload | null> {
  let extractionError = "";

  try {
    const response = (await chrome.tabs.sendMessage(tabId, {
      type: "EXTRACT_NOW"
    })) as { ok?: boolean; payload?: unknown; error?: string } | undefined;

    if (response?.ok && isAnalyzePayload(response.payload)) {
      return response.payload;
    }

    if (isNonEmptyString(response?.error)) {
      extractionError = response.error;
    }
  } catch {
    // Fall through to executeScript fallback when the content script isn't injected.
  }

  const fallbackPayload = await extractFromTabViaScripting(tabId);
  if (fallbackPayload) {
    return fallbackPayload;
  }

  if (extractionError) {
    throw new Error(extractionError);
  }

  return null;
}

async function extractFromTabViaScripting(tabId: number): Promise<AnalyzePayload | null> {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        if (!/^\/problems\//.test(window.location.pathname)) {
          return null;
        }

        const cleanText = (value: string | null | undefined): string => (value ?? "").replace(/\s+/g, " ").trim();
        const normalizeCode = (value: string): string =>
          value.replace(/\u00a0/g, " ").replace(/\r\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();

        const titleFromSlug = (): string | null => {
          const match = window.location.pathname.match(/^\/problems\/([^\/]+)/i);
          if (!match?.[1]) {
            return null;
          }

          return match[1]
            .split("-")
            .filter(Boolean)
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ");
        };

        const extractTitle = (): string => {
          const selectors = [
            'div[data-cy="question-title"]',
            'a[href*="/problems/"][href*="/description"]',
            'a[href^="/problems/"]',
            "h1"
          ];

          for (const selector of selectors) {
            const node = document.querySelector(selector);
            const text = cleanText(node?.textContent);
            if (text) {
              return text.replace(/^\d+\.\s*/, "");
            }
          }

          const fromTitle = document.title.replace(/\s*-\s*LeetCode\s*$/, "").trim();
          if (fromTitle && !/^All Submissions$/i.test(fromTitle)) {
            return fromTitle;
          }

          return titleFromSlug() ?? "Unknown Problem";
        };

        const extractDifficulty = (): string => {
          const selectors = [
            '[diff="easy"]',
            '[diff="medium"]',
            '[diff="hard"]',
            '[class*="difficulty"]',
            ".text-difficulty-easy",
            ".text-difficulty-medium",
            ".text-difficulty-hard"
          ];

          for (const selector of selectors) {
            const nodes = document.querySelectorAll(selector);
            for (const node of nodes) {
              const lowered = cleanText(node.textContent).toLowerCase();
              if (lowered.includes("easy")) {
                return "Easy";
              }
              if (lowered.includes("medium")) {
                return "Medium";
              }
              if (lowered.includes("hard")) {
                return "Hard";
              }
            }
          }

          const textMatch = document.body.innerText.match(/\b(Easy|Medium|Hard)\b/);
          return textMatch?.[1] ?? "Unknown";
        };

        const extractSubmissionId = (): string | undefined => {
          const fromPath = window.location.pathname.match(/\/submissions\/(\d+)/i)?.[1];
          if (fromPath) {
            return fromPath;
          }

          const fromQuery = new URLSearchParams(window.location.search).get("submissionId");
          if (fromQuery?.trim()) {
            return fromQuery.trim();
          }

          return undefined;
        };

        const extractLanguage = (): string | undefined => {
          const selectors = [
            '[data-cy="lang-select"]',
            '[id*="lang"]',
            'button[class*="language"]',
            '[class*="language-select"]'
          ];

          for (const selector of selectors) {
            const nodes = document.querySelectorAll(selector);
            for (const node of nodes) {
              const text = cleanText(node.textContent);
              if (text && text.length <= 24 && /[A-Za-z+#]/.test(text)) {
                return text;
              }
            }
          }

          return undefined;
        };

        const score = (code: string): number => {
          const lineCount = code.split("\n").length;
          const syntaxBonus = /[{}();=<>,\[\]#]/.test(code) ? 500 : 0;
          return Math.min(code.length, 2000) + lineCount * 20 + syntaxBonus;
        };

        const candidates: string[] = [];
        const selectors = [
          ".monaco-editor textarea",
          ".monaco-editor .inputarea",
          "textarea.inputarea",
          "textarea",
          "pre code",
          ".view-lines .view-line",
          ".CodeMirror-code",
          "[data-track-load='code_editor']",
          ".monaco-editor",
          ".view-lines"
        ];

        for (const selector of selectors) {
          const nodes = document.querySelectorAll(selector);
          for (const node of nodes) {
            if (node instanceof HTMLTextAreaElement) {
              if (node.value.trim()) {
                candidates.push(node.value);
              }
            } else {
              const text = normalizeCode(node.textContent ?? "");
              if (text.length >= 20) {
                candidates.push(text);
              }
            }
          }
        }

        const lines = document.querySelectorAll(".monaco-editor .view-lines .view-line, .view-lines .view-line");
        if (lines.length > 0) {
          const merged = Array.from(lines)
            .map((line) => (line.textContent ?? "").replace(/\u00a0/g, " ").replace(/\s+$/, ""))
            .join("\n");
          if (normalizeCode(merged).length >= 20) {
            candidates.push(merged);
          }
        }

        const normalizedCandidates = candidates
          .map((candidate) => normalizeCode(candidate))
          .filter((candidate) => candidate.length >= 20);

        if (normalizedCandidates.length === 0) {
          return null;
        }

        normalizedCandidates.sort((a, b) => score(b) - score(a));

        const payload = {
          title: extractTitle(),
          difficulty: extractDifficulty(),
          code: normalizedCandidates[0],
          url: window.location.href,
          submissionId: extractSubmissionId(),
          language: extractLanguage()
        };

        if (!payload.title.trim() || !payload.code.trim()) {
          return null;
        }

        return payload;
      }
    });

    const result = results[0]?.result;

    if (isAnalyzePayload(result)) {
      return result;
    }

    return null;
  } catch {
    return null;
  }
}

function resolveSubmissionId(payload: AnalyzePayload, activeTabUrl?: string): string | null {
  if (isNonEmptyString(payload.submissionId)) {
    return payload.submissionId;
  }

  const fromPayloadUrl = extractSubmissionIdFromAnyUrl(payload.url);
  if (fromPayloadUrl) {
    return fromPayloadUrl;
  }

  if (isNonEmptyString(activeTabUrl)) {
    const fromActiveTab = extractSubmissionIdFromAnyUrl(activeTabUrl);
    if (fromActiveTab) {
      return fromActiveTab;
    }
  }

  return null;
}

function extractSubmissionIdFromAnyUrl(url: string): string | null {
  const fromPath = url.match(/\/submissions\/(\d+)/i)?.[1];
  if (fromPath) {
    return fromPath;
  }

  try {
    const parsed = new URL(url);
    const fromQuery = parsed.searchParams.get("submissionId");
    if (fromQuery?.trim()) {
      return fromQuery.trim();
    }
  } catch {
    // Ignore malformed URL.
  }

  return null;
}

function buildLeetCodePostUrl(problemUrl: string, submissionId: string): string {
  let slug = "";

  try {
    const parsed = new URL(problemUrl);
    slug = parsed.pathname.match(/^\/problems\/([^/]+)/i)?.[1] ?? "";
  } catch {
    slug = problemUrl.match(/\/problems\/([^/]+)/i)?.[1] ?? "";
  }

  if (!slug) {
    throw new Error("Unable to determine LeetCode problem slug from current URL");
  }

  return `https://leetcode.com/problems/${slug}/post-solution/?submissionId=${encodeURIComponent(submissionId)}`;
}

function buildLeetCodePostDraft(payload: AnalyzePayload, explanation: StructuredExplanation): LeetCodePostDraft {
  const title = `${payload.title} | ${payload.difficulty} | Solution`;
  const approach = explanation.approach.map((step, index) => `${index + 1}. ${step}`).join("\n");
  const edgeCases = explanation.edgeCases.length > 0
    ? explanation.edgeCases.map((item) => `- ${item}`).join("\n")
    : "- None specific";

  const language = normalizeCodeFenceLanguage(payload.language);

  const content = [
    "## Intuition",
    explanation.problemSummary,
    "",
    "## Approach",
    explanation.coreIdea,
    "",
    approach,
    "",
    "## Complexity",
    `- Time complexity: ${explanation.timeComplexity}`,
    `- Space complexity: ${explanation.spaceComplexity}`,
    "",
    "## Edge Cases",
    edgeCases,
    "",
    "## Code",
    `\`\`\`${language}`,
    payload.code.trim(),
    "\`\`\`"
  ].join("\n");

  return {
    title: title.slice(0, 120),
    content,
    autoPublish: true
  };
}

function normalizeCodeFenceLanguage(language: string | undefined): string {
  if (!language) {
    return "";
  }

  const lowered = language.toLowerCase().trim();

  if (lowered.includes("c++") || lowered === "cpp") {
    return "cpp";
  }

  if (lowered.includes("python")) {
    return "python";
  }

  if (lowered.includes("java")) {
    return "java";
  }

  if (lowered.includes("javascript")) {
    return "javascript";
  }

  if (lowered.includes("typescript")) {
    return "typescript";
  }

  return lowered.replace(/\s+/g, "");
}

async function openLeetCodePostAndPublish(postUrl: string, draft: LeetCodePostDraft): Promise<void> {
  const tab = await chrome.tabs.create({
    url: postUrl,
    active: true
  });

  if (tab.id === undefined) {
    throw new Error("Unable to open LeetCode post page");
  }

  await waitForTabComplete(tab.id, 25000);
  await prepareLeetCodePostPage(tab.id, postUrl);
  await sendLeetCodeDraftWithRetry(tab.id, draft, 30, 500);
}

async function prepareLeetCodePostPage(tabId: number, postUrl: string): Promise<void> {
  let lastError = "";

  for (let attempt = 0; attempt < 35; attempt += 1) {
    try {
      const response = (await chrome.tabs.sendMessage(tabId, {
        type: "PREPARE_LEETCODE_POST_PAGE",
        postUrl
      })) as { ok?: boolean; error?: string } | undefined;

      if (response?.ok) {
        await waitForTabComplete(tabId, 25000);
        return;
      }

      if (isNonEmptyString(response?.error)) {
        lastError = response.error;
      }
    } catch (error) {
      lastError = toErrorMessage(error);
    }

    await delay(350);
  }

  throw new Error(lastError || "Unable to navigate to LeetCode post page automatically");
}

async function waitForTabComplete(tabId: number, timeoutMs: number): Promise<void> {
  return new Promise((resolve, reject) => {
    let settled = false;

    const cleanup = (): void => {
      if (settled) {
        return;
      }

      settled = true;
      chrome.tabs.onUpdated.removeListener(onUpdated);
      clearTimeout(timeoutHandle);
    };

    const onUpdated = (updatedTabId: number, changeInfo: { status?: string }): void => {
      if (updatedTabId === tabId && changeInfo.status === "complete") {
        cleanup();
        resolve();
      }
    };

    const timeoutHandle = setTimeout(() => {
      cleanup();
      reject(new Error("Timed out while loading LeetCode post page"));
    }, timeoutMs);

    chrome.tabs.onUpdated.addListener(onUpdated);

    void chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete") {
        cleanup();
        resolve();
      }
    }).catch(() => {
      // Ignore and rely on onUpdated listener.
    });
  });
}

async function sendLeetCodeDraftWithRetry(
  tabId: number,
  draft: LeetCodePostDraft,
  attempts: number,
  delayMs: number
): Promise<void> {
  let lastError = "";

  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      const response = (await chrome.tabs.sendMessage(tabId, {
        type: "APPLY_LEETCODE_POST_DRAFT",
        draft
      })) as { ok?: boolean; error?: string } | undefined;

      if (response?.ok) {
        return;
      }

      if (isNonEmptyString(response?.error)) {
        lastError = response.error;
      }
    } catch (error) {
      lastError = toErrorMessage(error);
    }

    await delay(delayMs);
  }

  throw new Error(lastError || "Failed to apply LeetCode post draft automatically");
}

async function resolveTargetTab(sender: chrome.runtime.MessageSender): Promise<chrome.tabs.Tab | null> {
  if (sender.tab?.id !== undefined) {
    return sender.tab;
  }

  const tabs = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });

  return tabs[0] ?? null;
}

async function initializeState(): Promise<void> {
  const state = await getState();
  await chrome.storage.local.set({ [STORAGE_KEY]: state });
}

async function getState(): Promise<AnalysisState> {
  const storage = await chrome.storage.local.get(STORAGE_KEY);
  const state = storage[STORAGE_KEY] as Partial<AnalysisState> | undefined;

  if (!state) {
    return { ...DEFAULT_STATE };
  }

  return {
    ...DEFAULT_STATE,
    ...state,
    enabled: Boolean(state.enabled),
    status: isValidStatus(state.status) ? state.status : "idle",
    linkedInPostStatus: isValidLinkedInPostStatus(state.linkedInPostStatus)
      ? state.linkedInPostStatus
      : "idle",
    leetCodePostStatus: isValidLeetCodePostStatus(state.leetCodePostStatus)
      ? state.leetCodePostStatus
      : "idle"
  };
}

async function patchState(patch: Partial<AnalysisState>): Promise<AnalysisState> {
  const current = await getState();

  const next: AnalysisState = {
    ...current,
    ...patch,
    lastUpdated: Date.now()
  };

  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  return next;
}

function isAnalyzePayload(value: unknown): value is AnalyzePayload {
  if (typeof value !== "object" || value === null) {
    return false;
  }

  const payload = value as Partial<AnalyzePayload>;

  return (
    isNonEmptyString(payload.title) &&
    isNonEmptyString(payload.difficulty) &&
    isNonEmptyString(payload.code) &&
    isNonEmptyString(payload.url)
  );
}

function isAnalyzeAndPostResponse(value: unknown): value is AnalyzeAndPostResponse {
  if (typeof value !== "object" || value === null) {
    return false;
  }

  const response = value as Partial<AnalyzeAndPostResponse>;

  return (
    response.explanation !== undefined &&
    isStructuredExplanation(response.explanation) &&
    isNonEmptyString(response.linkedin_post) &&
    isNonEmptyString(response.status)
  );
}

function isStructuredExplanation(value: unknown): value is StructuredExplanation {
  if (typeof value !== "object" || value === null) {
    return false;
  }

  const explanation = value as Partial<StructuredExplanation>;

  return (
    isNonEmptyString(explanation.problemSummary) &&
    isNonEmptyString(explanation.coreIdea) &&
    Array.isArray(explanation.approach) &&
    explanation.approach.every((entry) => isNonEmptyString(entry)) &&
    isNonEmptyString(explanation.timeComplexity) &&
    isNonEmptyString(explanation.spaceComplexity) &&
    Array.isArray(explanation.edgeCases) &&
    explanation.edgeCases.every((entry) => isNonEmptyString(entry))
  );
}

function isValidStatus(value: unknown): value is ExtensionStatus {
  return value === "idle" || value === "extracting" || value === "sending" || value === "posting" || value === "done";
}

function isValidLinkedInPostStatus(value: unknown): value is LinkedInPostStatus {
  return value === "idle" || value === "posting" || value === "posted" || value === "failed";
}

function isValidLeetCodePostStatus(value: unknown): value is LeetCodePostStatus {
  return value === "idle" || value === "posting" || value === "posted" || value === "failed";
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function toErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Unknown error";
}

async function safeJson(response: Response): Promise<unknown> {
  try {
    return await response.json();
  } catch {
    return null;
  }
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

export {};
