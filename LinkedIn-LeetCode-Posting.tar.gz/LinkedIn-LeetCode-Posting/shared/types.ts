export type Difficulty = "Easy" | "Medium" | "Hard" | "Unknown";

export interface AnalyzeRequestPayload {
  title: string;
  difficulty: Difficulty | string;
  code: string;
  url: string;
}

export interface StructuredExplanation {
  problemSummary: string;
  coreIdea: string;
  approach: string[];
  timeComplexity: string;
  spaceComplexity: string;
  edgeCases: string[];
}

export interface AnalyzeResponsePayload {
  explanation: StructuredExplanation;
  model: string;
}

export interface AnalyzeAndPostResponsePayload {
  explanation: StructuredExplanation;
  linkedin_post: string;
  linkedin_post_id: string | null;
  status: "posted";
}

export interface PostLinkedInResponsePayload {
  status: "posted";
  linkedin_post_id: string | null;
}
