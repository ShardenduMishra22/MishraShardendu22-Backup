# LeetCode Local Explainer

Local-first system:

- Chrome Extension (Manifest V3) runs on LeetCode problem pages.
- Local backend runs on `http://localhost:3000`.
- Backend calls OpenRouter and LinkedIn API.
- No external database.
- LinkedIn access token stays only in backend environment variables.

## Architecture

```text
Chrome Extension -> Local Backend (localhost:3000) -> OpenRouter API -> LinkedIn API -> Extension UI
```

## Project Structure

```text
/extension
  manifest.json
  background.ts
  contentScript.ts
  popup.html
  popup.ts
  package.json
  tsconfig.json

/backend
  .env.example
  package.json
  tsconfig.json
  src/
    server.ts
    routes/analyze.ts
    routes/linkedin.ts
    services/llm.ts
    services/linkedin.ts

/shared
  types.ts
```

## 1. Backend Setup

```bash
cd backend
npm install
cp .env.example .env
```

Set your OpenRouter key in `.env`:

```env
OPENROUTER_API_KEY=your_real_key
OPENROUTER_TIMEOUT_MS=30000
LINKEDIN_ACCESS_TOKEN=your_linkedin_access_token
LINKEDIN_USER_ID=your_linkedin_user_id
LINKEDIN_TIMEOUT_MS=20000
PORT=3000
```

Run backend:

```bash
npm run dev
```

Health check:

```bash
curl http://localhost:3000/health
```

## 2. Extension Setup

Build extension TypeScript:

```bash
cd extension
npm install
npm run build
```

Load in Chrome:

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select the `extension` folder.

## 3. Usage Flow

1. Open a LeetCode problem page.
2. Submit your solution.
3. When result is **Accepted**, the extension captures metadata + code.
4. Open extension popup.
5. Click **Generate Explanation** for explanation only, or click **Generate + Post to LinkedIn**.
6. Popup shows structured sections:
   - Problem Summary
   - Core Idea
   - Approach
   - Time Complexity
   - Space Complexity
   - Edge Cases
7. When posting succeeds, popup shows the generated LinkedIn post and success state.

## API Endpoints

- `GET /health`
- `POST /analyze`
- `POST /analyze-and-post`
- `POST /post-linkedin`

`POST /analyze` request body:

```json
{
  "title": "Two Sum",
  "difficulty": "Easy",
  "code": "...",
  "url": "https://leetcode.com/problems/two-sum/"
}
```

`POST /analyze-and-post` response body:

```json
{
  "explanation": {
    "problemSummary": "...",
    "coreIdea": "...",
    "approach": ["..."],
    "timeComplexity": "...",
    "spaceComplexity": "...",
    "edgeCases": ["..."]
  },
  "linkedin_post": "...",
  "linkedin_post_id": "urn:li:share:1234567890",
  "status": "posted"
}
```

## Security Notes

- OpenRouter API key is only in backend `.env`.
- LinkedIn access token and LinkedIn user id are only in backend `.env`.
- Extension never stores or sends API keys or LinkedIn tokens.
- Backend CORS allows Chrome extension origin and localhost only.
