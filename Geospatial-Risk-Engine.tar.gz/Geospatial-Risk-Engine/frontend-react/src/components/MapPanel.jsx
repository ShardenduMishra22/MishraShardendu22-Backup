import { useEffect } from "react";
import { MapContainer, Marker, Polygon, TileLayer, Tooltip, useMap, useMapEvents } from "react-leaflet";
import L from "leaflet";

const markerIcon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

function riskColor(riskClass) {
  if (riskClass === "High") return "#c13b1f";
  if (riskClass === "Medium") return "#df8a2d";
  return "#2e7d4f";
}

function geoJsonToLeafletPolygon(geometry) {
  if (!geometry || !geometry.type || !geometry.coordinates) return null;

  if (geometry.type === "Polygon") {
    return geometry.coordinates[0].map(([lng, lat]) => [lat, lng]);
  }
  if (geometry.type === "MultiPolygon") {
    return geometry.coordinates[0][0].map(([lng, lat]) => [lat, lng]);
  }
  return null;
}

function parseCoordinate(value) {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function MapClickHandler({ onPickLocation }) {
  useMapEvents({
    click(event) {
      if (!onPickLocation) return;
      onPickLocation({
        latitude: Number(event.latlng.lat.toFixed(6)),
        longitude: Number(event.latlng.lng.toFixed(6)),
      });
    },
  });

  return null;
}

function MapViewportSync({ lat, lng }) {
  const map = useMap();

  useEffect(() => {
    map.setView([lat, lng], map.getZoom(), { animate: true, duration: 0.7 });
  }, [lat, lng, map]);

  return null;
}

export default function MapPanel({ report, input, onPickLocation }) {
  const lat = parseCoordinate(input?.latitude) ?? 12.9716;
  const lng = parseCoordinate(input?.longitude) ?? 77.5946;
  const polygon = geoJsonToLeafletPolygon(report?.geometry);
  const color = riskColor(report?.riskClass);

  return (
    <div className="card map-card">
      <div className="section-head">
        <div>
          <p className="section-kicker">Spatial</p>
          <h2>Spatial Risk View</h2>
        </div>
        <span className="coord-chip">{lat.toFixed(6)}, {lng.toFixed(6)}</span>
      </div>
      <p className="muted">Click anywhere on the map to fill latitude and longitude in the form.</p>
      <MapContainer center={[lat, lng]} zoom={13} className="map">
        <MapClickHandler onPickLocation={onPickLocation} />
        <MapViewportSync lat={lat} lng={lng} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <Marker position={[lat, lng]} icon={markerIcon}>
          <Tooltip direction="top" offset={[0, -20]} opacity={1}>
            Input location
          </Tooltip>
        </Marker>

        {polygon && (
          <Polygon positions={polygon} pathOptions={{ color, fillColor: color, fillOpacity: 0.35 }}>
            <Tooltip sticky>{report?.riskClass || "Risk"} risk overlay</Tooltip>
          </Polygon>
        )}
      </MapContainer>
    </div>
  );
}
