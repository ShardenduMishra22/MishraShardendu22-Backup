import os
from typing import Optional
from dotenv import load_dotenv

load_dotenv()

def get_env(var_name: str, required: bool = True, default: Optional[str] = None) -> str:
    """
    Retrieves an environment variable with proper error handling.
    Args:
        var_name: The name of the environment variable to retrieve.
        required: Whether the environment variable is required. If True and the variable is not set, raises ValueError.
        default: Default value to return if the variable is not set and not required.
    Returns:
        str: The value of the environment variable, or the default value if not required and not set.
    Raises:
        ValueError: If the environment variable is not set and required is True.
    """

    value = os.getenv(var_name)

    if value is None:
        if required:
            raise ValueError(f"{var_name} environment variable is not set.")
        return default or ""

    return value
