"""
Different chunking strategies for RAG pipelines.
Each function returns a text splitter or processes documents directly.
"""

from langchain_text_splitters import (
    CharacterTextSplitter,
    RecursiveCharacterTextSplitter,
    TokenTextSplitter,
)
from langchain_experimental.text_splitter import SemanticChunker
from langchain_mistralai import MistralAIEmbeddings
from langchain_core.documents import Document
from dotenv import load_dotenv
from typing import List
import re

load_dotenv()


# =============================================================================
# 1. BASIC CHARACTER SPLITTER
# =============================================================================
def get_basic_splitter(chunk_size: int = 1000, chunk_overlap: int = 200):
    """
    Simple character-based splitting.
    Splits text based on character count without considering structure.
    
    Pros: Simple, predictable chunk sizes
    Cons: May split mid-sentence or mid-word
    """
    return CharacterTextSplitter(
        separator="",  # Split anywhere
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
    )


# =============================================================================
# 2. NEWLINE-BASED SPLITTER (\n\n)
# =============================================================================
def get_paragraph_splitter(chunk_size: int = 1000, chunk_overlap: int = 200):
    """
    Splits on double newlines (paragraphs).
    Good for documents with clear paragraph structure.
    
    Pros: Respects paragraph boundaries
    Cons: Paragraphs may vary significantly in size
    """
    return CharacterTextSplitter(
        separator="\n\n",
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
    )


# =============================================================================
# 3. RECURSIVE SPLITTER (Priority: \n\n → \n → . → , → " ")
# =============================================================================
def get_recursive_splitter(chunk_size: int = 1000, chunk_overlap: int = 200):
    """
    Recursively splits with priority separators.
    Tries to split on paragraphs first, then sentences, then words.
    
    Priority order: \n\n → \n → . → , → " "
    
    Pros: Best balance of respecting structure and chunk size
    Cons: Slightly more complex
    """
    return RecursiveCharacterTextSplitter(
        separators=["\n\n", "\n", ". ", ", ", " ", ""],
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
    )


# =============================================================================
# 4. SENTENCE-BASED SPLITTER
# =============================================================================
def get_sentence_splitter(chunk_size: int = 1000, chunk_overlap: int = 200):
    """
    Splits primarily on sentence boundaries.
    Uses common sentence endings: . ! ?
    
    Pros: Keeps complete sentences together
    Cons: Sentences can vary in length
    """
    return RecursiveCharacterTextSplitter(
        separators=[". ", "! ", "? ", "\n\n", "\n", " ", ""],
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
    )


# =============================================================================
# 5. TOKEN-BASED SPLITTER
# =============================================================================
def get_token_splitter(chunk_size: int = 256, chunk_overlap: int = 50):
    """
    Splits based on token count (useful for LLM context limits).
    Uses tiktoken encoding.
    
    Pros: Precise control over token count for LLM context
    Cons: Requires tiktoken, may split mid-sentence
    """
    return TokenTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )


# =============================================================================
# 6. SEMANTIC CHUNKER (Embedding-based)
# =============================================================================
def get_semantic_chunker(
    breakpoint_threshold_type: str = "percentile",
    breakpoint_threshold_amount: float = 95.0,
):
    """
    Splits based on semantic similarity between sentences.
    Groups semantically similar content together.
    
    breakpoint_threshold_type options:
    - "percentile": Use percentile of distances as threshold
    - "standard_deviation": Use std dev from mean
    - "interquartile": Use IQR for threshold
    - "gradient": Use rate of change in distances
    
    Pros: Creates semantically coherent chunks
    Cons: Requires embedding calls, variable chunk sizes
    """
    embeddings = MistralAIEmbeddings(model="mistral-embed")
    
    return SemanticChunker(
        embeddings=embeddings,
        breakpoint_threshold_type=breakpoint_threshold_type,
        breakpoint_threshold_amount=breakpoint_threshold_amount,
    )


# =============================================================================
# 7. CUSTOM HIERARCHICAL SPLITTER
# =============================================================================
def get_hierarchical_splitter(
    max_chunk_size: int = 1000,
    min_chunk_size: int = 100,
    chunk_overlap: int = 100,
):
    """
    Custom hierarchical splitter that tries multiple strategies.
    First tries to split on headers/sections, then paragraphs, then sentences.
    
    Pros: Best for structured documents with headers
    Cons: May not work well with unstructured text
    """
    return RecursiveCharacterTextSplitter(
        separators=[
            # Headers and section breaks
            "\n# ", "\n## ", "\n### ",
            "\n---\n", "\n***\n",
            # Paragraphs
            "\n\n\n", "\n\n",
            # Lines
            "\n",
            # Sentences
            ". ", "! ", "? ",
            # Clauses
            "; ", ": ",
            # Words
            ", ", " ",
            # Characters (last resort)
            "",
        ],
        chunk_size=max_chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
    )


# =============================================================================
# 8. REGEX-BASED SPLITTER
# =============================================================================
def split_by_regex(
    documents: List[Document],
    pattern: str = r"(?<=\.)\s+",  # Split after sentence endings
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
) -> List[Document]:
    r"""
    Split documents using custom regex pattern.
    
    Common patterns:
    - r"(?<=\.)\s+" : After sentences
    - r"\n{2,}" : Multiple newlines
    - r"(?<=\n)(?=[A-Z])" : Before capital letters after newline
    
    Pros: Full control over split logic
    Cons: Requires regex knowledge
    """
    result = []
    
    for doc in documents:
        # Split by regex
        parts = re.split(pattern, doc.page_content)
        
        # Combine parts into chunks
        current_chunk = ""
        for part in parts:
            if len(current_chunk) + len(part) <= chunk_size:
                current_chunk += part
            else:
                if current_chunk:
                    result.append(Document(
                        page_content=current_chunk.strip(),
                        metadata=doc.metadata.copy()
                    ))
                current_chunk = part[-chunk_overlap:] + part if chunk_overlap else part
        
        if current_chunk.strip():
            result.append(Document(
                page_content=current_chunk.strip(),
                metadata=doc.metadata.copy()
            ))
    
    return result


# =============================================================================
# 9. AGENTIC/LLM-BASED CHUNKER (Using OpenRouter GPT-OSS-120B)
# =============================================================================
def get_openrouter_llm():
    """
    Get an OpenRouter LLM instance using GPT-OSS-120B (free).
    Uses OPENROUTER_API_KEY from environment.
    """
    import os
    from langchain_openai import ChatOpenAI
    
    return ChatOpenAI(
        model="openai/gpt-oss-120b:free",
        openai_api_key=os.getenv("OPENROUTER_API_KEY"),
        openai_api_base="https://openrouter.ai/api/v1",
    )


def split_with_llm(
    documents: List[Document],
    max_chunk_size: int = 1000,
) -> List[Document]:
    """
    Uses GPT-OSS-120B via OpenRouter to identify logical breakpoints in text.
    The LLM analyzes the content and suggests where to split.
    
    Pros: Most intelligent splitting, understands context
    Cons: Slower, requires API calls
    
    Usage:
        chunks = split_with_llm(documents)
    """
    from langchain_core.prompts import ChatPromptTemplate
    
    llm = get_openrouter_llm()
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", """You are a text chunking assistant. Your job is to identify logical breakpoints in text.
Given a piece of text, identify where it should be split to create coherent, standalone chunks.
Each chunk should be about a single topic or concept.
Return the text with <<<SPLIT>>> markers where chunks should be separated.
Keep chunks under {max_size} characters when possible.
IMPORTANT: Return ONLY the text with <<<SPLIT>>> markers. Do not add any explanations."""),
        ("human", "{text}")
    ])
    
    chain = prompt | llm
    result = []
    
    for doc in documents:
        text = doc.page_content
        
        # For very short documents, don't split
        if len(text) <= max_chunk_size:
            result.append(doc)
            continue
        
        try:
            # Get LLM suggestions for splits
            response = chain.invoke({
                "text": text,
                "max_size": max_chunk_size
            })
            
            # Parse the response and create chunks
            chunks = response.content.split("<<<SPLIT>>>")
            
            for chunk in chunks:
                chunk = chunk.strip()
                if chunk:
                    result.append(Document(
                        page_content=chunk,
                        metadata=doc.metadata.copy()
                    ))
        except Exception as e:
            print(f"Error processing document with LLM: {e}")
            # Fallback: just add the original document
            result.append(doc)
    
    return result


def split_with_llm_batched(
    documents: List[Document],
    max_chunk_size: int = 1000,
    pre_split_size: int = 5000,
) -> List[Document]:
    """
    LLM-based chunking with pre-splitting for large documents.
    Uses GPT-OSS-120B via OpenRouter.
    First splits large documents into smaller pieces, then uses LLM for final chunking.
    
    This is more efficient for very large documents as it reduces LLM token usage.
    
    Args:
        documents: List of documents to split
        max_chunk_size: Target maximum chunk size
        pre_split_size: Pre-split documents larger than this
    """
    from tqdm import tqdm
    
    llm = get_openrouter_llm()
    
    # Pre-split large documents using recursive splitter
    pre_splitter = RecursiveCharacterTextSplitter(
        chunk_size=pre_split_size,
        chunk_overlap=200,
    )
    
    pre_split_docs = []
    for doc in documents:
        if len(doc.page_content) > pre_split_size:
            pre_split_docs.extend(pre_splitter.split_documents([doc]))
        else:
            pre_split_docs.append(doc)
    
    print(f"Pre-split into {len(pre_split_docs)} sections for LLM processing...")
    print("Using OpenRouter GPT-OSS-120B for intelligent chunking...")
    
    # Now use LLM on smaller pieces
    result = []
    for doc in tqdm(pre_split_docs, desc="LLM Chunking"):
        text = doc.page_content
        
        if len(text) <= max_chunk_size:
            result.append(doc)
            continue
            
        try:
            from langchain_core.prompts import ChatPromptTemplate
            
            prompt = ChatPromptTemplate.from_messages([
                ("system", """You are a text chunking assistant. Your job is to identify logical breakpoints in text.
Given a piece of text, identify where it should be split to create coherent, standalone chunks.
Each chunk should be about a single topic or concept.
Return the text with <<<SPLIT>>> markers where chunks should be separated.
Keep chunks under {max_size} characters when possible.
IMPORTANT: Return ONLY the text with <<<SPLIT>>> markers. Do not add any explanations."""),
                ("human", "{text}")
            ])
            
            chain = prompt | llm
            response = chain.invoke({"text": text, "max_size": max_chunk_size})
            
            chunks = response.content.split("<<<SPLIT>>>")
            for chunk in chunks:
                chunk = chunk.strip()
                if chunk:
                    result.append(Document(
                        page_content=chunk,
                        metadata=doc.metadata.copy()
                    ))
        except Exception as e:
            print(f"Error: {e}")
            result.append(doc)
    
    return result


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================
def print_chunk_stats(chunks: List[Document], name: str = "Chunks"):
    """Print statistics about chunks."""
    if not chunks:
        print(f"{name}: No chunks")
        return
    
    sizes = [len(c.page_content) for c in chunks]
    print(f"\n{'='*50}")
    print(f"{name} Statistics:")
    print(f"{'='*50}")
    print(f"  Total chunks: {len(chunks)}")
    print(f"  Min size: {min(sizes)} chars")
    print(f"  Max size: {max(sizes)} chars")
    print(f"  Avg size: {sum(sizes) / len(sizes):.1f} chars")
    print(f"  Total chars: {sum(sizes)}")
    print(f"{'='*50}\n")


def preview_chunks(chunks: List[Document], num_preview: int = 3):
    """Preview first few chunks."""
    print(f"\nPreview of first {min(num_preview, len(chunks))} chunks:")
    print("-" * 50)
    for i, chunk in enumerate(chunks[:num_preview]):
        print(f"\nChunk {i+1} ({len(chunk.page_content)} chars):")
        print(chunk.page_content[:200] + "..." if len(chunk.page_content) > 200 else chunk.page_content)
        print("-" * 50)


# =============================================================================
# DEMO / TEST FUNCTION
# =============================================================================
def test_all_splitters(documents: List[Document]):
    """Test all chunking strategies and compare results."""
    
    print("\n" + "="*60)
    print("CHUNKING STRATEGY COMPARISON")
    print("="*60)
    
    strategies = {
        "1. Basic Character": get_basic_splitter(),
        "2. Paragraph (\\n\\n)": get_paragraph_splitter(),
        "3. Recursive (priority)": get_recursive_splitter(),
        "4. Sentence-based": get_sentence_splitter(),
        "5. Hierarchical": get_hierarchical_splitter(),
    }
    
    results = {}
    
    for name, splitter in strategies.items():
        chunks = splitter.split_documents(documents)
        results[name] = chunks
        print_chunk_stats(chunks, name)
    
    # Token splitter (different default size)
    token_chunks = get_token_splitter().split_documents(documents)
    results["6. Token-based"] = token_chunks
    print_chunk_stats(token_chunks, "6. Token-based (256 tokens)")
    
    return results


if __name__ == "__main__":
    # Example usage
    from langchain_community.document_loaders import DirectoryLoader, TextLoader
    
    # Load documents
    loader = DirectoryLoader(
        path="docs",
        glob="*.txt",
        loader_cls=TextLoader
    )
    documents = loader.load()
    print(f"Loaded {len(documents)} documents")
    
    # Test all splitters
    results = test_all_splitters(documents)
    
    # Preview chunks from recursive splitter
    print("\n" + "="*60)
    print("PREVIEW: Recursive Splitter Chunks")
    print("="*60)
    preview_chunks(results["3. Recursive (priority)"], num_preview=3)
