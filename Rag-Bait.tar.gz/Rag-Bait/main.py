import chromadb
from tqdm import tqdm
from dotenv import load_dotenv
from langchain_chroma import Chroma
from langchain_mistralai import MistralAIEmbeddings
from langchain_community.document_loaders import DirectoryLoader, TextLoader

# Import chunking strategies
from chunking_strategies import (
    get_basic_splitter,
    get_paragraph_splitter,
    get_recursive_splitter,
    get_sentence_splitter,
    get_token_splitter,
    get_semantic_chunker,
    get_hierarchical_splitter,
    split_with_llm,
    split_with_llm_batched,
    print_chunk_stats,
)

load_dotenv()

# Use local ChromaDB to avoid cloud quota limits
chroma_client = chromadb.PersistentClient(path="./chroma_db")

# Use MistralAI embeddings
embeddings = MistralAIEmbeddings(model="mistral-embed")

def load_documents(docs_path="docs"):
    loader = DirectoryLoader(
        path=docs_path,
        glob="*.txt",
        loader_cls=TextLoader
    )
    return loader.load()


# =============================================================================
# CHOOSE YOUR CHUNKING STRATEGY HERE
# =============================================================================
# Uncomment ONE of the following to use that strategy:

# 1. Basic character splitter (simple, may split mid-word)
# text_splitter = get_basic_splitter(chunk_size=1000, chunk_overlap=200)

# 2. Paragraph splitter (splits on \n\n)
# text_splitter = get_paragraph_splitter(chunk_size=1000, chunk_overlap=200)

# 3. Recursive splitter (priority: \n\n → \n → . → , → " ") [RECOMMENDED]
# text_splitter = get_recursive_splitter(chunk_size=1000, chunk_overlap=200)

# 4. Sentence-based splitter (keeps sentences intact)
# text_splitter = get_sentence_splitter(chunk_size=1000, chunk_overlap=200)

# 5. Token-based splitter (useful for LLM context limits)
# text_splitter = get_token_splitter(chunk_size=256, chunk_overlap=50)

# 6. Hierarchical splitter (best for documents with headers)
# text_splitter = get_hierarchical_splitter(max_chunk_size=1000, chunk_overlap=100)

# 7. Semantic chunker (groups by meaning - slower, uses embeddings)
text_splitter = get_semantic_chunker(breakpoint_threshold_type="percentile")

# 8. LLM-based chunker (uses OpenRouter GPT-OSS-120B - set USE_LLM_CHUNKING = True below)
USE_LLM_CHUNKING = False  # Set to True to use LLM-based chunking

# =============================================================================


def main():
    # documents = load_documents(docs_path="learn")
    documents = load_documents()
    print(f"Loaded {len(documents)} documents from 'docs' directory")

    # This prints the data in the first document for inspection.
    # print(documents[0])

    # Document {
    #     pageContent: 'Foo\nBar\nBaz\n\n',
    #     metadata: {
    #         source: '/Users/bracesproul/code/lang-chain-ai/langchainjs/examples/src/document_loaders/example_data/example.txt'
    #     },
    #     id: undefined
    # }
    # print(documents)

    # Split documents into smaller chunks
    if USE_LLM_CHUNKING:
        # Use LLM-based chunking with OpenRouter GPT-OSS-120B
        print("Using LLM-based chunking with GPT-OSS-120B...")
        chunks = split_with_llm_batched(documents, max_chunk_size=1000)
    else:
        # Use the selected text splitter
        chunks = text_splitter.split_documents(documents)
    
    print_chunk_stats(chunks, "Selected Chunking Strategy")

    # A LangChain wrapper that connects to a local Chroma collection with Mistral embeddings
    vectorstore = Chroma(
        collection_name="rag-learn-1",
        client=chroma_client,
        embedding_function=embeddings,
    )

    batch_size = 50  
    print(f"Adding {len(chunks)} chunks to vector store...")
    for i in tqdm(range(0, len(chunks), batch_size), desc="Embedding"):
        batch = chunks[i:i + batch_size]
        vectorstore.add_documents(batch)
    
    print(f"✓ Inserted {len(chunks)} chunks into Chroma")

if __name__ == "__main__":
    main()