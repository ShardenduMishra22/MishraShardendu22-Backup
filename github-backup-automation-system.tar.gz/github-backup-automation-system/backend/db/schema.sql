CREATE TABLE IF NOT EXISTS backup_runs (
    id SERIAL PRIMARY KEY,
    status TEXT NOT NULL DEFAULT 'running',
    started_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    total_repos INT DEFAULT 0,
    successful INT DEFAULT 0,
    failed INT DEFAULT 0,
    skipped INT DEFAULT 0,
    duration_ms BIGINT DEFAULT 0,
    error_message TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS backup_results (
    id SERIAL PRIMARY KEY,
    run_id INT REFERENCES backup_runs(id) ON DELETE CASCADE,
    repo_full_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    commit_hash TEXT DEFAULT '',
    archive_size_bytes BIGINT DEFAULT 0,
    duration_ms BIGINT DEFAULT 0,
    error_message TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS execution_logs (
    id SERIAL PRIMARY KEY,
    run_id INT REFERENCES backup_runs(id) ON DELETE CASCADE,
    level TEXT NOT NULL DEFAULT 'info',
    message TEXT NOT NULL,
    repository TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_execution_logs_run ON execution_logs(run_id);
CREATE INDEX IF NOT EXISTS idx_execution_logs_time ON execution_logs(created_at);

CREATE TABLE IF NOT EXISTS analytics_snapshots (
    id SERIAL PRIMARY KEY,
    run_id INT REFERENCES backup_runs(id) ON DELETE SET NULL,
    captured_at TIMESTAMPTZ DEFAULT NOW(),
    head_commit TEXT DEFAULT '',
    head_commit_message TEXT DEFAULT '',
    head_commit_at TIMESTAMPTZ,
    total_commits INT DEFAULT 0,
    branch_count INT DEFAULT 0,
    tag_count INT DEFAULT 0,
    tracked_files INT DEFAULT 0,
    total_blob_size_bytes BIGINT DEFAULT 0,
    avg_blob_size_bytes BIGINT DEFAULT 0,
    largest_blob_path TEXT DEFAULT '',
    largest_blob_size_bytes BIGINT DEFAULT 0,
    archive_count INT DEFAULT 0,
    total_archive_size_bytes BIGINT DEFAULT 0,
    avg_archive_size_bytes BIGINT DEFAULT 0,
    largest_archive_path TEXT DEFAULT '',
    largest_archive_size_bytes BIGINT DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_analytics_snapshots_time ON analytics_snapshots(captured_at);
CREATE INDEX IF NOT EXISTS idx_analytics_snapshots_run ON analytics_snapshots(run_id);

CREATE TABLE IF NOT EXISTS backup_fixes (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    commit_hash TEXT DEFAULT '',
    author TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS backup_run_fixes (
    run_id INT REFERENCES backup_runs(id) ON DELETE CASCADE,
    fix_id INT REFERENCES backup_fixes(id) ON DELETE CASCADE,
    PRIMARY KEY (run_id, fix_id)
);

CREATE INDEX IF NOT EXISTS idx_backup_run_fixes_run ON backup_run_fixes(run_id);
CREATE INDEX IF NOT EXISTS idx_backup_run_fixes_fix ON backup_run_fixes(fix_id);

-- ============================================================
-- EMBEDDING SYSTEM TABLES
-- ============================================================

CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS embedding_config (
    id SERIAL PRIMARY KEY,
    provider TEXT NOT NULL,
    embedding_model TEXT NOT NULL,
    embedding_dimensions INT NOT NULL,
    rerank_enabled BOOLEAN NOT NULL DEFAULT false,
    rerank_model TEXT,
    active_version INT NOT NULL DEFAULT 1,
    next_version INT NOT NULL DEFAULT 2,
    status TEXT NOT NULL DEFAULT 'ready'
        CHECK (status IN ('ready', 'reindexing', 'failed')),
    last_reindexed_at TIMESTAMPTZ,
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (id = 1)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_embedding_config_singleton ON embedding_config(id);

CREATE TABLE IF NOT EXISTS content_embeddings (
    id BIGSERIAL PRIMARY KEY,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    chunk_index INT NOT NULL,
    chunk_text TEXT NOT NULL,
    chunk_hash TEXT NOT NULL,
    embedding_version INT NOT NULL DEFAULT 1,
    embedding vector(1536),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(entity_type, entity_id, chunk_index, embedding_version)
);

CREATE INDEX IF NOT EXISTS idx_content_embeddings_entity 
    ON content_embeddings(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_content_embeddings_hash 
    ON content_embeddings(chunk_hash);
CREATE INDEX IF NOT EXISTS idx_content_embeddings_version 
    ON content_embeddings(embedding_version);
CREATE INDEX IF NOT EXISTS idx_content_embeddings_active 
    ON content_embeddings(entity_type, entity_id) 
    WHERE embedding_version = (SELECT active_version FROM embedding_config WHERE id = 1);
CREATE INDEX IF NOT EXISTS idx_content_embeddings_vector 
    ON content_embeddings USING ivfflat (embedding vector_cosine_ops) 
    WITH (lists = 100);

CREATE TABLE IF NOT EXISTS embedding_jobs (
    id BIGSERIAL PRIMARY KEY,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    total_entities INT DEFAULT 0,
    processed_entities INT DEFAULT 0,
    total_chunks INT DEFAULT 0,
    processed_chunks INT DEFAULT 0,
    failed_chunks INT DEFAULT 0,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_embedding_jobs_status 
    ON embedding_jobs(status);
CREATE INDEX IF NOT EXISTS idx_embedding_jobs_created 
    ON embedding_jobs(created_at DESC);

CREATE TABLE IF NOT EXISTS vector_searches (
    id BIGSERIAL PRIMARY KEY,
    query TEXT NOT NULL,
    embedding_model TEXT NOT NULL,
    rerank_model TEXT,
    query_embedding_latency_ms INT,
    vector_search_latency_ms INT,
    retrieved_candidates INT,
    rerank_latency_ms INT,
    reranked_candidates INT,
    returned_results INT,
    context_tokens INT,
    llm_latency_ms INT,
    total_latency_ms INT,
    success BOOLEAN NOT NULL DEFAULT true,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_vector_searches_model 
    ON vector_searches(embedding_model);
CREATE INDEX IF NOT EXISTS idx_vector_searches_time 
    ON vector_searches(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_vector_searches_success 
    ON vector_searches(success);