package db

import (
	"context"
	"fmt"

	"github.com/MishraShardendu22/github-backup/backend/models"
	"github.com/pgvector/pgvector-go"
)

// ============================================================
// EmbeddingConfig Operations
// ============================================================

// GetEmbeddingConfig retrieves the singleton embedding configuration.
func GetEmbeddingConfig(ctx context.Context) (*models.EmbeddingConfig, error) {
	var config models.EmbeddingConfig
	err := Pool.QueryRow(ctx, `
		SELECT id, provider, embedding_model, embedding_dimensions,
		       rerank_enabled, rerank_model, active_version, next_version, status,
		       last_reindexed_at, last_error, created_at, updated_at
		FROM embedding_config
		WHERE id = 1
	`).Scan(
		&config.ID, &config.Provider, &config.EmbeddingModel,
		&config.EmbeddingDimensions, &config.ReRankEnabled, &config.ReRankModel,
		&config.ActiveVersion, &config.NextVersion, &config.Status,
		&config.LastReindexedAt, &config.LastError,
		&config.CreatedAt, &config.UpdatedAt,
	)
	if err != nil {
		return nil, fmt.Errorf("get embedding config: %w", err)
	}
	return &config, nil
}

// UpdateEmbeddingConfig updates the embedding configuration.
func UpdateEmbeddingConfig(ctx context.Context, provider, model string, dimensions int, reRankEnabled bool, reRankModel *string) error {
	_, err := Pool.Exec(ctx, `
		UPDATE embedding_config
		SET provider = $1, embedding_model = $2, embedding_dimensions = $3,
		    rerank_enabled = $4, rerank_model = $5, updated_at = NOW()
		WHERE id = 1
	`, provider, model, dimensions, reRankEnabled, reRankModel)
	if err != nil {
		return fmt.Errorf("update embedding config: %w", err)
	}
	return nil
}

// SetEmbeddingStatus updates the embedding config status (ready/reindexing/failed).
func SetEmbeddingStatus(ctx context.Context, status string, errorMsg *string) error {
	_, err := Pool.Exec(ctx, `
		UPDATE embedding_config
		SET status = $1, last_error = $2, updated_at = NOW()
		WHERE id = 1
	`, status, errorMsg)
	if err != nil {
		return fmt.Errorf("set embedding status: %w", err)
	}
	return nil
}

// SetReindexedAt updates the last reindexed timestamp.
func SetReindexedAt(ctx context.Context) error {
	_, err := Pool.Exec(ctx, `
		UPDATE embedding_config
		SET last_reindexed_at = NOW(), status = 'ready', last_error = NULL, updated_at = NOW()
		WHERE id = 1
	`)
	if err != nil {
		return fmt.Errorf("set reindexed at: %w", err)
	}
	return nil
}

// CreateNewEmbeddingVersion creates a new version for rebuilding.
// Returns the new version number to use.
func CreateNewEmbeddingVersion(ctx context.Context) (int, error) {
	var newVersion int
	err := Pool.QueryRow(ctx, `
		UPDATE embedding_config
		SET next_version = next_version + 1, status = 'reindexing', updated_at = NOW()
		WHERE id = 1
		RETURNING next_version - 1
	`).Scan(&newVersion)
	if err != nil {
		return 0, fmt.Errorf("create new embedding version: %w", err)
	}
	return newVersion, nil
}

// ActivateEmbeddingVersion activates a version (makes it active for searches).
// Only call after the version is fully built and validated.
func ActivateEmbeddingVersion(ctx context.Context, version int) error {
	_, err := Pool.Exec(ctx, `
		UPDATE embedding_config
		SET active_version = $1, status = 'ready', last_reindexed_at = NOW(), 
		    last_error = NULL, updated_at = NOW()
		WHERE id = 1
	`, version)
	if err != nil {
		return fmt.Errorf("activate embedding version: %w", err)
	}
	return nil
}

// CleanupOldEmbeddingVersions deletes versions older than the active version (keep last 2 versions).
// Keeps active_version and the previous version for rollback capability.
func CleanupOldEmbeddingVersions(ctx context.Context) error {
	config, err := GetEmbeddingConfig(ctx)
	if err != nil {
		return fmt.Errorf("get config: %w", err)
	}

	// Keep active version and the one before it
	minVersionToKeep := config.ActiveVersion - 1
	if minVersionToKeep < 1 {
		minVersionToKeep = 1
	}

	_, err = Pool.Exec(ctx, `
		DELETE FROM content_embeddings
		WHERE embedding_version < $1
	`, minVersionToKeep)
	if err != nil {
		return fmt.Errorf("cleanup old embedding versions: %w", err)
	}
	return nil
}

// GetEmbeddingVersionStatus returns detailed version status information.
func GetEmbeddingVersionStatus(ctx context.Context) (map[string]interface{}, error) {
	config, err := GetEmbeddingConfig(ctx)
	if err != nil {
		return nil, fmt.Errorf("get config: %w", err)
	}

	// Count chunks per version
	var counts map[string]int = make(map[string]int)
	rows, err := Pool.Query(ctx, `
		SELECT embedding_version, COUNT(*) as count
		FROM content_embeddings
		GROUP BY embedding_version
		ORDER BY embedding_version
	`)
	if err != nil {
		return nil, fmt.Errorf("query version counts: %w", err)
	}
	defer rows.Close()

	for rows.Next() {
		var version, count int
		if err := rows.Scan(&version, &count); err != nil {
			return nil, err
		}
		counts[fmt.Sprintf("v%d", version)] = count
	}

	return map[string]interface{}{
		"active_version": config.ActiveVersion,
		"next_version":   config.NextVersion,
		"status":         config.Status,
		"version_counts": counts,
	}, nil
}

// ============================================================
// ContentEmbedding Operations
// ============================================================

// InsertContentEmbedding inserts or updates a content embedding in the specified version.
func InsertContentEmbedding(ctx context.Context, entityType, entityID string, chunkIndex int, 
	chunkText, chunkHash string, version int, embedding pgvector.Vector) error {
	_, err := Pool.Exec(ctx, `
		INSERT INTO content_embeddings 
		(entity_type, entity_id, chunk_index, chunk_text, chunk_hash, embedding_version, embedding, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())
		ON CONFLICT (entity_type, entity_id, chunk_index, embedding_version) DO UPDATE SET
		  chunk_text = $4, chunk_hash = $5, embedding = $7, updated_at = NOW()
	`, entityType, entityID, chunkIndex, chunkText, chunkHash, version, embedding)
	if err != nil {
		return fmt.Errorf("insert content embedding: %w", err)
	}
	return nil
}

// DeleteEmbeddingsForEntity deletes all embeddings for a given entity.
func DeleteEmbeddingsForEntity(ctx context.Context, entityType, entityID string) error {
	_, err := Pool.Exec(ctx, `
		DELETE FROM content_embeddings
		WHERE entity_type = $1 AND entity_id = $2
	`, entityType, entityID)
	if err != nil {
		return fmt.Errorf("delete embeddings for entity: %w", err)
	}
	return nil
}

// ClearAllEmbeddings deletes all embeddings (for full rebuild).
func ClearAllEmbeddings(ctx context.Context) error {
	_, err := Pool.Exec(ctx, "TRUNCATE TABLE content_embeddings")
	if err != nil {
		return fmt.Errorf("clear all embeddings: %w", err)
	}
	return nil
}

// VectorSearch performs a similarity search and returns top k results.
// Only searches the active version of embeddings.
func VectorSearch(ctx context.Context, queryEmbedding pgvector.Vector, topK int, entityType *string) ([]models.SearchResult, error) {
	config, err := GetEmbeddingConfig(ctx)
	if err != nil {
		return nil, fmt.Errorf("get config: %w", err)
	}

	query := `
		SELECT id, entity_type, entity_id, chunk_index, chunk_text,
		       1 - (embedding <=> $1::vector) as similarity
		FROM content_embeddings
		WHERE embedding_version = $2
	`
	args := []interface{}{queryEmbedding, config.ActiveVersion}
	argNum := 3

	if entityType != nil {
		query += fmt.Sprintf(" AND entity_type = $%d", argNum)
		args = append(args, *entityType)
		argNum++
	}

	query += fmt.Sprintf(`
		ORDER BY similarity DESC
		LIMIT $%d
	`, argNum)
	args = append(args, topK)

	rows, err := Pool.Query(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("vector search: %w", err)
	}
	defer rows.Close()

	var results []models.SearchResult
	for rows.Next() {
		var result models.SearchResult
		var similarity float32
		err := rows.Scan(&result.ID, &result.EntityType, &result.EntityID, 
			&result.ChunkIndex, &result.ChunkText, &similarity)
		if err != nil {
			return nil, fmt.Errorf("scan search result: %w", err)
		}
		result.Similarity = similarity
		results = append(results, result)
	}

	return results, rows.Err()
}

// GetEmbeddingsForEntity retrieves all embeddings for an entity.
func GetEmbeddingsForEntity(ctx context.Context, entityType, entityID string) ([]models.ContentEmbedding, error) {
	rows, err := Pool.Query(ctx, `
		SELECT id, entity_type, entity_id, chunk_index, chunk_text, chunk_hash,
		       embedding, created_at, updated_at
		FROM content_embeddings
		WHERE entity_type = $1 AND entity_id = $2
		ORDER BY chunk_index ASC
	`, entityType, entityID)
	if err != nil {
		return nil, fmt.Errorf("get embeddings for entity: %w", err)
	}
	defer rows.Close()

	var embeddings []models.ContentEmbedding
	for rows.Next() {
		var emb models.ContentEmbedding
		err := rows.Scan(&emb.ID, &emb.EntityType, &emb.EntityID, &emb.ChunkIndex,
			&emb.ChunkText, &emb.ChunkHash, &emb.Embedding, &emb.CreatedAt, &emb.UpdatedAt)
		if err != nil {
			return nil, fmt.Errorf("scan embedding: %w", err)
		}
		embeddings = append(embeddings, emb)
	}

	return embeddings, rows.Err()
}

// CountEmbeddedEntities returns count of distinct entities with embeddings.
func CountEmbeddedEntities(ctx context.Context) (int, error) {
	var count int
	err := Pool.QueryRow(ctx, `
		SELECT COUNT(DISTINCT entity_type || ':' || entity_id)
		FROM content_embeddings
	`).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("count embedded entities: %w", err)
	}
	return count, nil
}

// CountEmbeddedChunks returns count of all chunks.
func CountEmbeddedChunks(ctx context.Context) (int, error) {
	var count int
	err := Pool.QueryRow(ctx, `
		SELECT COUNT(*)
		FROM content_embeddings
	`).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("count embedded chunks: %w", err)
	}
	return count, nil
}

// ============================================================
// EmbeddingJob Operations
// ============================================================

// CreateEmbeddingJob creates a new embedding job.
func CreateEmbeddingJob(ctx context.Context) (int64, error) {
	var jobID int64
	err := Pool.QueryRow(ctx, `
		INSERT INTO embedding_jobs (status, started_at, created_at, updated_at)
		VALUES ('pending', NOW(), NOW(), NOW())
		RETURNING id
	`).Scan(&jobID)
	if err != nil {
		return 0, fmt.Errorf("create embedding job: %w", err)
	}
	return jobID, nil
}

// UpdateEmbeddingJob updates job progress and status.
func UpdateEmbeddingJob(ctx context.Context, jobID int64, status string, processedEntities, totalChunks, processedChunks, failedChunks int, errorMsg *string) error {
	_, err := Pool.Exec(ctx, `
		UPDATE embedding_jobs
		SET status = $1, processed_entities = $2, total_chunks = $3, 
		    processed_chunks = $4, failed_chunks = $5, error_message = $6, updated_at = NOW()
		WHERE id = $7
	`, status, processedEntities, totalChunks, processedChunks, failedChunks, errorMsg, jobID)
	if err != nil {
		return fmt.Errorf("update embedding job: %w", err)
	}
	return nil
}

// CompleteEmbeddingJob marks a job as completed.
func CompleteEmbeddingJob(ctx context.Context, jobID int64) error {
	_, err := Pool.Exec(ctx, `
		UPDATE embedding_jobs
		SET status = 'completed', completed_at = NOW(), updated_at = NOW()
		WHERE id = $1
	`, jobID)
	if err != nil {
		return fmt.Errorf("complete embedding job: %w", err)
	}
	return nil
}

// GetLastEmbeddingJob retrieves the most recent job.
func GetLastEmbeddingJob(ctx context.Context) (*models.EmbeddingJob, error) {
	var job models.EmbeddingJob
	err := Pool.QueryRow(ctx, `
		SELECT id, status, started_at, completed_at, total_entities,
		       processed_entities, total_chunks, processed_chunks, failed_chunks,
		       error_message, created_at, updated_at
		FROM embedding_jobs
		ORDER BY created_at DESC
		LIMIT 1
	`).Scan(&job.ID, &job.Status, &job.StartedAt, &job.CompletedAt, &job.TotalEntities,
		&job.ProcessedEntities, &job.TotalChunks, &job.ProcessedChunks, &job.FailedChunks,
		&job.ErrorMessage, &job.CreatedAt, &job.UpdatedAt)
	if err != nil {
		return nil, fmt.Errorf("get last embedding job: %w", err)
	}
	return &job, nil
}

// ============================================================
// VectorSearch Telemetry Operations
// ============================================================

// RecordVectorSearch records a search operation.
func RecordVectorSearch(ctx context.Context, search *models.VectorSearch) error {
	_, err := Pool.Exec(ctx, `
		INSERT INTO vector_searches
		(query, embedding_model, rerank_model, query_embedding_latency_ms,
		 vector_search_latency_ms, retrieved_candidates, rerank_latency_ms,
		 reranked_candidates, returned_results, context_tokens, llm_latency_ms,
		 total_latency_ms, success, error_message, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW())
	`, search.Query, search.EmbeddingModel, search.ReRankModel, search.QueryEmbeddingLatencyMs,
		search.VectorSearchLatencyMs, search.RetrievedCandidates, search.ReRankLatencyMs,
		search.RerankedCandidates, search.ReturnedResults, search.ContextTokens, search.LLMLatencyMs,
		search.TotalLatencyMs, search.Success, search.ErrorMessage)
	if err != nil {
		return fmt.Errorf("record vector search: %w", err)
	}
	return nil
}

// GetSearchStats returns search statistics for a time period.
func GetSearchStats(ctx context.Context, hours int) (map[string]interface{}, error) {
	var totalSearches int64
	var avgEmbeddingLatency *int
	var avgSearchLatency *int
	var avgReRankLatency *int
	var avgTotalLatency *int
	var avgCandidates *int
	var successfulSearches int64

	row := Pool.QueryRow(ctx, `
		SELECT COUNT(*) as total_searches,
		       AVG(query_embedding_latency_ms) as avg_embedding_latency,
		       AVG(vector_search_latency_ms) as avg_search_latency,
		       AVG(rerank_latency_ms) as avg_rerank_latency,
		       AVG(total_latency_ms) as avg_total_latency,
		       AVG(retrieved_candidates) as avg_candidates,
		       SUM(CASE WHEN success = true THEN 1 ELSE 0 END) as successful_searches
		FROM vector_searches
		WHERE created_at > NOW() - INTERVAL '1 hour' * $1
	`, hours)

	err := row.Scan(
		&totalSearches,
		&avgEmbeddingLatency,
		&avgSearchLatency,
		&avgReRankLatency,
		&avgTotalLatency,
		&avgCandidates,
		&successfulSearches,
	)
	if err != nil {
		return nil, fmt.Errorf("get search stats: %w", err)
	}

	stats := map[string]interface{}{
		"total_searches":        totalSearches,
		"avg_embedding_latency": avgEmbeddingLatency,
		"avg_search_latency":    avgSearchLatency,
		"avg_rerank_latency":    avgReRankLatency,
		"avg_total_latency":     avgTotalLatency,
		"avg_candidates":        avgCandidates,
		"successful_searches":   successfulSearches,
	}

	return stats, nil
}

// InitializeEmbeddingConfig inserts the default singleton configuration.
func InitializeEmbeddingConfig(ctx context.Context) error {
	_, err := Pool.Exec(ctx, `
		INSERT INTO embedding_config
		(id, provider, embedding_model, embedding_dimensions, rerank_enabled, active_version, next_version, status, created_at, updated_at)
		VALUES (1, 'openrouter', 'jina-embeddings-v3', 1024, false, 1, 2, 'ready', NOW(), NOW())
		ON CONFLICT (id) DO NOTHING
	`)
	if err != nil {
		return fmt.Errorf("initialize embedding config: %w", err)
	}
	return nil
}
