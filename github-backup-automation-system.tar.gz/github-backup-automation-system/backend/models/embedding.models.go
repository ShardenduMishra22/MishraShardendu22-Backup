package models

import (
	"time"

	"github.com/pgvector/pgvector-go"
)

// EmbeddingConfig stores the active embedding configuration (singleton row).
type EmbeddingConfig struct {
	ID                  int       `db:"id" json:"id"`
	Provider            string    `db:"provider" json:"provider"`
	EmbeddingModel      string    `db:"embedding_model" json:"embedding_model"`
	EmbeddingDimensions int       `db:"embedding_dimensions" json:"embedding_dimensions"`
	ReRankEnabled       bool      `db:"rerank_enabled" json:"rerank_enabled"`
	ReRankModel         *string   `db:"rerank_model" json:"rerank_model"`
	ActiveVersion       int       `db:"active_version" json:"active_version"`      // Currently active version
	NextVersion         int       `db:"next_version" json:"next_version"`          // Version being built
	Status              string    `db:"status" json:"status"`                       // ready, reindexing, failed
	LastReindexedAt     *time.Time `db:"last_reindexed_at" json:"last_reindexed_at"`
	LastError           *string   `db:"last_error" json:"last_error"`
	CreatedAt           time.Time `db:"created_at" json:"created_at"`
	UpdatedAt           time.Time `db:"updated_at" json:"updated_at"`
}

// ContentEmbedding represents a single embedded chunk.
type ContentEmbedding struct {
	ID                 int64                   `db:"id" json:"id"`
	EntityType         string                  `db:"entity_type" json:"entity_type"`
	EntityID           string                  `db:"entity_id" json:"entity_id"`
	ChunkIndex         int                     `db:"chunk_index" json:"chunk_index"`
	ChunkText          string                  `db:"chunk_text" json:"chunk_text"`
	ChunkHash          string                  `db:"chunk_hash" json:"chunk_hash"`
	EmbeddingVersion   int                     `db:"embedding_version" json:"embedding_version"`
	Embedding          pgvector.Vector         `db:"embedding" json:"embedding"`
	CreatedAt          time.Time               `db:"created_at" json:"created_at"`
	UpdatedAt          time.Time               `db:"updated_at" json:"updated_at"`
}

// EmbeddingJob tracks embedding rebuild jobs.
type EmbeddingJob struct {
	ID               int64          `db:"id" json:"id"`
	Status           string         `db:"status" json:"status"` // pending, processing, completed, failed
	StartedAt        time.Time      `db:"started_at" json:"started_at"`
	CompletedAt      *time.Time     `db:"completed_at" json:"completed_at"`
	TotalEntities    int            `db:"total_entities" json:"total_entities"`
	ProcessedEntities int           `db:"processed_entities" json:"processed_entities"`
	TotalChunks      int            `db:"total_chunks" json:"total_chunks"`
	ProcessedChunks  int            `db:"processed_chunks" json:"processed_chunks"`
	FailedChunks     int            `db:"failed_chunks" json:"failed_chunks"`
	ErrorMessage     *string        `db:"error_message" json:"error_message"`
	CreatedAt        time.Time      `db:"created_at" json:"created_at"`
	UpdatedAt        time.Time      `db:"updated_at" json:"updated_at"`
}

// VectorSearch stores search telemetry.
type VectorSearch struct {
	ID                        int64       `db:"id" json:"id"`
	Query                     string      `db:"query" json:"query"`
	EmbeddingModel            string      `db:"embedding_model" json:"embedding_model"`
	ReRankModel               *string     `db:"rerank_model" json:"rerank_model"`
	QueryEmbeddingLatencyMs   *int        `db:"query_embedding_latency_ms" json:"query_embedding_latency_ms"`
	VectorSearchLatencyMs     *int        `db:"vector_search_latency_ms" json:"vector_search_latency_ms"`
	RetrievedCandidates       *int        `db:"retrieved_candidates" json:"retrieved_candidates"`
	ReRankLatencyMs           *int        `db:"rerank_latency_ms" json:"rerank_latency_ms"`
	RerankedCandidates        *int        `db:"reranked_candidates" json:"reranked_candidates"`
	ReturnedResults           *int        `db:"returned_results" json:"returned_results"`
	ContextTokens             *int        `db:"context_tokens" json:"context_tokens"`
	LLMLatencyMs              *int        `db:"llm_latency_ms" json:"llm_latency_ms"`
	TotalLatencyMs            *int        `db:"total_latency_ms" json:"total_latency_ms"`
	Success                   bool        `db:"success" json:"success"`
	ErrorMessage              *string     `db:"error_message" json:"error_message"`
	CreatedAt                 time.Time   `db:"created_at" json:"created_at"`
}

// SearchRequest is the request structure for vector search.
type SearchRequest struct {
	Query         string  `json:"query" binding:"required"`
	TopK          int     `json:"top_k,omitempty"`
	UseReranking  bool    `json:"use_reranking,omitempty"`
	EntityType    *string `json:"entity_type,omitempty"`
}

// SearchResult is a single search result.
type SearchResult struct {
	ID        int64   `json:"id"`
	EntityType string `json:"entity_type"`
	EntityID  string  `json:"entity_id"`
	ChunkIndex int     `json:"chunk_index"`
	ChunkText string  `json:"chunk_text"`
	Similarity float32 `json:"similarity"`
}

// SearchResponse is the response structure for vector search.
type SearchResponse struct {
	Results    []SearchResult `json:"results"`
	TotalCount int            `json:"total_count"`
	Query      string         `json:"query"`
}
