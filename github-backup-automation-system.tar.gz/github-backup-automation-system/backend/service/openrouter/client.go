package openrouter

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

const (
	BaseURL              = "https://openrouter.ai/api/v1"
	ModelsEndpoint       = "/models"
	EmbeddingsEndpoint   = "/embeddings"
	RankerEndpoint       = "/rank"
	DefaultTimeout       = 30 * time.Second
	DefaultRetries       = 3
	DefaultBackoffFactor = 2.0
)

// Client handles OpenRouter API interactions.
type Client struct {
	apiKey     string
	apiKeys    []string
	keyIndex   int
	baseURL    string
	httpClient *http.Client
	timeout    time.Duration
}

// Model represents an OpenRouter model.
type Model struct {
	ID           string                 `json:"id"`
	Name         string                 `json:"name"`
	Pricing      map[string]interface{} `json:"pricing"`
	Architecture map[string]interface{} `json:"architecture"`
	Capabilities []string               `json:"capabilities"`
	Context      int                    `json:"context_length"`
}

// ModelsResponse is the response from the models endpoint.
type ModelsResponse struct {
	Data []Model `json:"data"`
}

// EmbeddingRequest is the request for embedding.
type EmbeddingRequest struct {
	Model  string   `json:"model"`
	Input  []string `json:"input"`
	EncodingFormat string `json:"encoding_format,omitempty"`
}

// EmbeddingResponse is the response from embedding endpoint.
type EmbeddingResponse struct {
	Data []struct {
		Embedding []float32 `json:"embedding"`
		Index     int       `json:"index"`
	} `json:"data"`
	Model string `json:"model"`
	Usage struct {
		PromptTokens int `json:"prompt_tokens"`
		TotalTokens  int `json:"total_tokens"`
	} `json:"usage"`
}

// NewClient creates a new OpenRouter client.
// Supports multiple API keys separated by commas.
func NewClient(apiKey string) *Client {
	keys := strings.Split(strings.TrimSpace(apiKey), ",")
	var cleanKeys []string
	for _, k := range keys {
		trimmed := strings.TrimSpace(k)
		if trimmed != "" {
			cleanKeys = append(cleanKeys, trimmed)
		}
	}

	if len(cleanKeys) == 0 {
		return nil
	}

	return &Client{
		apiKey:   apiKey,
		apiKeys:  cleanKeys,
		baseURL:  BaseURL,
		timeout:  DefaultTimeout,
		httpClient: &http.Client{
			Timeout: DefaultTimeout,
		},
	}
}

// getNextAPIKey rotates to the next API key.
func (c *Client) getNextAPIKey() string {
	if len(c.apiKeys) == 0 {
		return ""
	}
	key := c.apiKeys[c.keyIndex]
	c.keyIndex = (c.keyIndex + 1) % len(c.apiKeys)
	return key
}

// GetAvailableModels retrieves all models from OpenRouter, filtered for embeddings.
func (c *Client) GetAvailableModels(ctx context.Context) ([]Model, error) {
	req, err := http.NewRequestWithContext(ctx, "GET", c.baseURL+ModelsEndpoint, nil)
	if err != nil {
		return nil, fmt.Errorf("create request: %w", err)
	}

	req.Header.Set("Authorization", "Bearer "+c.getNextAPIKey())
	req.Header.Set("User-Agent", "GitHub-Backup-Observatory/1.0")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("api error %d: %s", resp.StatusCode, string(body))
	}

	var modelsResp ModelsResponse
	if err := json.NewDecoder(resp.Body).Decode(&modelsResp); err != nil {
		return nil, fmt.Errorf("decode response: %w", err)
	}

	return modelsResp.Data, nil
}

// GetEmbeddingModels filters models that support embeddings.
func (c *Client) GetEmbeddingModels(ctx context.Context) ([]Model, error) {
	models, err := c.GetAvailableModels(ctx)
	if err != nil {
		return nil, err
	}

	var embeddingModels []Model
	for _, model := range models {
		// Check for embedding capability
		arch, ok := model.Architecture["output_modalities"]
		if !ok {
			continue
		}

		modalities, ok := arch.([]interface{})
		if !ok {
			continue
		}

		// Check if "text" is in output_modalities
		hasText := false
		for _, m := range modalities {
			if s, ok := m.(string); ok && s == "text" {
				hasText = true
				break
			}
		}

		if !hasText {
			continue
		}

		// Check if free (pricing is 0)
		prompt, _ := model.Pricing["prompt"].(string)
		completion, _ := model.Pricing["completion"].(string)

		// Skip paid models
		if prompt != "0" && prompt != "" {
			continue
		}
		if completion != "0" && completion != "" {
			continue
		}

		embeddingModels = append(embeddingModels, model)
	}

	return embeddingModels, nil
}

// GetRerankerModels filters models that support reranking.
func (c *Client) GetRerankerModels(ctx context.Context) ([]Model, error) {
	models, err := c.GetAvailableModels(ctx)
	if err != nil {
		return nil, err
	}

	var rerankerModels []Model
	for _, model := range models {
		// Check for reranking capability
		hasReranking := false
		for _, cap := range model.Capabilities {
			if cap == "ranking" || strings.Contains(cap, "rerank") {
				hasReranking = true
				break
			}
		}

		if !hasReranking {
			continue
		}

		// Check if free (pricing is 0)
		prompt, _ := model.Pricing["prompt"].(string)
		completion, _ := model.Pricing["completion"].(string)

		// Skip paid models
		if prompt != "0" && prompt != "" {
			continue
		}
		if completion != "0" && completion != "" {
			continue
		}

		rerankerModels = append(rerankerModels, model)
	}

	return rerankerModels, nil
}

// CreateEmbedding generates embeddings for text.
func (c *Client) CreateEmbedding(ctx context.Context, model string, texts []string) ([][]float32, error) {
	if len(texts) == 0 {
		return nil, fmt.Errorf("no texts provided")
	}

	req := EmbeddingRequest{
		Model:  model,
		Input:  texts,
	}

	body, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("marshal request: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx, "POST", c.baseURL+EmbeddingsEndpoint, bytes.NewReader(body))
	if err != nil {
		return nil, fmt.Errorf("create request: %w", err)
	}

	httpReq.Header.Set("Authorization", "Bearer "+c.getNextAPIKey())
	httpReq.Header.Set("User-Agent", "GitHub-Backup-Observatory/1.0")
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		respBody, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("api error %d: %s", resp.StatusCode, string(respBody))
	}

	var embeddingResp EmbeddingResponse
	if err := json.NewDecoder(resp.Body).Decode(&embeddingResp); err != nil {
		return nil, fmt.Errorf("decode response: %w", err)
	}

	// Convert to slice of embeddings
	embeddings := make([][]float32, len(embeddingResp.Data))
	for _, emb := range embeddingResp.Data {
		embeddings[emb.Index] = emb.Embedding
	}

	return embeddings, nil
}

// IsAvailable checks if the OpenRouter API is available.
func (c *Client) IsAvailable(ctx context.Context) bool {
	_, err := c.GetAvailableModels(ctx)
	return err == nil
}
