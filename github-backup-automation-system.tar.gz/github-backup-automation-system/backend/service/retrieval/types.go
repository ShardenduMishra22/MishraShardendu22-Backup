package retrieval

import (
	"context"
	"time"

	"github.com/MishraShardendu22/github-backup/backend/models"
	"github.com/pgvector/pgvector-go"
)

// RetrievalService orchestrates the semantic search pipeline.
// It handles query embedding, vector search, optional reranking, and telemetry.
type RetrievalService interface {
	// Search performs a semantic search query end-to-end.
	// Returns search results ranked by relevance.
	Search(ctx context.Context, query string) (*SearchResults, error)

	// DebugSearch performs a search with detailed debug information.
	// Useful for understanding the retrieval pipeline behavior.
	DebugSearch(ctx context.Context, query string) (*DebugSearchResults, error)
}

// SearchResults represents the final search results.
type SearchResults struct {
	Query            string               `json:"query"`
	Results          []RankedSearchResult `json:"results"`
	TotalCandidates  int                  `json:"total_candidates"`
	FinalCount       int                  `json:"final_count"`
	ExecutionDetails ExecutionMetrics     `json:"execution"`
}

// RankedSearchResult is a search result with rank information.
type RankedSearchResult struct {
	models.SearchResult
	Rank int `json:"rank"` // 1-based rank in results
}

// ExecutionMetrics contains timing and performance metrics.
type ExecutionMetrics struct {
	QueryEmbeddingMs int64 `json:"query_embedding_ms"`
	VectorSearchMs   int64 `json:"vector_search_ms"`
	RerankerMs       int64 `json:"reranker_ms"`
	TotalMs          int64 `json:"total_ms"`
	RerankerUsed     bool  `json:"reranker_used"`
}

// DebugSearchResults contains detailed debug information about the search pipeline.
type DebugSearchResults struct {
	Query                    string                  `json:"query"`
	QueryEmbedding           pgvector.Vector         `json:"query_embedding"`
	QueryEmbeddingModel      string                  `json:"query_embedding_model"`
	VectorSearchCandidates   []VectorSearchCandidate `json:"vector_search_candidates"`
	VectorSearchTopK         int                     `json:"vector_search_top_k"`
	SimilarityThreshold      float32                 `json:"similarity_threshold"`
	RerankingEnabled         bool                    `json:"reranking_enabled"`
	RerankModel              *string                 `json:"rerank_model"`
	RankedResults            []RankedResult          `json:"ranked_results"`
	ExecutionDetails         ExecutionMetrics        `json:"execution"`
	CandidatesAfterThreshold int                     `json:"candidates_after_threshold"`
	FinalResults             int                     `json:"final_results"`
}

// VectorSearchCandidate represents a candidate from vector search before reranking.
type VectorSearchCandidate struct {
	models.SearchResult
	Embedding *pgvector.Vector `json:"embedding,omitempty"` // Only in debug mode
}

// RankedResult represents a result after reranking.
type RankedResult struct {
	ID               int64    `json:"id"`
	EntityType       string   `json:"entity_type"`
	EntityID         string   `json:"entity_id"`
	ChunkIndex       int      `json:"chunk_index"`
	ChunkText        string   `json:"chunk_text"`
	VectorSimilarity float32  `json:"vector_similarity"`
	RerankScore      *float32 `json:"rerank_score,omitempty"`
	OriginalRank     int      `json:"original_rank"` // Rank from vector search
	FinalRank        int      `json:"final_rank"`    // Rank after reranking
}

// SearchConfig contains configuration for search operations.
type SearchConfig struct {
	TopK                int     `json:"top_k"`
	SimilarityThreshold float32 `json:"similarity_threshold"`
	EmbeddingModel      string  `json:"embedding_model"`
	RerankEnabled       bool    `json:"rerank_enabled"`
	RerankModel         *string `json:"rerank_model"`
	MaxVectorCandidates int     `json:"max_vector_candidates"` // Candidates before reranking
}

// SearchTelemetry contains telemetry data for recording search operations.
type SearchTelemetry struct {
	Query                   string    `db:"query"`
	QueryHash               string    `db:"query_hash"` // SHA256 of query
	EmbeddingModel          string    `db:"embedding_model"`
	RerankModel             *string   `db:"rerank_model"`
	QueryEmbeddingLatencyMs int       `db:"query_embedding_latency_ms"`
	VectorSearchLatencyMs   int       `db:"vector_search_latency_ms"`
	RetrievedCandidates     int       `db:"retrieved_candidates"`
	RerankLatencyMs         *int      `db:"rerank_latency_ms"`
	RerankedCandidates      *int      `db:"reranked_candidates"`
	ReturnedResults         int       `db:"returned_results"`
	TotalLatencyMs          int       `db:"total_latency_ms"`
	Success                 bool      `db:"success"`
	ErrorMessage            *string   `db:"error_message"`
	CreatedAt               time.Time `db:"created_at"`
}
