package retrieval

import (
	"context"
	"crypto/sha256"
	"fmt"
	"log/slog"
	"time"

	"github.com/MishraShardendu22/github-backup/backend/db"
	"github.com/MishraShardendu22/github-backup/backend/models"
	"github.com/MishraShardendu22/github-backup/backend/service/provider"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/pgvector/pgvector-go"
)

// Service implements RetrievalService for semantic search.
type Service struct {
	pool              *pgxpool.Pool
	embeddingProvider provider.EmbeddingProvider
	rerankProvider    provider.RerankProvider
	logger            *slog.Logger
	config            *SearchConfig
}

// NewService creates a new retrieval service.
func NewService(
	pool *pgxpool.Pool,
	embeddingProvider provider.EmbeddingProvider,
	rerankProvider provider.RerankProvider,
	logger *slog.Logger,
) (*Service, error) {
	if pool == nil {
		return nil, fmt.Errorf("pool is required")
	}
	if embeddingProvider == nil {
		return nil, fmt.Errorf("embedding provider is required")
	}
	if logger == nil {
		logger = slog.Default()
	}

	// Load configuration from embedding_config
	config, err := loadSearchConfig(context.Background())
	if err != nil {
		return nil, fmt.Errorf("load search config: %w", err)
	}

	return &Service{
		pool:              pool,
		embeddingProvider: embeddingProvider,
		rerankProvider:    rerankProvider,
		logger:            logger,
		config:            config,
	}, nil
}

// Search performs an end-to-end semantic search.
func (s *Service) Search(ctx context.Context, query string) (*SearchResults, error) {
	start := time.Now()
	telemetry := &SearchTelemetry{
		Query:      query,
		QueryHash:  hashQuery(query),
		CreatedAt:  start,
		Success:    true,
	}

	// 1. Generate query embedding
	embedStart := time.Now()
	queryEmbedding, err := s.generateQueryEmbedding(ctx, query)
	if err != nil {
		telemetry.Success = false
		telemetry.ErrorMessage = ptrString(fmt.Sprintf("embedding generation: %v", err))
		s.recordTelemetry(context.Background(), telemetry)
		return nil, fmt.Errorf("generate query embedding: %w", err)
	}
	telemetry.EmbeddingModel = s.config.EmbeddingModel
	telemetry.QueryEmbeddingLatencyMs = int(time.Since(embedStart).Milliseconds())

	// 2. Vector search
	searchStart := time.Now()
	candidates, err := s.vectorSearch(ctx, queryEmbedding)
	if err != nil {
		telemetry.Success = false
		telemetry.ErrorMessage = ptrString(fmt.Sprintf("vector search: %v", err))
		s.recordTelemetry(context.Background(), telemetry)
		return nil, fmt.Errorf("vector search: %w", err)
	}
	telemetry.VectorSearchLatencyMs = int(time.Since(searchStart).Milliseconds())
	telemetry.RetrievedCandidates = len(candidates)

	// 3. Optional reranking
	results := candidates
	if s.config.RerankEnabled && s.rerankProvider != nil {
		rerankStart := time.Now()
		reranked, rerankErr := s.rerankCandidates(ctx, query, candidates)
		rerankMs := int(time.Since(rerankStart).Milliseconds())
		telemetry.RerankLatencyMs = &rerankMs

		if rerankErr != nil {
			s.logger.WarnContext(ctx, "reranking failed, using vector search results", "error", rerankErr)
			// Fall through - use vector search results
		} else {
			results = reranked
			telemetry.RerankedCandidates = ptrInt(len(reranked))
		}

		if s.config.RerankModel != nil {
			telemetry.RerankModel = s.config.RerankModel
		}
	}

	// 4. Apply threshold filter
	filtered := s.applyThreshold(results)

	// 5. Finalize results
	final := s.finalizeResults(filtered)

	telemetry.ReturnedResults = len(final)
	telemetry.TotalLatencyMs = int(time.Since(start).Milliseconds())

	s.recordTelemetry(context.Background(), telemetry)

	rankedFinal := make([]RankedSearchResult, len(final))
	for i, r := range final {
		rankedFinal[i] = RankedSearchResult{
			SearchResult: r,
			Rank:         i + 1,
		}
	}

	return &SearchResults{
		Query:           query,
		Results:         rankedFinal,
		TotalCandidates: len(candidates),
		FinalCount:      len(final),
		ExecutionDetails: ExecutionMetrics{
			QueryEmbeddingMs: int64(telemetry.QueryEmbeddingLatencyMs),
			VectorSearchMs:   int64(telemetry.VectorSearchLatencyMs),
			RerankerMs:       int64(derefInt(telemetry.RerankLatencyMs)),
			TotalMs:          int64(telemetry.TotalLatencyMs),
			RerankerUsed:     s.config.RerankEnabled && telemetry.RerankLatencyMs != nil,
		},
	}, nil
}

// DebugSearch returns detailed search pipeline information.
func (s *Service) DebugSearch(ctx context.Context, query string) (*DebugSearchResults, error) {
	start := time.Now()

	// Generate query embedding
	embedStart := time.Now()
	queryEmbedding, err := s.generateQueryEmbedding(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("generate query embedding: %w", err)
	}
	embedMs := int64(time.Since(embedStart).Milliseconds())

	// Vector search
	searchStart := time.Now()
	candidates, err := s.vectorSearch(ctx, queryEmbedding)
	if err != nil {
		return nil, fmt.Errorf("vector search: %w", err)
	}
	searchMs := int64(time.Since(searchStart).Milliseconds())

	// Convert to debug candidates
	debugCandidates := make([]VectorSearchCandidate, len(candidates))
	for i, c := range candidates {
		debugCandidates[i] = VectorSearchCandidate{
			SearchResult: c,
		}
	}

	// Apply threshold for counting
	filtered := s.applyThreshold(candidates)

	// Optional reranking
	var rankedResults []RankedResult
	var rerankMs int64
	if s.config.RerankEnabled && s.rerankProvider != nil {
		rerankStart := time.Now()
		reranked, rerankErr := s.rerankCandidates(ctx, query, candidates)
		rerankMs = int64(time.Since(rerankStart).Milliseconds())

		if rerankErr == nil {
			rankedResults = make([]RankedResult, len(reranked))
			for i, r := range reranked {
				rankedResults[i] = RankedResult{
					ID:               r.ID,
					EntityType:       r.EntityType,
					EntityID:         r.EntityID,
					ChunkIndex:       r.ChunkIndex,
					ChunkText:        r.ChunkText,
					VectorSimilarity: r.Similarity,
					OriginalRank:     i + 1,
					FinalRank:        i + 1,
				}
			}
		}
	}

	totalMs := int64(time.Since(start).Milliseconds())

	return &DebugSearchResults{
		Query:                    query,
		QueryEmbedding:           queryEmbedding,
		QueryEmbeddingModel:      s.config.EmbeddingModel,
		VectorSearchCandidates:   debugCandidates,
		VectorSearchTopK:         s.config.TopK,
		SimilarityThreshold:      s.config.SimilarityThreshold,
		RerankingEnabled:         s.config.RerankEnabled,
		RerankModel:              s.config.RerankModel,
		RankedResults:            rankedResults,
		CandidatesAfterThreshold: len(filtered),
		FinalResults:             len(rankedResults),
		ExecutionDetails: ExecutionMetrics{
			QueryEmbeddingMs: embedMs,
			VectorSearchMs:   searchMs,
			RerankerMs:       rerankMs,
			TotalMs:          totalMs,
			RerankerUsed:     s.config.RerankEnabled,
		},
	}, nil
}

// generateQueryEmbedding generates embedding for the query.
func (s *Service) generateQueryEmbedding(ctx context.Context, query string) (pgvector.Vector, error) {
	embeddings, err := s.embeddingProvider.GenerateEmbeddings(ctx, s.config.EmbeddingModel, []string{query})
	if err != nil {
		return pgvector.Vector{}, fmt.Errorf("embedding provider: %w", err)
	}

	if len(embeddings) == 0 {
		return pgvector.Vector{}, fmt.Errorf("no embeddings returned")
	}

	return pgvector.NewVector(embeddings[0]), nil
}

// vectorSearch performs vector similarity search.
func (s *Service) vectorSearch(ctx context.Context, queryEmbedding pgvector.Vector) ([]models.SearchResult, error) {
	results, err := db.VectorSearch(ctx, queryEmbedding, s.config.TopK, nil)
	if err != nil {
		return nil, fmt.Errorf("vector search: %w", err)
	}

	return results, nil
}

// rerankCandidates reranks candidates using the rerank provider.
func (s *Service) rerankCandidates(ctx context.Context, query string, candidates []models.SearchResult) ([]models.SearchResult, error) {
	if s.rerankProvider == nil || !s.config.RerankEnabled {
		return candidates, nil
	}

	// Extract chunk texts for reranking
	texts := make([]string, len(candidates))
	for i, c := range candidates {
		texts[i] = c.ChunkText
	}

	// Call rerank provider
	model := ""
	if s.config.RerankModel != nil {
		model = *s.config.RerankModel
	}
	indices, err := s.rerankProvider.Rerank(ctx, model, query, texts)
	if err != nil {
		return nil, fmt.Errorf("rerank provider: %w", err)
	}

	// Reorder results based on returned indices
	reranked := make([]models.SearchResult, len(indices))
	for i, idx := range indices {
		if idx >= 0 && idx < len(candidates) {
			reranked[i] = candidates[idx]
		}
	}

	return reranked, nil
}

// applyThreshold filters candidates below similarity threshold.
func (s *Service) applyThreshold(candidates []models.SearchResult) []models.SearchResult {
	filtered := make([]models.SearchResult, 0, len(candidates))
	for _, c := range candidates {
		if c.Similarity >= s.config.SimilarityThreshold {
			filtered = append(filtered, c)
		}
	}
	return filtered
}

// finalizeResults adds ranking and prepares final output.
func (s *Service) finalizeResults(results []models.SearchResult) []models.SearchResult {
	return results
}

// recordTelemetry stores search telemetry in the database.
func (s *Service) recordTelemetry(ctx context.Context, telemetry *SearchTelemetry) {
	// Convert to models.VectorSearch for storage
	search := &models.VectorSearch{
		Query:                    telemetry.Query,
		EmbeddingModel:           telemetry.EmbeddingModel,
		ReRankModel:              telemetry.RerankModel,
		QueryEmbeddingLatencyMs:  ptrInt(telemetry.QueryEmbeddingLatencyMs),
		VectorSearchLatencyMs:    ptrInt(telemetry.VectorSearchLatencyMs),
		RetrievedCandidates:      ptrInt(telemetry.RetrievedCandidates),
		ReRankLatencyMs:          telemetry.RerankLatencyMs,
		RerankedCandidates:       telemetry.RerankedCandidates,
		ReturnedResults:          ptrInt(telemetry.ReturnedResults),
		TotalLatencyMs:           ptrInt(telemetry.TotalLatencyMs),
		Success:                  telemetry.Success,
		ErrorMessage:             telemetry.ErrorMessage,
	}

	if err := db.RecordVectorSearch(ctx, search); err != nil {
		s.logger.WarnContext(ctx, "failed to record telemetry", "error", err)
	}
}

// loadSearchConfig loads search configuration from database.
func loadSearchConfig(ctx context.Context) (*SearchConfig, error) {
	config, err := db.GetEmbeddingConfig(ctx)
	if err != nil {
		return nil, fmt.Errorf("get embedding config: %w", err)
	}

	searchConfig := &SearchConfig{
		TopK:                100,
		SimilarityThreshold: 0.5,
		EmbeddingModel:      config.EmbeddingModel,
		RerankEnabled:       config.ReRankEnabled,
		RerankModel:         config.ReRankModel,
		MaxVectorCandidates: 200,
	}

	return searchConfig, nil
}

// Helper functions
func hashQuery(query string) string {
	hash := sha256.Sum256([]byte(query))
	return fmt.Sprintf("%x", hash)
}

func ptrString(s string) *string { return &s }
func ptrInt(i int) *int          { return &i }
func derefInt(i *int) int        { if i == nil { return 0 }; return *i }
