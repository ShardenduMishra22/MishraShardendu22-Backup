package chunking

import (
	"crypto/sha256"
	"fmt"
	"strings"
	"unicode"
)

// Strategy defines the chunking strategy for an entity type.
type Strategy string

const (
	StrategyNone     Strategy = "none"
	StrategyFixed    Strategy = "fixed"
	StrategyMarkdown Strategy = "markdown"
	StrategySemantic Strategy = "semantic"
)

// Chunk represents a text chunk.
type Chunk struct {
	Index int
	Text  string
	Hash  string // SHA256 hash of the text
}

// ChunkedContent represents content split into chunks.
type ChunkedContent struct {
	Total  int
	Chunks []Chunk
}

// Chunker handles text chunking based on strategy.
type Chunker struct {
	strategy Strategy
	maxSize  int
}

// New creates a new chunker with the specified strategy and max size.
func New(strategy Strategy, maxSize int) *Chunker {
	if maxSize <= 0 {
		maxSize = 512 // default
	}
	return &Chunker{
		strategy: strategy,
		maxSize:  maxSize,
	}
}

// Chunk splits text according to the chunking strategy.
func (c *Chunker) Chunk(text string) ChunkedContent {
	switch c.strategy {
	case StrategyNone:
		return c.chunkNone(text)
	case StrategyFixed:
		return c.chunkFixed(text)
	case StrategyMarkdown:
		return c.chunkMarkdown(text)
	case StrategySemantic:
		return c.chunkSemantic(text)
	default:
		return c.chunkFixed(text)
	}
}

// chunkNone returns the entire text as a single chunk.
func (c *Chunker) chunkNone(text string) ChunkedContent {
	if text == "" {
		return ChunkedContent{Total: 0, Chunks: []Chunk{}}
	}

	chunk := Chunk{
		Index: 0,
		Text:  text,
		Hash:  hashText(text),
	}

	return ChunkedContent{
		Total:  1,
		Chunks: []Chunk{chunk},
	}
}

// chunkFixed splits text into fixed-size chunks based on character count.
// Does not split on word boundaries.
func (c *Chunker) chunkFixed(text string) ChunkedContent {
	if text == "" {
		return ChunkedContent{Total: 0, Chunks: []Chunk{}}
	}

	runes := []rune(text)
	var chunks []Chunk
	index := 0

	for i := 0; i < len(runes); i += c.maxSize {
		end := i + c.maxSize
		if end > len(runes) {
			end = len(runes)
		}

		chunkText := string(runes[i:end])
		chunks = append(chunks, Chunk{
			Index: index,
			Text:  chunkText,
			Hash:  hashText(chunkText),
		})
		index++
	}

	return ChunkedContent{
		Total:  len(chunks),
		Chunks: chunks,
	}
}

// chunkMarkdown splits text on markdown headers and paragraphs.
func (c *Chunker) chunkMarkdown(text string) ChunkedContent {
	if text == "" {
		return ChunkedContent{Total: 0, Chunks: []Chunk{}}
	}

	lines := strings.Split(text, "\n")
	var chunks []Chunk
	var currentChunk strings.Builder
	index := 0

	for _, line := range lines {
		// Check if this is a header (markdown)
		isHeader := strings.HasPrefix(strings.TrimSpace(line), "#")

		// If we have accumulated content and encounter a header, save the chunk
		if isHeader && currentChunk.Len() > 0 {
			chunkText := strings.TrimSpace(currentChunk.String())
			if chunkText != "" {
				chunks = append(chunks, Chunk{
					Index: index,
					Text:  chunkText,
					Hash:  hashText(chunkText),
				})
				index++
				currentChunk.Reset()
			}
		}

		// Add line to current chunk
		if currentChunk.Len() > 0 {
			currentChunk.WriteString("\n")
		}
		currentChunk.WriteString(line)

		// If chunk is large enough, save it
		if currentChunk.Len() >= c.maxSize {
			chunkText := strings.TrimSpace(currentChunk.String())
			if chunkText != "" {
				chunks = append(chunks, Chunk{
					Index: index,
					Text:  chunkText,
					Hash:  hashText(chunkText),
				})
				index++
				currentChunk.Reset()
			}
		}
	}

	// Add remaining content
	if currentChunk.Len() > 0 {
		chunkText := strings.TrimSpace(currentChunk.String())
		if chunkText != "" {
			chunks = append(chunks, Chunk{
				Index: index,
				Text:  chunkText,
				Hash:  hashText(chunkText),
			})
		}
	}

	return ChunkedContent{
		Total:  len(chunks),
		Chunks: chunks,
	}
}

// chunkSemantic splits text on sentences and paragraphs, respecting maxSize.
func (c *Chunker) chunkSemantic(text string) ChunkedContent {
	if text == "" {
		return ChunkedContent{Total: 0, Chunks: []Chunk{}}
	}

	// Split on double newlines (paragraphs)
	paragraphs := strings.Split(text, "\n\n")
	var chunks []Chunk
	var currentChunk strings.Builder
	index := 0

	for _, para := range paragraphs {
		// Split paragraph into sentences
		sentences := splitSentences(para)

		for _, sentence := range sentences {
			sentence = strings.TrimSpace(sentence)
			if sentence == "" {
				continue
			}

			// Check if adding this sentence would exceed max size
			potentialSize := currentChunk.Len() + len(sentence) + 1 // +1 for space
			if currentChunk.Len() > 0 && potentialSize > c.maxSize {
				// Save current chunk
				chunkText := strings.TrimSpace(currentChunk.String())
				if chunkText != "" {
					chunks = append(chunks, Chunk{
						Index: index,
						Text:  chunkText,
						Hash:  hashText(chunkText),
					})
					index++
					currentChunk.Reset()
				}
			}

			// Add sentence to current chunk
			if currentChunk.Len() > 0 {
				currentChunk.WriteString(" ")
			}
			currentChunk.WriteString(sentence)
		}
	}

	// Add remaining content
	if currentChunk.Len() > 0 {
		chunkText := strings.TrimSpace(currentChunk.String())
		if chunkText != "" {
			chunks = append(chunks, Chunk{
				Index: index,
				Text:  chunkText,
				Hash:  hashText(chunkText),
			})
		}
	}

	return ChunkedContent{
		Total:  len(chunks),
		Chunks: chunks,
	}
}

// splitSentences splits text on sentence boundaries.
func splitSentences(text string) []string {
	// Simple sentence splitting on . ! ?
	var sentences []string
	var current strings.Builder
	runes := []rune(text)

	for i, r := range runes {
		current.WriteRune(r)

		// Check if this is sentence-ending punctuation
		if (r == '.' || r == '!' || r == '?') && i < len(runes)-1 {
			// Check if next character is a space or EOL
			if i+1 < len(runes) && unicode.IsSpace(runes[i+1]) {
				sentences = append(sentences, current.String())
				current.Reset()
			}
		}
	}

	// Add remaining text
	if current.Len() > 0 {
		sentences = append(sentences, current.String())
	}

	return sentences
}

// hashText computes SHA256 hash of text.
func hashText(text string) string {
	hash := sha256.Sum256([]byte(text))
	return fmt.Sprintf("%x", hash)
}

// StrategyFor determines the chunking strategy for an entity type.
func StrategyFor(entityType string) Strategy {
	switch entityType {
	case "investigation":
		return StrategySemantic
	case "backup_fix":
		return StrategySemantic
	case "backup_run_summary":
		return StrategySemantic
	case "analytics_snapshot":
		return StrategyFixed
	case "execution_log":
		return StrategyFixed
	case "repository_summary":
		return StrategyMarkdown
	case "documentation":
		return StrategyMarkdown
	case "chat_message":
		return StrategyNone
	default:
		return StrategyFixed
	}
}

// MaxSizeFor returns the recommended max chunk size for an entity type.
func MaxSizeFor(entityType string) int {
	switch entityType {
	case "investigation":
		return 1000
	case "backup_fix":
		return 1500
	case "backup_run_summary":
		return 2000
	case "analytics_snapshot":
		return 1000
	case "execution_log":
		return 500
	case "repository_summary":
		return 2000
	case "documentation":
		return 2000
	case "chat_message":
		return 99999 // No chunking
	default:
		return 1000
	}
}
