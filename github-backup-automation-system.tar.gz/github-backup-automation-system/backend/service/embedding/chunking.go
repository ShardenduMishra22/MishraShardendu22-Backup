package embedding

import (
	"crypto/sha256"
	"fmt"

	"github.com/MishraShardendu22/github-backup/backend/service/chunking"
)

// ChunkingService handles text chunking using the registry.
type ChunkingService struct {
	registry ChunkingRegistry
}

// Chunk represents a single text chunk.
type Chunk struct {
	Index      int
	Text       string
	Hash       string
	TokenCount int
}

// NewChunkingService creates a new chunking service.
func NewChunkingService(registry ChunkingRegistry) *ChunkingService {
	return &ChunkingService{registry: registry}
}

// ChunkContent splits content into chunks using entity-specific strategy.
func (cs *ChunkingService) ChunkContent(entityType string, title string, content string) ([]Chunk, error) {
	// Combine title and content for chunking
	fullText := fmt.Sprintf("%s\n\n%s", title, content)

	strategy := cs.registry.GetStrategy(entityType)
	maxSize := cs.registry.GetChunkSize(entityType)

	// Use the chunking package's strategies
	chunker := chunking.New(stringToStrategy(strategy), maxSize)
	chunked := chunker.Chunk(fullText)

	// Convert to our Chunk format
	var chunks []Chunk
	for _, c := range chunked.Chunks {
		chunks = append(chunks, Chunk{
			Index:      c.Index,
			Text:       c.Text,
			Hash:       c.Hash,
			TokenCount: estimateTokens(c.Text),
		})
	}

	return chunks, nil
}

// stringToStrategy converts string to chunking.Strategy
func stringToStrategy(s string) chunking.Strategy {
	switch s {
	case "semantic":
		return chunking.StrategySemantic
	case "fixed":
		return chunking.StrategyFixed
	case "markdown":
		return chunking.StrategyMarkdown
	case "none":
		return chunking.StrategyNone
	default:
		return chunking.StrategyFixed
	}
}

// estimateTokens estimates token count using simple heuristic
// (real implementation would use tiktoken or similar)
func estimateTokens(text string) int {
	// Rough estimate: ~1 token per 4 characters
	return (len(text) + 3) / 4
}

// HashChunk creates SHA256 hash of chunk content
func HashChunk(text string) string {
	hash := sha256.Sum256([]byte(text))
	return fmt.Sprintf("%x", hash)
}

// DefaultChunkingRegistry provides default chunking strategy configurations.
type DefaultChunkingRegistry struct{}

func (r *DefaultChunkingRegistry) GetStrategy(entityType string) string {
	strategies := map[string]string{
		"investigation":      "semantic",
		"backup_fix":         "semantic",
		"backup_run":         "semantic",
		"execution_log":      "fixed",
		"analytics_snapshot": "fixed",
	}
	if s, ok := strategies[entityType]; ok {
		return s
	}
	return "fixed"
}

func (r *DefaultChunkingRegistry) GetChunkSize(entityType string) int {
	sizes := map[string]int{
		"investigation":      1024,
		"backup_fix":         1024,
		"backup_run":         512,
		"execution_log":      256,
		"analytics_snapshot": 512,
	}
	if size, ok := sizes[entityType]; ok {
		return size
	}
	return 512
}

func (r *DefaultChunkingRegistry) GetChunkOverlap(entityType string) int {
	overlaps := map[string]int{
		"investigation":      100,
		"backup_fix":         100,
		"backup_run":         50,
		"execution_log":      0,
		"analytics_snapshot": 0,
	}
	if overlap, ok := overlaps[entityType]; ok {
		return overlap
	}
	return 0
}
