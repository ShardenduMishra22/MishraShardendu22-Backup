package embedding

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/MishraShardendu22/github-backup/backend/db"
)

// InvestigationBuilder converts investigations to searchable text.
type InvestigationBuilder struct{}

func (b *InvestigationBuilder) Entity() string {
	return "investigation"
}

func (b *InvestigationBuilder) Build(ctx context.Context, entityID string) (string, string, error) {
	// Query investigation from database
	query := `
		SELECT id, question, answer, status, created_at
		FROM investigations
		WHERE request_id::text = $1
		LIMIT 1
	`
	
	var id, question, answer, status string
	var createdAt time.Time
	
	err := db.Pool.QueryRow(ctx, query, entityID).Scan(&id, &question, &answer, &status, &createdAt)
	if err != nil {
		return "", "", fmt.Errorf("query investigation: %w", err)
	}
	
	// Build title and content
	title := strings.TrimSpace(question)
	if len(title) > 100 {
		title = title[:100]
	}
	
	content := fmt.Sprintf("Question: %s\n\nAnswer: %s\n\nStatus: %s\n\nCreated: %s",
		question, answer, status, createdAt.Format(time.RFC3339))
	
	return title, content, nil
}

// BackupFixBuilder converts backup fixes to searchable text.
type BackupFixBuilder struct{}

func (b *BackupFixBuilder) Entity() string {
	return "backup_fix"
}

func (b *BackupFixBuilder) Build(ctx context.Context, entityID string) (string, string, error) {
	query := `
		SELECT id, title, description, commit_hash, author, created_at
		FROM backup_fixes
		WHERE id = $1
		LIMIT 1
	`
	
	var id int64
	var title, description, commitHash, author string
	var createdAt time.Time
	
	err := db.Pool.QueryRow(ctx, query, entityID).Scan(&id, &title, &description, &commitHash, &author, &createdAt)
	if err != nil {
		return "", "", fmt.Errorf("query backup fix: %w", err)
	}
	
	content := fmt.Sprintf("Title: %s\n\nDescription: %s\n\nAuthor: %s\n\nCommit: %s\n\nCreated: %s",
		title, description, author, commitHash, createdAt.Format(time.RFC3339))
	
	return strings.TrimSpace(title), content, nil
}

// ExecutionLogBuilder converts execution logs to searchable text.
type ExecutionLogBuilder struct{}

func (b *ExecutionLogBuilder) Entity() string {
	return "execution_log"
}

func (b *ExecutionLogBuilder) Build(ctx context.Context, entityID string) (string, string, error) {
	query := `
		SELECT id, level, message, repository, created_at
		FROM execution_logs
		WHERE id = $1
		LIMIT 1
	`
	
	var id int64
	var level, message, repository string
	var createdAt time.Time
	
	err := db.Pool.QueryRow(ctx, query, entityID).Scan(&id, &level, &message, &repository, &createdAt)
	if err != nil {
		return "", "", fmt.Errorf("query execution log: %w", err)
	}
	
	title := fmt.Sprintf("[%s] %s", level, repository)
	content := fmt.Sprintf("Level: %s\nRepository: %s\nMessage: %s\nTime: %s",
		level, repository, message, createdAt.Format(time.RFC3339))
	
	return title, content, nil
}

// AnalyticsSnapshotBuilder converts analytics snapshots to searchable text.
type AnalyticsSnapshotBuilder struct{}

func (b *AnalyticsSnapshotBuilder) Entity() string {
	return "analytics_snapshot"
}

func (b *AnalyticsSnapshotBuilder) Build(ctx context.Context, entityID string) (string, string, error) {
	query := `
		SELECT id, head_commit_message, total_commits, branch_count, tag_count, 
		       tracked_files, total_blob_size_bytes, total_archive_size_bytes, captured_at
		FROM analytics_snapshots
		WHERE id = $1
		LIMIT 1
	`
	
	var id int64
	var headCommitMsg string
	var totalCommits, branchCount, tagCount, trackedFiles int
	var totalBlobBytes, totalArchiveBytes int64
	var capturedAt time.Time
	
	err := db.Pool.QueryRow(ctx, query, entityID).Scan(
		&id, &headCommitMsg, &totalCommits, &branchCount, &tagCount, 
		&trackedFiles, &totalBlobBytes, &totalArchiveBytes, &capturedAt)
	if err != nil {
		return "", "", fmt.Errorf("query analytics snapshot: %w", err)
	}
	
	title := fmt.Sprintf("Analytics: %s", capturedAt.Format("2006-01-02"))
	content := fmt.Sprintf(
		"Snapshot captured: %s\n\nHead Commit: %s\n\nMetrics:\n"+
		"  Total Commits: %d\n  Branches: %d\n  Tags: %d\n  Tracked Files: %d\n"+
		"  Total Blob Size: %d bytes\n  Total Archive Size: %d bytes",
		capturedAt.Format(time.RFC3339), headCommitMsg, totalCommits, branchCount, 
		tagCount, trackedFiles, totalBlobBytes, totalArchiveBytes)
	
	return title, content, nil
}

// BackupRunBuilder converts backup runs to searchable text.
type BackupRunBuilder struct{}

func (b *BackupRunBuilder) Entity() string {
	return "backup_run"
}

func (b *BackupRunBuilder) Build(ctx context.Context, entityID string) (string, string, error) {
	query := `
		SELECT id, status, total_repos, successful, failed, skipped, duration_ms, 
		       error_message, started_at
		FROM backup_runs
		WHERE id = $1
		LIMIT 1
	`
	
	var id int64
	var status, errorMsg string
	var totalRepos, successful, failed, skipped int
	var durationMs int64
	var startedAt time.Time
	
	err := db.Pool.QueryRow(ctx, query, entityID).Scan(
		&id, &status, &totalRepos, &successful, &failed, &skipped, &durationMs, &errorMsg, &startedAt)
	if err != nil {
		return "", "", fmt.Errorf("query backup run: %w", err)
	}
	
	title := fmt.Sprintf("Backup Run %d: %s", id, status)
	errInfo := ""
	if errorMsg != "" {
		errInfo = fmt.Sprintf("\n\nError: %s", errorMsg)
	}
	
	content := fmt.Sprintf(
		"Run ID: %d\nStatus: %s\nStarted: %s\nDuration: %d ms\n\nResults:\n"+
		"  Total Repos: %d\n  Successful: %d\n  Failed: %d\n  Skipped: %d%s",
		id, status, startedAt.Format(time.RFC3339), durationMs, 
		totalRepos, successful, failed, skipped, errInfo)
	
	return title, content, nil
}

// NewEntityBuilders creates all standard entity builders.
func NewEntityBuilders() map[string]EntityBuilder {
	return map[string]EntityBuilder{
		"investigation":      &InvestigationBuilder{},
		"backup_fix":         &BackupFixBuilder{},
		"execution_log":      &ExecutionLogBuilder{},
		"analytics_snapshot": &AnalyticsSnapshotBuilder{},
		"backup_run":         &BackupRunBuilder{},
	}
}
