package embedding

import (
	"context"
	"fmt"
	"log/slog"
	"strings"
	"time"

	"github.com/MishraShardendu22/github-backup/backend/service/provider"
)

// EmbeddingGenerator handles embedding generation with retry and rate-limit handling.
type EmbeddingGenerator struct {
	provider         provider.EmbeddingProvider
	maxRetries       int
	initialBackoff   time.Duration
	maxBackoff       time.Duration
	logger           *slog.Logger
}

// NewEmbeddingGenerator creates a new embedding generator.
func NewEmbeddingGenerator(embeddingProvider provider.EmbeddingProvider, logger *slog.Logger) *EmbeddingGenerator {
	if logger == nil {
		logger = slog.Default()
	}
	return &EmbeddingGenerator{
		provider:         embeddingProvider,
		maxRetries:       3,
		initialBackoff:   1 * time.Second,
		maxBackoff:       30 * time.Second,
		logger:           logger,
	}
}

// GenerateEmbeddings generates embeddings for texts with retry logic.
// FIXED: Added retry logging (MEDIUM issue fix)
func (eg *EmbeddingGenerator) GenerateEmbeddings(
	ctx context.Context,
	model string,
	texts []string,
) ([][]float32, error) {
	if len(texts) == 0 {
		return nil, fmt.Errorf("no texts to embed")
	}

	backoff := eg.initialBackoff
	var lastErr error

	for attempt := 0; attempt <= eg.maxRetries; attempt++ {
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		default:
		}

		// Call provider with current API key (handles rotation internally)
		embeddings, err := eg.provider.GenerateEmbeddings(ctx, model, texts)
		if err == nil {
			if attempt > 0 {
				eg.logger.InfoContext(ctx, "embedding generation succeeded after retries",
					"model", model, "attempt", attempt+1, "text_count", len(texts))
			}
			return embeddings, nil
		}

		lastErr = err

		// Check if error is rate-limit (429)
		if strings.Contains(err.Error(), "429") || strings.Contains(err.Error(), "rate limit") {
			if attempt < eg.maxRetries {
				// Rate limited - log and retry (provider rotates API key)
				eg.logger.WarnContext(ctx, "rate limited, retrying",
					"attempt", attempt+1,
					"maxRetries", eg.maxRetries,
					"backoff_ms", backoff.Milliseconds(),
					"model", model)

				select {
				case <-time.After(backoff):
					backoff = time.Duration(float64(backoff) * 2)
					if backoff > eg.maxBackoff {
						backoff = eg.maxBackoff
					}
					continue
				case <-ctx.Done():
					return nil, ctx.Err()
				}
			}
		}

		// For other errors, don't retry - just fail
		eg.logger.ErrorContext(ctx, "embedding generation failed (not retrying)", 
			"model", model, "error", err)
		return nil, err
	}

	return nil, fmt.Errorf("embedding generation failed after %d retries: %w", eg.maxRetries, lastErr)
}

// BatchGenerateEmbeddings generates embeddings in batches to avoid rate limits.
// FIXED: Improved batch handling to preserve partial results on failure
func (eg *EmbeddingGenerator) BatchGenerateEmbeddings(
	ctx context.Context,
	model string,
	texts []string,
	batchSize int,
) ([][]float32, error) {
	if batchSize <= 0 {
		batchSize = 25 // Default batch size
	}

	allEmbeddings := make([][]float32, 0, len(texts))

	for i := 0; i < len(texts); i += batchSize {
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		default:
		}

		end := i + batchSize
		if end > len(texts) {
			end = len(texts)
		}

		batchNum := i / batchSize
		batch := texts[i:end]

		eg.logger.DebugContext(ctx, "generating batch",
			"model", model, "batch", batchNum+1, "batch_size", len(batch))

		embeddings, err := eg.GenerateEmbeddings(ctx, model, batch)
		if err != nil {
			// Log batch failure with position info
			eg.logger.ErrorContext(ctx, "batch embedding failed",
				"batch", batchNum, "batch_start", i, "batch_end", end,
				"previous_batches", batchNum, "error", err)

			// Return partial results instead of losing all progress
			// Caller can decide to retry, skip, or handle
			return allEmbeddings, fmt.Errorf("batch %d: %w", batchNum, err)
		}

		allEmbeddings = append(allEmbeddings, embeddings...)

		// Small delay between batches to avoid rate limits
		if i+batchSize < len(texts) {
			select {
			case <-time.After(100 * time.Millisecond):
			case <-ctx.Done():
				return nil, ctx.Err()
			}
		}
	}

	eg.logger.InfoContext(ctx, "batch generation complete",
		"model", model, "total_texts", len(texts), "total_embeddings", len(allEmbeddings))

	return allEmbeddings, nil
}
