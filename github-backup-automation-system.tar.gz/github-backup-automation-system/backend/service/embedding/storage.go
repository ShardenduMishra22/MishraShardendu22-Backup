package embedding

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/pgvector/pgvector-go"
)

// StorageService handles transactional storage of embeddings.
type StorageService struct {
	pool *pgxpool.Pool
}

// NewStorageService creates a new storage service.
func NewStorageService(pool *pgxpool.Pool) *StorageService {
	return &StorageService{pool: pool}
}

// StoreEmbedding stores a single embedding with metadata in the specified version.
// Must be called within a transaction.
func (ss *StorageService) StoreEmbedding(
	ctx context.Context,
	tx interface{}, // pgx.Tx
	entityType string,
	entityID string,
	chunkIndex int,
	chunkText string,
	chunkHash string,
	version int,
	embedding []float32,
) error {
	if len(embedding) == 0 {
		return fmt.Errorf("empty embedding")
	}

	// Convert []float32 to pgvector.Vector
	vec := pgvector.NewVector(embedding)

	query := `
		INSERT INTO content_embeddings 
		(entity_type, entity_id, chunk_index, chunk_text, chunk_hash, embedding_version, embedding, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())
		ON CONFLICT (entity_type, entity_id, chunk_index, embedding_version) DO UPDATE SET
		  chunk_text = $4, chunk_hash = $5, embedding = $7, updated_at = NOW()
	`

	// Execute on transaction
	if pgxTx, ok := tx.(interface {
		Exec(context.Context, string, ...interface{}) error
	}); ok {
		err := pgxTx.Exec(ctx, query, entityType, entityID, chunkIndex, chunkText, chunkHash, version, vec)
		return err
	}

	// Fallback to pool
	_, err := ss.pool.Exec(ctx, query, entityType, entityID, chunkIndex, chunkText, chunkHash, version, vec)
	return err
}

// DeleteEmbeddingsForEntity deletes all embeddings for an entity.
// Used during rebuilds to prepare for new embeddings.
func (ss *StorageService) DeleteEmbeddingsForEntity(
	ctx context.Context,
	tx interface{},
	entityType string,
	entityID string,
) (int64, error) {
	query := `
		DELETE FROM content_embeddings
		WHERE entity_type = $1 AND entity_id = $2
	`

	if pgxTx, ok := tx.(interface {
		Exec(context.Context, string, ...interface{}) error
	}); ok {
		err := pgxTx.Exec(ctx, query, entityType, entityID)
		if err != nil {
			return 0, err
		}
		// pgx doesn't return rows affected, return 1 to indicate deletion
		return 1, nil
	}

	_, err := ss.pool.Exec(ctx, query, entityType, entityID)
	if err != nil {
		return 0, err
	}
	return 1, nil
}

// ClearAllEmbeddings deletes all embeddings (for full rebuild).
func (ss *StorageService) ClearAllEmbeddings(ctx context.Context) error {
	_, err := ss.pool.Exec(ctx, "TRUNCATE TABLE content_embeddings")
	return err
}

// GetEmbeddingCount returns total number of embeddings.
func (ss *StorageService) GetEmbeddingCount(ctx context.Context) (int, error) {
	var count int
	err := ss.pool.QueryRow(ctx, "SELECT COUNT(*) FROM content_embeddings").Scan(&count)
	return count, err
}

// GetEntityChunkCount returns number of chunks for an entity in the active version.
func (ss *StorageService) GetEntityChunkCount(
	ctx context.Context,
	entityType string,
	entityID string,
) (int, error) {
	var count int
	err := ss.pool.QueryRow(ctx, `
		SELECT COUNT(*) FROM content_embeddings
		WHERE entity_type = $1 AND entity_id = $2 AND embedding_version = 
		  (SELECT active_version FROM embedding_config WHERE id = 1)
	`, entityType, entityID).Scan(&count)
	return count, err
}

// CheckChunkDeduplication checks if a chunk with the same hash already exists.
// FIXED: Implements chunk deduplication to prevent duplicate storage
func (ss *StorageService) CheckChunkDeduplication(
	ctx context.Context,
	chunkHash string,
) (bool, error) {
	var exists bool
	err := ss.pool.QueryRow(ctx, `
		SELECT EXISTS(
			SELECT 1 FROM content_embeddings
			WHERE chunk_hash = $1
		)
	`, chunkHash).Scan(&exists)
	return exists, err
}

// TransactionalStore executes a function within a database transaction.
// Ensures atomicity: either all embeddings are stored or none.
func (ss *StorageService) TransactionalStore(
	ctx context.Context,
	fn func(context.Context, interface{}) error,
) error {
	tx, err := ss.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin transaction: %w", err)
	}
	defer tx.Rollback(ctx)

	if err := fn(ctx, tx); err != nil {
		return err
	}

	if err := tx.Commit(ctx); err != nil {
		return fmt.Errorf("commit transaction: %w", err)
	}

	return nil
}
