package embedding

import (
	"context"
	"fmt"
	"log/slog"
	"sync"

	"github.com/MishraShardendu22/github-backup/backend/db"
	"github.com/MishraShardendu22/github-backup/backend/models"
	"github.com/jackc/pgx/v5/pgxpool"
)

// Service orchestrates the embedding generation pipeline.
// Responsibilities:
// - Load active configuration
// - Enumerate embeddable entities
// - Chunk content
// - Generate embeddings
// - Persist metadata and vectors
// - Track job progress
// - Support cancellation
type Service struct {
	mu               sync.Mutex
	currentJob       *models.EmbeddingJob
	cancelFn         context.CancelFunc
	entityBuilders   map[string]EntityBuilder
	chunkingService  *ChunkingService
	embeddingGen     *EmbeddingGenerator
	storageService   *StorageService
	logger           *slog.Logger
	pool             *pgxpool.Pool
}

// EntityBuilder converts database objects to searchable text.
type EntityBuilder interface {
	// Entity returns the entity type this builder handles.
	Entity() string

	// Build converts a database record to searchable text.
	// Returns the title and full content.
	Build(ctx context.Context, entityID string) (string, string, error)
}

// ChunkingRegistry provides entity-specific chunking strategies.
type ChunkingRegistry interface {
	GetStrategy(entityType string) string // "semantic", "fixed", "markdown", "none"
	GetChunkSize(entityType string) int
	GetChunkOverlap(entityType string) int
}

// NewService creates a new embedding service.
func NewService(
	pool *pgxpool.Pool,
	chunkingService *ChunkingService,
	embeddingGen *EmbeddingGenerator,
	storageService *StorageService,
	logger *slog.Logger,
) *Service {
	return &Service{
		pool:              pool,
		entityBuilders:    make(map[string]EntityBuilder),
		chunkingService:   chunkingService,
		embeddingGen:      embeddingGen,
		storageService:    storageService,
		logger:            logger,
	}
}

// RegisterBuilder registers an entity builder.
func (s *Service) RegisterBuilder(builder EntityBuilder) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.entityBuilders[builder.Entity()] = builder
}

// StartRebuild begins a new embedding rebuild job.
// Returns job ID or error if another job is already running.
// FIXED: Extended lock scope to cover entire initialization (race condition fix)
// FIXED: Properly handle error cleanup (context leak fix)
func (s *Service) StartRebuild(ctx context.Context) (int64, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	// Check if job already running
	if s.currentJob != nil && s.currentJob.Status == "processing" {
		return 0, fmt.Errorf("embedding job already in progress: %d", s.currentJob.ID)
	}

	// Create job in database
	jobID, err := db.CreateEmbeddingJob(ctx)
	if err != nil {
		return 0, fmt.Errorf("create job: %w", err)
	}

	// Update job status to processing
	if err := db.UpdateEmbeddingJob(ctx, jobID, "processing", 0, 0, 0, 0, nil); err != nil {
		return 0, fmt.Errorf("update job status: %w", err)
	}

	// Create new version for this rebuild
	version, err := db.CreateNewEmbeddingVersion(ctx)
	if err != nil {
		return 0, fmt.Errorf("create new version: %w", err)
	}

	// Create cancellable context
	rebuildCtx, cancel := context.WithCancel(ctx)

	// Update embedding config to reindexing status
	if err := db.SetEmbeddingStatus(ctx, "reindexing", nil); err != nil {
		cancel() // FIX: Cancel context before returning error (context leak fix)
		return 0, fmt.Errorf("set config status: %w", err)
	}

	s.currentJob = &models.EmbeddingJob{
		ID:     jobID,
		Status: "processing",
	}
	s.cancelFn = cancel

	// Run rebuild in background
	go s.rebuildLoop(rebuildCtx, jobID, version)

	return jobID, nil
}

// CancelJob cancels the current rebuild job.
func (s *Service) CancelJob(ctx context.Context) error {
	s.mu.Lock()
	if s.currentJob == nil {
		s.mu.Unlock()
		return fmt.Errorf("no job running")
	}
	if s.cancelFn != nil {
		s.cancelFn()
	}
	s.mu.Unlock()
	return nil
}

// GetJob retrieves a job by ID.
func (s *Service) GetJob(ctx context.Context, jobID int64) (*models.EmbeddingJob, error) {
	// Query job from database
	// For now, return from current job if it matches
	s.mu.Lock()
	if s.currentJob != nil && s.currentJob.ID == jobID {
		defer s.mu.Unlock()
		return s.currentJob, nil
	}
	s.mu.Unlock()

	// TODO: Query from database for historical jobs
	return nil, fmt.Errorf("job not found")
}

// LatestJob returns the most recent job.
func (s *Service) LatestJob(ctx context.Context) (*models.EmbeddingJob, error) {
	job, err := db.GetLastEmbeddingJob(ctx)
	if err != nil {
		return nil, fmt.Errorf("get last job: %w", err)
	}
	return job, nil
}

// Progress returns current job progress.
func (s *Service) Progress(ctx context.Context) (map[string]interface{}, error) {
	s.mu.Lock()
	if s.currentJob == nil {
		s.mu.Unlock()
		return nil, fmt.Errorf("no job running")
	}
	job := s.currentJob
	s.mu.Unlock()

	return map[string]interface{}{
		"job_id":             job.ID,
		"status":             job.Status,
		"started_at":         job.StartedAt,
		"total_entities":     job.TotalEntities,
		"processed_entities": job.ProcessedEntities,
		"total_chunks":       job.TotalChunks,
		"processed_chunks":   job.ProcessedChunks,
		"failed_chunks":      job.FailedChunks,
	}, nil
}

// rebuildLoop runs the rebuild process.
// FIXED: Uses version-based approach for atomic activation (partial rebuild state consistency fix)
func (s *Service) rebuildLoop(ctx context.Context, jobID int64, version int) {
	defer func() {
		s.mu.Lock()
		s.currentJob = nil
		s.cancelFn = nil
		s.mu.Unlock()
		// Cleanup old versions after successful rebuild
		if err := db.CleanupOldEmbeddingVersions(ctx); err != nil {
			s.logger.WarnContext(ctx, "failed to cleanup old versions", "error", err)
		}
	}()

	s.logger.InfoContext(ctx, "starting rebuild", "job_id", jobID, "version", version)

	config, err := db.GetEmbeddingConfig(ctx)
	if err != nil {
		s.handleJobError(ctx, jobID, fmt.Sprintf("get config: %v", err))
		return
	}

	totalChunks := 0
	processedChunks := 0
	failedChunks := 0
	totalEntities := 0
	processedEntities := 0

	// Process each entity type
	for entityType, builder := range s.entityBuilders {
		select {
		case <-ctx.Done():
			s.handleJobError(ctx, jobID, "cancelled by user")
			return
		default:
		}

		s.logger.InfoContext(ctx, "processing entity type", "type", entityType, "version", version)

		// Get all entity IDs for this type
		entityIDs, err := s.getEntityIDsForType(ctx, entityType)
		if err != nil {
			s.logger.ErrorContext(ctx, "failed to get entity ids", "type", entityType, "error", err)
			continue
		}

		totalEntities += len(entityIDs)

		// Process each entity
		for _, entityID := range entityIDs {
			select {
			case <-ctx.Done():
				s.handleJobError(ctx, jobID, "cancelled by user")
				return
			default:
			}

			// Build content
			title, content, err := builder.Build(ctx, entityID)
			if err != nil {
				s.logger.WarnContext(ctx, "failed to build content", "type", entityType, "id", entityID, "error", err)
				failedChunks++
				continue
			}

			// Chunk content
			chunks, err := s.chunkingService.ChunkContent(entityType, title, content)
			if err != nil {
				s.logger.WarnContext(ctx, "failed to chunk content", "type", entityType, "id", entityID, "error", err)
				failedChunks++
				continue
			}

			if len(chunks) == 0 {
				processedEntities++
				continue
			}

			// Prepare texts for embedding
			texts := make([]string, len(chunks))
			for i, chunk := range chunks {
				texts[i] = chunk.Text
			}

			// Generate embeddings with retry logic
			embeddings, err := s.embeddingGen.BatchGenerateEmbeddings(ctx, config.EmbeddingModel, texts, 25)
			if err != nil {
				s.logger.WarnContext(ctx, "failed to generate embeddings", "type", entityType, "id", entityID, "error", err)
				failedChunks += len(chunks)
				continue
			}

			// Store embeddings transactionally with version
			err = s.storageService.TransactionalStore(ctx, func(txCtx context.Context, tx interface{}) error {
				for i, chunk := range chunks {
					if i >= len(embeddings) {
						break
					}

					if err := s.storageService.StoreEmbedding(
						txCtx, tx,
						entityType, entityID, chunk.Index,
						chunk.Text, chunk.Hash, version, embeddings[i],
					); err != nil {
						return fmt.Errorf("store embedding: %w", err)
					}
				}
				return nil
			})

			if err != nil {
				s.logger.WarnContext(ctx, "failed to store embeddings", "type", entityType, "id", entityID, "error", err)
				failedChunks += len(chunks)
				continue
			}

			totalChunks += len(chunks)
			processedChunks += len(chunks)
			processedEntities++

			// Update progress every 10 entities
			if processedEntities%10 == 0 {
				if err := db.UpdateEmbeddingJob(ctx, jobID, "processing", processedEntities, totalEntities, processedChunks, failedChunks, nil); err != nil {
					s.logger.WarnContext(ctx, "failed to update job", "error", err)
				}
			}
		}
	}

	// Final progress update
	if err := db.UpdateEmbeddingJob(ctx, jobID, "processing", processedEntities, totalEntities, processedChunks, failedChunks, nil); err != nil {
		s.logger.WarnContext(ctx, "failed to update job", "error", err)
	}

	// Validate rebuild success - only activate if we processed at least some entities
	if processedChunks == 0 && totalEntities > 0 {
		errMsg := "rebuild produced no embeddings despite entities found"
		s.logger.ErrorContext(ctx, errMsg)
		s.handleJobError(ctx, jobID, errMsg)
		return
	}

	// Mark job complete
	if err := db.CompleteEmbeddingJob(ctx, jobID); err != nil {
		s.handleJobError(ctx, jobID, fmt.Sprintf("complete job: %v", err))
		return
	}

	// Activate the new version (atomic operation - only now is it visible to searches)
	if err := db.ActivateEmbeddingVersion(ctx, version); err != nil {
		s.handleJobError(ctx, jobID, fmt.Sprintf("activate version: %v", err))
		return
	}

	s.logger.InfoContext(ctx, "rebuild complete and activated",
		"job_id", jobID,
		"version", version,
		"total_entities", totalEntities,
		"processed_entities", processedEntities,
		"total_chunks", totalChunks,
		"processed_chunks", processedChunks,
		"failed_chunks", failedChunks)
}

// getEntityIDsForType returns all entity IDs for a given type.
// REFACTORED: Extract duplication by creating generic query method
func (s *Service) getEntityIDsForType(ctx context.Context, entityType string) ([]string, error) {
	// Map entity type to table name
	tableMap := map[string]string{
		"investigation":      "investigations",
		"backup_fix":         "backup_fixes",
		"execution_log":      "execution_logs",
		"analytics_snapshot": "analytics_snapshots",
		"backup_run":         "backup_runs",
	}

	table, ok := tableMap[entityType]
	if !ok {
		return nil, fmt.Errorf("unknown entity type: %s", entityType)
	}

	// Single generic query instead of 5 switch cases
	query := fmt.Sprintf("SELECT id FROM %s ORDER BY id", table)
	rows, err := s.pool.Query(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("query entity ids: %w", err)
	}
	defer rows.Close()

	var ids []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, fmt.Errorf("scan id: %w", err)
		}
		ids = append(ids, id)
	}

	return ids, rows.Err()
}

// handleJobError marks job as failed with error message and resets config status.
func (s *Service) handleJobError(ctx context.Context, jobID int64, errMsg string) {
	s.logger.ErrorContext(ctx, "job error", "job_id", jobID, "error", errMsg)

	// Set job status to failed
	if err := db.UpdateEmbeddingJob(ctx, jobID, "failed", 0, 0, 0, 0, &errMsg); err != nil {
		s.logger.WarnContext(ctx, "failed to update job status", "error", err)
	}

	// Reset config status back to ready instead of failed to allow retry
	if err := db.SetEmbeddingStatus(ctx, "ready", &errMsg); err != nil {
		s.logger.WarnContext(ctx, "failed to reset config status", "error", err)
	}
}
