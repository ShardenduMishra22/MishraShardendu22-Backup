package provider

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"strings"
	"time"
)

const (
	OpenRouterBaseURL        = "https://openrouter.ai/api/v1"
	OpenRouterModelsEndpoint = "/models"
	OpenRouterEmbedEndpoint  = "/embeddings"
	OpenRouterRankEndpoint   = "/rank"
)

// OpenRouterProvider implements EmbeddingProvider and RerankProvider for OpenRouter.
type OpenRouterProvider struct {
	apiKeys        []string
	keyIndex       int
	httpClient     *http.Client
	timeout        time.Duration
	maxRetries     int
	initialBackoff time.Duration
	maxBackoff     time.Duration
	logger         *slog.Logger
}

// NewOpenRouterProvider creates a new OpenRouter provider.
// apiKeyStr can be a single key or comma-separated keys for rotation.
func NewOpenRouterProvider(apiKeyStr string, logger *slog.Logger) (*OpenRouterProvider, error) {
	if logger == nil {
		logger = slog.Default()
	}

	// Parse comma-separated API keys
	keys := strings.Split(strings.TrimSpace(apiKeyStr), ",")
	var cleanKeys []string
	for _, k := range keys {
		trimmed := strings.TrimSpace(k)
		if trimmed != "" {
			cleanKeys = append(cleanKeys, trimmed)
		}
	}

	if len(cleanKeys) == 0 {
		return nil, fmt.Errorf("no valid API keys provided")
	}

	return &OpenRouterProvider{
		apiKeys:        cleanKeys,
		keyIndex:       0,
		httpClient:     &http.Client{Timeout: 30 * time.Second},
		timeout:        30 * time.Second,
		maxRetries:     3,
		initialBackoff: 1 * time.Second,
		maxBackoff:     30 * time.Second,
		logger:         logger,
	}, nil
}

// Name returns the provider name.
func (p *OpenRouterProvider) Name() string {
	return "openrouter"
}

// getNextAPIKey rotates to the next API key.
func (p *OpenRouterProvider) getNextAPIKey() string {
	if len(p.apiKeys) == 0 {
		return ""
	}
	key := p.apiKeys[p.keyIndex]
	p.keyIndex = (p.keyIndex + 1) % len(p.apiKeys)
	return key
}

// GenerateEmbeddings generates embeddings for texts with automatic retry and key rotation.
func (p *OpenRouterProvider) GenerateEmbeddings(ctx context.Context, model string, texts []string) ([][]float32, error) {
	if len(texts) == 0 {
		return nil, fmt.Errorf("no texts provided")
	}

	// Convert to embedding request
	req := map[string]interface{}{
		"model": model,
		"input": texts,
	}

	body, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("marshal request: %w", err)
	}

	var lastErr error
	backoff := p.initialBackoff

	for attempt := 0; attempt <= p.maxRetries; attempt++ {
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		default:
		}

		if attempt > 0 {
			p.logger.DebugContext(ctx, "retry embedding request", "attempt", attempt, "backoff_ms", backoff.Milliseconds())
			select {
			case <-time.After(backoff):
				backoff = time.Duration(float64(backoff) * 2)
				if backoff > p.maxBackoff {
					backoff = p.maxBackoff
				}
			case <-ctx.Done():
				return nil, ctx.Err()
			}
		}

		httpReq, err := http.NewRequestWithContext(ctx, "POST", OpenRouterBaseURL+OpenRouterEmbedEndpoint, bytes.NewReader(body))
		if err != nil {
			lastErr = err
			continue
		}

		httpReq.Header.Set("Authorization", "Bearer "+p.getNextAPIKey())
		httpReq.Header.Set("User-Agent", "GitHub-Backup-Observatory/1.0")
		httpReq.Header.Set("Content-Type", "application/json")

		resp, err := p.httpClient.Do(httpReq)
		if err != nil {
			lastErr = fmt.Errorf("request failed: %w", err)
			p.logger.DebugContext(ctx, "embedding request error", "attempt", attempt, "error", lastErr)
			continue
		}

		statusCode := resp.StatusCode
		respBody, _ := io.ReadAll(resp.Body)
		resp.Body.Close()

		// Handle rate limiting with retry
		if statusCode == http.StatusTooManyRequests {
			lastErr = fmt.Errorf("rate limited (429)")
			p.logger.InfoContext(ctx, "rate limited, will retry", "attempt", attempt)
			continue
		}

		// Non-retry errors
		if statusCode != http.StatusOK {
			return nil, fmt.Errorf("api error %d: %s", statusCode, string(respBody))
		}

		// Parse successful response
		var embResp struct {
			Data []struct {
				Embedding []float32 `json:"embedding"`
				Index     int       `json:"index"`
			} `json:"data"`
		}

		if err := json.Unmarshal(respBody, &embResp); err != nil {
			return nil, fmt.Errorf("decode response: %w", err)
		}

		// Convert to embeddings slice
		embeddings := make([][]float32, len(embResp.Data))
		for _, e := range embResp.Data {
			embeddings[e.Index] = e.Embedding
		}

		p.logger.DebugContext(ctx, "embeddings generated", "count", len(embeddings))
		return embeddings, nil
	}

	return nil, fmt.Errorf("embedding generation failed after %d retries: %w", p.maxRetries, lastErr)
}

// Rerank reorders candidates based on relevance to the query.
func (p *OpenRouterProvider) Rerank(ctx context.Context, model string, query string, candidates []string) ([]int, error) {
	if len(candidates) == 0 {
		return nil, fmt.Errorf("no candidates provided")
	}

	req := map[string]interface{}{
		"model":      model,
		"query":      query,
		"documents": candidates,
	}

	body, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("marshal request: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx, "POST", OpenRouterBaseURL+OpenRouterRankEndpoint, bytes.NewReader(body))
	if err != nil {
		return nil, fmt.Errorf("create request: %w", err)
	}

	httpReq.Header.Set("Authorization", "Bearer "+p.getNextAPIKey())
	httpReq.Header.Set("User-Agent", "GitHub-Backup-Observatory/1.0")
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := p.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		respBody, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("api error %d: %s", resp.StatusCode, string(respBody))
	}

	var rankResp struct {
		Results []struct {
			Index  int     `json:"index"`
			Score  float32 `json:"score"`
		} `json:"results"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&rankResp); err != nil {
		return nil, fmt.Errorf("decode response: %w", err)
	}

	// Extract indices in ranked order
	indices := make([]int, len(rankResp.Results))
	for i, r := range rankResp.Results {
		indices[i] = r.Index
	}

	p.logger.DebugContext(ctx, "reranking completed", "count", len(indices))
	return indices, nil
}

// IsAvailable checks if the OpenRouter API is accessible.
func (p *OpenRouterProvider) IsAvailable(ctx context.Context) bool {
	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()

	httpReq, err := http.NewRequestWithContext(ctx, "GET", OpenRouterBaseURL+OpenRouterModelsEndpoint, nil)
	if err != nil {
		return false
	}

	httpReq.Header.Set("Authorization", "Bearer "+p.getNextAPIKey())
	httpReq.Header.Set("User-Agent", "GitHub-Backup-Observatory/1.0")

	resp, err := p.httpClient.Do(httpReq)
	if err != nil {
		return false
	}
	resp.Body.Close()

	return resp.StatusCode == http.StatusOK
}

// GetEmbeddingModels returns models that support embeddings.
func (p *OpenRouterProvider) GetEmbeddingModels(ctx context.Context) ([]Model, error) {
	models, err := p.GetAllModels(ctx)
	if err != nil {
		return nil, err
	}

	var embeddingModels []Model
	for _, model := range models {
		// Check for text embedding capability
		hasText := false
		for _, mod := range model.Architecture.OutputModalities {
			if mod == "text" {
				hasText = true
				break
			}
		}

		if !hasText {
			continue
		}

		// Skip paid models
		if model.Pricing.Prompt != "0" && model.Pricing.Prompt != "" {
			continue
		}
		if model.Pricing.Completion != "0" && model.Pricing.Completion != "" {
			continue
		}

		embeddingModels = append(embeddingModels, model)
	}

	p.logger.DebugContext(ctx, "embedding models retrieved", "count", len(embeddingModels))
	return embeddingModels, nil
}

// GetRerankerModels returns models that support reranking.
func (p *OpenRouterProvider) GetRerankerModels(ctx context.Context) ([]Model, error) {
	models, err := p.GetAllModels(ctx)
	if err != nil {
		return nil, err
	}

	var rerankerModels []Model
	for _, model := range models {
		// Check for reranking capability
		hasReranking := false
		for _, cap := range model.Capabilities {
			if cap == "ranking" || strings.Contains(cap, "rerank") {
				hasReranking = true
				break
			}
		}

		if !hasReranking {
			continue
		}

		// Skip paid models
		if model.Pricing.Prompt != "0" && model.Pricing.Prompt != "" {
			continue
		}
		if model.Pricing.Completion != "0" && model.Pricing.Completion != "" {
			continue
		}

		rerankerModels = append(rerankerModels, model)
	}

	p.logger.DebugContext(ctx, "reranker models retrieved", "count", len(rerankerModels))
	return rerankerModels, nil
}

// GetAllModels retrieves all available models from OpenRouter.
func (p *OpenRouterProvider) GetAllModels(ctx context.Context) ([]Model, error) {
	httpReq, err := http.NewRequestWithContext(ctx, "GET", OpenRouterBaseURL+OpenRouterModelsEndpoint, nil)
	if err != nil {
		return nil, fmt.Errorf("create request: %w", err)
	}

	httpReq.Header.Set("Authorization", "Bearer "+p.getNextAPIKey())
	httpReq.Header.Set("User-Agent", "GitHub-Backup-Observatory/1.0")

	resp, err := p.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("api error %d: %s", resp.StatusCode, string(body))
	}

	var modelsResp struct {
		Data []struct {
			ID           string                 `json:"id"`
			Name         string                 `json:"name"`
			Pricing      map[string]interface{} `json:"pricing"`
			Architecture map[string]interface{} `json:"architecture"`
			Capabilities []string               `json:"capabilities"`
			Context      int                    `json:"context_length"`
		} `json:"data"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&modelsResp); err != nil {
		return nil, fmt.Errorf("decode response: %w", err)
	}

	// Convert to provider models
	models := make([]Model, 0, len(modelsResp.Data))
	for _, m := range modelsResp.Data {
		model := Model{
			ID:            m.ID,
			Name:          m.Name,
			Provider:      "openrouter",
			Capabilities:  m.Capabilities,
			ContextLength: m.Context,
		}

		// Extract pricing (already a map)
		if prompt, ok := m.Pricing["prompt"].(string); ok {
			model.Pricing.Prompt = prompt
		}
		if completion, ok := m.Pricing["completion"].(string); ok {
			model.Pricing.Completion = completion
		}

		// Extract architecture (already a map)
		if modalities, ok := m.Architecture["output_modalities"].([]interface{}); ok {
			model.Architecture.OutputModalities = make([]string, 0, len(modalities))
			for _, mod := range modalities {
				if s, ok := mod.(string); ok {
					model.Architecture.OutputModalities = append(model.Architecture.OutputModalities, s)
				}
			}
		}

		models = append(models, model)
	}

	p.logger.DebugContext(ctx, "all models retrieved", "count", len(models))
	return models, nil
}
