package provider

import (
	"fmt"
	"log/slog"
	"os"
)

// Factory design pattern for creating embedding and rerank providers based on configuration.

// ProviderType defines the type of provider to use.
type ProviderType string

const (
	ProviderOpenRouter ProviderType = "openrouter"
	ProviderDefault    ProviderType = ProviderOpenRouter
)

// NewEmbeddingProvider creates a new embedding provider based on configuration.
// Currently supports OpenRouter, but extensible for future providers.
func NewEmbeddingProvider(logger *slog.Logger) (EmbeddingProvider, error) {
	if logger == nil {
		logger = slog.Default()
	}

	// Get API key from environment
	apiKey := os.Getenv("OPENROUTER_API_KEY")
	if apiKey == "" {
		return nil, fmt.Errorf("OPENROUTER_API_KEY environment variable not set")
	}

	// Create OpenRouter provider
	provider, err := NewOpenRouterProvider(apiKey, logger)
	if err != nil {
		return nil, fmt.Errorf("create openrouter provider: %w", err)
	}

	logger.InfoContext(nil, "embedding provider initialized", "provider", "openrouter")
	return provider, nil
}

// NewRerankProvider creates a new rerank provider based on configuration.
// Currently supports OpenRouter, but extensible for future providers.
func NewRerankProvider(logger *slog.Logger) (RerankProvider, error) {
	if logger == nil {
		logger = slog.Default()
	}

	// Get API key from environment
	apiKey := os.Getenv("OPENROUTER_API_KEY")
	if apiKey == "" {
		return nil, fmt.Errorf("OPENROUTER_API_KEY environment variable not set")
	}

	// Create OpenRouter provider (implements both EmbeddingProvider and RerankProvider)
	provider, err := NewOpenRouterProvider(apiKey, logger)
	if err != nil {
		return nil, fmt.Errorf("create openrouter provider: %w", err)
	}

	logger.InfoContext(nil, "rerank provider initialized", "provider", "openrouter")
	return provider, nil
}

// Note: Future providers can be added here:
//
// func NewAzureOpenAIProvider(config AzureConfig, logger *slog.Logger) (EmbeddingProvider, error) { ... }
// func NewJinaProvider(apiKey string, logger *slog.Logger) (EmbeddingProvider, error) { ... }
// func NewVoyageProvider(apiKey string, logger *slog.Logger) (EmbeddingProvider, error) { ... }
// func NewOllamaProvider(endpoint string, logger *slog.Logger) (EmbeddingProvider, error) { ... }
