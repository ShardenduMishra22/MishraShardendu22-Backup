package provider

import "context"

// EmbeddingProvider defines the interface for embedding generation.
type EmbeddingProvider interface {
	// Name returns the provider name (e.g., "openrouter").
	Name() string

	// GenerateEmbeddings generates embeddings for the given texts.
	// Returns a slice of embeddings, one per input text.
	GenerateEmbeddings(ctx context.Context, model string, texts []string) ([][]float32, error)

	// IsAvailable checks if the provider is accessible (health check).
	IsAvailable(ctx context.Context) bool
}

// RerankProvider defines the interface for reranking candidates.
type RerankProvider interface {
	// Name returns the provider name (e.g., "openrouter").
	Name() string

	// Rerank reorders candidates based on relevance to the query.
	// Returns indices in reranked order.
	Rerank(ctx context.Context, model string, query string, candidates []string) ([]int, error)

	// IsAvailable checks if the provider is accessible (health check).
	IsAvailable(ctx context.Context) bool
}

// ModelDiscovery provides access to available models.
type ModelDiscovery interface {
	// GetEmbeddingModels returns available embedding models.
	GetEmbeddingModels(ctx context.Context) ([]Model, error)

	// GetRerankerModels returns available reranker models.
	GetRerankerModels(ctx context.Context) ([]Model, error)

	// GetAllModels returns all available models.
	GetAllModels(ctx context.Context) ([]Model, error)
}

// Model represents an available AI model.
type Model struct {
	ID           string
	Name         string
	Provider     string
	Pricing      ModelPricing
	Architecture ModelArchitecture
	Capabilities []string
	ContextLength int
}

// ModelPricing represents pricing information for a model.
type ModelPricing struct {
	Prompt     string
	Completion string
}

// ModelArchitecture represents architectural details of a model.
type ModelArchitecture struct {
	OutputModalities []string
}
