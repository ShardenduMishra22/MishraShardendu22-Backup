# Embedding System - Quick Reference Guide

## Document Index

| Document | Purpose | Audience |
|---|---|---|
| **EMBEDDING_SUMMARY.md** | Executive summary + decision validation | Architects, leads |
| **EMBEDDING_ARCHITECTURE_VALIDATION.md** | Detailed design review + critique | Architects, reviewers |
| **EMBEDDING_IMPLEMENTATION_PLAN.md** | Phase-by-phase roadmap + checklist | Developers, PMs |
| **002_embedding_schema.sql** | Complete SQL migration | DBAs, backend devs |
| **EMBEDDING_QUICK_REFERENCE.md** | This file - quick lookup | All engineers |

---

## Schema Quick Reference

### Tables (7 total)

```
embedding_config          Single row, active configuration
  ├─ embeddable_entities  Type registry (investigation, fix, etc.)
  ├─ entities             Actual embeddable items
  ├─ embeddings_index     Chunk metadata per entity
  ├─ content_embeddings   Vectors + content
  ├─ chunk_dedupe         Dedup hash map
  └─ vector_searches      Audit log
```

### Common Queries

**Get current config:**
```sql
SELECT * FROM embedding_config WHERE id = 1;
```

**Get all entities of a type:**
```sql
SELECT * FROM entities 
WHERE entity_type = 'investigation' 
ORDER BY created_at DESC;
```

**Get all chunks for an entity:**
```sql
SELECT ei.chunk_index, ei.chunk_count, ce.chunk_content, ce.embedding
FROM embeddings_index ei
JOIN content_embeddings ce ON ei.id = ce.embeddings_index_id
WHERE ei.entity_id = :entity_id
ORDER BY ei.chunk_index ASC;
```

**Vector similarity search:**
```sql
SELECT e.id, e.entity_type, e.external_id, e.display_name,
       1 - (ce.embedding <=> :query_vector) as similarity
FROM content_embeddings ce
JOIN embeddings_index ei ON ce.embeddings_index_id = ei.id
JOIN entities e ON ei.entity_id = e.id
WHERE e.entity_type = :entity_type
ORDER BY similarity DESC
LIMIT :top_k;
```

**Start reindex:**
```sql
UPDATE embedding_config SET 
  reindex_status = 'reindexing',
  reindex_started_at = NOW(),
  reindex_error = NULL
WHERE id = 1;
```

**Complete reindex:**
```sql
UPDATE embedding_config SET 
  reindex_status = 'idle',
  last_reindexed_at = NOW(),
  updated_at = NOW()
WHERE id = 1;
```

**Log search operation:**
```sql
INSERT INTO vector_searches (
  query, entity_type, top_k, reranking_used,
  retrieval_latency_ms, reranking_latency_ms, result_count
) VALUES (:query, :type, :k, :rerank, :ret_ms, :rerank_ms, :count);
```

---

## Chunking Strategy Reference

### By Entity Type

| Type | Size | Overlap | Strategy | Example |
|---|---|---|---|---|
| investigation | 512 tok | 50 | Semantic | Q + A + tools split by sentences |
| backup_fix | 768 tok | 100 | Semantic | Title + code blocks preserved |
| backup_run_summary | 1024 tok | 200 | Semantic | Stats + descriptions |
| analytics_snapshot | 512 tok | 0 | Fixed | Tabular metrics |
| execution_log | 256 tok | 0 | Fixed | Sequential log lines |
| repository_summary | 1024 tok | 150 | Semantic | README + metadata |
| chat_message | full | N/A | None | Single message as one chunk |

### Implementation Notes

- Use **tiktoken** for accurate token counting
- **Semantic chunking**: Split on `\n\n` (paragraphs), then sentences if > chunk_size
- **Fixed chunking**: Split on `\n` (lines), then bytes if > chunk_size
- **Special handling**: Preserve code blocks, markdown headers, JSON structures
- **Deduplication**: SHA256(chunk_text) before embedding
- **Uniqueness**: chunk_content_hash constraint in DB prevents duplicates

---

## API Endpoints (Phase 4-5)

### Admin Configuration

```
GET  /api/admin/embedding-config
     Returns: { provider, model, dimensions, rerank_enabled, rerank_model, status }

GET  /api/admin/embedding-models
     Returns: [ { id, name, dimensions, pricing } ]

GET  /api/admin/reranker-models
     Returns: [ { id, name, pricing } ]

POST /api/admin/config/embedding-model
     Body: { model_id }
     Effect: Updates embedding_config, triggers reindex

POST /api/admin/config/reranker-model
     Body: { model_id }
     Effect: Updates embedding_config, triggers reindex

GET  /api/admin/embedding-stats
     Returns: { total_entities, total_chunks, last_reindex_time, reindex_status }

POST /api/admin/reindex/trigger
     Effect: Sets reindex_status = 'reindexing', starts worker

GET  /api/admin/reindex/status
     Returns: { status, progress_pct, processed, remaining, failed, error }

GET  /api/admin/reindex/errors
     Returns: [ { entity_id, error_message, timestamp } ]
```

### Search

```
POST /api/search/vector
     Body: { query, entity_type?, top_k? }
     Returns: [ { id, type, name, similarity, metadata } ]

GET  /api/search/analytics
     Returns: { total_searches, avg_latency, top_entity_types, last_24h_stats }
```

---

## OpenRouter Integration Quick Notes

### Model Filtering

**Embedding models:**
```
Filter: architecture.output_modalities includes "text"
Filter: pricing.prompt == 0 AND pricing.completion == 0
```

**Reranking models:**
```
Filter: capabilities includes "ranking"
Filter: pricing.prompt == 0 AND pricing.completion == 0
```

### API Key Rotation

```python
# Parse from env
keys = os.getenv("OPENROUTER_API_KEY", "").split(",")

# Rotate per request (round-robin)
current_key = keys[request_count % len(keys)]

# On rate limit (429), move to next key
if status_code == 429:
    skip_key_for_n_minutes(current_key, 5)
    use_next_key()
```

### Batch Embedding

- ✅ Supported: Multiple chunks per request
- ✅ Recommended: Batch up to 20-50 chunks per API call
- ✅ Reduces latency: 1 req for 50 chunks vs 50 separate reqs

---

## Reindex Lifecycle

```
START: reindex_status = 'idle'
  ↓
TRIGGER: User clicks "Trigger Rebuild"
  ↓
UPDATE: reindex_status = 'reindexing', reindex_started_at = NOW()
  ↓
PROCESS: For each entity in entities:
  ├─ Extract content
  ├─ Chunk content
  ├─ Embed chunks
  ├─ Check chunk_dedupe (skip if exists)
  ├─ Insert/update embeddings_index + content_embeddings
  └─ Track progress
  ↓
SUCCESS: reindex_status = 'idle', last_reindexed_at = NOW()
  OR
FAILURE: reindex_status = 'failed', reindex_error = error_msg
  
RETRY: On failure, user can trigger again (idempotent)
```

---

## Dashboard Real-Time Metrics

All values MUST be queried from database. No hardcoding.

```sql
-- Total embedded entities
SELECT COUNT(*) FROM entities;

-- Total chunks
SELECT COUNT(*) FROM embeddings_index;

-- Last reindex time
SELECT last_reindexed_at FROM embedding_config WHERE id = 1;

-- Current reindex status
SELECT reindex_status, reindex_started_at FROM embedding_config WHERE id = 1;

-- Avg search latency (last 24h)
SELECT AVG(retrieval_latency_ms) FROM vector_searches 
WHERE created_at > NOW() - INTERVAL '24 hours';

-- Top entity types (last 24h)
SELECT entity_type, COUNT(*) 
FROM vector_searches 
WHERE created_at > NOW() - INTERVAL '24 hours' 
GROUP BY entity_type 
ORDER BY COUNT DESC;
```

---

## Phase Dependencies

- Phase 1 (Schema) → blocking for all
- Phase 2 (OpenRouter) → can proceed in parallel with Phase 1
- Phase 3 (Chunking) → depends on Phase 1 + 2
- Phase 4 (Retrieval) → depends on Phase 3
- Phase 5 (Dashboard) → depends on Phase 4

**Critical path**: Phase 1 → Phase 3 → Phase 4 → Phase 5

---

## Testing Strategy

```bash
# Phase 1: Schema tests
psql $POSTGRES_URL < backend/db/002_embedding_schema.sql
# Verify tables exist: \dt in psql

# Phase 2: OpenRouter client tests
go test ./backend/openrouter -v

# Phase 3: Full pipeline test
go test ./backend/embedding -v -integration
# Should successfully embed 10 sample investigations

# Phase 4: Search tests
go test ./backend/search -v -integration
# Should return relevant results with correct similarity scores

# Phase 5: Frontend tests
npm test ./frontend/src/components/EmbeddingDashboard
# Should render all sections with real data
```

---

## Common Mistakes to Avoid

❌ **DON'T:**
- Hardcode model lists in code (use OpenRouter API)
- Store vectors in separate database (use pgvector)
- Embed raw logs with PII (aggregate first)
- Allow concurrent reindex operations (use reindex_status lock)
- Skip chunk hashing (enables deduplication savings)
- Ignore reindex errors (log properly for debugging)

✅ **DO:**
- Use chunk_content_hash for deduplication
- Track latencies in vector_searches table
- Enforce singular embedding_config row
- Validate API keys before using
- Implement exponential backoff on rate limits
- Test each phase independently

---

## Performance Targets

| Operation | Target | Notes |
|---|---|---|
| Embedding (per chunk) | 50-100ms | Batched API call |
| Vector search | < 150ms | With ivfflat index |
| Reranking | < 100ms | Per top-k batch |
| Full reindex | < 30 min | For ~1000 entities |
| Dashboard load | < 2s | Cached queries |
| Model discovery | < 5s | With 5-min cache |

---

## Escalation Paths

### If reindex fails
1. Check `reindex_error` in embedding_config
2. Check `execution_logs` for details
3. Verify OpenRouter API is accessible
4. Verify API keys have quota remaining
5. Review chunk extraction for entity type

### If search returns poor results
1. Verify query embedding is correct (debug embedding API call)
2. Check if vector index was properly created (`\d content_embeddings` in psql)
3. Verify entity types are being indexed (`SELECT COUNT(*) FROM entities`)
4. Check if reranking is enabled (may improve results)
5. Review chunk content (may need better chunking strategy)

### If performance degrades
1. Check `vector_searches` table size (may need archival)
2. Run `ANALYZE` on tables (PostgreSQL query planning)
3. Verify ivfflat index is being used (`EXPLAIN ANALYZE` on search query)
4. Check API key rotation is working (latency may spike on rate limit)

---

## Handy SQL Scripts

**Find unused models (if tracked):**
```sql
SELECT model FROM content_embeddings GROUP BY model;
```

**Audit all searches by user (if user_id tracked):**
```sql
SELECT user_id, COUNT(*), AVG(retrieval_latency_ms)
FROM vector_searches 
GROUP BY user_id 
ORDER BY COUNT DESC;
```

**Cleanup old searches (if archival needed):**
```sql
DELETE FROM vector_searches 
WHERE created_at < NOW() - INTERVAL '90 days';
```

**Find duplicate chunks (should be none due to constraint):**
```sql
SELECT chunk_content_hash, COUNT(*) 
FROM content_embeddings 
GROUP BY chunk_content_hash 
HAVING COUNT(*) > 1;
```

---

## Useful Links & References

- **OpenRouter API Docs**: https://openrouter.ai/docs
- **pgvector GitHub**: https://github.com/pgvector/pgvector
- **PostgreSQL Docs**: https://www.postgresql.org/docs/
- **Go pgx driver**: https://github.com/jackc/pgx
- **LangChain Python**: https://python.langchain.com/ (for chunking)

---

**Last updated**: 2026-08-02  
**Status**: Ready for implementation  
**Questions?** Refer to detailed architecture doc or implementation roadmap.
