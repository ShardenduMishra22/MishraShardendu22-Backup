# Embedding System - Implementation Roadmap

---

## PART 8: DATABASE CLEANUP PLAN

### Phase 0: Audit Current Schema

**Current PostgreSQL tables (from backend/db/schema.sql):**
- ✓ backup_runs
- ✓ backup_results
- ✓ execution_logs
- ✓ analytics_snapshots
- ✓ backup_fixes
- ✓ backup_run_fixes

**Current Python/FastAPI tables (from agentic-observatory/data/db.py):**
- ✓ ai_chat_sessions
- ✓ ai_chat_messages
- ✓ ai_tool_calls
- ✓ investigations

**Assessment:**
- No old embedding tables exist (clean slate)
- AI chat infrastructure is separate and should remain
- Backup infrastructure is solid
- No conflicts detected
- No migration cleanup needed

**Action:** Database is clean. Proceed directly to new schema.

---

### Phase 0 SQL Execution Checklist

```sql
-- Step 1: Verify existing tables (run before implementation)
SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename;

-- Step 2: Check for embedding-related tables (should be empty)
SELECT * FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name LIKE '%embed%' 
OR table_name LIKE '%vector%';

-- Step 3: Verify pgvector extension is installed
CREATE EXTENSION IF NOT EXISTS vector;
```

---

## PART 9: FINAL SCHEMA CREATION MIGRATIONS

### Migration File: 001_create_embedding_tables.sql

```sql
-- ============================================================
-- EMBEDDING SYSTEM - TABLE DEFINITIONS
-- Created: 2026-08-02
-- ============================================================

-- 1. Extension: pgvector for embedding storage
CREATE EXTENSION IF NOT EXISTS vector;

-- 2. Single configuration table (singleton)
CREATE TABLE IF NOT EXISTS embedding_config (
    id SERIAL PRIMARY KEY CHECK (id = 1),
    provider TEXT NOT NULL,
    embedding_model TEXT NOT NULL,
    embedding_dimensions INT NOT NULL,
    rerank_enabled BOOLEAN NOT NULL DEFAULT false,
    rerank_model TEXT,
    reindex_status TEXT NOT NULL DEFAULT 'idle' 
        CHECK (reindex_status IN ('idle', 'reindexing', 'failed')),
    reindex_error TEXT,
    reindex_started_at TIMESTAMPTZ,
    last_reindexed_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_embedding_config_singleton ON embedding_config(id);

-- 3. Registry of embeddable entity types
CREATE TABLE IF NOT EXISTS embeddable_entities (
    entity_type TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    is_enabled BOOLEAN NOT NULL DEFAULT true,
    extraction_strategy TEXT NOT NULL 
        CHECK (extraction_strategy IN ('full_text', 'aggregated', 'synthesized')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Denormalized entity registry
CREATE TABLE IF NOT EXISTS entities (
    id BIGSERIAL PRIMARY KEY,
    entity_type TEXT NOT NULL REFERENCES embeddable_entities(entity_type),
    external_id TEXT NOT NULL,
    display_name TEXT NOT NULL,
    source_created_at TIMESTAMPTZ,
    source_updated_at TIMESTAMPTZ,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (entity_type, external_id)
);

CREATE INDEX idx_entities_type ON entities(entity_type);
CREATE INDEX idx_entities_type_id ON entities(entity_type, external_id);
CREATE INDEX idx_entities_created ON entities(created_at DESC);

-- 5. Embedding index (metadata layer)
CREATE TABLE IF NOT EXISTS embeddings_index (
    id BIGSERIAL PRIMARY KEY,
    entity_id BIGINT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    chunk_index INT NOT NULL,
    chunk_count INT NOT NULL,
    chunk_hash TEXT NOT NULL,
    embedding_dimensions INT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (entity_id, chunk_index)
);

CREATE INDEX idx_embeddings_entity ON embeddings_index(entity_id);
CREATE INDEX idx_embeddings_hash ON embeddings_index(chunk_hash);

-- 6. Content embeddings (vectors)
CREATE TABLE IF NOT EXISTS content_embeddings (
    id BIGSERIAL PRIMARY KEY,
    embeddings_index_id BIGINT NOT NULL REFERENCES embeddings_index(id) ON DELETE CASCADE,
    chunk_content TEXT NOT NULL,
    chunk_content_hash TEXT NOT NULL UNIQUE,
    embedding vector(1536),
    provider TEXT NOT NULL,
    model TEXT NOT NULL,
    reranking_score FLOAT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_content_embeddings_vector ON content_embeddings USING ivfflat (embedding vector_cosine_ops);
CREATE INDEX idx_content_embeddings_index ON content_embeddings(embeddings_index_id);
CREATE INDEX idx_content_embeddings_hash ON content_embeddings(chunk_content_hash);

-- 7. Search audit log
CREATE TABLE IF NOT EXISTS vector_searches (
    id BIGSERIAL PRIMARY KEY,
    query TEXT NOT NULL,
    query_embedding vector(1536),
    entity_type TEXT REFERENCES embeddable_entities(entity_type),
    top_k INT NOT NULL DEFAULT 10,
    reranking_used BOOLEAN NOT NULL DEFAULT false,
    retrieval_latency_ms INT,
    reranking_latency_ms INT,
    result_count INT,
    user_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_vector_searches_entity ON vector_searches(entity_type);
CREATE INDEX idx_vector_searches_time ON vector_searches(created_at DESC);

-- 8. Chunk deduplication map
CREATE TABLE IF NOT EXISTS chunk_dedupe (
    chunk_content_hash TEXT PRIMARY KEY,
    embedding_id BIGINT NOT NULL REFERENCES content_embeddings(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_chunk_dedupe_embedding ON chunk_dedupe(embedding_id);

-- 9. Initialization: Insert default embeddable entity types
INSERT INTO embeddable_entities (entity_type, display_name, extraction_strategy) VALUES
    ('investigation', 'AI Investigation', 'full_text'),
    ('execution_log', 'Execution Log', 'aggregated'),
    ('backup_fix', 'Backup Fix', 'full_text'),
    ('chat_message', 'Chat Message', 'full_text'),
    ('backup_run_summary', 'Backup Run Summary', 'synthesized'),
    ('analytics_snapshot', 'Analytics Snapshot', 'synthesized'),
    ('repository_summary', 'Repository Summary', 'synthesized')
ON CONFLICT DO NOTHING;

-- 10. Initialization: Insert default configuration (will be updated by application)
INSERT INTO embedding_config (
    id, provider, embedding_model, embedding_dimensions, rerank_enabled, rerank_model
) VALUES (
    1, 'openrouter', 'jina-embeddings-v3', 1024, false, NULL
) ON CONFLICT DO NOTHING;
```

---

## PART 10: PHASE-BY-PHASE IMPLEMENTATION

### Phase 0: Database Cleanup ✓

**Status:** COMPLETE - No cleanup needed

**Verification:**
```bash
# Run once before Phase 1
psql $POSTGRES_URL < schema_audit.sql
```

---

### Phase 1: Schema & Core Infrastructure

**Duration:** 1-2 days  
**Deliverables:**
1. Migration script (001_create_embedding_tables.sql)
2. Go models for database access
3. Basic configuration API endpoints

**Tasks:**
1. Execute migration in backend database
2. Create Go structs for table access:
   - `EmbeddingConfig`
   - `EmbeddableEntity`
   - `Entity`
   - `EmbeddingsIndex`
   - `ContentEmbedding`
   - `VectorSearch`
3. Implement database access layer:
   - `GetEmbeddingConfig()` - get current active config
   - `UpdateEmbeddingConfig()` - update model/provider
   - `GetEmbeddableEntities()` - list what can be embedded
   - `CreateEntity()` - register an embeddable item
   - `GetEntitiesByType()` - fetch all of a type

**Acceptance Criteria:**
- [ ] Migration runs successfully
- [ ] Tables created with correct indexes
- [ ] Primary key constraints enforced
- [ ] Foreign key relationships validated
- [ ] Default configuration inserted
- [ ] Go models compile
- [ ] Database access layer has unit tests

---

### Phase 2: OpenRouter Integration

**Duration:** 2-3 days  
**Deliverables:**
1. Dynamic model discovery
2. API key rotation
3. Rate limiting
4. Frontend model selector

**Tasks:**
1. Create OpenRouter client:
   - `FetchAvailableEmbeddingModels()` - GET /v1/models, filter for embedding
   - `FetchAvailableRerankerModels()` - GET /v1/models, filter for reranking
   - Cache results with 5-min TTL
2. Implement API key rotation:
   - Parse `OPENROUTER_API_KEY` env var
   - Rotate on each request
   - Handle rate limits (429)
3. Add backend API endpoints:
   - `GET /api/admin/embedding-models` - list available
   - `GET /api/admin/reranker-models` - list available
   - `POST /api/admin/config/embedding-model` - change model (admin only)
   - `POST /api/admin/config/reranker-model` - change model (admin only)
4. Update frontend:
   - Add model selector dropdowns
   - Fetch models on dashboard load
   - Show dimensions for each model

**Acceptance Criteria:**
- [ ] OpenRouter API client implemented
- [ ] Model discovery returns 10+ models
- [ ] API key rotation works across 3 keys
- [ ] Rate limit handling doesn't crash
- [ ] Frontend dropdowns populated dynamically
- [ ] Only admin users can change models
- [ ] Caching works (no repeated API calls)

---

### Phase 3: Chunking & Embedding Pipeline

**Duration:** 2-3 days  
**Deliverables:**
1. Chunking implementation
2. Embedding worker
3. Deduplication logic

**Tasks:**
1. Create chunking module:
   - `SemanticChunker` - split on sentences/paragraphs
   - `FixedChunker` - fixed-size chunks
   - `NoOpChunker` - single chunk
   - Special handling for markdown, code, JSON
2. Implement embedding worker:
   - `ProcessEntity()` - for single entity
   - `ProcessAllEntities()` - for full reindex
   - Track progress in `embedding_config.reindex_status`
   - Handle errors gracefully
3. Implement deduplication:
   - `GetDedupeHash()` - SHA256 of chunk content
   - `CheckDedupe()` - lookup existing embedding
   - `StoreDedupe()` - record hash → embedding_id
4. Integrate with OpenRouter:
   - Batch embeddings where possible
   - Call `/v1/embeddings` with chunks
   - Store results in `content_embeddings`

**Acceptance Criteria:**
- [ ] Chunking produces correct output
- [ ] All entity types can be processed
- [ ] Embeddings stored with correct dimensions
- [ ] Deduplication prevents re-embedding
- [ ] Reindex status tracked (start → complete/fail)
- [ ] Error handling doesn't corrupt state
- [ ] Reindex can be retried after failure

---

### Phase 4: Retrieval Pipeline & Search API

**Duration:** 2 days  
**Deliverables:**
1. Vector search implementation
2. Reranking integration
3. Search audit logging

**Tasks:**
1. Implement vector search:
   - Embed incoming query using active model
   - `SELECT` top-k from content_embeddings using cosine similarity
   - Return with metadata from entities table
2. Integrate reranking:
   - If `rerank_enabled`, call reranker API
   - Reorder results by rerank score
   - Log rerank latency
3. Add search API endpoint:
   - `POST /api/search/vector` - raw vector search
   - `POST /api/search/semantic` - semantic search with LLM context
   - Filters: `entity_type`, `top_k`
4. Implement search logging:
   - Insert into `vector_searches` after each query
   - Track latency, result count, user

**Acceptance Criteria:**
- [ ] Vector search returns relevant results
- [ ] Reranking reorders correctly
- [ ] Search latency < 500ms for typical queries
- [ ] All searches logged
- [ ] User feedback endpoint for relevance tuning
- [ ] Search works across entity types

---

### Phase 5: Frontend Dashboard

**Duration:** 2 days  
**Deliverables:**
1. Configuration panel
2. Index status display
3. Admin controls
4. Search analytics

**Tasks:**
1. Create dashboard page layout:
   - Configuration section (read-only initially)
   - Index status with real metrics
   - Search analytics (24h stats)
   - Admin panel (for verified users)
2. Implement data fetching:
   - `GET /api/admin/embedding-config` - current config
   - `GET /api/admin/embedding-stats` - index statistics
   - `GET /api/admin/search-analytics` - search metrics
3. Add admin controls:
   - Model selector dropdowns
   - "Apply" button triggers config update
   - "Trigger Rebuild" with confirmation
   - Error log display
4. Real-time updates:
   - Poll for reindex progress every 2 seconds
   - Update progress bar
   - Show current job status

**Acceptance Criteria:**
- [ ] Dashboard loads without errors
- [ ] All metrics are real (from database queries)
- [ ] Model selectors work
- [ ] Rebuild can be triggered
- [ ] Progress bar updates correctly
- [ ] Only admin users see admin panel
- [ ] No hardcoded or fake data

---

## PART 11: INTEGRATION CHECKLIST

### Pre-Implementation Verification

- [ ] PostgreSQL connection verified
- [ ] pgvector extension available
- [ ] OpenRouter API accessible
- [ ] Go build tools configured
- [ ] Node/TypeScript build working

### Phase Completion Checklist

**Phase 1: Schema**
- [ ] All tables created
- [ ] Indexes built
- [ ] Constraints enforced
- [ ] Default data inserted
- [ ] Go models written
- [ ] Unit tests passing

**Phase 2: OpenRouter**
- [ ] Model discovery working
- [ ] API key rotation tested
- [ ] Rate limiting handled
- [ ] Frontend dropdowns populated
- [ ] Admin auth enforced

**Phase 3: Chunking & Embedding**
- [ ] Chunking tested on all entity types
- [ ] Embeddings generated successfully
- [ ] Deduplication working
- [ ] Reindex workflow complete
- [ ] Error recovery tested
- [ ] Full reindex completes in < 30 min

**Phase 4: Retrieval**
- [ ] Vector search accurate
- [ ] Reranking improves relevance
- [ ] Latency acceptable (< 500ms)
- [ ] Search logging complete
- [ ] API documented

**Phase 5: Dashboard**
- [ ] Configuration displayed correctly
- [ ] Index stats accurate
- [ ] Admin controls functional
- [ ] Real-time updates working
- [ ] No hardcoded data

---

## PART 12: INDEPENDENCE & TESTING STRATEGY

### Phase Independence

Each phase can be tested independently:

1. **Phase 1**: Database tests only (no API calls)
2. **Phase 2**: API integration tests (mocked OpenRouter)
3. **Phase 3**: End-to-end embedding test (embed 10 sample entities)
4. **Phase 4**: Search quality tests (verify result relevance)
5. **Phase 5**: UI tests (verify display, admin controls)

### Testing Strategy

```bash
# Phase 1: Schema validation
go test ./backend/db -v

# Phase 2: OpenRouter client
go test ./backend/openrouter -v -integration

# Phase 3: Embedding pipeline
go test ./backend/embedding -v -integration

# Phase 4: Search
go test ./backend/search -v -integration

# Phase 5: Dashboard
npm test ./frontend/src/components/EmbeddingDashboard
```

### No Breaking Changes

- ✓ Existing backup tables untouched
- ✓ Existing API endpoints unchanged
- ✓ AI chat infrastructure independent
- ✓ Worker (CLI) unaffected
- ✓ Frontend other pages work as-is

---

## PART 13: SUCCESS CRITERIA

### Functional Requirements

- [ ] System can be configured with any OpenRouter embedding model
- [ ] System can be configured with any OpenRouter reranker model
- [ ] Full reindex completes without data loss
- [ ] Embeddings can be queried via vector similarity
- [ ] Reranking improves result quality
- [ ] Chunk deduplication prevents re-embedding
- [ ] Search results are relevant and ordered correctly
- [ ] Dashboard displays real, up-to-date metrics
- [ ] Admin controls work with proper authorization

### Non-Functional Requirements

- [ ] Vector search latency < 500ms
- [ ] Rerank latency < 200ms
- [ ] Reindex latency < 30 min (for full rebuild)
- [ ] No data loss on API key rotation
- [ ] Rate limiting doesn't crash application
- [ ] Graceful error handling on OpenRouter unavailable
- [ ] Database constraints enforce data integrity
- [ ] Schema normalized to 3NF

### Code Quality Requirements

- [ ] All code passes linting
- [ ] Unit test coverage > 80%
- [ ] Integration tests for each phase
- [ ] Database migration scripts tested
- [ ] Error messages are clear and actionable
- [ ] Configuration changes logged

---

End of Implementation Plan. This is the final blueprint - proceed only after validation.
