# Embedding System Architecture Validation & Implementation Blueprint

**Phase**: Final Architecture Review  
**Date**: 2026-08-02  
**Status**: Design Validation Complete

---

## PART 1: ARCHITECTURE REVIEW & CRITIQUE

### Current Design Assessment

#### Strengths
1. **Single active configuration** - Correct. No version history needed initially.
2. **Chunking as implementation step** - Correct. Don't pollute schema with chunking metadata.
3. **Embedding config normalization** - Correct. One row, no duplication.
4. **Content embeddings model** - Good foundation, but needs scrutiny.

#### Critical Issues Found

**ISSUE 1: embedding_config Schema is Under-Specified**

Current proposal:
```
- provider
- embedding_model
- embedding_dimensions
- rerank_enabled
- rerank_model
- updated_at
- last_reindexed_at
```

**Problems:**
- No explicit `id` (should be SERIAL PRIMARY KEY)
- No way to enforce exactly ONE row
- `updated_at` alone doesn't capture the reindex lifecycle clearly
- Missing: status tracking for ongoing reindex operations
- Missing: error tracking when reindex fails

**RECOMMENDATION:** Add a check constraint or application logic to enforce single row. Add explicit reindex_status column.

---

**ISSUE 2: content_embeddings Table Missing Normalization**

Current proposal includes all these fields in one table:
```
- entity_type
- entity_id
- chunk_index
- chunk_content
- chunk_hash
- embedding
- created_at
- updated_at
```

**Problems:**
- **Duplicate metadata**: entity_type is repeated N times per entity (for N chunks)
- **Entity lookup complexity**: To find all chunks for an entity, you need WHERE entity_type = X AND entity_id = Y (composite scan)
- **No entity reference table**: Breaking 3NF. entity_type + entity_id should be a foreign key to a normalized entity registry
- **Embedding provider/dimensions not tracked**: If you have 1000 chunks and change providers, you don't know which chunks used which provider

**RECOMMENDATION:** Create a separate `embeddings_index` table that normalizes entity references and provider metadata.

---

**ISSUE 3: No Entity Registry**

What should be embedded? You haven't defined this clearly:
- execution_logs
- backup_fixes
- investigations
- chat_messages
- repository_summaries
- reports
- documentation
- backup_runs
- analytics_snapshots

But the schema has no way to know which entities are eligible for embedding.

**RECOMMENDATION:** Create an `embeddable_entities` registry table that defines:
- entity_type (investigation, execution_log, backup_fix, etc.)
- display_name
- is_enabled
- extraction_strategy (how to get content)

---

**ISSUE 4: Chunk Hash Not Leveraged**

You're storing `chunk_hash` but there's no unique constraint on it. This means:
- Duplicate chunks can be embedded multiple times
- No deduplication across entities
- No way to detect if content changed without re-embedding

**RECOMMENDATION:** Use chunk_hash as a uniqueness constraint. Store mapping of hash → embedding_id to enable deduplication.

---

**ISSUE 5: No Search Metadata**

The retrieval pipeline needs:
- Search latency tracking per query
- Rerank latency tracking
- Top-K result metadata
- User feedback (relevance signals)

But there's nowhere to store this.

**RECOMMENDATION:** Add a `vector_searches` table to log every search operation.

---

### Better Schema Structure (3NF Normalized)

Instead of spreading metadata across `content_embeddings`, normalize into separate tables:

1. **embedding_config** - Single row with active configuration
2. **embeddable_entities** - Registry of what CAN be embedded
3. **entities** - Denormalized entity references (entity_type + entity_id + metadata)
4. **embeddings_index** - Maps entities to their embedding records
5. **content_embeddings** - Pure embedding storage (chunk data + vector)
6. **chunk_dedupe** - Chunk hash → embedding mapping for deduplication
7. **vector_searches** - Search audit log

---

## PART 2: DETAILED SCHEMA DESIGN

### Table 1: embedding_config

```sql
CREATE TABLE IF NOT EXISTS embedding_config (
    id SERIAL PRIMARY KEY CHECK (id = 1),
    provider TEXT NOT NULL,
    embedding_model TEXT NOT NULL,
    embedding_dimensions INT NOT NULL,
    rerank_enabled BOOLEAN NOT NULL DEFAULT false,
    rerank_model TEXT,
    reindex_status TEXT NOT NULL DEFAULT 'idle' 
        CHECK (reindex_status IN ('idle', 'reindexing', 'failed')),
    reindex_error TEXT,
    reindex_started_at TIMESTAMPTZ,
    last_reindexed_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_embedding_config_singleton ON embedding_config(id);
```

**Rationale:**
- `id = 1` check constraint ensures only one row
- Separate reindex_status from updated_at (reindexing is a lifecycle state, not just metadata)
- reindex_error captures failure context
- All timestamps are TIMESTAMPTZ for portability

---

### Table 2: embeddable_entities

```sql
CREATE TABLE IF NOT EXISTS embeddable_entities (
    entity_type TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    is_enabled BOOLEAN NOT NULL DEFAULT true,
    extraction_strategy TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO embeddable_entities (entity_type, display_name, extraction_strategy) VALUES
    ('investigation', 'AI Investigation', 'full_text'),
    ('execution_log', 'Execution Log', 'aggregated'),
    ('backup_fix', 'Backup Fix', 'full_text'),
    ('chat_message', 'Chat Message', 'full_text'),
    ('backup_run_summary', 'Backup Run Summary', 'synthesized'),
    ('analytics_snapshot', 'Analytics Snapshot', 'synthesized'),
    ('repository_summary', 'Repository Summary', 'synthesized')
ON CONFLICT DO NOTHING;
```

**Rationale:**
- Registry of embeddable types prevents hardcoding in application
- extraction_strategy describes how to get content (affects chunking)
- is_enabled allows toggling without schema changes

---

### Table 3: entities (Denormalized Reference)

```sql
CREATE TABLE IF NOT EXISTS entities (
    id BIGSERIAL PRIMARY KEY,
    entity_type TEXT NOT NULL REFERENCES embeddable_entities(entity_type),
    external_id TEXT NOT NULL,
    display_name TEXT NOT NULL,
    source_created_at TIMESTAMPTZ,
    source_updated_at TIMESTAMPTZ,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (entity_type, external_id)
);

CREATE INDEX idx_entities_type ON entities(entity_type);
CREATE INDEX idx_entities_type_id ON entities(entity_type, external_id);
CREATE INDEX idx_entities_created ON entities(created_at DESC);
```

**Rationale:**
- Denormalization: Combines entity_type + external_id with human-readable metadata
- One row per embeddable item (not one per chunk)
- Metadata JSONB captures provider-specific info without schema changes
- UNIQUE constraint ensures entity deduplication

---

### Table 4: embeddings_index

```sql
CREATE TABLE IF NOT EXISTS embeddings_index (
    id BIGSERIAL PRIMARY KEY,
    entity_id BIGINT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    chunk_index INT NOT NULL,
    chunk_count INT NOT NULL,
    chunk_hash TEXT NOT NULL,
    embedding_dimensions INT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (entity_id, chunk_index)
);

CREATE INDEX idx_embeddings_entity ON embeddings_index(entity_id);
CREATE INDEX idx_embeddings_hash ON embeddings_index(chunk_hash);
```

**Rationale:**
- One row per chunk per entity (normalized metadata)
- chunk_hash enables deduplication lookups
- chunk_count allows validation that all chunks exist
- Separate from actual vector storage (vectors stay in content_embeddings)

---

### Table 5: content_embeddings

```sql
CREATE TABLE IF NOT EXISTS content_embeddings (
    id BIGSERIAL PRIMARY KEY,
    embeddings_index_id BIGINT NOT NULL REFERENCES embeddings_index(id) ON DELETE CASCADE,
    chunk_content TEXT NOT NULL,
    chunk_content_hash TEXT NOT NULL UNIQUE,
    embedding vector(1536),
    provider TEXT NOT NULL,
    model TEXT NOT NULL,
    reranking_score FLOAT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_content_embeddings_vector ON content_embeddings USING ivfflat (embedding vector_cosine_ops);
CREATE INDEX idx_content_embeddings_index ON content_embeddings(embeddings_index_id);
CREATE INDEX idx_content_embeddings_hash ON content_embeddings(chunk_content_hash);
```

**Rationale:**
- Pure embedding storage (vectors in pgvector)
- chunk_content_hash enables deduplication (don't re-embed identical chunks)
- provider + model tracked per embedding (audit trail)
- reranking_score stored for retrieval optimization

---

### Table 6: vector_searches (Audit & Analytics)

```sql
CREATE TABLE IF NOT EXISTS vector_searches (
    id BIGSERIAL PRIMARY KEY,
    query TEXT NOT NULL,
    query_embedding vector(1536),
    entity_type TEXT REFERENCES embeddable_entities(entity_type),
    top_k INT NOT NULL DEFAULT 10,
    reranking_used BOOLEAN NOT NULL DEFAULT false,
    retrieval_latency_ms INT,
    reranking_latency_ms INT,
    result_count INT,
    user_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_vector_searches_entity ON vector_searches(entity_type);
CREATE INDEX idx_vector_searches_time ON vector_searches(created_at DESC);
```

**Rationale:**
- Audit log for every search (debugging, analytics, user feedback)
- Latency tracking enables performance monitoring
- result_count enables ranking quality metrics

---

## PART 3: WORKFLOW & PIPELINE DESIGN

### Embedding Lifecycle Workflow

```
1. User/Admin Action: "Change embedding model"
   ↓
2. Validation: Check OpenRouter available models
   ↓
3. Update embedding_config:
   - Set new provider, model, dimensions
   - Set reindex_status = 'reindexing'
   - Set reindex_started_at = NOW()
   ↓
4. For each entity in entities table WHERE embeddable_entities.is_enabled = true:
   ↓
5. Extract content (based on extraction_strategy)
   ↓
6. Chunk content (see chunking strategy below)
   ↓
7. Call OpenRouter embedding API
   ↓
8. Check chunk_content_hash against dedupe table:
   - If exists: reuse embedding, link to new entity
   - If new: insert into content_embeddings
   ↓
9. Insert into embeddings_index
   ↓
10. After all entities processed:
    - Set reindex_status = 'idle'
    - Set last_reindexed_at = NOW()
    - Update updated_at
    ↓
11. If error during reindex:
    - Set reindex_status = 'failed'
    - Set reindex_error = error message
    - Log to execution_logs (or new error table)
```

**Why this is safe:**
- Atomic: Set status to 'reindexing' before starting
- Failure handling: reindex_status and reindex_error capture lifecycle
- No data loss: Old embeddings remain until full replacement
- Deduplication: chunk_content_hash prevents re-embedding identical content
- Audit trail: vector_searches logs all lookups

---

### Retrieval Pipeline (Production)

```
User Query
    ↓
1. Normalize query text
   ↓
2. Embed query using ACTIVE model (from embedding_config)
   ↓
3. Vector search (pgvector cosine similarity):
   SELECT ce.id, e.entity_type, e.external_id, e.display_name, e.metadata,
          1 - (ce.embedding <=> query_embedding) as similarity
   FROM content_embeddings ce
   JOIN embeddings_index ei ON ce.embeddings_index_id = ei.id
   JOIN entities e ON ei.entity_id = e.id
   WHERE e.entity_type = :entity_type (optional filter)
   ORDER BY similarity DESC
   LIMIT :top_k + buffer
   ↓
4. If rerank_enabled from embedding_config:
   - Call rerank_model API
   - Reorder by rerank scores
   - LIMIT :top_k
   ↓
5. Log search (insert into vector_searches)
   ↓
6. Assemble context:
   - Get top-k results
   - Fetch full entity context from entities table
   - Build prompt with retrieved context
   ↓
7. Call LLM with context + user query
   ↓
8. Return to user
```

---

## PART 4: CHUNKING STRATEGY

### Chunking Parameters by Entity Type

| Entity Type | Strategy | Chunk Size | Overlap | Notes |
|---|---|---|---|---|
| investigation | semantic | 512 tokens | 50 | Full Q&A + tools, split on sentence boundaries |
| execution_log | fixed | 256 tokens | 0 | Sequential log lines, no overlap needed |
| backup_fix | semantic | 768 tokens | 100 | Code + description, preserve context |
| chat_message | none | full | N/A | Single message = one chunk (small) |
| backup_run_summary | semantic | 1024 tokens | 200 | Summary stats + descriptions |
| analytics_snapshot | fixed | 512 tokens | 0 | Tabular data, preserve structure |
| repository_summary | semantic | 1024 tokens | 150 | README + metadata, rich context |

### Chunking Implementation Details

1. **Semantic chunking** (for natural language):
   - Use sentence boundaries or paragraph breaks
   - Respect token limits with tiktoken
   - Preserve code blocks as atomic units
   - Detect headers and keep hierarchies

2. **Fixed chunking** (for logs):
   - Split on newline boundaries
   - Fixed token count per chunk
   - No overlap (logs are sequential)

3. **None** (for small content):
   - Single chunk = full content
   - Use for chat messages, small fixes

4. **Special handling**:
   - **Markdown**: Preserve structure, split on h2/h3 boundaries
   - **Code blocks**: Keep together, don't split at closing brackets
   - **JSON**: Parse and re-pretty-print for readability
   - **Long lists**: Split on item boundaries

### Deduplication Strategy

1. Hash each chunk content: `chunk_hash = SHA256(chunk_text)`
2. Before embedding, check `chunk_dedupe`:
   - If hash exists → reuse embedding, create link in embeddings_index
   - If new → embed and store in content_embeddings

This prevents re-embedding identical log entries, repeated descriptions, etc.

---

## PART 5: OPENROUTER INTEGRATION DESIGN

### Model Discovery (Dynamic)

```python
# OpenRouter official endpoint
GET https://openrouter.ai/api/v1/models

# Filter for embedding capability:
models = [m for m in response.data 
          if "text" in m.architecture.output_modalities
          and not m.pricing.prompt and not m.pricing.completion]

# Filter for reranking capability:
models = [m for m in response.data
          if "ranking" in m.capabilities
          and not m.pricing.prompt and not m.pricing.completion]
```

**Frontend behavior:**
- On load: Fetch available models from GET /api/models
- Cache for 5 minutes
- Render dropdown with model names and dimensions
- Only verified users can change model

---

### API Key Management

**Environment format:**
```bash
OPENROUTER_API_KEY="key1,key2,key3"
```

**Rotation strategy:**
```python
class APIKeyRotator:
    def __init__(self, keys: list[str]):
        self.keys = keys
        self.index = 0
    
    def get_next(self):
        key = self.keys[self.index]
        self.index = (self.index + 1) % len(self.keys)
        return key
    
    def on_rate_limit(self):
        # Skip this key for N minutes
        # Move to next
        pass
```

**Rate-limit handling:**
- Implement exponential backoff
- Track per-key rate limit status
- Rotate to next key on 429
- Log rate limits for monitoring

---

## PART 6: WHAT SHOULD BE EMBEDDED

### Detailed Analysis

| Entity | Should Embed? | Why | What Content |
|---|---|---|---|
| investigations | YES | Core use case for RAG | question + answer + tool results |
| execution_logs | PARTIAL | Only aggregated summaries | ERROR/WARN level logs aggregated by run |
| backup_fixes | YES | Context for agents | title + description + code changes |
| chat_messages | NO | Token waste | Single messages have low context value |
| backup_runs | NO | Metadata only | Run summaries exist in analytics_snapshots |
| analytics_snapshots | YES | System state tracking | head_commit_message + key metrics |
| repository_summaries | YES | High value | README + language stats + key files |
| reports | YES | Historical context | Generated HTML reports converted to text |
| documentation | YES | Operational ref | Markdown docs in /docs directory |

### Never Embed

- **Raw logs with PII**: Execution logs may contain tokens, secrets
- **Credentials/secrets**: API keys, tokens, passwords
- **Duplicate metadata**: Don't embed same data twice (deduplication)
- **Tiny content**: < 50 tokens (chat single messages)

---

## PART 7: DASHBOARD SPECIFICATION

### Real Data Requirements

Dashboard MUST show ONLY real data:
- No fake statistics
- No hardcoded numbers
- Everything query-based

### Dashboard Sections

**1. Configuration Panel**
```
┌─────────────────────────────────────────┐
│ EMBEDDING CONFIGURATION                 │
├─────────────────────────────────────────┤
│ Provider:           OpenRouter           │
│ Embedding Model:    [jina-embeddings-v3] │ (Dropdown if admin)
│ Dimensions:         1024                 │
│ Reranking Enabled:  Yes                  │
│ Rerank Model:       [jina-reranker-v1]   │ (Dropdown if admin)
│ Last Updated:       2026-08-02 14:30 UTC │
└─────────────────────────────────────────┘
```

**2. Index Status Panel**
```
┌─────────────────────────────────────────┐
│ INDEX STATUS                            │
├─────────────────────────────────────────┤
│ Total Embedded Entities:  234            │
│ Total Chunks:            1847            │
│ Last Full Reindex:       2026-08-01 UTC  │
│ Reindex Status:          idle / reindexing
│ Next Reindex:            --              │
└─────────────────────────────────────────┘
```

**3. Current Job Panel** (if reindexing)
```
┌─────────────────────────────────────────┐
│ REINDEXING PROGRESS                     │
├─────────────────────────────────────────┤
│ Progress:      [████████░░░░░░░░░░] 45%  │
│ Processed:     105 / 234 entities        │
│ Remaining:     129 entities              │
│ Failed:        2 entities (see log)      │
│ Elapsed:       12m 34s                   │
│ Estimated:     28m remaining             │
└─────────────────────────────────────────┘
```

**4. Search Analytics Panel**
```
┌─────────────────────────────────────────┐
│ SEARCH ANALYTICS (Last 24h)             │
├─────────────────────────────────────────┤
│ Total Searches:        156               │
│ Avg Retrieval Latency: 145ms             │
│ Avg Rerank Latency:    78ms              │
│ Indexed Entity Types:  7 active          │
│ Top Entity Type:       investigations (89) │
└─────────────────────────────────────────┘
```

**5. Admin Controls** (Verified users only)
```
┌─────────────────────────────────────────┐
│ ADMIN ACTIONS                           │
├─────────────────────────────────────────┤
│ [Change Embedding Model ▼]  [Apply]     │
│ [Change Rerank Model ▼]     [Apply]     │
│ [Trigger Full Rebuild]      [CONFIRM]   │
│ [View Reindex Errors]       [Logs]      │
└─────────────────────────────────────────┘
```

---

End of Part 1-7. Continuing in next sections...
