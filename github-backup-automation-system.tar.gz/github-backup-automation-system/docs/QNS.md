# Embeddings, Vector Search, ANN, and RAG Notes

Consolidated study notes from this conversation.

1. Embeddings

Embeddings are dense numerical vectors representing the semantic meaning of data (text, images, audio, etc.). Similar content maps to nearby vectors.

Key points:

Same embedding model must be used for queries and documents.

Common dimensions: 384, 768, 1024, 1536, 3072.

Higher dimensions improve expressiveness but increase memory and compute.

2. Similarity Metrics

Cosine Similarity: compares vector direction. Most common for text.

Euclidean (L2): straight-line distance.

Inner Product (Dot Product): often used with normalized vectors.

3. Exact vs Approximate Nearest Neighbor

Exact NN:

Compares against every vector.

Perfect recall.

O(N).

Approximate NN (ANN):

Trades a little accuracy for massive speed.

Used by nearly every production vector database.

4. ANN Index Types

Flat

Brute-force search.

HNSW

Graph-based ANN.

Very high recall

Fast queries

Higher RAM

Parameters: M, efConstruction, efSearch

IVFFlat

Cluster vectors with k-means.Search only relevant clusters.Parameters:

nlist: clusters

nprobe: clusters searched

IVFPQ

IVF + Product Quantization.Much lower memory.

IVF-HNSW

IVF partitioning with HNSW inside partitions.

DiskANN

SSD-backed ANN for billion-scale datasets.

ScaNN

Google's optimized ANN implementation.

Annoy

Tree-based ANN (Spotify).

NSG

Alternative graph-based ANN.

LSH

Hash-based approximate search.

5. Quantization

Scalar Quantization (SQ)

Compress float32 -> float16/int8.

Product Quantization (PQ)

Split vectors into sub-vectors and encode each independently.

Optimized PQ (OPQ)

Rotate vectors before PQ for better compression.

Residual Quantization

Compress residual after coarse clustering.

Binary Quantization

Represent vectors as binary codes.

6. Retrieval Concepts

Top-K Search

Radius Search

k-NN

Candidate Generation

Metadata Filtering

Hybrid Search (BM25 + Dense)

Reranking (Cross Encoder)

Context Packing

Context Compression

7. Retrieval Pipeline

Raw Documents→ Chunking→ Embedding Model→ Vector Index→ ANN Retrieval→ Metadata Filtering→ Hybrid Merge→ Reranker→ Top-K Context→ LLM→ Final Answer

8. Chunking

Strategies:

Fixed size

Sentence

Paragraph

Sliding window

Semantic chunking

Tradeoff:Small chunks = precision.Large chunks = more context.

9. Embedding Models

Examples:

OpenAI

BGE

E5

Jina

Nomic

Sentence Transformers

Never mix embeddings from different models.

10. Sparse vs Dense Retrieval

Dense:Semantic vectors.

Sparse:Keyword/token weights (BM25).

Hybrid combines both.

11. BM25

Classical lexical retrieval based on:

TF

IDF

Document length

Excellent for exact keywords.

12. Cross Encoder vs Bi Encoder

Bi Encoder:Independent embeddings.Fast.

Cross Encoder:Joint query-document inference.Slow but very accurate.

13. Ranking Techniques

Reciprocal Rank Fusion (RRF)

Maximum Marginal Relevance (MMR)

14. Evaluation Metrics

Recall

Precision

Recall@K

Precision@K

NDCG

Latency

Throughput

15. Distributed Concepts

Sharding

Replication

Incremental Indexing

Index Build Time

Compaction

Tombstones

16. Semantic Concepts

Semantic Similarity

Lexical Similarity

Semantic Search

Keyword Search

Query Expansion

Query Rewriting

17. Multi-vector Retrieval

ColBERT

Late Interaction

DPR

Dual Encoder

18. Training Embeddings

Contrastive Learning

Triplet Loss

InfoNCE Loss

Hard Negative Mining

19. Multimodal Embeddings

Single embedding space for:

Text

Images

Audio

Video

Example: CLIP.

20. Production Issues

Vector Drift

Re-Embedding

Curse of Dimensionality

Hubness

Out-of-Distribution Inputs

Embedding Collapse

Semantic Cache

21. RAG

Pipeline:Query→ Retrieve→ Rerank→ Provide Context→ LLM

Variants:

Basic RAG

Agentic RAG

GraphRAG

Self-RAG

CRAG

RAPTOR

HyDE

Parent Document Retrieval

Multi-query Retrieval

Ensemble Retrieval

Contextual Retrieval

22. Negative Search

Not a standard ANN algorithm.

Usually means:

Penalize similarity to unwanted concepts.

Exclude via metadata filters.

Score(query) - λ * Score(negative).

23. Common Interview Topics

Must know:

Embeddings

Similarity Metrics

ANN

HNSW

IVFFlat

PQ / OPQ

Hybrid Search

BM25

Cross Encoder

Chunking

Metadata Filtering

Reranking

Recall / Precision

Latency vs Recall

Sharding

Replication

Context Compression

Vector Databases

RAG Pipeline

Advanced:

DiskANN

ScaNN

ColBERT

Contrastive Learning

InfoNCE

Hard Negative Mining

GraphRAG

HyDE

Matryoshka Embeddings

SPLADE

ANN Benchmarks (BEIR, MTEB, ANN-Benchmarks)

24. Mental Model

Data
 ↓
Chunk
 ↓
Embedding Model
 ↓
Vectors
 ↓
ANN Index
 ↓
Retrieve
 ↓
Filter
 ↓
Hybrid Merge
 ↓
Rerank
 ↓
LLM
 ↓
Answer