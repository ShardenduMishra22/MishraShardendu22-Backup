# IMMEDIATE ACTION PLAN - Database Schema Migration

**Status**: ❌ BLOCKING  
**Issue**: Old embedding schema prevents new schema creation  
**Solution**: Rename old tables, restart backend, verify new schema  

---

## STEP-BY-STEP ACTIONS

### Step 1: Backup (5 minutes)
```bash
# Create timestamped backup
pg_dump "$POSTGRES_URL" > embedding_backup_$(date +%Y%m%d_%H%M%S).sql
echo "✓ Backup created"
```

### Step 2: Run Cleanup Migration (5 minutes)
```bash
cd /home/mishrashardendu22/Resume-Projects/GitHub-BackUp-Script/backend

# Option A: Using Go tool (preferred)
go run tools/migrate.go -cleanup

# Option B: Manual SQL (if tool fails)
# Open your favorite SQL client and run:
# ALTER TABLE embedding_configs RENAME TO embedding_configs_deprecated;
# ALTER TABLE content_embeddings RENAME TO content_embeddings_deprecated;
```

### Step 3: Restart Backend (2 minutes)
```bash
# Kill existing backend process
pkill -f "github-backup/backend" || true

# Wait for graceful shutdown
sleep 2

# Start backend (it will run schema.sql on startup)
cd /home/mishrashardendu22/Resume-Projects/GitHub-BackUp-Script/backend
go run main.go

# Or if you have a built binary:
# ./backend
```

**Watch for output:**
```
PostgreSQL connected and migrations applied
```

### Step 4: Verify Schema Was Created (5 minutes)
```bash
cd /home/mishrashardendu22/Resume-Projects/GitHub-BackUp-Script

# Run inspection script to verify
go run /tmp/inspect_db.go

# Expected output:
#   - content_embeddings (NEW)
#   - embedding_config (NEW - 1 row)
#   - embedding_jobs (NEW)
#   - vector_searches (NEW)
#   - content_embeddings_deprecated (OLD - preserved)
#   - embedding_configs_deprecated (OLD - preserved)
```

### Step 5: Verify Build Still Works (2 minutes)
```bash
cd /home/mishrashardendu22/Resume-Projects/GitHub-BackUp-Script/backend
go build ./...

# Should complete with no errors
echo "✓ Build successful"
```

### Step 6: Cleanup Old Tables (Optional, do after verification)
```bash
# After you've confirmed the new schema is working:
psql "$POSTGRES_URL" -c "
  DROP TABLE IF EXISTS embedding_configs_deprecated CASCADE;
  DROP TABLE IF EXISTS content_embeddings_deprecated CASCADE;
"
```

---

## WHAT HAPPENS AT EACH STEP

### Step 1: Backup
Creates a SQL dump of current database for rollback if needed.

### Step 2: Cleanup
Renames:
- `embedding_configs` → `embedding_configs_deprecated`
- `content_embeddings` → `content_embeddings_deprecated`

This clears the path for new tables to be created.

### Step 3: Restart
Backend startup process:
1. Connects to PostgreSQL
2. Calls `db.RunMigrations()`
3. Executes embedded schema.sql
4. Creates new tables:
   - `embedding_config` (new, clean)
   - `embedding_jobs` (new)
   - `vector_searches` (new)
   - `content_embeddings` (new schema, 0 rows)
5. Skips old tables (they're renamed)

### Step 4: Verify
Confirms:
- ✓ New tables created
- ✓ Old tables preserved as _deprecated
- ✓ Schema matches design
- ✓ No errors in creation

### Step 5: Build
Ensures Go code still compiles with new schema.

### Step 6: Cleanup
Drops old tables after confirming everything works.

---

## EXPECTED RESULTS

### Before Migration
```
Tables in public schema:
  - embedding_configs (OLD - 6 rows, wrong schema)
  - content_embeddings (OLD - 329 rows, wrong schema)
  - [missing: embedding_config, embedding_jobs, vector_searches]
```

### After Migration & Restart
```
Tables in public schema:
  - embedding_config (NEW - 1 row, correct schema) ✓
  - embedding_jobs (NEW - 0 rows, correct schema) ✓
  - vector_searches (NEW - 0 rows, correct schema) ✓
  - content_embeddings (NEW - 0 rows, correct schema) ✓
  - embedding_configs_deprecated (OLD - 6 rows, preserved)
  - content_embeddings_deprecated (OLD - 329 rows, preserved)
```

### Verification Script Output
```
Table: embedding_config
  ✓ Table exists
    - id (integer, nullable=NO)
    - provider (text, nullable=NO)
    - embedding_model (text, nullable=NO)
    - embedding_dimensions (integer, nullable=NO)
    - rerank_enabled (boolean, nullable=NO)
    - rerank_model (text, nullable=YES)
    - status (text, nullable=NO)
    - last_reindexed_at (timestamp with time zone, nullable=YES)
    - last_error (text, nullable=YES)
    - created_at (timestamp with time zone, nullable=NO)
    - updated_at (timestamp with time zone, nullable=NO)

Table: embedding_jobs
  ✓ Table exists
    - [all columns present and correct]

Table: vector_searches
  ✓ Table exists
    - [all columns present and correct]

Table: content_embeddings
  ✓ Table exists
    - [all columns present and correct]
```

---

## ROLLBACK PROCEDURE

If something goes wrong:

```sql
-- Restore old table names
ALTER TABLE embedding_configs_deprecated RENAME TO embedding_configs;
ALTER TABLE content_embeddings_deprecated RENAME TO content_embeddings;

-- Drop new tables (optional)
DROP TABLE IF EXISTS embedding_config CASCADE;
DROP TABLE IF EXISTS embedding_jobs CASCADE;
DROP TABLE IF EXISTS vector_searches CASCADE;
DROP TABLE IF EXISTS content_embeddings CASCADE;
```

Then restart backend.

---

## ESTIMATED TIME

- Backup: 5 minutes
- Cleanup migration: 5 minutes
- Restart backend: 2 minutes
- Verification: 5 minutes
- Build check: 2 minutes
- **Total: ~20 minutes**

---

## AFTER MIGRATION COMPLETE

Once verified:
1. ✓ Database schema matches design
2. ✓ Old infrastructure preserved in _deprecated tables
3. ✓ Build works
4. ✓ Ready for Phase 2

**Next**: Resume Phase 2 implementation (embedding service, worker, handlers)

---

## TROUBLESHOOTING

### Error: "ALTER TABLE" fails
- Check if table names are correct (might already be renamed)
- Check POSTGRES_URL is valid
- Verify database connection works

### Error: "New tables not created after restart"
- Check backend logs for errors
- Verify schema.sql was updated (check backend/db/schema.sql)
- Manually verify what tables exist
- Ensure pgvector extension is available

### Error: "Foreign key constraint failed"
- This shouldn't happen with cleanup migration (only renames)
- If using Option B (manual SQL), might need CASCADE
- Add CASCADE: `ALTER TABLE embedding_configs RENAME TO...`

### Old data lost
- It's preserved in _deprecated tables
- Can be recovered by renaming back or restoring from backup

---

## QUESTION: Can we skip this and just continue?

**NO.** 

The code compiles but will fail at runtime because:
- Tables don't exist with new schema
- Old tables have incompatible structure
- Embedding operations will crash
- Database layer expects new schema

This migration must complete before Phase 2.

---

**Status**: Ready to execute  
**Urgency**: Must complete before Phase 2  
**Risk**: Low (backup created, reversible)  
**Estimated success**: 95% (straightforward rename + restart)

**Execute migration when ready.**
