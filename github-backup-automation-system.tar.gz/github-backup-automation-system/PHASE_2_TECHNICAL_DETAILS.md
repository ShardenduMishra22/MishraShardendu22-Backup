# PHASE 2 TECHNICAL IMPLEMENTATION DETAILS

## CODE CHANGES SUMMARY

### 1. Schema Changes (backend/db/schema.sql)

**embedding_config Table**
```sql
-- NEW FIELDS
active_version INT NOT NULL DEFAULT 1    -- Currently active version
next_version INT NOT NULL DEFAULT 2      -- Version being built

-- NEW CONSTRAINT  
CHECK (id = 1)                           -- Enforce singleton at DB level
```

**content_embeddings Table**
```sql
-- NEW FIELD
embedding_version INT NOT NULL DEFAULT 1

-- UPDATED UNIQUENESS CONSTRAINT
UNIQUE(entity_type, entity_id, chunk_index, embedding_version)
-- Was: UNIQUE(entity_type, entity_id, chunk_index)

-- NEW INDEXES
idx_content_embeddings_version (for filtering by version)
idx_content_embeddings_active (for active version queries)
```

---

### 2. Model Updates (backend/models/embedding.models.go)

**EmbeddingConfig Struct**
```go
// Added fields
ActiveVersion int     // Currently active version for searches
NextVersion   int     // Version being built during rebuild
```

**ContentEmbedding Struct**
```go
// Added field
EmbeddingVersion int   // Version this chunk belongs to
```

---

### 3. Database Functions (backend/db/embedding.db.go)

**New Functions**
- `CreateNewEmbeddingVersion(ctx)` → int
  - Increments next_version, sets status to 'reindexing'
  - Returns version number to use for this rebuild

- `ActivateEmbeddingVersion(ctx, version)` → error
  - Sets active_version = version
  - Sets status = 'ready', clears last_error
  - Sets last_reindexed_at = NOW()
  - Called only after complete rebuild

- `CleanupOldEmbeddingVersions(ctx)` → error
  - Deletes embeddings where version < (active_version - 1)
  - Keeps active version and one previous for rollback

- `GetEmbeddingVersionStatus(ctx)` → map[string]interface{}, error
  - Returns active_version, next_version, status
  - Counts embeddings per version

**Updated Functions**
- `GetEmbeddingConfig()` - Now scans active_version, next_version
- `VectorSearch()` - Only queries WHERE embedding_version = active_version
- `InsertContentEmbedding()` - Now takes version parameter
- `InitializeEmbeddingConfig()` - Initializes active_version=1, next_version=2

---

### 4. Service Layer (backend/service/embedding/service.go)

**StartRebuild() - RACE CONDITION FIX**

Key changes:
- Extended lock scope: `s.mu.Lock()` → `defer s.mu.Unlock()`
- All initialization steps under lock:
  1. Check if job running
  2. CreateEmbeddingJob
  3. CreateNewEmbeddingVersion
  4. CreateEmbeddingContext and cancel function
  5. SetEmbeddingStatus to 'reindexing'
- Error handling: Cancel context on SetEmbeddingStatus failure (CONTEXT LEAK FIX)

```go
// Pattern
s.mu.Lock()
defer s.mu.Unlock()

// All checks and setup here
```

**rebuildLoop() - PARTIAL REBUILD CONSISTENCY FIX**

Key changes:
- Receives version parameter
- Passes version to StoreEmbedding for all chunks
- Only calls ActivateEmbeddingVersion() after ALL entities complete
- Failure: Doesn't activate version, keeps it inactive
- Search queries only active version, never sees failed rebuild

Flow:
1. Process all entities with new version
2. If complete: ActivateEmbeddingVersion(version)
3. If partial/failed: Don't activate, keep running with old version
4. Search queries always use active version

---

### 5. Generator (backend/service/embedding/generator.go)

**GenerateEmbeddings() - RETRY LOGGING**

Added logging:
```go
eg.logger.WarnContext(ctx, "rate limited, retrying",
    "attempt", attempt+1,
    "maxRetries", eg.maxRetries,
    "backoff_ms", backoff.Milliseconds(),
    "model", model)
```

**BatchGenerateEmbeddings() - BATCH FAILURE HANDLING**

Changed error handling:
- **Before**: Return error, discard all partial results
- **After**: Return partial embeddings + error
- Caller can decide to retry, skip, or continue

```go
embeddings, err := eg.GenerateEmbeddings(ctx, model, batch)
if err != nil {
    // Return what we have so far, let caller handle
    return allEmbeddings, fmt.Errorf("batch %d: %w", batchNum, err)
}
```

---

### 6. Storage Service (backend/service/embedding/storage.go)

**StoreEmbedding() - VERSION TRACKING**

Added version parameter:
```go
func (ss *StorageService) StoreEmbedding(
    ctx context.Context,
    tx interface{},
    entityType, entityID string,
    chunkIndex int,
    chunkText, chunkHash string,
    version int,                  // NEW
    embedding []float32,
) error
```

Uses version in INSERT:
```sql
INSERT INTO content_embeddings 
(entity_type, entity_id, chunk_index, chunk_text, chunk_hash, 
 embedding_version, embedding, created_at, updated_at)
VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())
ON CONFLICT (entity_type, entity_id, chunk_index, embedding_version) 
DO UPDATE SET ...
```

**New Method**
- `CheckChunkDeduplication(ctx, chunkHash)` → bool, error
  - Checks if chunk_hash already exists in any version

---

### 7. Configuration Initialization (backend/db/postgres.db.go)

**RunMigrations()**

Added initialization:
```go
// After running schema migrations
if err := InitializeEmbeddingConfig(ctx); err != nil {
    return fmt.Errorf("initialize embedding config: %w", err)
}
```

Ensures singleton row exists on startup with:
- active_version = 1
- next_version = 2
- status = 'ready'

---

### 8. Provider Abstraction (backend/service/provider/openrouter.go)

**Existing Implementation Verified**

Already implements:
- `EmbeddingProvider` interface
- `RerankProvider` interface (future use)
- `NewOpenRouterProvider(apiKeyStr, logger)` - Parses multiple keys
- Key rotation via `getNextAPIKey()`
- Exponential backoff retry
- Rate-limit handling (429)
- Structured logging

**Multiple API Key Parsing**
```go
keys := strings.Split(strings.TrimSpace(apiKeyStr), ",")
var cleanKeys []string
for _, k := range keys {
    trimmed := strings.TrimSpace(k)
    if trimmed != "" {
        cleanKeys = append(cleanKeys, trimmed)
    }
}
```

**Key Rotation**
```go
func (p *OpenRouterProvider) getNextAPIKey() string {
    if len(p.apiKeys) == 0 {
        return ""
    }
    key := p.apiKeys[p.keyIndex]
    p.keyIndex = (p.keyIndex + 1) % len(p.apiKeys)
    return key
}
```

---

## CONFIGURATION REFERENCE

### sample.env

All embedding-related variables documented:

```env
# OpenRouter API Keys - Multiple for rate-limit handling
OPENROUTER_API_KEY="sk-or-v1-xxxxx,sk-or-v1-yyyyy"

# Embedding Configuration
EMBEDDING_MODEL=jina-embeddings-v3
EMBEDDING_DIMENSIONS=1024
RERANK_ENABLED=false
RERANK_MODEL=
```

Full documentation includes:
- Format explanations
- Benefit descriptions
- Example configurations
- Requirements and notes

---

## VERSION LIFECYCLE

### 1. Start Rebuild
```
active_version = 1, next_version = 2
└─ CreateNewEmbeddingVersion()
   └─ Returns version=2 to use
   └─ Updates next_version=3
   └─ Sets status='reindexing'
```

### 2. During Rebuild
```
Process all entities with version=2
├─ StoreEmbedding(..., version=2, ...)
├─ All chunks stored with embedding_version=2
└─ Search still queries version=1 (active)
```

### 3. On Complete
```
ActivateEmbeddingVersion(2)
├─ Sets active_version=2
├─ Sets status='ready'
└─ Search now queries version=2

Version 1 remains for rollback
```

### 4. Cleanup
```
CleanupOldEmbeddingVersions()
└─ DELETE FROM content_embeddings
   WHERE embedding_version < (active_version - 1)
   └─ Keeps versions: 1 (previous), 2 (active)
   └─ Deletes: 0, -1, etc.
```

---

## ERROR FLOW

### StartRebuild Error
```
s.mu.Lock()
CreateEmbeddingJob() [OK]
CreateNewEmbeddingVersion() [OK]
CreateEmbeddingContext() [OK]
SetEmbeddingStatus() [FAILS]
  └─ cancel()              ← FIX: Cancel context on error
  └─ s.currentJob = nil    ← FIX: Cleanup state
  └─ return error
s.mu.Unlock()
```

### Rebuild Failure
```
rebuildLoop(..., version=2)
Process entities... [PARTIAL SUCCESS]
  └─ Some entities: SUCCESS
  └─ Some entities: FAILED
  └─ Version 2 has partial data
  
CompleteEmbeddingJob() [OK]
ActivateEmbeddingVersion(2) [SKIP if error above]
  └─ If skip: active_version stays 1
  └─ If skip: Search still queries version 1
  └─ Version 2 remains inactive for inspection
```

---

## TESTING SCENARIOS

### Scenario 1: Successful Rebuild
```
Initial: v1 active, v2 building
Rebuild: All 1000 entities processed
Final: v2 activated, v1 retained for rollback
Search: Queries v2
```

### Scenario 2: Failed Rebuild (Partial)
```
Initial: v1 active, v2 building
Rebuild: 500/1000 entities done, error occurs
Final: v2 stays inactive, v1 remains active
Search: Still queries v1 (consistent)
```

### Scenario 3: Rate-limit Hit
```
Batch 1-5: Success (embeddings 1-125)
Batch 6: 429 rate-limit
  └─ Retry with key2 [logged: "rate limited, retrying"]
  └─ Success
  └─ Continue with remaining batches
Final: All embeddings stored, partial results preserved
```

### Scenario 4: Key Exhaustion
```
Requests 1-100: key1 (rate limited)
Requests 101-200: key2 (rate limited)
Requests 201-300: key3 (success)
  └─ Automatic rotation across all keys
  └─ Higher effective throughput
```

---

## PERFORMANCE IMPLICATIONS

### Storage
- **Before**: 1000 chunks after rebuild
- **After**: 2000 chunks (1000 v1 + 1000 v2) until cleanup
- **Cleanup**: Removes old versions, stays at 1000 chunks

### Query Time
- **Before**: Query all embeddings
- **After**: Query WHERE version=active (same, usually faster due to index)

### API Calls
- **Before**: Rate-limited, transient failures lose progress
- **After**: Multiple keys, retries preserve progress

---

## MIGRATION PATH

### From Old Schema
```sql
-- Existing: UNIQUE(entity_type, entity_id, chunk_index)
-- Migration adds: embedding_version field (DEFAULT 1)

-- Query: SELECT * FROM content_embeddings
-- Result: All rows have embedding_version=1
-- Treat as: Version 1 (active) from old system
-- Next rebuild: Version 2 created, eventually activated
```

---

## BACKWARD COMPATIBILITY

### API Changes
- Embedding generation endpoint: No changes (internal only)
- Storage service: StoreEmbedding signature changed (version parameter added)
- Callers: Must pass version parameter (done in rebuildLoop)

### Database
- All schema changes additive (new fields/constraints)
- Existing data preserved
- No breaking migrations

---

## MONITORING RECOMMENDATIONS

### Logs to Watch
```
"rate limited, retrying"  → Key rotation in progress
"batch embedding failed"  → Transient failure, check error
"rebuild complete and activated"  → Successful rebuild
"job error"  → Failed rebuild, version not activated
```

### Metrics to Track
```
active_version  → Which version search queries use
next_version  → What version is being built
rebuild_duration  → Time to complete rebuild
chunks_processed  → Entity count
rate_limit_retries  → How often 429 occurs
api_key_rotation  → Which keys are being used
```

### Alerts
```
- Rebuild fails: alert on job.status='failed'
- Version mismatch: active_version != expected
- Orphaned embeddings: version < active_version-1 after cleanup
- Context leaks: goroutine count increasing during rebuild
```

