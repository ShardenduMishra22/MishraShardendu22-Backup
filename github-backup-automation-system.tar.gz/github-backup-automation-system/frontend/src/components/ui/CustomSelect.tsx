"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronDown, Check } from "lucide-react";

export interface SelectOption {
  value: string;
  label: string;
}

interface CustomSelectProps {
  options: SelectOption[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  style?: React.CSSProperties;
}

export function CustomSelect({
  options,
  value,
  onChange,
  placeholder = "Select option...",
  className,
  style,
}: CustomSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const selectedOption = options.find((opt) => opt.value === value) || options[0];

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div
      ref={containerRef}
      style={{
        position: "relative",
        display: "inline-block",
        minWidth: "160px",
        ...style,
      }}
      className={className}
    >
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "10px",
          background: "var(--surface, #141210)",
          border: "1px solid var(--border, #282520)",
          borderRadius: "8px",
          padding: "8px 14px",
          color: "var(--text-primary, #f0ead6)",
          fontSize: "13px",
          fontWeight: 500,
          cursor: "pointer",
          transition: "all 0.15s ease",
          boxShadow: isOpen ? "0 0 0 2px rgba(139, 92, 246, 0.25)" : "none",
          borderColor: isOpen ? "var(--accent, #8b5cf6)" : "var(--border, #282520)",
        }}
      >
        <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {selectedOption ? selectedOption.label : placeholder}
        </span>
        <ChevronDown
          size={14}
          style={{
            color: "var(--text-muted, #78716c)",
            transition: "transform 0.2s ease",
            transform: isOpen ? "rotate(180deg)" : "rotate(0deg)",
            flexShrink: 0,
          }}
        />
      </button>

      {isOpen && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 4px)",
            left: 0,
            right: 0,
            zIndex: 9999,
            background: "var(--card-bg, #181614)",
            border: "1px solid var(--border, #282520)",
            borderRadius: "10px",
            padding: "4px",
            boxShadow: "0 12px 28px rgba(0, 0, 0, 0.6)",
            backdropFilter: "blur(8px)",
            minWidth: "100%",
            maxHeight: "220px",
            overflowY: "auto",
          }}
        >
          {options.map((opt) => {
            const isSelected = opt.value === value;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => {
                  onChange(opt.value);
                  setIsOpen(false);
                }}
                style={{
                  width: "100%",
                  textAlign: "left",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "8px 12px",
                  fontSize: "13px",
                  borderRadius: "6px",
                  border: "none",
                  background: isSelected
                    ? "rgba(139, 92, 246, 0.15)"
                    : "transparent",
                  color: isSelected
                    ? "#a78bfa"
                    : "var(--text-primary, #f0ead6)",
                  fontWeight: isSelected ? 600 : 400,
                  cursor: "pointer",
                  transition: "background 0.1s ease",
                }}
                onMouseEnter={(e) => {
                  if (!isSelected) {
                    (e.currentTarget as HTMLElement).style.background =
                      "var(--surface, #141210)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isSelected) {
                    (e.currentTarget as HTMLElement).style.background =
                      "transparent";
                  }
                }}
              >
                <span>{opt.label}</span>
                {isSelected && <Check size={14} style={{ color: "#a78bfa" }} />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
