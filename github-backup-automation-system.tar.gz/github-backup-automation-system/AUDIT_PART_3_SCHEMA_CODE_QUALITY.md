# PHASE 2 IMPLEMENTATION AUDIT - PART 3

## CHECK 8: Normalization & Schema Design

### Finding: CRITICAL ISSUE - embedding_config is NOT Singleton-Safe

**Severity**: CRITICAL

**File**: `backend/db/schema.sql` (lines 67-81)

**Issue**:
```sql
CREATE UNIQUE INDEX IF NOT EXISTS idx_embedding_config_singleton ON embedding_config(id) 
    WHERE id = 1;
```

**Problem**: UNIQUE INDEX is NOT a constraint that prevents insert of id=2.

```sql
INSERT INTO embedding_config (id=2, provider='openai', ...) -- SUCCEEDS
INSERT INTO embedding_config (id=2, provider='cohere', ...) -- FAILS (good)
```

The WHERE clause makes it a PARTIAL INDEX. It only enforces uniqueness on id=1, but multiple rows with id != 1 are allowed.

**Current Code** (embedding.db.go line 17):
```go
func GetEmbeddingConfig(ctx context.Context) (*models.EmbeddingConfig, error) {
    var config models.EmbeddingConfig
    err := Pool.QueryRow(ctx, `
        SELECT ... FROM embedding_config WHERE id = 1  // Assumes id=1 exists
    `)
```

If someone inserts id=2 or id=3, GetEmbeddingConfig still returns id=1 correctly, but the table is no longer truly singleton.

**Recommended Fix**:
Replace the index with a CHECK constraint:
```sql
ALTER TABLE embedding_config ADD CONSTRAINT check_singleton CHECK (id = 1);
```

Or use a trigger to prevent non-id=1 rows.

**Current Impact**: LOW - code correctly assumes id=1, so this is defensive against buggy migration code, not a runtime bug.

---

## CHECK 8b: Normalization - denormalization Check

### Finding: GOOD - No Unnecessary Denormalization

**Severity**: NONE (PASS)

**Schema Analysis**:

✓ **No data duplication**: 
- embedding_config: singleton (1 row)
- content_embeddings: 1 row per chunk
- embedding_jobs: 1 row per job
- vector_searches: 1 row per search

✓ **No nullable fields that shouldn't be**:
- embedding_config.last_error: nullable (correct - no error initially)
- embedding_config.last_reindexed_at: nullable (correct - no reindex initially)
- embedding_config.rerank_model: nullable (correct - reranking disabled)
- embedding_jobs.completed_at: nullable (correct - not yet complete)
- embedding_jobs.error_message: nullable (correct - no error yet)

✓ **Reasonable defaults**:
- created_at/updated_at: NOW() default (good)
- status fields: NOT NULL with CHECK constraints (good)
- counts: 0 defaults for progress tracking (good)

✓ **No suspicious denormalization**:
- No copying of embedding_model into each row
- No duplicating search results into cache table
- No precomputed aggregates

**Status**: GOOD - Schema is normalized to 3NF.

---

## CHECK 9: Logging - Operational Information

### Finding: GOOD LOGGING - Progress, Failures, Retries Covered

**Severity**: NONE (PASS)

**File**: `backend/service/embedding/service.go`

**Progress Logging** (lines 163-164):
```go
s.logger.InfoContext(ctx, "starting rebuild", "job_id", jobID)
```
✓ Logs job start

(lines 246-253):
```go
if processedEntities%10 == 0 {
    if err := db.UpdateEmbeddingJob(ctx, jobID, "processing", ...) {
        s.logger.WarnContext(ctx, "failed to update job", "error", err)
    }
}
```
✓ Updates database every 10 entities
✓ Logs job update failures
✓ No console spam (batched)

(lines 274-283):
```go
s.logger.InfoContext(ctx, "rebuild complete",
    "job_id", jobID,
    "total_entities", totalEntities,
    "processed_entities", processedEntities,
    "total_chunks", totalChunks,
    "processed_chunks", processedChunks,
    "failed_chunks", failedChunks)
```
✓ Detailed completion stats

**Failure Logging** (lines 206-210):
```go
err := builder.Build(ctx, entityID)
if err != nil {
    s.logger.WarnContext(ctx, "failed to build content", 
        "type", entityType, "id", entityID, "error", err)
```
✓ Per-entity failure logs with type+id context

(lines 226-230):
```go
err = s.storageService.TransactionalStore(ctx, ...)
if err != nil {
    s.logger.WarnContext(ctx, "failed to store embeddings",
        "type", entityType, "id", entityID, "error", err)
```
✓ Storage failures logged

**Retry Logging** (generator.go lines 48-72):
```go
// No explicit retry logging
// Failures are silent - retry happens internally
```

**Finding: MINOR ISSUE - Retry Attempts Not Logged**

**Severity**: LOW

When rate-limited, the generator retries silently:
```go
if strings.Contains(err.Error(), "429") || strings.Contains(err.Error(), "rate limit") {
    if attempt < eg.maxRetries {
        // Backoff and retry, but NO LOG
        select {
        case <-time.After(backoff):
            // Retry on next loop iteration - silent
        }
    }
}
```

**Impact**: Operators can't see rate-limit retries in logs.

**Recommended Fix**: Add logging for rate-limit retries:
```go
s.logger.WarnContext(ctx, "rate limited, retrying", 
    "attempt", attempt+1, "maxRetries", eg.maxRetries, "backoff_ms", backoff.Milliseconds())
```

**Cancellation Logging** (service.go line 193):
```go
case <-ctx.Done():
    s.handleJobError(ctx, jobID, "cancelled by user")
    return
```
✓ Logs cancellation

**Status**: GOOD logging overall, minor gap on retry attempts.

---

## CHECK 10: Code Quality Review

### Finding: GOOD CODE - Clean Architecture, Some Duplication

**Severity**: NONE (PASS with minor notes)

**File Analysis**:

### Duplicated Code - getEntityIDsForType (service.go lines 295-379)

```go
func (s *Service) getEntityIDsForType(ctx context.Context, entityType string) ([]string, error) {
    switch entityType {
    case "investigation":
        rows, err := s.pool.Query(ctx, "SELECT id FROM investigations ORDER BY id")
        // ... 10 lines repeated
    case "backup_fix":
        rows, err := s.pool.Query(ctx, "SELECT id FROM backup_fixes ORDER BY id")
        // ... same 10 lines
    case "execution_log":
        rows, err := s.pool.Query(ctx, "SELECT id FROM execution_logs ORDER BY id")
        // ... same 10 lines again
    // ... 3 more times
    }
}
```

**Issue**: 45 lines of copy-paste code. Same pattern repeated 5 times.

**Recommended Refactor**:
```go
var tables = map[string]string{
    "investigation": "investigations",
    "backup_fix": "backup_fixes",
    "execution_log": "execution_logs",
    "analytics_snapshot": "analytics_snapshots",
    "backup_run": "backup_runs",
}

func (s *Service) getEntityIDsForType(ctx context.Context, entityType string) ([]string, error) {
    table, ok := tables[entityType]
    if !ok {
        return nil, fmt.Errorf("unknown entity type: %s", entityType)
    }
    
    query := fmt.Sprintf("SELECT id FROM %s ORDER BY id", table)  // Note: %s safe - hardcoded table names
    rows, err := s.pool.Query(ctx, query)
    if err != nil {
        return nil, err
    }
    defer rows.Close()
    
    var ids []string
    for rows.Next() {
        var id string
        if err := rows.Scan(&id); err != nil {
            return nil, err
        }
        ids = append(ids, id)
    }
    return ids, rows.Err()
}
```

Reduces 85 lines to 25 lines. Easier to maintain.

### Builder Duplication (builders.go)

Each builder has similar pattern:
1. Query database
2. Scan fields
3. Format title and content
4. Return

This is OK - DRY doesn't apply when implementations differ per builder. EntityBuilder interface is appropriate abstraction.

### Giant Function - rebuildLoop

**Severity**: MEDIUM

Lines 160-283 in service.go. The rebuildLoop is 124 lines.

Structure:
- Load config (3 lines)
- Clear embeddings (3 lines)
- Loop entity types (100 lines)
  - Enumerate entities (10 lines)
  - For each entity:
    - Build (5 lines)
    - Chunk (5 lines)
    - Generate (5 lines)
    - Store (15 lines)
    - Update progress (5 lines)
- Complete job (5 lines)

**Recommended Refactoring**: Extract inner loop into `processEntity()` method:
```go
func (s *Service) processEntity(ctx context.Context, builder EntityBuilder, 
    entityType, entityID string) error {
    // Build, chunk, generate, store, return error
}
```

Then rebuildLoop becomes:
```go
for _, entityID := range entityIDs {
    if err := s.processEntity(ctx, builder, entityType, entityID); err != nil {
        failedChunks++
        continue
    }
    processedChunks += len(chunks)
}
```

Makes the main loop readable and testable.

### Naming Issues

**Good Naming**:
- ChunkingService, EmbeddingGenerator, StorageService - clear purpose
- EntityBuilder interface - clear contract
- rebuildLoop - clear it's internal
- ClearAllEmbeddings - clear what it does

**Adequate Naming**:
- cfg for config - short, OK in context
- charlesLen/charlesWidth - not present, good

**No Naming Issues Found**

### Unnecessary Abstractions

**Concern**: Is the ChunkingRegistry interface necessary?

```go
type ChunkingRegistry interface {
    GetStrategy(entityType string) string
    GetChunkSize(entityType string) int
    GetChunkOverlap(entityType string) int
}
```

**Verdict**: APPROPRIATE - allows:
1. Dependency injection for testing
2. Swapping strategies at runtime
3. Configuration-driven chunking

The DefaultChunkingRegistry implementation shows this is extensible design.

### Error Handling

**Good**:
```go
if err != nil {
    return 0, fmt.Errorf("create job: %w", err)  // Wraps context
}
```
All errors wrapped with context using %w.

**Good**:
```go
select {
case <-ctx.Done():
    return nil, ctx.Err()
default:
}
```
Context cancellation checked at critical points.

**Code Quality Status**: GOOD - well-structured, some duplication to refactor (non-critical).

