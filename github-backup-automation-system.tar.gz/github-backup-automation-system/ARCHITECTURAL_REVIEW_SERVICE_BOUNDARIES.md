# Architectural Review: Service Boundaries

**Date**: 2026-08-02  
**Scope**: Go Backend vs Python Agentic Backend separation  
**Status**: VIOLATIONS IDENTIFIED - REFACTORING REQUIRED

## Executive Summary

The current implementation violates the established service boundary principles. **The Go backend has directly implemented AI-specific functionality that should reside exclusively in the Python backend.** This creates tight coupling, duplicates logic, and makes it impossible to change AI providers without modifying multiple services.

**Critical Violations Found**: 3 major, 2 supporting architectural anti-patterns

---

## Service Boundary Principle (Approved)

### Go Backend Owns
- ✅ Persistence (PostgreSQL)
- ✅ Retrieval (queries, searches)
- ✅ Jobs & scheduling
- ✅ APIs (HTTP endpoints)
- ✅ Configuration management
- ✅ Telemetry & logging
- ✅ **CALLING** AI services via internal endpoints

### Python Backend Owns
- ✅ All AI-specific functionality
- ✅ OpenRouter communication
- ✅ Embedding generation
- ✅ Reranking
- ✅ Model discovery
- ✅ Tool calling & agent workflows
- ✅ Provider abstraction (swap providers in one place)

---

## Critical Violations Identified

### **VIOLATION 1: OpenRouter Client in Go Backend**

**Location**: `backend/service/openrouter/client.go`  
**Severity**: CRITICAL  
**Impact**: Direct vendor lock-in to Go; AI logic not centralized

#### What Exists Now
```
Go Backend
  ├── service/openrouter/
  │   └── client.go              ← Direct OpenRouter API calls
  │       ├── GetAvailableModels()
  │       ├── GetEmbeddingModels()
  │       ├── GetRerankerModels()
  │       ├── CreateEmbedding()
  │       └── IsAvailable()
  └── service/embedding/
      └── generator.go           ← Uses openrouter.Client directly
```

#### The Problem
- Go backend **directly calls OpenRouter API** (Bearer token, HTTP)
- Model discovery happens in Go (`GetAvailableModels()`, `GetEmbeddingModels()`)
- Embedding generation happens in Go (`CreateEmbedding()`)
- **Consequence**: Changing from OpenRouter to Anthropic/Hugging Face requires rewriting Go code
- **Consequence**: Python backend can't participate in model selection decisions
- **Consequence**: Duplicate logic if Python also needs models

#### Why This Violates Principles
- AI provider logic should be **centralized in Python only**
- Go should be **agnostic to which AI provider** is used
- Go should **only call internal Python endpoints**, not external APIs

#### Required Architecture
```
Go Backend                          Python Backend
┌──────────────────┐               ┌──────────────────────────┐
│ POST /internal/  │──────HTTP──→  │ /internal/models         │
│    models        │               │ (queries OpenRouter)     │
│                  │               │                          │
└──────────────────┘               │ /internal/embed          │
                                   │ (generates embeddings)   │
                                   │                          │
                                   │ /internal/rerank         │
                                   │ (reranks candidates)     │
                                   │                          │
                                   │ OpenRouter API ──→ 🌐    │
                                   └──────────────────────────┘
```

---

### **VIOLATION 2: Embedding Generation in Go Backend**

**Location**: `backend/service/embedding/`  
**Files**:
- `generator.go` - Embedding generation logic
- `service.go` - Rebuild orchestration
- `storage.go` - Vector storage

**Severity**: CRITICAL  
**Impact**: AI orchestration logic split between services; violates single responsibility

#### What Exists Now
```
backend/service/embedding/
├── service.go         ← StartRebuild(), rebuildLoop()
├── generator.go       ← GenerateEmbeddings(), BatchGenerateEmbeddings()
├── chunking.go        ← ChunkContent() strategies
└── storage.go         ← StoreEmbedding(), TransactionalStore()
```

#### Current (Wrong) Flow
```
Rebuild Request → Go Backend
                    ├─ Load config
                    ├─ Get entity IDs from DB
                    ├─ Build content
                    ├─ Chunk text                    (← Should be Python)
                    ├─ Call OpenRouter.CreateEmbedding()  (← Should be internal Python endpoint)
                    └─ Store vectors in DB
```

#### The Problem
- Go backend **directly orchestrates** the entire embedding pipeline
- Chunking strategies are hardcoded in Go (`semantic`, `fixed`, `markdown`, `none`)
- Embedding model selection happens in Go
- Retry logic for rate limits is in Go
- **Consequence**: If changing chunking strategy, need to modify Go
- **Consequence**: If changing embedding model, need to redeploy Go
- **Consequence**: Python backend has no say in AI decisions

#### Required Architecture
```
Correct Flow:
Rebuild Request → Go Backend
                    ├─ Load config from DB
                    ├─ Get entity IDs from DB
                    ├─ For each entity:
                    │   ├─ Build content (Go owns)
                    │   └─ POST /internal/process-entity
                    │       └─ Python Backend
                    │           ├─ Chunk text
                    │           ├─ Generate embeddings (OpenRouter)
                    │           ├─ Return vectors
                    │
                    └─ Store vectors in DB (Go owns)
```

---

### **VIOLATION 3: Model Discovery in Go Backend**

**Location**: `backend/service/openrouter/client.go`  
**Functions**:
- `GetAvailableModels()` - Lists all OpenRouter models
- `GetEmbeddingModels()` - Filters for embeddings
- `GetRerankerModels()` - Filters for reranking

**Severity**: CRITICAL  
**Impact**: AI decision-making centralized in wrong service

#### The Problem
- Configuration UI needs to show available embedding models
- Currently, Go backend queries OpenRouter to populate UI
- **Go makes the decision** of which models to offer
- Python backend never knows what models were selected
- **Consequence**: Python can't reason about selected model unless it queries Go

#### Required Architecture
```
Frontend
  ├─ GET /api/models/embeddings
  │  └─ Go Backend
  │     └─ GET /internal/models/embeddings
  │        └─ Python Backend
  │           ├─ Query OpenRouter API
  │           ├─ Filter for embeddings
  │           └─ Return model list
  │
  └─ UI shows available models (sourced from Python)
```

---

## Supporting Anti-Patterns

### **Issue A: No Internal Endpoints Defined**

The Go backend **has no `/internal/` endpoints** for Python to call. Python backend is isolated; Go doesn't even have a mechanism to receive requests from Python.

**Current State**: Zero internal API contract  
**Required**: Define internal endpoints that Python will call

### **Issue B: Embedding Generator Couples to OpenRouter**

`backend/service/embedding/generator.go` imports and directly uses `openrouter.Client`:
```go
type EmbeddingGenerator struct {
	client *openrouter.Client  ← Tightly coupled
	...
}

embeddings, err := eg.client.CreateEmbedding(ctx, model, texts)  ← Direct call
```

**Should be**: HTTP call to internal Python endpoint, agnostic to which library Python uses

---

## Refactoring Plan

### Phase 1: Move OpenRouter Communication to Python (LOW EFFORT)
1. ✅ Move `backend/service/openrouter/client.go` → `agentic-observatory/` (already there? validate)
2. ✅ Python: Create `/internal/models` endpoint (list all OpenRouter models)
3. ✅ Python: Create `/internal/models/embeddings` endpoint (filter for embeddings)
4. ✅ Python: Create `/internal/models/rerankers` endpoint (filter for reranking)
5. ✅ Go: Remove `backend/service/openrouter/`
6. ✅ Go: Update routes to call Python endpoints

### Phase 2: Move Embedding Generation to Python (MEDIUM EFFORT)
1. ✅ Python: Create `/internal/embed` endpoint
   - Input: `{model, texts, batch_size}`
   - Output: `{embeddings: [[...], [...]], tokens_used}`
   - Handles chunking, rate limits, retries
2. ✅ Go: Update `generator.go` to call `POST /internal/embed`
3. ✅ Python: Move chunking logic from Go (or create new `__internal/chunk` endpoint)
4. ✅ Test: Verify Go embedding rebuild still works

### Phase 3: Define Internal API Contract (LOW EFFORT)
1. ✅ Document `/internal/` endpoints in `agentic-observatory/README.md`
2. ✅ Specify authentication (internal-only, e.g., shared secret)
3. ✅ Specify error codes and retry semantics
4. ✅ Add OpenAPI/Swagger docs for internal API

### Phase 4: Remove AI Logic from Go (CLEANUP)
1. ✅ Delete unused `backend/service/embedding/generator.go`
2. ✅ Delete unused `backend/service/openrouter/`
3. ✅ Delete unused `backend/service/chunking/`
4. ✅ Keep only `backend/service/embedding/storage.go` (for DB operations)

---

## Validation Checklist

After refactoring, verify:

- [ ] **No OpenRouter imports in Go code** (`grep -r "openrouter" backend/`)
- [ ] **No embedding generation code in Go** (`grep -r "CreateEmbedding" backend/`)
- [ ] **Go calls only internal Python endpoints** for AI features
- [ ] **Python backend has all OpenRouter communication** (models, embeddings, reranking)
- [ ] **Model selection happens in Python** (Python owns "which model is active")
- [ ] **Chunking strategies centralized in Python**
- [ ] **Retry logic centralized in Python**
- [ ] **Go backend is agnostic to AI provider** (could swap to Anthropic without changing Go)
- [ ] **All embedding rebuild tests still pass**
- [ ] **Model list endpoint works** (`GET /api/models/embeddings` returns results)

---

## Risk Assessment

### Low Risk (Safe to Refactor Immediately)
- Moving OpenRouter client → Python
- Creating internal endpoints in Python
- Go backend calling Python endpoints

### No Backward Compatibility Issues
- Internal endpoints don't exist yet, so nothing breaks
- Go backend can be updated incrementally
- All changes are internal, frontend sees no change

### Testing Strategy
1. Unit tests: Verify internal endpoints in Python
2. Integration tests: Verify Go calls work
3. E2E tests: Verify embedding rebuild produces same results
4. Regression tests: Verify search/retrieval unaffected

---

## Timeline Estimate

| Phase | Effort | Time | Blocking |
|-------|--------|------|----------|
| 1: Move OpenRouter | Low | 1-2h | No |
| 2: Move Embedding Gen | Medium | 2-3h | No |
| 3: Document Internal API | Low | 1h | No |
| 4: Cleanup Go | Low | 30m | No |
| **TOTAL** | **Medium** | **4-6h** | **No** |

**Can proceed in parallel with audit fixes**. This refactoring doesn't require blocking on audit completions.

---

## Conclusion

**Current State**: ❌ Architecture violated  
**Required Action**: Refactor to move all AI logic to Python  
**Effort**: 4-6 hours  
**Risk**: Low (internal changes only)  
**Benefit**: Clean boundaries, single source of truth for AI decisions, ability to swap providers

Once complete, the architecture will correctly enforce:
- **Go**: Data layer, retrieval, APIs, configuration
- **Python**: AI orchestration, provider integration, model selection

