# PHASE 2 IMPLEMENTATION AUDIT - PART 2

## CHECK 4: OpenRouter Integration - Error Handling & Cancellation

### Finding: MEDIUM ISSUE - Batch Failure Invalidates All Chunks

**Severity**: MEDIUM

**File**: `backend/service/embedding/generator.go` (lines 71-117)

**Issue 1: Batch Failure Loses Progress**
```go
// Lines 88-96
for i := 0; i < len(texts); i += batchSize {
    ...
    batch := texts[i:end]
    embeddings, err := eg.GenerateEmbeddings(ctx, model, batch)
    if err != nil {
        return nil, fmt.Errorf("batch %d: %w", i/batchSize, err)  // ALL batches lost
    }
    allEmbeddings = append(allEmbeddings, embeddings...)
```

If batch 5 of 10 fails, embeddings from batches 1-4 are discarded. No partial progress.

**Impact**: 
- Large entities with 100+ chunks: if batch 50 fails, all 49 prior batches wasted
- Retry must restart entire entity from scratch
- Inefficient and wastes API quota

**Issue 2: Timeout Not Enforced**
The underlying OpenRouter client has 30s timeout, but:
- No per-batch timeout
- No cumulative timeout for entity
- Long-running batch could timeout mid-operation

**Issue 3: Context Cancellation Propagated Correctly**
```go
// Line 83-86, 106-109
select {
case <-ctx.Done():
    return nil, ctx.Err()
default:
}
```
✓ GOOD - Cancellation checked at batch boundaries
✓ GOOD - Inter-batch delay respects context

**Recommended Fix**:
1. Collect successful batches even after error
2. Return partial results with error indicator
3. Let entity-level storage handle partial embeddings
4. Add per-batch timeout in addition to connection timeout

---

## CHECK 5: Chunking - Registry as Single Source of Truth

### Finding: GOOD IMPLEMENTATION - Registry Pattern Correct

**Severity**: NONE (PASS)

**File**: `backend/service/embedding/chunking.go`

**Verification**:

✓ **Single Source of Truth**: DefaultChunkingRegistry is the only place entity strategies are defined (lines 107-152)

✓ **Deterministic Hashing**: SHA256 used (line 63), consistent for same content

✓ **Entity-Specific Configuration**:
```
investigation    → semantic, 1024 tokens
backup_fix       → semantic, 1024 tokens  
execution_log    → fixed, 256 tokens
analytics_snapshot → fixed, 512 tokens
backup_run       → semantic, 512 tokens
```

✓ **Duplicate Detection via Hash**: Hash is computed but...

**Finding: MINOR ISSUE - Chunk Hash Not Actually Used for Deduplication**

**Severity**: LOW

The chunk hash is computed:
```go
// Line 32: Chunk has Hash field
type Chunk struct {
    Hash string  // SHA256 hash
}
```

But the hash is NEVER used to detect duplicates:
1. No deduplication logic in ChunkingService
2. Storage layer does NOT skip duplicate chunks (ON CONFLICT just UPSERTs)
3. Same content chunked twice will create duplicate rows with different timestamps

**Impact**: 
- If entity rebuilt multiple times, chunk table grows
- No prevention of duplicate embeddings
- Query performance degradation

**Recommended Fix**:
1. Add dedup logic in storage layer: check hash before insert
2. OR: Make hash part of primary key instead of (entity_type, entity_id, chunk_index)
3. OR: Skip storing if hash already exists in database

**Current Status**: Hashing works correctly, but deduplication logic missing.

---

## CHECK 6: Entity Builders - Information Completeness

### Finding: GOOD IMPLEMENTATIONS - Coverage Adequate for Retrieval

**Severity**: NONE (PASS with notes)

**Verification**:

### Investigation Builder (lines 8-40)
✓ Extracts: question, answer, status, created_at
✓ Title: question (first 100 chars) - good for display
✓ Content: formatted with all fields

**Good**: Question/answer are the key searchable content for investigations.
**Could improve**: None - adequate for retrieval quality.

### BackupFix Builder (lines 42-73)
✓ Extracts: title, description, commit_hash, author, created_at
✓ Title: title field
✓ Content: full structured format

**Good**: Title + description + author = comprehensive search surface
**Note**: commit_hash included for lineage tracking
**Could improve**: None - adequate.

### ExecutionLog Builder (lines 75-103)
✓ Extracts: level, message, repository, created_at
✓ Title: "[LEVEL] repository" - good for display
✓ Content: structured with all fields

**Good**: Message is searchable, level indicates severity
**Could improve**: Could include stack traces if available in schema

### AnalyticsSnapshot Builder (lines 105-147)
✓ Extracts: 9 metrics fields
✓ Title: "Analytics: YYYY-MM-DD"
✓ Content: structured metrics dump

**Good**: All numeric metrics are searchable
**Could improve**: Could compute summary stats (e.g., "1000 commits, 50 branches")

### BackupRun Builder (lines 149-186)
✓ Extracts: status, totals, results, error_message, started_at
✓ Title: "Backup Run {id}: {status}"
✓ Content: structured summary

**Good**: Success/failure stats searchable, error messages included
**Could improve**: None - adequate.

**Overall**: All builders extract key information. No critical information missing.

---

## CHECK 7: Storage - UPSERT Logic & Integrity

### Finding: GOOD IMPLEMENTATION - Transaction Safety Solid

**Severity**: NONE (PASS)

**File**: `backend/service/embedding/storage.go`

**Verification**:

### UPSERT Logic (lines 28-55)
```sql
INSERT INTO content_embeddings 
(entity_type, entity_id, chunk_index, chunk_text, chunk_hash, embedding, created_at, updated_at)
VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
ON CONFLICT (entity_type, entity_id, chunk_index) DO UPDATE SET
  chunk_text = $4, chunk_hash = $5, embedding = $6, updated_at = NOW()
```

✓ Conflict key is UNIQUE(entity_type, entity_id, chunk_index) - correct
✓ Updates all fields on conflict - idempotent
✓ Preserves created_at on update - good practice
✓ Updates updated_at - good for audit

### Transaction Handling (lines 130-146)
```go
func (ss *StorageService) TransactionalStore(ctx context.Context, fn func(...) error) error {
    tx, err := ss.pool.Begin(ctx)
    if err != nil {
        return fmt.Errorf("begin transaction: %w", err)
    }
    defer tx.Rollback(ctx)  // Rollback is deferred - safe
    
    if err := fn(ctx, tx); err != nil {
        return err  // Rollback happens via defer
    }
    
    if err := tx.Commit(ctx); err != nil {
        return fmt.Errorf("commit transaction: %w", err)
    }
    
    return nil
}
```

✓ Deferred rollback pattern - exception-safe
✓ Rollback called before commit attempt - safe order
✓ Commit checked for errors - not ignored

### Foreign Keys
The schema HAS NO foreign key constraints on (entity_type, entity_id):
```sql
entity_type TEXT NOT NULL,
entity_id TEXT NOT NULL,
```

No FK to any entities table. This means:
- Orphaned embeddings possible if entity deleted
- Rebuild doesn't validate entity exists first
- But this matches design (embeddings are standalone searchable index)

### Indexes (schema.sql lines 101-110)
```sql
CREATE INDEX IF NOT EXISTS idx_content_embeddings_entity 
    ON content_embeddings(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_content_embeddings_hash 
    ON content_embeddings(chunk_hash);
CREATE INDEX IF NOT EXISTS idx_content_embeddings_vector 
    ON content_embeddings USING ivfflat (embedding vector_cosine_ops);
```

✓ Entity index - fast lookup for entity-specific queries
✓ Hash index - fast dedup check (though not used currently)
✓ Vector index - IVFFlat for fast similarity search

**Storage Status**: GOOD - transactions are safe, UPSERT is idempotent, indexes are appropriate.

