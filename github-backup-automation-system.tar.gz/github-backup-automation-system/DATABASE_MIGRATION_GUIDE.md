# DATABASE CLEANUP & SCHEMA MIGRATION GUIDE

## SITUATION

The database contains **OLD embedding infrastructure** that interferes with the NEW schema:

```
OLD (Existing):
  - embedding_configs (6 rows, wrong schema)
  - content_embeddings (329 rows, wrong schema)

NEW (Expected, not created):
  - embedding_config (singular, new schema)
  - embedding_jobs (missing)
  - vector_searches (missing)
  - content_embeddings (NEW schema, clean)
```

The new schema.sql uses `CREATE TABLE IF NOT EXISTS`, so it skips creation when old tables exist with different names/schemas.

---

## SAFE MIGRATION STEPS

### Step 1: Backup (Recommended)
```bash
# Create a database backup before proceeding
pg_dump "$POSTGRES_URL" > embedding_backup_$(date +%Y%m%d_%H%M%S).sql
```

### Step 2: Run Cleanup Migration

Option A: Using Go tool (recommended)
```bash
cd /home/mishrashardendu22/Resume-Projects/GitHub-BackUp-Script/backend
go run tools/migrate.go -cleanup -dry-run    # See what will happen
go run tools/migrate.go -cleanup             # Execute the migration
```

Option B: Manual SQL (if tool not available)
```sql
-- Rename old tables
ALTER TABLE IF EXISTS embedding_configs RENAME TO embedding_configs_deprecated;
ALTER TABLE IF EXISTS content_embeddings RENAME TO content_embeddings_deprecated;
```

### Step 3: Verify Cleanup
```bash
cd /home/mishrashardendu22/Resume-Projects/GitHub-BackUp-Script
go run /tmp/inspect_db.go
```

Expected output after cleanup:
```
✗ embedding_configs (renamed to embedding_configs_deprecated)
✓ content_embeddings (OLD schema, renamed to content_embeddings_deprecated)
```

### Step 4: Restart Backend Server
```bash
# Stop backend
pkill -f "github-backup/backend"

# Wait 2 seconds
sleep 2

# Start backend (will run schema.sql and create new tables)
cd backend && go run main.go
# or
cd backend && ./backend
```

### Step 5: Verify New Schema Created
```bash
cd /home/mishrashardendu22/Resume-Projects/GitHub-BackUp-Script
go run /tmp/inspect_db.go
```

Expected output:
```
=== TABLES IN PUBLIC SCHEMA ===
  - ai_chat_messages
  - ai_chat_sessions
  - ai_tool_calls
  - analytics_snapshots
  - backup_fixes
  - backup_results
  - backup_run_fixes
  - backup_runs
  - content_embeddings (NEW - clean schema)
  - content_embeddings_deprecated (OLD - preserved)
  - embedding_config (NEW - 1 row)
  - embedding_configs_deprecated (OLD - preserved)
  - embedding_jobs (NEW - created)
  - execution_logs
  - investigations
  - vector_searches (NEW - created)

=== EMBEDDING TABLE DETAILS ===

Table: embedding_config
  ✓ Table exists
    - id (integer, nullable=NO)
    - provider (text, nullable=NO)
    - embedding_model (text, nullable=NO)
    - embedding_dimensions (integer, nullable=NO)
    - rerank_enabled (boolean, nullable=NO)
    - rerank_model (text, nullable=YES)
    - status (text, nullable=NO)
    - last_reindexed_at (timestamp with time zone, nullable=YES)
    - last_error (text, nullable=YES)
    - created_at (timestamp with time zone, nullable=NO)
    - updated_at (timestamp with time zone, nullable=NO)
```

### Step 6: Cleanup Old Tables (After Verification)

Once you've verified that the NEW schema is working correctly:

```bash
cat > /tmp/cleanup_old.sql << 'EOF'
DROP TABLE IF EXISTS embedding_configs_deprecated CASCADE;
DROP TABLE IF EXISTS content_embeddings_deprecated CASCADE;
EOF

# Run it
go run backend/tools/migrate.go  # Will add cleanup command
```

Or manually:
```sql
DROP TABLE embedding_configs_deprecated CASCADE;
DROP TABLE content_embeddings_deprecated CASCADE;
```

---

## WHAT CHANGED & WHY

### Why Old Tables Weren't Removed
- Old `embedding_configs` table existed with different schema
- Old `content_embeddings` table existed with different structure
- New schema.sql uses `CREATE TABLE IF NOT EXISTS`
- When migration ran, it found existing tables and skipped creation
- Different table names (`embedding_configs` vs `embedding_config`) prevented collision detection

### Why Rename Instead of Drop
- **Preserves data** for verification/rollback
- **Non-destructive** - can be undone if needed
- **Safe** - old data is isolated in _deprecated tables
- **Allows rollback** - can rename back if issues arise
- **Testing** - can compare old vs new schemas during Phase 1

### Why NOT Migrate Old Data
- Old and new schemas are fundamentally different
- Old uses UUID + FK references to embedding_configs
- New uses entity_type + entity_id directly
- Data mapping would be complex and error-prone
- Better to start fresh with new schema
- Old data preserved if needed for reference

---

## ROLLBACK PROCEDURE

If something goes wrong and you need to rollback:

```sql
-- Undo the cleanup (restore old names)
ALTER TABLE IF EXISTS embedding_configs_deprecated RENAME TO embedding_configs;
ALTER TABLE IF EXISTS content_embeddings_deprecated RENAME TO content_embeddings;

-- Drop the new schema tables (optional)
DROP TABLE IF EXISTS embedding_config CASCADE;
DROP TABLE IF EXISTS embedding_jobs CASCADE;
DROP TABLE IF EXISTS vector_searches CASCADE;
DROP TABLE IF EXISTS content_embeddings CASCADE;
```

Then restart the backend.

---

## TROUBLESHOOTING

### Error: "relation 'embedding_configs' already exists"
- New schema.sql is trying to create a table that already exists
- **Solution**: Run cleanup migration first

### Error: "cannot drop table (foreign keys reference it)"
- Old tables have dependent objects
- **Solution**: Use `CASCADE` keyword (included in cleanup script)

### New tables not created after restart
- Backend might not have restarted properly
- Check logs: `backend.log` or console output
- Verify POSTGRES_URL is set: `echo $POSTGRES_URL`
- Try restarting manually

### Old data still visible
- That's expected! _deprecated tables preserve the data
- Drop them only when you're sure they're not needed

---

## VERIFICATION QUERIES

After migration, you can verify the schema manually:

```sql
-- List all embedding tables
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema='public' AND table_name LIKE '%embedding%'
ORDER BY table_name;

-- Check new embedding_config
SELECT * FROM embedding_config;

-- Check new content_embeddings schema
\d content_embeddings

-- Count rows in each table
SELECT 'embedding_config' as table_name, COUNT(*) as row_count FROM embedding_config
UNION ALL
SELECT 'content_embeddings', COUNT(*) FROM content_embeddings
UNION ALL
SELECT 'embedding_jobs', COUNT(*) FROM embedding_jobs
UNION ALL
SELECT 'vector_searches', COUNT(*) FROM vector_searches;
```

---

## NEXT STEPS

After successful migration:

1. ✓ Cleanup migration executed
2. ✓ Backend restarted and schema.sql applied
3. ✓ New tables created with correct schema
4. ✓ Old tables renamed to _deprecated
5. **Next**: Continue with Phase 2 implementation
6. **Later**: Drop _deprecated tables after confirming everything works

---

**DO NOT PROCEED TO PHASE 2 UNTIL THIS MIGRATION IS COMPLETE AND VERIFIED**
