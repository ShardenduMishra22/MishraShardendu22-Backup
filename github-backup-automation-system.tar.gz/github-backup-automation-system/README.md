# GitHub Backup Observatory

> This project was open source, but it is now closed source. Only the project details and documentation are available here, and not the underlying code. We hope to open source it again someday.

## Overview

This application is a backup and monitoring system for GitHub repositories. Its purpose is to protect important repository content by creating reliable backup snapshots and keeping a clear history of what happened.

## What it does

The system helps with four main tasks:

1. It looks at selected GitHub repositories.
2. It checks whether anything has changed since the last backup.
3. When needed, it creates a fresh backup snapshot and stores it safely.
4. It records the backup activity so the status and history are easy to review.

## How it works

The process is simple and repeatable:

1. The system identifies the repositories that should be backed up.
2. It compares the latest state with the previous backup.
3. If changes are present, it creates a new protected snapshot.
4. It keeps a record of each backup run and its result.
5. The user can review the latest status, recent activity, and overall backup health.

## Why it is useful

This system helps prevent data loss, reduces the effort of managing backups manually, and makes backup activity visible and understandable.

## Who it is for

It is designed for anyone who wants a dependable way to preserve GitHub repository content and monitor backup progress over time.

## Summary

In short, this application exists to make repository backups easier, safer, and more transparent.