# PHASE 2 IMPLEMENTATION AUDIT - PART 1

## CHECK 1: Rebuild Workflow - embedding_version

### Finding: CRITICAL ISSUE - embedding_version NOT IMPLEMENTED

**Severity**: CRITICAL

**File**: `backend/service/embedding/service.go`

**Issue**:
The rebuild workflow does not implement embedding_version tracking as specified in the approved architecture. The system:

1. Does NOT load embedding_version from config
2. Does NOT tag generated embeddings with a version
3. Does NOT prevent partial rebuilds from becoming active
4. Does NOT have version switching logic
5. Does NOT validate that only active versions are generated

**Current Implementation**:
```go
// Line 173-180: rebuildLoop simply clears ALL embeddings
if err := s.storageService.ClearAllEmbeddings(ctx); err != nil {
    s.handleJobError(ctx, jobID, fmt.Sprintf("clear embeddings: %v", err))
    return
}
```

No versioning exists. All embeddings are cleared and regenerated without version isolation.

**Approved Architecture Requirement**:
- embedding_version field should exist in embedding_config (singleton)
- Each rebuild should generate embeddings with a new version
- Only COMPLETE rebuilds should become active
- Previous versions should be retained for rollback
- Partial rebuilds should NOT be visible to search

**Recommended Fix**:
1. Add `embedding_version` INT to embedding_config table
2. Create `content_embeddings.version` INT column
3. Rebuild with new version number BEFORE clearing old
4. Only after rebuild COMPLETES, atomically set config.active_version
5. Implement rollback capability to previous version

---

## CHECK 2: Transaction Boundaries - Orphaned Vectors

### Finding: HIGH ISSUE - Partial Entity Failures Not Atomic Across Entities

**Severity**: HIGH

**File**: `backend/service/embedding/service.go` (lines 223-247)

**Issue**:
While individual entity transactions ARE atomic (all-or-nothing per entity), the overall rebuild lacks transaction isolation:

1. Entity A completes successfully → vectors stored
2. Entity B's storage fails → rollback for B only, but A already committed
3. Entity C's build fails → skipped, but A's vectors remain
4. Job marked as "failed" overall, but A's vectors exist in "partial" state

If the service crashes between Entity A success and job completion, the database contains partial embeddings from a "failed" job.

**Current Code**:
```go
// Line 223-247: Per-entity transaction
err = s.storageService.TransactionalStore(ctx, func(txCtx context.Context, tx interface{}) error {
    for i, chunk := range chunks {
        if err := s.storageService.StoreEmbedding(...) {
            return fmt.Errorf("store embedding: %w", err)  // Rolls back THIS entity
        }
    }
    return nil
})

if err != nil {
    s.logger.WarnContext(ctx, "failed to store embeddings", ...)
    failedChunks += len(chunks)
    continue  // Next entity proceeds, previous entities already committed
}
```

**Impact**: 
- Rebuild failure leaves inconsistent state
- Some entities have embeddings, others don't
- Search results are inconsistent
- No clear way to know which entities are "good"

**Recommended Fix**:
1. Option A: Mark all entities as "embedding_version = NULL" on job failure
2. Option B: Create versioned approach - don't activate until ALL complete
3. Option C: Add entity-level status tracking (embedded_version per entity)
4. Implementation: After rebuild complete, atomically update config.active_version

---

## CHECK 3: Concurrency - Mutex Correctness & Deadlocks

### Finding: MEDIUM ISSUE - Lock Scope Issues & Potential Resource Leaks

**Severity**: MEDIUM

**File**: `backend/service/embedding/service.go`

**Issue 1: Lock Released Too Early in StartRebuild**
```go
// Lines 77-86
s.mu.Lock()
if s.currentJob != nil && s.currentJob.Status == "processing" {
    s.mu.Unlock()
    return 0, fmt.Errorf("embedding job already in progress: %d", s.currentJob.ID)
}
s.mu.Unlock()

// Gap here - no lock held during CreateEmbeddingJob
jobID, err := db.CreateEmbeddingJob(ctx)  // Could race here
```

Between releasing lock and creating job, another goroutine could start a second rebuild. Race condition window: job creation unprotected.

**Issue 2: Context Not Canceled on Startup Error**
```go
// Lines 93-107
rebuildCtx, cancel := context.WithCancel(ctx)
s.mu.Lock()
s.currentJob = &models.EmbeddingJob{...}
s.cancelFn = cancel
s.mu.Unlock()

// If SetEmbeddingStatus fails here:
if err := db.SetEmbeddingStatus(ctx, "reindexing", nil); err != nil {
    return 0, fmt.Errorf("set config status: %w", err)  // cancel NOT called
}
```

If SetEmbeddingStatus fails, cancelFn is never called. The rebuildLoop goroutine is created but not properly initialized. Context leak.

**Issue 3: Mutex Not Re-acquired in rebuildLoop Cleanup**
```go
// Line 153-157
defer func() {
    s.mu.Lock()
    s.currentJob = nil
    s.cancelFn = nil
    s.mu.Unlock()
}()
```

This is correct - deferred cleanup. But if rebuildLoop panics, the cleanup still runs (good).

**Issue 4: CancelJob Race Condition**
```go
// Lines 116-124
func (s *Service) CancelJob(ctx context.Context) error {
    s.mu.Lock()
    if s.currentJob == nil {
        s.mu.Unlock()
        return fmt.Errorf("no job running")
    }
    if s.cancelFn != nil {
        s.cancelFn()  // Called inside lock - OK
    }
    s.mu.Unlock()
    return nil
}
```

This is actually correct - cancel is synchronous and safe.

**Recommended Fix**:
1. Extend lock in StartRebuild to cover job creation
2. Ensure cancelFn is called on any startup error
3. Add timeout to rebuildLoop to detect hangs

