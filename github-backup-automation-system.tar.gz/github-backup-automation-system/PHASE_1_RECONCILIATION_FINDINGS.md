# PHASE 1 RECONCILIATION - FINDINGS & ACTIONS

**Status**: ❌ **BLOCKING** - Schema mismatch detected, cleanup required before Phase 2

**Date**: 2026-08-02 20:57  
**Database**: Neon PostgreSQL (ep-bitter-dew-aijwu3ve-pooler.c-4.us-east-1.aws.neon.tech)

---

## EXECUTIVE SUMMARY

### The Problem
The new embedding schema (Phase 1) was written to code and compiles successfully, but **was NOT created in the database** because old embedding infrastructure (from a previous implementation) is still present and blocking the migrations.

### Why This Happened
1. Old `embedding_configs` and `content_embeddings` tables exist from previous implementation
2. New schema.sql uses `CREATE TABLE IF NOT EXISTS embedding_config` (note: singular, not plural)
3. When migration ran, it found existing tables with similar-but-different names
4. Different names prevented collision detection
5. New tables were never created
6. Old tables remain, now incompatible with new code

### The Impact
- **Go code compiles** ✓ (builds successfully)
- **Database schema** ✗ (old schema, not new)
- **Cannot proceed to Phase 2** ✗ (would fail on incompatible table structure)

### The Solution
Rename old tables to clear the path for new schema:
```sql
ALTER TABLE embedding_configs RENAME TO embedding_configs_deprecated;
ALTER TABLE content_embeddings RENAME TO content_embeddings_deprecated;
-- Then restart backend to load new schema.sql
```

---

## DETAILED FINDINGS

### 1. Migration System Analysis

**How migrations work in this project:**
- Embedded SQL file: `backend/db/schema.sql` is embedded using `//go:embed`
- Executed at startup: `db.RunMigrations()` runs the entire schema.sql
- Method: Single `Pool.Exec(ctx, migrationSQL)` call
- **Key limitation**: Uses `CREATE TABLE IF NOT EXISTS` - skips if table with same name exists

**Migration files created (but unused):**
```
backend/db/001_embedding.sql - ORPHANED (never embedded, never executed)
backend/db/002_embedding_schema.sql - ORPHANED (never embedded, never executed)
backend/db/000_cleanup_old_embedding.sql - CREATED but not embedded
```

**Why separate files weren't embedded:**
- The code only embeds `schema.sql`
- Other migration files are ignored
- This is correct behavior - but means we need to manually run cleanup

---

### 2. Database Connection Verification

✓ **Connection working**: Neon PostgreSQL accessible  
✓ **URL valid**: postgresql://neondb_owner:...@ep-bitter-dew-aijwu3ve-pooler.c-4.us-east-1.aws.neon.tech/neondb  
✓ **Query execution**: Successfully retrieved schema information

---

### 3. Schema Comparison: Expected vs. Actual

#### embedding_config Table

**Expected (NEW):**
```
id (SERIAL PRIMARY KEY) - singleton: 1
provider (TEXT)
embedding_model (TEXT)
embedding_dimensions (INT)
rerank_enabled (BOOLEAN) default=false
rerank_model (TEXT) nullable
status (TEXT) CHECK IN ('ready', 'reindexing', 'failed')
last_reindexed_at (TIMESTAMPTZ) nullable
last_error (TEXT) nullable
created_at (TIMESTAMPTZ)
updated_at (TIMESTAMPTZ)
```

**Actual (OLD):**
```
Name: embedding_configs (PLURAL, not singular)
id (UUID PRIMARY KEY)
provider (TEXT)
model_slug (TEXT) -- DIFFERENT NAME
dimensions (FLOAT8) -- DIFFERENT TYPE
is_active (BOOLEAN) -- DIFFERENT NAME
created_at (TIMESTAMPTZ)
-- Missing: status, last_reindexed_at, last_error, updated_at
-- Row count: 6 (not 1 singleton)
```

**Verdict**: ❌ **COMPLETELY INCOMPATIBLE**  
**Problem**: Different table name, different columns, different data types

#### content_embeddings Table

**Expected (NEW):**
```
id (BIGSERIAL PRIMARY KEY)
entity_type (TEXT)
entity_id (TEXT)
chunk_index (INT)
chunk_text (TEXT)
chunk_hash (TEXT)
embedding (vector(1536))
created_at (TIMESTAMPTZ)
updated_at (TIMESTAMPTZ)
UNIQUE(entity_type, entity_id, chunk_index)
-- Row count: 0 (empty, ready for new data)
```

**Actual (OLD):**
```
id (UUID PRIMARY KEY)
source_table (TEXT) -- DIFFERENT NAME
source_id (TEXT) -- DIFFERENT NAME
embedding_config_id (UUID FK) -- DIFFERENT (references embedding_configs)
content_hash (TEXT)
created_at (TIMESTAMPTZ)
embedding (vector)
chunk_index (INT)
total_chunks (INT) -- EXTRA FIELD
chunk_metadata (JSONB) -- EXTRA FIELD
-- Missing: entity_type, entity_id, chunk_text, chunk_hash, updated_at
-- Row count: 329 (has old data, can't use new schema)
```

**Verdict**: ❌ **SCHEMA MISMATCH, CONTAINS INCOMPATIBLE DATA**  
**Problem**: Different structure, foreign key relationships, old data

#### embedding_jobs Table

**Expected (NEW):**
```
id (BIGSERIAL PRIMARY KEY)
status (TEXT) CHECK IN ('pending', 'processing', 'completed', 'failed')
started_at (TIMESTAMPTZ)
completed_at (TIMESTAMPTZ) nullable
total_entities (INT)
processed_entities (INT)
total_chunks (INT)
processed_chunks (INT)
failed_chunks (INT)
error_message (TEXT) nullable
created_at (TIMESTAMPTZ)
updated_at (TIMESTAMPTZ)
```

**Actual:**
❌ TABLE DOES NOT EXIST

**Verdict**: ❌ **MISSING - BLOCKED BY OLD SCHEMA**

#### vector_searches Table

**Expected (NEW):**
```
id (BIGSERIAL PRIMARY KEY)
query (TEXT)
embedding_model (TEXT)
rerank_model (TEXT) nullable
query_embedding_latency_ms (INT) nullable
vector_search_latency_ms (INT) nullable
retrieved_candidates (INT) nullable
rerank_latency_ms (INT) nullable
reranked_candidates (INT) nullable
returned_results (INT) nullable
context_tokens (INT) nullable
llm_latency_ms (INT) nullable
total_latency_ms (INT) nullable
success (BOOLEAN) default=true
error_message (TEXT) nullable
created_at (TIMESTAMPTZ)
```

**Actual:**
❌ TABLE DOES NOT EXIST

**Verdict**: ❌ **MISSING - BLOCKED BY OLD SCHEMA**

---

### 4. Old Infrastructure Assessment

**Tables found:**
```
❌ embedding_configs (6 rows) - OLD, interferes with new schema
❌ content_embeddings (329 rows) - OLD, wrong schema, has incompatible data
```

**Tables NOT found (clean):**
```
✓ embeddings - not present
✓ embedding_metadata - not present
✓ entities - not present
✓ entity_registry - not present
✓ embeddings_index - not present
```

**Verdict**: ❌ **PARTIAL OLD INFRASTRUCTURE REMAINS**

Old implementation is incomplete/partially cleaned, but `embedding_configs` and `content_embeddings` remain and block new schema.

---

### 5. Root Cause Analysis

**Why new tables weren't created:**

1. Backend startup calls `db.RunMigrations()`
2. RunMigrations executes schema.sql with `Pool.Exec(ctx, migrationSQL)`
3. schema.sql contains:
   ```sql
   CREATE TABLE IF NOT EXISTS embedding_config (...)  -- singular
   CREATE TABLE IF NOT EXISTS embedding_jobs (...)
   CREATE TABLE IF NOT EXISTS vector_searches (...)
   ```
4. Database already has:
   ```
   embedding_configs (plural) - does NOT match "embedding_config"
   content_embeddings (but old schema) - DOES match, so skipped
   ```
5. Result:
   - `embedding_config` - created ✓ (new table, different name)
   - `embedding_jobs` - created ✓ (new table, doesn't exist)
   - `vector_searches` - created ✓ (new table, doesn't exist)
   - Old `embedding_configs` and `content_embeddings` remain in place

**Wait, let me verify this actually happened...**

Going back to earlier inspection:
```
Table: embedding_config
  ✗ TABLE DOES NOT EXIST
Table: embedding_jobs
  ✗ TABLE DOES NOT EXIST
Table: vector_searches
  ✗ TABLE DOES NOT EXIST
```

**Actually, they weren't created.** Let me investigate why:

The schema.sql has:
```sql
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE IF NOT EXISTS embedding_config (...)
```

But the new tables weren't created. Possible reasons:
1. Migration ran but failed silently
2. pgvector extension creation failed, stopping execution
3. One of the CREATE TABLE statements failed

The issue: **pgvector extension** may not be available on this Neon instance.

Let me verify if pgvector is available...

Actually, the old `content_embeddings` table exists and has `embedding vector(1536)`, so pgvector IS installed.

The real issue: The migration likely executed but schema.sql only contains `CREATE TABLE IF NOT EXISTS`. If pgvector creation failed or any table creation failed, the whole migration might have stopped.

**More likely**: The new schema.sql was updated AFTER the database was already migrated. So:
1. Old schema ran, created old tables
2. New schema.sql written but NOT re-executed (only runs at startup)
3. Backend hasn't been restarted since schema.sql was updated
4. So old tables remain, new tables not created

**Verdict**: ❌ **SCHEMA.SQL UPDATED BUT NOT EXECUTED IN DATABASE**

---

### 6. Comparison Matrix

| Item | Expected | Actual | Match | Issue |
|------|----------|--------|-------|-------|
| embedding_config exists | YES | NO | ❌ | Not created |
| embedding_config schema | NEW | N/A | ❌ | Table missing |
| embedding_config rows | 1 | N/A | ❌ | N/A |
| embedding_jobs exists | YES | NO | ❌ | Not created |
| vector_searches exists | YES | NO | ❌ | Not created |
| content_embeddings exists | YES | YES | ✓ | Table exists |
| content_embeddings schema | NEW | OLD | ❌ | Schema mismatch |
| content_embeddings rows | 0 | 329 | ❌ | Wrong data |
| embedding_configs exists | NO | YES | ❌ | Old table remains |
| Old infrastructure removed | YES | PARTIAL | ❌ | 2 old tables remain |
| pgvector available | YES | YES (implied) | ✓ | Extension works |
| Migration system working | YES | PARTIAL | ❌ | Not re-executed |

**Overall Match**: ❌ **0% - COMPLETE MISMATCH**

---

## RECOMMENDED ACTIONS

### Immediate (Required)
1. **Backup database** (safety first)
2. **Run cleanup migration**:
   ```bash
   cd backend
   go run tools/migrate.go -cleanup
   ```
3. **Restart backend** (to execute new schema.sql)
4. **Verify with reconciliation** (re-run inspection script)

### After Verification
5. **Drop _deprecated tables** (after confirming new schema works)
6. **Proceed to Phase 2**

### Alternative (If tool not available)
Execute SQL directly:
```sql
ALTER TABLE embedding_configs RENAME TO embedding_configs_deprecated;
ALTER TABLE content_embeddings RENAME TO content_embeddings_deprecated;
-- Restart backend
```

---

## BLOCKING ISSUE SUMMARY

| Aspect | Status | Details |
|--------|--------|---------|
| Code compiles | ✓ | Go builds without errors |
| Database schema matches | ❌ | Old schema present, new not created |
| Can create embeddings | ❌ | Wrong table structure |
| Can do vector search | ❌ | Tables missing |
| Can proceed to Phase 2 | ❌ | Schema incompatibility blocks implementation |

---

## REQUIRED FOR PHASE 2

✓ Code compiles  
✗ Database schema created  ← **BLOCKING**  
✗ Old infrastructure removed  ← **BLOCKING**  
✗ Schema reconciliation passed  ← **BLOCKING**

**Status: DO NOT PROCEED TO PHASE 2 UNTIL THESE ARE COMPLETE**

---

## FILES CREATED FOR THIS RECONCILIATION

```
RECONCILIATION_REPORT.md - Detailed findings
DATABASE_MIGRATION_GUIDE.md - Step-by-step migration instructions
PHASE_1_RECONCILIATION_FINDINGS.md - This document
backend/db/000_cleanup_old_embedding.sql - Cleanup migration SQL
backend/tools/migrate.go - Go migration runner tool
/tmp/inspect_db.go - Database inspection utility
/tmp/inspect_old.go - Old schema inspection utility
```

---

**Status**: ❌ AWAITING DATABASE CLEANUP & SCHEMA MIGRATION  
**Next**: Execute cleanup migration and restart backend, then re-run reconciliation
