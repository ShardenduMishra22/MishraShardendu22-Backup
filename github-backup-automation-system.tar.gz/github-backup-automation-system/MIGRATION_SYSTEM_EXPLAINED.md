# Migration System Explained

## Current Migration Architecture

### How It Works

```
┌─────────────────────────────────────────────────────────────────┐
│                     BACKEND STARTUP                             │
└─────────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────────┐
│ main.go → db.Connect()                                          │
│ - Loads backend/.env                                            │
│ - Connects to PostgreSQL using POSTGRES_URL                     │
└─────────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────────┐
│ main.go → db.RunMigrations()                                    │
│ - Reads backend/db/schema.sql using //go:embed                 │
│ - Executes ENTIRE schema.sql in one Pool.Exec() call           │
│ - RUN EVERY TIME THE BACKEND STARTS                            │
└─────────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────────┐
│ schema.sql Execution                                            │
│ - Contains: CREATE TABLE IF NOT EXISTS ...                      │
│ - Idempotent: Safe to run multiple times                        │
│ - Creates all tables (backup, embedding, AI chat)              │
│ - All 80+ lines executed in single transaction                  │
└─────────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────────┐
│ Result:                                                          │
│ - Schema verified at every startup                              │
│ - If table exists: CREATE IF NOT EXISTS skips it                │
│ - If table missing: Created automatically                       │
│ - No migrations skipped or rolled back                          │
└─────────────────────────────────────────────────────────────────┘
```

## What migrate.go Does

`migrate.go` is a **standalone manual tool** for one-time database fixes.

### Purpose
- NOT automatically executed by backend
- Used to manually handle migration edge cases
- Example: cleaning up old tables before new schema is created

### How It's Different

```
┌──────────────────────────────────────────┐
│ Automatic (runs at backend startup)      │
├──────────────────────────────────────────┤
│ go run main.go                           │
│  → db.RunMigrations()                    │
│   → Executes schema.sql                  │
│    → Tables created/verified             │
└──────────────────────────────────────────┘

         VS

┌──────────────────────────────────────────┐
│ Manual (run once when needed)             │
├──────────────────────────────────────────┤
│ go run backend/tools/migrate.go -cleanup │
│  → Renames old tables                    │
│  → Never runs automatically              │
│  → Developer has to run it               │
└──────────────────────────────────────────┘
```

## Migration Lifecycle

### Scenario 1: Normal Backend Startup
```
Backend starts
  ↓
db.RunMigrations() called
  ↓
schema.sql executed
  ↓
CREATE TABLE IF NOT EXISTS embedding_config
  ├─ Table doesn't exist? CREATE IT
  └─ Table exists? SKIP (no-op)
  ↓
All tables checked and created if missing
  ↓
Backend ready, server starts
```

**Result**: ✓ Migrations run automatically every time

### Scenario 2: Cleanup Before New Schema (One-Time)
```
Old embedding_configs and content_embeddings exist
  ↓
Developer runs:
  go run backend/tools/migrate.go -cleanup
  ↓
migrate.go connects to database
  ↓
Renames old tables:
  ├─ embedding_configs → embedding_configs_deprecated
  └─ content_embeddings → content_embeddings_deprecated
  ↓
Developer restarts backend
  ↓
db.RunMigrations() runs
  ↓
schema.sql creates NEW embedding_config, content_embeddings
  ↓
Both old (_deprecated) and new tables coexist
```

**Result**: ✓ Old data preserved, new schema created, migration complete

### Scenario 3: Schema Update (Future)
```
Current schema in database: version 1
New schema required: version 2
  ↓
Developer updates schema.sql
  ↓
Next backend restart
  ↓
db.RunMigrations() runs
  ↓
schema.sql has new fields in CREATE TABLE IF NOT EXISTS
  ├─ If table exists: SKIP (doesn't add new fields!)
  └─ Problem: new fields not added to existing tables!
  ↓
Need ALTER TABLE to add columns (manual migration)
```

**Problem Identified**: Current system doesn't handle schema evolution!

---

## Current Limitations

### 1. CREATE TABLE IF NOT EXISTS Only
- ✓ Works for creating new tables
- ✗ Doesn't modify existing tables
- ✗ Can't add/remove/rename columns
- ✗ Can't change column types

### 2. No Version Tracking
- Schema.sql has no version number
- Can't tell if database is at schema v1, v2, or v3
- Can't track which migrations have been applied

### 3. No Rollback
- All-or-nothing approach
- No ability to revert schema changes
- No migration history

### 4. No State Management
- Backend startup doesn't check if migrations succeeded
- If migration fails halfway, system doesn't know
- Subsequent restarts try to re-run (might fail again)

---

## Answer to Your Questions

### Q1: What is the use of migrate.go?

**migrate.go** is a **one-time manual tool** for handling database cleanup or edge cases that the automatic migration system can't handle.

**Specific use case we created it for:**
- Old embedding tables existed and blocked new schema creation
- Automatic migrations couldn't handle this (CREATE IF NOT EXISTS would skip)
- Solution: Manual tool to rename old tables first
- Then restart backend so automatic migrations create new schema

### Q2: How do migrations run? Do they run each time backend is started?

**YES - migrations run EVERY TIME the backend starts**

```go
// In main.go
if err := db.RunMigrations(); err != nil {
    log.Fatalf("Failed to run migrations: %v", err)
}
```

**Every startup:**
1. Backend starts
2. db.Connect() connects to PostgreSQL
3. db.RunMigrations() reads schema.sql from binary
4. Entire schema.sql executed in one transaction
5. All CREATE TABLE IF NOT EXISTS statements checked
6. Backend continues if successful, crashes if migration fails

**Example:**
```bash
# Start 1
$ go run main.go
PostgreSQL connected and migrations applied  ← schema.sql ran
Backend server running on http://localhost:8080

# Stop

# Start 2  
$ go run main.go
PostgreSQL connected and migrations applied  ← schema.sql ran AGAIN
Backend server running on http://localhost:8080
```

**Both times, schema.sql was executed.**

---

## Why This Design?

### Advantages
✓ Simple - one file, no versioning
✓ Idempotent - safe to run N times
✓ Embedded in binary - no separate files needed
✓ Works for new deployments
✓ Works for schema additions (new tables)

### Disadvantages
✗ No schema evolution (can't modify existing tables)
✗ Doesn't detect if migration failed
✗ No rollback capability
✗ All-or-nothing approach
✗ Can't add new columns to existing tables

---

## Implications for the Refactoring

When we refactor the schema (split embedding_vectors, add fields to embedding_config, etc.), we have a choice:

### Option A: Modify schema.sql (What We'd Do)
```sql
-- Update backend/db/schema.sql to include:
-- - embedding_vectors table (new)
-- - Modified embedding_config with new fields
-- - Modified vector_searches without certain fields

-- Next backend start:
-- - New table embedding_vectors created
-- - Existing tables: CREATE IF NOT EXISTS skips them
-- - Problem: New fields NOT added to existing tables!
```

**Result**: ✗ Schema mismatch - database doesn't have new fields

### Option B: Create ALTER Migration (Better)
```sql
-- Create backend/db/002_refactor_embedding_schema.sql
-- Contains ALTER TABLE statements to:
-- - Add new columns to embedding_config
-- - Remove columns from vector_searches
-- - Create embedding_vectors table
-- - Remove embedding column from content_embeddings

-- But: db.RunMigrations() only runs schema.sql, not 002_...
-- Problem: Manual migration never executes automatically
```

**Result**: ✗ Still requires manual migration tool

### Option C: Embed Multiple Files (Better Architecture)
```go
// Create versioned migrations
//go:embed schema.sql
//go:embed migrations/001_initial.sql
//go:embed migrations/002_refactor_embedding.sql

// Execute them in order
// Track which have been applied
// Support rollback
```

**Result**: ✓ Proper version tracking, automatic execution

---

## Recommendation

For **this specific refactoring**, since the new schema is being introduced BEFORE we deployed the current one to production:

**We can safely replace schema.sql entirely** because:
- ✓ No existing production data to migrate
- ✓ Current schema is still in development
- ✓ Database only has test/backup data
- ✓ Next backend restart will pick up new schema
- ✓ Old tables will be replaced cleanly

**This works because:**
1. We'll manually drop old content_embeddings and embedding_vectors first (if they exist)
2. Update schema.sql with new structure
3. Next backend restart runs new schema.sql
4. Fresh tables created with correct structure

---

## Summary

| Aspect | Current System |
|--------|---|
| **Automatic Execution** | ✓ Yes, every backend startup |
| **Idempotent** | ✓ Yes, safe to run N times |
| **Schema Evolution** | ✗ No, only CREATE not ALTER |
| **Version Tracking** | ✗ No versioning |
| **Rollback Support** | ✗ No rollback capability |
| **Manual Override** | ✓ via migrate.go tool |

**For our refactoring**: Replace schema.sql entirely, it's safe and clean.

