# Issues and Proposed Solutions Latest

## Coursera Embeds Colab

Coursera redirects to the Colab website and cannot embed notebooks directly - this is prohibited by their platform. We cannot use alternative methods like hosting our own Colab notebook because that would require users to sign into Colab, which defeats the purpose. Their previous approach involved using Docker and Kubernetes.

### How to Embed a Colab Notebook

We cannot embed interactive Colab notebooks for our use case. Here's an [article explaining static embedding](https://liyi-zhou.medium.com/how-to-embed-google-colaboratory-into-medium-in-3-steps-487b525b103c), but it only allows static (non-interactive) embedding. There's also a [GitHub thread discussing this limitation](https://github.com/googlecolab/colabtools/issues/1225), which confirms this approach isn't suitable for our use case.

A similar [Stack Overflow discussion](https://stackoverflow.com/questions/63208821/how-to-embed-a-live-colab-notebook-in-a-website) addresses the same issue. Theia is too resource-heavy and requires login (same as Colab), so it won't work either.

All other methods that don't involve Pyodide or Trinket are not cost-effective.

## Possible Solution: Chrome Extension

I thought of a potential solution, though it may not be very practical. Since children learn better with proper navigation, we could create a Chrome extension that:

- Tracks where children currently are in their learning
- Helps them navigate to Google Colab for their work
- Allows seamless return after submission

This is a somewhat naive idea, but I wanted to share it. Here's the [ChatGPT discussion](https://chatgpt.com/share/687e1379-1974-8005-88fa-aabaf736b6bb) about this concept. I'll prepare a demo and proof of concept soon.

Publishing the extension would cost $5 for the developer account, and we can publish multiple extensions under it.

### Pros

- Students learning Colab from the start would benefit long-term, as it's widely used in the industry
- Shifts computational load from our servers to Google's infrastructure, allowing us to scale and focus on unique features
- This approach seems novel - I haven't seen anyone implement this idea. Having created Chrome extensions before, I drew inspiration from testing tools like Keploy, which recently launched their unit testing Chrome extension (though it doesn't work perfectly, the concept exists)
- One-time payment of ₹500 opens opportunities to add more extensions under our copyright, which could be innovative and set us apart

### Cons

- Need senior guidance on implementation approach
- Slightly less control over user actions
- Poor initial UX, as the learning curve can be steep for children whose technical understanding is still developing (though this could foster community building through Discord or Slack, which kids are quite capable of using)

This is just an idea for seniors to evaluate.

## Alternative Solutions Considered

**Voila**: Not a good option as we'd need to add our own servers. If we were to go this route, we'd prefer using Jupyter Lite-related solutions. I won't spend time on this unless specifically asked.

**Jovian**: The Jovian platform allows embedding public, already-hosted Jupyter notebooks as interactive viewers in websites. Here's the [related article from Jupyter Blog](https://blog.jupyter.org/jupyter-everywhere-f8151c2cc6e8).

No other viable options exist without deploying our own server/backend. Here's the [ChatGPT summary](https://chatgpt.com/share/687e65b7-2a9c-8005-b04f-44290a0ff4b8) of this research.

## Trinket Analysis

Trinket offers several features:

- Users can download code to their local machine
- Sharing creates a link for the code
- Current code is stored only on Trinket's website
- [Allowed libraries in Trinket](https://trinket.io/docs/python)
- [Pyodide libraries available](https://pyodide.org/en/stable/usage/packages-in-pyodide.html)

### How Trinket Works

Trinket uses a Git-like system:

- Default iframe embedded from their [official library](https://trinket.io/library/trinkets)
- When users open and edit code, they get a separate branch with a unique browser ID and associated metadata
- This ID stores code data in local storage
- Default code is stored on their backend; everything else uses local storage
- Hardware interaction is possible - we can create code using Blockly and run it on Raspberry Pi (not yet tested, only researched through documentation and GPT; will test once I reach college)
