# Improved Quantisation of AI Models Documentation

## What is Quantisation?

Quantisation reduces the precision of numbers used to store model parameters. Instead of using full precision, such as `3.1419534083405`, quantised models might store just `3.14`. This provides better efficiency with a small accuracy trade-off.

## Technical Comparison

----------------------------------------------------------------------------
| Aspect           | Standard Model              | Quantised Model         |
|------------------|-----------------------------|-------------------------|
| Data type        | 32-bit float                | 8-bit integer           |
| Size             | Large (e.g., ~700GB)        | Small (e.g., ~175GB)    |
| Precision        | High                        | Lower                   |
| Speed            | Normal                      | Faster                  |
| Memory usage     | High                        | Low                     |
| Power use        | High                        | Low                     |
----------------------------------------------------------------------------

## Key Benefits

- **Smaller File Size:** Up to 4x reduction.
- **Faster Inference:** Less data to process speeds up prediction.
- **Lower Memory Usage:** Suits mobile, edge, and embedded devices.
- **Reduced Power Consumption:** Ideal for battery-powered environments.

## Trade-offs

- **Slight Accuracy Loss:** Usually 1-5% decrease in model performance.
- **May Affect Edge Cases:** Precision reduction can impact rare or sensitive outputs.

## Example: ChatGPT

| Model Type       | Calculation                                 | Size      |
|------------------|---------------------------------------------|-----------|
| Original Model   | 175B × 32 bits = ~700GB                     | ~700GB    |
| Quantised Model  | 175B × 8 bits = ~175GB                      | ~175GB    |

*Result: 4x smaller model with most of its intelligence intact.*

## Types of Quantisation

- **Post-training Quantisation:** Quantise model after training.
- **Quantisation-aware Training:** Train with quantisation in mind for better results.
- **Dynamic Quantisation:** Quantise during inference for speed.

## Packages

- `@huggingface/transformers` – Python (pip install transformers)
- `@xenova/transformers` – JavaScript/Web version

## Code Examples

### Python (Huggingface Transformers)
```python
from transformers import AutoModelForCausalLM
import torch

model = AutoModelForCausalLM.from_pretrained("model_name")
quantized_model = torch.quantization.quantize_dynamic(
    model, {torch.nn.Linear}, dtype=torch.qint8
)
```

### JavaScript (Xenova Transformers)
```javascript
import { pipeline } from '@xenova/transformers';

const classifier = await pipeline('sentiment-analysis', 'model_name', {
    quantized: true
});
```

## When to Use Quantisation

- **Mobile apps:** Efficient AI features directly on phones.
- **Edge computing:** Deploy models on compact, resource-limited hardware.
- **Cost savings:** Lower bandwidth and storage needs for large-scale deployments.
- **Real-time systems:** Faster response for voice, vision, or text tasks.

***