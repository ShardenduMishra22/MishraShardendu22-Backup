## Figma Design

- **Final Design Link**: [Figma Prototype](https://www.figma.com/design/RXM4V5WZP5QhRDCjTcQLw0/Coding-Junior?node-id=0-1&p=f)

## Design Reference Platforms

The following platforms were used as reference points for UI/UX decisions:

1. [Khan Academy Kids](https://learn.khanacademy.org/khan-academy-kids/)
2. [ABCmouse](https://www.abcmouse.com/)
3. [PBS Kids](https://pbskids.org/)
4. [National Geographic Kids](https://kids.nationalgeographic.com/)
5. [Scratch (MIT)](https://scratch.mit.edu/)
6. [BrainPOP Jr.](https://jr.brainpop.com/)
7. [Duolingo ABC](https://www.duolingo.com/abc)
8. [Prodigy Math Game](https://www.prodigygame.com/main-en)
9. [Tynker](https://www.tynker.com/)
10. [Epic! Books for Kids](https://www.getepic.com/)