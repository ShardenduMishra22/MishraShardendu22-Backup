# Jupyter Integration Options

## JupyterLite (Pyodide + micropip)

**Demo:** [https://jupyterlite.github.io/demo/repl/index.html?kernel=python\&toolbar=1](https://jupyterlite.github.io/demo/repl/index.html?kernel=python&toolbar=1)

* Libraries can be installed via `micropip`
* Same limitations as Pyodide (e.g. no native C/C++ extensions)
* UI is limited, customization is minimal
* File system exists, basic persistence supported
* **OpenCV works**, but **PyTorch/TensorFlow don't** (due to native dependency limitations)
* Have to deploy a seperate instance of this ourselves if we want to make it work, else rely on already deployed instances.

## Monaco Editor + Pyodide (`skycube.app`)

**Example:** [https://skycube.app/](https://skycube.app/)

* Same Pyodide-based environment as JupyterLite
* Slightly different UI (Monaco-based)
* Similar pros/cons as above

## React-py

**Docs:** [https://elilambnz.github.io/react-py/docs/introduction/getting-started](https://elilambnz.github.io/react-py/docs/introduction/getting-started)

* Runs Pyodide behind the scenes
* Good for embedding Python in React apps
* Same Pyodide limitations apply

## PyScript

* Not usable alongside separate Pyodide in current state
* Still immature, not powerful enough for real use
* Better alternatives exist (JupyterLite, React-py)

---

## Other Approaches (Require Backend/API)

* These approaches require backend processing or remote kernel execution
* Not preferred if the goal is fully client-side Python execution

**Reference:** [Research Summary](https://chatgpt.com/share/6877d941-0684-8005-93cb-038625f73bc8)

---

**TL;DR**
Use **JupyterLite** or **React-py** for in-browser Python.
Avoid anything that depends on native C extensions or a backend unless absolutely necessary.

```md
## ✅ Summary: Embedding Jupyter & Running Python in React

---

### **I. Static or Iframe-Based Notebook Embedding**

| Tool/Platform              | Type              | Interactivity | Notes                                                   | Links                                                                                                                                                              |
| -------------------------- | ----------------- | ------------- | ------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **react-jupyter-notebook** | React component   | None          | Renders `.ipynb` statically (no execution)              | [NPM](https://www.npmjs.com/package/react-jupyter-notebook), [GitHub](https://github.com/Joeyonng/react-jupyter-notebook)                                          |
| **Google Colab (iframe)**  | Cloud IDE         | Low           | No official API; login required; not for production use | [Colab](https://colab.research.google.com), [Colab FAQ](https://research.google.com/colaboratory/faq.html)                                                         |
| **Binder (iframe)**        | Jupyter on-demand | Low           | GitHub-powered launch; slow cold starts                 | [Binder](https://mybinder.org/), [Embedding Guide](https://elc.github.io/posts/embed-interactive-notebooks/), [NBInteract](https://github.com/SamLau95/nbinteract) |
| **Voila (iframe)**         | Dashboard         | Medium        | Turns notebooks into apps with `ipywidgets`             | [Voila Docs](https://voila.readthedocs.io/en/stable/)                                                                                                              |
| **JupyterLite (iframe)**   | In-browser        | High          | Full JupyterLab via Pyodide; runs client-side           | [JupyterLite](https://jupyterlite.readthedocs.io/en/latest/deploying.html), [Demo](https://jupyterlite.github.io/demo/repl/index.html?kernel=python&toolbar=1)     |

---

### **II. React Integration with Live Python Kernels**

| Tool                                     | Type            | Interactivity | Notes                                             | Links                                                                                                        |
| ---------------------------------------- | --------------- | ------------- | ------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| **ipyreact** (`@widgetti/jupyter-react`) | React + Jupyter | High          | Bi-directional React ↔ Python via Jupyter         | [NPM](https://www.npmjs.com/package/@widgetti/jupyter-react), [GitHub](https://github.com/widgetti/ipyreact) |
| **ipywidgets (embedded)**                | Jupyter output  | Medium        | Embeds UI elements from `.ipynb`; not live kernel | [Docs](https://ipywidgets.readthedocs.io/en/latest/embedding.html)                                           |
| **Jupyter Kernel Gateway / Server**      | Backend API     | High          | WebSocket API; build custom frontend with React   | [Jupyter Kernel Gateway](https://jupyter.org/documentation)                                                  |

---

### **III. In-Browser Python Execution (No Backend)**

| Tool         | Type           | Interactivity | Notes                                           | Links                                                                                                                                               |
| ------------ | -------------- | ------------- | ----------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Pyodide**  | WASM (CPython) | High          | Pure client-side Python, supports many packages | [Pyodide](https://pyodide.org/), [WASM Constraints](https://pyodide.org/en/stable/usage/wasm-constraints.html)                                      |
| **react-py** | React wrapper  | High          | Pyodide + React Hooks; REPL-like API            | [GitHub](https://github.com/elilambnz/react-py), [Docs](https://elilambnz.github.io/react-py/)                                                      |
| **PyScript** | HTML framework | Medium        | `<py-script>` tags for Python in HTML           | [PyScript Docs](https://docs.pyscript.net/2023.09.1.RC1/user-guide/), [Comparison](https://python.plainenglish.io/pyscript-or-pyodide-f0f1dc10291f) |

---

### **IV. Server-Side Code Execution APIs**

| Tool                             | Type     | Interactivity | Notes                                                     | Links                                                                                                     |
| -------------------------------- | -------- | ------------- | --------------------------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| **Piston API**                   | REST API | Stateless     | Multi-language exec API; self-host or use public endpoint | [GitHub](https://github.com/engineer-man/piston), [Docs](https://piston.readthedocs.io/en/latest/api-v2/) |
| **Custom Flask/FastAPI backend** | Server   | High          | Full control, secure sandboxing required                  | [Flask](https://flask.palletsprojects.com/), [FastAPI](https://fastapi.tiangolo.com/)                     |

---

## 🧭 Use Case Guidance

| Goal                                   | Recommended Option                  |
| -------------------------------------- | ----------------------------------- |
| Full interactive Jupyter UI in browser | JupyterLite                         |
| Tight React ↔ Python integration       | Pyodide / react-py / ipyreact       |
| Stateless Python code execution        | Piston API                          |
| Embed interactive notebook dashboard   | Voila                               |
| Display `.ipynb` output only           | react-jupyter-notebook              |
| Run actual backend Jupyter kernel      | Jupyter Kernel Gateway / JupyterHub |

---
```
