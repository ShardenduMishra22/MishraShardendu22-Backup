# Tenant Domain Management in a Multi-Tenant SaaS Platform on Vercel

When running a SaaS where each customer gets a dedicated deployment and (optionally) a unique subdomain or custom domain, Vercel provides robust tools to automate this—scaling well for both internal subdomains (e.g., tenant1.app_name.co) and external, user-supplied domains.

## **How It Works: Automated Domain Management for New Tenants**

**1. Customer Onboarding Automation** - When a user signs up:

- Your platform provisions a new deployment (front-end, API, etc.) for the customer using Vercel’s REST API or SDK.
- The system generates a unique subdomain for them, like customername.app_name.co, or adds a custom domain they supply (like customerbrand.com).

**2. Wildcard Domain Setup** - You configure a wildcard domain (`*.app_name.co`) in your DNS and Vercel project:
  
- Point your apex domain (`app_name.co`) to Vercel's nameservers.
- Add the wildcard domain (`.app_name.co`) in your Vercel project settings.
- Vercel automatically enables all possible subdomains—`customer1.app_name.co`, `customer2.app_name.co`, etc.—with no need for manual DNS edits for each tenant.

**3. SSL Certificate Management** - Vercel will automatically provision and manage SSL certificates for every registered subdomain (and for custom domains after DNS verification), provided you are using Vercel’s nameservers for the apex domain and have the wildcard domain added to the project.

- Each customer’s domain becomes secure (HTTPS) out of the box, improving trust and platform security.
- For custom domains, after adding via the API/SDK, customers may need to verify ownership (e.g., by adding a TXT or CNAME record) to enable SSL.

**4. Programmatic Domain Registration & Configuration** - Use the Vercel SDK or REST API endpoints to:

- Add subdomains or custom domains to your project.
- Trigger verification and monitor status.
- Remove domains on churn or offboarding.
- Automate all of this as part of your customer lifecycle in your backend code.

**5. Scalable, Flexible, and Cost-Efficient** -

- This platform-driven approach supports unlimited tenants (subject to plan limits) under a single Vercel project, with centralized management for SSL, DNS, and domain lifecycle.
- You avoid high per-customer domain/DNS management costs and get instant onboarding for new customers.

### **Sample Flow Chart**

1. **Customer signs up**  
2. **Backend triggers Vercel deployment for the user**  
3. **Backend adds tenant subdomain (or custom domain) via Vercel SDK**  
4. **Vercel verifies domain ownership if needed and issues SSL certificate**  
5. **Tenant content is available at customer-specific domain (secure and isolated)**

**Advantages:**

- Zero manual DNS overhead after setup—fully automated subdomain allocation.
- Secure by default (automatic HTTPS/SSL with proper setup).
- Seamless customer experience for onboarding and domain management.
- Scalable for high-growth SaaS/multi-tenant architectures.

**Implementation Requirements:**

- You must use Vercel nameservers for apex domain to leverage wildcard and automated SSL.
- For custom domains, guide tenants through simple DNS verification if needed.
- Ensure backend checks subdomain-to-tenant mapping on each request for proper routing and security.
