# Vercel Network

## POPs (Points of Presence)

POPs are locations around the world where users connect to your website. They handle routing, simple caching, SSL security, and help block attacks. When someone visits your site, they are connected to the closest POP for speed.

## Regions  

Regions are bigger server locations where Vercel does the backend work (APIs, server rendering). There are about 19 main regions. Each region also caches content. You get to pick which region your functions run in, usually the one nearest the database or your main users.

### Example Region Codes

| Region Code | Location              |
|-------------|----------------------|
| bom1        | Mumbai, India        |
| fra1        | Frankfurt, Germany   |
| iad1        | Washington, D.C., US |

Use region codes like these when configuring your project.

## Caching & CDN  

POPs cache and send static files fast. Regions use a bigger cache for backend data and popular content, for faster responses. This saves time and server trips.

## Defaults  

If you don't pick a region for your serverless functions, Vercel uses `iad1` (Washington, D.C.). It's better to select the region closest to your database for lowest delay.

## How To Set Regions  

- Use the `vercel.json` file to set `"regions"` for your functions:

  ```json
  {
    "regions": ["bom1"],
    "functionFailoverRegions": ["fra1", "iad1"]
  }
  ```

- Or choose regions in the Vercel dashboard.

## Multi-Region & Failover  

You can choose multiple regions on Pro/Enterprise plans. Your function runs closest to the user or database. If one region goes down, Vercel automatically uses your next region from the list.

## Local Development  

Running `vercel dev` simulates a region (`dev1`) on your own computer. This helps you see if your code works the same way as it would after deployment. It’s not global, but helps you test region-specific stuff locally.

**Summary:**  

- POPs = entry points and CDN for fast, safe access.
- Regions = where backend/server code runs.
- Use the right region(s) for speed.
- If a region fails, Vercel switches to your backup.
- Local test matches live setup.
