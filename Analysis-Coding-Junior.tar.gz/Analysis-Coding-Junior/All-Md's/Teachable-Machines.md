# Teachable Machine – Custom Demo

A browser-based tool to create and test your own machine learning models just like Google Teachable Machine—**entirely in your browser, using your webcam** for image classification! Built with React, Next.js, TensorFlow.js, and MobileNet.

## 🚀 What is this?

Create, train, and test your own image classifier models with a simple step-by-step UI:

- **Collect photos** for each label using your webcam.
- **Train a classifier** (no server needed, all compute stays in your browser).
- **Predict live**: See class predictions on your webcam feed in real time!

**NOTE:** This demo is for _image classification only_; audio and pose tasks can be added in the future.

## ✨ Features

- 📸 **Image Data Collection:** Add samples for each custom class via webcam snapshots.
- ⚡ **In-Browser Training:** Uses MobileNet’s feature extractor + a neural network “head,” trained directly (no uploading).
- 🧠 **Live Prediction:** Once trained, start live, frame-by-frame predictions on new webcam input.
- 🪶 **No Backend:** 100% client-side and private.
- 🖌️ **Clean UI:** Modern, mobile-ready, made with Tailwind CSS.
- 🛂 **Safe & Fast:** Automatic memory/stream clean-up.

## 🛠 Tech Stack

- **TypeScript + React + Next.js** (app router/client component)
- **Tailwind CSS** (utility styles)
- **@tensorflow/tfjs** (ML framework)
- **@tensorflow-models/mobilenet** (feature extraction backbone)

## 📝 How to Use

1. **Install dependencies**  

   ```bash
   npm install
   npm install @tensorflow/tfjs @tensorflow-models/mobilenet
   ```

2. **Run locally:**  

   ```bash
   npm run dev
   ```

3. Open [localhost:3000](http://localhost:3000) and follow the three steps:
   1. Enable webcam, add samples, repeat for each class.
   2. Train your model.
   3. Start predicting!

## 🏗️ App Overview

- **Class Setup:** Configure class names in the `CLASSES` constant.
- **Data Step:** Each "Add Sample" button instantly snaps a frame for that class.
- **Training Step:** Feature vectors are collected from samples using MobileNet, and a classifier is trained right in the browser (no data leaves your machine).
- **Prediction Step:** See class confidence bars updated live over webcam video.

## 🖥️ Code Highlights

- **Webcam handled via React refs.**
- **TensorFlow.js and MobileNet** provide all ML.
- **All tensors cleaned up,** all streams closed, safe for long sessions.
- **No direct DOM manipulation.** Only React state/hooks.

## 📥 Extending

- **Add more classes:** Update the `CLASSES` array in the code.
- **Audio or Pose:**  
  - For audio: See [`@tensorflow-models/speech-commands`](https://www.npmjs.com/package/@tensorflow-models/speech-commands).
  - For pose: See [`@tensorflow-models/pose-detection`](https://www.npmjs.com/package/@tensorflow-models/pose-detection).
  - The UI steps/patterns will remain the same.