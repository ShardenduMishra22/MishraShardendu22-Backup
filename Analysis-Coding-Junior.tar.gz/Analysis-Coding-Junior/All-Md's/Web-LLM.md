## web llm article by intel - https://www.intel.com/content/www/us/en/developer/articles/technical/web-developers-guide-to-in-browser-llms.html

## transformer.js - https://www.codemotion.com/magazine/ai-ml/tutorial-easy-client-side-ai-translator-with-transformers-js-codemotion/

## Repo of transformer.js - https://github.com/huggingface/transformers.js

3. What’s the Problem With Large Model Files and How Does Caching Help?
LLMs are big. Their files include the weights (.onnx), tokenizers (.json), and configuration files.

Downloading these every time is very slow and wastes bandwidth.

By combining a service worker and browser cache, you:

Capture these files on first load.

Store (cache) them so the browser never re-downloads unless you update them.

On subsequent loads, even when offline, the app can serve everything (UI, scripts, model files) from the local cache.

4. Why Use a Web Worker?
A Web Worker is a browser feature for running computationally heavy code (like AI model inference) in a background thread.

This means your UI never freezes, even if the model takes several seconds to produce an answer.

