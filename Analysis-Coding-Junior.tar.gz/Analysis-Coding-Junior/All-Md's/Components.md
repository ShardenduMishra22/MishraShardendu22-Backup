# Components

To maintain a consistent and professional UI/UX across the entire platform, we will **reuse key components** throughout the website. This ensures visual coherence and reinforces the identity of a unified product built by a single organization.

---

## Design Consistency Goals

- Ensure every page feels part of the same ecosystem
- Improve development efficiency via reusable elements
- Reflect a unified brand identity (Career Cafe)

---

## Component Reuse Guidelines

- **Icon Library:**  
  Use a single icon source — **Lucide-react** is recommended.  
  - Widely supported and modern  
  - Compatible with libraries like shadcn/ui  
  - Avoid mixing icon sets

- **Navbar:**  
  Standardize the entire navbar design across pages:  
  - Sun/moon toggle  
  - Positioning and layout  
  - Element spacing, sizing, and hover states

- **Buttons:**  
  Use a consistent design for all buttons (primary, secondary, disabled states).  
  Ensure reusable variants are defined.

- **Testimonials:**  
  Reuse base layout where appropriate, but customize for tone/audience (e.g. kid-focused testimonials should look distinct but follow same design system).

- **Footer:** *(Optional)*  
  - Consistency not strictly necessary, but a shared minimal footer is **recommended**.  
  - Include:  
    - `© YEAR Career Cafe`  
    - Privacy Policy  
    - Contact Us  
    - Company slogan (if not an image or SVG)

- **Mentors Panel:**  
  Create a reusable component that can adapt to:  
  - "Our Mentors"  
  - "Our Students"  
  - "Community Testimonials"  
  Just switch headings and data.

- **Mobile Menu (App):**  
  Create a shared mobile drawer/menu component.  
  Reuse it across all mobile/web views for familiarity and reduced dev time.

- **"Backed by"/"Supported by" Section:**  
  Create a component to highlight associations with companies, mentors, or partner platforms.  
  This will be reused across all future products/projects.

---

## Color Theme

The color palette is aligned with Career Cafe’s design language — no changes needed.

---

## Philosophy

Reusing components reflects a **clear separation of concerns** in UI/UX design. It supports the narrative that:
> "These are different products built by the same company — not necessarily the same developer, but the same design vision."
