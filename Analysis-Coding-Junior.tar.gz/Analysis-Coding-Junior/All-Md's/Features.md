# PLatform Feature Planning 

**1 The website supports both dark and light mode. It's accessible on mobile and smaller devices, but to improve experience, the IDE will be disabled on mobile with a message prompting users to switch to a larger screen.**
**2 Student Testimonials or Public Gallery (Can be added later I can make the section we can update it later)**
**3 Admin Panel - CMS**

## Two Areas to Work On

1. All features that the website will have.
2. Advanced logged-in user-specific features.

---

## General User Features (including non-logged-in or free plan users)

- Login page  
- Register page  
- Landing page  
- Course pages  
- IDE page  
- Block coding page  

Users can utilize all of the above.  
Exporting their code to the local machine is possible.

---

## Logged-In Advanced User Features

- Saved code pages  
- Can share their code  
  - They will have a separate page for saved code (not tied to courses; casual coding zone)  
- Can save their progress  
- Gamified progress tracking (badges, milestones)  
- Can save which lectures/videos have already been watched  
- Save video watch progress (like YouTube, bookmark-style tracking, history enabled)

---

## Course System Enhancements

- Course structure can be linked to a Google Classroom-style format  
- Messaging functionality per course  
- Course-specific videos  
- Assignments added directly to courses  
- Resource/doc uploads (referencing Udemy and Google Classroom)  
- Certificate generation (should hold value if verification is implemented)

---

## Assignment Evaluation

- Coding assignments can be auto-verified  
  - Start small with predefined test cases (Polygon or similar system)  
- Same for Blockly-generated code  

---

## Level-Based Coding System (We can also have age absed access or combination of both)

- Progression can be tied to course completion  
- More advanced content unlocked as users progress  
- Note: Free-tier users may lose relevance unless progress is stored  
- Suggestion: Introduce a simple free-tier credit system  

### GPT Suggestion this will make us code a lot more though, it's basically creating another website but yes this can improve website experience a lot, this is usually done with games, PictoBlox does this

- Level-based access = unlocks based on user progress (e.g., Blockly → Python).
- Age-based filtering = UI/content changes dynamically based on user's age (e.g., simpler UI for 6–8 yrs, more features for 10+).

---

## (Optional Advanced Ideas)

- Use compilation time as a performance metric  
- AI-based code analysis and suggestions  
  - Risky, must use a reliable model  
  - Requires curated question data and test cases  
  - Likely only viable for simple problems  
- AI Plagiarism Detection  
  - Detect AI-generated or plagiarized submissions  
  - (You said it's a good idea if possible)

---

## Practice Problems Section (can add)

- Dedicated area for solving additional coding problems  

## TTS/STT Integration

- For easeir Page Navigation we can add this as planned.

## Hardawre Integration

- Raspberry Pi + GPIO via Blockly-generated Python.
- Pi Pico, Edge Impulse integration, UART, I2C, camera/mic support.