# Additional Features

## Support for Not Logged-In and Free Users

We will use browser-side storage (IndexedDB or similar) to handle user data locally.

> **Note:** Browser DBs can be slow and are not suitable for long-term or large-scale storage.

---

## Client-Side Virtual File System

### **Why This Is Necessary**

To allow users to work with realistic coding projects — not just single scripts, but entire project structures with multiple files and configurations.

### **How It Works**

- A virtual file system is created in the browser using IndexedDB or in-memory storage.
- Integrated with Monaco Editor and Pyodide (or similar) for full in-browser coding capability.
- Enables features like file/folder creation, editing, and structured project storage without needing backend calls.

### **Use Case Example**

A course module may require building a small project like:

```
project/
├── main.py
├── utils.py
└── config.json
```

Users can:

- Edit each file individually
- Run the full project in-browser
- Save changes locally in the browser

---

## Key Benefits

- Supports multi-file coding within a course
- Preserves project folder structure for sharing or collaboration
- Provides personal sandboxed project space
- Enables offline coding or temporary session persistence without needing a backend

---

## Limitations

- Runs in browser memory — may lag or crash with large projects
- IndexedDB performance can vary across browsers
- Needs custom logic for storage limits and cleanup

---

## Planned Fixes

1. **Aggressive Cleanup**  
   Implement background cleanup to manage browser DB size and prevent bloat.

2. **Backend Sync for Advanced Users**  
   Logged-in advanced users will have their code and project state synced to the backend for persistence across devices and sessions.

### Tech to Use

- [BrowserFS](https://jvilk.com/browserfs/2.0.0-beta/index.html)

## Progression System

- Level 0 → 1 → 2 progression.
- Unlock text coding from block level.
- Block to Text Transition System.

## Notebook / Jupyter / Colab-Style Integration

- Cant find a way to do this though.

## Machine Learning Part

- We will just add assignments rest they can sue teachable machines - (as said in meeting).

## Other

- Future Expansion Plans (AR/VR, ML Extensions, Mobile App Menu Reuse)
- Daily Challenges, Leaderboards, Micro Projects
- Code Persistence and Draft Saving Strategy