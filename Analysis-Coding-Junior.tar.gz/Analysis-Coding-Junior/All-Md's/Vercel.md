# Vercel Hosting

## Pro Plan of Vercel

### Bandwidth — the data server sends to the user's screen after each refresh

* 1 TB provided

  * Let's say our application scales to 100,000 users initially — even then, 500 KB per first load
  * For subsequent loads (due to caching), it will reduce — let’s assume 1.5 TB max in the worst case with high user activity
  * For the start, 1 TB/month is enough (though while coding, we’ll make sure the site isn’t unnecessarily heavy — I’ll remember this)
  * If we somehow cross 1 TB early on, overage cost in **Mumbai region** is: \$0.20/GB → extra 500 GB = **\$100/month**
  * In that case, we can consider discussing the **Enterprise plan** with Vercel
  * Best practice: don’t run heavy videos or large images natively — use **iframe/YouTube embeds** for course content
  * All images should be converted to `.webp`, lazy-loaded, compressed — standard image optimization practices (I’ll do all this thoroughly)
  * Avoid dynamic in-browser library loading (like MicroPip). Pre-bundle libraries instead. Use client-side cache/db if needed, but only when justified. Pre-bundling can **increase deployment size**.

---

### Edge Requests

* API calls, visiting a page (first time), refreshing a page ✅

* Navigating via router (Next.js), dynamic routes with ISR/SSR ✅

* Fetching API routes like `/api/xyz`, accessing fonts, images, assets ✅

* `<Image />` optimization, JSON, static files ✅

* 10 million edge requests/month included (Pro Plan) — enough at start

* For 500,000 users × 3–5 requests/user = 1.5M–2.5M/month

* If exceeded: Mumbai overage is **\$2.20 per 1M requests**

**Example Optimization**:
Instead of:

```http
GET /api/user  
GET /api/notifications  
GET /api/settings
```

Do:

```http
GET /api/dashboard?include=user,notifications,settings
```

**Use:**

* **TanStack Query** for caching
* **Zustand** for persistent global state

---

### Incremental Static Regeneration (ISR)

* 10M reads/month → \$0.44 per additional 1M
* 2M writes/month → \$4.40 per additional 1M
* Reads = page hits (when in cache window)
* Writes = on-demand static revalidation

**Strategy**:

* For content that doesn’t change often (e.g., docs, blogs), set high `revalidate` time (1 hour or more)
* ISR is backend triggered and counts toward **function CPU time**

---

### Fluid Active CPU (ISR/SSR/API compute)

* 16 hours/month included (CPU time)
* 1440 GB-Hours memory/month included
* Overage in Mumbai:

  * \$0.33 per additional CPU hour
  * \$0.0106 per additional GB-hour

**Note**:

* Mostly consumed during **ISR writes**, SSR, and API functions
* Reads from static cache do not use CPU

---

### Image Optimization

* 10,000 transformations/month
* 600,000 image cache reads/month
* 200,000 image cache writes/month
* Mumbai overage pricing:

  * \$0.0527 per 1K transforms
  * \$0.44 per 1M reads
  * \$4.40 per 1M writes

**Optimization Plan**:

* Use `next/image` everywhere
* Use `.webp`, compress at build time
* Images are minimal anyway — won’t breach limits

---

### Middleware

* Edge Middleware runs before request hits the page
* Useful for:

  * JWT-based auth validation
  * Logging, redirects, geo-based content, A/B testing
* Pro Plan provides **enough capacity**
* We have limited auth-based routes → won’t exceed limits

---

### Blob Storage

* 5 GB/month included
* \$0.025 per GB after that
* Used for storing uploaded files (if any)
* In our case, not a priority — very low usage

---

### Rate Limiting

* 1M included/month under **Vercel Firewall**
* \$0.55 per 1M extra requests
* Vercel-side rate limiting is **infrastructure level**
* App-level rate limiting via `express-rate-limit` or `axios-throttle` still required

---

### Vercel Firewall

* Custom Rules: 40
* IP Blocking: 100
* System Bypass Rules: 25
* WAF is adequate for protecting against basic bots, brute force

---

### Final Verdict

* For a **Next.js** app with SSR, API routes, auth, some media — **Vercel Pro Plan is ideal**
* One-click deploy, single repo, both frontend + backend
* Cheaper, faster, and easier than managing separate AWS infra
* Upgrade to **Enterprise** if:
  * We cross 10M edge or ISR usage
  * Bandwidth > 2 TB/month
  * Want private support, VPC, SLA, security features