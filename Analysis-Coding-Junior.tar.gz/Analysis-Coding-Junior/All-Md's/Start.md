# Requirements

1. Admin Panel (Low Priority)
   Not required at this stage. For now, we will implement scripts for onboarding one or two schools. These scripts will be designed in a way that can later be integrated into a full admin panel, allowing schools to manage student onboarding and automation themselves.

2. Blockly Integration (Must)
   Most of the work is completed. Remaining tasks include assignment handling and backend validation.

3. Python Module (Must)
   Core implementation is complete. Assignment handling and backend validation are still pending.

4. Turtle Module (Must)
   Core implementation is complete. Assignment handling and backend validation are still pending.

5. Multi-Tenant Architecture (Must)
   Nearly complete. Final integration and testing remain.

6. Authentication System (Must)
   Almost complete. Final implementation and validation are pending.

7. Customizable UI (Low Priority)
   Not started yet.
