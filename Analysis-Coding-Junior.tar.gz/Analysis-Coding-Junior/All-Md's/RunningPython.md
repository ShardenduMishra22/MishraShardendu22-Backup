# Running Python – Evaluation & Approaches

**This is an iterative process. Multiple refinements will be made before finalizing the optimal approach.**

## 1. Skulpt

* A Python-to-JavaScript interpreter that translates Python code into JavaScript for in-browser execution.
* Performs well for basic tasks (loops, arithmetic).
* Poor performance with complex logic or heavy computation.
* **No support for third-party libraries.**
* Used by platforms like Trinket.
* **Supports the Turtle module**, useful for visual learning.
* Cannot store compiled code in our database since it only provides an iframe for embedding.

## 2. Pyodide

* A full Python runtime compiled to WebAssembly (WASM), running entirely in the browser.
* Resource-intensive (high RAM and CPU usage).
* Supports many third-party libraries via **micropip**.
* Better suited for advanced Python features and use cases.

## 3. Pyodide Worker Runner

* A multithreaded variant of Pyodide utilizing Web Workers.
* Currently does not support package installation via `micropip`.
* Previously challenging to integrate with **Next.js**, but worth revisiting for improved performance isolation.

## 4. Running Python on Raspberry Pi

* Fully supported—Python runs natively.
* Requires real-device testing for confirmation (initial mobile emulator tests failed).

## 5. Alternatives (Not Preferred for Now)

* **Backend Execution**

  * Overkill for the current scope. Might be reconsidered for advanced use cases.

* **Jupyter + React Frontend**

  * Initial attempts failed. Will explore this further in future iterations.

* **ElectronJS + Thonny (Desktop App)**

  * Not applicable—our focus is web-based environments.

* **JDoodle API**

  * Not cost-effective. May be considered for higher-level (college) users later.

* **Piston API / Custom Piston Instance**

  * Highly dependent on external APIs.
  * Rate limits and hosting costs are concerns.
  * Under re-evaluation—may work with proper cost control and isolation.
