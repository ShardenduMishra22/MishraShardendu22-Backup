# Coding Junior – Final Summary

## Design.md

## Features.md

## Additional.md

## Components.md

## RunningPython.md
