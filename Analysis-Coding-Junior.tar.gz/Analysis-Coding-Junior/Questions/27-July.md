# Questions

- Q1. Please tell about the pages that will be made other than the landing page I already made ?
  - I'll provide wireframes of what is to be made.

- Q2. Types of users that will use the application ?
  - I'll provide the flow chart of the possible solution.

- Q3. Basic Idea of backend routes ?
  - I have given some sample routes
  - What auth will users have ?

- Q4. Idea about tech stack ?
  - Which database will we use ?
  - Please verify atleast a basic schema so I can start and as we need more features we can add accordingly.
