# Coding Junior Requirments

0 level blockly 

1 level thonny (change theme) (plugins add them and customise them)

2 lectures free few then all paid (courses are for teachers) 

3 edge impulse / rasberry pi 40 gpi pins with few defaults pins like diff proto cols like itc protocols, iamgine for  uart port to connect raspi and arduino and minpui ports to access camera and other ports to acces mics and camera .

4 edge impulse as they can access hardware data locally

5 rasberry pi and pi pico are options thonny on rasberry pi and use pico for the other thing 

6 j doodle api for like running the application

7 frotnend home page no login just courses details and when logged in you can add this things 

8 meet with didi for a meet, identify learn how i can make an library and reuse component