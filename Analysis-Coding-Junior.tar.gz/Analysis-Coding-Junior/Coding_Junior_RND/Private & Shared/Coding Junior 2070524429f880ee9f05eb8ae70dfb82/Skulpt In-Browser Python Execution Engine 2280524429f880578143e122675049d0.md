# Skulpt: In-Browser Python Execution Engine

**Skulpt** is a JavaScript-based Python interpreter that runs entirely in the browser. It simulates Python execution using JavaScript, without requiring a server or native Python environment.

---

## Architecture

- Runs fully client-side.
- Executes Python code in-memory.
- No real filesystem or OS-level access.
- No built-in persistence. Code is lost on reload unless explicitly saved.
- Can use `localStorage`, but that is limited and unreliable at scale.

---

## When to Use

Skulpt is appropriate for:

- Basic Python code (`print`, `if`, `for`, `def`).
- Lightweight, interactive code editors.
- Educational tools and demos.
- Environments where backend infrastructure is unavailable.

---

## When Not to Use

Avoid Skulpt if your project involves:

- Advanced language features like `asyncio`, decorators, or exception hierarchies.
- Standard libraries such as `math`, `json`, `re`, or `datetime`.
- Third-party libraries like `numpy`, `pandas`, or `matplotlib`.
- Any form of data persistence or complex I/O.

---

## Third-Party Packages

- Skulpt does not support native Python packages.
- It can simulate a few libraries using JavaScript mocks via `Sk.externalLibraries`.
- These are incomplete, limited in functionality, and prone to breakage.
- Examples include Trinket.io, which uses these mocks in a restricted environment.

Do not rely on them for any serious application.

---

## Performance

**Fast for:**

- Simple arithmetic
- Basic loops
- Short recursive calls

**Poor for:**

- Real-world business logic
- Complex operations
- Anything requiring consistent performance or memory management

Reference: [https://anvil.works/forum/t/questions-about-skulpt-underlying-anvil/14365/2](https://anvil.works/forum/t/questions-about-skulpt-underlying-anvil/14365/2)

---

## Stability and Maintenance

- Project is no longer actively maintained.
- Core developer is inactive.
- Dependencies are outdated and conflict with modern build tools.
- Fails under newer frameworks (e.g., React 19+).
- Prone to complete failure after dependency upgrades or structural refactors.

Example: used in a React-based project, broke completely after updating packages.

See: [https://vidkarya.vercel.app/](https://vidkarya.vercel.app/)

---

## Summary

| Feature | Skulpt |
| --- | --- |
| Python Support | Basic only |
| Package Support | None |
| File I/O | Not supported |
| Performance | Fast for simple code |
| Maintenance Status | Inactive |
| Production Ready | No |

**Use Skulpt only for:**

- Demos
- Code previews
- One-off tutorials

For all other use cases, prefer:

- [Pyodide](https://pyodide.org/) for full CPython in the browser
- Server-executed Python via APIs

---