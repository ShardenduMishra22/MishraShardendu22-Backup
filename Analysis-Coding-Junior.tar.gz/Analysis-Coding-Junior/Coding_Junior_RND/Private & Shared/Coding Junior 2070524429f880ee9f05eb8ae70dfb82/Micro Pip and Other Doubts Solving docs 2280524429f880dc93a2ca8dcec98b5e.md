# Micro Pip and Other Doubts Solving docs

1. It installs in browser memory, not in the server from what I have found, also you have to reinstall when refreshed so that settles the  fact that its not on server.
    
    I tried finding where exactly gpt says (i cant find them though)
    
    - Open **DevTools → Sources → Emscripten file system**
    - Navigate to `/lib/python3.11/site-packages/`
    
    Pyodide uses a virtual POSIX filesystem in the browser — created via Emscripten's in-memory FS.
    Virtual POSIX FS in Pyodide = Fake Linux-like Filesystem in Browser Memory
    POSIX = Portable Operating System Interface
    
    When I use `micropip` in Pyodide, it sets up a virtual POSIX-like filesystem basically a temporary Linux-like environment inside the browser’s memory. All installed Python packages like NumPy or pandas are placed in this in-memory structure, not on disk or server. Since this runs entirely in RAM, the more packages I install, the more memory the browser consumes. This can lead to performance drops, increased lag, or even crashes if I overload it. Everything is lost on refresh, so it’s a throwaway runtime meant for lightweight, temporary use.
    
    Personally tested 256mb (matplotlib) to 146mb(numpy like depends on library I guess) this could slow down and be bad UX.
    
2. Librarries 
    1. What libs can be used - [Link Docs](https://pyodide.org/en/stable/usage/packages-in-pyodide.html)
    2. cant be used
        - `opencv-python` (native C++, not WebAssembly-compatible)
        - `tensorflow`, `torch` (too heavy, C++/CUDA based)
        - `turtle` (**relies on native GUI**, not usable in browser) (Imporatant in our use case)
        - `pygame` (relies on SDL, not available in browser)
        - `tkinter` (desktop GUI, not supported)
        - `cv2` (same reason as OpenCV)
    
    alt to turtle maybe we can use some npm package, and some how connect them like I dont know yet but I am sure we can if things boil down to this we can figure something out (p5.js ). let me confirm use case once exactly then Ill conclude what can be done.
    
    https://github.com/ShardenduMishra22/tmep-turtle this does some work but its not a good thing its not scalable
    
    ### Why native C++ libs like OpenCV/turtle/tkinter still fail, though C/CPP run in wasm:
    
    ### 1. **Not compiled to WASM**
    
    Most Python packages with C++ code (e.g., `opencv-python`, `turtle`, `tkinter`) are **not compiled for WebAssembly**. Pyodide can only run code if it’s:
    
    - Pure Python, or
    - Precompiled to WebAssembly + linked correctly
    
    `pip install` or `micropip.install()` **won’t compile C++ extensions in the browser** that’s impossible.
    
    ### 2. **Missing Dependencies**
    
    GUI libs (like `turtle`, `tkinter`) depend on:
    
    - Native OS graphics APIs
    - Windowing systems (X11, Wayland, Windows API)
    - Event loops bound to desktop systems
    
    These have **no browser equivalent** and cannot be emulated inside WASM.
    
    C++ works in WASM, **but Python’s native C++-based packages won’t**, unless they are:
    
    - Precompiled for WASM
    - Free from OS dependencies (like GUI)
    - Explicitly supported by Pyodide or similar projects
    
    ### `.whl` — Python Wheel File
    
    - `.whl` = **Wheel**, a built Python package
    - It’s a **ZIP archive** that contains:
        - Python code
        - Metadata
        - Compiled extensions (if any)
    - Used by `pip` and `micropip` to install packages
3. Skulpt 
    - **Skulpt runs slower (JS interpreter vs WASM)**
    - **Limited external package support (no `numpy`, `pandas`, etc.)**
    - **Skulpt** = lighter, slower, pure JS Python engine with built-in turtle graphics, limited libs.
    - **Pyodide** = full CPython compiled to WASM, supports heavy libs but no native turtle.