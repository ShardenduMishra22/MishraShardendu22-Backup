# Trinket - Github Org

- they have am amazing turtle game where basically they give you a screen with a space ship that u can why source code is also given , we can try something like this - [Link](https://trinket.io/library/trinkets/992bde90dce4)  (Jypter NB is an amazing alt if we can find a way to improve its theme and embed it properly)
- it similarly has other tutorial with code that run and show amzing things we can add this as well
- Customized Blockly with a fork - [Link](https://github.com/trinketapp/blockly)
- Skulpt js to python compile - [Link](https://github.com/trinketapp/skulpt-docs), Limited Packages - [Link](https://trinket.io/docs/python) (not a good option imo)
- Jekyll - to embed Markdown like things (static site) [Link](https://trinketapp.github.io/jekyll-tools/) ( we can try using mdx, nextra uses mdx we can try that , its not very dependable last time i checked but i am sure I can do something)
    - **Running Python** = done by **Skulpt**
    - **Building the page** = done by **Jekyll**
    - **Embedding code** = enabled via `jekyll-tools`
- Rest for blockly they have simply embed it in skuplt that is basic blockly nothing special in that (though how they embed it is a great question)
- allow to create file and folder structure so people can save the info and code (basic we will do that too most probably
- skill builder ai is also same as them nothing new, they are using trinkers libraries and components.