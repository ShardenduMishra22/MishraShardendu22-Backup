# Reusable component

- icon library should be the same like lets say we use lucide-react (i recommend this cause other libs like sahdcn use this not that we are going to use shadcn but what if we do also its good not bad) Then only that none other
- Navbar and its element designs (sun moon icon the navbar element itself)
- Button designs
- testimonials design (optional not recommended cause like the one of kids has to be like of a little diff designs)
- footer (not recommended)
- so the main company behind this is career cafe so like the bottom most part like year@ cc privacy policy contact us some slogan (if its not an image or svg) (recommended)
- our mentors panel can be reused with various headings like it can also be used for like our students or something like basically testimonial reuse
- in phone app if we make a menu then that can be reused that would be a great idea
- platform backed by part and mentors from xyz company can be made as a component as it can be reused as i am pretty sure we will mention it not only in this but all future projects
- color theme is already being made in a way where its similar to cc website (no issues there)
- basically reusing components where there is a clear separation of UI/UX with respect to websites ideology and the idea of "These are different websites made by same developer (developer of the same company so not exactly a developer but the company is same maybe dev is diff doesn’t concern user)"