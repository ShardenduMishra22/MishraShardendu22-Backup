# How can we create the library on Github ?

- rollup to make custom packages for npm not needed here
- how can we test them to see how they look then and there ?
    - set up vite
    - have like a two folder structure
        - one for testing how they look
        - one to bundle them in library
    - setup taliwind css (we will probably most certainly definetly use this) ( gpt says setting  it up in peer dependency is wrong and i get why it says that , its beacasue way to setup taliwind css is diff for diff frameworks maybe thats why ) but maybe we should or else what he suggests is writting in docs to definetly install and use it only if tailwind is installed.
    - make our component and then push the lib
- install and use component directly form github no npm needed
- i tried this but I was facing some errors like module not found type of things, if there is a reference for this please share so I can see and learn from that.
    - I would also suggest that if we decide to push them as a npm package it would be easier and its not bad ( as I have done that earlier and we can always have the package as private but if not please guide with some reference repo or something ).