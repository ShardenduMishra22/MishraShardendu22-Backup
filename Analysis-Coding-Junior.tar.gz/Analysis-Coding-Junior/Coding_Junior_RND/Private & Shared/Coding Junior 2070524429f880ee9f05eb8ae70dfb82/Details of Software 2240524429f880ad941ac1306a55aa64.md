# Details of Software

1. Blockly Research
    1. Blockly React Code Sandbox - [Link](https://codesandbox.io/examples/package/react-blockly)