# Coding Junior

didi made component

brython sckulpt and pyodide are options ( work on it cause its heavy and can we optimsie to improve load time using cdn or caching)

performance issue and memory issue (not all libs available)

how can we run turle on pyodide, is debuggin easier or not.

saving a code like draft based on performance 

sculpt deekho kya h 

issues with pyodide

built a sample with react + pydodie + monaaco

[Skulpt: In-Browser Python Execution Engine](Coding%20Junior%202070524429f880ee9f05eb8ae70dfb82/Skulpt%20In-Browser%20Python%20Execution%20Engine%202280524429f880578143e122675049d0.md)

[Micro Pip and Other Doubts Solving docs ](Coding%20Junior%202070524429f880ee9f05eb8ae70dfb82/Micro%20Pip%20and%20Other%20Doubts%20Solving%20docs%202280524429f880dc93a2ca8dcec98b5e.md)

[Coding Junior Requirments](Coding%20Junior%202070524429f880ee9f05eb8ae70dfb82/Coding%20Junior%20Requirments%202240524429f8808da23afa373f2835d2.md)

[Trinket - [Github Org](https://github.com/trinketapp)](Coding%20Junior%202070524429f880ee9f05eb8ae70dfb82/Trinket%20-%20Github%20Org%202240524429f880dda861d7ed27c4e098.md)

[Reusable component](Coding%20Junior%202070524429f880ee9f05eb8ae70dfb82/Reusable%20component%202240524429f880f188c2cc942d28c48e.md)

[How can we create the library on Github ?](Coding%20Junior%202070524429f880ee9f05eb8ae70dfb82/How%20can%20we%20create%20the%20library%20on%20Github%202240524429f880788ac5d7ca0229e938.md)

[Minutes Meeting](Coding%20Junior%202070524429f880ee9f05eb8ae70dfb82/Minutes%20Meeting%202240524429f8809697c1e504c39d2680.md)

[Details of Software](Coding%20Junior%202070524429f880ee9f05eb8ae70dfb82/Details%20of%20Software%202240524429f880ad941ac1306a55aa64.md)