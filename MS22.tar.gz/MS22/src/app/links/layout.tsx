import type { Metadata } from "next";
import { generatePageMetadata } from "@/lib/metadata";

export const metadata: Metadata = generatePageMetadata({
  title: "Links & Social Media",
  description:
    "Connect with Shardendu Mishra across all platforms - GitHub, LinkedIn, Twitter, Instagram, LeetCode, and explore my projects including blogs, treasure hunt game, and pixel art tool.",
  path: "/links",
  keywords: [
    "Shardendu Mishra Links",
    "Social Media Links",
    "Developer Links",
    "GitHub Profile",
    "LinkedIn Profile",
    "Twitter Profile",
    "Instagram",
    "LeetCode Profile",
    "Contact Shardendu Mishra",
    "Developer Portfolio Links",
    "Tech Blog",
    "Coding Projects",
    "Connect With Developer",
    "Social Links",
    "Link Tree",
    "All Social Links",
    "Professional Network",
    "Coding Platforms",
    "Developer Community",
  ],
});

export default function LinksLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto lg:relative lg:flex-1 lg:z-auto lg:overflow-visible">
      {children}
    </div>
  );
}
