# PyMuPDF implementation for better PDF processing
import fitz  # PyMuPDF
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_ollama import OllamaEmbeddings
from langchain_community.llms import Ollama
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA
from langchain.schema import Document
import json
import datetime
import os
import re
import glob

def load_pdf_with_pymupdf(pdf_path):
    """Load PDF using PyMuPDF with enhanced metadata and better text extraction"""
    documents = []
    
    try:
        # Open PDF with PyMuPDF
        pdf_doc = fitz.open(pdf_path)
        
        print(f"📖 PDF Metadata: Title: {pdf_doc.metadata.get('title', 'N/A')}, Pages: {len(pdf_doc)}")
        
        for page_num in range(len(pdf_doc)):
            page = pdf_doc[page_num]
            
            # Extract text with better formatting preservation
            text = page.get_text("text")
            
            # Enhanced metadata with PyMuPDF features
            metadata = {
                'source': pdf_path,
                'page': page_num + 1,  # 1-indexed
                'page_label': f"Page {page_num + 1}",
                'total_pages': len(pdf_doc),
                'pdf_title': pdf_doc.metadata.get('title', ''),
                'pdf_author': pdf_doc.metadata.get('author', ''),
                'pdf_creator': pdf_doc.metadata.get('creator', ''),
                'text_length': len(text),
                'page_rotation': page.rotation,
                'page_width': page.rect.width,
                'page_height': page.rect.height
            }
            
            # Only add non-empty pages
            if text.strip():
                doc = Document(page_content=text.strip(), metadata=metadata)
                documents.append(doc)
            else:
                print(f"⚠️ Skipped empty page {page_num + 1}")
        
        pdf_doc.close()
        return documents
        
    except Exception as e:
        print(f"❌ Error loading PDF with PyMuPDF: {e}")
        return []

def extract_medical_condition(query):
    """Extract medical condition from query - now supports more conditions"""
    query_lower = query.lower()
    conditions = {
        # Medical procedures
        "knee surgery": ["knee surgery", "knee operation", "knee procedure", "arthroscopy"],
        "heart surgery": ["heart surgery", "cardiac surgery", "heart operation", "bypass"],
        "eye surgery": ["eye surgery", "cataract", "retina surgery", "lasik"],
        "dental treatment": ["dental", "tooth treatment", "oral surgery", "root canal"],
        "cancer treatment": ["cancer", "chemotherapy", "oncology", "tumor"],
        
        # Health conditions
        "maternity": ["maternity", "pregnancy", "delivery", "childbirth", "newborn"],
        "diabetes treatment": ["diabetes", "diabetic treatment", "blood sugar"],
        "hypertension": ["hypertension", "blood pressure", "bp"],
        
        # Travel-related
        "trip cancellation": ["trip cancellation", "travel cancellation", "flight cancelled"],
        "baggage loss": ["baggage loss", "luggage lost", "bag missing"],
        "flight delay": ["flight delay", "airline delay", "travel delay"],
        "medical emergency abroad": ["medical emergency", "emergency treatment", "hospitalization abroad"],
        
        # General insurance
        "accident": ["accident", "injury", "trauma"],
        "illness": ["illness", "disease", "sickness"],
        "hospitalization": ["hospitalization", "admission", "inpatient"]
    }
    
    for condition, keywords in conditions.items():
        for keyword in keywords:
            if keyword in query_lower:
                return condition
    
    # Fallback extraction
    medical_terms = re.findall(r'\b(?:surgery|treatment|procedure|operation|claim|coverage)\b', query_lower)
    if medical_terms:
        words = query_lower.split()
        for i, word in enumerate(words):
            if word in medical_terms and i > 0:
                return f"{words[i-1]} {word}"
    
    return "the requested procedure/coverage"

def detect_insurance_type(documents):
    """Detect the type of insurance policy from document content with improved accuracy"""
    # Use more documents for better detection
    full_text = " ".join([doc.page_content.lower() for doc in documents[:10]])
    
    # Enhanced keyword detection
    travel_keywords = ["travel", "trip", "baggage", "flight", "common carrier", "hijack", "tourism", 
                      "airline", "journey", "destination", "passport", "visa"]
    travel_score = sum(1 for keyword in travel_keywords if keyword in full_text)
    
    health_keywords = ["health", "medical", "hospital", "treatment", "surgery", "illness", "disease",
                      "physician", "diagnosis", "prescription", "clinic", "patient"]
    health_score = sum(1 for keyword in health_keywords if keyword in full_text)
    
    # Additional context scoring
    if "global health care" in full_text or "bajaj allianz" in full_text:
        health_score += 3
    if "cholamandalam" in full_text and "travel" in full_text:
        travel_score += 3
    
    print(f"🔍 Insurance Type Detection - Travel: {travel_score}, Health: {health_score}")
    
    # Determine policy type
    if travel_score > health_score:
        return "travel"
    elif health_score > travel_score:
        return "health"
    else:
        return "general"

def get_insurance_specific_prompt(insurance_type):
    """Get insurance type-specific prompt template with enhanced page number requirements"""
    
    if insurance_type == "travel":
        specific_focus = """
5. TRAVEL INSURANCE SPECIFIC ANALYSIS:
   - Check for trip duration limits and geographical coverage
   - Verify common carrier requirements for transportation claims
   - Look for adventure sports exclusions
   - Check terrorism coverage if applicable
   - Consider baggage limits and deductibles
   - Verify pre-existing condition clauses for medical emergencies abroad
"""
    elif insurance_type == "health":
        specific_focus = """
5. HEALTH INSURANCE SPECIFIC ANALYSIS:
   - Check waiting periods for specific treatments (2-4 years for major surgeries)
   - Verify pre-existing disease exclusions (48 months look-back)
   - Look for room rent limits and sub-limits
   - Check age-based coverage restrictions
   - Verify network/non-network hospital provisions
   - Consider maternity waiting periods (9-24 months)
"""
    else:
        specific_focus = """
5. GENERAL INSURANCE ANALYSIS:
   - Review all applicable coverage sections
   - Check for policy-specific exclusions
   - Verify claim eligibility criteria
"""

    # Enhanced template with strict page number requirements
    template = f"""You are an expert insurance claim assessor with deep knowledge of medical procedures, policy coverage, and claim evaluation. Your task is to analyze insurance claims against policy documents with precision and accuracy.

Policy Context:
----------------
{{context}}
----------------

Customer Query: {{question}}

ANALYSIS INSTRUCTIONS:
1. MEDICAL CONDITION/CLAIM IDENTIFICATION:
   - Extract the exact medical condition/procedure/claim type from the query
   - Identify patient demographics (age, gender, location) if provided
   - Note policy duration/waiting periods mentioned

2. POLICY SEARCH STRATEGY:
   - Search for EXACT matches of the condition/claim in policy context
   - Look for related categories (medical, travel, accident, etc.)
   - Check for exclusions, waiting periods, and coverage limits
   - Verify age-related restrictions if applicable

3. DECISION CRITERIA:
   - APPROVED: Clear coverage found with matching condition AND specific coverage amount found
   - REJECTED: Explicit exclusion found OR waiting period not met
   - NEEDS REVIEW: Partial coverage or ambiguous policy language
   - INSUFFICIENT DATA: Relevant policy sections not found in context

4. CRITICAL VALIDATION RULES:
   - DO NOT use general insurance knowledge or typical coverage amounts
   - DO NOT assume coverage amounts - only use EXACT figures from the policy context
   - If specific coverage amount is not found, use "Amount not specified in retrieved policy sections"
   - If no relevant policy sections found, respond with "Insufficient Data"
   - Quote ONLY the exact text that appears in the provided policy context

{specific_focus}

6. PAGE NUMBER REQUIREMENTS (MANDATORY):
   - You MUST identify and include the exact page number for EVERY piece of information you reference
   - The pages_referenced field should list ALL page numbers where relevant information was found
   - Each justification item MUST include the specific page number where that clause was found
   - If you cannot identify a page number, state "Page number not available in context"

RESPONSE FORMAT (JSON ONLY):
{{{{
  "decision": "Approved/Rejected/Needs Review/Insufficient Data",
  "amount": "ONLY exact amounts from policy context, or 'Amount not specified in retrieved policy sections', or 'Not Applicable'",
  "confidence": "High/Medium/Low",
  "insurance_type_detected": "{insurance_type}",
  "condition_identified": "Exact condition from query",
  "policy_match": "Direct/Partial/None",
  "waiting_period_status": "Met/Not Met/Not Applicable/Unknown",
  "pages_referenced": "Comma-separated list of ALL page numbers where relevant information was found (e.g., 'Page 25, Page 34, Page 47')",
  "total_pages_used": "Total number of different pages referenced",
  "justification": [
    {{{{
      "clause_type": "Coverage/Exclusion/Waiting Period/Age Limit",
      "section_reference": "Specific policy section from context",
      "page_number": "EXACT page number where this text was found (MANDATORY)",
      "exact_text": "Word-for-word quote from policy context",
      "application": "How this applies to the case"
    }}}}
  ],
  "additional_considerations": [
    "Any other relevant policy conditions found in context with page references"
  ]
}}}}

ABSOLUTE REQUIREMENTS:
- EVERY piece of information MUST include its source page number
- If you cannot find the condition/claim in policy context, set decision to "Insufficient Data"
- If you cannot find specific coverage amount, set amount to "Amount not specified in retrieved policy sections"
- Never invent policy clauses, amounts, or coverage details
- Only reference text that actually exists in the provided policy context
- The pages_referenced field is MANDATORY and must list all pages used in your analysis
- Each justification item MUST have a page_number field filled"""

    return template

def extract_page_numbers_from_result(result):
    """Extract page numbers from the result for enhanced display"""
    pages_from_sources = []
    pages_from_response = []
    
    # Get pages from source documents
    for doc in result["source_documents"]:
        page_num = doc.metadata.get('page', 'Unknown')
        if page_num != 'Unknown':
            pages_from_sources.append(str(page_num))
    
    # Try to get pages from LLM response
    try:
        response_data = json.loads(result["result"])
        if "pages_referenced" in response_data:
            pages_text = response_data["pages_referenced"]
            # Extract numbers from the pages_referenced field
            page_numbers = re.findall(r'\d+', str(pages_text))
            pages_from_response.extend(page_numbers)
        
        # Also check justification items for page numbers
        if "justification" in response_data:
            for item in response_data["justification"]:
                if "page_number" in item:
                    page_num = re.findall(r'\d+', str(item["page_number"]))
                    pages_from_response.extend(page_num)
    except:
        pass
    
    # Combine and deduplicate
    all_pages = list(set(pages_from_sources + pages_from_response))
    all_pages.sort(key=lambda x: int(x) if x.isdigit() else float('inf'))
    
    return all_pages, pages_from_sources, pages_from_response

def validate_response_against_sources(result):
    """Enhanced validation for different insurance types"""
    try:
        response_data = json.loads(result["result"])
        amount = response_data.get("amount", "")
        
        # Extract all numbers from the response
        response_numbers = re.findall(r'[\d,]+', amount)
        
        # Get all text from source documents
        source_text = " ".join([doc.page_content for doc in result["source_documents"]])
        
        # Check if response numbers exist in source
        hallucinated_amounts = []
        for num in response_numbers:
            if num not in source_text and len(num) > 2:
                hallucinated_amounts.append(num)
        
        # Check if page numbers are provided
        pages_referenced = response_data.get("pages_referenced", "")
        if not pages_referenced or pages_referenced == "":
            print("⚠️ Warning: No page numbers provided in response")
        
        if hallucinated_amounts:
            print(f"🚨 HALLUCINATED AMOUNTS DETECTED: {hallucinated_amounts}")
            return False, hallucinated_amounts
        
        return True, []
        
    except Exception as e:
        return False, [f"Validation error: {e}"]

def generate_enhanced_simple_output(query, result, insurance_type):
    """Generate simple output with prominent page number display"""
    try:
        response_data = json.loads(result["result"])
        condition = extract_medical_condition(query)
        decision = response_data.get("decision", "").lower()
        
        # Extract page information
        all_pages, source_pages, response_pages = extract_page_numbers_from_result(result)
        
        # Create page reference string
        if all_pages:
            page_ref = f" (Referenced from Pages: {', '.join(all_pages)})"
        else:
            page_ref = " (Page references not available)"
        
        # Insurance type specific messaging
        type_prefix = {
            "travel": "🧳 Travel Insurance:",
            "health": "🏥 Health Insurance:",
            "general": "📋 Insurance:"
        }.get(insurance_type, "📋 Insurance:")
        
        if decision == "approved":
            amount = response_data.get("amount", "")
            if "not specified" in amount.lower() or "not applicable" in amount.lower():
                base_msg = f"{type_prefix} ✅ Yes, {condition} is covered under the policy, but specific coverage amount not found in policy sections."
            else:
                base_msg = f"{type_prefix} ✅ Yes, {condition} is covered under the policy. Coverage: {amount}"
        elif decision == "rejected":
            base_msg = f"{type_prefix} ❌ No, {condition} is not covered under the policy."
        elif decision == "insufficient data":
            base_msg = f"{type_prefix} ❓ Cannot determine if {condition} is covered - relevant policy sections not found."
        else:
            base_msg = f"{type_prefix} ⚠️ {condition} requires manual review for coverage determination."
        
        return base_msg + page_ref
            
    except Exception as e:
        return f"❌ Error processing coverage determination for {extract_medical_condition(query)}."

def save_generalized_result(query, result, simple_answer, validation_status, insurance_type, pdf_name):
    """Save results with enhanced page information"""
    output_dir = "output"
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        parsed_response = json.loads(result["result"])
        json_valid = True
    except:
        json_valid = False
        parsed_response = None
    
    # Extract comprehensive page information
    all_pages, source_pages, response_pages = extract_page_numbers_from_result(result)
    
    # Enhanced page information
    pages_used = []
    for doc in result["source_documents"]:
        page_info = {
            "page_number": doc.metadata.get('page', 'Unknown'),
            "page_label": doc.metadata.get('page_label', 'Unknown'),
            "content_preview": doc.page_content[:200] + "..." if len(doc.page_content) > 200 else doc.page_content,
            "full_content": doc.page_content,
            "referenced_in_response": str(doc.metadata.get('page', 'Unknown')) in response_pages,
            "page_dimensions": f"{doc.metadata.get('page_width', 'N/A')}x{doc.metadata.get('page_height', 'N/A')}"
        }
        pages_used.append(page_info)
    
    output_data = {
        "timestamp": datetime.datetime.now().isoformat(),
        "pdf_source": pdf_name,
        "insurance_type_detected": insurance_type,
        "query": query,
        "simple_answer": simple_answer,
        "detailed_response": result["result"],
        "json_valid": json_valid,
        "parsed_response": parsed_response,
        "validation_passed": validation_status["is_valid"],
        "validation_issues": validation_status.get("issues", []),
        
        # Enhanced page information
        "page_analysis": {
            "all_pages_referenced": all_pages,
            "pages_from_sources": source_pages,
            "pages_from_llm_response": response_pages,
            "total_unique_pages": len(all_pages),
            "page_reference_consistency": len(response_pages) > 0
        },
        
        "pages_used": pages_used,
        "total_pages_referenced": len(pages_used),
        "source_documents": [
            {
                "content": doc.page_content,
                "metadata": doc.metadata,
                "page_number_extracted": doc.metadata.get('page', 'Unknown')
            }
            for doc in result["source_documents"]
        ],
        "system_info": {
            "model": "gemma:2b",
            "embedding_model": "nomic-embed-text",
            "framework": "LangChain + Ollama + PyMuPDF",
            "prompt_version": "PyMuPDF Enhanced v2.0"
        }
    }
    
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{output_dir}/pymupdf_result_{insurance_type}_{timestamp}.json"
    
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)
    
    return filename

def process_insurance_pdf(pdf_path):
    """Process any insurance PDF using PyMuPDF and return QA chain with detected type"""
    print(f"🔹 Loading document with PyMuPDF: {pdf_path}")
    
    # Use PyMuPDF instead of PyPDFLoader
    pages = load_pdf_with_pymupdf(pdf_path)
    
    if not pages:
        raise Exception("Failed to load PDF with PyMuPDF")
    
    print(f"📄 Successfully loaded {len(pages)} pages from {os.path.basename(pdf_path)}")

    # Better chunking for different insurance types
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,  # Slightly larger chunks for better context
        chunk_overlap=200,
        separators=["\n\n", "\n", ".", " ", ""]
    )
    documents = splitter.split_documents(pages)
    
    print(f"📝 Created {len(documents)} text chunks")
    
    # Detect insurance type with improved accuracy
    insurance_type = detect_insurance_type(documents)
    print(f"🔍 Detected insurance type: {insurance_type.upper()}")

    # Create FAISS index
    print("🔹 Creating vector store...")
    embedding = OllamaEmbeddings(model="nomic-embed-text")
    vectorstore = FAISS.from_documents(documents, embedding)

    # Load LLM
    print("🔹 Loading Gemma 2B...")
    llm = Ollama(model="gemma:2b", temperature=0.1)

    # Get insurance-specific prompt
    prompt_template_text = get_insurance_specific_prompt(insurance_type)
    prompt_template = PromptTemplate(
        input_variables=["context", "question"],
        template=prompt_template_text
    )

    # Setup QA chain
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=vectorstore.as_retriever(
            search_type="similarity",
            search_kwargs={"k": 8}  # More documents for comprehensive analysis
        ),
        chain_type="stuff",
        chain_type_kwargs={"prompt": prompt_template},
        return_source_documents=True
    )
    
    return qa_chain, insurance_type, documents

def main():
    # Find all PDF files in the current directory
    pdf_files = glob.glob("*.pdf")
    
    if not pdf_files:
        print("❌ No PDF files found in current directory!")
        return
    
    print(f"📁 Found {len(pdf_files)} PDF files: {pdf_files}")
    print("🚀 Using PyMuPDF for enhanced PDF processing!")
    
    # Test queries for different insurance types
    test_queries = {
        "health": [
            "46-year-old male, knee surgery in Pune, 3-month-old insurance policy",
            "25-year-old female, maternity claim, Mumbai, 6-month policy",
            "60-year-old male, heart surgery, Delhi, 2-year policy",
            "30-year-old female, dental treatment, Chennai, 1-year policy"
        ],
        "travel": [
            "Flight delayed by 8 hours due to bad weather, need accommodation expenses",
            "Baggage lost by airline during domestic travel, claim for replacement items",
            "Medical emergency during trip to Goa, hospitalization required",
            "Trip cancellation due to family member's illness"
        ],
        "general": [
            "Accident claim for vehicle damage",
            "Property damage due to fire",
            "Personal liability claim"
        ]
    }
    
    all_results = []
    
    # Process each PDF file
    for pdf_file in pdf_files:
        print(f"\n{'='*80}")
        print(f"🔄 PROCESSING WITH PYMUPDF: {pdf_file}")
        print("="*80)
        
        try:
            # Process the PDF with PyMuPDF
            qa_chain, insurance_type, documents = process_insurance_pdf(pdf_file)
            
            # Select appropriate test queries based on detected type
            if insurance_type in test_queries:
                selected_queries = test_queries[insurance_type]
            else:
                selected_queries = test_queries["general"]
            
            # Process queries for this PDF
            for i, query in enumerate(selected_queries, 1):
                print(f"\n--- Query {i} for {pdf_file} ---")
                print(f"Query: {query}")
                
                try:
                    result = qa_chain(query)
                    
                    # Extract page information
                    all_pages, source_pages, response_pages = extract_page_numbers_from_result(result)
                    
                    # Validate response
                    is_valid, issues = validate_response_against_sources(result)
                    validation_status = {"is_valid": is_valid, "issues": issues}
                    
                    # Generate simple answer with page numbers
                    simple_answer = generate_enhanced_simple_output(query, result, insurance_type)
                    
                    print(f"Answer: {simple_answer}")
                    
                    if not is_valid:
                        print(f"⚠️ Validation Issues: {issues}")
                    
                    # Enhanced page display
                    print(f"📄 Source Pages: {', '.join(source_pages) if source_pages else 'Not available'}")
                    print(f"📋 LLM Referenced Pages: {', '.join(response_pages) if response_pages else 'Not specified'}")
                    print(f"📊 Total Unique Pages: {len(all_pages)}")
                    
                    # Save result with PyMuPDF enhancement tracking
                    filename = save_generalized_result(
                        query, result, simple_answer, validation_status, 
                        insurance_type, os.path.basename(pdf_file)
                    )
                    
                    all_results.append({
                        "pdf_file": pdf_file,
                        "insurance_type": insurance_type,
                        "query": query,
                        "simple_answer": simple_answer,
                        "validation_passed": is_valid,
                        "all_pages_referenced": all_pages,
                        "source_pages": source_pages,
                        "llm_pages": response_pages,
                        "filename": filename,
                        "processing_method": "PyMuPDF",
                        "status": "success"
                    })
                    
                except Exception as e:
                    print(f"❌ Error processing query: {e}")
                    all_results.append({
                        "pdf_file": pdf_file,
                        "insurance_type": insurance_type,
                        "query": query,
                        "simple_answer": f"❌ Error processing query: {str(e)}",
                        "validation_passed": False,
                        "all_pages_referenced": [],
                        "filename": None,
                        "processing_method": "PyMuPDF",
                        "status": "error"
                    })
        
        except Exception as e:
            print(f"❌ Error processing PDF {pdf_file}: {e}")
    
    # Save comprehensive summary with PyMuPDF analytics
    summary = {
        "timestamp": datetime.datetime.now().isoformat(),
        "processing_method": "PyMuPDF Enhanced",
        "total_pdfs_processed": len(pdf_files),
        "total_queries": len(all_results),
        "successful_queries": len([r for r in all_results if r["status"] == "success"]),
        "validation_passed": len([r for r in all_results if r.get("validation_passed", False)]),
        "insurance_types_detected": list(set([r["insurance_type"] for r in all_results if "insurance_type" in r])),
        "page_analytics": {
            "queries_with_page_refs": len([r for r in all_results if r.get("all_pages_referenced", [])]),
            "average_pages_per_query": sum([len(r.get("all_pages_referenced", [])) for r in all_results]) / max(len(all_results), 1)
        },
        "pymupdf_benefits": {
            "enhanced_text_extraction": True,
            "better_page_tracking": True,
            "improved_metadata": True
        },
        "detailed_results": all_results
    }
    
    summary_filename = f"output/pymupdf_enhanced_summary_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(summary_filename, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    
    print(f"\n📊 PyMuPDF Enhanced Summary saved to: {summary_filename}")
    print(f"✅ Successfully processed: {summary['successful_queries']}/{summary['total_queries']} queries across {summary['total_pdfs_processed']} PDFs")
    if summary['insurance_types_detected']:
        print(f"🏷️ Insurance types detected: {', '.join(summary['insurance_types_detected'])}")
    print(f"📄 Page Reference Analytics: {summary['page_analytics']['queries_with_page_refs']}/{summary['total_queries']} queries included page references")
    print("🚀 PyMuPDF enhancements: Better text extraction, improved page tracking, enhanced metadata!")

if __name__ == "__main__":
    main()
