import NextAuth from 'next-auth';
import { PrismaAdapter } from '@auth/prisma-adapter';
import { Role } from '@prisma/client';

import { prisma } from '@/lib/prisma';

export const { handlers, auth } = NextAuth({
  adapter: PrismaAdapter(prisma),
  session: {
    strategy: 'database',
    maxAge: 60 * 60 * 12,
  },
  pages: {
    signIn: '/login',
  },
  providers: [],
  callbacks: {
    session({ session, user }) {
      if (session.user) {
        session.user.id = user.id;
        session.user.username = (user as { username?: string | null }).username ?? user.name ?? '';
        session.user.role = (user as { role?: Role | null }).role ?? Role.RECEPTIONIST;
        session.user.doctorDepartment = (user as { doctorDepartment?: string | null }).doctorDepartment ?? null;
      }

      return session;
    },
  },
});
