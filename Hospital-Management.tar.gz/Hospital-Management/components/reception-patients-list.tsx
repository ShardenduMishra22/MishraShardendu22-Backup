'use client';

import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';

import { PaginationControls } from '@/components/ui/pagination-controls';
import { type ReceptionPatientRecord } from '@/lib/reception-utils';

type ReceptionPatientsListProps = {
  patients: ReceptionPatientRecord[];
};

function statusClasses(status: string) {
  if (status === 'WAITING') return 'bg-amber-100 text-amber-700';
  if (status === 'CONSULTING') return 'bg-sky-100 text-sky-700';
  if (status === 'PRESCRIBED') return 'bg-emerald-100 text-emerald-700';
  if (status === 'DISPENSED') return 'bg-slate-200 text-slate-700';
  return 'bg-slate-100 text-slate-600';
}

export function ReceptionPatientsList({ patients }: ReceptionPatientsListProps) {
  const router = useRouter();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const totalPages = Math.max(1, Math.ceil(patients.length / pageSize));
  const currentPage = Math.min(page, totalPages);

  const paginatedPatients = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return patients.slice(start, start + pageSize);
  }, [patients, currentPage, pageSize]);

  if (patients.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-8 text-center text-sm text-slate-600">
        No real patient records are available yet. Add a patient from the Registration Desk to populate this page.
      </div>
    );
  }

  return (
    <>
      <div className="overflow-hidden rounded-xl border border-slate-200">
        <table className="min-w-full divide-y divide-slate-200 text-sm">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                Name
              </th>
              <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                Status
              </th>
              <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                Token No.
              </th>
              <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                Department
              </th>
              <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                Phone
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 bg-white">
            {paginatedPatients.map((patient) => (
              <tr
                key={patient.patientUuid}
                role="button"
                tabIndex={0}
                onClick={() => router.push(`/reception/patients/${patient.patientUuid}`)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    router.push(`/reception/patients/${patient.patientUuid}`);
                  }
                }}
                className="cursor-pointer transition-colors hover:bg-[#0f5ea8]/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0f5ea8]/30"
              >
                <td className="px-4 py-3">
                  <p className="font-medium text-[#0f5ea8]">
                    {patient.name}
                  </p>
                  <p className="mt-1 font-mono text-xs text-slate-500">{patient.patientUuid}</p>
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${statusClasses(patient.status)}`}
                  >
                    {patient.status === 'NO_VISIT' ? 'No Active Visit' : patient.status}
                  </span>
                </td>
                <td className="px-4 py-3 font-mono text-sm text-slate-700">
                  {patient.tokenNo}
                </td>
                <td className="px-4 py-3 text-slate-700">{patient.department}</td>
                <td className="px-4 py-3 font-mono text-slate-700">{patient.phone}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <PaginationControls
        totalItems={patients.length}
        page={currentPage}
        pageSize={pageSize}
        onPageChange={setPage}
        onPageSizeChange={(next) => {
          setPageSize(next);
          setPage(1);
        }}
        itemLabel="patients"
        pageSizeOptions={[5, 10, 20]}
      />
    </>
  );
}
