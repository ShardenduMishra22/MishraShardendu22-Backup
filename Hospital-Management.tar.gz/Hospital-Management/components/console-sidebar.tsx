'use client';

import type { ReactNode } from 'react';
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  ClipboardCheck,
  ClipboardList,
  FileScan,
  PanelLeftClose,
  PanelLeftOpen,
  KeyRound,
  Pill,
  Printer,
  Shield,
  Search,
  Stethoscope,
  ShieldCheck,
  Users,
  type LucideIcon,
} from 'lucide-react';

const ICONS = {
  clipboardCheck: ClipboardCheck,
  clipboardList: ClipboardList,
  fileScan: FileScan,
  keyRound: KeyRound,
  pill: Pill,
  printer: Printer,
  search: Search,
  shield: Shield,
  shieldCheck: ShieldCheck,
  stethoscope: Stethoscope,
  users: Users,
} satisfies Record<string, LucideIcon>;

type ConsoleSidebarProps = {
  title: string;
  description: string;
  items: ReadonlyArray<{
    href?: string;
    label: string;
    detail: string;
    icon: string;
    matchers?: readonly string[];
    disabled?: boolean;
  }>;
  sidebarContent?: ReactNode;
};

export function ConsoleSidebar({
  title,
  description,
  items,
  sidebarContent,
}: ConsoleSidebarProps) {
  const pathname = usePathname();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [username, setUsername] = useState('User');

  useEffect(() => {
    let isActive = true;

    async function loadSessionName() {
      try {
        const response = await fetch('/api/auth/session', { cache: 'no-store' });
        if (!response.ok) {
          return;
        }

        const payload = (await response.json().catch(() => null)) as
          | {
            user?: {
              username?: string;
              name?: string;
            };
          }
          | null;

        const nextName = payload?.user?.username ?? payload?.user?.name ?? '';

        if (isActive && nextName.trim()) {
          setUsername(nextName.trim());
        }
      } catch {
        // Keep fallback label when session read fails.
      }
    }

    void loadSessionName();

    return () => {
      isActive = false;
    };
  }, []);

  const profileHref = useMemo(() => {
    if (pathname.startsWith('/doctor')) return '/doctor/profile';
    if (pathname.startsWith('/reception')) return '/reception/profile';
    if (pathname.startsWith('/pharmacy')) return '/pharmacy/profile';
    return null;
  }, [pathname]);

  const getMatchLength = (matcher: string) => {
    if (matcher === pathname) return matcher.length;
    if (matcher !== '/' && pathname.startsWith(`${matcher}/`)) return matcher.length;
    return -1;
  };

  const activeLengths = items.map((item) =>
    Math.max(...(item.matchers?.map(getMatchLength) ?? [-1])),
  );
  const activeMatchLength = Math.max(...activeLengths);

  return (
    <aside
      className={`hidden h-screen shrink-0 border-r border-slate-200 bg-white transition-[width] duration-200 lg:flex lg:flex-col ${
        isCollapsed ? 'w-20' : 'w-80'
      }`}
    >
      <div className={`border-b border-slate-200 ${isCollapsed ? 'px-3 py-4' : 'px-6 py-6'}`}>
        {isCollapsed ? (
          <div className="flex flex-col items-center gap-2">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-slate-100 font-mono text-sm font-semibold text-slate-700">
              HM
            </div>
            <button
              type="button"
              onClick={() => setIsCollapsed((value) => !value)}
              className="inline-flex h-10 items-center justify-center px-3 text-slate-500 transition-colors hover:text-slate-900"
              aria-label="Open sidebar"
              title="Open sidebar"
            >
              <PanelLeftOpen className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <h1 className="font-display text-2xl font-semibold tracking-tight">
                {title}
              </h1>
            </div>

            <button
              type="button"
              onClick={() => setIsCollapsed((value) => !value)}
              className="inline-flex h-10 items-center justify-center px-3 text-slate-500 transition-colors hover:text-slate-900"
              aria-label="Close sidebar"
              title="Close sidebar"
            >
              <PanelLeftClose className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>

      <div className={`min-h-0 flex-1 overflow-y-auto subtle-scrollbar ${isCollapsed ? 'px-2 py-4' : 'px-3 py-4'}`}>
        <nav className="space-y-1">
          {items.map((item, index) => {
            const Icon = ICONS[item.icon as keyof typeof ICONS] ?? Search;
            const itemMatchLength = activeLengths[index] ?? -1;
            const isActive = itemMatchLength > -1 && itemMatchLength === activeMatchLength;
            const itemKey = `${item.href ?? 'static'}-${item.label}-${index}`;

            const content = (
              <div
                className={`rounded-lg px-4 py-3 transition-colors ${
                  item.disabled
                    ? 'cursor-not-allowed text-slate-400'
                    : isActive
                      ? 'bg-slate-100 text-slate-900'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
                title={item.label}
              >
                <div className={`flex ${isCollapsed ? 'justify-center' : 'items-start gap-3'}`}>
                  <Icon className="mt-0.5 h-5 w-5 shrink-0" />
                  {!isCollapsed && (
                    <div>
                      <p className="font-display text-base font-semibold leading-none">
                        {item.label}
                      </p>
                      <p className="mt-1 text-sm text-slate-500">{item.detail}</p>
                    </div>
                  )}
                </div>
              </div>
            );

            if (item.disabled || !item.href) {
              return <div key={itemKey}>{content}</div>;
            }

            return (
              <Link key={itemKey} href={item.href}>
                {content}
              </Link>
            );
          })}
        </nav>

        {!isCollapsed && sidebarContent ? (
          <div className="mt-6 border-t border-slate-200 pt-6">{sidebarContent}</div>
        ) : null}
      </div>

      <div className={`${isCollapsed ? 'px-2 pb-4' : 'px-3 pb-4 pt-3 border-t border-slate-200'}`}>
        {isCollapsed ? (
          <Link
            href="/logout"
            className="block rounded-lg px-4 py-3 text-center font-mono text-sm font-semibold text-slate-600 transition-colors hover:bg-slate-50 hover:text-slate-900"
            title="Sign out"
          >
            ⎋
          </Link>
        ) : (
          <>
            {profileHref ? (
              <Link
                href={profileHref}
                className="flex items-center gap-3 rounded-lg px-2 py-2.5 transition-colors hover:bg-slate-100"
              >
                <Users className="h-6 w-6 text-slate-600" />
                <span className="min-w-0">
                  <span className="block truncate text-base font-semibold leading-5 text-slate-900">{username}</span>
                  <span className="mt-0.5 block text-sm text-slate-500">View profile</span>
                </span>
              </Link>
            ) : (
              <div className="flex items-center gap-3 px-2 py-2.5">
                <Users className="h-6 w-6 text-slate-600" />
                <span className="min-w-0 truncate text-base font-semibold leading-5 text-slate-900">{username}</span>
              </div>
            )}

            <Link
              href="/logout"
              className="mt-1 ml-9 inline-flex rounded-md px-2 py-1.5 text-base font-semibold text-slate-700 transition-colors hover:bg-slate-100"
            >
              Sign out
            </Link>
          </>
        )}
      </div>
    </aside>
  );
}
