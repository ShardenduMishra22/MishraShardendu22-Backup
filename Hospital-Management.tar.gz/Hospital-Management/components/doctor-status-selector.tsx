'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type VisitWorkflowStatus = 'WAITING' | 'CONSULTING' | 'PRESCRIBED' | 'DISPENSED';

const VISIT_STATUS_OPTIONS: VisitWorkflowStatus[] = [
  'WAITING',
  'CONSULTING',
  'PRESCRIBED',
  'DISPENSED',
];

type DoctorStatusSelectorProps = {
  visitId: string;
  status: string;
};

export function DoctorStatusSelector({ visitId, status }: DoctorStatusSelectorProps) {
  const router = useRouter();
  const [value, setValue] = useState(status as VisitWorkflowStatus);
  const [isUpdating, setIsUpdating] = useState(false);

  const handleChange = async (nextStatus: VisitWorkflowStatus) => {
    if (nextStatus === value) {
      return;
    }

    const previous = value;

    try {
      setIsUpdating(true);
      setValue(nextStatus);

      const response = await fetch(`/api/doctor/visits/${visitId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: nextStatus }),
      });

      if (!response.ok) {
        throw new Error('Failed to update visit status.');
      }

      router.refresh();
    } catch {
      setValue(previous);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div>
      <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">
        Visit Status
      </p>
      <select
        value={value}
        disabled={isUpdating}
        onChange={(event) => {
          void handleChange(event.target.value as VisitWorkflowStatus);
        }}
        className="app-select mt-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 disabled:opacity-60"
      >
        {VISIT_STATUS_OPTIONS.map((item) => (
          <option key={item} value={item}>
            {item}
          </option>
        ))}
      </select>
    </div>
  );
}
