'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type ScannerFormProps = {
  visitId: string;
};

type Feedback = {
  tone: 'success' | 'warning';
  message: string;
};

async function readJson<T>(response: Response): Promise<T> {
  const payload = (await response.json().catch(() => null)) as
    | { error?: string }
    | T
    | null;

  if (!response.ok) {
    throw new Error(
      (payload && typeof payload === 'object' && 'error' in payload && payload.error) ||
        'Request failed.',
    );
  }

  return payload as T;
}

export function DoctorReportScanner({ visitId }: ScannerFormProps) {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [remarks, setRemarks] = useState('');
  const [extractedText, setExtractedText] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [feedback, setFeedback] = useState<Feedback | null>(null);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!file) {
      setFeedback({ tone: 'warning', message: 'Please select a scanned file first.' });
      return;
    }

    try {
      setIsSaving(true);
      setFeedback(null);

      const formData = new FormData();
      formData.append('scanFile', file);
      if (remarks.trim()) {
        formData.append('doctorRemarks', remarks.trim());
      }
      if (extractedText.trim()) {
        formData.append('text', extractedText.trim());
      }

      await readJson(
        await fetch(`/api/doctor/visits/${visitId}/reports`, {
          method: 'POST',
          body: formData,
        }),
      );

      setFeedback({
        tone: 'success',
        message: 'Scanned report saved to patient profile successfully.',
      });
      setFile(null);
      setRemarks('');
      setExtractedText('');
      router.refresh();
    } catch (error) {
      setFeedback({
        tone: 'warning',
        message:
          error instanceof Error
            ? error.message
            : 'Unable to save scanned report right now.',
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="mb-2 block font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
          Scan File
        </label>
        <input
          type="file"
          accept=".png,.jpg,.jpeg,.webp,.pdf"
          onChange={(event) => setFile(event.target.files?.[0] ?? null)}
          className="block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-700"
        />
        <p className="mt-2 text-xs text-slate-500">
          Allowed formats: PNG, JPG, WEBP, PDF.
        </p>
      </div>

      <div>
        <label className="mb-2 block font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
          Doctor Remarks
        </label>
        <textarea
          value={remarks}
          onChange={(event) => setRemarks(event.target.value)}
          rows={3}
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-700"
          placeholder="Optional remarks for this scanned report"
        />
      </div>

      <div>
        <label className="mb-2 block font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
          Extracted Text
        </label>
        <textarea
          value={extractedText}
          onChange={(event) => setExtractedText(event.target.value)}
          rows={3}
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-700"
          placeholder="Optional OCR text"
        />
      </div>

      <button
        type="submit"
        disabled={isSaving}
        className="inline-flex w-full items-center justify-center rounded-lg bg-[#0f5ea8] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#0c4d8a] disabled:cursor-not-allowed disabled:opacity-60"
      >
        {isSaving ? 'Saving Scan...' : 'Save Scanned Report'}
      </button>

      {feedback ? (
        <p
          className={`rounded-lg border px-3 py-2 text-sm ${
            feedback.tone === 'success'
              ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
              : 'border-amber-200 bg-amber-50 text-amber-700'
          }`}
        >
          {feedback.message}
        </p>
      ) : null}
    </form>
  );
}
