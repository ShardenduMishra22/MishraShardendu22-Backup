'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { Search, ShieldAlert } from 'lucide-react';

import { PaginationControls } from '@/components/ui/pagination-controls';
import { type PharmacyQueueVisit } from '@/lib/pharmacy-utils';

function normalizeValue(value: string) {
  return value.trim().toLowerCase();
}

function normalizeCompact(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]/g, '');
}

function digitsOnly(value: string) {
  return value.replace(/\D/g, '');
}

type PharmacyQueuePanelProps = {
  queue: PharmacyQueueVisit[];
};

export function PharmacyQueuePanel({ queue }: PharmacyQueuePanelProps) {
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const filteredQueue = useMemo(() => {
    const raw = query.trim();

    if (!raw) {
      return queue;
    }

    const upper = raw.toUpperCase();
    const normalized = normalizeValue(raw);
    const compact = normalizeCompact(raw);
    const digits = digitsOnly(raw);

    return queue
      .map((visit) => {
        let score = 0;

        if (visit.id.toUpperCase().includes(upper)) score += 6;
        if (visit.patient.patientUuid.toUpperCase().includes(upper)) score += 6;
        if (normalizeValue(visit.patient.name).includes(normalized)) score += 4;
        if (normalizeValue(visit.department).includes(normalized)) score += 2;
        if (normalizeValue(visit.status).includes(normalized)) score += 1;
        if (compact && normalizeCompact(visit.id).includes(compact)) score += 6;
        if (compact && normalizeCompact(visit.patient.patientUuid).includes(compact)) score += 6;
        if (compact && normalizeCompact(visit.patient.name).includes(compact)) score += 4;
        if (compact && normalizeCompact(visit.department).includes(compact)) score += 2;
        if (compact && normalizeCompact(visit.status).includes(compact)) score += 1;
        if (digits && visit.tokenNo.includes(digits)) score += 2;

        return { visit, score };
      })
      .filter((entry) => entry.score > 0)
      .sort((left, right) => right.score - left.score)
      .map((entry) => entry.visit);
  }, [query, queue]);

  const quickOpenVisit = filteredQueue[0] ?? null;
  const totalPages = Math.max(1, Math.ceil(filteredQueue.length / pageSize));
  const currentPage = Math.min(page, totalPages);

  const paginatedQueue = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredQueue.slice(start, start + pageSize);
  }, [filteredQueue, currentPage, pageSize]);

  const handleQueryChange = (value: string) => {
    setQuery(value);
    setPage(1);
  };

  return (
    <>
      <div className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex items-start gap-3">
          <Search className="mt-1 h-5 w-5 text-[#0f5ea8]" />
          <div>
            <h2 className="font-display text-xl font-semibold">Find Dispense Visit</h2>
            <p className="mt-1 text-sm text-slate-600">
              Search by visit ID, patient UUID, patient name, token number, or department.
            </p>
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
          <input
            value={query}
            onChange={(event) => handleQueryChange(event.target.value)}
            className="w-full rounded-lg border border-slate-300 bg-white px-4 py-3 text-base outline-none focus:border-[#0f5ea8]"
            placeholder="VISIT-..., patient UUID, patient name, token..."
          />
          {quickOpenVisit ? (
            <Link
              href={`/pharmacy/dispense/${quickOpenVisit.id}`}
              className="inline-flex items-center justify-center rounded-lg bg-[#0f5ea8] px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-[#0c4d8a]"
            >
              Open Top Match
            </Link>
          ) : (
            <button
              type="button"
              disabled
              className="inline-flex items-center justify-center rounded-lg bg-slate-200 px-4 py-3 text-sm font-medium text-slate-500"
            >
              Open Top Match
            </button>
          )}
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex items-center justify-between gap-4">
          <h2 className="font-display text-xl font-semibold">Prescribed Queue</h2>
          <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
            {filteredQueue.length} visit{filteredQueue.length === 1 ? '' : 's'}
          </span>
        </div>

        <div className="mt-4 space-y-3">
          {filteredQueue.length > 0 ? (
            paginatedQueue.map((visit) => (
              <Link
                key={visit.id}
                href={`/pharmacy/dispense/${visit.id}`}
                className="flex items-center justify-between rounded-lg border border-slate-200 p-4 transition-colors hover:border-[#0f5ea8] hover:bg-slate-50"
              >
                <div>
                  <p className="text-sm font-semibold text-slate-900">{visit.patient.name}</p>
                  <p className="mt-1 text-sm text-slate-600">
                    UUID {visit.patient.patientUuid} • Token {visit.tokenNo}
                  </p>
                  <p className="mt-1 text-sm text-slate-500">
                    {visit.department} • {visit.pendingItems} pending item(s)
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-mono text-sm font-semibold text-[#0f5ea8]">{visit.id}</p>
                  <p className="mt-1 text-xs font-medium text-slate-500">{visit.status}</p>
                </div>
              </Link>
            ))
          ) : (
            <div className="flex items-center gap-3 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-700">
              <ShieldAlert className="h-4 w-4" />
              No matching visits found. Pharmacy queue only shows PRESCRIBED / DISPENSED visits.
            </div>
          )}
        </div>

        {filteredQueue.length > 0 ? (
          <PaginationControls
            totalItems={filteredQueue.length}
            page={currentPage}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={(next) => {
              setPageSize(next);
              setPage(1);
            }}
            itemLabel="visits"
            pageSizeOptions={[5, 10, 20]}
          />
        ) : null}
      </div>
    </>
  );
}
