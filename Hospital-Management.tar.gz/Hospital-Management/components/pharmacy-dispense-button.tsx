'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type PharmacyDispenseButtonProps = {
  visitId: string;
  disabled: boolean;
};

export function PharmacyDispenseButton({ visitId, disabled }: PharmacyDispenseButtonProps) {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDispense = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`/api/pharmacy/visits/${visitId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'DISPENSE_ALL' }),
      });

      if (!response.ok) {
        const payload = (await response.json().catch(() => null)) as
          | { error?: string }
          | null;
        throw new Error(payload?.error ?? 'Failed to mark as dispensed.');
      }

      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to mark as dispensed.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <button
        type="button"
        disabled={disabled || isLoading}
        onClick={() => {
          void handleDispense();
        }}
        className="inline-flex items-center justify-center rounded-lg bg-[#0f5ea8] px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-[#0c4d8a] disabled:cursor-not-allowed disabled:opacity-60"
      >
        {isLoading ? 'Dispensing...' : 'Mark as Dispensed'}
      </button>

      {error ? <p className="mt-2 text-sm font-medium text-amber-700">{error}</p> : null}
    </div>
  );
}
