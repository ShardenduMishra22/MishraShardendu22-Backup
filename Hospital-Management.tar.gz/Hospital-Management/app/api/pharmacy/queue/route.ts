import { NextResponse } from 'next/server';

import { getPharmacyQueueVisits, getPharmacyStockAlerts } from '@/lib/pharmacy-data';

export async function GET() {
  try {
    const [queue, stockAlerts] = await Promise.all([
      getPharmacyQueueVisits(),
      getPharmacyStockAlerts(),
    ]);

    return NextResponse.json({ queue, stockAlerts });
  } catch (error) {
    console.error('Error fetching pharmacy queue:', error);
    return NextResponse.json(
      { error: 'Failed to fetch pharmacy queue.' },
      { status: 500 },
    );
  }
}
