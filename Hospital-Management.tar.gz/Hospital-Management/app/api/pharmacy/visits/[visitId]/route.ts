import { NextResponse } from 'next/server';

import { dispensePharmacyVisit, getPharmacyVisitById } from '@/lib/pharmacy-data';

type RouteContext = {
  params: Promise<{
    visitId: string;
  }>;
};

export async function GET(_request: Request, context: RouteContext) {
  const { visitId } = await context.params;

  try {
    const visit = await getPharmacyVisitById(visitId);

    if (!visit) {
      return NextResponse.json({ error: 'Visit not found.' }, { status: 404 });
    }

    return NextResponse.json(visit);
  } catch (error) {
    console.error('Error fetching pharmacy visit:', error);
    return NextResponse.json(
      { error: 'Failed to fetch pharmacy visit.' },
      { status: 500 },
    );
  }
}

export async function PATCH(request: Request, context: RouteContext) {
  const { visitId } = await context.params;

  try {
    const body = (await request.json().catch(() => null)) as { action?: string } | null;

    if (body?.action !== 'DISPENSE_ALL') {
      return NextResponse.json(
        { error: 'Invalid action. Use DISPENSE_ALL.' },
        { status: 400 },
      );
    }

    const updatedVisit = await dispensePharmacyVisit(visitId);
    return NextResponse.json(updatedVisit);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to dispense visit.';

    if (message === 'Visit not found.') {
      return NextResponse.json({ error: message }, { status: 404 });
    }

    return NextResponse.json({ error: message }, { status: 400 });
  }
}
