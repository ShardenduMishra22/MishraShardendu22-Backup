import { NextResponse } from 'next/server';

import { prisma } from '@/lib/prisma';

export async function GET() {
  const checkedAt = new Date().toISOString();

  try {
    await prisma.$queryRaw`SELECT 1`;

    return NextResponse.json({
      ok: true,
      service: 'database',
      checkedAt,
      message: 'Database connection is healthy.',
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Unknown database connection error';

    console.error('Database health check failed:', error);

    return NextResponse.json(
      {
        ok: false,
        service: 'database',
        checkedAt,
        message: 'Database connection failed.',
        error: message,
      },
      { status: 503 },
    );
  }
}
