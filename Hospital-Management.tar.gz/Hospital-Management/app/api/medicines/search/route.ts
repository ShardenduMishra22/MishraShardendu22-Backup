import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';


export async function GET(request: Request) {
  // 1. Get the search query from the URL (e.g., /api/medicines/search?q=para)
  const { searchParams } = new URL(request.url);
  const query = searchParams.get('q');

  // If the doctor hasn't typed anything, return an empty array
  if (!query) {
    return NextResponse.json([]);
  }

  try {
    // 2. Query the Neon database using Prisma
    const medicines = await prisma.medicine.findMany({
      where: {
        name: {
          contains: query,
          mode: 'insensitive', // Makes "Para" and "para" return the same thing
        },
      },
      take: 10, // Limit to 10 results so the dropdown doesn't lag
      select: {
        id: true,
        name: true,
        stockQuantity: true, // Useful to show the doctor if it's actually in stock!
      }
    });

    // 3. Send the results back to the frontend
    return NextResponse.json(medicines);
    
  } catch (error) {
    console.error("Error fetching medicines:", error);
    return NextResponse.json(
      { error: 'Failed to fetch medicines' }, 
      { status: 500 }
    );
  }
}