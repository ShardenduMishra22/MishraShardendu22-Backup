import { NextResponse } from 'next/server';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { Role } from '@prisma/client';

import { createDoctorScannedReportForVisit } from '@/lib/reception-data';
import { getSession } from '@/lib/auth';

export const runtime = 'nodejs';

type RouteContext = {
  params: Promise<{
    visitId: string;
  }>;
};

type CreateReportBody = {
  imageUrl?: unknown;
  doctorRemarks?: unknown;
  text?: unknown;
};

const ALLOWED_UPLOAD_TYPES = new Set([
  'image/png',
  'image/jpeg',
  'image/jpg',
  'image/webp',
  'application/pdf',
]);

function toOptionalString(value: FormDataEntryValue | null) {
  if (typeof value !== 'string') {
    return undefined;
  }

  const trimmed = value.trim();
  return trimmed || undefined;
}

async function persistReportUpload(file: File) {
  if (!ALLOWED_UPLOAD_TYPES.has(file.type)) {
    throw new Error('Only PNG, JPG, WEBP, or PDF files are allowed.');
  }

  const uploadsDir = path.join(process.cwd(), 'public', 'uploads', 'reports');
  await mkdir(uploadsDir, { recursive: true });

  const extension =
    file.type === 'application/pdf'
      ? 'pdf'
      : file.type === 'image/png'
        ? 'png'
        : file.type === 'image/webp'
          ? 'webp'
          : 'jpg';

  const fileName = `${Date.now()}-${randomUUID()}.${extension}`;
  const outputPath = path.join(uploadsDir, fileName);
  const buffer = Buffer.from(await file.arrayBuffer());

  await writeFile(outputPath, buffer);

  return `/uploads/reports/${fileName}`;
}

export async function POST(request: Request, context: RouteContext) {
  const { visitId } = await context.params;

  try {
    const session = await getSession();

    if (!session || (session.role !== Role.DOCTOR && session.role !== Role.ADMIN)) {
      return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });
    }

    let imageUrl = '';
    let doctorRemarks: string | undefined;
    let text: string | undefined;

    const contentType = request.headers.get('content-type') ?? '';

    if (contentType.includes('multipart/form-data')) {
      const form = await request.formData();
      const file = form.get('scanFile');

      doctorRemarks = toOptionalString(form.get('doctorRemarks'));
      text = toOptionalString(form.get('text'));

      if (!(file instanceof File)) {
        return NextResponse.json(
          { error: 'scanFile is required.' },
          { status: 400 },
        );
      }

      imageUrl = await persistReportUpload(file);
    } else {
      const body = (await request.json().catch(() => null)) as CreateReportBody | null;

      imageUrl = typeof body?.imageUrl === 'string' ? body.imageUrl.trim() : '';
      doctorRemarks = typeof body?.doctorRemarks === 'string' ? body.doctorRemarks : undefined;
      text = typeof body?.text === 'string' ? body.text : undefined;
    }

    if (!imageUrl) {
      return NextResponse.json(
        { error: 'imageUrl is required.' },
        { status: 400 },
      );
    }

    const report = await createDoctorScannedReportForVisit({
      visitId,
      imageUrl,
      doctorRemarks,
      text,
    });

    return NextResponse.json(report, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === 'Visit not found.') {
      return NextResponse.json({ error: 'Visit not found.' }, { status: 404 });
    }

    if (
      error instanceof Error &&
      error.message === 'Only PNG, JPG, WEBP, or PDF files are allowed.'
    ) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    console.error('Error creating doctor scanned report:', error);
    return NextResponse.json(
      { error: 'Failed to store scanned report.' },
      { status: 500 },
    );
  }
}