import { NextResponse } from 'next/server';
import { Prisma, VisitStatus } from '@prisma/client';

import {
  getDoctorConsultDetailsById,
  updateDoctorVisitStatus,
} from '@/lib/reception-data';

type RouteContext = {
  params: Promise<{
    visitId: string;
  }>;
};

export async function GET(_request: Request, context: RouteContext) {
  const { visitId } = await context.params;

  try {
    const visit = await getDoctorConsultDetailsById(visitId);

    if (!visit) {
      return NextResponse.json({ error: 'Visit not found.' }, { status: 404 });
    }

    return NextResponse.json(visit);
  } catch (error) {
    console.error('Error fetching doctor visit:', error);
    return NextResponse.json(
      { error: 'Failed to fetch doctor visit.' },
      { status: 500 },
    );
  }
}

function isVisitStatus(value: unknown): value is VisitStatus {
  return (
    value === 'WAITING' ||
    value === 'CONSULTING' ||
    value === 'PRESCRIBED' ||
    value === 'DISPENSED'
  );
}

export async function PATCH(request: Request, context: RouteContext) {
  const { visitId } = await context.params;

  try {
    const body = (await request.json().catch(() => null)) as { status?: unknown } | null;
    const status = body?.status;

    if (!isVisitStatus(status)) {
      return NextResponse.json(
        { error: 'Invalid status. Use WAITING, CONSULTING, PRESCRIBED, or DISPENSED.' },
        { status: 400 },
      );
    }

    const visit = await updateDoctorVisitStatus(visitId, status);
    return NextResponse.json(visit);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2025') {
      return NextResponse.json({ error: 'Visit not found.' }, { status: 404 });
    }

    console.error('Error updating doctor visit status:', error);
    return NextResponse.json(
      { error: 'Failed to update visit status.' },
      { status: 500 },
    );
  }
}
