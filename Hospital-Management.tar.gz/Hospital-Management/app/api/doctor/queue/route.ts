import { NextResponse } from 'next/server';
import { Role } from '@prisma/client';

import { getSession } from '@/lib/auth';
import { getTodayDoctorQueueVisits } from '@/lib/reception-data';
import { RECEPTION_DEPARTMENTS } from '@/lib/reception-utils';

function normalizeDepartment(value: string | null | undefined) {
  if (!value) return null;
  const department = value.trim();

  return RECEPTION_DEPARTMENTS.includes(
    department as (typeof RECEPTION_DEPARTMENTS)[number],
  )
    ? department
    : null;
}

export async function GET(request: Request) {
  try {
    const session = await getSession();

    if (!session || (session.role !== Role.DOCTOR && session.role !== Role.ADMIN)) {
      return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);

    const department =
      session.role === Role.DOCTOR
        ? normalizeDepartment(session.doctorDepartment)
        : normalizeDepartment(searchParams.get('department')) ?? RECEPTION_DEPARTMENTS[0];

    if (!department) {
      return NextResponse.json(
        { error: 'Doctor department is not configured. Contact admin.' },
        { status: 400 },
      );
    }

    const visits = await getTodayDoctorQueueVisits(department);

    return NextResponse.json({ department, visits });
  } catch (error) {
    console.error('Error fetching doctor queue:', error);
    return NextResponse.json(
      { error: 'Failed to fetch doctor queue.' },
      { status: 500 },
    );
  }
}
