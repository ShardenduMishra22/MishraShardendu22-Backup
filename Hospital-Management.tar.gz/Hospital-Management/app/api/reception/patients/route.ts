import { NextResponse } from 'next/server';

import { createReceptionPatient, getRecentReceptionPatients } from '@/lib/reception-data';
import {
  digitsOnly,
  type ReceptionGender,
  type ReceptionPatientForm,
  validateReceptionPatientForm,
} from '@/lib/reception-utils';

function toStringValue(value: unknown) {
  return typeof value === 'string' ? value : '';
}

function normalizeGender(value: unknown): ReceptionGender {
  return value === 'FEMALE' || value === 'OTHER' ? value : 'MALE';
}

function parseReceptionPatientForm(body: unknown): ReceptionPatientForm | null {
  if (!body || typeof body !== 'object') {
    return null;
  }

  const payload = body as Record<string, unknown>;
  const rawAge = payload.age;

  return {
    patientUuid: toStringValue(payload.patientUuid).trim().toUpperCase(),
    name: toStringValue(payload.name),
    fatherName: toStringValue(payload.fatherName),
    phone: digitsOnly(toStringValue(payload.phone)),
    age:
      typeof rawAge === 'number'
        ? String(rawAge)
        : toStringValue(rawAge),
    gender: normalizeGender(payload.gender),
    address: toStringValue(payload.address),
    department: toStringValue(payload.department) || 'General Medicine',
  };
}

export async function GET() {
  try {
    const patients = await getRecentReceptionPatients();
    return NextResponse.json(patients);
  } catch (error) {
    console.error('Error fetching reception patients:', error);
    return NextResponse.json(
      { error: 'Failed to fetch reception patients.' },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const form = parseReceptionPatientForm(body);

    if (!form) {
      return NextResponse.json(
        { error: 'Invalid patient payload.' },
        { status: 400 },
      );
    }

    const validationError = validateReceptionPatientForm(form);
    if (validationError) {
      return NextResponse.json({ error: validationError }, { status: 400 });
    }

    const patient = await createReceptionPatient({
      patientUuid: form.patientUuid,
      name: form.name.trim(),
      fatherName: form.fatherName.trim(),
      phone: digitsOnly(form.phone),
      age: Number(form.age),
      gender: form.gender,
      address: form.address.trim(),
      department: form.department,
    });

    return NextResponse.json(patient, { status: 201 });
  } catch (error) {
    console.error('Error creating reception patient:', error);
    const message = error instanceof Error ? error.message : 'Failed to create reception patient.';

    return NextResponse.json({ error: message }, { status: 500 });
  }
}
