import { NextResponse } from 'next/server';

import { getReceptionPatientByUuid, updateReceptionPatient } from '@/lib/reception-data';
import {
  digitsOnly,
  type ReceptionGender,
  type ReceptionPatientForm,
  validateReceptionPatientForm,
} from '@/lib/reception-utils';

function toStringValue(value: unknown) {
  return typeof value === 'string' ? value : '';
}

function normalizeGender(value: unknown): ReceptionGender {
  return value === 'FEMALE' || value === 'OTHER' ? value : 'MALE';
}

function parseReceptionPatientForm(body: unknown): ReceptionPatientForm | null {
  if (!body || typeof body !== 'object') {
    return null;
  }

  const payload = body as Record<string, unknown>;
  const rawAge = payload.age;

  return {
    patientUuid: toStringValue(payload.patientUuid).trim().toUpperCase(),
    name: toStringValue(payload.name),
    fatherName: toStringValue(payload.fatherName),
    phone: digitsOnly(toStringValue(payload.phone)),
    age:
      typeof rawAge === 'number'
        ? String(rawAge)
        : toStringValue(rawAge),
    gender: normalizeGender(payload.gender),
    address: toStringValue(payload.address),
    department: toStringValue(payload.department) || 'General Medicine',
  };
}

type RouteContext = {
  params: Promise<{
    patientUuid: string;
  }>;
};

export async function GET(_request: Request, context: RouteContext) {
  const { patientUuid } = await context.params;

  try {
    const patient = await getReceptionPatientByUuid(patientUuid);

    if (!patient) {
      return NextResponse.json({ error: 'Patient not found.' }, { status: 404 });
    }

    return NextResponse.json(patient);
  } catch (error) {
    console.error('Error fetching reception patient:', error);
    return NextResponse.json(
      { error: 'Failed to fetch patient details.' },
      { status: 500 },
    );
  }
}

export async function PUT(request: Request, context: RouteContext) {
  const { patientUuid } = await context.params;

  try {
    const body = await request.json();
    const form = parseReceptionPatientForm(body);

    if (!form) {
      return NextResponse.json(
        { error: 'Invalid patient payload.' },
        { status: 400 },
      );
    }

    const validationError = validateReceptionPatientForm(form);
    if (validationError) {
      return NextResponse.json({ error: validationError }, { status: 400 });
    }

    const patient = await updateReceptionPatient(patientUuid, {
      patientUuid: form.patientUuid,
      name: form.name.trim(),
      fatherName: form.fatherName.trim(),
      phone: digitsOnly(form.phone),
      age: Number(form.age),
      gender: form.gender,
      address: form.address.trim(),
      department: form.department,
    });

    if (!patient) {
      return NextResponse.json({ error: 'Patient not found.' }, { status: 404 });
    }

    return NextResponse.json(patient);
  } catch (error) {
    console.error('Error updating reception patient:', error);
    const message = error instanceof Error ? error.message : 'Failed to update reception patient.';

    return NextResponse.json({ error: message }, { status: 500 });
  }
}
