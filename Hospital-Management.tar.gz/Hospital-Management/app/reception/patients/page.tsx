import { ConsoleSidebar } from '@/components/console-sidebar';
import { ReceptionPatientsList } from '@/components/reception-patients-list';
import { getRecentReceptionPatients } from '@/lib/reception-data';
import { RECEPTION_ITEMS } from '@/lib/reception-utils';

export default async function ReceptionPatientsPage() {
  const patients = await getRecentReceptionPatients();

  return (
    <div className="flex h-screen overflow-hidden bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Reception"
        description="Reception desk functions for patient search, patient registration, edits, and slip issue."
        items={RECEPTION_ITEMS}
      />

      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-6xl space-y-6 p-4 md:p-6">
          <header className="border-b border-slate-200 pb-5">
            <p className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
              Recent Patients
            </p>
            <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight md:text-4xl">
              Patient Records
            </h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
              Open a recent patient from here, then continue into the patient details page or the visit review flow.
            </p>
          </header>

          <section className="bg-white">
            <ReceptionPatientsList patients={patients} />
          </section>
        </div>
      </main>
    </div>
  );
}
