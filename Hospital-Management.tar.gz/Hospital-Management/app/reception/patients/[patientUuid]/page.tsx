import Link from 'next/link';
import { ArrowLeft, ClipboardList, UserRound } from 'lucide-react';
import { notFound } from 'next/navigation';

import { ConsoleSidebar } from '@/components/console-sidebar';
import { getReceptionPatientByUuid } from '@/lib/reception-data';
import { RECEPTION_ITEMS } from '@/lib/reception-utils';

type ReceptionPatientDetailsPageProps = {
  params: Promise<{
    patientUuid: string;
  }>;
};

export default async function ReceptionPatientDetailsPage({
  params,
}: ReceptionPatientDetailsPageProps) {
  const { patientUuid } = await params;
  const patient = await getReceptionPatientByUuid(patientUuid);

  if (!patient) {
    notFound();
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Reception"
        description="Reception desk functions for patient search, patient registration, edits, and slip issue."
        items={RECEPTION_ITEMS}
      />

      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-6xl space-y-6 p-4 md:p-6">
          <header className="flex flex-col gap-4 border-b border-slate-200 pb-5 md:flex-row md:items-center md:justify-between">
            <div>
              <Link
                href="/reception/patients"
                className="inline-flex items-center gap-2 text-sm font-medium text-[#0f5ea8]"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to recent patients
              </Link>
              <h1 className="mt-3 font-display text-3xl font-semibold tracking-tight">
                {patient.name}
              </h1>
              <p className="mt-2 text-sm leading-6 text-slate-600">
                Dedicated patient details page opened from the Recent Patients tab.
              </p>
            </div>
            {patient.currentVisit ? (
              <Link
                href={`/reception/visit/${patient.currentVisit.id}`}
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#0f5ea8] px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-[#0c4d8a]"
              >
                <ClipboardList className="h-4 w-4" />
                Open Visit Review
              </Link>
            ) : null}
          </header>

          <div className="grid gap-6 lg:grid-cols-12">
            <section className="space-y-6 lg:col-span-7">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <UserRound className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">
                      Patient Information
                    </h2>
                    <p className="mt-1 text-sm text-slate-600">
                      Core demographic information for this patient record.
                    </p>
                  </div>
                </div>

                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <InfoItem label="Patient UUID" value={patient.patientUuid} />
                  <InfoItem label="Patient Name" value={patient.name} />
                  <InfoItem label="Father Name" value={patient.fatherName || 'Not added'} />
                  <InfoItem label="Phone" value={patient.phone} />
                  <InfoItem label="Age" value={`${patient.age} Years`} />
                  <InfoItem label="Gender" value={patient.gender} />
                  <InfoItem label="Address" value={patient.address || 'Not added'} />
                  <InfoItem label="Department" value={patient.department} />
                </div>
              </div>
            </section>

            <aside className="space-y-6 lg:col-span-5">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <h2 className="font-display text-xl font-semibold">Current Visit</h2>
                {patient.currentVisit ? (
                  <div className="mt-4 space-y-3 rounded-lg border border-slate-200 bg-slate-50 p-4">
                    <InfoLine label="Visit ID" value={patient.currentVisit.id} />
                    <InfoLine label="Token" value={patient.currentVisit.tokenNo} />
                    <InfoLine label="Department" value={patient.currentVisit.department} />
                    <InfoLine label="Status" value={patient.currentVisit.status} />
                    <InfoLine label="Created" value={patient.currentVisit.createdLabel} />
                  </div>
                ) : (
                  <div className="mt-4 rounded-lg border border-dashed border-slate-300 bg-slate-50 p-4 text-sm text-slate-600">
                    No visit has been created for this patient yet.
                  </div>
                )}
              </div>
            </aside>
          </div>
        </div>
      </main>
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 p-4">
      <p className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </p>
      <p className="mt-2 text-sm font-medium text-slate-900">{value}</p>
    </div>
  );
}

function InfoLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-2 last:border-b-0">
      <span className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </span>
      <span className="text-sm font-medium text-slate-900">{value}</span>
    </div>
  );
}
