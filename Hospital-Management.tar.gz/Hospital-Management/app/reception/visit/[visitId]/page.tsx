import Link from 'next/link';
import { ArrowLeft, ClipboardList, Printer, UserRound } from 'lucide-react';
import { notFound } from 'next/navigation';

import { ConsoleSidebar } from '@/components/console-sidebar';
import { getReceptionVisitById } from '@/lib/reception-data';
import { RECEPTION_ITEMS } from '@/lib/reception-utils';

type ReceptionVisitPageProps = {
  params: Promise<{
    visitId: string;
  }>;
};

export default async function ReceptionVisitPage({
  params,
}: ReceptionVisitPageProps) {
  const { visitId } = await params;
  const visit = await getReceptionVisitById(visitId);

  if (!visit) {
    notFound();
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Reception"
        description="Reception desk functions for patient search, patient edits, and slip issue."
        items={RECEPTION_ITEMS}
      />

      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
          <header className="flex flex-col gap-4 border-b border-slate-200 pb-5 md:flex-row md:items-center md:justify-between">
            <div>
              <Link
                href="/reception"
                className="inline-flex items-center gap-2 text-sm font-medium text-[#0f5ea8]"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to reception
              </Link>
              <h1 className="mt-3 font-display text-3xl font-semibold tracking-tight">
                Visit {visit.id}
              </h1>
              <p className="mt-2 text-sm leading-6 text-slate-600">
                Reception review page for patient details, department assignment, and OPD slip issue.
              </p>
            </div>
            <button className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#0f5ea8] px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-[#0c4d8a]">
              <Printer className="h-4 w-4" />
              Print OPD Slip
            </button>
          </header>

          <div className="grid gap-6 lg:grid-cols-12">
            <section className="space-y-6 lg:col-span-7">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <UserRound className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">
                      Patient Information
                    </h2>
                    <p className="mt-1 text-sm text-slate-600">
                      Reception now opens patients from the actual patient and visit records stored in the database.
                    </p>
                  </div>
                </div>

                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <InfoItem label="Patient UUID" value={visit.patient.patientUuid} />
                  <InfoItem label="Name" value={visit.patient.name} />
                  <InfoItem label="Phone" value={visit.patient.phone} />
                  <InfoItem label="Age / Gender" value={`${visit.patient.age} / ${visit.patient.gender}`} />
                  <InfoItem label="Father Name" value={visit.patient.fatherName || 'Not added'} />
                  <InfoItem label="Address" value={visit.patient.address || 'Not added'} />
                  <InfoItem label="Department" value={visit.department} />
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <ClipboardList className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">
                      Current Visit
                    </h2>
                    <p className="mt-1 text-sm text-slate-600">
                      Visit creation stays tied to patient UUID and now issues a department-wise daily token for doctor queue calling.
                    </p>
                  </div>
                </div>

                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <InfoItem label="Token" value={visit.tokenNo} />
                  <InfoItem label="Visit ID" value={visit.id} />
                  <InfoItem label="Patient UUID" value={visit.patient.patientUuid} />
                  <InfoItem label="Department" value={visit.department} />
                  <InfoItem label="Status" value={visit.status} />
                  <InfoItem label="Doctor" value={visit.doctor} />
                  <InfoItem label="Chief Complaint" value={visit.chiefComplaint} />
                  <InfoItem label="Created At" value={visit.createdLabel} />
                </div>
              </div>
            </section>

            <aside className="space-y-6 lg:col-span-5">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <h2 className="font-display text-xl font-semibold">
                  Reception Actions
                </h2>
                <div className="mt-4 space-y-3">
                  <ActionRow
                    title="Confirm patient identity"
                    detail="Verify patient UUID, father name, phone, and address before slip issue."
                  />
                  <ActionRow
                    title="Update demographics if needed"
                    detail="Reception can reopen the same patient record and edit details before sending the patient onward."
                  />
                  <ActionRow
                    title="Issue token slip"
                    detail="Print slip carrying patient UUID, visit ID, and doctor token number."
                  />
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <h2 className="font-display text-xl font-semibold">Slip Preview</h2>
                <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-4">
                  <div className="space-y-3">
                    <InfoLine label="Patient" value={visit.patient.name} />
                    <InfoLine label="Token" value={visit.tokenNo} />
                    <InfoLine label="Patient UUID" value={visit.patient.patientUuid} />
                    <InfoLine label="Visit ID" value={visit.id} />
                    <InfoLine label="Department" value={visit.department} />
                    <InfoLine label="Status" value={visit.status} />
                  </div>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </main>
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 p-4">
      <p className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </p>
      <p className="mt-2 text-sm font-medium text-slate-900">{value}</p>
    </div>
  );
}

function ActionRow({ title, detail }: { title: string; detail: string }) {
  return (
    <div className="rounded-lg border border-slate-200 p-4">
      <p className="text-sm font-semibold text-slate-900">{title}</p>
      <p className="mt-1 text-sm leading-6 text-slate-600">{detail}</p>
    </div>
  );
}

function InfoLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-2 last:border-b-0">
      <span className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </span>
      <span className="text-sm font-medium text-slate-900">{value}</span>
    </div>
  );
}
