import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { Role } from '@prisma/client';
import { IdCard, Users } from 'lucide-react';

import { ConsoleSidebar } from '@/components/console-sidebar';
import { requireSession } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { RECEPTION_ITEMS } from '@/lib/reception-utils';

type ReceptionProfilePageProps = {
  searchParams: Promise<{
    updated?: string;
    error?: string;
  }>;
};

async function updateReceptionProfile(formData: FormData) {
  'use server';

  const session = await requireSession([Role.ADMIN, Role.RECEPTIONIST]);

  const username = String(formData.get('username') ?? '').trim();
  const emailInput = String(formData.get('email') ?? '').trim();
  const email = emailInput ? emailInput.toLowerCase() : null;

  if (!username) {
    redirect('/reception/profile?error=Username%20is%20required');
  }

  const existingByUsername = await prisma.user.findUnique({
    where: { username },
    select: { id: true },
  });

  if (existingByUsername && existingByUsername.id !== session.userId) {
    redirect('/reception/profile?error=Username%20already%20in%20use');
  }

  if (email) {
    const existingByEmail = await prisma.user.findFirst({
      where: {
        email,
        NOT: { id: session.userId },
      },
      select: { id: true },
    });

    if (existingByEmail) {
      redirect('/reception/profile?error=Email%20already%20in%20use');
    }
  }

  await prisma.user.update({
    where: { id: session.userId },
    data: {
      username,
      email,
    },
  });

  revalidatePath('/reception/profile');
  redirect('/reception/profile?updated=1');
}

export default async function ReceptionProfilePage({ searchParams }: ReceptionProfilePageProps) {
  const session = await requireSession([Role.ADMIN, Role.RECEPTIONIST]);
  const params = await searchParams;

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    select: {
      username: true,
      email: true,
      role: true,
      createdAt: true,
    },
  });

  if (!user) {
    redirect('/login');
  }

  return (
    <div className="flex min-h-screen bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Reception"
        description="Reception functions for patient registration, visit review, and OPD slip printing."
        items={RECEPTION_ITEMS}
      />

      <main className="min-w-0 flex-1">
        <div className="mx-auto max-w-5xl space-y-6 p-4 md:p-6">
          <header className="border-b border-slate-200 pb-5">
            <h1 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
              My Profile
            </h1>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              View and edit your receptionist account details.
            </p>
          </header>

          {params.error ? (
            <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {params.error}
            </div>
          ) : null}

          {params.updated ? (
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
              Profile updated successfully.
            </div>
          ) : null}

          <div className="grid gap-6 lg:grid-cols-12">
            <section className="space-y-6 lg:col-span-7">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <IdCard className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Edit Profile</h2>
                    <p className="mt-1 text-sm text-slate-600">
                      Keep your account details up to date.
                    </p>
                  </div>
                </div>

                <form action={updateReceptionProfile} className="mt-6 space-y-4">
                  <Field label="Username">
                    <input
                      name="username"
                      defaultValue={user.username}
                      required
                      className="w-full rounded-lg border border-slate-300 px-4 py-3 text-base outline-none focus:border-[#0f5ea8]"
                    />
                  </Field>

                  <Field label="Email (optional)">
                    <input
                      name="email"
                      type="email"
                      defaultValue={user.email ?? ''}
                      className="w-full rounded-lg border border-slate-300 px-4 py-3 text-base outline-none focus:border-[#0f5ea8]"
                      placeholder="reception@hospital.com"
                    />
                  </Field>

                  <button
                    type="submit"
                    className="inline-flex rounded-lg bg-[#0f5ea8] px-4 py-2 text-sm font-semibold text-white hover:bg-[#0c4d8a]"
                  >
                    Save Profile
                  </button>
                </form>
              </div>
            </section>

            <aside className="space-y-6 lg:col-span-5">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <Users className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Account Summary</h2>
                    <p className="mt-1 text-sm text-slate-600">Current role and profile snapshot.</p>
                  </div>
                </div>

                <div className="mt-5 space-y-3 rounded-lg border border-slate-200 bg-slate-50 p-4">
                  <InfoRow label="Role" value={user.role} />
                  <InfoRow label="Username" value={user.username} />
                  <InfoRow label="Email" value={user.email ?? 'Not added'} />
                  <InfoRow label="Created" value={new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium' }).format(user.createdAt)} />
                </div>
              </div>
            </aside>
          </div>
        </div>
      </main>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="text-sm font-medium text-slate-700">{label}</span>
      {children}
    </label>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-2 last:border-b-0">
      <span className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </span>
      <span className="max-w-52 truncate text-right text-sm font-medium text-slate-900">{value}</span>
    </div>
  );
}
