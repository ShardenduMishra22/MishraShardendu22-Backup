import { Role } from '@prisma/client';

import { requireSession } from '@/lib/auth';

export default async function ReceptionLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  await requireSession([Role.ADMIN, Role.RECEPTIONIST]);
  return children;
}
