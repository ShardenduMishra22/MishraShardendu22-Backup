'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowRight,
  CheckCircle2,
  PencilLine,
  Printer,
  Search,
  ShieldAlert,
  UserPlus,
} from 'lucide-react';

import { ConsoleSidebar } from '@/components/console-sidebar';
import {
  INITIAL_RECEPTION_FORM,
  RECEPTION_DEPARTMENTS,
  RECEPTION_ITEMS,
  digitsOnly,
  generateVisitId,
  normalizeValue,
  previewGeneratedPatientUuid,
  type ReceptionPatientForm,
  type ReceptionPatientRecord,
  validateReceptionPatientForm,
} from '@/lib/reception-utils';

type Feedback = {
  tone: 'success' | 'warning';
  message: string;
};

type BusyState = 'loading' | 'adding' | 'saving' | null;
type SuggestibleField = 'patientUuid' | 'name' | 'fatherName' | 'phone' | 'age' | 'address';

async function readJson<T>(response: Response): Promise<T> {
  const payload = (await response.json().catch(() => null)) as
    | { error?: string }
    | T
    | null;

  if (!response.ok) {
    throw new Error(
      (payload && typeof payload === 'object' && 'error' in payload && payload.error) ||
        'Request failed.',
    );
  }

  return payload as T;
}

export default function ReceptionDashboard() {
  const router = useRouter();
  const [patients, setPatients] = useState<ReceptionPatientRecord[]>([]);
  const [formData, setFormData] = useState<ReceptionPatientForm>(INITIAL_RECEPTION_FORM);
  const [selectedPatientUuid, setSelectedPatientUuid] = useState<string | null>(null);
  const [lastRegisteredSlip, setLastRegisteredSlip] =
    useState<ReceptionPatientRecord | null>(null);
  const [searchResults, setSearchResults] = useState<ReceptionPatientRecord[]>([]);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [busyState, setBusyState] = useState<BusyState>('loading');
  const [activeSuggestionField, setActiveSuggestionField] = useState<SuggestibleField | null>(null);

  const selectedPatient = useMemo(
    () =>
      patients.find((patient) => patient.patientUuid === selectedPatientUuid) ?? null,
    [patients, selectedPatientUuid],
  );

  useEffect(() => {
    let isActive = true;

    async function loadPatients() {
      try {
        const response = await fetch('/api/reception/patients', {
          cache: 'no-store',
        });
        const records = await readJson<ReceptionPatientRecord[]>(response);

        if (!isActive) {
          return;
        }

        setPatients(records);
        setSelectedPatientUuid((current) =>
          current && records.some((patient) => patient.patientUuid === current)
            ? current
            : null,
        );
      } catch (error) {
        if (!isActive) {
          return;
        }

        setFeedback({
          tone: 'warning',
          message:
            error instanceof Error
              ? error.message
              : 'Unable to load receptionist patient records.',
        });
      } finally {
        if (isActive) {
          setBusyState(null);
        }
      }
    }

    void loadPatients();

    return () => {
      isActive = false;
    };
  }, []);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((current) => ({ ...current, [name]: value }));
  };

  const liveSuggestions = useMemo(() => {
    if (!activeSuggestionField) {
      return [] as ReceptionPatientRecord[];
    }

    const rawQuery = String(formData[activeSuggestionField] ?? '');
    const normalizedQuery = normalizeValue(rawQuery);
    const numericQuery = digitsOnly(rawQuery);

    const hasMinimumLength =
      activeSuggestionField === 'phone'
        ? numericQuery.length >= 3
        : activeSuggestionField === 'age'
          ? rawQuery.trim().length >= 1
          : normalizedQuery.length >= 2;

    if (!hasMinimumLength) {
      return [] as ReceptionPatientRecord[];
    }

    const results = patients.filter((patient) => {
      if (activeSuggestionField === 'patientUuid') {
        return patient.patientUuid.toUpperCase().includes(rawQuery.trim().toUpperCase());
      }

      if (activeSuggestionField === 'phone') {
        return digitsOnly(patient.phone).includes(numericQuery);
      }

      if (activeSuggestionField === 'age') {
        return String(patient.age).includes(rawQuery.trim());
      }

      if (activeSuggestionField === 'name') {
        return normalizeValue(patient.name).includes(normalizedQuery);
      }

      if (activeSuggestionField === 'fatherName') {
        return normalizeValue(patient.fatherName).includes(normalizedQuery);
      }

      return normalizeValue(patient.address).includes(normalizedQuery);
    });

    return results.slice(0, 6);
  }, [activeSuggestionField, formData, patients]);

  const openPatientDetailsFromSuggestion = (patient: ReceptionPatientRecord) => {
    setActiveSuggestionField(null);
    router.push(`/reception/patients/${encodeURIComponent(patient.patientUuid)}`);
  };

  const closeSuggestionsFor = (field: SuggestibleField) => {
    window.setTimeout(() => {
      setActiveSuggestionField((current) => (current === field ? null : current));
    }, 120);
  };

  const openPatientRecord = (patient: ReceptionPatientRecord, source: string) => {
    setFormData({
      patientUuid: patient.patientUuid,
      name: patient.name,
      fatherName: patient.fatherName,
      phone: patient.phone,
      age: String(patient.age),
      gender: patient.gender,
      address: patient.address,
      department: patient.department,
    });
    setSelectedPatientUuid(patient.patientUuid);
    setSearchResults([patient]);
    setFeedback({
      tone: 'success',
      message: `Opened ${patient.name} from ${source}. You can now review or edit the patient record.`,
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearch = () => {
    const sanitizedUuid = formData.patientUuid.trim().toUpperCase();
    const query = {
      name: normalizeValue(formData.name),
      fatherName: normalizeValue(formData.fatherName),
      phone: digitsOnly(formData.phone),
      age: formData.age.trim(),
      address: normalizeValue(formData.address),
      department:
        formData.department === INITIAL_RECEPTION_FORM.department
          ? ''
          : normalizeValue(formData.department),
    };
    const hasDetailQuery = Object.values(query).some(Boolean);

    if (sanitizedUuid && !hasDetailQuery) {
      const exactMatch = patients.find(
        (patient) => patient.patientUuid.toUpperCase() === sanitizedUuid,
      );

      if (exactMatch) {
        openPatientRecord(exactMatch, 'UUID search');
      } else {
        setSearchResults([]);
        setFeedback({
          tone: 'warning',
          message: `No patient found for UUID ${sanitizedUuid}. Check the ID or use the other fields for fuzzy search.`,
        });
      }

      return;
    }

    if (!sanitizedUuid && !hasDetailQuery) {
      setSearchResults([]);
      setFeedback({
        tone: 'warning',
        message:
          'Enter patient UUID for exact lookup, or fill any patient details to run fuzzy search.',
      });
      return;
    }

    const matches = patients
      .map((patient) => {
        let score = 0;

        if (sanitizedUuid && patient.patientUuid.toUpperCase().includes(sanitizedUuid)) {
          score += 5;
        }
        if (query.name && normalizeValue(patient.name).includes(query.name)) score += 4;
        if (query.fatherName && normalizeValue(patient.fatherName).includes(query.fatherName)) {
          score += 3;
        }
        if (query.phone && digitsOnly(patient.phone).includes(query.phone)) score += 3;
        if (query.age && String(patient.age).includes(query.age)) score += 1;
        if (query.address && normalizeValue(patient.address).includes(query.address)) {
          score += 2;
        }
        if (query.department && normalizeValue(patient.department).includes(query.department)) {
          score += 1;
        }

        return { patient, score };
      })
      .filter((entry) => entry.score > 0)
      .sort((left, right) => right.score - left.score)
      .map((entry) => entry.patient);

    setSearchResults(matches);

    if (matches[0]) {
      setFeedback({
        tone: 'success',
        message: `Found ${matches.length} likely patient match${matches.length > 1 ? 'es' : ''}. Click any result below to open that record.`,
      });
    } else {
      setFeedback({
        tone: 'warning',
        message:
          'No matching patients found. Fill the remaining details and use Add New Patient instead.',
      });
    }
  };

  const handleAddPatient = async () => {
    const validationError = validateReceptionPatientForm(formData);
    if (validationError) {
      setFeedback({ tone: 'warning', message: validationError });
      return;
    }

    try {
      setBusyState('adding');

      const response = await fetch('/api/reception/patients', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      const record = await readJson<ReceptionPatientRecord>(response);

      setPatients((current) => [
        record,
        ...current.filter((patient) => patient.patientUuid !== record.patientUuid),
      ]);
      setLastRegisteredSlip(record);
      setFormData(INITIAL_RECEPTION_FORM);
      setSearchResults([]);
      setSelectedPatientUuid(null);
      setFeedback({
        tone: 'success',
        message: `Created patient ${record.patientUuid} with visit ${record.visitId} and token ${record.tokenNo}. Form reset for next registration.`,
      });
    } catch (error) {
      setFeedback({
        tone: 'warning',
        message:
          error instanceof Error
            ? error.message
            : 'Unable to create the patient right now.',
      });
    } finally {
      setBusyState(null);
    }
  };

  const handleSaveEdits = async () => {
    if (!selectedPatient) {
      setFeedback({
        tone: 'warning',
        message: 'Search or open a patient first before saving edits.',
      });
      return;
    }

    const validationError = validateReceptionPatientForm(formData);
    if (validationError) {
      setFeedback({ tone: 'warning', message: validationError });
      return;
    }

    try {
      setBusyState('saving');

      const response = await fetch(
        `/api/reception/patients/${selectedPatient.patientUuid}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(formData),
        },
      );
      const updated = await readJson<ReceptionPatientRecord>(response);

      setPatients((current) => [
        updated,
        ...current.filter(
          (patient) =>
            patient.patientUuid !== selectedPatient.patientUuid &&
            patient.patientUuid !== updated.patientUuid,
        ),
      ]);
      openPatientRecord(updated, 'saved edits');
      setFeedback({
        tone: 'success',
        message: `Saved receptionist edits for patient ${updated.patientUuid}.`,
      });
    } catch (error) {
      setFeedback({
        tone: 'warning',
        message:
          error instanceof Error
            ? error.message
            : 'Unable to save patient edits right now.',
      });
    } finally {
      setBusyState(null);
    }
  };

  const clearForm = () => {
    setFormData(INITIAL_RECEPTION_FORM);
    setLastRegisteredSlip(null);
    setSearchResults([]);
    setSelectedPatientUuid(null);
    setFeedback(null);
  };

  const hasDraftInput =
    Boolean(formData.patientUuid.trim()) ||
    Boolean(formData.name.trim()) ||
    Boolean(formData.fatherName.trim()) ||
    Boolean(formData.phone.trim()) ||
    Boolean(formData.age.trim()) ||
    Boolean(formData.address.trim());

  const slipPatient = selectedPatient ?? (!hasDraftInput ? lastRegisteredSlip : null);

  const previewPatientUuid =
    slipPatient?.patientUuid ||
    formData.patientUuid.trim().toUpperCase() ||
    previewGeneratedPatientUuid(formData, patients.length + 1);
  const previewVisitId =
    slipPatient?.visitId ||
    generateVisitId(formData.name || 'PAT', new Date(), patients.length + 1);
  const isBusy = busyState === 'loading' || busyState === 'adding' || busyState === 'saving';

  return (
    <div className="flex h-screen overflow-hidden bg-[#f3f5f7] text-[#1f2937] selection:bg-[#0f5ea8] selection:text-white">
      <ConsoleSidebar
        title="Reception"
        description="Reception desk functions for patient search, patient registration, edits, and slip issue."
        items={RECEPTION_ITEMS}
      />

      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-6xl space-y-6 p-4 md:p-6">
          <header className="border-b border-slate-200 pb-5">
            <h1 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
              OPD Registration
            </h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
              This page stays focused on registration work. Use the real left sidebar tab
              for Recent Patients when you want the patient list view.
            </p>
          </header>

          <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1.45fr)_minmax(320px,0.8fr)]">
            <section className="space-y-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 md:flex-row md:items-start md:justify-between">
                  <div>
                    <p className="font-mono text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">
                      Patient Desk
                    </p>
                    <h2 className="mt-2 font-display text-2xl font-semibold text-slate-900">
                      Search, register, and edit from one place
                    </h2>
                    <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
                      Exact search uses patient UUID. If UUID is blank, the receptionist
                      can search using partial patient details like name, father name,
                      phone, age, or address.
                    </p>
                  </div>
                  <button
                    onClick={clearForm}
                    className="inline-flex items-center justify-center whitespace-nowrap px-1 py-2 text-sm font-semibold text-slate-500 transition-colors hover:text-slate-900"
                  >
                    Clear Form
                  </button>
                </div>

                <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
                  <FormField
                    label="Patient UUID"
                    hint="Exact search key. Leave blank while adding to auto-generate a unique ID."
                  >
                    <div className="relative">
                      <input
                        name="patientUuid"
                        value={formData.patientUuid}
                        onChange={handleInputChange}
                        onFocus={() => setActiveSuggestionField('patientUuid')}
                        onBlur={() => closeSuggestionsFor('patientUuid')}
                        type="text"
                        className="w-full rounded-xl border border-slate-300 px-4 py-3 text-base uppercase outline-none transition-colors focus:border-[#0f5ea8]"
                        placeholder="RAMMAH3210001-210326"
                      />
                      {activeSuggestionField === 'patientUuid' && liveSuggestions.length > 0 ? (
                        <SuggestionList
                          items={liveSuggestions}
                          onSelect={openPatientDetailsFromSuggestion}
                        />
                      ) : null}
                    </div>
                  </FormField>
                  <FormField
                    label="Department"
                    hint="Assigned OPD desk for the current visit slip."
                  >
                    <select
                      name="department"
                      value={formData.department}
                      onChange={handleInputChange}
                      className="app-select w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-base outline-none transition-colors focus:border-[#0f5ea8]"
                    >
                      {RECEPTION_DEPARTMENTS.map((department) => (
                        <option key={department} value={department}>
                          {department}
                        </option>
                      ))}
                    </select>
                  </FormField>
                  <FormField label="Patient Name">
                    <div className="relative">
                      <input
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        onFocus={() => setActiveSuggestionField('name')}
                        onBlur={() => closeSuggestionsFor('name')}
                        type="text"
                        className="w-full rounded-xl border border-slate-300 px-4 py-3 text-base outline-none transition-colors focus:border-[#0f5ea8]"
                        placeholder="Ramesh Kumar"
                      />
                      {activeSuggestionField === 'name' && liveSuggestions.length > 0 ? (
                        <SuggestionList
                          items={liveSuggestions}
                          onSelect={openPatientDetailsFromSuggestion}
                        />
                      ) : null}
                    </div>
                  </FormField>
                  <FormField label="Father Name">
                    <div className="relative">
                      <input
                        name="fatherName"
                        value={formData.fatherName}
                        onChange={handleInputChange}
                        onFocus={() => setActiveSuggestionField('fatherName')}
                        onBlur={() => closeSuggestionsFor('fatherName')}
                        type="text"
                        className="w-full rounded-xl border border-slate-300 px-4 py-3 text-base outline-none transition-colors focus:border-[#0f5ea8]"
                        placeholder="Mahesh Kumar"
                      />
                      {activeSuggestionField === 'fatherName' && liveSuggestions.length > 0 ? (
                        <SuggestionList
                          items={liveSuggestions}
                          onSelect={openPatientDetailsFromSuggestion}
                        />
                      ) : null}
                    </div>
                  </FormField>
                  <FormField label="Mobile Number">
                    <div className="relative">
                      <input
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        onFocus={() => setActiveSuggestionField('phone')}
                        onBlur={() => closeSuggestionsFor('phone')}
                        type="tel"
                        maxLength={10}
                        className="w-full rounded-xl border border-slate-300 px-4 py-3 text-base outline-none transition-colors focus:border-[#0f5ea8]"
                        placeholder="9876543210"
                      />
                      {activeSuggestionField === 'phone' && liveSuggestions.length > 0 ? (
                        <SuggestionList
                          items={liveSuggestions}
                          onSelect={openPatientDetailsFromSuggestion}
                        />
                      ) : null}
                    </div>
                  </FormField>
                  <FormField label="Age">
                    <input
                      name="age"
                      value={formData.age}
                      onChange={handleInputChange}
                      type="number"
                      className="w-full rounded-xl border border-slate-300 px-4 py-3 text-base outline-none transition-colors focus:border-[#0f5ea8]"
                      placeholder="45"
                    />
                  </FormField>
                  <FormField label="Gender">
                    <select
                      name="gender"
                      value={formData.gender}
                      onChange={handleInputChange}
                      className="app-select w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-base outline-none transition-colors focus:border-[#0f5ea8]"
                    >
                      <option value="MALE">Male</option>
                      <option value="FEMALE">Female</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </FormField>
                  <FormField label="Address">
                    <textarea
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      rows={4}
                      className="w-full rounded-xl border border-slate-300 px-4 py-3 text-base outline-none transition-colors focus:border-[#0f5ea8]"
                      placeholder="Ward 4, Civil Lines, Kanpur"
                    />
                  </FormField>
                </div>

                <div className="mt-6 grid gap-3 md:grid-cols-3">
                  <button
                    onClick={handleSearch}
                    disabled={busyState === 'loading'}
                    className="inline-flex items-center justify-center gap-3 rounded-xl border border-[#0f5ea8] px-4 py-3 text-sm font-semibold text-[#0f5ea8] transition-colors hover:bg-[#0f5ea8]/5 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    <Search className="h-4 w-4" />
                    Search Patient
                  </button>
                  <button
                    onClick={handleAddPatient}
                    disabled={isBusy}
                    className="inline-flex items-center justify-center gap-3 rounded-xl bg-[#0f5ea8] px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#0c4d8a] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    <UserPlus className="h-4 w-4" />
                    {busyState === 'adding' ? 'Adding Patient...' : 'Add New Patient'}
                  </button>
                  <button
                    onClick={handleSaveEdits}
                    disabled={isBusy || !selectedPatient}
                    className="inline-flex items-center justify-center gap-3 rounded-xl border border-slate-300 px-4 py-3 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    <PencilLine className="h-4 w-4" />
                    {busyState === 'saving' ? 'Saving...' : 'Save Edits'}
                  </button>
                </div>

                {feedback && (
                  <StatusBanner tone={feedback.tone} message={feedback.message} />
                )}
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                      Search Results
                    </p>
                    <h3 className="mt-2 font-display text-xl font-semibold text-slate-900">
                      Matching patients
                    </h3>
                  </div>
                  <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
                    {searchResults.length} result{searchResults.length === 1 ? '' : 's'}
                  </span>
                </div>

                <div className="mt-5 space-y-3">
                  {busyState === 'loading' ? (
                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">
                      Loading patient records from the database...
                    </div>
                  ) : searchResults.length > 0 ? (
                    searchResults.map((patient) => {
                      const isOpen = patient.patientUuid === selectedPatientUuid;

                      return (
                        <button
                          key={patient.patientUuid}
                          type="button"
                          onClick={() => openPatientRecord(patient, 'search results')}
                          className={`flex w-full items-center justify-between rounded-2xl border p-4 text-left transition-colors ${
                            isOpen
                              ? 'border-[#0f5ea8] bg-[#0f5ea8]/5'
                              : 'border-slate-200 hover:border-[#0f5ea8] hover:bg-slate-50'
                          }`}
                        >
                          <div>
                            <p className="font-display text-lg font-semibold text-slate-900">
                              {patient.name}
                            </p>
                            <p className="mt-1 text-sm text-slate-600">
                              {patient.fatherName} • {patient.phone} • {patient.age} Yrs
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">
                              Patient UUID
                            </p>
                            <p className="mt-1 font-mono text-sm font-semibold text-[#0f5ea8]">
                              {patient.patientUuid}
                            </p>
                            <span className="mt-2 inline-flex rounded-full bg-white px-3 py-1 text-xs font-semibold text-slate-700">
                              {isOpen ? 'Open in Form' : 'Click to Open'}
                            </span>
                          </div>
                        </button>
                      );
                    })
                  ) : (
                    <div className="flex items-center gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-red-700">
                      <ShieldAlert className="h-5 w-5" />
                      <span className="text-sm font-medium">
                        No patient is open from search right now.
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </section>

            <aside>
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm xl:sticky xl:top-6">
                <div className="mb-4 border-b border-slate-200 pb-4 text-center">
                  <h2 className="font-display text-xl font-semibold">
                    Government Hospital
                  </h2>
                  <p className="mt-1 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                    Outpatient Slip Preview
                  </p>
                </div>

                <div className="space-y-4">
                  <PreviewRow label="Patient UUID" value={previewPatientUuid} />
                  <PreviewRow label="Patient Name" value={slipPatient?.name || formData.name || '---'} />
                  <PreviewRow label="Father Name" value={slipPatient?.fatherName || formData.fatherName || '---'} />
                  <PreviewRow label="Phone" value={slipPatient?.phone || formData.phone || '---'} />
                  <PreviewRow
                    label="Age / Gender"
                    value={
                      slipPatient
                        ? `${slipPatient.age} Y / ${slipPatient.gender.charAt(0)}`
                        : `${formData.age || '--'} Y / ${formData.gender.charAt(0)}`
                    }
                  />
                  <PreviewRow label="Department" value={slipPatient?.department || formData.department} />
                  <PreviewRow label="Visit ID" value={previewVisitId} />
                  <PreviewRow
                    label="Doctor Token"
                    value={slipPatient?.tokenNo || 'Assigned after registration save'}
                  />

                  <div className="rounded-xl bg-slate-50 p-4">
                    <p className="font-mono text-center text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                      Doctor Queue Token
                    </p>
                    <p className="mt-3 text-center font-display text-3xl font-semibold text-[#0f5ea8]">
                      {slipPatient?.tokenNo ?? '----'}
                    </p>
                    <p className="mt-2 text-center text-xs text-slate-500">
                      Token is generated when patient registration is saved.
                    </p>
                  </div>
                </div>

                <button className="mt-6 flex w-full items-center justify-center gap-3 rounded-xl bg-[#0f5ea8] py-3 text-white transition-colors hover:bg-[#0c4d8a]">
                  <Printer className="h-5 w-5" />
                  <span className="font-display text-base font-semibold">
                    Print and Assign
                  </span>
                </button>
              </div>
            </aside>
          </div>
        </div>
      </main>
    </div>
  );
}

function FormField({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-2 block font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </label>
      {children}
      {hint && <p className="mt-2 text-xs leading-5 text-slate-500">{hint}</p>}
    </div>
  );
}

function SuggestionList({
  items,
  onSelect,
}: {
  items: ReceptionPatientRecord[];
  onSelect: (patient: ReceptionPatientRecord) => void;
}) {
  return (
    <div className="absolute left-0 right-0 z-20 mt-2 max-h-64 overflow-y-auto rounded-xl border border-slate-200 bg-white shadow-lg">
      {items.map((patient) => (
        <button
          key={patient.patientUuid}
          type="button"
          onMouseDown={(event) => event.preventDefault()}
          onClick={() => onSelect(patient)}
          className="w-full border-b border-slate-100 px-3 py-2.5 text-left transition-colors hover:bg-slate-50 last:border-b-0"
        >
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-slate-900">{patient.name}</p>
              <p className="mt-0.5 text-xs text-slate-600">Phone: {patient.phone}</p>
            </div>
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0f5ea8]">
              View profile
              <ArrowRight className="h-3.5 w-3.5" />
            </span>
          </div>
        </button>
      ))}
    </div>
  );
}

function PreviewRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-end justify-between gap-4 border-b border-slate-200 pb-2">
      <span className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </span>
      <span className="max-w-55 truncate text-right text-base font-medium text-slate-900">
        {value}
      </span>
    </div>
  );
}

function StatusBanner({
  tone,
  message,
}: {
  tone: 'success' | 'warning';
  message: string;
}) {
  const palette =
    tone === 'success'
      ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
      : 'border-amber-200 bg-amber-50 text-amber-700';

  return (
    <div className={`mt-5 flex items-start gap-3 rounded-xl border p-4 ${palette}`}>
      {tone === 'success' ? (
        <CheckCircle2 className="mt-0.5 h-5 w-5" />
      ) : (
        <ShieldAlert className="mt-0.5 h-5 w-5" />
      )}
      <span className="text-sm font-medium">{message}</span>
    </div>
  );
}
