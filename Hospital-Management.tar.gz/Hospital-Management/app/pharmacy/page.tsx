import { ClipboardCheck, Pill } from 'lucide-react';

import { PharmacyQueuePanel } from '@/components/pharmacy-queue-panel';
import { ConsoleSidebar } from '@/components/console-sidebar';
import { getPharmacyQueueVisits, getPharmacyStockAlerts } from '@/lib/pharmacy-data';
import { PHARMACY_ITEMS } from '@/lib/pharmacy-utils';

export default async function PharmacyDashboardPage() {
  const [queue, stockAlerts] = await Promise.all([
    getPharmacyQueueVisits(),
    getPharmacyStockAlerts(),
  ]);

  return (
    <div className="flex min-h-screen bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Pharmacy"
        description="Pharmacy functions for prescribed visit review, medicine dispense, and stock alerts."
        items={PHARMACY_ITEMS}
      />

      <main className="min-w-0 flex-1">
        <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
          <header className="border-b border-slate-200 pb-5">
            <h1 className="font-display text-3xl font-semibold tracking-tight">
              Pharmacy Counter
            </h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
              Open prescribed visits, check validated medicines, dispense stock, and watch low-inventory alerts.
            </p>
          </header>

          <div className="grid gap-6 lg:grid-cols-12">
            <section className="space-y-6 lg:col-span-8">
              <PharmacyQueuePanel queue={queue} />
            </section>

            <aside className="space-y-6 lg:col-span-4">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <ClipboardCheck className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Dispense Flow</h2>
                    <p className="mt-2 text-sm leading-6 text-slate-600">
                      Pharmacy uses the doctor-approved prescription items and deducts exact quantities from stock.
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <Pill className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Low Stock Alerts</h2>
                    <p className="mt-2 text-sm leading-6 text-slate-600">
                      Medicines nearing reorder level based on the inventory model.
                    </p>
                  </div>
                </div>

                <div className="mt-4 space-y-3">
                  {stockAlerts.length > 0 ? (
                    stockAlerts.map((item) => (
                      <div key={item.id} className="rounded-lg border border-slate-200 bg-slate-50 p-4">
                        <p className="text-sm font-semibold text-slate-900">{item.name}</p>
                        <p className="mt-1 text-sm text-slate-600">
                          Stock {item.stockQuantity} • Reorder level {item.reorderLevel}
                        </p>
                      </div>
                    ))
                  ) : (
                    <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-4 text-sm text-slate-600">
                      No low-stock alerts right now.
                    </div>
                  )}
                </div>
              </div>
            </aside>
          </div>
        </div>
      </main>
    </div>
  );
}
