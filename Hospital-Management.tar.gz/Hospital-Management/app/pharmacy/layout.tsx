import { Role } from '@prisma/client';

import { requireSession } from '@/lib/auth';

export default async function PharmacyLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  await requireSession([Role.ADMIN, Role.PHARMACIST]);
  return children;
}
