import Link from 'next/link';
import { ArrowLeft, ClipboardCheck, Pill, Shield } from 'lucide-react';
import { notFound } from 'next/navigation';

import { ConsoleSidebar } from '@/components/console-sidebar';
import { PharmacyDispenseButton } from '@/components/pharmacy-dispense-button';
import { getPharmacyStockAlerts, getPharmacyVisitById } from '@/lib/pharmacy-data';
import { PHARMACY_ITEMS } from '@/lib/pharmacy-utils';

type PharmacyDispensePageProps = {
  params: Promise<{
    visitId: string;
  }>;
};

export default async function PharmacyDispensePage({
  params,
}: PharmacyDispensePageProps) {
  const { visitId } = await params;
  const [visit, stockAlerts] = await Promise.all([
    getPharmacyVisitById(visitId),
    getPharmacyStockAlerts(),
  ]);

  if (!visit) {
    notFound();
  }

  const hasPendingItems = visit.prescriptionItems.some((item) => !item.isDispensed);

  return (
    <div className="flex min-h-screen bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Pharmacy"
        description="Pharmacy functions for prescribed visit review, medicine dispense, and stock alerts."
        items={PHARMACY_ITEMS}
      />

      <main className="min-w-0 flex-1">
        <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
          <header className="border-b border-slate-200 pb-5">
            <Link
              href="/pharmacy"
              className="inline-flex items-center gap-2 text-sm font-medium text-[#0f5ea8]"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to pharmacy queue
            </Link>
            <h1 className="mt-3 font-display text-3xl font-semibold tracking-tight">
              Dispense {visit.id}
            </h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
              Verify the visit, review doctor-approved medicines, and confirm dispense against available stock.
            </p>
          </header>

          <div className="grid gap-6 lg:grid-cols-12">
            <section className="space-y-6 lg:col-span-8">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <ClipboardCheck className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Visit and Patient</h2>
                    <p className="mt-1 text-sm text-slate-600">
                      Dispense is tied to the same visit and patient identifiers created earlier in the flow.
                    </p>
                  </div>
                </div>

                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                  <InfoItem label="Patient" value={visit.patient.name} />
                  <InfoItem label="Patient UUID" value={visit.patient.patientUuid} />
                  <InfoItem label="Token" value={visit.tokenNo} />
                  <InfoItem label="Visit ID" value={visit.id} />
                  <InfoItem label="Department" value={visit.department} />
                  <InfoItem label="Status" value={visit.status} />
                  <InfoItem label="Doctor Note" value={visit.latestReportRemarks} />
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <Pill className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Medicine Items</h2>
                    <p className="mt-1 text-sm text-slate-600">
                      Doctor-confirmed prescription items ready for dispensing.
                    </p>
                  </div>
                </div>

                <div className="mt-4 space-y-3">
                  {visit.prescriptionItems.map((item) => (
                    <div key={item.id} className="rounded-lg border border-slate-200 p-4">
                      <div className="flex items-center justify-between gap-4">
                        <div>
                          <p className="text-sm font-semibold text-slate-900">{item.medicine}</p>
                          <p className="mt-1 text-sm text-slate-600">
                            Dosage {item.dosage} • {item.duration}
                          </p>
                          <p className="mt-1 text-xs text-slate-500">Current stock {item.stockQuantity}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-mono text-sm font-semibold text-[#0f5ea8]">
                            Qty {item.quantity}
                          </p>
                          <span className={`mt-2 inline-flex rounded-md px-2.5 py-1 text-xs font-medium ${
                            item.isDispensed
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-amber-50 text-amber-700'
                          }`}>
                            {item.isDispensed ? 'Dispensed' : 'Pending'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6">
                  <PharmacyDispenseButton
                    visitId={visit.id}
                    disabled={!hasPendingItems || visit.status === 'DISPENSED'}
                  />
                </div>
              </div>
            </section>

            <aside className="space-y-6 lg:col-span-4">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <Shield className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Inventory Check</h2>
                    <p className="mt-2 text-sm leading-6 text-slate-600">
                      Use this section to avoid dispensing items already close to stock limits.
                    </p>
                  </div>
                </div>

                <div className="mt-4 space-y-3">
                  {stockAlerts.length > 0 ? (
                    stockAlerts.map((item) => (
                      <div key={item.id} className="rounded-lg border border-slate-200 bg-slate-50 p-4">
                        <p className="text-sm font-semibold text-slate-900">{item.name}</p>
                        <p className="mt-1 text-sm text-slate-600">
                          Stock {item.stockQuantity} • Reorder level {item.reorderLevel}
                        </p>
                      </div>
                    ))
                  ) : (
                    <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-4 text-sm text-slate-600">
                      No low-stock alerts right now.
                    </div>
                  )}
                </div>
              </div>
            </aside>
          </div>
        </div>
      </main>
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 p-4">
      <p className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </p>
      <p className="mt-2 text-sm font-medium text-slate-900">{value}</p>
    </div>
  );
}
