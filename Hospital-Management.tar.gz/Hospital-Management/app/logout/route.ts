import { NextResponse } from 'next/server';

import { clearDatabaseSession } from '@/lib/auth';

export async function GET(request: Request) {
  await clearDatabaseSession();
  return NextResponse.redirect(new URL('/login', request.url));
}
