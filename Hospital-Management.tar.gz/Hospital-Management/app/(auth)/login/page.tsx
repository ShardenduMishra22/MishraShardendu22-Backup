import { redirect } from 'next/navigation';
import { Role } from '@prisma/client';
import { ShieldCheck, Stethoscope, UserCog, UserRound } from 'lucide-react';

import {
  authenticateUser,
  createDatabaseSessionForUser,
  getHomeForRole,
  getSession,
} from '@/lib/auth';

type LoginPageProps = {
  searchParams: Promise<{
    error?: string;
  }>;
};

function toLoginErrorRedirect(message: string) {
  const params = new URLSearchParams({ error: message });
  return `/login?${params.toString()}`;
}

async function loginAction(formData: FormData) {
  'use server';

  const username = String(formData.get('username') ?? '').trim();
  const password = String(formData.get('password') ?? '').trim();
  const role = String(formData.get('role') ?? '').trim() as Role;

  if (!username || !password || !role) {
    redirect(toLoginErrorRedirect('Please fill all login fields'));
  }

  let user: Awaited<ReturnType<typeof authenticateUser>> = null;

  try {
    user = await authenticateUser({ username, password, role });
  } catch (error) {
    console.error('Login credential check failed:', error);
    redirect(
      toLoginErrorRedirect(
        'Database connection failed. Please check DATABASE_URL and database status',
      ),
    );
  }

  if (!user) {
    redirect(toLoginErrorRedirect('Invalid role, username, or password'));
  }

  try {
    await createDatabaseSessionForUser(user.id);
  } catch (error) {
    console.error('Login session creation failed:', error);
    redirect(
      toLoginErrorRedirect(
        'Database connection failed. Please check DATABASE_URL and database status',
      ),
    );
  }

  redirect(getHomeForRole(user.role));
}

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const session = await getSession();
  if (session) {
    redirect(getHomeForRole(session.role));
  }

  const params = await searchParams;

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#f3f5f7] px-4 py-10 text-[#1f2937]">
      <div className="grid w-full max-w-5xl gap-6 lg:grid-cols-[420px_minmax(0,1fr)]">
        <section className="rounded-2xl border border-slate-200 bg-white p-8">
          <div className="mb-8">
            <p className="font-mono text-xs font-semibold uppercase tracking-[0.24em] text-[#0f5ea8]">
              Government Hospital
            </p>
            <h1 className="mt-3 font-display text-3xl font-semibold tracking-tight">
              Staff Login
            </h1>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Admin creates staff credentials. Receptionist, doctor, and pharmacist use those credentials to enter the system.
            </p>
          </div>

          {params.error ? (
            <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {params.error}
            </div>
          ) : null}

          <form action={loginAction} className="space-y-4">
            <Field label="Role">
              <select
                name="role"
                required
                className="app-select w-full rounded-lg border border-slate-300 bg-white px-4 py-3 text-base outline-none focus:border-[#0f5ea8]"
                defaultValue={Role.RECEPTIONIST}
              >
                <option value={Role.ADMIN}>Admin</option>
                <option value={Role.RECEPTIONIST}>Receptionist</option>
                <option value={Role.DOCTOR}>Doctor</option>
                <option value={Role.PHARMACIST}>Pharmacist</option>
              </select>
            </Field>

            <Field label="Username">
              <input
                name="username"
                type="text"
                required
                className="w-full rounded-lg border border-slate-300 px-4 py-3 text-base outline-none focus:border-[#0f5ea8]"
                placeholder="Enter username"
              />
            </Field>

            <Field label="Password">
              <input
                name="password"
                type="password"
                required
                className="w-full rounded-lg border border-slate-300 px-4 py-3 text-base outline-none focus:border-[#0f5ea8]"
                placeholder="Enter password"
              />
            </Field>

            <button
              type="submit"
              className="w-full rounded-lg bg-[#0f5ea8] px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-[#0c4d8a]"
            >
              Login to System
            </button>
          </form>
        </section>

        <aside className="space-y-4">
          <InfoCard
            icon={<UserCog className="h-5 w-5 text-[#0f5ea8]" />}
            title="Admin"
            detail="Single admin account creates hospital staff credentials and controls access."
          />
          <InfoCard
            icon={<UserRound className="h-5 w-5 text-[#0f5ea8]" />}
            title="Receptionist"
            detail="Uses admin-created credentials to register patients and generate OPD slips."
          />
          <InfoCard
            icon={<Stethoscope className="h-5 w-5 text-[#0f5ea8]" />}
            title="Doctor"
            detail="Uses admin-created credentials to open visits, review scans, and confirm medicines."
          />
          <InfoCard
            icon={<ShieldCheck className="h-5 w-5 text-[#0f5ea8]" />}
            title="Patient Portal"
            detail="Not implemented yet in the schema. Current auth covers hospital staff accounts only."
          />
        </aside>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 block font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </span>
      {children}
    </label>
  );
}

function InfoCard({
  icon,
  title,
  detail,
}: {
  icon: React.ReactNode;
  title: string;
  detail: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6">
      <div className="flex items-start gap-3">
        {icon}
        <div>
          <h2 className="font-display text-xl font-semibold">{title}</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600">{detail}</p>
        </div>
      </div>
    </div>
  );
}
