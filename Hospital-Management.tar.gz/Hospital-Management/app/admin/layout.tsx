import { Role } from '@prisma/client';

import { requireSession } from '@/lib/auth';

export default async function AdminLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  await requireSession([Role.ADMIN]);
  return children;
}
