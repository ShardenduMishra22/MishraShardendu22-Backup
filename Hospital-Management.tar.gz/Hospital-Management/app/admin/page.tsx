import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { Role } from '@prisma/client';
import { ClipboardPlus, KeyRound, ShieldCheck, Users } from 'lucide-react';

import { ConsoleSidebar } from '@/components/console-sidebar';
import { hashPassword, requireSession } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { RECEPTION_DEPARTMENTS } from '@/lib/reception-utils';

const ADMIN_ITEMS = [
  {
    href: '/admin',
    label: 'Credential Desk',
    detail: 'Create staff usernames and passwords',
    icon: 'keyRound',
    matchers: ['/admin'],
  },
  {
    label: 'Single Admin',
    detail: 'Only one admin account manages staff access',
    icon: 'shieldCheck',
  },
  {
    label: 'Hospital Users',
    detail: 'Receptionist, doctor, pharmacist credentials',
    icon: 'users',
  },
] as const;

type AdminPageProps = {
  searchParams: Promise<{
    created?: string;
    error?: string;
  }>;
};

async function createStaffUser(formData: FormData) {
  'use server';

  await requireSession([Role.ADMIN]);

  const username = String(formData.get('username') ?? '').trim();
  const password = String(formData.get('password') ?? '').trim();
  const role = String(formData.get('role') ?? '').trim() as Role;
  const doctorDepartment = String(formData.get('doctorDepartment') ?? '').trim();

  if (!username || !password || !role) {
    redirect('/admin?error=All%20fields%20are%20required');
  }

  const allowedStaffRoles: Role[] = [
    Role.RECEPTIONIST,
    Role.DOCTOR,
    Role.PHARMACIST,
  ];

  if (!allowedStaffRoles.includes(role)) {
    redirect('/admin?error=Only%20staff%20roles%20can%20be%20created%20here');
  }

  if (role === Role.DOCTOR && !doctorDepartment) {
    redirect('/admin?error=Doctor%20department%20is%20required');
  }

  if (
    role === Role.DOCTOR &&
    !RECEPTION_DEPARTMENTS.includes(
      doctorDepartment as (typeof RECEPTION_DEPARTMENTS)[number],
    )
  ) {
    redirect('/admin?error=Please%20select%20a%20valid%20doctor%20department');
  }

  const existingUser = await prisma.user.findUnique({
    where: { username },
  });

  if (existingUser) {
    redirect('/admin?error=Username%20already%20exists');
  }

  if (role === Role.DOCTOR) {
    await prisma.user.create({
      data: {
        username,
        password: hashPassword(password),
        role,
        doctorDepartment,
      },
    });
  } else {
    await prisma.user.create({
      data: {
        username,
        password: hashPassword(password),
        role,
      },
    });
  }

  revalidatePath('/admin');
  redirect('/admin?created=1');
}

export default async function AdminPage({ searchParams }: AdminPageProps) {
  const session = await requireSession([Role.ADMIN]);
  const params = await searchParams;

  const users = await prisma.user.findMany({
    orderBy: [
      { role: 'asc' },
      { username: 'asc' },
    ],
  });

  const staffUsers = users.filter((user) => user.role !== Role.ADMIN);

  return (
    <div className="flex min-h-screen bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Admin Login"
        description="Admin-only control for creating hospital staff credentials and onboarding desk users."
        items={ADMIN_ITEMS}
      />

      <main className="min-w-0 flex-1">
        <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
          <header className="flex flex-col gap-4 border-b border-slate-200 pb-5 md:flex-row md:items-end md:justify-between">
            <div>
              <h1 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
                Admin Credential Desk
              </h1>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
                Create usernames and passwords for reception, doctor, and pharmacy staff.
              </p>
            </div>
            <div className="rounded-lg border border-slate-200 bg-white px-4 py-3">
              <p className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                Logged In
              </p>
              <p className="mt-1 text-sm font-medium text-slate-900">{session.username}</p>
            </div>
          </header>

          {params.error ? (
            <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {params.error}
            </div>
          ) : null}

          {params.created ? (
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
              Staff credential created successfully.
            </div>
          ) : null}

          <div className="grid gap-6 lg:grid-cols-12">
            <section className="space-y-6 lg:col-span-6">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <KeyRound className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Create Staff Login</h2>
                    <p className="mt-1 text-sm text-slate-600">
                      Admin creates credentials once, then staff use them at the login screen.
                    </p>
                  </div>
                </div>

                <form action={createStaffUser} className="mt-6 space-y-4">
                  <Field label="Username">
                    <input
                      name="username"
                      type="text"
                      required
                      className="w-full rounded-lg border border-slate-300 px-4 py-3 text-base outline-none focus:border-[#0f5ea8]"
                      placeholder="doctor.sharma"
                    />
                  </Field>

                  <Field label="Password">
                    <input
                      name="password"
                      type="password"
                      required
                      minLength={6}
                      className="w-full rounded-lg border border-slate-300 px-4 py-3 text-base outline-none focus:border-[#0f5ea8]"
                      placeholder="Temporary password"
                    />
                  </Field>

                  <Field label="Role">
                    <select
                      name="role"
                      required
                      className="app-select w-full rounded-lg border border-slate-300 bg-white px-4 py-3 text-base outline-none focus:border-[#0f5ea8]"
                    >
                      <option value={Role.RECEPTIONIST}>Receptionist</option>
                      <option value={Role.DOCTOR}>Doctor</option>
                      <option value={Role.PHARMACIST}>Pharmacist</option>
                    </select>
                  </Field>

                  <Field label="Doctor Department (required for doctor role)">
                    <select
                      name="doctorDepartment"
                      className="app-select w-full rounded-lg border border-slate-300 bg-white px-4 py-3 text-base outline-none focus:border-[#0f5ea8]"
                      defaultValue={RECEPTION_DEPARTMENTS[0]}
                    >
                      {RECEPTION_DEPARTMENTS.map((department) => (
                        <option key={department} value={department}>
                          {department}
                        </option>
                      ))}
                    </select>
                  </Field>

                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#0f5ea8] px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-[#0c4d8a]"
                  >
                    <ClipboardPlus className="h-4 w-4" />
                    Generate Credentials
                  </button>
                </form>
              </div>
            </section>

            <aside className="space-y-6 lg:col-span-6">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Admin Rules</h2>
                    <p className="mt-1 text-sm text-slate-600">
                      This system keeps one admin account and uses it to issue hospital staff credentials.
                    </p>
                  </div>
                </div>

                <div className="mt-5 space-y-3">
                  <RuleRow text="Only the admin can create hospital staff logins." />
                  <RuleRow text="Admin creation is blocked from this panel." />
                  <RuleRow text="Current bootstrap admin comes from env or defaults on first run." />
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex items-start gap-3">
                  <Users className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Hospital Users</h2>
                    <p className="mt-1 text-sm text-slate-600">
                      Staff accounts currently registered in the system.
                    </p>
                  </div>
                </div>

                <div className="mt-5 space-y-3">
                  {staffUsers.length > 0 ? (
                    staffUsers.map((user) => (
                      <div
                        key={user.id}
                        className="flex items-center justify-between rounded-lg border border-slate-200 p-4"
                      >
                        <div>
                          <p className="text-sm font-semibold text-slate-900">{user.username}</p>
                          <p className="mt-1 text-xs font-medium text-slate-500">
                            {user.role}
                            {(user as { doctorDepartment?: string | null }).doctorDepartment
                              ? ` • ${(user as { doctorDepartment?: string | null }).doctorDepartment}`
                              : ''}
                          </p>
                        </div>
                        <p className="text-xs text-slate-500">
                          {new Date(user.createdAt).toLocaleDateString('en-IN')}
                        </p>
                      </div>
                    ))
                  ) : (
                    <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">
                      No staff credentials created yet.
                    </div>
                  )}
                </div>
              </div>

            </aside>
          </div>
        </div>
      </main>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 block font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </span>
      {children}
    </label>
  );
}

function RuleRow({ text }: { text: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700">
      {text}
    </div>
  );
}
