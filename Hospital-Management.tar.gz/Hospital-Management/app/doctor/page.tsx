'use client';

import Link from 'next/link';
import React, { useEffect, useMemo, useState } from 'react';
import { ListOrdered, ShieldAlert } from 'lucide-react';
import { useRouter } from 'next/navigation';

import { ConsoleSidebar } from '@/components/console-sidebar';
import { PaginationControls } from '@/components/ui/pagination-controls';
import { DOCTOR_ITEMS } from '@/lib/doctor-utils';
import {
  digitsOnly,
  type DoctorQueueVisit,
} from '@/lib/reception-utils';

type BusyState = 'loading' | null;
type VisitWorkflowStatus = 'WAITING' | 'CONSULTING' | 'PRESCRIBED' | 'DISPENSED';
type DoctorQueuePayload = {
  department: string;
  visits: DoctorQueueVisit[];
};

const VISIT_STATUS_OPTIONS: VisitWorkflowStatus[] = [
  'WAITING',
  'CONSULTING',
  'PRESCRIBED',
  'DISPENSED',
];

async function readJson<T>(response: Response): Promise<T> {
  const payload = (await response.json().catch(() => null)) as
    | { error?: string }
    | T
    | null;

  if (!response.ok) {
    throw new Error(
      (payload && typeof payload === 'object' && 'error' in payload && payload.error) ||
        'Request failed.',
    );
  }

  return payload as T;
}

function statusClasses(status: string) {
  if (status === 'WAITING') return 'bg-amber-100 text-amber-700';
  if (status === 'CONSULTING') return 'bg-sky-100 text-sky-700';
  if (status === 'PRESCRIBED') return 'bg-emerald-100 text-emerald-700';
  return 'bg-slate-100 text-slate-700';
}

function getStatusPriority(status: string) {
  if (status === 'WAITING') return 0;
  if (status === 'CONSULTING') return 1;
  if (status === 'PRESCRIBED') return 2;
  return 3;
}

export default function DoctorDashboardPage() {
  const router = useRouter();
  const [queueRows, setQueueRows] = useState<DoctorQueueVisit[]>([]);
  const [department, setDepartment] = useState<string>('Assigned Department');
  const [tokenInput, setTokenInput] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [busyState, setBusyState] = useState<BusyState>('loading');
  const [updatingVisitId, setUpdatingVisitId] = useState<string | null>(null);
  const [queuePage, setQueuePage] = useState(1);
  const [queuePageSize, setQueuePageSize] = useState(10);

  useEffect(() => {
    let isActive = true;

    async function loadQueue() {
      setBusyState('loading');
      setFeedback(null);

      try {
        const response = await fetch(
          '/api/doctor/queue',
          { cache: 'no-store' },
        );
        const payload = await readJson<DoctorQueuePayload>(response);

        if (!isActive) {
          return;
        }

        setQueueRows(payload.visits);
        setDepartment(payload.department);
      } catch (error) {
        if (!isActive) {
          return;
        }

        setQueueRows([]);
        setFeedback(
          error instanceof Error
            ? error.message
            : 'Unable to load doctor queue right now.',
        );
      } finally {
        if (isActive) {
          setBusyState(null);
        }
      }
    }

    void loadQueue();

    return () => {
      isActive = false;
    };
  }, []);

  const normalizedToken = useMemo(() => {
    const digits = digitsOnly(tokenInput).slice(-4);
    return digits ? digits.padStart(4, '0') : '';
  }, [tokenInput]);

  const matchedVisit = useMemo(
    () =>
      queueRows.find((visit) => visit.tokenNo === normalizedToken) ?? null,
    [queueRows, normalizedToken],
  );

  const prioritizedQueue = useMemo(() => {
    return [...queueRows].sort((a, b) => {
      const statusDiff = getStatusPriority(a.status) - getStatusPriority(b.status);
      if (statusDiff !== 0) {
        return statusDiff;
      }

      const tokenA = Number.parseInt(a.tokenNo, 10);
      const tokenB = Number.parseInt(b.tokenNo, 10);

      if (!Number.isNaN(tokenA) && !Number.isNaN(tokenB) && tokenA !== tokenB) {
        return tokenA - tokenB;
      }

      return a.createdLabel.localeCompare(b.createdLabel);
    });
  }, [queueRows]);

  const paginatedQueue = useMemo(() => {
    const start = (queuePage - 1) * queuePageSize;
    return prioritizedQueue.slice(start, start + queuePageSize);
  }, [prioritizedQueue, queuePage, queuePageSize]);

  useEffect(() => {
    setQueuePage(1);
  }, [queuePageSize]);

  useEffect(() => {
    const maxPage = Math.max(1, Math.ceil(prioritizedQueue.length / queuePageSize));
    if (queuePage > maxPage) {
      setQueuePage(maxPage);
    }
  }, [prioritizedQueue.length, queuePage, queuePageSize]);

  const handleStatusChange = async (
    visitId: string,
    nextStatus: VisitWorkflowStatus,
  ) => {
    const current = queueRows.find((visit) => visit.id === visitId);

    if (!current || current.status === nextStatus) {
      return;
    }

    try {
      setUpdatingVisitId(visitId);
      setFeedback(null);

      const response = await fetch(`/api/doctor/visits/${visitId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: nextStatus }),
      });

      const updated = await readJson<DoctorQueueVisit>(response);

      setQueueRows((currentRows) =>
        currentRows.map((visit) => (visit.id === visitId ? updated : visit)),
      );
      setFeedback(`Visit ${updated.id} status updated to ${updated.status}.`);
    } catch (error) {
      setFeedback(
        error instanceof Error
          ? error.message
          : 'Unable to update patient status right now.',
      );
    } finally {
      setUpdatingVisitId(null);
    }
  };

  const handleConsultClick = async (visit: DoctorQueueVisit) => {
    if (visit.status === 'WAITING') {
      try {
        setUpdatingVisitId(visit.id);
        setFeedback(null);

        const response = await fetch(`/api/doctor/visits/${visit.id}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ status: 'CONSULTING' }),
        });

        const updated = await readJson<DoctorQueueVisit>(response);

        setQueueRows((currentRows) =>
          currentRows.map((row) => (row.id === visit.id ? updated : row)),
        );
      } catch (error) {
        setFeedback(
          error instanceof Error
            ? error.message
            : 'Unable to update patient status right now.',
        );
        setUpdatingVisitId(null);
        return;
      }
    }

    setUpdatingVisitId(null);
    router.push(`/doctor/consult/${visit.id}`);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Doctor"
        description="Doctor functions for queue review, consultation, scanned reports, and prescription confirmation."
        items={DOCTOR_ITEMS}
      />

      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
          <header className="border-b border-slate-200 pb-5">
            <h1 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
              Doctor Desk
            </h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
              Open the scanned visit, verify the updated patient details coming from reception, review notes, and continue the consultation flow.
            </p>
          </header>

          <div className="space-y-6">
            <section className="space-y-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <div className="flex items-start gap-3">
                  <ListOrdered className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <p className="font-mono text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">
                      Token Access
                    </p>
                    <h2 className="mt-2 font-display text-2xl font-semibold text-slate-900">
                      Open by token number
                    </h2>
                    <p className="mt-2 text-sm leading-6 text-slate-600">
                      Your department is fixed by admin. Enter today’s 4-digit token to open the current patient.
                    </p>
                  </div>
                </div>

                <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
                  <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">
                    Assigned Department
                  </p>
                  <p className="mt-1 text-sm font-semibold text-slate-900">{department}</p>
                </div>

                <div className="mt-5 grid gap-3 sm:grid-cols-[1fr_auto]">
                  <input
                    value={tokenInput}
                    onChange={(event) => setTokenInput(event.target.value)}
                    className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-base outline-none transition-colors focus:border-[#0f5ea8]"
                    placeholder="0001"
                  />
                  {matchedVisit ? (
                    <Link
                      href={`/doctor/consult/${matchedVisit.id}`}
                      className="inline-flex items-center justify-center whitespace-nowrap rounded-xl bg-[#0f5ea8] px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#0c4d8a]"
                    >
                      Open Visit
                    </Link>
                  ) : (
                    <button
                      type="button"
                      disabled
                      className="inline-flex items-center justify-center whitespace-nowrap rounded-xl bg-slate-200 px-5 py-3 text-sm font-semibold text-slate-500"
                    >
                      Open Visit
                    </button>
                  )}
                </div>

                <div className="mt-5 rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-4">
                  {matchedVisit ? (
                    <div className="grid gap-4 md:grid-cols-2">
                      <MiniInfo label="Token" value={matchedVisit.tokenNo} />
                      <MiniInfo label="Patient" value={matchedVisit.patient.name} />
                      <MiniInfo label="Patient UUID" value={matchedVisit.patient.patientUuid} />
                      <MiniInfo label="Father Name" value={matchedVisit.patient.fatherName || 'Not added'} />
                      <MiniInfo label="Department" value={matchedVisit.department} />
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 text-sm text-amber-700">
                      <ShieldAlert className="h-5 w-5" />
                      {normalizedToken
                        ? `No patient found for this token in today’s ${department} queue.`
                        : 'Enter a token to open the current patient.'}
                    </div>
                  )}
                </div>
              </div>

              
            </section>

            {feedback ? (
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm font-medium text-amber-700">
                {feedback}
              </div>
            ) : null}
          </div>
        </div>
      </main>
    </div>
  );
}

function MiniInfo({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </p>
      <p className="mt-2 text-sm font-medium text-slate-900">{value}</p>
    </div>
  );
}
