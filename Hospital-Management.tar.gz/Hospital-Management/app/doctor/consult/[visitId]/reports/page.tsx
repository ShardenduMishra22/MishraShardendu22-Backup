import Link from 'next/link';
import { ArrowLeft, FileImage } from 'lucide-react';
import { notFound } from 'next/navigation';

import { ConsoleSidebar } from '@/components/console-sidebar';
import { DoctorStatusSelector } from '@/components/doctor-status-selector';
import { DoctorReportScanner } from '@/components/doctor-report-scanner';
import { getDoctorConsultItems } from '@/lib/doctor-utils';
import { getDoctorConsultDetailsById } from '@/lib/reception-data';

type DoctorReportsPageProps = {
  params: Promise<{
    visitId: string;
  }>;
};

function statusClasses(status: string) {
  if (status === 'WAITING') return 'bg-amber-100 text-amber-700';
  if (status === 'CONSULTING') return 'bg-sky-100 text-sky-700';
  if (status === 'PRESCRIBED') return 'bg-emerald-100 text-emerald-700';
  return 'bg-slate-100 text-slate-700';
}

export default async function DoctorReportsPage({ params }: DoctorReportsPageProps) {
  const { visitId } = await params;
  const visit = await getDoctorConsultDetailsById(visitId);

  if (!visit) {
    notFound();
  }

  const latestReport = visit.reports[0] ?? null;

  return (
    <div className="flex h-screen overflow-hidden bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Doctor"
        description="Doctor functions for queue review, consultation, scanned reports, and prescription confirmation."
        items={getDoctorConsultItems(visit.id)}
      />

      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
          <header className="border-b border-slate-200 pb-5">
            <Link
              href={`/doctor/consult/${visit.id}`}
              className="inline-flex items-center gap-2 text-sm font-medium text-[#0f5ea8]"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to patient summary
            </Link>
            <div className="mt-3 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
                  Scanned Reports
                </h1>
                <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
                  Review scanned OPD notes and doctor remarks in one focused workspace.
                </p>
              </div>
              <span className={`inline-flex w-fit rounded-full px-3 py-1 text-xs font-semibold ${statusClasses(visit.status)}`}>
                {visit.status}
              </span>
            </div>
          </header>

          <div className="grid gap-6 xl:grid-cols-[minmax(0,1.7fr)_minmax(320px,0.9fr)]">
            <section className="space-y-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <div className="flex items-start gap-3">
                  <FileImage className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Latest Scanned Note</h2>
                    <p className="mt-1 text-sm leading-6 text-slate-600">
                      Open the most recent report image for quick handwriting verification.
                    </p>
                  </div>
                </div>

                <div className="mt-5 flex h-80 items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-slate-50 text-center">
                  {latestReport ? (
                    <div>
                      <p className="font-display text-lg font-semibold text-slate-900">Report attached</p>
                      <p className="mt-2 text-sm text-slate-500">Uploaded {latestReport.uploadedLabel}</p>
                      <a
                        href={latestReport.imageUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-4 inline-flex rounded-lg border border-[#0f5ea8] px-4 py-2 text-sm font-semibold text-[#0f5ea8]"
                      >
                        Open scanned image
                      </a>
                    </div>
                  ) : (
                    <div>
                      <p className="font-display text-lg font-semibold text-slate-900">No scanned note yet</p>
                      <p className="mt-2 text-sm text-slate-500">Upload from scanner workflow to view here.</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="font-display text-xl font-semibold">Report Log</h2>
                <div className="mt-5 overflow-hidden rounded-xl border border-slate-200">
                  <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50">
                      <tr>
                        <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Upload</th>
                        <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Remarks</th>
                        <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Image</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                      {visit.reports.length > 0 ? (
                        visit.reports.map((report) => (
                          <tr key={report.id}>
                            <td className="px-4 py-3 text-slate-700">{report.uploadedLabel}</td>
                            <td className="px-4 py-3 text-slate-700">{report.doctorRemarks}</td>
                            <td className="px-4 py-3">
                              <a
                                href={report.imageUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="text-sm font-semibold text-[#0f5ea8]"
                              >
                                Open
                              </a>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={3} className="px-4 py-6 text-center text-sm text-slate-600">
                            No report records available for this visit.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>

            <aside className="space-y-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="font-display text-xl font-semibold">Scan & Save Report</h2>
                <p className="mt-1 text-sm leading-6 text-slate-600">
                  Upload the physical scanned file. It will be attached to this visit and visible in the patient profile.
                </p>
                <div className="mt-4">
                  <DoctorReportScanner visitId={visit.id} />
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="font-display text-xl font-semibold">Visit Controls</h2>
                <div className="mt-4">
                  <DoctorStatusSelector visitId={visit.id} status={visit.status} />
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="font-display text-xl font-semibold">Visit Context</h2>
                <div className="mt-4 space-y-3 rounded-xl border border-slate-200 bg-slate-50 p-4">
                  <InfoRow label="Patient" value={visit.patient.name} />
                  <InfoRow label="Patient UUID" value={visit.patient.patientUuid} />
                  <InfoRow label="Token" value={visit.tokenNo} />
                  <InfoRow label="Visit ID" value={visit.id} />
                  <InfoRow label="Department" value={visit.department} />
                </div>
              </div>
            </aside>
          </div>
        </div>
      </main>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-2 last:border-b-0">
      <span className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </span>
      <span className="max-w-44 truncate text-right text-sm font-medium text-slate-900">{value}</span>
    </div>
  );
}
