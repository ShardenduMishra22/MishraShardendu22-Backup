import Link from 'next/link';
import type { ReactNode } from 'react';
import {
  ArrowLeft,
  ClipboardCheck,
  Pill,
  UserRound,
} from 'lucide-react';
import { notFound } from 'next/navigation';

import { ConsoleSidebar } from '@/components/console-sidebar';
import { DoctorStatusSelector } from '@/components/doctor-status-selector';
import { getDoctorConsultItems } from '@/lib/doctor-utils';
import { getDoctorConsultDetailsById } from '@/lib/reception-data';

type DoctorConsultPageProps = {
  params: Promise<{
    visitId: string;
  }>;
};

function statusClasses(status: string) {
  if (status === 'WAITING') return 'bg-amber-100 text-amber-700';
  if (status === 'CONSULTING') return 'bg-sky-100 text-sky-700';
  if (status === 'PRESCRIBED') return 'bg-emerald-100 text-emerald-700';
  return 'bg-slate-100 text-slate-700';
}

export default async function DoctorConsultPage({
  params,
}: DoctorConsultPageProps) {
  const { visitId } = await params;
  const visit = await getDoctorConsultDetailsById(visitId);

  if (!visit) {
    notFound();
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Doctor"
        description="Doctor functions for queue review, consultation, scanned reports, and prescription confirmation."
        items={getDoctorConsultItems(visit.id)}
      />

      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
          <header className="border-b border-slate-200 pb-5">
            <Link
              href="/doctor/queue"
              className="inline-flex items-center gap-2 text-sm font-medium text-[#0f5ea8]"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to doctor queue
            </Link>
            <div className="mt-3 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
                  {visit.patient.name}
                </h1>
                <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
                  Patient summary is organized for quick clinical decisions: chief complaint, active status, key identity checks, then prescription details.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <span className={`inline-flex w-fit rounded-full px-3 py-1 text-xs font-semibold ${statusClasses(visit.status)}`}>
                  {visit.status}
                </span>
                <Link
                  href={`/doctor/consult/${visit.id}/reports`}
                  className="inline-flex items-center justify-center rounded-lg border border-[#0f5ea8] px-4 py-2 text-sm font-semibold text-[#0f5ea8]"
                >
                  Open Scanned Reports
                </Link>
              </div>
            </div>
          </header>

          <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
            <TopInfoCard label="Chief Complaint" value={visit.chiefComplaint} icon={<ClipboardCheck className="h-4 w-4" />} />
            <TopInfoCard label="Department" value={visit.department} icon={<UserRound className="h-4 w-4" />} />
            <TopInfoCard label="Token" value={visit.tokenNo} icon={<UserRound className="h-4 w-4" />} />
            <TopInfoCard label="Age / Gender" value={`${visit.patient.age} / ${visit.patient.gender}`} icon={<UserRound className="h-4 w-4" />} />
            <TopInfoCard label="Created" value={visit.createdLabel} icon={<UserRound className="h-4 w-4" />} />
          </section>

          <div className="grid gap-6 xl:grid-cols-[minmax(0,1.6fr)_minmax(320px,0.9fr)]">
            <section className="space-y-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <div className="flex items-start gap-3">
                  <Pill className="mt-1 h-5 w-5 text-[#0f5ea8]" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Prescription Table</h2>
                    <p className="mt-1 text-sm leading-6 text-slate-600">
                      Medicines are shown in a compact table for quick review before pharmacy handoff.
                    </p>
                  </div>
                </div>

                <div className="mt-5 overflow-hidden rounded-xl border border-slate-200">
                  <table className="min-w-full divide-y divide-slate-200 text-sm">
                    <thead className="bg-slate-50">
                      <tr>
                        <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                          Medicine
                        </th>
                        <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                          Dosage
                        </th>
                        <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                          Duration
                        </th>
                        <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                          Qty
                        </th>
                        <th className="px-4 py-3 text-left font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                          Dispensed
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                      {visit.prescriptionItems.length > 0 ? (
                        visit.prescriptionItems.map((item) => (
                          <tr key={item.id}>
                            <td className="px-4 py-3 font-medium text-slate-900">{item.medicine}</td>
                            <td className="px-4 py-3 text-slate-700">{item.dosage}</td>
                            <td className="px-4 py-3 text-slate-700">{item.duration}</td>
                            <td className="px-4 py-3 text-slate-700">{item.quantity}</td>
                            <td className="px-4 py-3">
                              <span
                                className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${
                                  item.isDispensed
                                    ? 'bg-emerald-100 text-emerald-700'
                                    : 'bg-amber-100 text-amber-700'
                                }`}
                              >
                                {item.isDispensed ? 'Yes' : 'No'}
                              </span>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={5} className="px-4 py-6 text-center text-sm text-slate-600">
                            No prescription items added yet for this visit.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>

            <aside className="space-y-6">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="font-display text-xl font-semibold text-slate-900">
                  Patient Identity Check
                </h2>
                <p className="mt-1 text-sm leading-6 text-slate-600">
                  Verify key identity fields before starting or continuing consultation.
                </p>
                <div className="mt-4 space-y-3 rounded-xl border border-slate-200 bg-slate-50 p-4">
                  <InfoRow label="Patient Name" value={visit.patient.name} />
                  <InfoRow label="Age / Gender" value={`${visit.patient.age} / ${visit.patient.gender}`} />
                  <InfoRow label="Token" value={visit.tokenNo} />
                  <InfoRow label="Patient UUID" value={visit.patient.patientUuid} />
                  <InfoRow label="Phone" value={visit.patient.phone} />
                </div>

                <div className="mt-4 rounded-xl border border-slate-200 bg-white p-4">
                  <p className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                    Additional Registration Details
                  </p>
                  <div className="mt-3 space-y-3">
                    <InfoRow label="Father Name" value={visit.patient.fatherName || 'Not added'} />
                    <InfoRow label="Address" value={visit.patient.address || 'Not added'} />
                    <InfoRow label="Visit ID" value={visit.id} />
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="font-display text-xl font-semibold text-slate-900">
                  Visit Controls
                </h2>
                <p className="mt-1 text-sm leading-6 text-slate-600">
                  Update workflow status and quickly move to scanned report review.
                </p>
                <div className="mt-4">
                  <DoctorStatusSelector visitId={visit.id} status={visit.status} />
                </div>
                <Link
                  href={`/doctor/consult/${visit.id}/reports`}
                  className="mt-4 inline-flex w-full items-center justify-center rounded-lg border border-[#0f5ea8] px-4 py-2 text-sm font-semibold text-[#0f5ea8]"
                >
                  Open Scanned Reports
                </Link>
                <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-3">
                  <p className="font-mono text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                    Immediate Clinical Focus
                  </p>
                  <p className="mt-2 text-sm text-slate-700">{visit.chiefComplaint}</p>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </main>
    </div>
  );
}

function TopInfoCard({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon: ReactNode;
}) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex items-center gap-2 text-[#0f5ea8]">{icon}</div>
      <p className="mt-2 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </p>
      <p className="mt-2 text-sm font-medium text-slate-900">{value}</p>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-2 last:border-b-0">
      <span className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
        {label}
      </span>
      <span className="max-w-44 truncate text-right text-sm font-medium text-slate-900">
        {value}
      </span>
    </div>
  );
}
