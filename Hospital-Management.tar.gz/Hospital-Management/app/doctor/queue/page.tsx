'use client';

import Link from 'next/link';
import React, { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';

import { ConsoleSidebar } from '@/components/console-sidebar';
import { PaginationControls } from '@/components/ui/pagination-controls';
import { DOCTOR_ITEMS } from '@/lib/doctor-utils';
import {
  type DoctorQueueVisit,
} from '@/lib/reception-utils';

type BusyState = 'loading' | null;
type VisitWorkflowStatus = 'WAITING' | 'CONSULTING' | 'PRESCRIBED' | 'DISPENSED';
type DoctorQueuePayload = {
  department: string;
  visits: DoctorQueueVisit[];
};

const VISIT_STATUS_OPTIONS: VisitWorkflowStatus[] = [
  'WAITING',
  'CONSULTING',
  'PRESCRIBED',
  'DISPENSED',
];

async function readJson<T>(response: Response): Promise<T> {
  const payload = (await response.json().catch(() => null)) as
    | { error?: string }
    | T
    | null;

  if (!response.ok) {
    throw new Error(
      (payload && typeof payload === 'object' && 'error' in payload && payload.error) ||
        'Request failed.',
    );
  }

  return payload as T;
}

function statusClasses(status: string) {
  if (status === 'WAITING') return 'bg-amber-100 text-amber-700';
  if (status === 'CONSULTING') return 'bg-sky-100 text-sky-700';
  if (status === 'PRESCRIBED') return 'bg-emerald-100 text-emerald-700';
  return 'bg-slate-100 text-slate-700';
}

function getStatusPriority(status: string) {
  if (status === 'WAITING') return 0;
  if (status === 'CONSULTING') return 1;
  if (status === 'PRESCRIBED') return 2;
  return 3;
}

export default function DoctorQueuePage() {
  const router = useRouter();
  const [queueRows, setQueueRows] = useState<DoctorQueueVisit[]>([]);
  const [department, setDepartment] = useState<string>('Assigned Department');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [busyState, setBusyState] = useState<BusyState>('loading');
  const [updatingVisitId, setUpdatingVisitId] = useState<string | null>(null);
  const [queuePage, setQueuePage] = useState(1);
  const [queuePageSize, setQueuePageSize] = useState(10);

  useEffect(() => {
    let isActive = true;

    async function loadQueue() {
      setBusyState('loading');
      setFeedback(null);

      try {
        const response = await fetch('/api/doctor/queue', { cache: 'no-store' });
        const payload = await readJson<DoctorQueuePayload>(response);

        if (!isActive) {
          return;
        }

        setQueueRows(payload.visits);
        setDepartment(payload.department);
      } catch (error) {
        if (!isActive) {
          return;
        }

        setQueueRows([]);
        setFeedback(
          error instanceof Error
            ? error.message
            : 'Unable to load doctor queue right now.',
        );
      } finally {
        if (isActive) {
          setBusyState(null);
        }
      }
    }

    void loadQueue();

    return () => {
      isActive = false;
    };
  }, []);

  const prioritizedQueue = useMemo(() => {
    return [...queueRows].sort((a, b) => {
      const statusDiff = getStatusPriority(a.status) - getStatusPriority(b.status);
      if (statusDiff !== 0) {
        return statusDiff;
      }

      const tokenA = Number.parseInt(a.tokenNo, 10);
      const tokenB = Number.parseInt(b.tokenNo, 10);

      if (!Number.isNaN(tokenA) && !Number.isNaN(tokenB) && tokenA !== tokenB) {
        return tokenA - tokenB;
      }

      return a.createdLabel.localeCompare(b.createdLabel);
    });
  }, [queueRows]);

  const paginatedQueue = useMemo(() => {
    const start = (queuePage - 1) * queuePageSize;
    return prioritizedQueue.slice(start, start + queuePageSize);
  }, [prioritizedQueue, queuePage, queuePageSize]);

  useEffect(() => {
    setQueuePage(1);
  }, [queuePageSize]);

  useEffect(() => {
    const maxPage = Math.max(1, Math.ceil(prioritizedQueue.length / queuePageSize));
    if (queuePage > maxPage) {
      setQueuePage(maxPage);
    }
  }, [prioritizedQueue.length, queuePage, queuePageSize]);

  const handleStatusChange = async (
    visitId: string,
    nextStatus: VisitWorkflowStatus,
  ) => {
    const current = queueRows.find((visit) => visit.id === visitId);

    if (!current || current.status === nextStatus) {
      return;
    }

    try {
      setUpdatingVisitId(visitId);
      setFeedback(null);

      const response = await fetch(`/api/doctor/visits/${visitId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: nextStatus }),
      });

      const updated = await readJson<DoctorQueueVisit>(response);

      setQueueRows((currentRows) => {
        if (updated.status === 'PRESCRIBED' || updated.status === 'DISPENSED') {
          return currentRows.filter((visit) => visit.id !== visitId);
        }

        return currentRows.map((visit) => (visit.id === visitId ? updated : visit));
      });
      setFeedback(`Visit ${updated.id} status updated to ${updated.status}.`);
    } catch (error) {
      setFeedback(
        error instanceof Error
          ? error.message
          : 'Unable to update patient status right now.',
      );
    } finally {
      setUpdatingVisitId(null);
    }
  };

  const handleConsultClick = async (visit: DoctorQueueVisit) => {
    if (visit.status === 'WAITING') {
      try {
        setUpdatingVisitId(visit.id);
        setFeedback(null);

        const response = await fetch(`/api/doctor/visits/${visit.id}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ status: 'CONSULTING' }),
        });

        const updated = await readJson<DoctorQueueVisit>(response);

        setQueueRows((currentRows) =>
          currentRows.map((row) => (row.id === visit.id ? updated : row)),
        );
      } catch (error) {
        setFeedback(
          error instanceof Error
            ? error.message
            : 'Unable to update patient status right now.',
        );
        setUpdatingVisitId(null);
        return;
      }
    }

    setUpdatingVisitId(null);
    router.push(`/doctor/consult/${visit.id}`);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#f3f5f7] text-[#1f2937]">
      <ConsoleSidebar
        title="Doctor"
        description="Doctor functions for queue review, consultation, scanned reports, and prescription confirmation."
        items={DOCTOR_ITEMS}
      />

      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
          <header className="border-b border-slate-200 pb-5">
            <h1 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
              Doctor Queue
            </h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
              Today’s active queue for your assigned department. Prescribed and completed visits are auto-removed.
            </p>
          </header>

          <div className="space-y-6">
            <div className="bg-white p-6">
              <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-4">
                <div>
                  <p className="font-mono text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">
                    Queue
                  </p>
                  <h2 className="mt-2 font-display text-2xl font-semibold text-slate-900">
                    Active Patients
                  </h2>
                  <p className="mt-2 text-sm leading-6 text-slate-600">
                    Today’s queue is department-scoped and ordered by status then token number.
                  </p>
                </div>
                <div className="text-right">
                  <p className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
                    {queueRows.length} visits
                  </p>
                  <p className="mt-2 text-xs text-slate-500">{department}</p>
                </div>
              </div>

              <div className="mt-5 space-y-3">
                {busyState === 'loading' ? (
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">
                    Loading today’s queue...
                  </div>
                ) : prioritizedQueue.length > 0 ? (
                  paginatedQueue.map((visit) => (
                    <div
                      key={visit.id}
                      className="rounded-2xl border border-slate-200 bg-white p-4 transition-colors hover:border-[#0f5ea8]"
                    >
                      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_220px]">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="rounded-md bg-slate-900 px-2.5 py-1 font-mono text-xs font-semibold text-white">
                              Token {visit.tokenNo}
                            </span>
                            <span className={`rounded-full px-3 py-1 text-xs font-semibold ${statusClasses(visit.status)}`}>
                              {visit.status}
                            </span>
                            <span className="text-xs text-slate-500">{visit.department}</span>
                            <span className="text-xs text-slate-400">•</span>
                            <span className="text-xs text-slate-500">{visit.createdLabel}</span>
                          </div>

                          <p className="mt-3 font-display text-xl font-semibold text-slate-900">
                            {visit.patient.name}
                          </p>

                          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-slate-600">
                            <span>{visit.patient.age}Y / {visit.patient.gender}</span>
                            <span className="text-slate-400">•</span>
                            <span className="font-mono text-xs font-semibold text-[#0f5ea8]">
                              {visit.patient.patientUuid}
                            </span>
                          </div>

                          <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3">
                            <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
                              Chief Complaint
                            </p>
                            <p className="mt-1 text-sm text-slate-700">{visit.chiefComplaint}</p>
                          </div>

                          <p className="mt-2 text-xs text-slate-500">Visit ID {visit.id}</p>
                        </div>

                        <div className="space-y-3 rounded-xl border border-slate-200 bg-slate-50 p-3">
                          <button
                            type="button"
                            disabled={updatingVisitId === visit.id}
                            onClick={() => {
                              void handleConsultClick(visit);
                            }}
                            className="inline-flex w-full items-center justify-center rounded-lg bg-[#0f5ea8] px-3 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#0c4d8a] disabled:opacity-60"
                          >
                            {visit.status === 'WAITING' ? 'Start Consult' : 'Open Consult'}
                          </button>

                          <Link
                            href={`/doctor/consult/${visit.id}`}
                            className="inline-flex w-full items-center justify-center rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-100"
                          >
                            View Summary
                          </Link>

                          <div>
                            <label className="mb-1 block text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-500">
                              Update Status
                            </label>
                            <select
                              value={visit.status}
                              disabled={updatingVisitId === visit.id}
                              onChange={(event) => {
                                void handleStatusChange(
                                  visit.id,
                                  event.target.value as VisitWorkflowStatus,
                                );
                              }}
                              className="app-select w-full rounded-lg border border-slate-300 bg-white px-2 py-2 text-xs font-semibold text-slate-700 disabled:opacity-60"
                            >
                              {VISIT_STATUS_OPTIONS.map((status) => (
                                <option key={status} value={status}>
                                  {status}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-4 text-sm text-slate-600">
                    No active visits found today for {department}.
                  </div>
                )}
              </div>

              {prioritizedQueue.length > 0 ? (
                <PaginationControls
                  totalItems={prioritizedQueue.length}
                  page={queuePage}
                  pageSize={queuePageSize}
                  onPageChange={setQueuePage}
                  onPageSizeChange={setQueuePageSize}
                  itemLabel="visits"
                  pageSizeOptions={[5, 10, 20]}
                />
              ) : null}
            </div>

            {feedback ? (
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm font-medium text-amber-700">
                {feedback}
              </div>
            ) : null}
          </div>
        </div>
      </main>
    </div>
  );
}
