import { Role } from '@prisma/client';

import { requireSession } from '@/lib/auth';

export default async function DoctorLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  await requireSession([Role.ADMIN, Role.DOCTOR]);
  return children;
}
