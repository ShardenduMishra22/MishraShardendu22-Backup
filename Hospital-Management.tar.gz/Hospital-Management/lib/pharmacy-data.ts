import 'server-only';

import { Prisma } from '@prisma/client';

import { prisma } from '@/lib/prisma';
import { formatCreatedLabel } from '@/lib/reception-utils';
import {
  type PharmacyQueueVisit,
  type PharmacyStockAlert,
  type PharmacyVisitDetails,
} from '@/lib/pharmacy-utils';

function mapPharmacyQueueVisit(
  visit: Prisma.VisitGetPayload<{
    include: {
      patient: true;
      prescriptionItems: true;
    };
  }>,
): PharmacyQueueVisit {
  const pendingItems = visit.prescriptionItems.filter((item) => !item.isDispensed).length;

  return {
    id: visit.id,
    tokenNo: visit.tokenNo,
    department: visit.department,
    status: visit.status,
    createdLabel: formatCreatedLabel(visit.createdAt),
    patient: {
      patientUuid: visit.patient.patientUuid,
      name: visit.patient.name,
      age: visit.patient.age,
      gender: visit.patient.gender,
    },
    pendingItems,
  };
}

function mapPharmacyVisit(
  visit: Prisma.VisitGetPayload<{
    include: {
      patient: true;
      reports: {
        orderBy: {
          uploadedAt: 'desc';
        };
      };
      prescriptionItems: {
        include: {
          medicine: true;
        };
        orderBy: {
          createdAt: 'asc';
        };
      };
    };
  }>,
): PharmacyVisitDetails {
  const latestReport = visit.reports[0] ?? null;

  return {
    id: visit.id,
    tokenNo: visit.tokenNo,
    department: visit.department,
    status: visit.status,
    createdLabel: formatCreatedLabel(visit.createdAt),
    patient: {
      patientUuid: visit.patient.patientUuid,
      name: visit.patient.name,
      phone: visit.patient.phone,
      age: visit.patient.age,
      gender: visit.patient.gender,
      fatherName: visit.patient.fatherName ?? '',
      address: visit.patient.address ?? '',
    },
    latestReportRemarks: latestReport?.doctorRemarks ?? 'No doctor remarks added yet.',
    prescriptionItems: visit.prescriptionItems.map((item) => ({
      id: item.id,
      medicineId: item.medicineId,
      medicine: item.medicine.name,
      dosage: item.dosage,
      duration: item.duration,
      quantity: item.totalQuantity,
      isDispensed: item.isDispensed,
      stockQuantity: item.medicine.stockQuantity,
    })),
  };
}

export async function getPharmacyQueueVisits() {
  const visits = await prisma.visit.findMany({
    where: {
      status: {
        in: ['PRESCRIBED', 'DISPENSED'],
      },
    },
    orderBy: [{ status: 'asc' }, { createdAt: 'asc' }],
    include: {
      patient: true,
      prescriptionItems: true,
    },
  });

  return visits.map(mapPharmacyQueueVisit);
}

export async function getPharmacyVisitById(visitId: string) {
  const visit = await prisma.visit.findUnique({
    where: { id: visitId },
    include: {
      patient: true,
      reports: {
        orderBy: {
          uploadedAt: 'desc',
        },
      },
      prescriptionItems: {
        orderBy: {
          createdAt: 'asc',
        },
        include: {
          medicine: true,
        },
      },
    },
  });

  return visit ? mapPharmacyVisit(visit) : null;
}

export async function getPharmacyStockAlerts(): Promise<PharmacyStockAlert[]> {
  const lowStock = await prisma.medicine.findMany({
    where: {
      reorderLevel: {
        not: null,
      },
    },
    orderBy: [{ stockQuantity: 'asc' }, { name: 'asc' }],
    select: {
      id: true,
      name: true,
      stockQuantity: true,
      reorderLevel: true,
    },
  });

  return lowStock
    .filter(
      (item): item is typeof item & { reorderLevel: number } =>
        item.reorderLevel !== null && item.stockQuantity <= item.reorderLevel,
    )
    .map((item) => ({
      id: item.id,
      name: item.name,
      stockQuantity: item.stockQuantity,
      reorderLevel: item.reorderLevel,
    }));
}

export async function dispensePharmacyVisit(visitId: string) {
  return prisma.$transaction(async (tx) => {
    const visit = await tx.visit.findUnique({
      where: { id: visitId },
      include: {
        patient: true,
        reports: {
          orderBy: {
            uploadedAt: 'desc',
          },
        },
        prescriptionItems: {
          orderBy: {
            createdAt: 'asc',
          },
          include: {
            medicine: true,
          },
        },
      },
    });

    if (!visit) {
      throw new Error('Visit not found.');
    }

    const pendingItems = visit.prescriptionItems.filter((item) => !item.isDispensed);

    if (pendingItems.length === 0) {
      const alreadyDispensedVisit = await tx.visit.update({
        where: { id: visitId },
        data: { status: 'DISPENSED' },
        include: {
          patient: true,
          reports: {
            orderBy: {
              uploadedAt: 'desc',
            },
          },
          prescriptionItems: {
            orderBy: {
              createdAt: 'asc',
            },
            include: {
              medicine: true,
            },
          },
        },
      });

      return mapPharmacyVisit(alreadyDispensedVisit);
    }

    for (const item of pendingItems) {
      if (item.medicine.stockQuantity < item.totalQuantity) {
        throw new Error(`Not enough stock for ${item.medicine.name}.`);
      }
    }

    for (const item of pendingItems) {
      await tx.medicine.update({
        where: { id: item.medicineId },
        data: {
          stockQuantity: {
            decrement: item.totalQuantity,
          },
        },
      });
    }

    await tx.prescriptionItem.updateMany({
      where: {
        visitId,
        isDispensed: false,
      },
      data: {
        isDispensed: true,
      },
    });

    const updatedVisit = await tx.visit.update({
      where: { id: visitId },
      data: {
        status: 'DISPENSED',
      },
      include: {
        patient: true,
        reports: {
          orderBy: {
            uploadedAt: 'desc',
          },
        },
        prescriptionItems: {
          orderBy: {
            createdAt: 'asc',
          },
          include: {
            medicine: true,
          },
        },
      },
    });

    return mapPharmacyVisit(updatedVisit);
  });
}
