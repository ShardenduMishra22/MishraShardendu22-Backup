export const DOCTOR_ITEMS = [
  {
    href: '/doctor',
    label: 'Token Access',
    detail: 'Open a patient quickly by today’s token',
    icon: 'keyRound' as const,
    matchers: ['/doctor'],
  },
  {
    href: '/doctor/queue',
    label: 'Patients Queue',
    detail: 'Open waiting visits and active consultations',
    icon: 'stethoscope' as const,
    matchers: ['/doctor/queue'],
  },
  {
    label: 'Consultation Workspace',
    detail: 'Open patient summary and clinical workflow',
    icon: 'clipboardCheck' as const,
    matchers: ['/doctor/consult'],
  },
  {
    label: 'Scanned Reports',
    detail: 'Check scanned notes and doctor remarks',
    icon: 'fileScan' as const,
    matchers: ['/doctor/consult'],
  },
];

export function getDoctorConsultItems(visitId: string) {
  return [
    {
      href: '/doctor',
      label: 'Token Access',
      detail: 'Open a patient quickly by today’s token',
      icon: 'keyRound' as const,
      matchers: ['/doctor'],
    },
    {
      href: '/doctor/queue',
      label: 'Doctor Queue',
      detail: 'Open waiting visits and active consultations',
      icon: 'stethoscope' as const,
      matchers: ['/doctor/queue'],
    },
    {
      href: `/doctor/consult/${visitId}`,
      label: 'Patient Summary',
      detail: 'Most important clinical details first',
      icon: 'clipboardCheck' as const,
      matchers: [`/doctor/consult/${visitId}`],
    },
    {
      href: `/doctor/consult/${visitId}/reports`,
      label: 'Scanned Reports',
      detail: 'Scanned notes and doctor remarks',
      icon: 'fileScan' as const,
      matchers: [`/doctor/consult/${visitId}/reports`],
    },
  ];
}
