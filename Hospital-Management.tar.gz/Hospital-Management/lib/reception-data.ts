import 'server-only';

import { Prisma, VisitStatus } from '@prisma/client';

import { prisma } from '@/lib/prisma';
import {
  buildPatientUuid,
  formatCreatedLabel,
  generateDailyTokenNo,
  generateVisitId,
  type DoctorQueueVisit,
  type ReceptionPatientDetails,
  type ReceptionPatientInput,
  type ReceptionPatientRecord,
  type ReceptionVisitDetails,
} from '@/lib/reception-utils';

type PrismaTx = Prisma.TransactionClient;

type PatientWithLatestVisit = Prisma.PatientGetPayload<{
  include: {
    visits: {
      orderBy: { createdAt: 'desc' };
      take: 1;
    };
  };
}>;

type VisitWithPatientAndDoctor = Prisma.VisitGetPayload<{
  include: {
    patient: true;
    doctor: {
      select: {
        username: true;
      };
    };
  };
}>;

function getDayBounds(now: Date) {
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);

  const end = new Date(start);
  end.setDate(end.getDate() + 1);

  return { start, end };
}

function mapPatientRecord(patient: PatientWithLatestVisit): ReceptionPatientRecord {
  const latestVisit = patient.visits[0] ?? null;

  return {
    patientUuid: patient.patientUuid,
    name: patient.name,
    fatherName: patient.fatherName ?? '',
    phone: patient.phone,
    age: patient.age,
    gender: patient.gender,
    address: patient.address ?? '',
    department: latestVisit?.department ?? 'General Medicine',
    status: latestVisit?.status ?? 'NO_VISIT',
    tokenNo: latestVisit?.tokenNo ?? '----',
    visitId: latestVisit?.id ?? '',
    createdLabel: formatCreatedLabel(latestVisit?.createdAt ?? patient.createdAt),
  };
}

function mapPatientDetails(patient: PatientWithLatestVisit): ReceptionPatientDetails {
  const latestVisit = patient.visits[0] ?? null;

  return {
    patientUuid: patient.patientUuid,
    name: patient.name,
    fatherName: patient.fatherName ?? '',
    phone: patient.phone,
    age: patient.age,
    gender: patient.gender,
    address: patient.address ?? '',
    department: latestVisit?.department ?? 'General Medicine',
    createdLabel: formatCreatedLabel(patient.createdAt),
    currentVisit: latestVisit
      ? {
          id: latestVisit.id,
          department: latestVisit.department,
          tokenNo: latestVisit.tokenNo,
          status: latestVisit.status,
          createdLabel: formatCreatedLabel(latestVisit.createdAt),
        }
      : null,
  };
}

function mapVisitDetails(visit: VisitWithPatientAndDoctor): ReceptionVisitDetails {
  return {
    id: visit.id,
    department: visit.department,
    tokenNo: visit.tokenNo,
    status: visit.status,
    chiefComplaint: visit.chiefComplaint ?? 'Not added yet',
    doctor: visit.doctor?.username ?? 'Not assigned yet',
    createdLabel: formatCreatedLabel(visit.createdAt),
    patient: {
      patientUuid: visit.patient.patientUuid,
      name: visit.patient.name,
      fatherName: visit.patient.fatherName ?? '',
      phone: visit.patient.phone,
      age: visit.patient.age,
      gender: visit.patient.gender,
      address: visit.patient.address ?? '',
    },
  };
}

function mapDoctorQueueVisit(visit: VisitWithPatientAndDoctor): DoctorQueueVisit {
  return {
    id: visit.id,
    tokenNo: visit.tokenNo,
    department: visit.department,
    status: visit.status,
    chiefComplaint: visit.chiefComplaint ?? 'Chief complaint not added yet',
    createdLabel: formatCreatedLabel(visit.createdAt),
    patient: {
      patientUuid: visit.patient.patientUuid,
      name: visit.patient.name,
      fatherName: visit.patient.fatherName ?? '',
      phone: visit.patient.phone,
      age: visit.patient.age,
      gender: visit.patient.gender,
      address: visit.patient.address ?? '',
    },
  };
}

async function generateUniquePatientUuid(
  tx: PrismaTx,
  input: ReceptionPatientInput,
  now: Date,
) {
  if (input.patientUuid.trim()) {
    return input.patientUuid.trim().toUpperCase();
  }

  const { start, end } = getDayBounds(now);
  const serialBase =
    (await tx.patient.count({
      where: {
        createdAt: {
          gte: start,
          lt: end,
        },
      },
    })) + 1;

  let collisionIndex = 0;
  let candidate = buildPatientUuid(input, now, serialBase, collisionIndex);

  while (
    await tx.patient.findUnique({
      where: { patientUuid: candidate },
      select: { patientUuid: true },
    })
  ) {
    collisionIndex += 1;
    candidate = buildPatientUuid(input, now, serialBase, collisionIndex);
  }

  return candidate;
}

async function generateUniqueVisitId(tx: PrismaTx, patientName: string, now: Date) {
  const { start, end } = getDayBounds(now);
  const serialBase =
    (await tx.visit.count({
      where: {
        createdAt: {
          gte: start,
          lt: end,
        },
      },
    })) + 1;

  let collisionIndex = 0;
  let candidate = generateVisitId(patientName, now, serialBase + collisionIndex);

  while (
    await tx.visit.findUnique({
      where: { id: candidate },
      select: { id: true },
    })
  ) {
    collisionIndex += 1;
    candidate = generateVisitId(patientName, now, serialBase + collisionIndex);
  }

  return candidate;
}

async function generateDailyVisitToken(tx: PrismaTx, now: Date, department: string) {
  const { start, end } = getDayBounds(now);
  const serialBase =
    (await tx.visit.count({
      where: {
        department,
        createdAt: {
          gte: start,
          lt: end,
        },
      },
    })) + 1;

  let collisionIndex = 0;
  let candidate = generateDailyTokenNo(serialBase + collisionIndex);

  while (
    await tx.visit.findFirst({
      where: {
        department,
        tokenNo: candidate,
        createdAt: {
          gte: start,
          lt: end,
        },
      },
      select: { id: true },
    })
  ) {
    collisionIndex += 1;
    candidate = generateDailyTokenNo(serialBase + collisionIndex);
  }

  return candidate;
}

export async function getRecentReceptionPatients() {
  const patients = await prisma.patient.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      visits: {
        orderBy: { createdAt: 'desc' },
        take: 1,
      },
    },
  });

  return patients.map(mapPatientRecord);
}

export async function getReceptionPatientByUuid(patientUuid: string) {
  const patient = await prisma.patient.findUnique({
    where: { patientUuid },
    include: {
      visits: {
        orderBy: { createdAt: 'desc' },
        take: 1,
      },
    },
  });

  return patient ? mapPatientDetails(patient) : null;
}

export async function getReceptionVisitById(visitId: string) {
  const visit = await prisma.visit.findUnique({
    where: { id: visitId },
    include: {
      patient: true,
      doctor: {
        select: {
          username: true,
        },
      },
    },
  });

  return visit ? mapVisitDetails(visit) : null;
}

export async function getTodayDoctorQueueVisits(department?: string) {
  const now = new Date();
  const { start, end } = getDayBounds(now);

  const visits = await prisma.visit.findMany({
    where: {
      ...(department ? { department } : {}),
      status: {
        in: [VisitStatus.WAITING, VisitStatus.CONSULTING],
      },
      createdAt: {
        gte: start,
        lt: end,
      },
    },
    orderBy: [{ tokenNo: 'asc' }, { createdAt: 'asc' }],
    include: {
      patient: true,
      doctor: {
        select: {
          username: true,
        },
      },
    },
  });

  return visits.map(mapDoctorQueueVisit);
}

export async function getTodayDoctorVisitByToken(tokenNo: string, department?: string) {
  const now = new Date();
  const { start, end } = getDayBounds(now);

  const visit = await prisma.visit.findFirst({
    where: {
      ...(department ? { department } : {}),
      tokenNo,
      createdAt: {
        gte: start,
        lt: end,
      },
    },
    orderBy: { createdAt: 'asc' },
    include: {
      patient: true,
      doctor: {
        select: {
          username: true,
        },
      },
    },
  });

  return visit ? mapDoctorQueueVisit(visit) : null;
}

export async function getDoctorVisitById(visitId: string) {
  const visit = await prisma.visit.findUnique({
    where: { id: visitId },
    include: {
      patient: true,
      doctor: {
        select: {
          username: true,
        },
      },
    },
  });

  return visit ? mapDoctorQueueVisit(visit) : null;
}

export async function updateDoctorVisitStatus(
  visitId: string,
  status: VisitStatus,
) {
  const updated = await prisma.visit.update({
    where: { id: visitId },
    data: { status },
    include: {
      patient: true,
      doctor: {
        select: {
          username: true,
        },
      },
    },
  });

  return mapDoctorQueueVisit(updated);
}

type CreateDoctorScannedReportInput = {
  visitId: string;
  imageUrl: string;
  doctorRemarks?: string;
  text?: string;
};

export async function createDoctorScannedReportForVisit({
  visitId,
  imageUrl,
  doctorRemarks,
  text,
}: CreateDoctorScannedReportInput) {
  return prisma.$transaction(async (tx) => {
    const visit = await tx.visit.findUnique({
      where: { id: visitId },
      select: {
        id: true,
        patientId: true,
        status: true,
      },
    });

    if (!visit) {
      throw new Error('Visit not found.');
    }

    const report = await tx.report.create({
      data: {
        visitId: visit.id,
        patientId: visit.patientId,
        imageUrl,
        text: text?.trim() || null,
        doctorRemarks: doctorRemarks?.trim() || null,
      },
    });

    if (visit.status === 'WAITING' || visit.status === 'CONSULTING') {
      await tx.visit.update({
        where: { id: visit.id },
        data: { status: 'PRESCRIBED' },
      });
    }

    const updatedVisit = await tx.visit.findUniqueOrThrow({
      where: { id: visit.id },
      select: {
        status: true,
      },
    });

    return {
      id: report.id,
      visitId: report.visitId,
      patientId: report.patientId,
      imageUrl: report.imageUrl,
      text: report.text,
      doctorRemarks: report.doctorRemarks,
      uploadedAt: report.uploadedAt,
      visitStatus: updatedVisit.status,
    };
  });
}

export type DoctorConsultDetails = {
  id: string;
  tokenNo: string;
  department: string;
  status: string;
  chiefComplaint: string;
  createdLabel: string;
  patient: {
    patientUuid: string;
    name: string;
    fatherName: string;
    phone: string;
    age: number;
    gender: ReceptionPatientRecord['gender'];
    address: string;
  };
  reports: Array<{
    id: string;
    imageUrl: string;
    text: string;
    doctorRemarks: string;
    uploadedLabel: string;
  }>;
  prescriptionItems: Array<{
    id: string;
    medicine: string;
    dosage: string;
    duration: string;
    quantity: number;
    isDispensed: boolean;
  }>;
};

export async function getDoctorConsultDetailsById(
  visitId: string,
): Promise<DoctorConsultDetails | null> {
  const visit = await prisma.visit.findUnique({
    where: { id: visitId },
    include: {
      patient: true,
      reports: {
        orderBy: {
          uploadedAt: 'desc',
        },
      },
      prescriptionItems: {
        orderBy: {
          createdAt: 'asc',
        },
        include: {
          medicine: {
            select: {
              name: true,
            },
          },
        },
      },
    },
  });

  if (!visit) {
    return null;
  }

  return {
    id: visit.id,
    tokenNo: visit.tokenNo,
    department: visit.department,
    status: visit.status,
    chiefComplaint: visit.chiefComplaint ?? 'Chief complaint not added yet',
    createdLabel: formatCreatedLabel(visit.createdAt),
    patient: {
      patientUuid: visit.patient.patientUuid,
      name: visit.patient.name,
      fatherName: visit.patient.fatherName ?? '',
      phone: visit.patient.phone,
      age: visit.patient.age,
      gender: visit.patient.gender,
      address: visit.patient.address ?? '',
    },
    reports: visit.reports.map((report) => ({
      id: report.id,
      imageUrl: report.imageUrl,
      text: report.text ?? 'No extracted text available.',
      doctorRemarks: report.doctorRemarks ?? 'No doctor remarks added yet.',
      uploadedLabel: formatCreatedLabel(report.uploadedAt),
    })),
    prescriptionItems: visit.prescriptionItems.map((item) => ({
      id: item.id,
      medicine: item.medicine.name,
      dosage: item.dosage,
      duration: item.duration,
      quantity: item.totalQuantity,
      isDispensed: item.isDispensed,
    })),
  };
}

export async function createReceptionPatient(input: ReceptionPatientInput) {
  const now = new Date();

  return prisma.$transaction(async (tx) => {
    const patientUuid = await generateUniquePatientUuid(tx, input, now);

    if (
      input.patientUuid.trim() &&
      (await tx.patient.findUnique({
        where: { patientUuid },
        select: { patientUuid: true },
      }))
    ) {
      throw new Error(`Patient UUID ${patientUuid} already exists.`);
    }

    const visitId = await generateUniqueVisitId(tx, input.name, now);
    const tokenNo = await generateDailyVisitToken(tx, now, input.department);

    await tx.patient.create({
      data: {
        patientUuid,
        name: input.name.trim(),
        fatherName: input.fatherName.trim(),
        phone: input.phone.trim(),
        age: input.age,
        gender: input.gender,
        address: input.address.trim(),
      },
    });

    await tx.visit.create({
      data: {
        id: visitId,
        patientId: patientUuid,
        department: input.department,
        tokenNo,
        status: 'WAITING',
      },
    });

    const created = await tx.patient.findUniqueOrThrow({
      where: { patientUuid },
      include: {
        visits: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
      },
    });

    return mapPatientRecord(created);
  });
}

export async function updateReceptionPatient(
  currentPatientUuid: string,
  input: ReceptionPatientInput,
) {
  return prisma.$transaction(async (tx) => {
    const existing = await tx.patient.findUnique({
      where: { patientUuid: currentPatientUuid },
      include: {
        visits: {
          orderBy: { createdAt: 'desc' },
        },
        reports: true,
      },
    });

    if (!existing) {
      return null;
    }

    const nextPatientUuid = input.patientUuid.trim().toUpperCase() || existing.patientUuid;

    if (nextPatientUuid !== existing.patientUuid) {
      const duplicate = await tx.patient.findUnique({
        where: { patientUuid: nextPatientUuid },
        select: { patientUuid: true },
      });

      if (duplicate) {
        throw new Error(`Patient UUID ${nextPatientUuid} already exists.`);
      }

      await tx.patient.create({
        data: {
          patientUuid: nextPatientUuid,
          name: input.name.trim(),
          fatherName: input.fatherName.trim(),
          phone: input.phone.trim(),
          age: input.age,
          gender: input.gender,
          address: input.address.trim(),
          createdAt: existing.createdAt,
        },
      });

      await tx.visit.updateMany({
        where: { patientId: existing.patientUuid },
        data: { patientId: nextPatientUuid },
      });

      await tx.report.updateMany({
        where: { patientId: existing.patientUuid },
        data: { patientId: nextPatientUuid },
      });

      await tx.patient.delete({
        where: { patientUuid: existing.patientUuid },
      });
    } else {
      await tx.patient.update({
        where: { patientUuid: existing.patientUuid },
        data: {
          name: input.name.trim(),
          fatherName: input.fatherName.trim(),
          phone: input.phone.trim(),
          age: input.age,
          gender: input.gender,
          address: input.address.trim(),
        },
      });
    }

    const latestVisit = existing.visits[0] ?? null;

    if (latestVisit) {
      await tx.visit.update({
        where: { id: latestVisit.id },
        data: {
          department: input.department,
        },
      });
    }

    const updated = await tx.patient.findUniqueOrThrow({
      where: { patientUuid: nextPatientUuid },
      include: {
        visits: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
      },
    });

    return mapPatientRecord(updated);
  });
}
