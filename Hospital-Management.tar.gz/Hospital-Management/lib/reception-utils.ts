export const RECEPTION_ITEMS = [
  {
    href: '/reception',
    label: 'Registration Desk',
    detail: 'Search patient records and create registrations',
    icon: 'search' as const,
  },
  {
    href: '/reception/patients',
    label: 'Recent Patients',
    detail: 'Browse recent patient records and open details',
    icon: 'users' as const,
    matchers: ['/reception/patients'],
  },
  {
    label: 'Visit Review',
    detail: 'Verify patient details and issue OPD slips',
    icon: 'clipboardList' as const,
    matchers: ['/reception/visit'],
  },
  {
    label: 'Slip Printing',
    detail: 'Print visit slip with patient UUID and doctor token',
    icon: 'printer' as const,
  },
];

export type ReceptionGender = 'MALE' | 'FEMALE' | 'OTHER';

export type ReceptionPatientRecord = {
  patientUuid: string;
  name: string;
  fatherName: string;
  phone: string;
  age: number;
  gender: ReceptionGender;
  address: string;
  department: string;
  status: string;
  tokenNo: string;
  visitId: string;
  createdLabel: string;
};

export type ReceptionPatientDetails = {
  patientUuid: string;
  name: string;
  fatherName: string;
  phone: string;
  age: number;
  gender: ReceptionGender;
  address: string;
  department: string;
  createdLabel: string;
  currentVisit: {
    id: string;
    department: string;
    tokenNo: string;
    status: string;
    createdLabel: string;
  } | null;
};

export type ReceptionVisitDetails = {
  id: string;
  department: string;
  tokenNo: string;
  status: string;
  chiefComplaint: string;
  doctor: string;
  createdLabel: string;
  patient: {
    patientUuid: string;
    name: string;
    fatherName: string;
    phone: string;
    age: number;
    gender: ReceptionGender;
    address: string;
  };
};

export type ReceptionPatientForm = {
  patientUuid: string;
  name: string;
  fatherName: string;
  phone: string;
  age: string;
  gender: ReceptionGender;
  address: string;
  department: string;
};

export type ReceptionPatientInput = {
  patientUuid: string;
  name: string;
  fatherName: string;
  phone: string;
  age: number;
  gender: ReceptionGender;
  address: string;
  department: string;
};

export type DoctorQueueVisit = {
  id: string;
  tokenNo: string;
  department: string;
  status: string;
  chiefComplaint: string;
  createdLabel: string;
  patient: {
    patientUuid: string;
    name: string;
    fatherName: string;
    phone: string;
    age: number;
    gender: ReceptionGender;
    address: string;
  };
};

export const INITIAL_RECEPTION_FORM: ReceptionPatientForm = {
  patientUuid: '',
  name: '',
  fatherName: '',
  phone: '',
  age: '',
  gender: 'MALE',
  address: '',
  department: 'General Medicine',
};

export const RECEPTION_DEPARTMENTS = [
  'General Medicine',
  'Orthopedics',
  'Pediatrics',
  'ENT',
] as const;

export function buildSlice(value: string, fallback: string) {
  const cleaned = value.replace(/[^a-zA-Z]/g, '').toUpperCase();
  return (cleaned || fallback).slice(0, 3).padEnd(3, 'X');
}

export function buildVisitSlice(value: string, fallback: string) {
  const cleaned = value.replace(/[^a-zA-Z]/g, '').toUpperCase();
  return (cleaned || fallback).slice(0, 4).padEnd(4, 'X');
}

export function digitsOnly(value: string) {
  return value.replace(/\D/g, '');
}

export function normalizeValue(value: string) {
  return value.trim().toLowerCase();
}

export function normalizeReceptionGender(value: string): ReceptionGender {
  if (value === 'F' || value === 'FEMALE') return 'FEMALE';
  if (value === 'OTHER') return 'OTHER';
  return 'MALE';
}

export function formatCreatedLabel(date: Date | string) {
  const parsed = typeof date === 'string' ? new Date(date) : date;
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(parsed);
}

export function buildPatientUuid(
  formData: Pick<ReceptionPatientForm | ReceptionPatientInput, 'name' | 'fatherName' | 'phone'>,
  now: Date,
  serial: number,
  collisionIndex: number,
) {
  const nameSlice = buildSlice(formData.name, 'PAT');
  const fatherSlice = buildSlice(formData.fatherName, 'FAT');
  const phoneSlice = digitsOnly(formData.phone).slice(-4).padStart(4, '0');
  const serialSlice = String(serial + collisionIndex).padStart(4, '0');
  const dateSlice = `${String(now.getDate()).padStart(2, '0')}${String(
    now.getMonth() + 1,
  ).padStart(2, '0')}${String(now.getFullYear()).slice(-2)}`;

  return `${nameSlice}${fatherSlice}${phoneSlice}${serialSlice}-${dateSlice}`;
}

export function previewGeneratedPatientUuid(
  formData: Pick<ReceptionPatientForm, 'name' | 'fatherName' | 'phone'>,
  serial: number,
) {
  return buildPatientUuid(formData, new Date(), serial, 0);
}

export function generateVisitId(name: string, now: Date, serial: number) {
  const patientSlice = buildVisitSlice(name, 'PAT');
  const dateSlice = `${String(now.getDate()).padStart(2, '0')}${String(
    now.getMonth() + 1,
  ).padStart(2, '0')}${String(now.getFullYear()).slice(-2)}`;
  const sequence = String(serial).padStart(4, '0');

  return `${patientSlice}-VISIT-${dateSlice}-${sequence}`;
}

export function generateDailyTokenNo(serial: number) {
  return String(serial).padStart(4, '0');
}

export function extractVisitSequence(visitId: string) {
  const match = visitId.match(/(\d{4})$/);
  return match ? Number(match[1]) : 1;
}

export function validateReceptionPatientForm(formData: ReceptionPatientForm) {
  if (!formData.name.trim()) return 'Patient name is required before adding or saving.';
  if (!formData.fatherName.trim()) return 'Father name is required before adding or saving.';
  if (digitsOnly(formData.phone).length !== 10) return 'Please enter a valid 10-digit mobile number.';
  if (!formData.age.trim() || Number(formData.age) <= 0) return 'Please enter a valid patient age.';
  if (!formData.address.trim()) return 'Address is required before adding or saving.';

  return null;
}
