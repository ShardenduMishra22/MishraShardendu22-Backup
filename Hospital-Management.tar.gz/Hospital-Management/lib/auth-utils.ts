import 'server-only';

import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

import { Role } from '@prisma/client';

import { prisma } from '@/lib/prisma';

const DEFAULT_ADMIN_USERNAME = process.env.ADMIN_USERNAME ?? 'admin';
const DEFAULT_ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? 'Admin@123';

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, storedPassword: string) {
  const [salt, storedHash] = storedPassword.split(':');

  if (!salt || !storedHash) {
    return false;
  }

  const computedHash = scryptSync(password, salt, 64);
  const storedHashBuffer = Buffer.from(storedHash, 'hex');

  if (computedHash.length !== storedHashBuffer.length) {
    return false;
  }

  return timingSafeEqual(computedHash, storedHashBuffer);
}

export async function bootstrapAdminIfNeeded() {
  const existingAdmin = await prisma.user.findFirst({
    where: { role: Role.ADMIN },
    orderBy: { createdAt: 'asc' },
  });

  if (!existingAdmin) {
    await prisma.user.create({
      data: {
        username: DEFAULT_ADMIN_USERNAME,
        email: `${DEFAULT_ADMIN_USERNAME}@local.hms`,
        password: hashPassword(DEFAULT_ADMIN_PASSWORD),
        role: Role.ADMIN,
      },
    });
    return;
  }

  const usernameMatches = existingAdmin.username === DEFAULT_ADMIN_USERNAME;
  const passwordMatches = verifyPassword(
    DEFAULT_ADMIN_PASSWORD,
    existingAdmin.password,
  );

  if (usernameMatches && passwordMatches) {
    return;
  }

  await prisma.user.update({
    where: { id: existingAdmin.id },
    data: {
      username: DEFAULT_ADMIN_USERNAME,
      email: `${DEFAULT_ADMIN_USERNAME}@local.hms`,
      password: hashPassword(DEFAULT_ADMIN_PASSWORD),
    },
  });
}

export async function authenticateUser({
  username,
  password,
  role,
}: {
  username: string;
  password: string;
  role: Role;
}) {
  await bootstrapAdminIfNeeded();

  const user = await prisma.user.findUnique({
    where: { username },
  });

  if (!user || user.role !== role) {
    return null;
  }

  if (!verifyPassword(password, user.password)) {
    return null;
  }

  return user;
}

export function getHomeForRole(role: Role) {
  switch (role) {
    case Role.ADMIN:
      return '/admin';
    case Role.RECEPTIONIST:
      return '/reception';
    case Role.DOCTOR:
      return '/doctor';
    case Role.PHARMACIST:
      return '/pharmacy';
    case Role.LABORATORY:
      return '/';
    default:
      return '/login';
  }
}
