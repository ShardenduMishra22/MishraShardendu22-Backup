import 'server-only';

import { randomUUID } from 'node:crypto';

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { Role } from '@prisma/client';

import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';
import {
  authenticateUser,
  bootstrapAdminIfNeeded,
  getHomeForRole,
  hashPassword,
  verifyPassword,
} from '@/lib/auth-utils';

type AppSession = {
  userId: string;
  username: string;
  role: Role;
  doctorDepartment: string | null;
};

export async function getSession(): Promise<AppSession | null> {
  const session = await auth();

  if (!session?.user) {
    return null;
  }

  const role = session.user.role;

  if (!role) {
    return null;
  }

  return {
    userId: session.user.id,
    username: session.user.username ?? session.user.name ?? '',
    role,
    doctorDepartment: session.user.doctorDepartment ?? null,
  };
}

export async function requireSession(allowedRoles?: Role[]) {
  const session = await getSession();

  if (!session) {
    redirect('/login');
  }

  if (allowedRoles && !allowedRoles.includes(session.role)) {
    redirect(getHomeForRole(session.role));
  }

  return session;
}

function getSessionCookieName() {
  return process.env.NODE_ENV === 'production'
    ? '__Secure-authjs.session-token'
    : 'authjs.session-token';
}

export async function createDatabaseSessionForUser(userId: string) {
  const sessionToken = randomUUID();
  const maxAgeSeconds = 60 * 60 * 12;
  const expires = new Date(Date.now() + maxAgeSeconds * 1000);

  await prisma.session.create({
    data: {
      sessionToken,
      userId,
      expires,
    },
  });

  const cookieStore = await cookies();
  cookieStore.set(getSessionCookieName(), sessionToken, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    expires,
  });
}

export async function clearDatabaseSession() {
  const cookieStore = await cookies();
  const secureName = '__Secure-authjs.session-token';
  const nonSecureName = 'authjs.session-token';

  const sessionToken =
    cookieStore.get(secureName)?.value ?? cookieStore.get(nonSecureName)?.value;

  if (sessionToken) {
    await prisma.session.deleteMany({
      where: { sessionToken },
    });
  }

  cookieStore.set(secureName, '', {
    httpOnly: true,
    sameSite: 'lax',
    secure: true,
    path: '/',
    maxAge: 0,
  });

  cookieStore.set(nonSecureName, '', {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    path: '/',
    maxAge: 0,
  });
}

export {
  authenticateUser,
  bootstrapAdminIfNeeded,
  getHomeForRole,
  hashPassword,
  verifyPassword,
};
