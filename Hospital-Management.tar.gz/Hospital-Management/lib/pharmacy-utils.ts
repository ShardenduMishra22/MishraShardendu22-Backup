export const PHARMACY_ITEMS = [
  {
    href: '/pharmacy',
    label: 'Dispense Queue',
    detail: 'Open prescribed visits and issue medicines',
    icon: 'pill' as const,
    matchers: ['/pharmacy'],
  },
  {
    label: 'Dispense Visit',
    detail: 'Check doctor-approved items and mark dispensed',
    icon: 'clipboardCheck' as const,
    matchers: ['/pharmacy/dispense'],
  },
  {
    label: 'Stock Alerts',
    detail: 'Watch low inventory before it blocks dispensing',
    icon: 'shield' as const,
  },
];

export type PharmacyQueueVisit = {
  id: string;
  tokenNo: string;
  department: string;
  status: string;
  createdLabel: string;
  patient: {
    patientUuid: string;
    name: string;
    age: number;
    gender: 'MALE' | 'FEMALE' | 'OTHER';
  };
  pendingItems: number;
};

export type PharmacyStockAlert = {
  id: string;
  name: string;
  stockQuantity: number;
  reorderLevel: number;
};

export type PharmacyVisitDetails = {
  id: string;
  tokenNo: string;
  department: string;
  status: string;
  createdLabel: string;
  patient: {
    patientUuid: string;
    name: string;
    phone: string;
    age: number;
    gender: 'MALE' | 'FEMALE' | 'OTHER';
    fatherName: string;
    address: string;
  };
  latestReportRemarks: string;
  prescriptionItems: Array<{
    id: string;
    medicineId: string;
    medicine: string;
    dosage: string;
    duration: string;
    quantity: number;
    isDispensed: boolean;
    stockQuantity: number;
  }>;
};
