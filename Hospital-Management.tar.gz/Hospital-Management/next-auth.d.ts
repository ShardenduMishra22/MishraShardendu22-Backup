import type { DefaultSession } from 'next-auth';
import { Role } from '@prisma/client';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      username: string;
      role: Role;
      doctorDepartment: string | null;
    } & DefaultSession['user'];
  }

  interface User {
    username?: string | null;
    role?: Role;
    doctorDepartment?: string | null;
  }
}
