"use client"

import { useEffect, useRef, useState } from "react"

const templates = {
  linkedinCloud:
    "Hi [Name], I'm exploring Cloud / DevOps opportunities. My background includes strong Linux fundamentals, containerized systems, and hands-on cloud infrastructure work. I'd appreciate the chance to connect if relevant roles are open.\n\nResume: https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link\nLinkedIn: https://www.linkedin.com/in/shardendumishra22/\nGitHub: https://github.com/MishraShardendu22",
  linkedinBackend:
    "Hi [Name], I'm currently exploring Backend Engineer opportunities. My work has focused on backend systems, APIs, and building production-oriented services using Go and Node.js. I'd value the chance to connect if there are relevant openings.\n\nResume: https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link\nLinkedIn: https://www.linkedin.com/in/shardendumishra22/\nGitHub: https://github.com/MishraShardendu22",
  linkedinAi:
    "Hi [Name], I'm exploring AI / ML opportunities. My background includes applied machine learning, deep learning, and building practical AI-powered systems. I'd appreciate the chance to connect if suitable roles are open.\n\nResume: https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link\nLinkedIn: https://www.linkedin.com/in/shardendumishra22/\nGitHub: https://github.com/MishraShardendu22",
  coldCloud:
    "Hello [Name],\n\nI am reaching out regarding Cloud / DevOps opportunities.\n\nMy background includes Linux systems, containers, automation, and cloud infrastructure projects. I would appreciate consideration for any suitable openings.\n\nResume: https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link\nLinkedIn: https://www.linkedin.com/in/shardendumishra22/\nGitHub: https://github.com/MishraShardendu22\n\nRegards,\nShardendu Mishra",
  coldBackend:
    "Subject - Application for Backend Engineer Opportunities\n\nHello [Name],\n\nI am reaching out regarding Backend Engineer opportunities.\n\nMy experience includes backend development, APIs, and production-focused systems using Go and Node.js. I would appreciate consideration for relevant openings.\n\nResume: https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link\nLinkedIn: https://www.linkedin.com/in/shardendumishra22/\nGitHub: https://github.com/MishraShardendu22\n\nRegards,\nShardendu Mishra",
  coldAi:
    "Hello [Name],\n\nI am reaching out regarding AI / ML opportunities.\n\nMy background includes machine learning, deep learning, and applied AI system development. I would appreciate consideration for suitable roles.\n\nResume: https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link\nLinkedIn: https://www.linkedin.com/in/shardendumishra22/\nGitHub: https://github.com/MishraShardendu22\n\nRegards,\nShardendu Mishra",
  referral:
    "Hi [Name], I noticed you work at [Company]. I'm currently exploring opportunities in Cloud / Backend / AI roles and would appreciate a referral if there are suitable openings.\n\nResume: https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link",
  followUp:
    "Hi [Name], following up on my earlier message regarding opportunities at [Company]. I remain very interested and would appreciate consideration if any suitable roles are available.\n\nResume: https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link",
  connect:
    "Hi [Name], I'm a Software Engineer exploring Cloud / Backend / AI opportunities. Your experience at [Company] stood out to me. Would be glad to connect.",
}

const Page = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const timeoutRef = useRef<number | null>(null)

  const handleCopy = async (id: string, text: string) => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text)
      } else {
        const textarea = document.createElement("textarea")
        textarea.value = text
        textarea.style.position = "fixed"
        textarea.style.opacity = "0"
        document.body.appendChild(textarea)
        textarea.focus()
        textarea.select()
        document.execCommand("copy")
        document.body.removeChild(textarea)
      }

      setCopiedId(id)
      if (timeoutRef.current) {
        window.clearTimeout(timeoutRef.current)
      }
      timeoutRef.current = window.setTimeout(() => {
        setCopiedId(null)
      }, 2000)
    } catch (error) {
      console.error("Copy failed", error)
    }
  }

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        window.clearTimeout(timeoutRef.current)
      }
    }
  }, [])
  return (
    <main className="page">
      <header className="hero">
        <div className="hero-content">
          <p className="eyebrow">Outreach kit</p>
          <h1>Recruiter and Referral Messaging Pack</h1>
          <p className="subtitle">
            Nine ready-to-send templates for Cloud, Backend, and AI roles. Keep
            them short, clear, and easy to personalize.
          </p>
          <div className="link-row">
            <a
              className="btn primary"
              href="https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link"
              target="_blank"
              rel="noreferrer"
            >
              Resume
            </a>
            <a
              className="btn ghost"
              href="https://www.linkedin.com/in/shardendumishra22/"
              target="_blank"
              rel="noreferrer"
            >
              LinkedIn
            </a>
            <a
              className="btn ghost"
              href="https://github.com/MishraShardendu22"
              target="_blank"
              rel="noreferrer"
            >
              GitHub
            </a>
          </div>
          <div className="hero-meta">
            <span className="chip">Cloud / DevOps</span>
            <span className="chip">Backend</span>
            <span className="chip">AI / ML</span>
          </div>
        </div>
        <div className="hero-card">
          <div className="stat">
            <span className="stat-value">9</span>
            <span className="stat-label">Templates</span>
          </div>
          <div className="stat">
            <span className="stat-value">3</span>
            <span className="stat-label">Channels</span>
          </div>
          <p className="hero-note">
            Personalize the [Name] and [Company] placeholders before sending.
          </p>
        </div>
      </header>

      <nav className="nav">
        <a href="#linkedin">LinkedIn recruiter</a>
        <a href="#cold-email">Cold email</a>
        <a href="#quick-notes">Quick notes</a>
        <a href="#source">Source basis</a>
      </nav>

      <section className="section" id="linkedin">
        <div className="section-header">
          <h2>LinkedIn recruiter messages</h2>
          <p>Short introductions tailored to the role focus.</p>
        </div>
        <div className="grid">
          <article className="card" data-index="01">
            <div className="card-top">
              <span className="pill">Cloud / DevOps</span>
              <span className="channel">LinkedIn DM</span>
            </div>
            <div className="card-actions">
              <button
                type="button"
                className={`copy-btn ${
                  copiedId === "linkedinCloud" ? "copied" : ""
                }`}
                onClick={() => handleCopy("linkedinCloud", templates.linkedinCloud)}
              >
                {copiedId === "linkedinCloud" ? "Copied" : "Copy"}
              </button>
            </div>
            <h3>Recruiter message</h3>
            <div className="message">
              <p>
                Hi [Name], I'm exploring Cloud / DevOps opportunities. My
                background includes strong Linux fundamentals, containerized
                systems, and hands-on cloud infrastructure work. I'd appreciate
                the chance to connect if relevant roles are open.
              </p>
              <div className="message-links">
                <a
                  href="https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link"
                  target="_blank"
                  rel="noreferrer"
                >
                  Resume
                </a>
                <a
                  href="https://www.linkedin.com/in/shardendumishra22/"
                  target="_blank"
                  rel="noreferrer"
                >
                  LinkedIn
                </a>
                <a
                  href="https://github.com/MishraShardendu22"
                  target="_blank"
                  rel="noreferrer"
                >
                  GitHub
                </a>
              </div>
            </div>
          </article>

          <article className="card" data-index="02">
            <div className="card-top">
              <span className="pill">Backend</span>
              <span className="channel">LinkedIn DM</span>
            </div>
            <div className="card-actions">
              <button
                type="button"
                className={`copy-btn ${
                  copiedId === "linkedinBackend" ? "copied" : ""
                }`}
                onClick={() =>
                  handleCopy("linkedinBackend", templates.linkedinBackend)
                }
              >
                {copiedId === "linkedinBackend" ? "Copied" : "Copy"}
              </button>
            </div>
            <h3>Recruiter message</h3>
            <div className="message">
              <p>
                Hi [Name], I'm currently exploring Backend Engineer
                opportunities. My work has focused on backend systems, APIs, and
                building production-oriented services using Go and Node.js. I'd
                value the chance to connect if there are relevant openings.
              </p>
              <div className="message-links">
                <a
                  href="https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link"
                  target="_blank"
                  rel="noreferrer"
                >
                  Resume
                </a>
                <a
                  href="https://www.linkedin.com/in/shardendumishra22/"
                  target="_blank"
                  rel="noreferrer"
                >
                  LinkedIn
                </a>
                <a
                  href="https://github.com/MishraShardendu22"
                  target="_blank"
                  rel="noreferrer"
                >
                  GitHub
                </a>
              </div>
            </div>
          </article>

          <article className="card" data-index="03">
            <div className="card-top">
              <span className="pill">AI / ML</span>
              <span className="channel">LinkedIn DM</span>
            </div>
            <div className="card-actions">
              <button
                type="button"
                className={`copy-btn ${
                  copiedId === "linkedinAi" ? "copied" : ""
                }`}
                onClick={() => handleCopy("linkedinAi", templates.linkedinAi)}
              >
                {copiedId === "linkedinAi" ? "Copied" : "Copy"}
              </button>
            </div>
            <h3>Recruiter message</h3>
            <div className="message">
              <p>
                Hi [Name], I'm exploring AI / ML opportunities. My background
                includes applied machine learning, deep learning, and building
                practical AI-powered systems. I'd appreciate the chance to
                connect if suitable roles are open.
              </p>
              <div className="message-links">
                <a
                  href="https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link"
                  target="_blank"
                  rel="noreferrer"
                >
                  Resume
                </a>
                <a
                  href="https://www.linkedin.com/in/shardendumishra22/"
                  target="_blank"
                  rel="noreferrer"
                >
                  LinkedIn
                </a>
                <a
                  href="https://github.com/MishraShardendu22"
                  target="_blank"
                  rel="noreferrer"
                >
                  GitHub
                </a>
              </div>
            </div>
          </article>
        </div>
      </section>

      <section className="section" id="cold-email">
        <div className="section-header">
          <h2>Cold email templates</h2>
          <p>Longer outreach with a clear reason for contact.</p>
        </div>
        <div className="grid">
          <article className="card" data-index="04">
            <div className="card-top">
              <span className="pill">Cloud / DevOps</span>
              <span className="channel">Email</span>
            </div>
            <div className="card-actions">
              <button
                type="button"
                className={`copy-btn ${copiedId === "coldCloud" ? "copied" : ""}`}
                onClick={() => handleCopy("coldCloud", templates.coldCloud)}
              >
                {copiedId === "coldCloud" ? "Copied" : "Copy"}
              </button>
            </div>
            <h3>Cold email - Cloud</h3>
            <div className="message">
              <p>Hello [Name],</p>
              <p>I am reaching out regarding Cloud / DevOps opportunities.</p>
              <p>
                My background includes Linux systems, containers, automation,
                and cloud infrastructure projects. I would appreciate
                consideration for any suitable openings.
              </p>
              <div className="message-links">
                <a
                  href="https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link"
                  target="_blank"
                  rel="noreferrer"
                >
                  Resume
                </a>
                <a
                  href="https://www.linkedin.com/in/shardendumishra22/"
                  target="_blank"
                  rel="noreferrer"
                >
                  LinkedIn
                </a>
                <a
                  href="https://github.com/MishraShardendu22"
                  target="_blank"
                  rel="noreferrer"
                >
                  GitHub
                </a>
              </div>
              <p className="signature">
                Regards,
                <br />
                Shardendu Mishra
              </p>
            </div>
          </article>

          <article className="card" data-index="05">
            <div className="card-top">
              <span className="pill">Backend</span>
              <span className="channel">Email</span>
            </div>
            <div className="card-actions">
              <button
                type="button"
                className={`copy-btn ${
                  copiedId === "coldBackend" ? "copied" : ""
                }`}
                onClick={() => handleCopy("coldBackend", templates.coldBackend)}
              >
                {copiedId === "coldBackend" ? "Copied" : "Copy"}
              </button>
            </div>
            <h3>Cold email - Backend</h3>
            <div className="message">
              <p className="subject-line">
                Subject - Application for Backend Engineer Opportunities
              </p>
              <p>Hello [Name],</p>
              <p>I am reaching out regarding Backend Engineer opportunities.</p>
              <p>
                My experience includes backend development, APIs, and
                production-focused systems using Go and Node.js. I would
                appreciate consideration for relevant openings.
              </p>
              <div className="message-links">
                <a
                  href="https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link"
                  target="_blank"
                  rel="noreferrer"
                >
                  Resume
                </a>
                <a
                  href="https://www.linkedin.com/in/shardendumishra22/"
                  target="_blank"
                  rel="noreferrer"
                >
                  LinkedIn
                </a>
                <a
                  href="https://github.com/MishraShardendu22"
                  target="_blank"
                  rel="noreferrer"
                >
                  GitHub
                </a>
              </div>
              <p className="signature">
                Regards,
                <br />
                Shardendu Mishra
              </p>
            </div>
          </article>

          <article className="card" data-index="06">
            <div className="card-top">
              <span className="pill">AI / ML</span>
              <span className="channel">Email</span>
            </div>
            <div className="card-actions">
              <button
                type="button"
                className={`copy-btn ${copiedId === "coldAi" ? "copied" : ""}`}
                onClick={() => handleCopy("coldAi", templates.coldAi)}
              >
                {copiedId === "coldAi" ? "Copied" : "Copy"}
              </button>
            </div>
            <h3>Cold email - AI / ML</h3>
            <div className="message">
              <p>Hello [Name],</p>
              <p>I am reaching out regarding AI / ML opportunities.</p>
              <p>
                My background includes machine learning, deep learning, and
                applied AI system development. I would appreciate consideration
                for suitable roles.
              </p>
              <div className="message-links">
                <a
                  href="https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link"
                  target="_blank"
                  rel="noreferrer"
                >
                  Resume
                </a>
                <a
                  href="https://www.linkedin.com/in/shardendumishra22/"
                  target="_blank"
                  rel="noreferrer"
                >
                  LinkedIn
                </a>
                <a
                  href="https://github.com/MishraShardendu22"
                  target="_blank"
                  rel="noreferrer"
                >
                  GitHub
                </a>
              </div>
              <p className="signature">
                Regards,
                <br />
                Shardendu Mishra
              </p>
            </div>
          </article>
        </div>
      </section>

      <section className="section" id="quick-notes">
        <div className="section-header">
          <h2>Quick notes</h2>
          <p>Referral, follow-up, and short connect copy.</p>
        </div>
        <div className="grid">
          <article className="card" data-index="07">
            <div className="card-top">
              <span className="pill">Referral</span>
              <span className="channel">Message</span>
            </div>
            <div className="card-actions">
              <button
                type="button"
                className={`copy-btn ${copiedId === "referral" ? "copied" : ""}`}
                onClick={() => handleCopy("referral", templates.referral)}
              >
                {copiedId === "referral" ? "Copied" : "Copy"}
              </button>
            </div>
            <h3>Referral request</h3>
            <div className="message">
              <p>
                Hi [Name], I noticed you work at [Company]. I'm currently
                exploring opportunities in Cloud / Backend / AI roles and would
                appreciate a referral if there are suitable openings.
              </p>
              <div className="message-links">
                <a
                  href="https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link"
                  target="_blank"
                  rel="noreferrer"
                >
                  Resume
                </a>
              </div>
            </div>
          </article>

          <article className="card" data-index="08">
            <div className="card-top">
              <span className="pill">Follow-up</span>
              <span className="channel">Message</span>
            </div>
            <div className="card-actions">
              <button
                type="button"
                className={`copy-btn ${copiedId === "followUp" ? "copied" : ""}`}
                onClick={() => handleCopy("followUp", templates.followUp)}
              >
                {copiedId === "followUp" ? "Copied" : "Copy"}
              </button>
            </div>
            <h3>After no reply</h3>
            <div className="message">
              <p>
                Hi [Name], following up on my earlier message regarding
                opportunities at [Company]. I remain very interested and would
                appreciate consideration if any suitable roles are available.
              </p>
              <div className="message-links">
                <a
                  href="https://drive.google.com/file/d/1Fv-5awiroGex8aO78DcnXLCcVJNyvd6b/view?usp=drive_link"
                  target="_blank"
                  rel="noreferrer"
                >
                  Resume
                </a>
              </div>
            </div>
          </article>

          <article className="card" data-index="09">
            <div className="card-top">
              <span className="pill">LinkedIn</span>
              <span className="channel">Under 300</span>
            </div>
            <div className="card-actions">
              <button
                type="button"
                className={`copy-btn ${copiedId === "connect" ? "copied" : ""}`}
                onClick={() => handleCopy("connect", templates.connect)}
              >
                {copiedId === "connect" ? "Copied" : "Copy"}
              </button>
            </div>
            <h3>Connect note</h3>
            <div className="message">
              <p>
                Hi [Name], I'm a Software Engineer exploring Cloud / Backend /
                AI opportunities. Your experience at [Company] stood out to me.
                Would be glad to connect.
              </p>
            </div>
          </article>
        </div>
      </section>

      <section className="section" id="source">
        <div className="note">
          <h2>Source basis</h2>
          <p>
            Built only from your shared links and uploaded resume content. No
            assumptions added.
          </p>
        </div>
      </section>
    </main>
  )
}

export default Page
