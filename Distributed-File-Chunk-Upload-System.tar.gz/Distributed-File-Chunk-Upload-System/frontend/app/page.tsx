"use client";

import { useEffect, useMemo, useState } from "react";

type InitUploadResponse = {
  fileId: string;
  totalChunks: number;
};

type UploadStatus = {
  fileId: string;
  filename: string;
  totalSize: number;
  totalChunks: number;
  receivedChunks: number;
  receivedIndices: number[];
  status: string;
  finalObjectKey: string;
  createdAt: string;
  updatedAt: string;
};

type SessionsResponse = {
  sessions: UploadStatus[];
};

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:18080";
const CHUNK_SIZE = 8 * 1024 * 1024;
const PARALLEL_WORKERS = 4;
const SESSION_KEY_PREFIX = "uile-fpload-session";
const RECENT_SCAN_LIMIT = 24;

export default function Page() {
  const [file, setFile] = useState<File | null>(null);
  const [session, setSession] = useState<UploadStatus | null>(null);
  const [recent, setRecent] = useState<UploadStatus[]>([]);
  const [progress, setProgress] = useState(0);
  const [uploadedChunks, setUploadedChunks] = useState(0);
  const [failedChunks, setFailedChunks] = useState(0);
  const [busy, setBusy] = useState(false);
  const [statusLine, setStatusLine] = useState("Ready");
  const [errorLine, setErrorLine] = useState<string | null>(null);

  useEffect(() => {
    void loadRecent();
  }, []);

  const selectedLabel = useMemo(() => {
    if (!file) {
      return "No file selected";
    }
    return `${file.name} (${(file.size / (1024 * 1024)).toFixed(2)} MB)`;
  }, [file]);

  async function startUpload(): Promise<void> {
    if (!file) {
      setErrorLine("Select a file first.");
      return;
    }

    setBusy(true);
    setErrorLine(null);
    setFailedChunks(0);
    setUploadedChunks(0);
    setProgress(0);

    try {
      setStatusLine("Checking for resumable session...");
      const existing = await resolveResumableSession(file);
      if (existing) {
        rememberSession(file, existing.fileId);
        await uploadAndFinalize(file, existing);
        return;
      }

      setStatusLine("Initializing upload...");
      const init = await apiRequest<InitUploadResponse>("/api/uploads/init", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filename: file.name,
          totalSize: file.size,
          contentType: file.type || "application/octet-stream",
          fileChecksum: "",
        }),
      });

      rememberSession(file, init.fileId);
      const current = await getStatus(init.fileId);
      await uploadAndFinalize(file, current);
    } catch (err) {
      setErrorLine(messageOf(err));
      setStatusLine("Upload failed.");
    } finally {
      setBusy(false);
      await loadRecent();
    }
  }

  async function resumeUpload(): Promise<void> {
    if (!file) {
      setErrorLine("Select the original file to resume.");
      return;
    }

    setBusy(true);
    setErrorLine(null);
    setFailedChunks(0);

    try {
      setStatusLine("Searching for resumable session...");
      const current = await resolveResumableSession(file);
      if (!current) {
        setErrorLine("No resumable upload session was found for this file.");
        setStatusLine("Select the exact file and try Resume again.");
        return;
      }

      rememberSession(file, current.fileId);
      await uploadAndFinalize(file, current);
    } catch (err) {
      setErrorLine(messageOf(err));
      setStatusLine("Resume failed.");
    } finally {
      setBusy(false);
      await loadRecent();
    }
  }

  async function uploadAndFinalize(selected: File, current: UploadStatus, recoveryAttempt = 0): Promise<void> {
    setSession(current);
    setUploadedChunks(current.receivedChunks);
    setProgress(Math.round((current.receivedChunks / Math.max(current.totalChunks, 1)) * 100));

    setStatusLine("Uploading missing chunks in parallel...");
    const failed = await uploadMissingChunks(selected, current);

    if (failed > 0) {
      setStatusLine(`Upload paused. ${failed} chunks failed and can be resumed.`);
      setSession(await getStatus(current.fileId));
      return;
    }

    setStatusLine("Finalizing upload object...");
    try {
      await apiRequest(`/api/uploads/${current.fileId}/finalize`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ expectedChecksum: "" }),
      });
    } catch (err) {
      const message = messageOf(err).toLowerCase();
      const canRecover = message.includes("missing chunk") || message.includes("cannot finalize upload with missing chunks");
      if (canRecover && recoveryAttempt < 2) {
        setStatusLine("Detected missing chunk object. Re-syncing and retrying...");
        const refreshed = await getStatus(current.fileId);
        await uploadAndFinalize(selected, refreshed, recoveryAttempt + 1);
        return;
      }
      throw err;
    }

    const finalized = await getStatus(current.fileId);
    setSession(finalized);
    setProgress(100);
    setStatusLine("Upload completed successfully.");
    clearRememberedSession(selected);
  }

  async function uploadMissingChunks(selected: File, current: UploadStatus): Promise<number> {
    const received = new Set<number>(current.receivedIndices);
    const queue: number[] = [];

    for (let i = 0; i < current.totalChunks; i += 1) {
      if (!received.has(i)) {
        queue.push(i);
      }
    }

    if (queue.length === 0) {
      return 0;
    }

    let done = current.receivedChunks;
    let failed = 0;

    const worker = async () => {
      while (queue.length > 0) {
        const idx = queue.shift();
        if (idx === undefined) {
          return;
        }

        try {
          await uploadChunk(selected, current.fileId, idx);
          done += 1;
          setUploadedChunks(done);
          setProgress(Math.round((done / current.totalChunks) * 100));
        } catch {
          failed += 1;
          setFailedChunks((v) => v + 1);
        }
      }
    };

    const workers = Array.from({ length: Math.min(PARALLEL_WORKERS, queue.length) }, () => worker());
    await Promise.all(workers);
    return failed;
  }

  async function uploadChunk(selected: File, fileId: string, index: number): Promise<void> {
    const start = index * CHUNK_SIZE;
    const end = Math.min(start + CHUNK_SIZE, selected.size);
    const blob = selected.slice(start, end);

    const checksum = await sha256Hex(await blob.arrayBuffer());
    await apiRequest(`/api/uploads/${fileId}/chunks/${index}`, {
      method: "PUT",
      headers: { "X-Chunk-Checksum": checksum },
      body: blob,
    });
  }

  async function fetchStatus(fileId: string): Promise<UploadStatus> {
    return apiRequest<UploadStatus>(`/api/uploads/${fileId}/status`);
  }

  async function getStatus(fileId: string): Promise<UploadStatus> {
    const current = await fetchStatus(fileId);
    setSession(current);
    return current;
  }

  async function fetchRecent(limit = 12): Promise<UploadStatus[]> {
    const data = await apiRequest<SessionsResponse>(`/api/uploads/recent?limit=${limit}`);
    return data.sessions || [];
  }

  async function loadRecent(): Promise<void> {
    setRecent(await fetchRecent(12));
  }

  async function resolveResumableSession(selected: File): Promise<UploadStatus | null> {
    const rememberedSessionId = recallSession(selected);
    if (rememberedSessionId) {
      try {
        const remembered = await fetchStatus(rememberedSessionId);
        if (sessionMatchesFile(remembered, selected) && isResumableStatus(remembered.status)) {
          return remembered;
        }
        clearRememberedSession(selected);
      } catch {
        clearRememberedSession(selected);
      }
    }

    const sessions = await fetchRecent(RECENT_SCAN_LIMIT);
    const candidate = sessions.find((item) => sessionMatchesFile(item, selected) && isResumableStatus(item.status));
    if (!candidate) {
      return null;
    }

    rememberSession(selected, candidate.fileId);
    return candidate;
  }

  return (
    <main className="page">
      <section className="hero">
        <p className="eyebrow">Distributed Upload Control Plane</p>
        <h1>Resumable 8 MB Chunk Uploads</h1>
        <p>Parallel chunks, resume-safe state, and final object assembly over S3-compatible storage.</p>
      </section>

      <section className="panelGrid">
        <article className="panel primary">
          <h2>Upload Console</h2>
          <label className="fileInputWrap" htmlFor="pick-file">
            <span>Select File</span>
            <input id="pick-file" type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          </label>
          <p className="selectedFile">{selectedLabel}</p>

          <div className="buttonRow">
            <button disabled={busy || !file} onClick={() => void startUpload()}>Start Upload</button>
            <button disabled={busy || !file} onClick={() => void resumeUpload()}>Resume Upload</button>
            <button className="ghost" onClick={() => void loadRecent()}>Refresh Sessions</button>
          </div>

          <div className="progressWrap">
            <div className="progressTrack"><div className="progressFill" style={{ width: `${progress}%` }} /></div>
            <p>{progress}% complete</p>
          </div>

          <div className="metrics">
            <div><strong>{uploadedChunks}</strong><span>Uploaded chunks</span></div>
            <div><strong>{failedChunks}</strong><span>Failed chunks</span></div>
            <div><strong>{session?.totalChunks || 0}</strong><span>Total chunks</span></div>
          </div>

          <p className="statusLine">{statusLine}</p>
          {errorLine ? <p className="errorLine">{errorLine}</p> : null}
        </article>

        <article className="panel secondary">
          <h2>Active Session</h2>
          {session ? (
            <dl className="sessionGrid">
              <div><dt>File ID</dt><dd>{session.fileId}</dd></div>
              <div><dt>Status</dt><dd>{session.status}</dd></div>
              <div><dt>Received Chunks</dt><dd>{session.receivedChunks}/{session.totalChunks}</dd></div>
              <div><dt>Final Object</dt><dd>{session.finalObjectKey || "not finalized"}</dd></div>
              <div><dt>Created</dt><dd>{new Date(session.createdAt).toLocaleString()}</dd></div>
              <div><dt>Updated</dt><dd>{new Date(session.updatedAt).toLocaleString()}</dd></div>
            </dl>
          ) : (
            <p className="muted">No active session.</p>
          )}
        </article>
      </section>

      <section className="panel recent">
        <h2>Recent Uploads</h2>
        {recent.length === 0 ? (
          <p className="muted">No uploads yet.</p>
        ) : (
          <div className="recentList">
            {recent.map((item) => {
              const pct = Math.round((item.receivedChunks / Math.max(item.totalChunks, 1)) * 100);
              return (
                <article className="recentCard" key={item.fileId}>
                  <header>
                    <h3>{item.filename}</h3>
                    <span className={`statusBadge status-${item.status}`}>{item.status}</span>
                  </header>
                  <p className="meta">{item.fileId}</p>
                  <p className="meta">{item.receivedChunks}/{item.totalChunks} chunks ({pct}%)</p>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </main>
  );
}

async function apiRequest<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, init);
  if (!res.ok) {
    let message = `Request failed with status ${res.status}`;
    try {
      const payload = (await res.json()) as { error?: string };
      if (payload.error) {
        message = payload.error;
      }
    } catch {
      // ignored
    }
    throw new Error(message);
  }

  return (await res.json()) as T;
}

async function sha256Hex(buffer: ArrayBuffer): Promise<string> {
  const hashBuffer = await crypto.subtle.digest("SHA-256", buffer);
  return Array.from(new Uint8Array(hashBuffer))
    .map((v) => v.toString(16).padStart(2, "0"))
    .join("");
}

function fileKey(file: File): string {
  return `${SESSION_KEY_PREFIX}:${file.name}:${file.size}`;
}

function legacyFileKey(file: File): string {
  return `${SESSION_KEY_PREFIX}:${file.name}:${file.size}:${file.lastModified}`;
}

function rememberSession(file: File, fileId: string): void {
  localStorage.setItem(fileKey(file), fileId);
  localStorage.setItem(legacyFileKey(file), fileId);
}

function recallSession(file: File): string | null {
  return localStorage.getItem(fileKey(file)) || localStorage.getItem(legacyFileKey(file));
}

function clearRememberedSession(file: File): void {
  localStorage.removeItem(fileKey(file));
  localStorage.removeItem(legacyFileKey(file));
}

function sessionMatchesFile(session: UploadStatus, file: File): boolean {
  return session.filename === file.name && session.totalSize === file.size;
}

function isResumableStatus(status: string): boolean {
  const normalized = status.toLowerCase();
  return normalized === "initialized" || normalized === "uploading" || normalized === "finalizing" || normalized === "checksum_failed";
}

function messageOf(value: unknown): string {
  return value instanceof Error ? value.message : "Unexpected error";
}
