import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Distributed Chunk Upload Console",
  description: "Resumable 8 MB chunk uploader backed by Go, gRPC, Redis, and S3-compatible storage.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
