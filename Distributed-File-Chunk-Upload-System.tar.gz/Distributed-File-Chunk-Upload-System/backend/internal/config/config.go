package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

const RequiredChunkSize int64 = 8 * 1024 * 1024

type Config struct {
	GRPCAddr             string
	HTTPAddr             string
	RedisAddr            string
	RedisPassword        string
	RedisDB              int
	S3Endpoint           string
	S3AccessKey          string
	S3SecretKey          string
	S3Bucket             string
	S3Region             string
	S3UseSSL             bool
	ChunkSize            int64
	UploadTimeout        time.Duration
	MaxConcurrentUploads int
	AllowedOrigins       []string
	LogLevel             string
}

func Load() (*Config, error) {
	cfg := &Config{
		GRPCAddr:             getEnv("GRPC_ADDR", ":50051"),
		HTTPAddr:             getEnv("HTTP_ADDR", ":8080"),
		RedisAddr:            getEnv("REDIS_ADDR", "redis:6379"),
		RedisPassword:        getEnv("REDIS_PASSWORD", ""),
		RedisDB:              getEnvInt("REDIS_DB", 0),
		S3Endpoint:           getEnv("S3_ENDPOINT", "http://minio:9000"),
		S3AccessKey:          getEnv("S3_ACCESS_KEY", "minioadmin"),
		S3SecretKey:          getEnv("S3_SECRET_KEY", "minioadmin"),
		S3Bucket:             getEnv("S3_BUCKET", "uploads"),
		S3Region:             getEnv("S3_REGION", "us-east-1"),
		S3UseSSL:             getEnvBool("S3_USE_SSL", false),
		ChunkSize:            getEnvInt64("CHUNK_SIZE", RequiredChunkSize),
		UploadTimeout:        getEnvDuration("UPLOAD_TIMEOUT", 24*time.Hour),
		MaxConcurrentUploads: getEnvInt("MAX_CONCURRENT_UPLOADS", 32),
		AllowedOrigins:       splitCSV(getEnv("ALLOWED_ORIGINS", "*")),
		LogLevel:             strings.ToLower(getEnv("LOG_LEVEL", "info")),
	}

	if cfg.ChunkSize != RequiredChunkSize {
		return nil, fmt.Errorf("CHUNK_SIZE must be %d (8 MB), got %d", RequiredChunkSize, cfg.ChunkSize)
	}
	if cfg.RedisAddr == "" {
		return nil, fmt.Errorf("REDIS_ADDR is required")
	}
	if cfg.S3Endpoint == "" {
		return nil, fmt.Errorf("S3_ENDPOINT is required")
	}
	if cfg.S3AccessKey == "" || cfg.S3SecretKey == "" {
		return nil, fmt.Errorf("S3_ACCESS_KEY and S3_SECRET_KEY are required")
	}
	if cfg.S3Bucket == "" {
		return nil, fmt.Errorf("S3_BUCKET is required")
	}
	if cfg.MaxConcurrentUploads < 1 {
		return nil, fmt.Errorf("MAX_CONCURRENT_UPLOADS must be >= 1")
	}

	return cfg, nil
}

func getEnv(key, fallback string) string {
	if v, ok := os.LookupEnv(key); ok {
		return strings.TrimSpace(v)
	}
	return fallback
}

func getEnvInt(key string, fallback int) int {
	raw := getEnv(key, "")
	if raw == "" {
		return fallback
	}
	parsed, err := strconv.Atoi(raw)
	if err != nil {
		return fallback
	}
	return parsed
}

func getEnvInt64(key string, fallback int64) int64 {
	raw := getEnv(key, "")
	if raw == "" {
		return fallback
	}
	parsed, err := strconv.ParseInt(raw, 10, 64)
	if err != nil {
		return fallback
	}
	return parsed
}

func getEnvBool(key string, fallback bool) bool {
	raw := getEnv(key, "")
	if raw == "" {
		return fallback
	}
	parsed, err := strconv.ParseBool(raw)
	if err != nil {
		return fallback
	}
	return parsed
}

func getEnvDuration(key string, fallback time.Duration) time.Duration {
	raw := getEnv(key, "")
	if raw == "" {
		return fallback
	}
	parsed, err := time.ParseDuration(raw)
	if err != nil {
		return fallback
	}
	return parsed
}

func splitCSV(raw string) []string {
	parts := strings.Split(raw, ",")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		trimmed := strings.TrimSpace(part)
		if trimmed != "" {
			out = append(out, trimmed)
		}
	}
	if len(out) == 0 {
		return []string{"*"}
	}
	return out
}
