package storage

import (
	"context"
	"fmt"
	"io"
	"net/url"
	"strings"

	"github.com/example/uile-fpload/backend/internal/config"
	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

type Client interface {
	EnsureBucket(ctx context.Context) error
	PutObject(ctx context.Context, key string, data io.Reader, size int64, contentType string, metadata map[string]string) error
	GetObject(ctx context.Context, key string) (io.ReadCloser, error)
	ListObjects(ctx context.Context, prefix string) ([]string, error)
	DeleteObject(ctx context.Context, key string) error
	DeleteObjects(ctx context.Context, keys []string) error
}

type S3Client struct {
	client *minio.Client
	bucket string
	region string
}

func NewS3Client(cfg *config.Config) (*S3Client, error) {
	endpoint, secure, err := normalizeEndpoint(cfg.S3Endpoint, cfg.S3UseSSL)
	if err != nil {
		return nil, err
	}

	minioClient, err := minio.New(endpoint, &minio.Options{
		Creds:        credentials.NewStaticV4(cfg.S3AccessKey, cfg.S3SecretKey, ""),
		Secure:       secure,
		Region:       cfg.S3Region,
		BucketLookup: minio.BucketLookupPath,
	})
	if err != nil {
		return nil, fmt.Errorf("create s3 client: %w", err)
	}

	return &S3Client{
		client: minioClient,
		bucket: cfg.S3Bucket,
		region: cfg.S3Region,
	}, nil
}

func (c *S3Client) EnsureBucket(ctx context.Context) error {
	exists, err := c.client.BucketExists(ctx, c.bucket)
	if err != nil {
		return fmt.Errorf("check bucket exists: %w", err)
	}
	if exists {
		return nil
	}

	if err := c.client.MakeBucket(ctx, c.bucket, minio.MakeBucketOptions{Region: c.region}); err != nil {
		return fmt.Errorf("make bucket: %w", err)
	}
	return nil
}

func (c *S3Client) PutObject(ctx context.Context, key string, data io.Reader, size int64, contentType string, metadata map[string]string) error {
	options := minio.PutObjectOptions{
		ContentType:  contentType,
		UserMetadata: metadata,
	}
	if contentType == "" {
		options.ContentType = "application/octet-stream"
	}

	if _, err := c.client.PutObject(ctx, c.bucket, key, data, size, options); err != nil {
		return fmt.Errorf("put object %q: %w", key, err)
	}
	return nil
}

func (c *S3Client) GetObject(ctx context.Context, key string) (io.ReadCloser, error) {
	object, err := c.client.GetObject(ctx, c.bucket, key, minio.GetObjectOptions{})
	if err != nil {
		return nil, fmt.Errorf("get object %q: %w", key, err)
	}

	if _, err := object.Stat(); err != nil {
		_ = object.Close()
		return nil, fmt.Errorf("stat object %q: %w", key, err)
	}

	return object, nil
}

func (c *S3Client) ListObjects(ctx context.Context, prefix string) ([]string, error) {
	objectsCh := c.client.ListObjects(ctx, c.bucket, minio.ListObjectsOptions{
		Prefix:    prefix,
		Recursive: true,
	})

	keys := make([]string, 0)
	for obj := range objectsCh {
		if obj.Err != nil {
			return nil, fmt.Errorf("list objects with prefix %q: %w", prefix, obj.Err)
		}
		keys = append(keys, obj.Key)
	}
	return keys, nil
}

func (c *S3Client) DeleteObject(ctx context.Context, key string) error {
	if err := c.client.RemoveObject(ctx, c.bucket, key, minio.RemoveObjectOptions{}); err != nil {
		return fmt.Errorf("delete object %q: %w", key, err)
	}
	return nil
}

func (c *S3Client) DeleteObjects(ctx context.Context, keys []string) error {
	if len(keys) == 0 {
		return nil
	}

	objectsCh := make(chan minio.ObjectInfo)
	go func() {
		defer close(objectsCh)
		for _, key := range keys {
			objectsCh <- minio.ObjectInfo{Key: key}
		}
	}()

	errorsCh := c.client.RemoveObjects(ctx, c.bucket, objectsCh, minio.RemoveObjectsOptions{})
	var allErrs []string
	for removeErr := range errorsCh {
		allErrs = append(allErrs, removeErr.Err.Error())
	}

	if len(allErrs) > 0 {
		return fmt.Errorf("delete objects: %s", strings.Join(allErrs, "; "))
	}
	return nil
}

func normalizeEndpoint(endpoint string, fallbackSecure bool) (string, bool, error) {
	endpoint = strings.TrimSpace(endpoint)
	if endpoint == "" {
		return "", false, fmt.Errorf("S3 endpoint is empty")
	}

	if strings.HasPrefix(endpoint, "http://") || strings.HasPrefix(endpoint, "https://") {
		parsed, err := url.Parse(endpoint)
		if err != nil {
			return "", false, fmt.Errorf("parse S3_ENDPOINT: %w", err)
		}
		return parsed.Host, parsed.Scheme == "https", nil
	}

	return endpoint, fallbackSecure, nil
}
