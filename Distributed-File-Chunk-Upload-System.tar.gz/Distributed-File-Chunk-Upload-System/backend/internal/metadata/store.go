package metadata

import (
	"context"
	"errors"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
)

const (
	StatusInitialized    = "initialized"
	StatusUploading      = "uploading"
	StatusFinalizing     = "finalizing"
	StatusCompleted      = "completed"
	StatusAborted        = "aborted"
	StatusChecksumFailed = "checksum_failed"

	recentUploadsKey = "uploads:recent"
)

var (
	ErrSessionNotFound           = errors.New("upload session not found")
	ErrDuplicateChecksumMismatch = errors.New("duplicate chunk checksum mismatch")
)

type Session struct {
	FileID         string
	Filename       string
	ContentType    string
	TotalSize      int64
	ChunkSize      int64
	TotalChunks    int
	ReceivedCount  int
	Status         string
	FileChecksum   string
	FinalObjectKey string
	FinalChecksum  string
	AbortReason    string
	CreatedAt      time.Time
	UpdatedAt      time.Time
}

type ChunkMarkResult struct {
	Accepted  bool
	Duplicate bool
}

type Store interface {
	CreateSession(ctx context.Context, session Session) error
	GetSession(ctx context.Context, fileID string) (Session, error)
	MarkChunkReceived(ctx context.Context, fileID string, chunkIndex int, chunkChecksum string) (ChunkMarkResult, error)
	UnmarkChunk(ctx context.Context, fileID string, chunkIndex int) error
	GetReceivedIndices(ctx context.Context, fileID string) ([]int, error)
	SetStatus(ctx context.Context, fileID string, status string) error
	SetCompleted(ctx context.Context, fileID string, finalObjectKey string, finalChecksum string) error
	SetAborted(ctx context.Context, fileID string, reason string) error
	SetChecksumFailed(ctx context.Context, fileID string) error
	DeleteChunkState(ctx context.Context, fileID string) error
	ListRecentSessions(ctx context.Context, limit int) ([]Session, error)
	ScanStaleSessions(ctx context.Context, olderThan time.Time, limit int) ([]Session, error)
	AcquireFinalizeLock(ctx context.Context, fileID string, ttl time.Duration) (bool, error)
	ReleaseFinalizeLock(ctx context.Context, fileID string) error
	Close() error
}

type RedisStore struct {
	client *redis.Client
}

func NewRedisStore(addr, password string, db int) (*RedisStore, error) {
	client := redis.NewClient(&redis.Options{
		Addr:         addr,
		Password:     password,
		DB:           db,
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 5 * time.Second,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := client.Ping(ctx).Err(); err != nil {
		return nil, fmt.Errorf("ping redis: %w", err)
	}

	return &RedisStore{client: client}, nil
}

func (s *RedisStore) CreateSession(ctx context.Context, session Session) error {
	now := time.Now().UTC().Unix()
	createdAt := session.CreatedAt.UTC().Unix()
	if createdAt == 0 {
		createdAt = now
	}

	meta := map[string]any{
		"file_id":         session.FileID,
		"filename":        session.Filename,
		"content_type":    session.ContentType,
		"total_size":      session.TotalSize,
		"chunk_size":      session.ChunkSize,
		"total_chunks":    session.TotalChunks,
		"received_count":  0,
		"status":          StatusInitialized,
		"file_checksum":   session.FileChecksum,
		"created_at_unix": createdAt,
		"updated_at_unix": now,
	}

	pipe := s.client.TxPipeline()
	pipe.HSet(ctx, metaKey(session.FileID), meta)
	pipe.LRem(ctx, recentUploadsKey, 0, session.FileID)
	pipe.LPush(ctx, recentUploadsKey, session.FileID)
	pipe.LTrim(ctx, recentUploadsKey, 0, 199)

	if _, err := pipe.Exec(ctx); err != nil {
		return fmt.Errorf("create session in redis: %w", err)
	}
	return nil
}

func (s *RedisStore) GetSession(ctx context.Context, fileID string) (Session, error) {
	raw, err := s.client.HGetAll(ctx, metaKey(fileID)).Result()
	if err != nil {
		return Session{}, fmt.Errorf("get session: %w", err)
	}
	if len(raw) == 0 {
		return Session{}, ErrSessionNotFound
	}

	session, err := parseSession(raw)
	if err != nil {
		return Session{}, err
	}
	return session, nil
}

func (s *RedisStore) MarkChunkReceived(ctx context.Context, fileID string, chunkIndex int, chunkChecksum string) (ChunkMarkResult, error) {
	idxField := strconv.Itoa(chunkIndex)
	added, err := s.client.SAdd(ctx, receivedKey(fileID), idxField).Result()
	if err != nil {
		return ChunkMarkResult{}, fmt.Errorf("sadd received chunk: %w", err)
	}

	if added == 0 {
		existingChecksum, getErr := s.client.HGet(ctx, chunkChecksumKey(fileID), idxField).Result()
		if getErr != nil && !errors.Is(getErr, redis.Nil) {
			return ChunkMarkResult{}, fmt.Errorf("get existing chunk checksum: %w", getErr)
		}
		if existingChecksum != "" && chunkChecksum != "" && !strings.EqualFold(existingChecksum, chunkChecksum) {
			return ChunkMarkResult{}, ErrDuplicateChecksumMismatch
		}
		if err := s.touchSession(ctx, fileID); err != nil {
			return ChunkMarkResult{}, err
		}
		return ChunkMarkResult{Accepted: false, Duplicate: true}, nil
	}

	now := time.Now().UTC().Unix()
	pipe := s.client.TxPipeline()
	pipe.HSet(ctx, chunkChecksumKey(fileID), idxField, strings.ToLower(chunkChecksum))
	pipe.HIncrBy(ctx, metaKey(fileID), "received_count", 1)
	pipe.HSet(ctx, metaKey(fileID), "updated_at_unix", now)
	if _, err := pipe.Exec(ctx); err != nil {
		_ = s.client.SRem(ctx, receivedKey(fileID), idxField).Err()
		return ChunkMarkResult{}, fmt.Errorf("commit chunk metadata: %w", err)
	}

	return ChunkMarkResult{Accepted: true, Duplicate: false}, nil
}

func (s *RedisStore) UnmarkChunk(ctx context.Context, fileID string, chunkIndex int) error {
	idxField := strconv.Itoa(chunkIndex)
	pipe := s.client.TxPipeline()
	pipe.SRem(ctx, receivedKey(fileID), idxField)
	pipe.HDel(ctx, chunkChecksumKey(fileID), idxField)
	pipe.HIncrBy(ctx, metaKey(fileID), "received_count", -1)
	pipe.HSet(ctx, metaKey(fileID), "updated_at_unix", time.Now().UTC().Unix())
	if _, err := pipe.Exec(ctx); err != nil {
		return fmt.Errorf("unmark chunk: %w", err)
	}
	return nil
}

func (s *RedisStore) GetReceivedIndices(ctx context.Context, fileID string) ([]int, error) {
	rawIndices, err := s.client.SMembers(ctx, receivedKey(fileID)).Result()
	if err != nil {
		return nil, fmt.Errorf("read received chunk set: %w", err)
	}

	indices := make([]int, 0, len(rawIndices))
	for _, raw := range rawIndices {
		idx, convErr := strconv.Atoi(raw)
		if convErr != nil {
			continue
		}
		indices = append(indices, idx)
	}

	sort.Ints(indices)
	return indices, nil
}

func (s *RedisStore) SetStatus(ctx context.Context, fileID string, status string) error {
	return s.client.HSet(ctx, metaKey(fileID),
		"status", status,
		"updated_at_unix", time.Now().UTC().Unix(),
	).Err()
}

func (s *RedisStore) SetCompleted(ctx context.Context, fileID string, finalObjectKey string, finalChecksum string) error {
	now := time.Now().UTC().Unix()
	return s.client.HSet(ctx, metaKey(fileID),
		"status", StatusCompleted,
		"final_object_key", finalObjectKey,
		"final_checksum", strings.ToLower(finalChecksum),
		"completed_at_unix", now,
		"updated_at_unix", now,
	).Err()
}

func (s *RedisStore) SetAborted(ctx context.Context, fileID string, reason string) error {
	now := time.Now().UTC().Unix()
	return s.client.HSet(ctx, metaKey(fileID),
		"status", StatusAborted,
		"abort_reason", reason,
		"aborted_at_unix", now,
		"updated_at_unix", now,
	).Err()
}

func (s *RedisStore) SetChecksumFailed(ctx context.Context, fileID string) error {
	return s.client.HSet(ctx, metaKey(fileID),
		"status", StatusChecksumFailed,
		"updated_at_unix", time.Now().UTC().Unix(),
	).Err()
}

func (s *RedisStore) DeleteChunkState(ctx context.Context, fileID string) error {
	if err := s.client.Del(ctx, receivedKey(fileID), chunkChecksumKey(fileID)).Err(); err != nil {
		return fmt.Errorf("delete chunk state: %w", err)
	}
	return nil
}

func (s *RedisStore) ListRecentSessions(ctx context.Context, limit int) ([]Session, error) {
	if limit <= 0 {
		limit = 10
	}

	ids, err := s.client.LRange(ctx, recentUploadsKey, 0, int64(limit-1)).Result()
	if err != nil {
		return nil, fmt.Errorf("list recent upload ids: %w", err)
	}

	sessions := make([]Session, 0, len(ids))
	for _, id := range ids {
		session, getErr := s.GetSession(ctx, id)
		if getErr == nil {
			sessions = append(sessions, session)
		}
	}
	return sessions, nil
}

func (s *RedisStore) ScanStaleSessions(ctx context.Context, olderThan time.Time, limit int) ([]Session, error) {
	if limit <= 0 {
		limit = 50
	}

	stale := make([]Session, 0, limit)
	var cursor uint64
	for {
		keys, nextCursor, err := s.client.Scan(ctx, cursor, "upload:meta:*", 100).Result()
		if err != nil {
			return nil, fmt.Errorf("scan sessions: %w", err)
		}
		cursor = nextCursor

		for _, key := range keys {
			fileID := strings.TrimPrefix(key, "upload:meta:")
			session, getErr := s.GetSession(ctx, fileID)
			if getErr != nil {
				continue
			}
			if session.Status == StatusCompleted || session.Status == StatusAborted {
				continue
			}
			if session.UpdatedAt.Before(olderThan) {
				stale = append(stale, session)
				if len(stale) >= limit {
					return stale, nil
				}
			}
		}

		if cursor == 0 {
			break
		}
	}

	return stale, nil
}

func (s *RedisStore) AcquireFinalizeLock(ctx context.Context, fileID string, ttl time.Duration) (bool, error) {
	ok, err := s.client.SetNX(ctx, finalizeLockKey(fileID), "1", ttl).Result()
	if err != nil {
		return false, fmt.Errorf("acquire finalize lock: %w", err)
	}
	return ok, nil
}

func (s *RedisStore) ReleaseFinalizeLock(ctx context.Context, fileID string) error {
	return s.client.Del(ctx, finalizeLockKey(fileID)).Err()
}

func (s *RedisStore) Close() error {
	return s.client.Close()
}

func (s *RedisStore) touchSession(ctx context.Context, fileID string) error {
	return s.client.HSet(ctx, metaKey(fileID), "updated_at_unix", time.Now().UTC().Unix()).Err()
}

func parseSession(raw map[string]string) (Session, error) {
	totalSize, err := strconv.ParseInt(raw["total_size"], 10, 64)
	if err != nil {
		return Session{}, fmt.Errorf("parse total_size: %w", err)
	}

	chunkSize, err := strconv.ParseInt(raw["chunk_size"], 10, 64)
	if err != nil {
		return Session{}, fmt.Errorf("parse chunk_size: %w", err)
	}

	totalChunks, err := strconv.Atoi(raw["total_chunks"])
	if err != nil {
		return Session{}, fmt.Errorf("parse total_chunks: %w", err)
	}

	receivedCount, err := strconv.Atoi(raw["received_count"])
	if err != nil {
		return Session{}, fmt.Errorf("parse received_count: %w", err)
	}

	createdAtUnix, err := strconv.ParseInt(raw["created_at_unix"], 10, 64)
	if err != nil {
		return Session{}, fmt.Errorf("parse created_at_unix: %w", err)
	}

	updatedAtUnix, err := strconv.ParseInt(raw["updated_at_unix"], 10, 64)
	if err != nil {
		return Session{}, fmt.Errorf("parse updated_at_unix: %w", err)
	}

	return Session{
		FileID:         raw["file_id"],
		Filename:       raw["filename"],
		ContentType:    raw["content_type"],
		TotalSize:      totalSize,
		ChunkSize:      chunkSize,
		TotalChunks:    totalChunks,
		ReceivedCount:  receivedCount,
		Status:         raw["status"],
		FileChecksum:   raw["file_checksum"],
		FinalObjectKey: raw["final_object_key"],
		FinalChecksum:  raw["final_checksum"],
		AbortReason:    raw["abort_reason"],
		CreatedAt:      time.Unix(createdAtUnix, 0).UTC(),
		UpdatedAt:      time.Unix(updatedAtUnix, 0).UTC(),
	}, nil
}

func metaKey(fileID string) string {
	return "upload:meta:" + fileID
}

func receivedKey(fileID string) string {
	return "upload:received:" + fileID
}

func chunkChecksumKey(fileID string) string {
	return "upload:chunk-checksum:" + fileID
}

func finalizeLockKey(fileID string) string {
	return "upload:finalize-lock:" + fileID
}
