package grpcserver

import (
	"context"
	"errors"
	"fmt"
	"io"

	uploadv1 "github.com/example/uile-fpload/backend/api/proto/upload/v1"
	"github.com/example/uile-fpload/backend/internal/metadata"
	"github.com/example/uile-fpload/backend/internal/service"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

type Server struct {
	uploadv1.UnimplementedUploadServiceServer
	service *service.UploadService
}

func New(svc *service.UploadService) *Server {
	return &Server{service: svc}
}

func (s *Server) InitUpload(ctx context.Context, req *uploadv1.InitUploadRequest) (*uploadv1.InitUploadResponse, error) {
	result, err := s.service.InitUpload(ctx, service.InitUploadInput{
		Filename:     req.GetFilename(),
		TotalSize:    req.GetTotalSize(),
		ContentType:  req.GetContentType(),
		FileChecksum: req.GetFileChecksum(),
	})
	if err != nil {
		return nil, toGRPCError(err)
	}

	return &uploadv1.InitUploadResponse{
		FileId:        result.FileID,
		TotalChunks:   int32(result.TotalChunks),
		ChunkSize:     result.ChunkSize,
		Status:        result.Status,
		CreatedAtUnix: result.CreatedAt.Unix(),
	}, nil
}

func (s *Server) Upload(stream uploadv1.UploadService_UploadServer) error {
	var accepted int32
	duplicates := make([]int32, 0)
	streamErrors := make([]string, 0)
	fileID := ""

	for {
		req, err := stream.Recv()
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil {
			return status.Errorf(codes.Internal, "receive stream: %v", err)
		}

		chunk := req.GetChunk()
		if chunk == nil {
			streamErrors = append(streamErrors, "received empty chunk message")
			continue
		}

		fileID = chunk.GetFileId()
		result, uploadErr := s.service.UploadChunk(stream.Context(), service.UploadChunkInput{
			FileID:      chunk.GetFileId(),
			ChunkIndex:  int(chunk.GetChunkIndex()),
			Data:        chunk.GetData(),
			ChecksumHex: chunk.GetChecksum(),
		})
		if uploadErr != nil {
			streamErrors = append(streamErrors, fmt.Sprintf("chunk %d failed: %v", chunk.GetChunkIndex(), uploadErr))
			continue
		}

		if result.Duplicate {
			duplicates = append(duplicates, int32(result.ChunkIndex))
			continue
		}

		accepted++
	}

	return stream.SendAndClose(&uploadv1.UploadResponse{
		FileId:          fileID,
		AcceptedChunks:  accepted,
		DuplicateChunks: duplicates,
		Errors:          streamErrors,
	})
}

func (s *Server) GetStatus(ctx context.Context, req *uploadv1.UploadStatusRequest) (*uploadv1.UploadStatusResponse, error) {
	statusResult, err := s.service.GetStatus(ctx, req.GetFileId())
	if err != nil {
		return nil, toGRPCError(err)
	}

	return &uploadv1.UploadStatusResponse{
		FileId:          statusResult.FileID,
		Filename:        statusResult.Filename,
		ContentType:     statusResult.ContentType,
		TotalSize:       statusResult.TotalSize,
		ChunkSize:       statusResult.ChunkSize,
		TotalChunks:     int32(statusResult.TotalChunks),
		ReceivedChunks:  int32(statusResult.ReceivedChunks),
		ReceivedIndices: toInt32Slice(statusResult.ReceivedIndices),
		Status:          statusResult.Status,
		FileChecksum:    statusResult.FileChecksum,
		CreatedAtUnix:   statusResult.CreatedAt.Unix(),
		UpdatedAtUnix:   statusResult.UpdatedAt.Unix(),
		CanFinalize:     statusResult.CanFinalize,
	}, nil
}

func (s *Server) FinalizeUpload(ctx context.Context, req *uploadv1.FinalizeUploadRequest) (*uploadv1.FinalizeUploadResponse, error) {
	result, err := s.service.FinalizeUpload(ctx, service.FinalizeUploadInput{
		FileID:           req.GetFileId(),
		ExpectedChecksum: req.GetExpectedChecksum(),
	})
	if err != nil {
		return nil, toGRPCError(err)
	}

	return &uploadv1.FinalizeUploadResponse{
		FileId:          result.FileID,
		Status:          result.Status,
		ObjectKey:       result.ObjectKey,
		Checksum:        result.Checksum,
		CompletedAtUnix: result.CompletedAt.Unix(),
	}, nil
}

func (s *Server) AbortUpload(ctx context.Context, req *uploadv1.AbortUploadRequest) (*uploadv1.AbortUploadResponse, error) {
	result, err := s.service.AbortUpload(ctx, service.AbortUploadInput{
		FileID: req.GetFileId(),
		Reason: req.GetReason(),
	})
	if err != nil {
		return nil, toGRPCError(err)
	}

	return &uploadv1.AbortUploadResponse{
		FileId:        result.FileID,
		Status:        result.Status,
		AbortedAtUnix: result.AbortedAt.Unix(),
	}, nil
}

func (s *Server) ListRecentUploads(ctx context.Context, req *uploadv1.ListRecentUploadsRequest) (*uploadv1.ListRecentUploadsResponse, error) {
	sessions, err := s.service.ListRecentUploads(ctx, int(req.GetLimit()))
	if err != nil {
		return nil, toGRPCError(err)
	}

	out := make([]*uploadv1.UploadStatusResponse, 0, len(sessions))
	for _, session := range sessions {
		out = append(out, &uploadv1.UploadStatusResponse{
			FileId:          session.FileID,
			Filename:        session.Filename,
			ContentType:     session.ContentType,
			TotalSize:       session.TotalSize,
			ChunkSize:       session.ChunkSize,
			TotalChunks:     int32(session.TotalChunks),
			ReceivedChunks:  int32(session.ReceivedChunks),
			ReceivedIndices: toInt32Slice(session.ReceivedIndices),
			Status:          session.Status,
			FileChecksum:    session.FileChecksum,
			CreatedAtUnix:   session.CreatedAt.Unix(),
			UpdatedAtUnix:   session.UpdatedAt.Unix(),
			CanFinalize:     session.CanFinalize,
		})
	}

	return &uploadv1.ListRecentUploadsResponse{Sessions: out}, nil
}

func toGRPCError(err error) error {
	switch {
	case errors.Is(err, metadata.ErrSessionNotFound):
		return status.Error(codes.NotFound, err.Error())
	case errors.Is(err, service.ErrInvalidArgument):
		return status.Error(codes.InvalidArgument, err.Error())
	case errors.Is(err, service.ErrMissingChunks),
		errors.Is(err, service.ErrUploadAborted),
		errors.Is(err, service.ErrUploadCompleted),
		errors.Is(err, service.ErrUploadFinalizing),
		errors.Is(err, service.ErrFinalizeInProgress):
		return status.Error(codes.FailedPrecondition, err.Error())
	case errors.Is(err, service.ErrChecksumMismatch),
		errors.Is(err, metadata.ErrDuplicateChecksumMismatch):
		return status.Error(codes.InvalidArgument, err.Error())
	default:
		return status.Error(codes.Internal, err.Error())
	}
}

func toInt32Slice(values []int) []int32 {
	out := make([]int32, 0, len(values))
	for _, value := range values {
		out = append(out, int32(value))
	}
	return out
}
