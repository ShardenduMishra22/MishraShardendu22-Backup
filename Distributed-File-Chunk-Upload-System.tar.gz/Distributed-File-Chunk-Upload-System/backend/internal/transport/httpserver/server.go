package httpserver

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"strconv"
	"strings"

	"github.com/example/uile-fpload/backend/internal/config"
	"github.com/example/uile-fpload/backend/internal/metadata"
	"github.com/example/uile-fpload/backend/internal/service"
	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
)

type Server struct {
	service        *service.UploadService
	allowedOrigins []string
	logger         *slog.Logger
}

func New(svc *service.UploadService, cfg *config.Config, logger *slog.Logger) http.Handler {
	if logger == nil {
		logger = slog.Default()
	}

	s := &Server{
		service:        svc,
		allowedOrigins: cfg.AllowedOrigins,
		logger:         logger,
	}

	r := chi.NewRouter()
	r.Use(middleware.RequestID)
	r.Use(middleware.RealIP)
	r.Use(middleware.Recoverer)
	r.Use(s.corsMiddleware)

	r.Get("/healthz", s.handleHealth)

	r.Route("/api/uploads", func(r chi.Router) {
		r.Post("/init", s.handleInitUpload)
		r.Get("/recent", s.handleListRecentUploads)
		r.Get("/{fileID}/status", s.handleGetStatus)
		r.Put("/{fileID}/chunks/{chunkIndex}", s.handleUploadChunk)
		r.Post("/{fileID}/finalize", s.handleFinalizeUpload)
		r.Post("/{fileID}/abort", s.handleAbortUpload)
	})

	return r
}

type initUploadRequest struct {
	Filename     string `json:"filename"`
	TotalSize    int64  `json:"totalSize"`
	ContentType  string `json:"contentType"`
	FileChecksum string `json:"fileChecksum"`
}

type initUploadResponse struct {
	FileID      string `json:"fileId"`
	TotalChunks int    `json:"totalChunks"`
	ChunkSize   int64  `json:"chunkSize"`
	Status      string `json:"status"`
	CreatedAt   string `json:"createdAt"`
}

type chunkUploadResponse struct {
	FileID     string `json:"fileId"`
	ChunkIndex int    `json:"chunkIndex"`
	Accepted   bool   `json:"accepted"`
	Duplicate  bool   `json:"duplicate"`
}

type uploadStatusResponse struct {
	FileID          string `json:"fileId"`
	Filename        string `json:"filename"`
	ContentType     string `json:"contentType"`
	TotalSize       int64  `json:"totalSize"`
	ChunkSize       int64  `json:"chunkSize"`
	TotalChunks     int    `json:"totalChunks"`
	ReceivedChunks  int    `json:"receivedChunks"`
	ReceivedIndices []int  `json:"receivedIndices"`
	Status          string `json:"status"`
	FileChecksum    string `json:"fileChecksum"`
	FinalObjectKey  string `json:"finalObjectKey"`
	FinalChecksum   string `json:"finalChecksum"`
	CreatedAt       string `json:"createdAt"`
	UpdatedAt       string `json:"updatedAt"`
	CanFinalize     bool   `json:"canFinalize"`
}

type finalizeUploadRequest struct {
	ExpectedChecksum string `json:"expectedChecksum"`
}

type finalizeUploadResponse struct {
	FileID      string `json:"fileId"`
	Status      string `json:"status"`
	ObjectKey   string `json:"objectKey"`
	Checksum    string `json:"checksum"`
	CompletedAt string `json:"completedAt"`
}

type abortUploadRequest struct {
	Reason string `json:"reason"`
}

type abortUploadResponse struct {
	FileID    string `json:"fileId"`
	Status    string `json:"status"`
	AbortedAt string `json:"abortedAt"`
}

type errorResponse struct {
	Error string `json:"error"`
}

func (s *Server) handleHealth(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

func (s *Server) handleInitUpload(w http.ResponseWriter, r *http.Request) {
	var req initUploadRequest
	if err := decodeJSON(r, &req); err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}

	result, err := s.service.InitUpload(r.Context(), service.InitUploadInput{
		Filename:     req.Filename,
		TotalSize:    req.TotalSize,
		ContentType:  req.ContentType,
		FileChecksum: req.FileChecksum,
	})
	if err != nil {
		writeError(w, statusCodeForError(err), err)
		return
	}

	writeJSON(w, http.StatusCreated, initUploadResponse{
		FileID:      result.FileID,
		TotalChunks: result.TotalChunks,
		ChunkSize:   result.ChunkSize,
		Status:      result.Status,
		CreatedAt:   result.CreatedAt.UTC().Format(timeFormat),
	})
}

func (s *Server) handleUploadChunk(w http.ResponseWriter, r *http.Request) {
	fileID := strings.TrimSpace(chi.URLParam(r, "fileID"))
	chunkIndexRaw := chi.URLParam(r, "chunkIndex")

	chunkIndex, err := strconv.Atoi(chunkIndexRaw)
	if err != nil {
		writeError(w, http.StatusBadRequest, errors.New("chunkIndex must be an integer"))
		return
	}

	chunkChecksum := strings.TrimSpace(r.Header.Get("X-Chunk-Checksum"))
	if chunkChecksum == "" {
		writeError(w, http.StatusBadRequest, errors.New("X-Chunk-Checksum header is required"))
		return
	}

	body := io.LimitReader(r.Body, s.service.ChunkSize()+1)
	chunkData, err := io.ReadAll(body)
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}

	if int64(len(chunkData)) > s.service.ChunkSize() {
		writeError(w, http.StatusBadRequest, errors.New("chunk payload exceeds 8 MB"))
		return
	}

	result, err := s.service.UploadChunk(r.Context(), service.UploadChunkInput{
		FileID:      fileID,
		ChunkIndex:  chunkIndex,
		Data:        chunkData,
		ChecksumHex: chunkChecksum,
	})
	if err != nil {
		writeError(w, statusCodeForError(err), err)
		return
	}

	writeJSON(w, http.StatusOK, chunkUploadResponse{
		FileID:     result.FileID,
		ChunkIndex: result.ChunkIndex,
		Accepted:   result.Accepted,
		Duplicate:  result.Duplicate,
	})
}

func (s *Server) handleGetStatus(w http.ResponseWriter, r *http.Request) {
	fileID := strings.TrimSpace(chi.URLParam(r, "fileID"))

	statusResult, err := s.service.GetStatus(r.Context(), fileID)
	if err != nil {
		writeError(w, statusCodeForError(err), err)
		return
	}

	writeJSON(w, http.StatusOK, toUploadStatusResponse(*statusResult))
}

func (s *Server) handleFinalizeUpload(w http.ResponseWriter, r *http.Request) {
	fileID := strings.TrimSpace(chi.URLParam(r, "fileID"))

	var req finalizeUploadRequest
	if r.ContentLength > 0 {
		if err := decodeJSON(r, &req); err != nil {
			writeError(w, http.StatusBadRequest, err)
			return
		}
	}

	result, err := s.service.FinalizeUpload(r.Context(), service.FinalizeUploadInput{
		FileID:           fileID,
		ExpectedChecksum: req.ExpectedChecksum,
	})
	if err != nil {
		writeError(w, statusCodeForError(err), err)
		return
	}

	writeJSON(w, http.StatusOK, finalizeUploadResponse{
		FileID:      result.FileID,
		Status:      result.Status,
		ObjectKey:   result.ObjectKey,
		Checksum:    result.Checksum,
		CompletedAt: result.CompletedAt.UTC().Format(timeFormat),
	})
}

func (s *Server) handleAbortUpload(w http.ResponseWriter, r *http.Request) {
	fileID := strings.TrimSpace(chi.URLParam(r, "fileID"))

	var req abortUploadRequest
	if r.ContentLength > 0 {
		if err := decodeJSON(r, &req); err != nil {
			writeError(w, http.StatusBadRequest, err)
			return
		}
	}

	result, err := s.service.AbortUpload(r.Context(), service.AbortUploadInput{
		FileID: fileID,
		Reason: req.Reason,
	})
	if err != nil {
		writeError(w, statusCodeForError(err), err)
		return
	}

	writeJSON(w, http.StatusOK, abortUploadResponse{
		FileID:    result.FileID,
		Status:    result.Status,
		AbortedAt: result.AbortedAt.UTC().Format(timeFormat),
	})
}

func (s *Server) handleListRecentUploads(w http.ResponseWriter, r *http.Request) {
	limit := 10
	if raw := r.URL.Query().Get("limit"); raw != "" {
		parsed, err := strconv.Atoi(raw)
		if err == nil && parsed > 0 {
			limit = parsed
		}
	}

	sessions, err := s.service.ListRecentUploads(r.Context(), limit)
	if err != nil {
		writeError(w, statusCodeForError(err), err)
		return
	}

	response := make([]uploadStatusResponse, 0, len(sessions))
	for _, session := range sessions {
		response = append(response, toUploadStatusResponse(session))
	}

	writeJSON(w, http.StatusOK, map[string]any{"sessions": response})
}

func (s *Server) corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		origin := strings.TrimSpace(r.Header.Get("Origin"))
		allowedOrigin := ""

		if len(s.allowedOrigins) == 1 && s.allowedOrigins[0] == "*" {
			allowedOrigin = "*"
		} else if origin != "" && containsOrigin(s.allowedOrigins, origin) {
			allowedOrigin = origin
		}

		if allowedOrigin != "" {
			w.Header().Set("Access-Control-Allow-Origin", allowedOrigin)
			w.Header().Set("Vary", "Origin")
		}

		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, X-Chunk-Checksum")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS")

		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}

		next.ServeHTTP(w, r)
	})
}

func toUploadStatusResponse(status service.UploadStatus) uploadStatusResponse {
	return uploadStatusResponse{
		FileID:          status.FileID,
		Filename:        status.Filename,
		ContentType:     status.ContentType,
		TotalSize:       status.TotalSize,
		ChunkSize:       status.ChunkSize,
		TotalChunks:     status.TotalChunks,
		ReceivedChunks:  status.ReceivedChunks,
		ReceivedIndices: status.ReceivedIndices,
		Status:          status.Status,
		FileChecksum:    status.FileChecksum,
		FinalObjectKey:  status.FinalObjectKey,
		FinalChecksum:   status.FinalChecksum,
		CreatedAt:       status.CreatedAt.UTC().Format(timeFormat),
		UpdatedAt:       status.UpdatedAt.UTC().Format(timeFormat),
		CanFinalize:     status.CanFinalize,
	}
}

func decodeJSON(r *http.Request, out any) error {
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()

	if err := decoder.Decode(out); err != nil {
		return err
	}

	if decoder.More() {
		return errors.New("request body must contain only one JSON object")
	}

	return nil
}

func writeJSON(w http.ResponseWriter, code int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(payload)
}

func writeError(w http.ResponseWriter, code int, err error) {
	writeJSON(w, code, errorResponse{Error: err.Error()})
}

func statusCodeForError(err error) int {
	switch {
	case errors.Is(err, metadata.ErrSessionNotFound):
		return http.StatusNotFound
	case errors.Is(err, service.ErrInvalidArgument),
		errors.Is(err, service.ErrChecksumMismatch),
		errors.Is(err, metadata.ErrDuplicateChecksumMismatch):
		return http.StatusBadRequest
	case errors.Is(err, service.ErrMissingChunks),
		errors.Is(err, service.ErrUploadAborted),
		errors.Is(err, service.ErrUploadCompleted),
		errors.Is(err, service.ErrUploadFinalizing),
		errors.Is(err, service.ErrFinalizeInProgress):
		return http.StatusConflict
	case errors.Is(err, context.DeadlineExceeded), errors.Is(err, context.Canceled):
		return http.StatusGatewayTimeout
	default:
		return http.StatusInternalServerError
	}
}

func containsOrigin(values []string, wanted string) bool {
	for _, value := range values {
		if strings.EqualFold(strings.TrimSpace(value), wanted) {
			return true
		}
	}
	return false
}

const timeFormat = "2006-01-02T15:04:05Z07:00"
