package service

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"math"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/example/uile-fpload/backend/internal/checksum"
	"github.com/example/uile-fpload/backend/internal/config"
	"github.com/example/uile-fpload/backend/internal/metadata"
	"github.com/example/uile-fpload/backend/internal/storage"
	"github.com/google/uuid"
)

type UploadService struct {
	store         metadata.Store
	storageClient storage.Client
	chunkSize     int64
	uploadTimeout time.Duration
	sem           chan struct{}
	logger        *slog.Logger
}

type missingChunkObjectError struct {
	ChunkIndex int
	Err        error
}

func (e *missingChunkObjectError) Error() string {
	return fmt.Sprintf("missing chunk object %d: %v", e.ChunkIndex, e.Err)
}

func (e *missingChunkObjectError) Unwrap() error {
	return e.Err
}

func NewUploadService(store metadata.Store, storageClient storage.Client, cfg *config.Config, logger *slog.Logger) *UploadService {
	if logger == nil {
		logger = slog.Default()
	}
	return &UploadService{
		store:         store,
		storageClient: storageClient,
		chunkSize:     cfg.ChunkSize,
		uploadTimeout: cfg.UploadTimeout,
		sem:           make(chan struct{}, cfg.MaxConcurrentUploads),
		logger:        logger,
	}
}

func (s *UploadService) ChunkSize() int64 {
	return s.chunkSize
}

func (s *UploadService) InitUpload(ctx context.Context, input InitUploadInput) (*InitUploadResult, error) {
	input.Filename = strings.TrimSpace(input.Filename)
	if input.Filename == "" {
		return nil, fmt.Errorf("%w: filename is required", ErrInvalidArgument)
	}
	if input.TotalSize <= 0 {
		return nil, fmt.Errorf("%w: total_size must be > 0", ErrInvalidArgument)
	}

	totalChunks := int(math.Ceil(float64(input.TotalSize) / float64(s.chunkSize)))
	now := time.Now().UTC()
	fileID := uuid.NewString()

	session := metadata.Session{
		FileID:       fileID,
		Filename:     input.Filename,
		ContentType:  input.ContentType,
		TotalSize:    input.TotalSize,
		ChunkSize:    s.chunkSize,
		TotalChunks:  totalChunks,
		Status:       metadata.StatusInitialized,
		FileChecksum: strings.ToLower(strings.TrimSpace(input.FileChecksum)),
		CreatedAt:    now,
		UpdatedAt:    now,
	}

	if err := s.store.CreateSession(ctx, session); err != nil {
		return nil, fmt.Errorf("create session: %w", err)
	}

	return &InitUploadResult{
		FileID:      fileID,
		TotalChunks: totalChunks,
		ChunkSize:   s.chunkSize,
		Status:      metadata.StatusInitialized,
		CreatedAt:   now,
	}, nil
}

func (s *UploadService) UploadChunk(ctx context.Context, input UploadChunkInput) (*UploadChunkResult, error) {
	if err := s.acquire(ctx); err != nil {
		return nil, err
	}
	defer s.release()

	if strings.TrimSpace(input.FileID) == "" {
		return nil, fmt.Errorf("%w: file_id is required", ErrInvalidArgument)
	}
	if input.ChunkIndex < 0 {
		return nil, fmt.Errorf("%w: chunk_index must be >= 0", ErrInvalidArgument)
	}
	if len(input.Data) == 0 {
		return nil, fmt.Errorf("%w: chunk data is empty", ErrInvalidArgument)
	}
	if strings.TrimSpace(input.ChecksumHex) == "" {
		return nil, fmt.Errorf("%w: chunk checksum is required", ErrInvalidArgument)
	}

	session, err := s.store.GetSession(ctx, input.FileID)
	if err != nil {
		return nil, err
	}

	switch session.Status {
	case metadata.StatusCompleted:
		return nil, ErrUploadCompleted
	case metadata.StatusAborted:
		return nil, ErrUploadAborted
	case metadata.StatusFinalizing:
		return nil, ErrUploadFinalizing
	}

	if input.ChunkIndex >= session.TotalChunks {
		return nil, fmt.Errorf("%w: chunk index %d out of range [0,%d)", ErrInvalidArgument, input.ChunkIndex, session.TotalChunks)
	}

	expectedSize := s.expectedChunkSize(session, input.ChunkIndex)
	if int64(len(input.Data)) != expectedSize {
		return nil, fmt.Errorf("%w: chunk %d size mismatch, expected %d got %d", ErrInvalidArgument, input.ChunkIndex, expectedSize, len(input.Data))
	}

	calculatedChecksum := checksum.SHA256Hex(input.Data)
	if !strings.EqualFold(calculatedChecksum, strings.TrimSpace(input.ChecksumHex)) {
		return nil, fmt.Errorf("%w: chunk %d checksum validation failed", ErrChecksumMismatch, input.ChunkIndex)
	}

	markResult, err := s.store.MarkChunkReceived(ctx, input.FileID, input.ChunkIndex, calculatedChecksum)
	if err != nil {
		return nil, err
	}
	if markResult.Duplicate {
		return &UploadChunkResult{
			FileID:     input.FileID,
			ChunkIndex: input.ChunkIndex,
			Accepted:   false,
			Duplicate:  true,
		}, nil
	}

	key := chunkObjectKey(input.FileID, input.ChunkIndex)
	if err := s.storageClient.PutObject(
		ctx,
		key,
		bytes.NewReader(input.Data),
		int64(len(input.Data)),
		"application/octet-stream",
		map[string]string{
			"chunk-index":    strconv.Itoa(input.ChunkIndex),
			"chunk-checksum": calculatedChecksum,
			"file-id":        input.FileID,
		},
	); err != nil {
		rollbackErr := s.store.UnmarkChunk(ctx, input.FileID, input.ChunkIndex)
		if rollbackErr != nil {
			s.logger.Error("failed to rollback chunk metadata", "file_id", input.FileID, "chunk_index", input.ChunkIndex, "error", rollbackErr)
		}
		return nil, fmt.Errorf("store chunk object: %w", err)
	}

	if session.Status == metadata.StatusInitialized {
		if err := s.store.SetStatus(ctx, input.FileID, metadata.StatusUploading); err != nil {
			s.logger.Warn("failed to mark upload session as uploading", "file_id", input.FileID, "error", err)
		}
	}

	return &UploadChunkResult{
		FileID:     input.FileID,
		ChunkIndex: input.ChunkIndex,
		Accepted:   true,
		Duplicate:  false,
	}, nil
}

func (s *UploadService) GetStatus(ctx context.Context, fileID string) (*UploadStatus, error) {
	if strings.TrimSpace(fileID) == "" {
		return nil, fmt.Errorf("%w: file_id is required", ErrInvalidArgument)
	}

	session, err := s.store.GetSession(ctx, fileID)
	if err != nil {
		return nil, err
	}

	receivedIndices, err := s.store.GetReceivedIndices(ctx, fileID)
	if err != nil {
		return nil, fmt.Errorf("get received indices: %w", err)
	}

	return &UploadStatus{
		FileID:          session.FileID,
		Filename:        session.Filename,
		ContentType:     session.ContentType,
		TotalSize:       session.TotalSize,
		ChunkSize:       session.ChunkSize,
		TotalChunks:     session.TotalChunks,
		ReceivedChunks:  len(receivedIndices),
		ReceivedIndices: receivedIndices,
		Status:          session.Status,
		FileChecksum:    session.FileChecksum,
		FinalObjectKey:  session.FinalObjectKey,
		FinalChecksum:   session.FinalChecksum,
		CreatedAt:       session.CreatedAt,
		UpdatedAt:       session.UpdatedAt,
		CanFinalize:     len(receivedIndices) == session.TotalChunks && session.Status != metadata.StatusCompleted && session.Status != metadata.StatusAborted,
	}, nil
}

func (s *UploadService) FinalizeUpload(ctx context.Context, input FinalizeUploadInput) (*FinalizeUploadResult, error) {
	if strings.TrimSpace(input.FileID) == "" {
		return nil, fmt.Errorf("%w: file_id is required", ErrInvalidArgument)
	}

	session, err := s.store.GetSession(ctx, input.FileID)
	if err != nil {
		return nil, err
	}

	if session.Status == metadata.StatusCompleted {
		return &FinalizeUploadResult{
			FileID:      session.FileID,
			Status:      session.Status,
			ObjectKey:   session.FinalObjectKey,
			Checksum:    session.FinalChecksum,
			CompletedAt: session.UpdatedAt,
		}, nil
	}
	if session.Status == metadata.StatusAborted {
		return nil, ErrUploadAborted
	}

	lockAcquired, err := s.store.AcquireFinalizeLock(ctx, input.FileID, 2*time.Minute)
	if err != nil {
		return nil, err
	}
	if !lockAcquired {
		return nil, ErrFinalizeInProgress
	}
	defer func() {
		if releaseErr := s.store.ReleaseFinalizeLock(context.Background(), input.FileID); releaseErr != nil {
			s.logger.Warn("failed to release finalize lock", "file_id", input.FileID, "error", releaseErr)
		}
	}()

	receivedIndices, err := s.store.GetReceivedIndices(ctx, input.FileID)
	if err != nil {
		return nil, fmt.Errorf("read chunk status before finalize: %w", err)
	}
	if len(receivedIndices) != session.TotalChunks {
		return nil, fmt.Errorf("%w: %d/%d chunks available", ErrMissingChunks, len(receivedIndices), session.TotalChunks)
	}

	missingObjectIndices, err := s.reconcileMissingChunkObjects(ctx, input.FileID, receivedIndices)
	if err != nil {
		return nil, fmt.Errorf("verify chunk objects before finalize: %w", err)
	}
	if len(missingObjectIndices) > 0 {
		return nil, fmt.Errorf("%w: %d chunk objects missing (%v)", ErrMissingChunks, len(missingObjectIndices), missingObjectIndices)
	}

	if err := s.store.SetStatus(ctx, input.FileID, metadata.StatusFinalizing); err != nil {
		return nil, fmt.Errorf("set finalizing status: %w", err)
	}

	finalKey := finalObjectKey(input.FileID)
	assembledChecksum, err := s.assembleFinalObject(ctx, session, finalKey)
	if err != nil {
		_ = s.store.SetStatus(ctx, input.FileID, metadata.StatusUploading)

		var missingErr *missingChunkObjectError
		if errors.As(err, &missingErr) {
			if unmarkErr := s.store.UnmarkChunk(ctx, input.FileID, missingErr.ChunkIndex); unmarkErr != nil {
				s.logger.Warn("failed unmarking missing chunk after finalize", "file_id", input.FileID, "chunk_index", missingErr.ChunkIndex, "error", unmarkErr)
			}
			return nil, fmt.Errorf("%w: chunk %d object missing, resume upload to re-send it", ErrMissingChunks, missingErr.ChunkIndex)
		}

		return nil, err
	}

	expectedChecksum := strings.ToLower(strings.TrimSpace(input.ExpectedChecksum))
	if expectedChecksum == "" {
		expectedChecksum = strings.ToLower(strings.TrimSpace(session.FileChecksum))
	}

	if expectedChecksum != "" && !strings.EqualFold(expectedChecksum, assembledChecksum) {
		_ = s.storageClient.DeleteObject(ctx, finalKey)
		_ = s.store.SetChecksumFailed(ctx, input.FileID)
		return nil, fmt.Errorf("%w: expected %s got %s", ErrChecksumMismatch, expectedChecksum, assembledChecksum)
	}

	if err := s.store.SetCompleted(ctx, input.FileID, finalKey, assembledChecksum); err != nil {
		return nil, fmt.Errorf("set completed metadata: %w", err)
	}

	return &FinalizeUploadResult{
		FileID:      input.FileID,
		Status:      metadata.StatusCompleted,
		ObjectKey:   finalKey,
		Checksum:    assembledChecksum,
		CompletedAt: time.Now().UTC(),
	}, nil
}

func (s *UploadService) AbortUpload(ctx context.Context, input AbortUploadInput) (*AbortUploadResult, error) {
	if strings.TrimSpace(input.FileID) == "" {
		return nil, fmt.Errorf("%w: file_id is required", ErrInvalidArgument)
	}

	session, err := s.store.GetSession(ctx, input.FileID)
	if err != nil {
		return nil, err
	}

	if session.Status == metadata.StatusAborted {
		return &AbortUploadResult{FileID: input.FileID, Status: metadata.StatusAborted, AbortedAt: session.UpdatedAt}, nil
	}

	prefix := uploadPrefix(input.FileID)
	keys, err := s.storageClient.ListObjects(ctx, prefix)
	if err != nil {
		return nil, fmt.Errorf("list upload objects for abort: %w", err)
	}
	if err := s.storageClient.DeleteObjects(ctx, keys); err != nil {
		return nil, fmt.Errorf("delete upload objects for abort: %w", err)
	}

	reason := strings.TrimSpace(input.Reason)
	if reason == "" {
		reason = "aborted by client"
	}

	if err := s.store.SetAborted(ctx, input.FileID, reason); err != nil {
		return nil, fmt.Errorf("set aborted metadata: %w", err)
	}
	if err := s.store.DeleteChunkState(ctx, input.FileID); err != nil {
		s.logger.Warn("failed deleting chunk state after abort", "file_id", input.FileID, "error", err)
	}

	return &AbortUploadResult{
		FileID:    input.FileID,
		Status:    metadata.StatusAborted,
		AbortedAt: time.Now().UTC(),
	}, nil
}

func (s *UploadService) ListRecentUploads(ctx context.Context, limit int) ([]UploadStatus, error) {
	sessions, err := s.store.ListRecentSessions(ctx, limit)
	if err != nil {
		return nil, err
	}

	out := make([]UploadStatus, 0, len(sessions))
	for _, session := range sessions {
		indices, idxErr := s.store.GetReceivedIndices(ctx, session.FileID)
		if idxErr != nil {
			indices = nil
		}

		status := UploadStatus{
			FileID:          session.FileID,
			Filename:        session.Filename,
			ContentType:     session.ContentType,
			TotalSize:       session.TotalSize,
			ChunkSize:       session.ChunkSize,
			TotalChunks:     session.TotalChunks,
			ReceivedChunks:  len(indices),
			ReceivedIndices: indices,
			Status:          session.Status,
			FileChecksum:    session.FileChecksum,
			FinalObjectKey:  session.FinalObjectKey,
			FinalChecksum:   session.FinalChecksum,
			CreatedAt:       session.CreatedAt,
			UpdatedAt:       session.UpdatedAt,
			CanFinalize:     len(indices) == session.TotalChunks && session.Status != metadata.StatusCompleted && session.Status != metadata.StatusAborted,
		}
		out = append(out, status)
	}

	sort.Slice(out, func(i, j int) bool {
		return out[i].UpdatedAt.After(out[j].UpdatedAt)
	})

	return out, nil
}

func (s *UploadService) RunCleanupLoop(ctx context.Context, interval time.Duration) {
	if interval < 30*time.Second {
		interval = 30 * time.Second
	}

	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			if err := s.cleanupStaleUploads(ctx); err != nil {
				s.logger.Warn("stale upload cleanup tick failed", "error", err)
			}
		}
	}
}

func (s *UploadService) cleanupStaleUploads(ctx context.Context) error {
	cutoff := time.Now().UTC().Add(-s.uploadTimeout)
	staleSessions, err := s.store.ScanStaleSessions(ctx, cutoff, 50)
	if err != nil {
		return err
	}

	for _, stale := range staleSessions {
		_, abortErr := s.AbortUpload(ctx, AbortUploadInput{
			FileID: stale.FileID,
			Reason: "aborted by background cleanup due to inactivity timeout",
		})
		if abortErr != nil && !errors.Is(abortErr, metadata.ErrSessionNotFound) {
			s.logger.Warn("stale upload cleanup abort failed", "file_id", stale.FileID, "error", abortErr)
		}
	}

	return nil
}

func (s *UploadService) acquire(ctx context.Context) error {
	select {
	case s.sem <- struct{}{}:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func (s *UploadService) release() {
	<-s.sem
}

func (s *UploadService) expectedChunkSize(session metadata.Session, chunkIndex int) int64 {
	if chunkIndex < session.TotalChunks-1 {
		return s.chunkSize
	}

	remainder := session.TotalSize % s.chunkSize
	if remainder == 0 {
		return s.chunkSize
	}
	return remainder
}

func (s *UploadService) reconcileMissingChunkObjects(ctx context.Context, fileID string, receivedIndices []int) ([]int, error) {
	missingIndices := make([]int, 0)

	for _, idx := range receivedIndices {
		key := chunkObjectKey(fileID, idx)
		object, err := s.storageClient.GetObject(ctx, key)
		if err != nil {
			if isMissingObjectError(err) {
				if unmarkErr := s.store.UnmarkChunk(ctx, fileID, idx); unmarkErr != nil {
					s.logger.Warn("failed unmarking missing chunk", "file_id", fileID, "chunk_index", idx, "error", unmarkErr)
				} else {
					missingIndices = append(missingIndices, idx)
				}
				continue
			}
			return nil, fmt.Errorf("verify chunk object %d: %w", idx, err)
		}

		_ = object.Close()
	}

	return missingIndices, nil
}

func (s *UploadService) assembleFinalObject(ctx context.Context, session metadata.Session, finalKey string) (string, error) {
	pipeReader, pipeWriter := io.Pipe()
	hasher := sha256.New()
	copyErrCh := make(chan error, 1)

	go func() {
		defer close(copyErrCh)
		defer pipeWriter.Close()

		writer := io.MultiWriter(pipeWriter, hasher)
		for idx := 0; idx < session.TotalChunks; idx++ {
			key := chunkObjectKey(session.FileID, idx)
			object, err := s.storageClient.GetObject(ctx, key)
			if err != nil {
				wrappedErr := fmt.Errorf("read chunk %d: %w", idx, err)
				if isMissingObjectError(err) {
					wrappedErr = &missingChunkObjectError{ChunkIndex: idx, Err: wrappedErr}
				}
				pipeWriter.CloseWithError(wrappedErr)
				copyErrCh <- wrappedErr
				return
			}

			if _, err := io.Copy(writer, object); err != nil {
				_ = object.Close()
				wrappedErr := fmt.Errorf("copy chunk %d: %w", idx, err)
				pipeWriter.CloseWithError(wrappedErr)
				copyErrCh <- wrappedErr
				return
			}
			_ = object.Close()
		}

		copyErrCh <- nil
	}()

	putErr := s.storageClient.PutObject(ctx, finalKey, pipeReader, session.TotalSize, contentTypeOrDefault(session.ContentType), map[string]string{
		"file-id": session.FileID,
	})

	copyErr := <-copyErrCh
	if copyErr != nil {
		return "", fmt.Errorf("assemble final object: %w", copyErr)
	}

	if putErr != nil {
		return "", fmt.Errorf("write final object: %w", putErr)
	}

	return hex.EncodeToString(hasher.Sum(nil)), nil
}

func isMissingObjectError(err error) bool {
	lower := strings.ToLower(err.Error())
	return strings.Contains(lower, "specified key does not exist") ||
		strings.Contains(lower, "no such key") ||
		strings.Contains(lower, "not found")
}

func chunkObjectKey(fileID string, chunkIndex int) string {
	return fmt.Sprintf("uploads/%s/chunk-%d", fileID, chunkIndex)
}

func finalObjectKey(fileID string) string {
	return fmt.Sprintf("uploads/%s/final", fileID)
}

func uploadPrefix(fileID string) string {
	return fmt.Sprintf("uploads/%s/", fileID)
}

func contentTypeOrDefault(contentType string) string {
	contentType = strings.TrimSpace(contentType)
	if contentType == "" {
		return "application/octet-stream"
	}
	return contentType
}
