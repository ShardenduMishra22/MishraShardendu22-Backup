package service

import (
	"errors"
	"time"
)

var (
	ErrInvalidArgument    = errors.New("invalid argument")
	ErrUploadCompleted    = errors.New("upload already completed")
	ErrUploadAborted      = errors.New("upload already aborted")
	ErrUploadFinalizing   = errors.New("upload is finalizing")
	ErrFinalizeInProgress = errors.New("finalization already in progress")
	ErrMissingChunks      = errors.New("cannot finalize upload with missing chunks")
	ErrChecksumMismatch   = errors.New("checksum mismatch")
)

type InitUploadInput struct {
	Filename     string
	TotalSize    int64
	ContentType  string
	FileChecksum string
}

type InitUploadResult struct {
	FileID      string
	TotalChunks int
	ChunkSize   int64
	Status      string
	CreatedAt   time.Time
}

type UploadChunkInput struct {
	FileID      string
	ChunkIndex  int
	Data        []byte
	ChecksumHex string
}

type UploadChunkResult struct {
	FileID     string
	ChunkIndex int
	Accepted   bool
	Duplicate  bool
}

type UploadStatus struct {
	FileID          string
	Filename        string
	ContentType     string
	TotalSize       int64
	ChunkSize       int64
	TotalChunks     int
	ReceivedChunks  int
	ReceivedIndices []int
	Status          string
	FileChecksum    string
	FinalObjectKey  string
	FinalChecksum   string
	CreatedAt       time.Time
	UpdatedAt       time.Time
	CanFinalize     bool
}

type FinalizeUploadInput struct {
	FileID           string
	ExpectedChecksum string
}

type FinalizeUploadResult struct {
	FileID      string
	Status      string
	ObjectKey   string
	Checksum    string
	CompletedAt time.Time
}

type AbortUploadInput struct {
	FileID string
	Reason string
}

type AbortUploadResult struct {
	FileID    string
	Status    string
	AbortedAt time.Time
}
