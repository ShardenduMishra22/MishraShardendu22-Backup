package main

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	uploadv1 "github.com/example/uile-fpload/backend/api/proto/upload/v1"
	"github.com/example/uile-fpload/backend/internal/config"
	"github.com/example/uile-fpload/backend/internal/metadata"
	"github.com/example/uile-fpload/backend/internal/service"
	"github.com/example/uile-fpload/backend/internal/storage"
	"github.com/example/uile-fpload/backend/internal/transport/grpcserver"
	"github.com/example/uile-fpload/backend/internal/transport/httpserver"
	"golang.org/x/sync/errgroup"
	"google.golang.org/grpc"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed loading config: %v\n", err)
		os.Exit(1)
	}

	logger := buildLogger(cfg.LogLevel)

	store, err := metadata.NewRedisStore(cfg.RedisAddr, cfg.RedisPassword, cfg.RedisDB)
	if err != nil {
		logger.Error("failed to initialize redis store", "error", err)
		os.Exit(1)
	}
	defer func() {
		if closeErr := store.Close(); closeErr != nil {
			logger.Warn("failed closing redis store", "error", closeErr)
		}
	}()

	s3Client, err := storage.NewS3Client(cfg)
	if err != nil {
		logger.Error("failed to initialize object storage client", "error", err)
		os.Exit(1)
	}

	rootCtx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	if err := ensureBucketWithRetry(rootCtx, s3Client, logger); err != nil {
		logger.Error("failed to ensure object storage bucket", "error", err)
		os.Exit(1)
	}

	uploadService := service.NewUploadService(store, s3Client, cfg, logger)
	go uploadService.RunCleanupLoop(rootCtx, time.Minute)

	grpcSrv := grpc.NewServer(
		grpc.MaxRecvMsgSize(int(cfg.ChunkSize+1024*1024)),
		grpc.MaxSendMsgSize(16*1024*1024),
	)
	uploadv1.RegisterUploadServiceServer(grpcSrv, grpcserver.New(uploadService))

	grpcListener, err := net.Listen("tcp", cfg.GRPCAddr)
	if err != nil {
		logger.Error("failed to listen for grpc", "addr", cfg.GRPCAddr, "error", err)
		os.Exit(1)
	}

	httpHandler := httpserver.New(uploadService, cfg, logger)
	httpSrv := &http.Server{
		Addr:              cfg.HTTPAddr,
		Handler:           httpHandler,
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       120 * time.Second,
		WriteTimeout:      120 * time.Second,
		IdleTimeout:       120 * time.Second,
	}

	g, ctx := errgroup.WithContext(rootCtx)

	g.Go(func() error {
		logger.Info("grpc server listening", "addr", cfg.GRPCAddr)
		if err := grpcSrv.Serve(grpcListener); err != nil && !errors.Is(err, grpc.ErrServerStopped) {
			return fmt.Errorf("grpc serve: %w", err)
		}
		return nil
	})

	g.Go(func() error {
		logger.Info("http gateway listening", "addr", cfg.HTTPAddr)
		if err := httpSrv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			return fmt.Errorf("http serve: %w", err)
		}
		return nil
	})

	g.Go(func() error {
		<-ctx.Done()

		shutdownCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()

		grpcSrv.GracefulStop()
		if err := httpSrv.Shutdown(shutdownCtx); err != nil && !errors.Is(err, http.ErrServerClosed) {
			return fmt.Errorf("http shutdown: %w", err)
		}
		return nil
	})

	if err := g.Wait(); err != nil && !errors.Is(err, context.Canceled) {
		logger.Error("server terminated with error", "error", err)
		os.Exit(1)
	}

	logger.Info("server shut down cleanly")
}

func ensureBucketWithRetry(ctx context.Context, storageClient storage.Client, logger *slog.Logger) error {
	var lastErr error
	for attempt := 1; attempt <= 20; attempt++ {
		err := storageClient.EnsureBucket(ctx)
		if err == nil {
			return nil
		}

		lastErr = err
		logger.Warn("failed ensuring bucket, will retry", "attempt", attempt, "error", err)

		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(2 * time.Second):
		}
	}

	if lastErr == nil {
		lastErr = errors.New("unknown bucket initialization error")
	}
	return fmt.Errorf("bucket init retries exhausted: %w", lastErr)
}

func buildLogger(level string) *slog.Logger {
	slogLevel := slog.LevelInfo
	switch level {
	case "debug":
		slogLevel = slog.LevelDebug
	case "warn":
		slogLevel = slog.LevelWarn
	case "error":
		slogLevel = slog.LevelError
	}

	handler := slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: slogLevel})
	return slog.New(handler)
}
