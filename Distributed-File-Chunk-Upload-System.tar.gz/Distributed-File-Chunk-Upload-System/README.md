# Distributed Resumable File Upload System

Production-grade local stack for large-file uploads using:

- Go backend with gRPC + HTTP gateway
- Redis for durable upload metadata and resume state
- MinIO for local S3-compatible object storage
- Next.js frontend for parallel chunk upload and resume UX
- Docker + docker-compose for one-command local deployment

## Architecture

- Frontend: Next.js app uploads chunks through HTTP gateway (`/api/uploads/*`)
- Backend: Go service exposes both:
  - gRPC service (`UploadService`) for service-to-service clients
  - HTTP gateway for browser clients
- Redis: tracks session metadata, received chunks, and upload state
- S3-compatible storage: stores chunk objects and final object

Chunk layout in object storage:

- `uploads/{fileId}/chunk-{index}`
- `uploads/{fileId}/final`

## Hard Guarantees Implemented

- Fixed chunk size: 8 MB (`CHUNK_SIZE=8388608`)
- Parallel chunk uploads (frontend worker pool)
- Out-of-order chunk acceptance
- Idempotent duplicate chunk handling
- Resume support from Redis-tracked chunk state
- Stateless backend design (durable state in Redis + S3)
- Same storage code works for MinIO and cloud S3-compatible providers by env config only

## Local Run

```bash
cp .env.example .env
make up
```

Services:

- Frontend: <http://localhost:13000>
- Backend HTTP: <http://localhost:18080>
- Backend gRPC: localhost:15051
- MinIO API: <http://localhost:19000>
- MinIO Console: <http://localhost:19001>

Stop:

```bash
make down
```

Logs:

```bash
make logs
```

Clean (remove containers and volumes):

```bash
make clean
```

## Cloud Mode (Same Codebase)

Switch only environment values (no code change):

- `S3_ENDPOINT=https://s3.amazonaws.com` (or provider endpoint)
- `S3_ACCESS_KEY=<cloud-access-key>`
- `S3_SECRET_KEY=<cloud-secret-key>`
- `S3_BUCKET=<cloud-bucket>`
- `S3_REGION=<cloud-region>`
- `S3_USE_SSL=true`

The backend keeps using the same S3-compatible client abstraction.

## gRPC API

Protobuf definitions are in:

- `backend/api/proto/upload/v1/upload.proto`

RPCs:

- `InitUpload`
- `Upload` (client streaming)
- `GetStatus`
- `FinalizeUpload`
- `AbortUpload`
- `ListRecentUploads`

## HTTP Gateway Endpoints

- `POST /api/uploads/init`
- `PUT /api/uploads/{fileId}/chunks/{chunkIndex}`
- `GET /api/uploads/{fileId}/status`
- `POST /api/uploads/{fileId}/finalize`
- `POST /api/uploads/{fileId}/abort`
- `GET /api/uploads/recent`

## Backend Module Layout

- `backend/internal/config` env config
- `backend/internal/checksum` checksum helpers
- `backend/internal/metadata` Redis metadata store
- `backend/internal/storage` S3-compatible storage client
- `backend/internal/service` upload orchestration logic
- `backend/internal/transport/grpcserver` gRPC handlers
- `backend/internal/transport/httpserver` HTTP gateway handlers

## Notes

- Upload timeout cleanup runs in background; stale incomplete sessions are aborted and storage objects are cleaned.
- Frontend stores a per-file session key in browser localStorage for resume workflow.
