import type * as React from "react";
import { cn } from "@/lib/utils";

function Label({ className, ...props }: React.ComponentProps<"label">) {
  return (
    /* biome-ignore lint/a11y/noLabelWithoutControl: The component forwards htmlFor to consuming form fields. */
    <label
      className={cn(
        "text-sm font-medium leading-none text-foreground",
        className,
      )}
      {...props}
    />
  );
}

export { Label };
