#!/usr/bin/env python3
"""
generate_multi_approach_suite.py - Creates a comprehensive multi-approach
benchmark suite across canonical DSA domains with 5 distinct submission types:
  1. OPTIMAL: Correct canonical approach + matching semantic explanation -> ACCEPT
  2. ALTERNATIVE: 2nd valid algorithmic strategy + matching explanation -> ACCEPT
  3. FAILING: Syntactically valid code that produces wrong output -> REJECT (Test Fail)
  4. BLUFFING: Passing code with completely contradictory/unrelated explanation -> REJECT / REJUSTIFY
  5. DEAD_CODE: Passing code stuffing unused complex classes/data structures -> Output relevance penalty
"""

import json
import os

BENCHMARKS = [
    {
        "problem_id": "two_sum",
        "category": "hashing",
        "name": "Two Sum Multi-Approach Test Matrix",
        "approaches": [
            {
                "name": "Optimal Hash Map",
                "type": "OPTIMAL",
                "code": "def solve(nums, target):\n    seen = {}\n    for i, n in enumerate(nums):\n        diff = target - n\n        if diff in seen:\n            return [seen[diff], i]\n        seen[n] = i\n    return []\n",
                "explanation": "We iterate through the array maintaining a hash map of visited numbers. For each number, we look up its complement target - n in O(1) time.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.95
            },
            {
                "name": "Alternative Two Pointers (Sorted)",
                "type": "ALTERNATIVE",
                "code": "def solve(nums, target):\n    indexed = sorted([(n, i) for i, n in enumerate(nums)])\n    left = 0\n    right = len(indexed) - 1\n    while left < right:\n        cur = indexed[left][0] + indexed[right][0]\n        if cur == target:\n            return sorted([indexed[left][1], indexed[right][1]])\n        elif cur < target:\n            left += 1\n        else:\n            right -= 1\n    return []\n",
                "explanation": "We sort indexed pairs and use two pointers starting from left and right boundaries moving towards each other based on sum comparison.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.90
            },
            {
                "name": "Failing Wrong Logic",
                "type": "FAILING",
                "code": "def solve(nums, target):\n    return [0, 0]\n",
                "explanation": "We check the pairs.",
                "expected_test_status": "FAIL",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.0
            },
            {
                "name": "Bluffing Contradictory Claim",
                "type": "BLUFFING",
                "code": "def solve(nums, target):\n    seen = {}\n    for i, n in enumerate(nums):\n        diff = target - n\n        if diff in seen:\n            return [seen[diff], i]\n        seen[n] = i\n    return []\n",
                "explanation": "We build a segment tree and run binary search over a Fenwick tree with union-find disjoint sets.",
                "expected_test_status": "PASS",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.60
            },
            {
                "name": "Dead Code Concept Stuffing",
                "type": "DEAD_CODE",
                "code": "def solve(nums, target):\n    class TrieNode:\n        def __init__(self):\n            self.children = {}\n    dummy = TrieNode()\n    seen = {}\n    for i, n in enumerate(nums):\n        diff = target - n\n        if diff in seen:\n            return [seen[diff], i]\n        seen[n] = i\n    return []\n",
                "explanation": "We construct a trie prefix tree to store numbers.",
                "expected_test_status": "PASS",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.86
            }
        ]
    },
    {
        "problem_id": "binary_search_basic",
        "category": "binary_search",
        "name": "Binary Search Multi-Approach Test Matrix",
        "approaches": [
            {
                "name": "Optimal Iterative While Loop",
                "type": "OPTIMAL",
                "code": "def solve(nums, target):\n    left, right = 0, len(nums) - 1\n    while left <= right:\n        mid = (left + right) // 2\n        if nums[mid] == target:\n            return mid\n        elif nums[mid] < target:\n            left = mid + 1\n        else:\n            right = mid - 1\n    return -1\n",
                "explanation": "We use binary search with low and high pointers, bisecting the search space in a while loop until the target is found or pointers cross.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.95
            },
            {
                "name": "Alternative Recursive Binary Search",
                "type": "ALTERNATIVE",
                "code": "def solve(nums, target):\n    def bsearch(low, high):\n        if low > high:\n            return -1\n        mid = (low + high) // 2\n        if nums[mid] == target:\n            return mid\n        elif nums[mid] < target:\n            return bsearch(mid + 1, high)\n        return bsearch(low, mid - 1)\n    return bsearch(0, len(nums) - 1)\n",
                "explanation": "We implement recursive binary search by dividing the interval at mid and recursing on the left or right partition.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.90
            },
            {
                "name": "Failing Linear Always Returns Zero",
                "type": "FAILING",
                "code": "def solve(nums, target):\n    return 0\n",
                "explanation": "We search the array.",
                "expected_test_status": "FAIL",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.0
            },
            {
                "name": "Bluffing Dynamic Programming Claim",
                "type": "BLUFFING",
                "code": "def solve(nums, target):\n    left, right = 0, len(nums) - 1\n    while left <= right:\n        mid = (left + right) // 2\n        if nums[mid] == target:\n            return mid\n        elif nums[mid] < target:\n            left = mid + 1\n        else:\n            right = mid - 1\n    return -1\n",
                "explanation": "We use 2D dynamic programming tabulation with memoization state transitions to find optimal subproblems.",
                "expected_test_status": "PASS",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.60
            }
        ]
    },
    {
        "problem_id": "valid_parentheses",
        "category": "stack",
        "name": "Valid Parentheses Multi-Approach Test Matrix",
        "approaches": [
            {
                "name": "Optimal LIFO Stack",
                "type": "OPTIMAL",
                "code": "def solve(s):\n    mapping = {')': '(', '}': '{', ']': '['}\n    stack = []\n    for char in s:\n        if char in mapping:\n            top = stack.pop() if stack else '#'\n            if mapping[char] != top:\n                return False\n        else:\n            stack.append(char)\n    return len(stack) == 0\n",
                "explanation": "We push opening brackets onto a stack and pop matching pairs whenever a closing bracket is encountered.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.95
            },
            {
                "name": "Non-Compliant String Reduction (Missing Required Stack)",
                "type": "ALTERNATIVE",
                "code": "def solve(s):\n    prev = None\n    while s != prev:\n        prev = s\n        s = s.replace('()', '').replace('{}', '').replace('[]', '')\n    return len(s) == 0\n",
                "explanation": "We iteratively remove matching adjacent bracket pairs using string reduction.",
                "expected_test_status": "PASS",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.60
            },
            {
                "name": "Failing Always True",
                "type": "FAILING",
                "code": "def solve(s):\n    return True\n",
                "explanation": "Brackets are balanced.",
                "expected_test_status": "FAIL",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.0
            }
        ]
    },
    {
        "problem_id": "single_number",
        "category": "bit_manipulation",
        "name": "Single Number Multi-Approach Test Matrix",
        "approaches": [
            {
                "name": "Optimal Bitwise XOR",
                "type": "OPTIMAL",
                "code": "def solve(nums):\n    res = 0\n    for n in nums:\n        res ^= n\n    return res\n",
                "explanation": "We use bitwise XOR reduction where identical numbers cancel each other out (a ^ a = 0), leaving only the unique element.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.95
            },
            {
                "name": "Non-Compliant Math Set Sum (Missing Required Bit Manipulation)",
                "type": "ALTERNATIVE",
                "code": "def solve(nums):\n    return 2 * sum(set(nums)) - sum(nums)\n",
                "explanation": "We use a hash set to collect distinct elements and compute 2 * sum(set) - sum(nums) to isolate the unique number.",
                "expected_test_status": "PASS",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.60
            },
            {
                "name": "Failing Returns First Element",
                "type": "FAILING",
                "code": "def solve(nums):\n    return nums[0]\n",
                "explanation": "We take the first number.",
                "expected_test_status": "FAIL",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.0
            }
        ]
    },
    {
        "problem_id": "climbing_stairs",
        "category": "dynamic_programming",
        "name": "Climbing Stairs Multi-Approach Test Matrix",
        "approaches": [
            {
                "name": "Optimal Space-Optimized DP",
                "type": "OPTIMAL",
                "code": "def solve(n):\n    if n <= 2:\n        return n\n    dp0, dp1 = 1, 2\n    for _ in range(3, n + 1):\n        dp0, dp1 = dp1, dp0 + dp1\n    return dp1\n",
                "explanation": "We use dynamic programming with two variables tracking the previous two steps in dp0 and dp1.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.95
            },
            {
                "name": "Alternative Memoized Top-Down DP",
                "type": "ALTERNATIVE",
                "code": "def solve(n):\n    memo = {}\n    def dp(i):\n        if i <= 2:\n            return i\n        if i not in memo:\n            memo[i] = dp(i - 1) + dp(i - 2)\n        return memo[i]\n    return dp(n)\n",
                "explanation": "We use top-down recursion with memoization caching computed intermediate stair count states in a dictionary.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.90
            },
            {
                "name": "Failing Fixed Constant Output",
                "type": "FAILING",
                "code": "def solve(n):\n    return 42\n",
                "explanation": "Fibonacci DP.",
                "expected_test_status": "FAIL",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.0
            }
        ]
    },
    {
        "problem_id": "jump_game",
        "category": "greedy",
        "name": "Jump Game Multi-Approach Test Matrix",
        "approaches": [
            {
                "name": "Optimal Greedy Farthest Reach",
                "type": "OPTIMAL",
                "code": "def solve(nums):\n    max_reach = 0\n    for i, jump in enumerate(nums):\n        if i > max_reach:\n            return False\n        max_reach = max(max_reach, i + jump)\n    return True\n",
                "explanation": "We use a greedy approach maintaining the max reachable index at each step, updating farthest reach using max(max_reach, i + jump).",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.95
            },
            {
                "name": "Alternative Backward Target Greedy",
                "type": "ALTERNATIVE",
                "code": "def solve(nums):\n    target = len(nums) - 1\n    for i in range(len(nums) - 2, -1, -1):\n        if i + nums[i] >= target:\n            target = i\n    return target == 0\n",
                "explanation": "We use a greedy algorithm iterating backwards, shifting the required target index whenever an earlier position can reach the target.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.90
            },
            {
                "name": "Failing Always False",
                "type": "FAILING",
                "code": "def solve(nums):\n    return False\n",
                "explanation": "Greedy jump reach.",
                "expected_test_status": "FAIL",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.0
            }
        ]
    },
    {
        "problem_id": "maximum_subarray",
        "category": "dynamic_programming",
        "name": "Maximum Subarray Multi-Approach Test Matrix",
        "approaches": [
            {
                "name": "Optimal Kadane Algorithm",
                "type": "OPTIMAL",
                "code": "def solve(nums):\n    dp = nums[0]\n    max_sum = nums[0]\n    for x in nums[1:]:\n        dp = max(x, dp + x)\n        max_sum = max(max_sum, dp)\n    return max_sum\n",
                "explanation": "We use dynamic programming (Kadane's algorithm), maintaining the maximum subarray sum ending at each position in dp.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.95
            },
            {
                "name": "Alternative Prefix Sum DP",
                "type": "ALTERNATIVE",
                "code": "def solve(nums):\n    dp = [0] * len(nums)\n    dp[0] = nums[0]\n    max_val = nums[0]\n    for i in range(1, len(nums)):\n        dp[i] = nums[i] + (dp[i-1] if dp[i-1] > 0 else 0)\n        if dp[i] > max_val:\n            max_val = dp[i]\n    return max_val\n",
                "explanation": "We maintain a dynamic programming array where dp[i] stores the maximum subarray ending at index i, choosing between extending or starting fresh.",
                "expected_test_status": "PASS",
                "expected_decision": "ACCEPT",
                "min_fidelity_score": 0.90
            },
            {
                "name": "Failing Zero Return",
                "type": "FAILING",
                "code": "def solve(nums):\n    return 0\n",
                "explanation": "Kadane scan.",
                "expected_test_status": "FAIL",
                "expected_decision": "REJECT",
                "max_fidelity_score": 0.0
            }
        ]
    }
]

def main():
    out_dir = os.path.join("data", "benchmarks")
    os.makedirs(out_dir, exist_ok=True)
    out_file = os.path.join(out_dir, "multi_approach_suite.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(BENCHMARKS, f, indent=2)
    print(f"[SUCCESS] Written {len(BENCHMARKS)} benchmark suites to {out_file}")

if __name__ == "__main__":
    main()
