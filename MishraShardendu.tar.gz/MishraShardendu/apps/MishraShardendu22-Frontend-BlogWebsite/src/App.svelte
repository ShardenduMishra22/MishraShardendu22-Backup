<script lang="ts">
  import BlogNavigation from "./lib/components/BlogNavigation.svelte";
  import BlogListPage from "./lib/components/BlogListPage.svelte";
  import Toast from "./lib/components/Toast.svelte";
  import ConfirmDialog from "./lib/components/ConfirmDialog.svelte";
  import Footer from "./lib/components/Footer.svelte";
  import { authStore } from "./lib/auth";
  import { updateSEO } from "./lib/seo";
  import { navigateTo } from "./lib/navigation";
  import { onMount } from "svelte";

  // Lazy load heavier page components
  let BlogCreatePage: any = $state(null);
  let BlogDetailPage: any = $state(null);
  let BlogDashboardPage: any = $state(null);
  let LoginPage: any = $state(null);

  let currentPath = $state(window.location.pathname);
  let isAuthenticated = $state(false);
  let isOwner = $state(false);
  let isLoading = $state(true);

  onMount(() => {
    let cleanup: (() => void) | undefined;
    
    (async () => {
      try {
        document.documentElement.classList.add('dark');
        await authStore.init();
        updatePageSEO();
      } catch (error) {
        console.error('[Blog App] Initialization error:', error);
      }
    })();
    
    // Set up navigation event listeners
    const handleLocationChange = () => {
      currentPath = window.location.pathname;
      
      if (currentPath === '/' || currentPath === '') {
        window.history.replaceState(null, '', '/read');
        currentPath = '/read';
      }
    };

    // Check initial path
    const checkPath = window.location.pathname;
    if (checkPath === '/' || checkPath === '') {
      window.history.replaceState(null, '', '/read');
      currentPath = '/read';
    }

    window.addEventListener("popstate", handleLocationChange);
    
    cleanup = () => {
      window.removeEventListener("popstate", handleLocationChange);
    };
    
    return cleanup;
  });

  authStore.subscribe((state) => {
    isAuthenticated = state.isAuthenticated;
    isOwner = state.user?.isOwner || false;
    isLoading = state.isLoading;
  });

  const normalizedPath = $derived(() => {
    let path = currentPath;
    if (!path || path === '/') {
      path = '/read';
    }
    return path;
  });

  const requiresAuth = $derived(() => {
    const path = normalizedPath();
    return path === "/create" || 
           path === "/dashboard" || 
           path.endsWith("/edit");
  });

  $effect(() => {
    if (!isLoading && requiresAuth() && !isAuthenticated) {
      navigateTo('/login');
    } else if (!isLoading && requiresAuth() && isAuthenticated && !isOwner && 
               (normalizedPath() === "/create" || normalizedPath() === "/dashboard" || normalizedPath().endsWith("/edit"))) {
      navigateTo('/read');
    }
  });

  // Lazy load page components on demand
  $effect(() => {
    const page = pageComponent();
    if (page === "login" && !LoginPage) {
      import("./lib/components/LoginPage.svelte").then(m => { LoginPage = m.default; });
    } else if (page === "create" || page === "edit") {
      if (!BlogCreatePage) import("./lib/components/BlogCreatePage.svelte").then(m => { BlogCreatePage = m.default; });
    } else if (page === "detail") {
      if (!BlogDetailPage) import("./lib/components/BlogDetailPage.svelte").then(m => { BlogDetailPage = m.default; });
    } else if (page === "dashboard") {
      if (!BlogDashboardPage) import("./lib/components/BlogDashboardPage.svelte").then(m => { BlogDashboardPage = m.default; });
    }
  });

  const pageComponent = $derived(() => {
    const path = normalizedPath();
    if (path === "/login" || path === "/register") {
      return "login";
    } else if (path === "/" || path === "" || path === "/read") {
      return "list";
    } else if (path === "/create") {
      return "create";
    } else if (path === "/dashboard") {
      return "dashboard";
    } else if (path.match(/^\/read\/\d+\/edit$/)) {
      return "edit";
    } else if (path.match(/^\/read\/\d+$/)) {
      return "detail";
    }
    return "list";
  });

  const blogId = $derived(() => {
    const path = normalizedPath();
    const match = path.match(/^\/read\/(\d+)(?:\/edit)?$/);
    return match ? match[1] : null;
  });

  function updatePageSEO() {
    const baseUrl = 'https://blogs.mishrashardendu22.is-a.dev';
    
    switch (pageComponent()) {
      case 'login':
        updateSEO({
          title: 'Login | Shardendu Mishra Blog | Access Your Dashboard',
          description: 'Sign in to your blog dashboard to create, edit, and publish technical articles. Manage your content and engage with your readers.',
          url: `${baseUrl}/login`,
          keywords: 'blog login, content management, writer dashboard',
        });
        break;
      case 'list':
        updateSEO({
          title: 'Blogs By Shardendu Mishra | Tech Articles & Programming Insights',
          description: 'Explore in-depth technical articles covering web development, software engineering, programming best practices, system design, and modern tech stack insights. Written by Shardendu Mishra, a passionate software engineer and IIIT Dharwad student.',
          url: `${baseUrl}/read`,
          keywords: 'technical articles, programming blog, web development, software engineering, coding tutorials, tech insights',
        });
        break;
      case 'create':
        updateSEO({
          title: 'Create New Post | Shardendu Mishra Blog',
          description: 'Create and publish a new technical blog post. Share your knowledge, insights, and experiences with the developer community.',
          url: `${baseUrl}/create`,
          keywords: 'create blog post, write article, publish content',
        });
        break;
      case 'dashboard':
        updateSEO({
          title: 'Dashboard | Shardendu Mishra Blog | Manage Your Content',
          description: 'Manage your blog posts, view analytics, monitor engagement, and track your content performance. Your central hub for blog management.',
          url: `${baseUrl}/dashboard`,
          keywords: 'blog dashboard, content management, analytics, post management',
        });
        break;
      case 'edit':
        updateSEO({
          title: 'Edit Post - Shardendu Mishra Blog',
          description: 'Edit and update your blog post content. Refine your technical article to ensure accuracy and clarity for your readers.',
          url: `${baseUrl}${currentPath}`,
          keywords: 'edit blog post, update article, content editing',
        });
        break;
      case 'detail':
        updateSEO({
          title: 'Blog Post | Shardendu Mishra',
          description: 'Read this insightful technical article by Shardendu Mishra covering programming concepts, best practices, and real-world development experiences.',
          url: `${baseUrl}${currentPath}`,
          type: 'article',
          keywords: 'technical article, programming tutorial, software development',
        });
        break;
      default:
        updateSEO();
    }
  }

  $effect(() => {
    if (!isLoading) {
      updatePageSEO();
    }
  });
</script>

<div class="min-h-screen bg-background overflow-x-hidden w-full max-w-full" style="min-height: 100vh;">
  <Toast />
  <ConfirmDialog />
  
  {#if isLoading}
    <div class="flex items-center justify-center min-h-screen bg-background" style="min-height: 100vh;">
      <div class="text-center">
        <div class="w-12 h-12 mx-auto mb-4 border-3 border-primary/30 border-t-primary rounded-full animate-spin"></div>
        <p class="text-muted-foreground text-sm">Loading...</p>
      </div>
    </div>
  {:else if pageComponent() === "login"}
    {#if LoginPage}
      <LoginPage />
    {:else}
      <div class="flex items-center justify-center min-h-screen"><div class="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div></div>
    {/if}
  {:else}
    <BlogNavigation />
  <main class="lg:ml-20 transition-all duration-300 ease-in-out overflow-x-hidden w-full max-w-full">
      <div class="mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 max-w-7xl w-full">
        {#if pageComponent() === "list"}
          <BlogListPage />

      {:else if pageComponent() === "create"}
        <div class="space-y-6 sm:space-y-8 animate-slide-up">
          <div class="relative space-y-3 pb-6 border-b-2 border-border/50">
            <div class="absolute -top-4 -left-4 w-24 h-24 bg-emerald-500/5 rounded-full blur-3xl"></div>
            <h1 class="relative text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight bg-linear-to-r from-emerald-600 dark:from-emerald-400 to-primary bg-clip-text text-transparent">
              Create New Post
            </h1>
            <p class="relative text-base sm:text-lg text-muted-foreground font-medium leading-relaxed">
              Share your thoughts and insights with the world
            </p>
          </div>
          {#if BlogCreatePage}
            <BlogCreatePage blogId={blogId()} />
          {:else}
            <div class="flex justify-center py-12"><div class="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div></div>
          {/if}
        </div>
      {:else if pageComponent() === "dashboard"}
        {#if BlogDashboardPage}
          <BlogDashboardPage />
        {:else}
          <div class="flex justify-center py-12"><div class="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div></div>
        {/if}
      {:else if pageComponent() === "detail" && blogId()}
        {#if BlogDetailPage}
          <BlogDetailPage blogId={blogId() || "1"} />
        {:else}
          <div class="flex justify-center py-12"><div class="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div></div>
        {/if}
      {:else if pageComponent() === "edit" && blogId()}
        <div class="space-y-6 sm:space-y-8 animate-slide-up">
          <div class="relative space-y-3 pb-6 border-b-2 border-border/50">
            <div class="absolute -top-4 -left-4 w-24 h-24 bg-amber-500/5 rounded-full blur-3xl"></div>
            <h1 class="relative text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight bg-linear-to-r from-amber-600 dark:from-amber-400 to-primary bg-clip-text text-transparent">
              Edit Post
            </h1>
            <p class="relative text-base sm:text-lg text-muted-foreground font-medium leading-relaxed">
              Update your blog post content
            </p>
          </div>
          {#if BlogCreatePage}
            <BlogCreatePage blogId={blogId()} />
          {:else}
            <div class="flex justify-center py-12"><div class="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div></div>
          {/if}
        </div>
        {/if}
      </div>
      <Footer />
    </main>
  {/if}
</div>
