use std::fmt::Debug;

fn main() {
    demonstrate_generics();
    demonstrate_traits();
    demonstrate_debug_trait();
    demonstrate_collections();
    demonstrate_iterators();
    demonstrate_custom_iterator();
    demonstrate_type_alias();
    demonstrate_error_handling();
}

fn demonstrate_generics() {
    println!("=== Generics ===\n");
    
    fn print_anything<T: Debug>(x: T) {
        println!("{:?}", x);
    }
    
    print_anything(42);
    print_anything("hello");
    print_anything(vec![1, 2, 3]);
    
    fn largest<T: PartialOrd>(a: T, b: T) -> T {
        if a > b { a } else { b }
    }
    
    println!("Largest: {}", largest(10, 20));
    println!("Largest: {}", largest(3.14, 2.71));
    
    struct Point<T> {
        x: T,
        y: T,
    }
    
    let int_point = Point { x: 5, y: 10 };
    let float_point = Point { x: 1.0, y: 4.0 };
    
    println!("Int point: ({}, {})", int_point.x, int_point.y);
    println!("Float point: ({}, {})", float_point.x, float_point.y);
}

fn demonstrate_traits() {
    println!("\n=== Traits ===\n");
    
    trait Speak {
        fn speak(&self);
        
        fn greet(&self) {
            println!("Hello!");
        }
    }
    
    struct Dog;
    struct Cat;
    
    impl Speak for Dog {
        fn speak(&self) {
            println!("Woof!");
        }
    }
    
    impl Speak for Cat {
        fn speak(&self) {
            println!("Meow!");
        }
        
        fn greet(&self) {
            println!("Meow meow!");
        }
    }
    
    let dog = Dog;
    let cat = Cat;
    
    dog.speak();
    dog.greet();
    cat.speak();
    cat.greet();
    
    trait Area {
        fn area(&self) -> f64;
    }
    
    struct Rectangle {
        width: f64,
        height: f64,
    }
    
    struct Circle {
        radius: f64,
    }
    
    impl Area for Rectangle {
        fn area(&self) -> f64 {
            self.width * self.height
        }
    }
    
    impl Area for Circle {
        fn area(&self) -> f64 {
            3.14159 * self.radius * self.radius
        }
    }
    
    let rect = Rectangle { width: 10.0, height: 5.0 };
    let circle = Circle { radius: 3.0 };
    
    println!("Rectangle area: {}", rect.area());
    println!("Circle area: {}", circle.area());
}

fn demonstrate_debug_trait() {
    println!("\n=== Debug Trait ===\n");
    
    #[derive(Debug)]
    struct Person {
        name: String,
        age: u32,
    }
    
    let person = Person {
        name: String::from("Alice"),
        age: 30,
    };
    
    println!("{:?}", person);
    println!("{:#?}", person);
    
    #[derive(Debug)]
    enum Status {
        Active,
        Inactive,
        Pending,
    }
    
    let status = Status::Active;
    println!("{:?}", status);
}

fn demonstrate_collections() {
    println!("\n=== Collections ===\n");
    
    let arr = [1, 2, 3, 4, 5];
    let vec = vec![10, 20, 30, 40, 50];
    
    fn sum_slice(slice: &[i32]) -> i32 {
        slice.iter().sum()
    }
    
    println!("Array sum: {}", sum_slice(&arr));
    println!("Vector sum: {}", sum_slice(&vec));
    println!("Partial vec sum: {}", sum_slice(&vec[1..4]));
    
    let mut numbers = vec![1, 2, 3, 4, 5];
    
    fn modify_slice(slice: &mut [i32]) {
        for item in slice.iter_mut() {
            *item *= 2;
        }
    }
    
    modify_slice(&mut numbers);
    println!("Modified: {:?}", numbers);
}

fn demonstrate_iterators() {
    println!("\n=== Iterators ===\n");
    
    let numbers = vec![1, 2, 3, 4, 5];
    
    let doubled: Vec<i32> = numbers.iter().map(|x| x * 2).collect();
    println!("Doubled: {:?}", doubled);
    
    let evens: Vec<i32> = numbers.iter()
        .filter(|&&x| x % 2 == 0)
        .copied()
        .collect();
    println!("Evens: {:?}", evens);
    
    let first_three: Vec<i32> = numbers.iter()
        .take(3)
        .copied()
        .collect();
    println!("First three: {:?}", first_three);
    
    let skip_two: Vec<i32> = numbers.iter()
        .skip(2)
        .copied()
        .collect();
    println!("Skip two: {:?}", skip_two);
    
    let sum: i32 = numbers.iter().sum();
    println!("Sum: {}", sum);
    
    let product: i32 = numbers.iter().product();
    println!("Product: {}", product);
    
    let found = numbers.iter().find(|&&x| x > 3);
    println!("Found > 3: {:?}", found);
    
    numbers.iter().for_each(|x| print!("{} ", x));
    println!();
}

fn demonstrate_custom_iterator() {
    println!("\n=== Custom Iterator ===\n");
    
    struct Counter {
        count: u32,
        max: u32,
    }
    
    impl Counter {
        fn new(max: u32) -> Counter {
            Counter { count: 0, max }
        }
    }
    
    impl Iterator for Counter {
        type Item = u32;
        
        fn next(&mut self) -> Option<Self::Item> {
            if self.count < self.max {
                self.count += 1;
                Some(self.count)
            } else {
                None
            }
        }
    }
    
    let counter = Counter::new(5);
    
    for num in counter {
        print!("{} ", num);
    }
    println!();
    
    let counter2 = Counter::new(10);
    let sum: u32 = counter2.sum();
    println!("Sum 1-10: {}", sum);
}

fn demonstrate_type_alias() {
    println!("\n=== Type Alias ===\n");
    
    type Kilometers = i32;
    type Result<T> = std::result::Result<T, String>;
    
    let distance: Kilometers = 100;
    println!("Distance: {} km", distance);
    
    fn divide(a: i32, b: i32) -> Result<i32> {
        if b == 0 {
            Err(String::from("Division by zero"))
        } else {
            Ok(a / b)
        }
    }
    
    match divide(10, 2) {
        Ok(result) => println!("10 / 2 = {}", result),
        Err(e) => println!("Error: {}", e),
    }
    
    match divide(10, 0) {
        Ok(result) => println!("Result: {}", result),
        Err(e) => println!("Error: {}", e),
    }
}

fn demonstrate_error_handling() {
    println!("\n=== Error Handling ===\n");
    
    fn parse_number(s: &str) -> Result<i32, String> {
        match s.parse::<i32>() {
            Ok(n) => Ok(n),
            Err(_) => Err(String::from("Failed to parse")),
        }
    }
    
    match parse_number("42") {
        Ok(n) => println!("Parsed: {}", n),
        Err(e) => println!("Error: {}", e),
    }
    
    match parse_number("abc") {
        Ok(n) => println!("Parsed: {}", n),
        Err(e) => println!("Error: {}", e),
    }
    
    let num = parse_number("100").unwrap();
    println!("Unwrapped: {}", num);
    
    let num = parse_number("200").expect("Should be valid number");
    println!("Expected: {}", num);
    
    let num = parse_number("invalid").unwrap_or_else(|_| {
        println!("Using fallback value");
        0
    });
    println!("With fallback: {}", num);
    
    fn process_numbers() -> Result<i32, String> {
        let a = parse_number("10")?;
        let b = parse_number("20")?;
        Ok(a + b)
    }
    
    match process_numbers() {
        Ok(sum) => println!("Sum: {}", sum),
        Err(e) => println!("Error: {}", e),
    }
}
