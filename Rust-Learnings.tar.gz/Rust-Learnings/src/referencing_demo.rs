fn main() {
    println!("╔══════════════════════════════════════════════════════╗");
    println!("║             Referencing & Dereferencing               ║");
    println!("║         Pointers, References & Auto-deref             ║");
    println!("╚══════════════════════════════════════════════════════╝\n");
    
    demonstrate_referencing();
    demonstrate_function_refs();
    demonstrate_reference_vs_raw_pointer();
    
    println!("\n╔══════════════════════════════════════════════════════╗");
    println!("║                   Demo Complete!                      ║");
    println!("╚══════════════════════════════════════════════════════╝");
}

fn demonstrate_referencing() {
    println!("=== Referencing Demo ===\n");
    
    let x = 5;
    let y = &x;
    println!("x = {}, y points to x, *y = {}", x, *y);
    
    let z = *y;
    println!("z = {} (copied value)", z);
    
    let w = &y;
    println!("**w = {} (double dereference)", **w);
    
    demonstrate_mutable_reference();
    demonstrate_auto_deref();
    demonstrate_as_ptr();
}

fn demonstrate_mutable_reference() {
    println!("\n--- Mutable Reference ---");
    
    let mut x = 5;
    let y = &mut x;
    *y = 50;
    println!("After *y = 50: x = {}", x);
    
    let mut a = 5;
    let b = &mut a;
    let c = &mut *b;
    *c = 120;
    println!("After **c = 120: a = {}", a);
}

fn demonstrate_auto_deref() {
    println!("\n--- Auto Dereferencing ---");
    
    let s = String::from("hello");
    
    let len1 = (&s).len();
    let len2 = s.len();
    
    println!("(&s).len() = {}", len1);
    println!("s.len() = {} (auto-deref)", len2);
    
    println!("Rust automatically dereferences for method calls!");
}

fn demonstrate_as_ptr() {
    println!("\n--- as_ptr() Demo ---");
    
    let s1 = String::from("hello");
    
    let ptr1 = s1.as_ptr();
    let len1 = s1.len();
    let cap1 = s1.capacity();
    
    println!("s1 - ptr: {:?}, len: {}, cap: {}", ptr1, len1, cap1);
    
    let s2 = s1;
    
    let ptr2 = s2.as_ptr();
    let len2 = s2.len();
    let cap2 = s2.capacity();
    
    println!("s2 - ptr: {:?}, len: {}, cap: {}", ptr2, len2, cap2);
    
    println!("\nPointers are the same - heap data not copied!");
    println!("Ownership moved, not data duplicated");
}

fn add_one(v: &mut i32) {
    *v += 1;
}

fn demonstrate_function_refs() {
    println!("\n--- References in Functions ---");
    
    let mut num = 10;
    println!("Before: {}", num);
    
    add_one(&mut num);
    println!("After add_one: {}", num);
}

fn demonstrate_reference_vs_raw_pointer() {
    println!("\n--- Reference vs Raw Pointer ---");
    
    let x = 42;
    
    let ref_x = &x;
    println!("Reference: {}", *ref_x);
    
    let ptr_x = &x as *const i32;
    unsafe {
        println!("Raw pointer: {}", *ptr_x);
    }
    
    println!("\nReferences: safe, checked, no null");
    println!("Raw pointers: unsafe, unchecked, can be null");
}
