fn main() {
    println!("╔══════════════════════════════════════════════════════╗");
    println!("║          Algebraic Data Types Demo                    ║");
    println!("║        Structs, Enums & Pattern Matching              ║");
    println!("╚══════════════════════════════════════════════════════╝\n");
    
    demonstrate_algebraic_types();
    demonstrate_visibility();
    
    println!("\n╔══════════════════════════════════════════════════════╗");
    println!("║                   Demo Complete!                      ║");
    println!("╚══════════════════════════════════════════════════════╝");
}

fn demonstrate_algebraic_types() {
    println!("=== Algebraic Data Types Demo ===\n");
    
    demonstrate_structs();
    demonstrate_enums();
    demonstrate_pattern_matching();
}

#[derive(Debug)]
struct Rectangle {
    width: u32,
    height: u32,
}

impl Rectangle {
    pub fn new(width: u32, height: u32) -> Rectangle {
        Rectangle { width, height }
    }
    
    pub fn area(&self) -> u32 {
        self.width * self.height
    }
    
    pub fn scale(&mut self, factor: u32) {
        self.width *= factor;
        self.height *= factor;
    }
    
    pub fn into_square(self) -> Square {
        let side = self.width.min(self.height);
        Square { side }
    }
}

#[derive(Debug)]
struct Square {
    side: u32,
}

fn demonstrate_structs() {
    println!("--- Structs ---");
    
    let rect = Rectangle::new(10, 20);
    println!("Rectangle: {:?}", rect);
    
    println!("Area: {}", rect.area());
    
    let mut rect2 = Rectangle::new(5, 10);
    println!("Before scale: {:?}", rect2);
    rect2.scale(2);
    println!("After scale: {:?}", rect2);
    
    let square = rect.into_square();
    println!("Converted to Square: {:?}", square);
    
    let rect3 = Rectangle::new(3, 4);
    borrow_rect(&rect3);
    println!("rect3 still valid: {:?}", rect3);
    
    let mut rect4 = Rectangle::new(6, 8);
    borrow_rect_mut(&mut rect4);
    println!("rect4 after mutation: {:?}", rect4);
}

fn borrow_rect(r: &Rectangle) {
    println!("Borrowed (immutable): area = {}", r.area());
}

fn borrow_rect_mut(r: &mut Rectangle) {
    r.scale(2);
    println!("Borrowed (mutable): scaled");
}

#[derive(Debug)]
enum Message {
    Quit,
    Move { x: i32, y: i32 },
    Write(String),
    ChangeColor(u8, u8, u8),
}

impl Message {
    pub fn process(&self) {
        match self {
            Message::Quit => println!("Quit message"),
            Message::Move { x, y } => println!("Move to ({}, {})", x, y),
            Message::Write(text) => println!("Write: {}", text),
            Message::ChangeColor(r, g, b) => println!("Color: rgb({}, {}, {})", r, g, b),
        }
    }
}

fn demonstrate_enums() {
    println!("\n--- Enums ---");
    
    let msg1 = Message::Quit;
    let msg2 = Message::Move { x: 10, y: 20 };
    let msg3 = Message::Write(String::from("Hello"));
    let msg4 = Message::ChangeColor(255, 0, 0);
    
    println!("Messages:");
    msg1.process();
    msg2.process();
    msg3.process();
    msg4.process();
}

fn demonstrate_pattern_matching() {
    println!("\n--- Pattern Matching ---");
    
    let some_value: Option<i32> = Some(5);
    let no_value: Option<i32> = None;
    
    match some_value {
        Some(n) => println!("Value: {}", n),
        None => println!("No value"),
    }
    
    match no_value {
        Some(n) => println!("Value: {}", n),
        None => println!("No value"),
    }
    
    let success: Result<i32, String> = Ok(42);
    let failure: Result<i32, String> = Err(String::from("Error occurred"));
    
    match success {
        Ok(val) => println!("Success: {}", val),
        Err(e) => println!("Error: {}", e),
    }
    
    match failure {
        Ok(val) => println!("Success: {}", val),
        Err(e) => println!("Error: {}", e),
    }
    
    if let Some(n) = some_value {
        println!("if let: {}", n);
    }
}

pub struct BankAccount {
    owner: String,
    balance: f64,
}

impl BankAccount {
    pub fn new(owner: String) -> BankAccount {
        BankAccount {
            owner,
            balance: 0.0,
        }
    }
    
    pub fn deposit(&mut self, amount: f64) {
        self.balance += amount;
    }
    
    pub fn balance(&self) -> f64 {
        self.balance
    }
}

fn demonstrate_visibility() {
    println!("\n--- Visibility (pub) ---");
    
    let mut account = BankAccount::new(String::from("Alice"));
    println!("Initial balance: {}", account.balance());
    
    account.deposit(100.0);
    println!("After deposit: {}", account.balance());
}
