fn main() {
    println!("╔══════════════════════════════════════════════════════╗");
    println!("║              Base Concepts Demo                       ║");
    println!("║          RustUp, Cargo & Project Structure            ║");
    println!("╚══════════════════════════════════════════════════════╝\n");
    
    demonstrate_base_concepts();
    
    println!("\n╔══════════════════════════════════════════════════════╗");
    println!("║                   Demo Complete!                      ║");
    println!("╚══════════════════════════════════════════════════════╝");
}

fn demonstrate_base_concepts() {
    println!("=== Base Concepts Demo ===\n");
    
    println!("Common Cargo commands:");
    println!("  cargo new <name>      - Create new project");
    println!("  cargo build           - Compile (debug)");
    println!("  cargo run             - Build + run");
    println!("  cargo build --release - Optimized build");
    println!("  cargo update          - Update dependencies");
    println!("  cargo fmt             - Format code");
    
    println!("\nNaming convention: snake_case");
    let my_variable = 42;
    println!("  Variable: my_variable = {}", my_variable);
}
