use std::rc::Rc;
use std::cell::RefCell;

fn main() {
    demonstrate_closures();
    demonstrate_iterator_adapters();
    demonstrate_smart_pointers();
    demonstrate_borrow_checker_rules();
    demonstrate_lifetimes();
    demonstrate_lifetime_structs();
    demonstrate_static_lifetime();
}

fn demonstrate_closures() {
    println!("=== Closures ===\n");
    
    let x = 10;
    let immutable_closure = || println!("x = {}", x);
    immutable_closure();
    
    let mut y = 20;
    let mut mutable_closure = || {
        y += 1;
        println!("y = {}", y);
    };
    mutable_closure();
    mutable_closure();
    
    let s = String::from("hello");
    let move_closure = move || {
        println!("s = {}", s);
    };
    move_closure();
    
    let numbers = vec![1, 2, 3, 4, 5];
    let doubled: Vec<i32> = numbers.iter().map(|x| x * 2).collect();
    println!("Doubled: {:?}", doubled);
    
    let evens: Vec<i32> = numbers.iter()
        .filter(|&&x| x % 2 == 0)
        .copied()
        .collect();
    println!("Evens: {:?}", evens);
    
    fn apply_operation<F>(x: i32, f: F) -> i32
    where
        F: Fn(i32) -> i32,
    {
        f(x)
    }
    
    let result = apply_operation(5, |x| x * x);
    println!("Square of 5: {}", result);
    
    let add_ten = |x| x + 10;
    println!("5 + 10 = {}", add_ten(5));
}

fn demonstrate_iterator_adapters() {
    println!("\n=== Iterator Adapters ===\n");
    
    let numbers = vec![1, 2, 3, 4, 5];
    
    let result: Vec<i32> = numbers.iter()
        .copied()
        .map(|x| x * 2)
        .filter(|x| *x > 5)
        .take(3)
        .collect();
    
    println!("Chained operations: {:?}", result);
    
    let sum: i32 = numbers.iter()
        .map(|x| x * x)
        .sum();
    println!("Sum of squares: {}", sum);
    
    let found = numbers.iter()
        .find(|&&x| x > 3);
    println!("First > 3: {:?}", found);
    
    numbers.iter()
        .enumerate()
        .for_each(|(i, x)| println!("Index {}: {}", i, x));
}

fn demonstrate_smart_pointers() {
    println!("\n=== Smart Pointers ===\n");
    
    let boxed = Box::new(42);
    println!("Box: {}", boxed);
    
    let x = Rc::new(5);
    let y = Rc::clone(&x);
    let _z = Rc::clone(&x);
    
    println!("Rc value: {}", x);
    println!("Rc count: {}", Rc::strong_count(&x));
    
    drop(y);
    println!("After drop: {}", Rc::strong_count(&x));
    
    let data = RefCell::new(5);
    
    {
        let mut borrow = data.borrow_mut();
        *borrow += 1;
    }
    
    println!("RefCell value: {}", data.borrow());
    
    let shared = Rc::new(RefCell::new(10));
    let a = Rc::clone(&shared);
    let b = Rc::clone(&shared);
    
    *a.borrow_mut() += 5;
    *b.borrow_mut() += 10;
    
    println!("Shared mutable: {}", shared.borrow());
    
    struct Node {
        value: i32,
        next: Option<Box<Node>>,
    }
    
    let list = Node {
        value: 1,
        next: Some(Box::new(Node {
            value: 2,
            next: Some(Box::new(Node {
                value: 3,
                next: None,
            })),
        })),
    };
    
    println!("List head: {}", list.value);
}

fn demonstrate_borrow_checker_rules() {
    println!("\n=== Borrow Checker Rules ===\n");
    
    let s = String::from("hello");
    let r1 = &s;
    let r2 = &s;
    println!("r1: {}, r2: {}", r1, r2);
    
    let mut s = String::from("hello");
    let r1 = &s;
    let r2 = &s;
    println!("{} {}", r1, r2);
    
    let r3 = &mut s;
    r3.push_str(" world");
    println!("{}", r3);
    
    let mut s = String::from("hello");
    {
        let r1 = &mut s;
        r1.push_str(" world");
    }
    {
        let r2 = &mut s;
        r2.push_str("!");
    }
    println!("{}", s);
}

fn demonstrate_lifetimes() {
    println!("\n=== Lifetimes ===\n");
    
    fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
        if x.len() > y.len() {
            x
        } else {
            y
        }
    }
    
    let s1 = String::from("long string");
    let s2 = String::from("short");
    
    let result = longest(&s1, &s2);
    println!("Longest: {}", result);
    
    fn first_word<'a>(s: &'a str) -> &'a str {
        let bytes = s.as_bytes();
        
        for (i, &item) in bytes.iter().enumerate() {
            if item == b' ' {
                return &s[0..i];
            }
        }
        
        &s[..]
    }
    
    let sentence = String::from("hello world");
    let word = first_word(&sentence);
    println!("First word: {}", word);
    
    fn larger<'a>(x: &'a i32, y: &'a i32) -> &'a i32 {
        if x > y { x } else { y }
    }
    
    let a = 10;
    let b = 20;
    let max = larger(&a, &b);
    println!("Larger: {}", max);
}

fn demonstrate_lifetime_structs() {
    println!("\n=== Lifetime in Structs ===\n");
    
    struct Excerpt<'a> {
        text: &'a str,
    }
    
    impl<'a> Excerpt<'a> {
        fn get_text(&self) -> &str {
            self.text
        }
        
        fn announce(&self, announcement: &str) -> &str {
            println!("{}", announcement);
            self.text
        }
    }
    
    let novel = String::from("Call me Ishmael. Some years ago...");
    let first_sentence = novel.split('.').next().unwrap();
    let excerpt = Excerpt { text: first_sentence };
    
    println!("Excerpt: {}", excerpt.get_text());
    excerpt.announce("Announcing!");
    
    struct ImportantExcerpt<'a> {
        part: &'a str,
    }
    
    let text = String::from("The quick brown fox");
    let words: Vec<&str> = text.split_whitespace().collect();
    let excerpt = ImportantExcerpt { part: words[0] };
    println!("Important: {}", excerpt.part);
}

fn demonstrate_static_lifetime() {
    println!("\n=== Static Lifetime ===\n");
    
    let s: &'static str = "I have a static lifetime";
    println!("{}", s);
    
    static GREETING: &str = "Hello, world!";
    println!("{}", GREETING);
    
    fn return_static() -> &'static str {
        "This is static"
    }
    
    println!("{}", return_static());
    
    const MAX_POINTS: u32 = 100_000;
    println!("Max points: {}", MAX_POINTS);
}
