fn main() {
    println!("╔══════════════════════════════════════════════════════╗");
    println!("║          Functions and Ownership Demo                 ║");
    println!("║         Parameters, Returns & Memory Safety           ║");
    println!("╚══════════════════════════════════════════════════════╝\n");
    
    demonstrate_functions_ownership();
    
    println!("\n╔══════════════════════════════════════════════════════╗");
    println!("║                   Demo Complete!                      ║");
    println!("╚══════════════════════════════════════════════════════╝");
}

fn demonstrate_functions_ownership() {
    println!("=== Functions and Ownership Demo ===\n");
    
    print_hello_world();
    
    let num: u8 = 10;
    print_value(num);
    
    let result = multiply_by_two(num);
    println!("Multiplied: {}", result);
    
    demonstrate_ownership();
    demonstrate_stack_heap();
}

fn print_hello_world() {
    println!("Hello World!");
}

fn print_value(item: u8) {
    println!("The value is: {}", item);
}

fn multiply_by_two(item: u8) -> u8 {
    item * 2
}

fn demonstrate_ownership() {
    println!("\n--- Ownership Rules ---");
    
    let s1 = String::from("hello");
    println!("s1 owns: {}", s1);
    
    let s2 = s1;
    println!("s2 owns: {}", s2);
    
    let x = 5;
    let y = x;
    println!("x={}, y={} (both valid)", x, y);
    
    let s3 = String::from("world");
    let s4 = s3.clone();
    println!("s3={}, s4={} (both valid)", s3, s4);
    
    {
        let s5 = String::from("temporary");
        println!("s5 in scope: {}", s5);
    }
    
    let s = String::from("ownership test");
    takes_ownership(s);
    
    let x = 5;
    takes_copy(x);
    println!("After takes_copy: x={}", x);
}

fn demonstrate_stack_heap() {
    println!("\n--- Stack vs Heap ---");
    
    let stack_int: i32 = 42;
    let stack_bool: bool = true;
    println!("Stack: int={}, bool={}", stack_int, stack_bool);
    
    let heap_string = String::from("allocated on heap");
    let heap_vec = vec![1, 2, 3];
    println!("Heap: string={}, vec={:?}", heap_string, heap_vec);
    
    println!("\nString consists of:");
    println!("  ptr -> heap address");
    println!("  len -> {} bytes", heap_string.len());
    println!("  capacity -> {} bytes", heap_string.capacity());
}

fn takes_ownership(s: String) {
    println!("Function owns: {}", s);
}

fn takes_copy(x: i32) {
    println!("Function has copy: {}", x);
}
