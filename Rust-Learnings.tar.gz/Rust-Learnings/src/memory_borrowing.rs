fn main() {
    println!("╔══════════════════════════════════════════════════════╗");
    println!("║           Memory and Borrowing Demo                   ║");
    println!("║        References & Borrowing Rules                   ║");
    println!("╚══════════════════════════════════════════════════════╝\n");
    
    demonstrate_memory_borrowing();
    demonstrate_reference_lifetime();
    demonstrate_string_literal_borrowing();
    
    println!("\n╔══════════════════════════════════════════════════════╗");
    println!("║                   Demo Complete!                      ║");
    println!("╚══════════════════════════════════════════════════════╝");
}

fn demonstrate_memory_borrowing() {
    println!("=== Memory and Borrowing Demo ===\n");
    
    let s = String::from("hello");
    let len = calculate_length(&s);
    println!("String: '{}', Length: {}", s, len);
    
    let mut s = String::from("hello");
    append_world(&mut s);
    println!("After mutation: {}", s);
    
    demonstrate_borrowing_rules();
    demonstrate_data_race_prevention();
    demonstrate_no_dangling();
}

fn calculate_length(s: &String) -> usize {
    s.len()
}

fn append_world(s: &mut String) {
    s.push_str(" world");
}

fn demonstrate_borrowing_rules() {
    println!("\n--- Borrowing Rules ---");
    
    let mut s = String::from("hello");
    
    let r1 = &s;
    let r2 = &s;
    println!("r1: {}, r2: {}", r1, r2);
    
    let r3 = &mut s;
    r3.push_str("!");
    println!("r3: {}", r3);
}

fn demonstrate_data_race_prevention() {
    println!("\n--- Data Race Prevention ---");
    println!("Rust prevents data races at compile time:");
    println!("  1. Two or more pointers access same data");
    println!("  2. At least one writes");
    println!("  3. No synchronization");
    println!("Borrowing rules make this impossible!");
}

fn demonstrate_no_dangling() {
    println!("\n--- No Dangling References ---");
    
    fn no_dangle() -> String {
        String::from("hello")
    }
    
    let s = no_dangle();
    println!("Owned string (no dangle): {}", s);
}

fn demonstrate_reference_lifetime() {
    println!("\n--- Reference Lifetime ---");
    
    let s = String::from("hello");
    
    let r1 = &s;
    let r2 = &s;
    println!("{} and {}", r1, r2);
    
    let mut s2 = String::from("world");
    let r3 = &mut s2;
    r3.push_str("!");
    println!("{}", r3);
}

fn demonstrate_string_literal_borrowing() {
    println!("\n--- String Literal Borrowing ---");
    
    let s1: &str = "Hello";
    let s2: &str = s1;
    println!("s1: {}, s2: {}", s1, s2);
    println!("No move, no ownership - both are references");
}
