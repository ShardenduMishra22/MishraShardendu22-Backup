fn main() {
    println!("╔══════════════════════════════════════════════════════╗");
    println!("║           Introduction to Rust Concepts               ║");
    println!("║      Statically Typed & System Programming            ║");
    println!("╚══════════════════════════════════════════════════════╝\n");
    
    demonstrate_intro_concepts();
    
    println!("\n╔══════════════════════════════════════════════════════╗");
    println!("║                   Demo Complete!                      ║");
    println!("╚══════════════════════════════════════════════════════╝");
}

fn demonstrate_intro_concepts() {
    println!("=== Introduction Concepts Demo ===\n");
    
    let x: i32 = 10;
    println!("Statically typed variable: x = {}", x);
    
    let my_value = 100;
    let another_variable = "Hello";
    println!("snake_case variables: {}, {}", my_value, another_variable);
    
    println!("\nRust is used for:");
    println!("  - Operating systems");
    println!("  - Browsers (Firefox)");
    println!("  - Game engines");
    println!("  - Network servers");
    println!("  - No garbage collector");
    println!("  - Direct memory control");
    
    println!("\nCompiler ensures:");
    println!("  - No use-after-free");
    println!("  - No data races");
    println!("  - No null pointer access");
}
