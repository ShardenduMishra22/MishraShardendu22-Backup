fn main() {
    println!("╔══════════════════════════════════════════════════════╗");
    println!("║                   Types Demo                          ║");
    println!("║        Data Types, Mutability & Strings               ║");
    println!("╚══════════════════════════════════════════════════════╝\n");
    
    demonstrate_types();
    demonstrate_string_conversion();
    
    println!("\n╔══════════════════════════════════════════════════════╗");
    println!("║                   Demo Complete!                      ║");
    println!("╚══════════════════════════════════════════════════════╝");
}

fn demonstrate_types() {
    println!("=== Types Demo ===\n");
    
    let unsigned: u8 = 255;
    let signed: i8 = -128;
    println!("Integers: u8={}, i8={}", unsigned, signed);
    
    let immutable = 10;
    println!("Immutable: {}", immutable);
    
    let mut mutable = 10;
    println!("Mutable before: {}", mutable);
    mutable = 20;
    println!("Mutable after: {}", mutable);
    
    let string_literal: &str = "Hello";
    println!("String literal (&str): {}", string_literal);
    
    let mut owned_string = String::from("Hello");
    owned_string.push_str(" World");
    println!("String (heap): {}", owned_string);
    
    let tuple: (&str, i32) = ("Age", 25);
    println!("Tuple: {} = {}", tuple.0, tuple.1);
    
    let (label, value) = tuple;
    println!("Destructured: {} = {}", label, value);
    
    let inferred = 42;
    let inferred_float = 3.14;
    println!("Inferred types: {} (i32), {} (f64)", inferred, inferred_float);
}

fn demonstrate_string_conversion() {
    println!("\n=== String Conversion ===");
    
    let literal = "hello";
    let owned = String::from(literal);
    let owned2 = literal.to_string();
    
    println!("String conversions:");
    println!("  &str: {}", literal);
    println!("  String: {}, {}", owned, owned2);
}
