use std::mem;

fn main() {
    println!("╔══════════════════════════════════════════════════════╗");
    println!("║          Detailed Data Types Demo                     ║");
    println!("║    Scalars, Arrays, Vectors, Loops & Control Flow     ║");
    println!("╚══════════════════════════════════════════════════════╝\n");
    
    demonstrate_data_types();
    
    println!("\n╔══════════════════════════════════════════════════════╗");
    println!("║                   Demo Complete!                      ║");
    println!("╚══════════════════════════════════════════════════════╝");
}

fn demonstrate_data_types() {
    println!("=== Detailed Data Types Demo ===\n");
    
    demonstrate_scalar_types();
    demonstrate_arrays();
    demonstrate_tuples();
    demonstrate_vectors();
    demonstrate_control_flow();
    demonstrate_loops();
    demonstrate_match();
}

fn demonstrate_scalar_types() {
    println!("--- Scalar Types ---");
    
    let a: i32 = 10;
    let b: u8 = 255;
    println!("Integers: i32={}, u8={}", a, b);
    
    let x: f32 = 3.14;
    let y = 6.28;
    println!("Floats: f32={}, f64={}", x, y);
    
    let is_raining = true;
    let is_sunny = false;
    let need_umbrella = is_raining && !is_sunny;
    println!("Bool: need_umbrella={}", need_umbrella);
    
    let letter = 'a';
    let emoji = '😀';
    let kanji = '漢';
    println!("Char: {}, {}, {} (4 bytes each)", letter, emoji, kanji);
    
    println!("\nSizes:");
    println!("  i32: {} bytes", mem::size_of::<i32>());
    println!("  f64: {} bytes", mem::size_of::<f64>());
    println!("  char: {} bytes", mem::size_of::<char>());
    println!("  bool: {} bytes", mem::size_of::<bool>());
}

fn demonstrate_arrays() {
    println!("\n--- Arrays ---");
    
    let a1 = [10, 11, 12];
    println!("Array: {:?}", a1);
    println!("Type: [i32; 3], Length: {}", a1.len());
    
    println!("First: {}, Last: {}", a1[0], a1[2]);
    
    let mut a2 = [10, 11, 12];
    a2[0] = 9;
    println!("After mutation: {:?}", a2);
    
    print!("Iteration: ");
    for x in a2.iter() {
        print!("{} ", x);
    }
    println!();
    
    let a3 = [32; 5];
    println!("Repeated: {:?}", a3);
    
    let a4: [i64; 3];
    a4 = [100, 200, 300];
    println!("Late init: {:?}", a4);
}

fn demonstrate_tuples() {
    println!("\n--- Tuples ---");
    
    let t = ("Age", 25, true);
    println!("Tuple: {:?}", t);
    
    println!("  t.0 = {}", t.0);
    println!("  t.1 = {}", t.1);
    println!("  t.2 = {}", t.2);
    
    let (label, age, flag) = t;
    println!("Destructured: {}, {}, {}", label, age, flag);
}

fn demonstrate_vectors() {
    println!("\n--- Vectors ---");
    
    let mut v: Vec<i32> = Vec::new();
    v.push(1);
    v.push(2);
    v.push(3);
    println!("Vector: {:?}", v);
    
    let v1 = vec![1, 2, 3, 4, 5];
    println!("vec! macro: {:?}", v1);
    
    let v2: Vec<i32> = vec![0; 5];
    println!("Repeated: {:?}", v2);
    
    println!("v1[0] = {}", v1[0]);
    
    match v1.get(0) {
        Some(val) => println!("v1.get(0) = {}", val),
        None => println!("Index out of bounds"),
    }
    
    print!("Iteration: ");
    for x in &v1 {
        print!("{} ", x);
    }
    println!();
}

fn demonstrate_control_flow() {
    println!("\n--- Control Flow ---");
    
    let number = 6;
    
    if number % 2 == 0 {
        println!("{} is even", number);
    } else {
        println!("{} is odd", number);
    }
    
    let score = 85;
    if score >= 90 {
        println!("Grade: A");
    } else if score >= 80 {
        println!("Grade: B");
    } else {
        println!("Grade: C");
    }
}

fn demonstrate_loops() {
    println!("\n--- Loops ---");
    
    print!("While: ");
    let mut count = 0;
    while count < 5 {
        print!("{} ", count);
        count += 1;
    }
    println!();
    
    print!("For: ");
    let arr = [10, 20, 30];
    for element in &arr {
        print!("{} ", element);
    }
    println!();
    
    print!("Range: ");
    for i in 0..5 {
        print!("{} ", i);
    }
    println!();
    
    print!("Loop: ");
    let mut counter = 0;
    let result = loop {
        counter += 1;
        if counter == 5 {
            break counter * 2;
        }
    };
    println!("result = {}", result);
}

fn demonstrate_match() {
    println!("\n--- Match ---");
    
    let number = 3;
    
    match number {
        1 => println!("One"),
        2 => println!("Two"),
        3 | 4 | 5 => println!("Three to Five"),
        _ => println!("Something else"),
    }
    
    let x = 10;
    match x {
        n if n % 2 == 0 => println!("{} is even", n),
        n if n % 2 != 0 => println!("{} is odd", n),
        _ => println!("Never reaches here"),
    }
}
