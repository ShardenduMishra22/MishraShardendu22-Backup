# Functions and Ownership in Rust

## 1) Simple Function

```rust
fn main() {
    let num: u8 = 10;
    print_hello_world();
}

fn print_hello_world() {
    println!("Hello World!");
}
```

What this shows:

* `fn` declares a function
* `main()` is program entry point
* Functions can be defined outside `main`
* Function must be declared before use OR later (Rust allows both)

No parameters.
No return value.
Pure side-effect (printing).

---

## 2) Function With Parameter

```rust
fn main() {
    let num: u8 = 10;
    print(num);
}

fn print(item: u8) {
    println!("The value of num is {}", item);
}
```

What changed:

* Function accepts input: `item: u8`
* Type must be specified
* Argument passed by value

Meaning:

```md
main -> sends num
print -> receives as item
```

---

## 3) Function With Return Value

```rust
fn main() {
    let num: u8 = 10;
    let value = multiply_by_two(num);
    println!("Num multiplied by two is {}", value);
}

fn multiply_by_two(item: u8) -> u8 {
    return item * 2;
}
```

Key additions:

* `-> u8` specifies return type
* Function produces a value
* Caller stores returned result

Rust shortcut:

```rust
item * 2
```

(no `return` needed if last expression)

---

## 4) Ownership (Module Intro)

Ownership = Rust’s memory safety system.

Goals:

* No dangling pointers
* No double free
* No memory leaks
* No garbage collector

Rust enforces these at **compile time**.

---

## 5) Memory Management (Concept)

Steps shown:

1. Allocate memory
2. Initialize memory
3. Free memory

In unsafe languages:

```md
ptr -> memory
ptr -> value
free(memory)
ptr still exists ❌
```

Pointer now points to freed memory → dangling pointer.

Using it = undefined behavior.

---

## 6) C Memory Management Example

C code uses:

```c
malloc()
free()
```

Programmer responsibilities:

* Check allocation success
* Write value
* Free memory
* Must NOT use pointer after free

If used:

* Crash
* Garbage value
* Security vulnerability

C gives **full control** but **no safety**.

---

## 7) Python Memory Management

Python uses:

* Reference counting
* Garbage collector

You delete references:

```python
del obj
```

When reference count = 0 → memory reclaimed.

You **do not control exact moment** of free.

Safe but unpredictable.

---

## 8) Garbage Collection Comparison

| Language | Memory Reclamation |
| -------- | ------------------ |
| C        | Manual             |
| Java     | Automatic GC       |
| Python   | Automatic GC       |
| Rust     | Ownership system   |

Rust = no GC, but still safe.

---

## 9) Stack vs Heap

### Stack

* Fixed-size data
* Known at compile time
* Fast
* Auto allocate/deallocate

Examples:

```md
i32
bool
char
```

---

### Heap

* Dynamic size
* Runtime allocation
* Slower
* Used for growable data

Examples:

```md
String
Vec
Box
```

---

## 10) Why Rust Cares About Stack vs Heap

Rust tracks:

* Who owns heap memory
* When it goes out of scope
* Frees automatically

Example:

```rust
{
    let s = String::from("hi");
} // memory freed here
```

No GC. No free(). No leaks.

---

## One-Line Mental Model

C → You manage memory
Python/Java → Runtime manages memory
Rust → Compiler manages memory

---

These slides continue the **ownership + move semantics** story.

I’ll explain them in the same order conceptually.

---

## 1) Ownership Rules (Recap)

Rust enforces:

1. Every value has an owner
2. Only one owner at a time
3. When owner goes out of scope → value is dropped

This is compile-time enforced.

---

## 2) Variable Scope

Scope = where a variable is valid.

```rust
{
    let x = 5;
} // x destroyed here
```

After block → `x` no longer exists.

If variable owns heap memory → memory freed here.

---

## 3) String Type Internals

```rust
let my_string = String::from("Hello");
```

Creates:

Stack (small object):

```md
ptr -> heap address
len -> 5
capacity -> 5
```

Heap:

```md
H e l l o
```

Important:

* Stack stores metadata
* Heap stores actual characters

---

## 4) Rust Approach (Copy Type)

```rust
let x = 2;
let y = x;
```

Integers implement **Copy**.

Result:

```md
x = 2
y = 2
```

Two independent values.

No ownership change.

Why:

* Fixed size
* Cheap to copy
* Stored on stack

---

## 5) Rust Approach (String Move)

```rust
let s1 = String::from("hello");
let s2 = s1;
```

What actually happens:

* Stack data is copied (ptr, len, cap)
* Heap data is NOT copied
* Ownership is MOVED

After move:

```md
s1 -> invalid
s2 -> owner
```

Using `s1` now = compile error.

---

## 6) Why Move Exists

If Rust allowed both:

```md
s1 and s2 -> same heap
```

When scope ends:

```md
drop(s1)
drop(s2)
```

Two frees → double free → memory corruption.

Rust prevents this by:

Invalidating `s1`.

---

## 7) Visualization Meaning

Boxes show:

Stack:

```md
s2:
ptr -> heap
len
cap
```

Heap:

```md
h e l l o
```

`s1` is crossed out → no longer usable.

---

## 8) How To Actually Duplicate String

If you want two independent heap copies:

```rust
let s1 = String::from("hello");
let s2 = s1.clone();
```

Now:

* Two heap allocations
* Two owners

---

## 9) Drop Function

When owner goes out of scope:

```rust
drop(value)
```

Runs automatically.

For String:

* Frees heap buffer

You never call `free`.

Rust inserts drop calls.

---

## 10) Mental Model

Copy types → duplicated
Heap types → moved
Clone → deep copy

---

### One Sentence Summary

Rust avoids garbage collection and memory bugs by enforcing single ownership and move semantics, automatically freeing heap memory when the owner leaves scope.

---

Below is a **clean, consolidated explanation** of the remaining slides.

---

## 1) String Literal vs String Type (Reinforced)

`"hello"` → `&str`
`String::from("hello")` → `String`

* `&str` → immutable, fixed, stored in binary
* `String` → heap allocated, mutable, growable

Key point:
Heap allocation is why `String` involves ownership rules.

---

## 2) Ownership Rules

1. Every value has an owner
2. Only one owner at a time
3. When owner goes out of scope → value dropped

Purpose: Prevent memory bugs at compile time.

---

## 3) Variable Scope

A variable exists only inside its `{ }` block.

```rust
{
    let x = 5;
}
// x invalid here
```

When variable leaves scope → Rust automatically frees owned memory.

---

## 4) String Internal Layout

A `String` consists of:

```md
ptr      -> heap address
len      -> used bytes
capacity -> allocated bytes
```

Struct stored on **stack**
Characters stored on **heap**

---

## 5) Move Semantics (String Assignment)

```rust
let s1 = String::from("hello");
let s2 = s1;
```

What happens:

* ptr, len, capacity copied to s2
* s1 is INVALIDATED
* Heap data NOT duplicated

Why:

Prevents two owners of same heap memory.

Using `s1` after move → compile error.

---

## 6) Why Rust Does This

If both owned same heap:

* Both would call `drop`
* Memory freed twice
* Crash / corruption

Rust avoids this by **move + invalidate**.

---

## 7) Clone (Deep Copy)

```rust
let s1 = String::from("hello");
let s2 = s1.clone();
```

Now:

* Heap data duplicated
* Two independent Strings
* Both valid

Cost: Expensive (alloc + copy)

Use only when necessary.

---

## 8) Copy Types (Primitive Types)

```rust
let x: u8 = 5;
let y = x;
```

Works fine.

Reason:

* Stored on stack
* Fixed size
* Cheap to copy

These types implement `Copy`:

* Integers
* Floats
* Bool
* Char
* Tuples of Copy types

No ownership transfer.

---

## 9) Rust Drop Mechanism

When owner leaves scope:

```rust
drop(value)
```

Called automatically.

String’s `drop` frees heap memory.

No garbage collector.

---

## 10) Rust Memory Model (Big Picture)

| Type Category | Behavior |
| ------------- | -------- |
| Stack types   | Copied   |
| Heap types    | Moved    |
| String        | Moved    |
| Vec           | Moved    |
| Box           | Moved    |

---

## Mental Model

* Stack data → copy
* Heap data → move
* Want duplicate heap data → clone
* Owner gone → memory freed

---
