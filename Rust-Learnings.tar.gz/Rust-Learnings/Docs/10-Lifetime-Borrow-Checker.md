# Lifetime & Borrow Checker

---

## 1. Closures

* Anonymous functions that capture environment.
* Traits chosen automatically:

  * `Fn` → immutable borrow
  * `FnMut` → mutable borrow
  * `FnOnce` → move ownership

Rule:

```md
move capture → FnOnce
mut borrow   → FnMut
imm borrow   → Fn
```

---

## 2. Iterators

* Adapters (`map`, `filter`, `take`, `skip`) are **lazy**
* Nothing runs until a **consumer**:

  * `collect`, `find`, `reduce`, `for_each`, `for`

Pipeline model:

```md
iterator → adapters → consumer (executes)
```

---

## 3. Packages / Crates / Modules

* Package = project
* Crate = compilation unit
* `mod name;` loads module
* `pub` required for cross-module access
* `crate::` = crate root

---

## 4. Smart Pointers

* `Box<T>` → single owner heap
* `Rc<T>` → shared owner (single thread)
* `Arc<T>` → shared owner (multi thread)
* `RefCell<T>` → runtime borrow check
* `Mutex<T>` / `RwLock<T>` → thread-safe interior mutability

---

## 5. Borrow Checker Core Rules

* Many immutable OR one mutable
* Never both
* Reference must not outlive data

Formal rule:

```md
lifetime(reference) <= lifetime(value)
```

---

## 6. Lifetime vs Scope

* Scope = where name is usable
* Lifetime = how long value is valid
* Often same, not guaranteed

---

## 7. Dangling Reference

```md
let r;
{
   let x = 5;
   r = &x;   // x dies
}
```

Rejected.

---

## 8. Explicit Lifetime Parameters

Used when compiler cannot infer.

```md
fn larger<'a>(x: &'a i32, y: &'a i32) -> &'a i32
```

Meaning:

* x ≥ 'a
* y ≥ 'a
* return = 'a

Returned ref lives as long as **shortest input**.

---

## 9. Multiple Lifetimes

```md
fn foo<'a,'b>(x:&'a i32, y:&'b i32)
```

No relation unless tied.

---

## 10. Lifetimes Are Descriptive

* Do NOT extend life
* Do NOT shorten life
* Only describe relationships

---

## 11. Structs With References Need Lifetimes

Bad:

```md
struct S { r: &i32 }
```

Good:

```md
struct S<'a> { r: &'a i32 }
```

Owned fields → no lifetimes.

---

## 12. No Reference → No Problems

Struct storing values instead of refs avoids lifetimes entirely.

---

## 13. 'static Lifetime

* Valid for entire program
* Common source: string literals

```md
let s: &'static str = "hello";
```

---

## 14. Unconstrained Lifetime Defaults to 'static

```md
fn f<'a>() {
   let x = 5;
   let y: &'a i32 = &x; // ERROR
}
```

Trying to store short-lived ref into long-lived promise.

---

## 15. Mental Model

* Ownership handles memory
* References require lifetimes
* Lifetimes = constraints
* Compiler solves constraint system
* If constraints impossible → error
