# Rust Data Types

## 1) Data Types (Big Picture)

Rust splits types into:

### Scalar (single value)

* Integer
* Float
* Bool
* Character

### Compound (group of values)

* Array
* Tuple
* String
* Vector

---

## 2) Scalar Types

### Integer

Whole numbers.

Examples:

```rust
let a: i32 = 10;
let b: u8 = 255;
```

* Signed: `i8 i16 i32 i64 i128`
* Unsigned: `u8 u16 u32 u64 u128`
* Default: `i32`

---

### Float

Decimal numbers.

Two types:

```rust
f32  // 32-bit
f64  // 64-bit (default)
```

Example:

```rust
let x: f32 = 3.14;
let y = 6.28;   // f64 by default
```

Why f64 default:

* Same speed as f32 on modern CPUs
* Higher precision

All floats are signed.

---

### Bool

True or false.

```rust
let is_raining: bool = true;
let is_sunny = false;
```

Logical ops:

```rust
&&   AND
||   OR
!    NOT
```

Example:

```rust
let need_umbrella = is_raining && !is_sunny;
```

---

### Character

Single Unicode scalar value.

```rust
let a = 'a';
let emoji = '😀';
let kanji = '漢';
```

Facts:

* 4 bytes
* Unicode
* Not same as byte

---

## 3) Compound Types

Two categories in slides:

### Primitive Compound

* Array
* Tuple

### Complex Compound

* String
* Vector

---

## 4) Array

Fixed-size collection of same type.

```rust
let a1 = [10, 11, 12];
```

Type:

```md
[i32; 3]
```

Access:

```rust
a1[0]
```

Length:

```rust
a1.len()
```

Mutable array:

```rust
let mut a2 = [10, 11, 12];
a2[0] = 9;
```

Iterate:

```rust
for x in a2.iter() {
    println!("{}", x);
}
```

Initialize later:

```rust
let mut a: [i64; 5];
a = [10,11,12,13,14];
```

Repeated value:

```rust
let a = [32; 5];   // [32,32,32,32,32]
```

Key property:

* Size known at compile time
* Cannot grow or shrink

---

## 5) Tuple

Fixed-size, mixed types.

```rust
let t = ("Age", 25, true);
```

Access:

```rust
t.0
t.1
t.2
```

Destructure:

```rust
let (label, age, flag) = t;
```

---

## 6) String (Complex Type)

Heap allocated, growable UTF-8 text.

```rust
let mut s = String::from("hello");
s.push_str(" world");
```

Properties:

* Heap memory
* Dynamic size
* Owns data

---

## 7) Vector

Dynamic array.

```rust
let mut v: Vec<i32> = Vec::new();
```

or

```rust
let mut v = Vec::<i32>::new();
```

or

```rust
let v1 = vec![1,2,3,4,5];
let v2: Vec<i32> = vec![0;5];
```

Add element:

```rust
v.push(10);
```

Access:

```rust
v[0]
```

or safe:

```rust
v.get(0)
```

Properties:

* Heap allocated
* Growable
* Same type elements

---

## 8) Array vs Vector

| Feature | Array           | Vector  |
| ------- | --------------- | ------- |
| Size    | Fixed           | Dynamic |
| Memory  | Stack (usually) | Heap    |
| Grow    | No              | Yes     |
| Syntax  | [T; N]          | Vec<T>  |

---

## 9) Mental Model

* Scalars → direct values
* Arrays/Tuples → grouped fixed data
* String/Vec → heap + dynamic

---

## 10) One-Line Takeaways

* Use **array** when size is known and fixed
* Use **vector** when size changes
* Use **char** for single Unicode character
* Use **String** for editable text
* Default floats are **f64**

---

Below are **direct, minimal explanations** of the shown concepts.

---

## If–Else

* Conditional branching.
* Conditions must evaluate to `bool`.
* `else if` chains allowed.
* Blocks `{}` are mandatory.

```rust
if cond {
} else if cond2 {
} else {
}
```

Used to execute different code paths based on conditions.

---

## Simple Loop (`loop`)

* Infinite loop.
* Runs until explicitly stopped.
* Exit using `break`.
* Can return a value via `break value`.

```rust
loop {
    // runs forever
}
```

Commonly combined with:

```rust
break;
continue;
```

---

### Key Difference vs Other Loops

* `loop` → infinite by default
* `while` → condition-based
* `for` → iterator-based

---

* **While Loop**

```md
let mut count = 0;
while count < 5 {
    println!("{}", count);
    count += 1;
}
```

* Runs while condition is true.
* Condition checked before every iteration.
* Requires manual update (`count += 1`) or infinite loop.

---

* **For Loop**

```md
for element in &array {
    println!("{}", element);
}
```

* Iterates over an iterator.
* `&array` borrows array → no ownership move.
* Preferred for collections.

---

* **Simple Match**

```md
match number {
    1 => ...
    2 => ...
    3 | 4 | 5 => ...
    _ => ...
}
```

* Pattern matching on value.
* `_` = default case.
* Must be exhaustive.

---

* **Match With Guard**

```md
match x {
    n if is_even(n) => ...
    n if !is_even(n) => ...
    _ => ...
}
```

* `if` after pattern is a guard condition.
* Pattern matches first, guard decides branch.
* Adds conditional logic inside match.

---

* **Modules Import**

```md
mod math { pub fn add(...) {} }

use crate::math::add;
```

* `mod` defines module.
* `pub` exposes item.
* `use path::item` brings into scope.

Forms:

```md
use crate::module;
use crate::module::*;
use crate::module::Item;
```

---

* **User Input**

```md
use std::io;

let mut input = String::new();
io::stdin().read_line(&mut input).unwrap();
```

* Reads line including newline.
* Stored in `String`.
* `trim()` removes whitespace/newline.

---

* **Size Of Data Type**

```md
mem::size_of_val(&x)
mem::size_of::<i32>()
```

* Returns size in bytes.
* `size_of_val` → value instance.
* `size_of::<T>` → type.

Typical sizes:

* i32 → 4 bytes
* f64 → 8 bytes
* char → 4 bytes (Unicode scalar)
* bool → 1 byte

---
