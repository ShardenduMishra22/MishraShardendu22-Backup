# Auto Dereferencing

Rust automatically dereferences references when calling methods or accessing fields.

Both are equivalent:

```rust
(*s).len()
s.len()
```

Why:

* `s` is `&String`
* `.len()` exists on `String`
* Compiler inserts `*` for you

Result: cleaner syntax, same behavior.

---

## Referencing

```rust
let y = &x;
```

* Creates a reference to `x`
* No ownership transfer
* `y` borrows `x`

Used to read or modify data without moving it.

---

### Dereferencing

```rust
let z = *y;
```

* Reads the value behind the reference
* `*` means "go to the value"

For mutation:

```rust
*y = 50;
```

Only allowed if reference is `&mut`.

---

### Mutable Reference Example

```rust
let mut x = 5;
let y = &mut x;
*y = 50;
```

Result:

```md
x = 50
```

Rules:

* Only one mutable reference at a time
* No immutable references while mutable exists

---

### Reference Chains

```rust
let y = &x;
let z = &y;
```

* `z` → `y` → `x`

Access value:

```rust
**z
```

Each `*` moves one level down.

---

### Reference vs Raw Pointer

| Aspect    | Reference (`&T`) | Raw Pointer (`*const T`) |
| --------- | ---------------- | ------------------------ |
| Safety    | Checked          | Unsafe                   |
| Lifetimes | Enforced         | Not enforced             |
| Deref     | Safe             | Unsafe block             |
| Usage     | Normal Rust      | Low-level / FFI          |

---

### Final Screenshot (Rust Approach with as_ptr)

```rust
let s1 = String::from("hello");

let ptr1 = s1.as_ptr();
let len1 = s1.len();
let cap1 = s1.capacity();

let s2 = s1;   // move

let ptr2 = s2.as_ptr();
let len2 = s2.len();
let cap2 = s2.capacity();
```

Meaning:

* `s1` owns heap buffer
* `as_ptr()` shows address of buffer
* After `let s2 = s1`, ownership moves
* Heap memory is NOT copied
* Pointer, length, capacity stay same
* `s1` becomes invalid

This proves:

* Move = transfer ownership
* No deep copy
* No double free
* One owner at a time

---

### Mental Model

* Stack values → copied
* Heap owners → moved
* References → borrow
* `*` → access value
* Auto-deref → compiler convenience

---
