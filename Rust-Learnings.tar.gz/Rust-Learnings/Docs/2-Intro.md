# Introduction to Rust

## 1) About Rust

### Statically Typed Language

Every variable’s type is known at compile time.

Rust:

```rust
let x: i32 = 10;
```

You cannot assign:

```rust
x = "hello"; // compile-time error
```

Why this matters:

* Catches mistakes early
* Faster execution
* No surprise type changes

---

### System-Level Programming

Rust is used where performance + safety matter:

* Operating systems
* Browsers (Firefox parts)
* Game engines
* Network servers
* Embedded systems

Because Rust:

* No garbage collector
* Direct memory control
* Zero-cost abstractions

---

### Strict but Protective

Rust compiler blocks:

* Use-after-free
* Data races
* Null pointer access

Result:
Harder to write code → Much harder to write bad code.

---

### Naming Convention: snake_case

Applies to:

Variables:

```rust
let my_value = 10;
```

Functions:

```rust
fn calculate_area() {}
```

Files:

```md
data_processing.rs
```

Why:

* Consistency
* Readability
* Tooling expectations

---

## 2) Compiler

### What Compiler Does

High-level code:

```rust
println!("Hello");
```

↓

Compiler

↓

Machine code (0s and 1s CPU understands)

---

### Output

On Windows → `.exe`
On Linux/macOS → no extension

The CPU runs this file directly.

---

### Key Property

Compilation happens **before execution**.

Errors must be fixed before program runs.

---

## 3) Cargo.toml

Main project configuration file.

Controls:

* Project name
* Version
* Dependencies
* Build settings

Example:

```toml
[package]
name = "app"
version = "0.1.0"

[dependencies]
rand = "0.8"
```

Cargo reads this file to know:

* What to download
* How to build

---

### TOML

Human-readable config format.

Key = value

```toml
port = 8080
debug = true
```

---

## 4) Target Folder

Created automatically by Cargo.

Contains **all build outputs**.

Typical:

```md
target/
  debug/
  release/
```

---

### Debug Folder

Created by:

```md
cargo build
```

Contains slow but debuggable binary.

---

### Release Folder

Created by:

```md
cargo build --release
```

Contains optimized fast binary.

---

### You never manually edit target/

It is disposable. Can be deleted anytime.

Cargo will recreate it.

---

## 5) Binary Executable

Your Rust code → compiled → executable file.

Example:

Project name: `app`

After build:

```md
target/debug/app
```

Run:

```md
./target/debug/app
```

Windows:

```md
target\debug\app.exe
```

---

### Meaning

Binary executable = machine code program ready to run.

Not source code.

---

## Mental Model (Pipeline)

```md
main.rs
   ↓
rustc (compiler)
   ↓
binary executable
   ↓
stored in target/
```

---
