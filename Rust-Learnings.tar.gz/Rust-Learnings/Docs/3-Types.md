# Rust Basics - Concise Summary

## 1. Data Types

Rust data types are divided into two categories:

### Scalar Types (store single value)

- Integers  
- Floating-point numbers  
- Boolean  
- Character  

### Compound Types (store multiple values)

- Arrays  
- Tuples  
- Strings  

---

## 2. Integer Types

Example:

```rust
let num: u8 = 10;
````

`u8` → Unsigned 8-bit integer

### Signed vs Unsigned

- Signed (`i*`) → Can store negative and positive numbers
- Unsigned (`u*`) → Only non-negative numbers

| Type          | Bits               | Example Range   |
| ------------- | ------------------ | --------------- |
| i8            | 8                  | -128 to 127     |
| u8            | 8                  | 0 to 255        |
| i16           | 16                 | -32768 to 32767 |
| u16           | 16                 | 0 to 65535      |
| i32 / u32     | 32                 | Larger          |
| i64 / u64     | 64                 | Larger          |
| isize / usize | Platform dependent |                 |

### Range Formula

Unsigned:

```md
0 to (2^n - 1)
```

Signed:

```md
-(2^(n-1)) to (2^(n-1) - 1)
```

---

## 3. Mutable vs Immutable Variables

Default: immutable

```rust
let x = 10;
x = 20; // Error
```

Mutable:

```rust
let mut x = 10;
x = 20; // OK
```

Why immutable by default:

- Prevents accidental modification
- Safer code
- Easier reasoning

---

## 4. String Literal (`&str`)

```rust
let s = "Hello";
```

Properties:

- Type: `&str`
- Immutable
- Fixed-size
- Stored in program binary

Cannot modify:

```rust
s.push_str("!"); // Error
```

---

## 5. String Type (`String`)

```rust
let mut s = String::from("Hello");
s.push_str(" world");
```

Properties:

- Heap allocated
- Growable
- Mutable

---

## 6. String Literal vs String

| Feature    | &str          | String        |
| ---------- | ------------- | ------------- |
| Mutable    | No            | Yes           |
| Allocation | Binary        | Heap          |
| Size       | Fixed         | Dynamic       |
| Use Case   | Constant text | Editable text |

---

## 7. String::from()

Creates an owned `String` from a string literal.

```rust
let s = String::from("Hello");
```

Meaning:

```md
&str  →  String
```

Equivalent:

```rust
"Hello".to_string()
```

Internally:

1. Allocate heap memory
2. Copy characters
3. Return String

---

## 8. Tuple

Fixed-size collection of mixed types.

```rust
let t: (&str, i32) = ("Salary", 50000);
```

Access:

```rust
t.0
t.1
```

Destructuring:

```rust
let (label, value) = t;
```

---

## 9. Core Memory Model

- Integers → Stack
- `&str` → Binary
- `String` → Heap
- Tuple → Same place as its elements

---

## One-Line Mental Model

Use `&str` for constant text.
Use `String` when text must change.
Use `mut` only when mutation is required.
