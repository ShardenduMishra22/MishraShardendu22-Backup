# RUST ADVANCED – COMPLETE CHAT SUMMARY

---

## GENERICS

* Write code that works for many types.
* Syntax: `fn f<T>(x: T)`
* Trait bounds restrict T:

```md
fn f<T: Debug>(x: T)
```

* Prevents duplicate functions.

---

## TRAITS

* Define behavior (like interfaces).
* Structs = data, Traits = behavior.
* Implement per type:

```md
impl Trait for Type {}
```

* Can have:

  * Required methods
  * Default methods

---

## DEBUG TRAIT

* Enables `{:?}` printing.
* Auto via:

```md
#[derive(Debug)]
```

* Manual impl only for custom formatting.

---

## ARRAYS

* Fixed size, stack.
* Type: `[T; N]`

## VECTORS

* Growable, heap.
* `Vec<T>`

## SLICES

* `&[T]` works for both arrays and vectors.

---

## BORROWING

* `&x` → read
* `&mut x` → write
* Passing collections usually as slices.

---

## ITERATORS

Core trait:

```md
next() -> Option<Item>
```

* `iter()` → `&T`
* `iter_mut()` → `&mut T`
* `into_iter()` → `T` (moves)

`for` loop = sugar over `next()`.

---

## CUSTOM ITERATOR

Implement `Iterator` trait.
Return `Some(value)` until finished, then `None`.

---

## TYPE ALIAS

```md
type New = Old;
```

Alias only. No new type.

---

## MACROS

* Compile-time code generation.
* `macro_rules!`
* Accept variable args.
* Token substitution.

Fragment examples:

* `expr`
* `ty`
* `ident`

---

## PROCEDURAL MACROS

* Custom derive
* Function-like
* Attribute-like

Operate on token streams.

---

## ERROR MODEL

No exceptions.

Two categories:

* Recoverable → `Result<T,E>`
* Unrecoverable → `panic!`

---

## RESULT

```md
Ok(T)
Err(E)
```

Handled with `match` or `?`.

---

## UNWRAP

* Extracts value.
* Panics on failure.

---

## EXPECT

* Same as unwrap.
* Custom panic message.

---

## UNWRAP_OR_ELSE

* Executes closure on failure.
* Can return fallback or panic with custom logic.

---

## ERROR PROPAGATION

`?` operator

* On `Ok` → value
* On `Err` → return Err to caller

No panic.

---

## WHEN TO USE WHAT

* `unwrap()` → tests only
* `expect()` → invariants
* `unwrap_or_else()` → custom handling
* `?` → real applications

---

## MENTAL MODEL

* Generics → type abstraction
* Traits → behavior abstraction
* Iterators → state machines
* Macros → compile-time templates
* Result → explicit error flow
* `?` → bubble errors
* unwrap/expect → crash

---
