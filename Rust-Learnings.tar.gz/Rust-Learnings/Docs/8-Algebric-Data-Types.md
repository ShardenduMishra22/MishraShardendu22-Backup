# Algebric Data Types

---

## Structs

* Group related fields into one type.
* Access with dot syntax.
* Ownership applies to entire struct.

---

## Ownership & Passing

```rust
fn f(x: T)        // move
fn f(x: &T)       // immutable borrow
fn f(x: &mut T)   // mutable borrow
```

* Move → original unusable
* Borrow → original usable

---

## Borrowing

* Borrowing = referencing with compiler-enforced rules.
* Many `&T` OR one `&mut T` per value.

---

## Mutable Reference Rule

* Only one mutable reference **per variable** at a time.
* Not global.

---

## Methods

```rust
fn area(&self)
```

* Inside `impl`
* First parameter is `self`, `&self`, or `&mut self`
* Called with dot: `obj.area()`

---

## Associated Functions

```rust
fn new() -> Type
```

* No `self`
* Called as `Type::new()`
* Commonly constructors

---

## `pub`

Controls visibility.

Options:

* private (default)
* `pub`
* `pub(crate)`
* `pub(super)`
* `pub(in path)`

---

## Enums

* One-of-many type.
* Variants may hold data.
* Can have methods via `impl`.
* Used for safe state modeling.

---

## Pattern Matching

* `match` chooses behavior per variant.
* All cases must be handled.

---

## `&self` vs `*self`

* `&self` → borrowed object
* `*self` → dereference inside method
* You never write `*self` as parameter.

---

## Memory Layout

* Rust auto-handles alignment.
* Ignore for normal code.

---

## `#[repr(C)]`

* Forces C-compatible layout.
* Used for FFI / binary formats.

---

## FFI (Foreign Function Interface)

Rust ↔ C/C++ interoperability.
Requires identical memory layout.

---

## `#[repr(packed)]`

* Removes padding.
* Risky.
* Used for raw byte parsing.

---

## `#[repr(align(N))]`

* Forces alignment boundary.
* Used for hardware / SIMD.

---

## Mental Model

Rust enforces:

* Ownership
* Borrowing
* Lifetime safety
* Memory correctness

at compile time.

---
