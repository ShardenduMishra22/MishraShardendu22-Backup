# Base Concepts

## 1 RustUp

RustUp is Rust’s **toolchain manager**.

What it does:

* Installs Rust compiler
* Updates Rust
* Switches Rust versions

Example:

Install Rust:

```md
curl https://sh.rustup.rs -sSf | sh
```

Check version:

```md
rustc --version
```

Switch to nightly Rust:

```md
rustup default nightly
```

Think of RustUp like:

Python → pyenv
Node → nvm

---

## 2 Cargo

Cargo is Rust’s **package manager + build system**.

What it handles:

* Creating projects
* Downloading libraries
* Building code
* Running code

Analogy:

Rust → Cargo
Node → npm
Python → pip

Project structure created by Cargo:

```md
project/
 ├── Cargo.toml
 └── src/main.rs
```

Cargo.toml = dependency + config file.

Example dependency:

```toml
[dependencies]
rand = "0.8"
```

---

## 3 Cargo Commands

### `cargo new folder_name`

Creates a new Rust project.

```md
cargo new hello
cd hello
```

Creates:

```md
hello/
  Cargo.toml
  src/main.rs
```

---

#### `cargo build`

Compiles project (debug mode.

```md
cargo build
```

Output binary:

```md
target/debug/
```

---

#### `cargo run`

Builds + runs.

```md
cargo run
```

Equivalent to:

```md
cargo build
./target/debug/project_name
```

---

#### `cargo build --release`

Optimized build.

```md
cargo build --release
```

Output:

```md
target/release/
```

Faster executable.

---

#### `cargo update`

Updates dependencies.

```md
cargo update
```

Uses Cargo.toml versions.

---

#### `cargo format`

Formats code.

```md
cargo fmt
```

Auto-aligns spacing, braces, etc.

---

### Mental Model

RustUp → installs Rust
Cargo → manages projects
cargo commands → operate project

---

### One-line Summary

RustUp manages Rust itself.
Cargo manages Rust projects.
