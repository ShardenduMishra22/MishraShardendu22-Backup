# Memory Management: Borrowing and References

## 1) Borrowing (`&T`)

```rust
fn calculate_length(s: &String) -> usize {
    s.len()
}
```

`&String` = reference (borrow)

Meaning:

* Function **does not take ownership**
* Can **read**
* Cannot modify

Why:

* Avoid move
* Avoid clone
* Cheap

Owner still exists in caller.

---

## 2) Mutable Borrowing (`&mut T`)

```rust
fn append_world(s: &mut String) {
    s.push_str(" world");
}
```

Requirements:

```rust
let mut s = String::from("hello");
append_world(&mut s);
```

Rules:

* Original variable must be `mut`
* Borrow type must be `&mut`

Effect:

* Function can modify original value
* Ownership still stays with caller

---

## 3) Borrowing Rules (Core)

At any moment:

```md
EITHER
- One mutable reference
OR
- Any number of immutable references
NOT BOTH
```

This is enforced at compile time.

---

## 4) Invalid: Two Mutable References

```rust
let w1 = &mut s;
let w2 = &mut s;   // ERROR
```

Why:

* Two writers → possible corruption
* Rust blocks it

---

## 5) Valid: Multiple Immutable References

```rust
let r1 = &s;
let r2 = &s;
```

Why allowed:

* Read-only
* No mutation

---

## 6) Scoped Mutable Reference

```rust
{
    let w1 = &mut s;
} // w1 ends here

let w2 = &mut s; // OK
```

Why works:

* First mutable reference ended
* Now a new one allowed

---

## 7) Reference Lifetime Ends At Last Use

```rust
let r1 = &s;
let r2 = &s;
println!("{}", r1);

let m = &mut s; // OK
```

Even though r1/r2 exist as variables, their **last usage already happened**.

Compiler tracks usage, not lines.

---

## 8) Data Race (What Rust Prevents)

Data race occurs when:

1. Two pointers access same data
2. At least one is writing
3. No synchronization

Rust borrowing rules make this **impossible** in safe code.

---

## 9) Dangling Reference (Forbidden)

```rust
fn create() -> &String {
    let s = String::from("hello");
    &s
}
```

`s` is destroyed when function ends.

Returning reference to destroyed data = dangling pointer.

Rust rejects this.

---

## 10) Correct Way Instead

```rust
fn create() -> String {
    String::from("hello")
}
```

Return ownership, not reference.

---

## 11) Reference vs Borrowing

* Borrowing → concept
* Reference (`&`) → tool

Borrowing means temporary access.
Reference is how you express it in code.

---

## 12) String Literal Borrowing

```rust
let s1: &str = "Hello";
let s2: &str = s1;
```

Facts:

* `"Hello"` stored in binary
* Both point to same memory
* No move
* No ownership

Why:

* `&str` already a reference

---

## 13) Heap String Borrowing

```rust
let s = String::from("hello");
let r = &s;
```

* s owns heap data
* r borrows
* s still valid

---

## 14) Mental Model

```md
Ownership = who frees memory
Borrowing = temporary access
Reference = pointer
```

---

## 15) One-Line Laws

* Stack values → copied
* Heap values → moved
* `&T` → read borrow
* `&mut T` → write borrow
* 1 writer OR many readers
* No dangling references

---

Below is a **direct, structured explanation** of the slides you shared.

---

## 1) Reference vs Pointer

### Reference (`&T`, `&mut T`)

* Safe
* Checked by borrow checker
* Has lifetime
* Cannot dangle
* Cannot be null
* Enforces borrowing rules

Example:

```rust
let x = 5;
let y = &x;
```

`y` borrows `x`.

---

### Raw Pointer (`*const T`, `*mut T`)

* Unsafe
* No lifetime tracking
* No borrow checking
* Can be null
* Used mainly for FFI / low-level code

Example:

```rust
let x = 5;
let p = &x as *const i32;
```

Dereference requires:

```rust
unsafe { *p }
```

---

### Key Idea

Rust references = pointers + compiler guarantees.

---

## 2) Referencing

Creating a reference:

```rust
let x = 5;
let y = &x;
```

* `x` owns `5`
* `y` borrows `x`
* No ownership transfer

Memory model:

```md
y ---> x ---> 5
```

---

## 3) Dereferencing

Access value behind reference:

```rust
let z = *y;
```

Now:

```md
z = 5 (copy)
```

`z` is independent.

---

## 4) Reference to Reference

```rust
let x = 5;
let y = &x;
let z = &y;
```

Chain:

```md
z -> y -> x -> 5
```

To reach value:

```rust
**z
```

---

## 5) Mutable Reference

```rust
let mut x = 5;
let y = &mut x;
*y = 50;
```

Result:

```md
x = 50
```

Rules:

* Only ONE mutable reference at a time
* No immutable refs while mutable exists

---

## 6) Mut Reference to Mut Reference

```rust
let mut x = 5;
let mut y = &mut x;
let z = &mut y;
**z = 120;
```

Effect:

```md
x = 120
```

Each `*` moves one level down.

---

## 7) References in Functions

```rust
fn calculate_length(s: &String) -> usize {
    s.len()
}
```

Call:

```rust
let s1 = String::from("hello");
let len = calculate_length(&s1);
```

Ownership NOT moved.

---

## 8) Why References Exist

Without reference:

```rust
fn f(s: String) { }
```

Ownership moves → caller loses `s`.

With reference:

```rust
fn f(s: &String) { }
```

Caller keeps ownership.

---

## 9) Dereference Operator (`*`)

Used when:

* You want to modify through reference
* You want to read pointed value

Example:

```rust
fn add_one(v: &mut i32) {
    *v += 1;
}
```

---

## 10) Auto Dereferencing

These are equivalent:

```rust
(*s).len()
s.len()
```

Rust automatically inserts `*` when calling methods.

Works only for method calls.

Not for assignments.

---

## 11) Reference vs Raw Pointer Summary

| Feature            | Reference   | Raw Pointer     |
| ------------------ | ----------- | --------------- |
| Safe               | Yes         | No              |
| Lifetime checked   | Yes         | No              |
| Null allowed       | No          | Yes             |
| Deref needs unsafe | No          | Yes             |
| Typical use        | Normal Rust | FFI / low-level |

---

## Mental Model

* `&` → create borrow
* `*` → go to value
* `&mut` → exclusive write access
* Compiler enforces correctness

---
