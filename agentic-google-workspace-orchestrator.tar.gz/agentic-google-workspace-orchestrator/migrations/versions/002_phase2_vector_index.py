"""Phase 2: Constrain vector dimension to 2048.

Revision ID: 002_phase2_vector_index
Revises: 001_initial_phase1_schema
Create Date: 2026-07-26

"""
from typing import Sequence, Union

from alembic import op

# revision identifiers, used by Alembic.
revision: str = '002_phase2_vector_index'
down_revision: Union[str, None] = '001_initial_phase1_schema'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 1. Constrain embedding column to vector(2048) for nvidia/llama-nemotron-embed-vl-1b-v2:free model
    op.execute("ALTER TABLE workspace_chunks ALTER COLUMN embedding TYPE vector(2048);")

    # Note: pgvector has a 2000-dimension limit for HNSW/IVFFlat indexes.
    # Vectors with 2048 dimensions are fully supported for exact cosine similarity search (<=>)
    # without creating an HNSW index.


def downgrade() -> None:
    op.execute("ALTER TABLE workspace_chunks ALTER COLUMN embedding TYPE vector;")
