import uuid
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import OrchestrationRun, PendingAction
from app.orchestration.confirmation import (
    confirm_all_pending_actions,
    confirm_pending_action,
    reject_all_pending_actions,
    reject_pending_action,
)
from app.orchestration.executor import DAGExecutor
from app.orchestration.models import ExecutionPlan, PlanStep
from app.orchestration.models import IntentClassification
from app.orchestration.plan_enrichment import enrich_plan_with_resolved_entities


def test_plan_enrichment_reuses_only_a_resolved_recipient() -> None:
    """An omitted Drive recipient must inherit the known workflow recipient."""
    plan = ExecutionPlan(
        goal="Share a file and invite the recipient",
        steps=[
            PlanStep(id="share", tool="drive.share_file", arguments={"external_id": "file-1"}),
            PlanStep(id="event", tool="calendar.create_event", arguments={"summary": "Kickoff"}),
            PlanStep(id="email", tool="gmail.send_email", arguments={"subject": "Kickoff", "body": "Details"}),
        ],
    )
    intent = IntentClassification(
        intent="prepare_meeting",
        services=["drive", "calendar", "gmail"],
        entities={"recipient": "person@example.com"},
    )

    enriched = enrich_plan_with_resolved_entities(plan, intent)

    assert enriched.steps[0].arguments["target_email"] == "person@example.com"
    assert enriched.steps[1].arguments["attendees"] == ["person@example.com"]
    assert enriched.steps[2].arguments["to"] == "person@example.com"


@pytest.mark.asyncio
async def test_dag_executor_collects_all_ready_mutating_pending_actions() -> None:
    """Test DAGExecutor executes read-only steps and collects ALL ready mutating steps into pending_actions."""
    user_id = uuid.uuid4()
    run_id = uuid.uuid4()

    mock_db = AsyncMock(spec=AsyncSession)

    plan = ExecutionPlan(
        goal="Multi-action workflow",
        steps=[
            PlanStep(id="step1", tool="drive.search_files", arguments={"query": "resume"}, requires_confirmation=False),
            PlanStep(id="step2", tool="calendar.create_event", arguments={"summary": "Meeting"}, requires_confirmation=True),
            PlanStep(id="step3", tool="drive.share_file", arguments={"external_id": "$steps.step1.output", "target_email": "a@b.com"}, depends_on=["step1"], requires_confirmation=True),
            PlanStep(id="step4", tool="gmail.send_email", arguments={"to": "a@b.com", "subject": "Hi", "body": "See resume"}, depends_on=["step1"], requires_confirmation=True),
        ],
    )

    executor = DAGExecutor(mock_db, user_id=user_id, run_id=run_id)

    with patch("app.orchestration.executor.AsyncSessionLocal") as mock_session_cls, \
         patch("app.tools.registry.tool_registry.get_tool") as mock_get_tool:

        mock_session = AsyncMock(spec=AsyncSession)
        mock_res = MagicMock()
        mock_res.scalar_one_or_none.return_value = None
        mock_session.execute = AsyncMock(return_value=mock_res)
        mock_session_cls.return_value.__aenter__.return_value = mock_session

        # Mock drive search tool
        mock_search_tool = MagicMock()
        mock_search_tool.requires_confirmation = False
        mock_search_tool.execute = AsyncMock(return_value=[{"id": "doc123", "web_view_link": "https://drive.com/123"}])

        # Mock mutating tools
        mock_mutating_tool = MagicMock()
        mock_mutating_tool.requires_confirmation = True

        def tool_side_effect(name):
            if name == "drive.search_files":
                return mock_search_tool
            return mock_mutating_tool

        mock_get_tool.side_effect = tool_side_effect

        result = await executor.execute_plan(plan, conversation_id=uuid.uuid4())

        assert result["status"] == "needs_confirmation"
        actions = result["pending_actions"]
        assert len(actions) == 3
        action_types = [a["action_type"] for a in actions]
        assert "calendar.create_event" in action_types
        assert "drive.share_file" in action_types
        assert "gmail.send_email" in action_types


@pytest.mark.asyncio
async def test_batch_confirm_all_executes_all_actions_in_order() -> None:
    """Test batch confirm_all_pending_actions executes all actions and returns completed status."""
    user_id = uuid.uuid4()
    run_id = uuid.uuid4()

    run = OrchestrationRun(id=run_id, user_id=user_id, query="test", status="needs_confirmation")
    act1 = PendingAction(id=uuid.uuid4(), orchestration_run_id=run_id, action_type="drive.share_file", payload={"arguments": {"file_id": "123"}}, status="pending")
    act2 = PendingAction(id=uuid.uuid4(), orchestration_run_id=run_id, action_type="calendar.create_event", payload={"arguments": {"summary": "Test"}}, status="pending")

    mock_db = AsyncMock(spec=AsyncSession)

    mock_run_res = MagicMock()
    mock_run_res.scalar_one_or_none.return_value = run

    mock_actions_res = MagicMock()
    mock_actions_res.scalars.return_value.all.return_value = [act1, act2]

    mock_db.execute = AsyncMock(side_effect=[mock_run_res, mock_actions_res])

    with patch("app.orchestration.confirmation.tool_registry.get_tool") as mock_get_tool:
        mock_tool = MagicMock()
        mock_tool.execute = AsyncMock(return_value={"message": "OK"})
        mock_get_tool.return_value = mock_tool

        res = await confirm_all_pending_actions(mock_db, user_id=user_id, run_id=run_id)

        assert res["status"] == "completed"
        assert "✓ drive.share_file" in res["message"]
        assert "✓ calendar.create_event" in res["message"]
        assert len(res["results"]) == 2


@pytest.mark.asyncio
async def test_batch_reject_all_cancels_workflow() -> None:
    """Test batch reject_all_pending_actions rejects everything and returns cancelled status."""
    user_id = uuid.uuid4()
    run_id = uuid.uuid4()

    run = OrchestrationRun(id=run_id, user_id=user_id, query="test", status="needs_confirmation")
    act1 = PendingAction(id=uuid.uuid4(), orchestration_run_id=run_id, action_type="drive.share_file", payload={"arguments": {}}, status="pending")
    act2 = PendingAction(id=uuid.uuid4(), orchestration_run_id=run_id, action_type="gmail.send_email", payload={"arguments": {}}, status="pending")

    mock_db = AsyncMock(spec=AsyncSession)

    mock_run_res = MagicMock()
    mock_run_res.scalar_one_or_none.return_value = run

    mock_actions_res = MagicMock()
    mock_actions_res.scalars.return_value.all.return_value = [act1, act2]

    mock_db.execute = AsyncMock(side_effect=[mock_run_res, mock_actions_res])

    res = await reject_all_pending_actions(mock_db, user_id=user_id, run_id=run_id)

    assert res["status"] == "cancelled"
    assert res["message"] == "The workflow was cancelled. No changes were made."
    assert len(res["rejected_actions"]) == 2
    assert act1.status == "rejected"
    assert act2.status == "rejected"


@pytest.mark.asyncio
async def test_legacy_individual_approval_still_works() -> None:
    """Test legacy per-action confirm/reject still works for backward compatibility."""
    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    act1_id = uuid.uuid4()

    mock_act1 = PendingAction(
        id=act1_id,
        orchestration_run_id=run_id,
        action_type="calendar.create_event",
        payload={"arguments": {"summary": "Meeting"}},
        status="pending",
    )

    mock_db = AsyncMock(spec=AsyncSession)

    def mock_execute(stmt):
        mock_res = MagicMock()
        mock_res.scalars.return_value.all.return_value = [mock_act1]
        mock_res.scalar_one_or_none.return_value = mock_act1
        return mock_res

    mock_db.execute.side_effect = mock_execute

    with patch("app.orchestration.confirmation.tool_registry.get_tool") as mock_get_tool:
        mock_tool = AsyncMock()
        mock_tool.execute.return_value = {"message": "Calendar event created."}
        mock_get_tool.return_value = mock_tool

        res = await confirm_pending_action(mock_db, user_id=user_id, pending_action_id=act1_id)
        assert res["status"] == "completed"
        assert "✓ calendar.create_event" in res["message"]
        assert mock_act1.status == "completed"
