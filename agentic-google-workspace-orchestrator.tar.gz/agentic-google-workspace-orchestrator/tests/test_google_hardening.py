import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch
import httpx
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.integrations.google.exceptions import (
    GoogleAPIError,
    GoogleAuthError,
    GoogleNotFoundError,
    GooglePermissionError,
    GoogleRateLimitError,
    GoogleServerError,
    GoogleValidationError,
    raise_for_google_status,
)
from app.integrations.google.utils import (
    build_calendar_event_payload,
    normalize_datetime_string,
    resolve_timezone,
    sanitize_payload_for_logging,
)
from app.models.models import OrchestrationRun, PendingAction, User
from app.orchestration.confirmation import confirm_pending_action


def test_resolve_timezone_priority() -> None:
    """Verify timezone resolution priority order."""
    assert resolve_timezone("Asia/Kolkata") == "Asia/Kolkata"
    assert resolve_timezone("America/New_York", fallback_tz="Asia/Kolkata") == "America/New_York"
    assert resolve_timezone(None, fallback_tz="Asia/Kolkata") == "Asia/Kolkata"
    assert resolve_timezone("Invalid/Timezone", fallback_tz="Asia/Kolkata") == "Asia/Kolkata"
    assert resolve_timezone(None, fallback_tz=None) == "Asia/Kolkata"


def test_normalize_datetime_string_naive_and_aware() -> None:
    """Verify timezone normalization for naive and aware datetimes."""
    dt_obj, iso_str = normalize_datetime_string("2026-07-29T10:00:00", tz_name="Asia/Kolkata")
    assert "+05:30" in iso_str or "05:30" in str(dt_obj.tzinfo)
    assert dt_obj.year == 2026
    assert dt_obj.month == 7
    assert dt_obj.day == 29
    assert dt_obj.hour == 10


def test_build_calendar_event_payload_default_1hr_duration() -> None:
    """Verify build_calendar_event_payload adds default 1-hour duration and explicit timeZone definitions."""
    payload, tz_name = build_calendar_event_payload(
        summary="Team Sync",
        start_time="2026-07-29T10:00:00",
        end_time=None,
        timezone_str="Asia/Kolkata",
    )

    assert payload["summary"] == "Team Sync"
    assert payload["start"]["timeZone"] == "Asia/Kolkata"
    assert payload["end"]["timeZone"] == "Asia/Kolkata"
    assert "2026-07-29T10:00:00" in payload["start"]["dateTime"]
    assert "2026-07-29T11:00:00" in payload["end"]["dateTime"]  # 1 hour later


def test_build_calendar_event_payload_validation() -> None:
    """Verify pre-call payload validation raises error if summary is missing."""
    with pytest.raises(ValueError, match="summary/title is required"):
        build_calendar_event_payload(summary="", start_time="2026-07-29T10:00:00")


def test_sanitize_payload_for_logging_redacts_tokens() -> None:
    """Verify log sanitizer redacts OAuth tokens and authorization headers."""
    raw_data = {
        "summary": "Meeting",
        "access_token": "secret_access_token_123",
        "refresh_token": "secret_refresh_token_456",
        "nested": {"Authorization": "Bearer secret_header"},
    }
    sanitized = sanitize_payload_for_logging(raw_data)
    assert sanitized["access_token"] == "[REDACTED]"
    assert sanitized["refresh_token"] == "[REDACTED]"
    assert sanitized["nested"]["Authorization"] == "[REDACTED]"
    assert sanitized["summary"] == "Meeting"


def test_raise_for_google_status_mapping() -> None:
    """Verify raise_for_google_status maps HTTP status codes to structured exception hierarchy."""
    # 400 Validation Error
    r400 = httpx.Response(400, json={"error": {"message": "Missing time zone definition"}})
    with pytest.raises(GoogleValidationError) as exc400:
        raise_for_google_status(r400, "calendar.create_event")
    assert "Missing time zone definition" in str(exc400.value)
    assert exc400.value.status_code == 400

    # 401 Auth Error
    r401 = httpx.Response(401, json={"error": {"message": "Invalid credentials"}})
    with pytest.raises(GoogleAuthError):
        raise_for_google_status(r401, "gmail.send_email")

    # 403 Permission Error
    r403 = httpx.Response(403, json={"error": {"message": "Insufficient OAuth scope"}})
    with pytest.raises(GooglePermissionError):
        raise_for_google_status(r403, "drive.share_file")

    # 404 Not Found
    r404 = httpx.Response(404, json={"error": {"message": "Resource not found"}})
    with pytest.raises(GoogleNotFoundError):
        raise_for_google_status(r404, "calendar.get_event")

    # 429 Rate Limit
    r429 = httpx.Response(429, json={"error": {"message": "Rate limit exceeded"}})
    with pytest.raises(GoogleRateLimitError):
        raise_for_google_status(r429, "gmail.send_email")

    # 500 Server Error
    r500 = httpx.Response(500, json={"error": {"message": "Internal Google error"}})
    with pytest.raises(GoogleServerError):
        raise_for_google_status(r500, "drive.create_folder")


@pytest.mark.asyncio
async def test_confirm_pending_action_handles_google_validation_error() -> None:
    """Verify confirm_pending_action catches GoogleValidationError, updates PendingAction status to 'failed',
    and returns structured failure response without raising HTTP 500 server error.
    """
    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    pending_action_id = uuid.uuid4()

    mock_action = PendingAction(
        id=pending_action_id,
        orchestration_run_id=run_id,
        action_type="calendar.create_event",
        payload={"arguments": {"summary": "Failed Event", "start_time": "invalid"}},
        status="pending",
    )

    mock_db = AsyncMock(spec=AsyncSession)
    mock_res = MagicMock()
    mock_res.scalar_one_or_none.return_value = mock_action
    mock_db.execute.return_value = mock_res

    # Mock tool execution to raise GoogleValidationError
    with patch("app.orchestration.confirmation.tool_registry.get_tool") as mock_get_tool:
        mock_tool = AsyncMock()
        mock_tool.execute.side_effect = GoogleValidationError(
            "Missing time zone definition for start time.", status_code=400
        )
        mock_get_tool.return_value = mock_tool

        result = await confirm_pending_action(mock_db, user_id=user_id, pending_action_id=pending_action_id)

        # Assert status is failed and structured error object is returned
        assert result["status"] == "failed"
        assert result["pending_action_id"] == str(pending_action_id)
        assert result["tool"] == "calendar.create_event"
        assert result["error"]["type"] == "google_validation_error"
        assert "Missing time zone definition" in result["error"]["message"]
        assert mock_action.status == "failed"
        assert "Missing time zone definition" in mock_action.error
