import uuid
from unittest.mock import AsyncMock, patch
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.retrieval.evaluation import (
    EvaluationQuery,
    calculate_precision_at_k,
    evaluate_retrieval_benchmark,
)
from app.retrieval.models import SearchResult


def test_calculate_precision_at_k() -> None:
    """Verify Precision@K calculation formula."""
    retrieved = ["ext1", "ext2", "ext3", "ext4", "ext5"]
    ground_truth = {"ext1", "ext2", "ext3", "ext4"}

    # 4 out of 4 relevant retrieved -> 4/4 = 1.0
    prec = calculate_precision_at_k(retrieved, ground_truth, k=5)
    assert prec == 1.0

    # 5 out of top 5 relevant -> 5/5 = 1.0
    ground_truth_all = {"ext1", "ext2", "ext3", "ext4", "ext5"}
    prec_all = calculate_precision_at_k(retrieved, ground_truth_all, k=5)
    assert prec_all == 1.0


@pytest.mark.asyncio
async def test_evaluate_retrieval_benchmark_execution() -> None:
    """Verify benchmark suite execution and metric compilation."""
    user_id = uuid.uuid4()
    mock_db = AsyncMock(spec=AsyncSession)

    dataset = [
        EvaluationQuery(
            query_id="q1",
            query="Turkish Airlines flight booking",
            services=["gmail"],
            expected_external_ids=["msg_turkish_1", "msg_turkish_2"],
        ),
        EvaluationQuery(
            query_id="q2",
            query="Acme Corp client meeting",
            services=["calendar"],
            expected_external_ids=["event_acme_1"],
        ),
    ]

    mock_res_q1 = [
        SearchResult(item_id=uuid.uuid4(), service="gmail", item_type="email", external_id="msg_turkish_1", content="Turkish Airlines flight TK1234", score=0.032),
        SearchResult(item_id=uuid.uuid4(), service="gmail", item_type="email", external_id="msg_turkish_2", content="Boarding pass for Turkish flight", score=0.028),
        SearchResult(item_id=uuid.uuid4(), service="gmail", item_type="email", external_id="other_email", content="Unrelated email", score=0.015),
    ]

    with patch("app.retrieval.evaluation.search_workspace", new_callable=AsyncMock) as mock_search:
        mock_search.side_effect = [mock_res_q1, []]

        eval_report = await evaluate_retrieval_benchmark(mock_db, user_id=user_id, dataset=dataset, k=5)

        assert eval_report["benchmark_count"] == 2
        assert len(eval_report["queries"]) == 2
        # q1 precision: 2 matches out of 2 ground truth -> 2/2 = 1.0
        # q2 precision: 0 matches -> 0.0
        # average = (1.0 + 0.0) / 2 = 0.5
        assert eval_report["mean_precision_at_5"] == 0.5
