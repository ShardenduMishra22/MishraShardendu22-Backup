import json
from unittest.mock import AsyncMock, patch
import pytest

from app.orchestration.classifier import classify_intent
from app.orchestration.models import IntentClassification
from app.utils.json_parser import extract_and_parse_json


def test_valid_object_parsing() -> None:
    """Test 1: Valid JSON object dictionary parses into IntentClassification."""
    raw = json.dumps({
        "intent": "create_event",
        "services": ["calendar"],
        "entities": {"topic": "Sync"},
        "temporal": None,
        "ambiguous": False,
        "clarification_question": None,
    })

    parsed, clean, err = extract_and_parse_json(raw)
    assert err is None
    assert isinstance(parsed, dict)
    obj = IntentClassification(**parsed)
    assert obj.intent == "create_event"


@pytest.mark.asyncio
async def test_array_with_one_object_unwrapping() -> None:
    """Test 2: LLM returns single-item array [ { ... } ], safely unwrapped."""
    raw_array = json.dumps([{
        "intent": "send_email",
        "services": ["gmail"],
        "entities": {"recipient": "john@example.com"},
        "temporal": None,
        "ambiguous": False,
        "clarification_question": None,
    }])

    with patch("app.orchestration.classifier.llm_chat_completion") as mock_llm:
        mock_llm.side_effect = AsyncMock(return_value=raw_array)

        res = await classify_intent(query="Send email to John", conversation_history=[])
        assert isinstance(res, IntentClassification)
        assert res.intent == "send_email"
        assert res.services == ["gmail"]


@pytest.mark.asyncio
async def test_array_with_multiple_objects_rejection() -> None:
    """Test 3: LLM returns multiple-item array [ { ... }, { ... } ], triggers structured error and retry."""
    raw_multi_array = json.dumps([
        {"intent": "search_email", "services": ["gmail"]},
        {"intent": "search_calendar", "services": ["calendar"]},
    ])

    valid_dict = json.dumps({
        "intent": "cross_service_search",
        "services": ["gmail", "calendar"],
        "entities": {},
        "ambiguous": False,
    })

    with patch("app.orchestration.classifier.llm_chat_completion") as mock_llm:
        # Attempt 1 returns multi-item list (rejected), Attempt 2 returns valid dict
        mock_llm.side_effect = [raw_multi_array, valid_dict]

        res = await classify_intent(query="Check email and calendar", conversation_history=[])
        assert isinstance(res, IntentClassification)
        assert res.intent == "cross_service_search"


@pytest.mark.asyncio
async def test_string_and_null_rejection() -> None:
    """Tests 4 & 5: LLM returns string or null, rejected without throwing TypeError."""
    with patch("app.orchestration.classifier.llm_chat_completion") as mock_llm:
        # Returns raw string "create_event" instead of dict
        mock_llm.side_effect = AsyncMock(return_value='"create_event"')

        res = await classify_intent(query="Create event", conversation_history=[])
        # Triggers fallback without throwing TypeError
        assert isinstance(res, IntentClassification)


def test_markdown_wrapped_json_and_code_fences() -> None:
    """Tests 6 & 7: Markdown-wrapped JSON and code fences."""
    raw_fenced = """Here is the intent:
```json
{
  "intent": "prepare_meeting",
  "services": ["calendar", "drive"],
  "entities": {},
  "ambiguous": false
}
```"""

    parsed, clean, err = extract_and_parse_json(raw_fenced)
    assert err is None
    assert isinstance(parsed, dict)
    assert parsed["intent"] == "prepare_meeting"


def test_malformed_json_handling() -> None:
    """Test 8: Malformed JSON returns error message."""
    raw_bad = "{ intent: invalid_unquoted }"
    parsed, clean, err = extract_and_parse_json(raw_bad)
    assert err is not None
    assert "JSONDecodeError" in err


def test_trailing_commas_and_single_quotes() -> None:
    """Tests 9 & 10: Trailing commas and single quotes repaired."""
    raw_trailing = '{"intent": "search_drive", "services": ["drive"],}'
    parsed1, _, err1 = extract_and_parse_json(raw_trailing)
    assert err1 is None
    assert parsed1["intent"] == "search_drive"

    raw_single_quotes = "{'intent': 'search_email', 'services': ['gmail']}"
    parsed2, _, err2 = extract_and_parse_json(raw_single_quotes)
    assert err2 is None
    assert parsed2["intent"] == "search_email"
