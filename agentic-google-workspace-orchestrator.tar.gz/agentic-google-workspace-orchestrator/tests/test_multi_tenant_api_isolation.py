import uuid
from unittest.mock import AsyncMock, MagicMock
import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.models.models import Conversation, GoogleAccount, Message, User


@pytest.mark.asyncio
async def test_unauthenticated_requests_are_isolated() -> None:
    """Verify that unauthenticated requests cannot access any user data or status."""
    mock_db = AsyncMock()

    from app.db import get_db
    app.dependency_overrides[get_db] = lambda: mock_db

    try:
        client = TestClient(app)

        # Status without user credentials must return connected: False
        status_res = client.get("/api/v1/auth/google/status")
        assert status_res.status_code == 200
        assert status_res.json() == {"connected": False, "email": None, "user_id": None}

        # Sync status without credentials returns no_account
        sync_res = client.get("/api/v1/sync/status")
        assert sync_res.status_code == 200
        assert sync_res.json() == {"status": "no_account", "sync_states": {}}

        # Protected endpoints must return 401 Unauthorized
        assert client.get("/api/v1/conversations").status_code == 401
        assert client.post("/api/v1/query", json={"query": "hello"}).status_code == 401
        assert client.post("/api/v1/sync/trigger", json={"services": ["gmail"]}).status_code == 401
        assert client.delete(f"/api/v1/conversations/{uuid.uuid4()}").status_code == 401
    finally:
        app.dependency_overrides.clear()


@pytest.mark.asyncio
async def test_user_cannot_access_other_users_conversations() -> None:
    """Verify user A cannot access conversation belonging to user B."""
    user_a = uuid.uuid4()
    user_b = uuid.uuid4()
    conv_b_id = uuid.uuid4()

    mock_db = AsyncMock()

    def mock_execute(stmt):
        stmt_str = str(stmt)
        res = MagicMock()
        if "users" in stmt_str:
            mock_user = User(id=user_a, email="user_a@test.com")
            res.scalar_one_or_none.return_value = mock_user
            res.scalars.return_value.first.return_value = mock_user
        elif "conversations" in stmt_str:
            # Query filters by Conversation.user_id == user_a, so conv_b is NOT found
            res.scalar_one_or_none.return_value = None
            res.scalars.return_value.all.return_value = []
        else:
            res.scalar_one_or_none.return_value = None
            res.scalars.return_value.first.return_value = None
        return res

    mock_db.execute.side_effect = mock_execute

    from app.db import get_db
    app.dependency_overrides[get_db] = lambda: mock_db

    try:
        client = TestClient(app)
        # User A attempts to view User B's conversation messages
        resp = client.get(
            f"/api/v1/conversations/{conv_b_id}/messages",
            headers={"X-User-ID": str(user_a)},
        )
        assert resp.status_code == 404
        assert "not found" in resp.json()["detail"].lower()

        # User A attempts to delete User B's conversation
        del_resp = client.delete(
            f"/api/v1/conversations/{conv_b_id}",
            headers={"X-User-ID": str(user_a)},
        )
        assert del_resp.status_code == 404
    finally:
        app.dependency_overrides.clear()
