from unittest.mock import AsyncMock, MagicMock, patch
import pytest

from app.integrations.llm import GroqClient, GroqError, llm_chat_completion


@pytest.mark.asyncio
async def test_groq_client_chat_completion_success() -> None:
    """Test GroqClient sends OpenAI-compatible chat completion request."""
    client = GroqClient(api_key="mock_groq_key")

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": '{"intent": "search_email", "services": ["gmail"]}',
                }
            }
        ]
    }

    with patch("httpx.AsyncClient.post", return_value=mock_response) as mock_post:
        res = await client.chat_completion(
            messages=[{"role": "user", "content": "Search emails"}],
            model="openai/gpt-oss-120b",
        )

        assert '{"intent": "search_email"' in res
        assert mock_post.called
        call_kwargs = mock_post.call_args[1]
        assert call_kwargs["json"]["model"] == "openai/gpt-oss-120b"


@pytest.mark.asyncio
async def test_groq_client_missing_api_key() -> None:
    """Test GroqClient raises GroqError when GROQ_API_KEY is missing."""
    with patch("app.config.settings.GROQ_API_KEY", None), patch("app.config.settings.GROQ", None), patch.dict("os.environ", {"GROQ": "", "GROQ_API_KEY": ""}):
        client = GroqClient(api_key=None)
        with pytest.raises(GroqError, match="GROQ_API_KEY or GROQ environment variable is not configured"):
            await client.chat_completion(messages=[{"role": "user", "content": "Hi"}])


@pytest.mark.asyncio
async def test_llm_chat_completion_router_groq() -> None:
    """Test unified llm_chat_completion routes to Groq when provider='groq'."""
    with patch("app.integrations.llm.groq_client.chat_completion") as mock_groq:
        mock_groq.return_value = "Groq response"

        res = await llm_chat_completion(
            messages=[{"role": "user", "content": "Hi"}],
            provider="groq",
        )

        assert res == "Groq response"
        mock_groq.assert_called_once()


@pytest.mark.asyncio
async def test_llm_chat_completion_router_fallback() -> None:
    """Test unified llm_chat_completion falls back to Gemini when Groq fails."""
    with patch("app.integrations.llm.groq_client.chat_completion", side_effect=GroqError("API error")), \
         patch("app.integrations.llm.gemini_client.chat_completion") as mock_gemini:
        mock_gemini.return_value = "Gemini fallback response"

        res = await llm_chat_completion(
            messages=[{"role": "user", "content": "Hi"}],
            provider="groq",
        )

        assert res == "Gemini fallback response"
        mock_gemini.assert_called_once()
