import uuid
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.tools.base import ToolNotFoundError
from app.tools.registry import tool_registry


def test_tool_registry_contains_all_15_tools() -> None:
    """Verify all 15 Gmail, Calendar, and Drive tools are registered."""
    tools = tool_registry.list_tools()
    tool_names = {t["name"] for t in tools}

    expected_tools = {
        "gmail.search_emails",
        "gmail.get_email",
        "gmail.draft_email",
        "gmail.send_email",
        "gmail.update_labels",
        "calendar.search_events",
        "calendar.get_event",
        "calendar.create_event",
        "calendar.update_event",
        "calendar.delete_event",
        "drive.search_files",
        "drive.get_file",
        "drive.share_file",
        "drive.create_folder",
        "drive.move_file",
    }

    assert expected_tools.issubset(tool_names)


def test_write_tools_require_confirmation_flags() -> None:
    """Verify read-only tools and write tools requiring human confirmation."""
    # Read-only tools -> requires_confirmation must be False
    assert tool_registry.get_tool("gmail.search_emails").requires_confirmation is False
    assert tool_registry.get_tool("calendar.search_events").requires_confirmation is False
    assert tool_registry.get_tool("drive.search_files").requires_confirmation is False

    # Safe write tool -> draft_email does not require confirmation
    assert tool_registry.get_tool("gmail.draft_email").requires_confirmation is False

    # Externally mutating write tools -> MUST require confirmation
    assert tool_registry.get_tool("gmail.send_email").requires_confirmation is True
    assert tool_registry.get_tool("gmail.update_labels").requires_confirmation is True
    assert tool_registry.get_tool("calendar.create_event").requires_confirmation is True
    assert tool_registry.get_tool("calendar.update_event").requires_confirmation is True
    assert tool_registry.get_tool("calendar.delete_event").requires_confirmation is True
    assert tool_registry.get_tool("drive.share_file").requires_confirmation is True
    assert tool_registry.get_tool("drive.create_folder").requires_confirmation is True
    assert tool_registry.get_tool("drive.move_file").requires_confirmation is True


def test_get_unknown_tool_raises_error() -> None:
    """Verify get_tool with invalid name raises ToolNotFoundError."""
    with pytest.raises(ToolNotFoundError, match="Tool 'unknown.tool' is not registered"):
        tool_registry.get_tool("unknown.tool")


@pytest.mark.asyncio
async def test_gmail_search_tool_execution() -> None:
    """Verify tool execution passes parameters correctly to search_workspace."""
    tool = tool_registry.get_tool("gmail.search_emails")
    mock_db = AsyncMock(spec=AsyncSession)
    user_id = uuid.uuid4()

    with patch("app.tools.gmail.search_workspace", new_callable=AsyncMock) as mock_search:
        mock_search.return_value = []
        res = await tool.execute(mock_db, user_id=user_id, query="flight booking", sender="airline@flight.com")

        assert res == []
        mock_search.assert_called_once()
        call_kwargs = mock_search.call_args[1]
        assert call_kwargs["user_id"] == user_id
        assert call_kwargs["query"] == "flight booking"
        assert call_kwargs["filters"].services == ["gmail"]
        assert call_kwargs["filters"].sender == "airline@flight.com"


@pytest.mark.asyncio
async def test_gmail_send_email_tool_success() -> None:
    """Verify GmailSendTool calls gmail_client.send_message with valid token."""
    tool = tool_registry.get_tool("gmail.send_email")
    mock_db = AsyncMock(spec=AsyncSession)
    user_id = uuid.uuid4()

    mock_google_acc = AsyncMock()
    mock_res = MagicMock()
    mock_res.scalars.return_value.first.return_value = mock_google_acc
    mock_db.execute = AsyncMock(return_value=mock_res)

    with patch("app.integrations.google.auth.get_valid_access_token", new_callable=AsyncMock) as mock_get_token, \
         patch("app.integrations.google.gmail.gmail_client.send_message", new_callable=AsyncMock) as mock_send_msg:
        
        mock_get_token.return_value = "mock_valid_token"
        mock_send_msg.return_value = {"id": "msg_abc123", "threadId": "thread_xyz"}

        res = await tool.execute(
            mock_db,
            user_id=user_id,
            to="test@example.com",
            subject="Greeting",
            body="Hello Shardendu",
        )

        assert res["status"] == "completed"
        assert res["message_id"] == "msg_abc123"
        assert res["thread_id"] == "thread_xyz"
        mock_send_msg.assert_called_once_with(
            "mock_valid_token",
            to="test@example.com",
            subject="Greeting",
            body="Hello Shardendu",
        )


@pytest.mark.asyncio
async def test_gmail_send_email_invalid_recipient_raises_error() -> None:
    """Verify GmailSendTool rejects non-email recipient addresses."""
    from app.tools.base import ToolExecutionError

    tool = tool_registry.get_tool("gmail.send_email")
    mock_db = AsyncMock(spec=AsyncSession)
    user_id = uuid.uuid4()

    with pytest.raises(ToolExecutionError, match="Invalid or missing recipient email address"):
        await tool.execute(
            mock_db,
            user_id=user_id,
            to="Shardendu Mishra",
            subject="Greeting",
            body="Hello",
        )
