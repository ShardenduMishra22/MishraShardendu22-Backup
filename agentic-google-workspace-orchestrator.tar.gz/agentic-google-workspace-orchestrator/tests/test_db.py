from app.models import (
    Base,
    User,
    GoogleAccount,
    Conversation,
    Message,
    WorkspaceItem,
    WorkspaceChunk,
    SyncState,
    OrchestrationRun,
    ExecutionStep,
    PendingAction,
    AuditLog,
)


def test_models_registered_in_metadata() -> None:
    """Verify that all 11 required models are registered in Base metadata."""
    tables = Base.metadata.tables
    expected_tables = {
        "users",
        "google_accounts",
        "conversations",
        "messages",
        "workspace_items",
        "workspace_chunks",
        "sync_states",
        "orchestration_runs",
        "execution_steps",
        "pending_actions",
        "audit_logs",
    }
    assert expected_tables.issubset(set(tables.keys()))


def test_workspace_item_unique_constraint() -> None:
    """Verify workspace_items unique constraint definition."""
    table = Base.metadata.tables["workspace_items"]
    constraint_names = {c.name for c in table.constraints}
    assert "uq_user_service_external_id" in constraint_names


def test_workspace_chunk_unique_constraint() -> None:
    """Verify workspace_chunks unique constraint definition."""
    table = Base.metadata.tables["workspace_chunks"]
    constraint_names = {c.name for c in table.constraints}
    assert "uq_workspace_item_chunk_index" in constraint_names
