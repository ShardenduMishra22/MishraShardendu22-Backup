import json
from unittest.mock import AsyncMock, MagicMock, patch
import pytest

from app.integrations.openrouter import OpenRouterError
from app.services.embedding_service import EmbeddingService


@pytest.mark.asyncio
async def test_embedding_cache_hit() -> None:
    """Test embedding service returns cached embedding on Redis cache hit."""
    fake_vector = [0.1] * 2048
    mock_redis = AsyncMock()
    mock_redis.mget = AsyncMock(return_value=[json.dumps(fake_vector)])
    mock_client = AsyncMock()

    service = EmbeddingService(client=mock_client)

    with patch("app.services.embedding_service.redis_client", mock_redis):
        result = await service.get_embedding("hello world")

    assert result == fake_vector
    mock_redis.mget.assert_called_once()
    mock_client.embed_texts.assert_not_called()


@pytest.mark.asyncio
async def test_embedding_cache_miss_and_store() -> None:
    """Test embedding service fetches from OpenRouter on cache miss and stores in Redis."""
    fake_vector = [0.2] * 2048
    mock_redis = AsyncMock()
    mock_redis.mget = AsyncMock(return_value=[None])
    
    mock_pipe = AsyncMock()
    mock_redis.pipeline = MagicMock(return_value=mock_pipe)

    mock_client = AsyncMock()
    mock_client.embed_texts = AsyncMock(return_value=[fake_vector])

    service = EmbeddingService(client=mock_client)

    with patch("app.services.embedding_service.redis_client", mock_redis):
        result = await service.get_embedding("new text chunk")

    assert result == fake_vector
    mock_redis.mget.assert_called_once()
    mock_client.embed_texts.assert_called_once_with(["new text chunk"])
    mock_pipe.set.assert_called_once()
    mock_pipe.execute.assert_called_once()


@pytest.mark.asyncio
async def test_openrouter_malformed_response_handling() -> None:
    """Test OpenRouter client raises OpenRouterError on unexpected response format."""
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"data": "invalid format"}

    mock_http_client = AsyncMock()
    mock_http_client.post.return_value = mock_response
    mock_http_client.__aenter__.return_value = mock_http_client

    from app.integrations.openrouter import OpenRouterClient
    client = OpenRouterClient(api_key="test_key")

    with patch("httpx.AsyncClient", return_value=mock_http_client):
        with pytest.raises(OpenRouterError, match="Malformed response"):
            await client.embed_texts(["sample text"])
