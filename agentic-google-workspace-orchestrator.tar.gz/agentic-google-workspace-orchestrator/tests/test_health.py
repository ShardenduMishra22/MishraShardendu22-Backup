from unittest.mock import patch
import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_health_endpoint(client: AsyncClient) -> None:
    """Test /health endpoint returns HTTP 200 and ok status."""
    response = await client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


@pytest.mark.asyncio
async def test_ready_endpoint_all_healthy(client: AsyncClient) -> None:
    """Test /ready endpoint when DB and Redis are both reachable."""
    with (
        patch("app.main.check_database_health", return_value=True),
        patch("app.main.check_redis_health", return_value=True),
    ):
        response = await client.get("/ready")
        assert response.status_code == 200
        assert response.json() == {
            "status": "ready",
            "database": "connected",
            "redis": "connected",
        }


@pytest.mark.asyncio
async def test_ready_endpoint_db_unhealthy(client: AsyncClient) -> None:
    """Test /ready endpoint returns 503 when database is unreachable."""
    with (
        patch("app.main.check_database_health", return_value=False),
        patch("app.main.check_redis_health", return_value=True),
    ):
        response = await client.get("/ready")
        assert response.status_code == 503
        assert response.json() == {
            "status": "not_ready",
            "database": "disconnected",
            "redis": "connected",
        }


@pytest.mark.asyncio
async def test_ready_endpoint_redis_unhealthy(client: AsyncClient) -> None:
    """Test /ready endpoint returns 503 when Redis is unreachable."""
    with (
        patch("app.main.check_database_health", return_value=True),
        patch("app.main.check_redis_health", return_value=False),
    ):
        response = await client.get("/ready")
        assert response.status_code == 503
        assert response.json() == {
            "status": "not_ready",
            "database": "connected",
            "redis": "disconnected",
        }
