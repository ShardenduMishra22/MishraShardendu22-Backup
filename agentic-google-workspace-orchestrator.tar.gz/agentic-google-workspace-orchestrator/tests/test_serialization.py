import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Conversation, OrchestrationRun
from app.orchestration.models import ExecutionPlan, IntentClassification, PlanStep, TemporalContext
from app.orchestration.service import orchestrate_query
from app.utils.serialization import serialize_for_jsonb


class SampleModel(BaseModel):
    name: str
    created_at: datetime
    metadata: dict


def test_serialize_for_jsonb_nested_datetimes_and_uuids() -> None:
    """Verify serialize_for_jsonb converts nested datetimes and UUIDs into ISO-8601 strings and strings."""
    now = datetime(2026, 7, 29, 17, 0, tzinfo=timezone.utc)
    uid = uuid.uuid4()

    raw_data = {
        "id": uid,
        "summary": "Team Sync",
        "temporal": {
            "start": now,
            "end": datetime(2026, 7, 29, 18, 0, tzinfo=timezone.utc),
        },
        "items": [
            {"date": now, "name": "item1"},
            {"date": "2026-07-29T10:00:00", "name": "item2"},
        ],
    }

    serialized = serialize_for_jsonb(raw_data)

    assert serialized["id"] == str(uid)
    assert serialized["temporal"]["start"] == "2026-07-29T17:00:00+00:00"
    assert serialized["temporal"]["end"] == "2026-07-29T18:00:00+00:00"
    assert serialized["items"][0]["date"] == "2026-07-29T17:00:00+00:00"
    assert serialized["items"][1]["date"] == "2026-07-29T10:00:00"


def test_serialize_for_jsonb_pydantic_intent_and_plan() -> None:
    """Verify serialize_for_jsonb serializes Pydantic IntentClassification and ExecutionPlan objects safely."""
    now = datetime(2026, 7, 29, 17, 0, tzinfo=timezone.utc)
    intent = IntentClassification(
        intent="create_event",
        services=["calendar"],
        entities={"attendee": "john@example.com"},
        temporal=TemporalContext(
            original_text="July 29 at 5 PM",
            start=now.isoformat(),
            end=None,
            timezone="Asia/Kolkata",
        ),
        ambiguous=True,
        clarification_question="What is the meeting title?",
    )

    serialized_intent = serialize_for_jsonb(intent)
    assert isinstance(serialized_intent, dict)
    assert serialized_intent["intent"] == "create_event"
    assert "2026-07-29T17:00:00" in serialized_intent["temporal"]["start"]


@pytest.mark.asyncio
async def test_clarification_persistence_with_datetimes() -> None:
    """Verify orchestrate_query persists intent and clarification state containing datetimes
    without triggering SQL JSONB datetime serialization error.
    """
    user_id = uuid.uuid4()
    conv_id = uuid.uuid4()
    mock_conv = Conversation(id=conv_id, user_id=user_id)

    now = datetime.now(timezone.utc)
    mock_intent_ambiguous = IntentClassification(
        intent="create_event",
        services=["calendar", "gmail"],
        entities={"recipient": "shardendumishra02@gmail.com"},
        temporal=None,
        ambiguous=True,
        clarification_question="When should this event start?",
    )

    mock_db = AsyncMock(spec=AsyncSession)
    mock_res = MagicMock()
    mock_res.scalars.return_value.first.return_value = None
    mock_db.execute.return_value = mock_res

    with patch("app.orchestration.service.get_or_create_conversation", return_value=mock_conv), \
         patch("app.orchestration.service.save_message"), \
         patch("app.orchestration.context.save_message"), \
         patch("app.orchestration.service.load_conversation_history", return_value=[]), \
         patch("app.orchestration.recipient_resolver.resolve_recipient_email", return_value={"status": "resolved", "email": "shardendumishra02@gmail.com"}), \
         patch("app.orchestration.service.classify_intent", return_value=mock_intent_ambiguous):

        res = await orchestrate_query(
            db=mock_db,
            user_id=user_id,
            query="Send email to Shardendu and schedule meeting on July 29.",
            conversation_id=conv_id,
        )

        assert res["status"] == "needs_clarification"
        assert "?" in res["clarification"]["question"]
        # Verify db.add and db.commit were called without raising TypeError
        assert mock_db.add.called
        assert mock_db.commit.called


@pytest.mark.asyncio
async def test_clarification_resumption_full_pipeline_persistence() -> None:
    """Verify that after clarification, the complete multi-service orchestration executes
    and persists execution plan and intent safely into JSONB columns.
    """
    user_id = uuid.uuid4()
    conv_id = uuid.uuid4()
    mock_conv = Conversation(id=conv_id, user_id=user_id)

    now_str = datetime.now(timezone.utc).isoformat()
    mock_pending_run = OrchestrationRun(
        id=uuid.uuid4(),
        user_id=user_id,
        conversation_id=conv_id,
        query="Send email to Shardendu Mishra (shardendumishra02@gmail.com), create calendar event, and include Drive resume.",
        intent={
            "intent": "prepare_meeting",
            "services": ["gmail", "calendar", "drive"],
            "temporal": {"start": now_str},
        },
        status="needs_clarification",
    )

    mock_db = AsyncMock(spec=AsyncSession)

    def mock_execute_side_effect(stmt):
        mock_res = MagicMock()
        stmt_str = str(stmt)
        if "orchestration_runs" in stmt_str:
            mock_res.scalars.return_value.first.return_value = mock_pending_run
        else:
            mock_res.scalars.return_value.first.return_value = None
            mock_res.scalars.return_value.all.return_value = []
        return mock_res

    mock_db.execute.side_effect = mock_execute_side_effect

    mock_intent_clarified = IntentClassification(
        intent="prepare_meeting",
        services=["calendar", "drive", "gmail"],
        entities={"recipient": "shardendumishra02@gmail.com", "attendee": "shardendumishra02@gmail.com"},
        temporal=TemporalContext(original_text="5 PM July 29", start="2026-07-29T17:00:00+05:30", end="2026-07-29T17:30:00+05:30", timezone="Asia/Kolkata"),
        ambiguous=False,
    )

    planned_steps = [
        PlanStep(id="step1", tool="calendar.create_event", arguments={"summary": "Resume Screening", "start_time": "2026-07-29T17:00:00+05:30", "end_time": "2026-07-29T17:30:00+05:30"}),
        PlanStep(id="step2", tool="drive.search_files", arguments={"query": "resume"}),
        PlanStep(id="step3", tool="drive.share_file", arguments={"file_id": "$steps.step2.output", "email": "shardendumishra02@gmail.com"}, depends_on=["step2"]),
        PlanStep(id="step4", tool="gmail.send_email", arguments={"to": "shardendumishra02@gmail.com", "subject": "Invitation", "body": "See resume"}, depends_on=["step1", "step3"]),
    ]
    mock_plan_obj = ExecutionPlan(goal="Full multi-service workflow", steps=planned_steps)

    with patch("app.orchestration.service.get_or_create_conversation", return_value=mock_conv), \
         patch("app.orchestration.service.save_message"), \
         patch("app.orchestration.service.load_conversation_history", return_value=[]), \
         patch("app.orchestration.clarification_engine.classify_intent", return_value=mock_intent_clarified), \
         patch("app.orchestration.service.generate_execution_plan", return_value=mock_plan_obj), \
         patch("app.orchestration.service.DAGExecutor") as mock_executor_cls:

        mock_executor = AsyncMock()
        mock_executor.execute_plan.return_value = {
            "status": "needs_confirmation",
            "pending_actions": [
                {"pending_action_id": "act1", "action_type": "calendar.create_event"},
                {"pending_action_id": "act3", "action_type": "drive.share_file"},
                {"pending_action_id": "act4", "action_type": "gmail.send_email"},
            ],
            "step_statuses": {"step1": "waiting_confirmation", "step2": "completed", "step3": "waiting_confirmation", "step4": "waiting_confirmation"},
        }
        mock_executor_cls.return_value = mock_executor

        res = await orchestrate_query(
            db=mock_db,
            user_id=user_id,
            query="5 PM, 30 minutes, Title Resume Screening",
            conversation_id=conv_id,
        )

        assert res["status"] == "needs_confirmation"
        assert len(res["pending_actions"]) == 3
        assert mock_pending_run.status == "needs_confirmation"
