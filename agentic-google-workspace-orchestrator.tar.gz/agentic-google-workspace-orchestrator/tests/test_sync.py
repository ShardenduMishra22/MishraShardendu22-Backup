import uuid
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import GoogleAccount, WorkspaceItem
from app.services.sync_service import SyncService


@pytest.mark.asyncio
async def test_upsert_workspace_item_idempotency() -> None:
    """Verify that syncing the same workspace item twice does not duplicate chunks or embeddings."""
    sync_srv = SyncService()
    fake_user_id = uuid.uuid4()
    
    mock_db = AsyncMock(spec=AsyncSession)
    
    # First call -> Item does not exist
    mock_res_empty = MagicMock()
    mock_res_empty.scalar_one_or_none.return_value = None
    mock_db.execute = AsyncMock(return_value=mock_res_empty)

    norm_item = {
        "user_id": fake_user_id,
        "service": "gmail",
        "item_type": "email",
        "external_id": "msg_test_1",
        "title": "Test Title",
        "content": "Test email body content",
        "metadata": {"sender": "test@example.com"},
        "source_created_at": None,
        "source_updated_at": None,
    }

    with patch("app.services.sync_service.embedding_service.get_embeddings", new_callable=AsyncMock) as mock_embed:
        mock_embed.return_value = [[0.1] * 2048]
        changed1 = await sync_srv.upsert_workspace_item_and_chunks(mock_db, norm_item)
        assert changed1 is True

    # Second call -> Item exists and content is unchanged
    existing_item = WorkspaceItem(
        id=uuid.uuid4(),
        user_id=fake_user_id,
        service="gmail",
        item_type="email",
        external_id="msg_test_1",
        title="Test Title",
        content="Test email body content",
        metadata_={"sender": "test@example.com"},
    )
    mock_res_existing = MagicMock()
    mock_res_existing.scalar_one_or_none.return_value = existing_item
    mock_db.execute = AsyncMock(return_value=mock_res_existing)

    with patch("app.services.sync_service.embedding_service.get_embeddings", new_callable=AsyncMock) as mock_embed:
        changed2 = await sync_srv.upsert_workspace_item_and_chunks(mock_db, norm_item)
        assert changed2 is False
        mock_embed.assert_not_called()


@pytest.mark.asyncio
async def test_parallel_sync_error_isolation() -> None:
    """Verify that failure in one service does not crash other concurrent service syncs."""
    sync_srv = SyncService()
    fake_user = GoogleAccount(
        id=uuid.uuid4(),
        user_id=uuid.uuid4(),
        google_account_id="acc123",
        email="user@test.com",
        access_token="valid_token",
        refresh_token="ref_token",
    )

    mock_db = AsyncMock(spec=AsyncSession)

    with (
        patch.object(sync_srv, "sync_gmail", new_callable=AsyncMock) as mock_gmail,
        patch.object(sync_srv, "sync_calendar", new_callable=AsyncMock) as mock_cal,
        patch.object(sync_srv, "sync_drive", new_callable=AsyncMock) as mock_drive,
    ):
        mock_gmail.return_value = 10
        mock_cal.side_effect = Exception("Calendar API Rate Limit Exceeded")
        mock_drive.return_value = 5

        res = await sync_srv.sync_services(mock_db, fake_user, ["gmail", "calendar", "drive"])

        assert res["status"] == "completed"
        results = res["results"]

        assert results["gmail"] == {"status": "success", "items_processed": 10}
        assert results["calendar"]["status"] == "failed"
        assert "Calendar API Rate Limit Exceeded" in results["calendar"]["error"]
        assert results["drive"] == {"status": "success", "items_processed": 5}
