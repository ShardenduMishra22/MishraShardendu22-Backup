import uuid
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.orchestration.executor import DAGExecutor
from app.orchestration.models import ExecutionPlan, PlanStep
from app.tools.base import ToolExecutionError


@pytest.mark.asyncio
async def test_tool_chaining_single_result_mapping_success() -> None:
    """Test 1 result: search_resume returns 1 file, executor resolves explicit field path."""
    plan = ExecutionPlan(
        goal="Share resume with target email",
        steps=[
            PlanStep(id="search_resume", tool="drive.search_files", arguments={"query": "resume"}, depends_on=[]),
            PlanStep(
                id="share_resume",
                tool="drive.share_file",
                arguments={"external_id": "$steps.search_resume[0].external_id", "target_email": "shardendu02@gmail.com"},
                depends_on=["search_resume"],
            ),
        ],
    )

    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    mock_db = AsyncMock(spec=AsyncSession)

    executor = DAGExecutor(mock_db, user_id=user_id, run_id=run_id)

    with patch("app.orchestration.executor.AsyncSessionLocal") as mock_session_cls, \
         patch("app.tools.registry.tool_registry.get_tool") as mock_get_tool:

        mock_session = AsyncMock(spec=AsyncSession)
        mock_res = MagicMock()
        mock_res.scalar_one_or_none.return_value = None
        mock_session.execute = AsyncMock(return_value=mock_res)
        mock_session_cls.return_value.__aenter__.return_value = mock_session

        # Search tool returns 1 result dict inside a list
        mock_search_tool = MagicMock()
        mock_search_tool.requires_confirmation = False
        mock_search_tool.input_model.model_fields = {"query": MagicMock(annotation=str)}
        mock_search_tool.execute = AsyncMock(return_value=[
            {
                "id": "file_abc_123",
                "external_id": "google_drive_ext_123",
                "title": "Shardendu_Mishra_Resume.pdf",
                "service": "drive",
            }
        ])

        # Share tool expects external_id: str
        from app.tools.drive import DriveShareInput
        mock_share_tool = MagicMock()
        mock_share_tool.name = "drive.share_file"
        mock_share_tool.input_model = DriveShareInput
        mock_share_tool.requires_confirmation = True

        def tool_side_effect(name):
            if name == "drive.search_files":
                return mock_search_tool
            return mock_share_tool

        mock_get_tool.side_effect = tool_side_effect

        exec_res = await executor.execute_plan(plan, conversation_id=uuid.uuid4())

        assert exec_res["status"] == "needs_confirmation"
        pending_actions = exec_res["pending_actions"]
        assert len(pending_actions) == 1
        bound_payload = pending_actions[0]["payload"]
        assert bound_payload["external_id"] == "google_drive_ext_123"
        assert isinstance(bound_payload["external_id"], str)
        assert bound_payload["target_email"] == "shardendu02@gmail.com"


@pytest.mark.asyncio
async def test_tool_chaining_zero_results_produces_descriptive_error() -> None:
    """Test 0 results: search_resume returns [], executor catches empty result and produces descriptive error."""
    plan = ExecutionPlan(
        goal="Share resume with target email",
        steps=[
            PlanStep(id="search_resume", tool="drive.search_files", arguments={"query": "nonexistent_resume"}, depends_on=[]),
            PlanStep(
                id="share_resume",
                tool="drive.share_file",
                arguments={"external_id": "$steps.search_resume[0].external_id", "target_email": "shardendu02@gmail.com"},
                depends_on=["search_resume"],
            ),
        ],
    )

    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    mock_db = AsyncMock(spec=AsyncSession)

    executor = DAGExecutor(mock_db, user_id=user_id, run_id=run_id)

    with patch("app.orchestration.executor.AsyncSessionLocal") as mock_session_cls, \
         patch("app.tools.registry.tool_registry.get_tool") as mock_get_tool:

        mock_session = AsyncMock(spec=AsyncSession)
        mock_res = MagicMock()
        mock_res.scalar_one_or_none.return_value = None
        mock_session.execute = AsyncMock(return_value=mock_res)
        mock_session_cls.return_value.__aenter__.return_value = mock_session

        # Search tool returns 0 results
        mock_search_tool = MagicMock()
        mock_search_tool.requires_confirmation = False
        mock_search_tool.input_model.model_fields = {"query": MagicMock(annotation=str)}
        mock_search_tool.execute = AsyncMock(return_value=[])

        from app.tools.drive import DriveShareInput
        mock_share_tool = MagicMock()
        mock_share_tool.name = "drive.share_file"
        mock_share_tool.input_model = DriveShareInput
        mock_share_tool.requires_confirmation = True

        def tool_side_effect(name):
            if name == "drive.search_files":
                return mock_search_tool
            return mock_share_tool

        mock_get_tool.side_effect = tool_side_effect

        exec_res = await executor.execute_plan(plan, conversation_id=uuid.uuid4())

        assert exec_res["status"] == "failed"
        step_statuses = exec_res["step_statuses"]
        assert step_statuses["search_resume"] == "completed"
        assert step_statuses["share_resume"] == "failed"


@pytest.mark.asyncio
async def test_tool_chaining_multiple_results_selects_top_match() -> None:
    """Test multiple results: search_resume returns 3 files, executor resolves first result's external_id."""
    plan = ExecutionPlan(
        goal="Share resume with target email",
        steps=[
            PlanStep(id="search_resume", tool="drive.search_files", arguments={"query": "resume"}, depends_on=[]),
            PlanStep(
                id="share_resume",
                tool="drive.share_file",
                arguments={"external_id": "$steps.search_resume[0].external_id", "target_email": "shardendu02@gmail.com"},
                depends_on=["search_resume"],
            ),
        ],
    )

    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    mock_db = AsyncMock(spec=AsyncSession)

    executor = DAGExecutor(mock_db, user_id=user_id, run_id=run_id)

    with patch("app.orchestration.executor.AsyncSessionLocal") as mock_session_cls, \
         patch("app.tools.registry.tool_registry.get_tool") as mock_get_tool:

        mock_session = AsyncMock(spec=AsyncSession)
        mock_res = MagicMock()
        mock_res.scalar_one_or_none.return_value = None
        mock_session.execute = AsyncMock(return_value=mock_res)
        mock_session_cls.return_value.__aenter__.return_value = mock_session

        # Search tool returns 3 results
        mock_search_tool = MagicMock()
        mock_search_tool.requires_confirmation = False
        mock_search_tool.input_model.model_fields = {"query": MagicMock(annotation=str)}
        mock_search_tool.execute = AsyncMock(return_value=[
            {"id": "top_match_123", "external_id": "top_ext_123", "title": "Latest_Resume_2026.pdf"},
            {"id": "old_match_456", "external_id": "old_ext_456", "title": "Resume_2024.pdf"},
            {"id": "old_match_789", "external_id": "old_ext_789", "title": "Resume_2022.pdf"},
        ])

        from app.tools.drive import DriveShareInput
        mock_share_tool = MagicMock()
        mock_share_tool.name = "drive.share_file"
        mock_share_tool.input_model = DriveShareInput
        mock_share_tool.requires_confirmation = True

        def tool_side_effect(name):
            if name == "drive.search_files":
                return mock_search_tool
            return mock_share_tool

        mock_get_tool.side_effect = tool_side_effect

        exec_res = await executor.execute_plan(plan, conversation_id=uuid.uuid4())

        assert exec_res["status"] == "needs_confirmation"
        pending_actions = exec_res["pending_actions"]
        assert len(pending_actions) == 1
        bound_payload = pending_actions[0]["payload"]
        assert bound_payload["external_id"] == "top_ext_123"
