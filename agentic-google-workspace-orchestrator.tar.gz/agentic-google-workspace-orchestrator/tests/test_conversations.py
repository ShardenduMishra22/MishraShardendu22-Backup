import uuid
from unittest.mock import AsyncMock, MagicMock
import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.models.models import Conversation, GoogleAccount, User


@pytest.mark.asyncio
async def test_delete_conversation_endpoint() -> None:
    """Test DELETE /api/v1/conversations/{id} deletes conversation."""
    user_id = uuid.uuid4()
    conv_id = uuid.uuid4()

    mock_user = User(id=user_id, email="test@example.com")
    mock_acc = GoogleAccount(id=uuid.uuid4(), user_id=user_id)
    mock_conv = Conversation(id=conv_id, user_id=user_id)

    mock_db = AsyncMock()

    def mock_execute(stmt):
        stmt_str = str(stmt)
        res = MagicMock()
        if "conversations" in stmt_str:
            res.scalar_one_or_none.return_value = mock_conv
            res.scalars.return_value.first.return_value = mock_conv
        elif "google_accounts" in stmt_str:
            res.scalars.return_value.first.return_value = mock_acc
        elif "users" in stmt_str:
            res.scalars.return_value.first.return_value = mock_user
            res.scalar_one_or_none.return_value = mock_user
        else:
            res.scalars.return_value.first.return_value = None
            res.scalar_one_or_none.return_value = None
        return res

    mock_db.execute.side_effect = mock_execute

    from app.db import get_db
    app.dependency_overrides[get_db] = lambda: mock_db

    try:
        client = TestClient(app)
        response = client.delete(f"/api/v1/conversations/{conv_id}")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "deleted"
        assert data["conversation_id"] == str(conv_id)
        assert mock_db.delete.called
        assert mock_db.commit.called
    finally:
        app.dependency_overrides.clear()
