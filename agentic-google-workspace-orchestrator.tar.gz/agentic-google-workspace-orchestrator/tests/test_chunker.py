from app.services.chunker import TextChunker


def test_chunker_gmail_headers() -> None:
    """Verify Gmail chunker prepends header metadata."""
    chunker = TextChunker(chunk_size=500, chunk_overlap=50)
    msg_item = {
        "service": "gmail",
        "title": "Flight Confirmation TK1234",
        "content": "Your flight from Istanbul to NYC is confirmed for Nov 5.",
        "metadata": {
            "sender": "booking@turkishairlines.com",
            "recipients": "user@example.com",
            "received_at": "2026-10-15T10:00:00Z",
        },
    }

    chunks = chunker.chunk_item(msg_item)
    assert len(chunks) == 1
    assert chunks[0]["chunk_index"] == 0
    assert "Subject: Flight Confirmation TK1234" in chunks[0]["content"]
    assert "From: booking@turkishairlines.com" in chunks[0]["content"]
    assert "Your flight from Istanbul to NYC is confirmed" in chunks[0]["content"]


def test_chunker_calendar_single_chunk() -> None:
    """Verify Calendar event fits in single structured chunk."""
    chunker = TextChunker(chunk_size=500, chunk_overlap=50)
    event_item = {
        "service": "calendar",
        "title": "Acme Corp Meeting",
        "content": "Discuss project budget and architecture.",
        "metadata": {
            "start": "2026-11-06T10:00:00Z",
            "end": "2026-11-06T11:00:00Z",
            "location": "Room 402",
            "attendees": ["john@acme.com", "sarah@acme.com"],
            "status": "confirmed",
        },
    }

    chunks = chunker.chunk_item(event_item)
    assert len(chunks) == 1
    content = chunks[0]["content"]
    assert "Title: Acme Corp Meeting" in content
    assert "Location: Room 402" in content
    assert "john@acme.com, sarah@acme.com" in content


def test_chunker_drive_long_document() -> None:
    """Verify Drive file text chunking breaks into overlapping chunks."""
    chunker = TextChunker(chunk_size=100, chunk_overlap=20)
    long_text = "Paragraph 1 sentence.\n" * 15
    file_item = {
        "service": "drive",
        "title": "Project Specification Doc",
        "content": long_text,
        "metadata": {"mime_type": "text/plain"},
    }

    chunks = chunker.chunk_item(file_item)
    assert len(chunks) > 1
    for idx, c in enumerate(chunks):
        assert c["chunk_index"] == idx
        assert len(c["content"]) > 0
