import uuid
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Conversation
from app.orchestration.models import ExecutionPlan, IntentClassification, PlanStep, TemporalContext
from app.orchestration.planner import generate_execution_plan, is_write_or_multi_service_intent, validate_plan_schema_and_tools
from app.orchestration.service import orchestrate_query
from app.utils.json_parser import extract_and_parse_json


def test_extract_and_parse_json_markdown_code_fences_and_prose() -> None:
    """Test extract_and_parse_json extracts valid JSON despite markdown fences, prose, and comments."""
    raw_with_prose = """Here is the generated plan:
```json
{
  "goal": "Schedule meeting and email attendee",
  "steps": [
    {
      "id": "step1",
      "tool": "calendar.create_event",
      "arguments": {"summary": "Sync"},
      "depends_on": []
    }
  ]
}
```
Hope this helps!"""

    parsed, clean, err = extract_and_parse_json(raw_with_prose)
    assert err is None
    assert parsed["goal"] == "Schedule meeting and email attendee"
    assert len(parsed["steps"]) == 1


def test_extract_and_parse_json_trailing_commas_repair() -> None:
    """Test extract_and_parse_json repairs trailing commas."""
    raw_trailing = """{
        "goal": "Test plan",
        "steps": [
            {
                "id": "s1",
                "tool": "gmail.search_emails",
                "arguments": {"query": "test",},
                "depends_on": [],
            },
        ],
    }"""

    parsed, clean, err = extract_and_parse_json(raw_trailing)
    assert err is None
    assert parsed["steps"][0]["id"] == "s1"


def test_strict_fallback_policy_detection() -> None:
    """Verify write or multi-service intent detection prevents silent search fallback."""
    write_intent = IntentClassification(
        intent="create_event",
        services=["calendar", "gmail"],
        entities={},
        ambiguous=False,
    )
    assert is_write_or_multi_service_intent("Send email and create calendar event", write_intent) is True

    search_intent = IntentClassification(
        intent="search_email",
        services=["gmail"],
        entities={},
        ambiguous=False,
    )
    assert is_write_or_multi_service_intent("Find recent emails", search_intent) is False


@pytest.mark.asyncio
async def test_end_to_end_test1_multi_service_email_meeting_resume() -> None:
    """Test 1: Complex query generating full DAG for drive, calendar, and gmail."""
    user_id = uuid.uuid4()
    conv_id = uuid.uuid4()
    mock_conv = Conversation(id=conv_id, user_id=user_id)

    mock_db = AsyncMock(spec=AsyncSession)
    mock_res = MagicMock()
    mock_res.scalars.return_value.first.return_value = None
    mock_res.scalars.return_value.all.return_value = []
    mock_db.execute.return_value = mock_res

    mock_intent = IntentClassification(
        intent="prepare_meeting",
        services=["calendar", "drive", "gmail"],
        entities={"recipient": "shardendumishra02@gmail.com", "attendee": "shardendumishra02@gmail.com"},
        temporal=TemporalContext(original_text="29th 5 PM", start="2026-07-29T17:00:00+05:30", end="2026-07-29T17:30:00+05:30", timezone="Asia/Kolkata"),
        ambiguous=False,
    )

    planned_steps = [
        PlanStep(id="search_resume", tool="drive.search_files", arguments={"query": "resume"}),
        PlanStep(id="share_resume", tool="drive.share_file", arguments={"file_id": "$steps.search_resume.output", "email": "shardendumishra02@gmail.com"}, depends_on=["search_resume"]),
        PlanStep(id="create_cal", tool="calendar.create_event", arguments={"summary": "Resume Screening", "start_time": "2026-07-29T17:00:00+05:30", "end_time": "2026-07-29T17:30:00+05:30"}),
        PlanStep(id="send_mail", tool="gmail.send_email", arguments={"to": "shardendumishra02@gmail.com", "subject": "Invitation", "body": "See attached resume $steps.search_resume.output"}, depends_on=["create_cal", "share_resume"]),
    ]
    mock_plan_obj = ExecutionPlan(goal="Schedule meeting, share resume, send invite email", steps=planned_steps)

    with patch("app.orchestration.service.get_or_create_conversation", return_value=mock_conv), \
         patch("app.orchestration.service.save_message"), \
         patch("app.orchestration.service.load_conversation_history", return_value=[]), \
         patch("app.orchestration.service.classify_intent", return_value=mock_intent), \
         patch("app.orchestration.service.generate_execution_plan", return_value=mock_plan_obj), \
         patch("app.orchestration.service.DAGExecutor") as mock_executor_cls:

        mock_executor = AsyncMock()
        mock_executor.execute_plan.return_value = {
            "status": "needs_confirmation",
            "pending_actions": [
                {"pending_action_id": "act1", "action_type": "drive.share_file"},
                {"pending_action_id": "act2", "action_type": "calendar.create_event"},
                {"pending_action_id": "act3", "action_type": "gmail.send_email"},
            ],
            "step_statuses": {"search_resume": "completed", "share_resume": "waiting_confirmation", "create_cal": "waiting_confirmation", "send_mail": "waiting_confirmation"},
        }
        mock_executor_cls.return_value = mock_executor

        res = await orchestrate_query(
            db=mock_db,
            user_id=user_id,
            query="Send email to Shardendu, create meeting on 29th 5 PM, include resume from Drive.",
            conversation_id=conv_id,
        )

        assert res["status"] == "needs_confirmation"
        actions = res["pending_actions"]
        assert len(actions) == 3
        action_types = [a["action_type"] for a in actions]
        assert "drive.share_file" in action_types
        assert "calendar.create_event" in action_types
        assert "gmail.send_email" in action_types


@pytest.mark.asyncio
async def test_end_to_end_test2_retrieval_meeting_prep() -> None:
    """Test 2: Retrieval query generating search steps for calendar, gmail, and drive."""
    user_id = uuid.uuid4()
    conv_id = uuid.uuid4()
    mock_conv = Conversation(id=conv_id, user_id=user_id)

    mock_db = AsyncMock(spec=AsyncSession)
    mock_res = MagicMock()
    mock_res.scalars.return_value.first.return_value = None
    mock_res.scalars.return_value.all.return_value = []
    mock_db.execute.return_value = mock_res

    mock_intent = IntentClassification(
        intent="cross_service_search",
        services=["calendar", "gmail", "drive"],
        entities={"company": "Acme"},
        ambiguous=False,
    )

    planned_steps = [
        PlanStep(id="search_cal", tool="calendar.search_events", arguments={"query": "Acme"}),
        PlanStep(id="search_mail", tool="gmail.search_emails", arguments={"query": "Acme"}),
        PlanStep(id="search_drive", tool="drive.search_files", arguments={"query": "Acme"}),
    ]
    mock_plan_obj = ExecutionPlan(goal="Prepare for Acme meeting", steps=planned_steps)

    with patch("app.orchestration.service.get_or_create_conversation", return_value=mock_conv), \
         patch("app.orchestration.service.save_message"), \
         patch("app.orchestration.service.load_conversation_history", return_value=[]), \
         patch("app.orchestration.service.classify_intent", return_value=mock_intent), \
         patch("app.orchestration.service.generate_execution_plan", return_value=mock_plan_obj), \
         patch("app.orchestration.service.DAGExecutor") as mock_executor_cls, \
         patch("app.orchestration.service.synthesize_response", return_value="Found Acme meeting notes and files."):

        mock_executor = AsyncMock()
        mock_executor.execute_plan.return_value = {
            "status": "completed",
            "completed_outputs": {"search_cal": [], "search_mail": [], "search_drive": []},
            "step_statuses": {"search_cal": "completed", "search_mail": "completed", "search_drive": "completed"},
        }
        mock_executor_cls.return_value = mock_executor

        res = await orchestrate_query(
            db=mock_db,
            user_id=user_id,
            query="Prepare me for tomorrow's meeting with Acme.",
            conversation_id=conv_id,
        )

        assert res["status"] == "completed"
        step_ids = [a["step_id"] for a in res["actions_taken"]]
        assert "search_cal" in step_ids
        assert "search_mail" in step_ids
        assert "search_drive" in step_ids


@pytest.mark.asyncio
async def test_end_to_end_test3_single_write_calendar_create() -> None:
    """Test 3: Single write query generating calendar.create_event (NOT search_calendar)."""
    user_id = uuid.uuid4()
    conv_id = uuid.uuid4()
    mock_conv = Conversation(id=conv_id, user_id=user_id)

    mock_db = AsyncMock(spec=AsyncSession)
    mock_res = MagicMock()
    mock_res.scalars.return_value.first.return_value = None
    mock_res.scalars.return_value.all.return_value = []
    mock_db.execute.return_value = mock_res

    mock_intent = IntentClassification(
        intent="create_event",
        services=["calendar"],
        entities={"topic": "Team Sync"},
        temporal=TemporalContext(original_text="tomorrow 3 PM", start="2026-07-29T15:00:00+05:30", end="2026-07-29T16:00:00+05:30", timezone="Asia/Kolkata"),
        ambiguous=False,
    )

    planned_steps = [
        PlanStep(id="create_cal", tool="calendar.create_event", arguments={"summary": "Team Sync", "start_time": "2026-07-29T15:00:00+05:30", "end_time": "2026-07-29T16:00:00+05:30"}),
    ]
    mock_plan_obj = ExecutionPlan(goal="Create Team Sync meeting", steps=planned_steps)

    with patch("app.orchestration.service.get_or_create_conversation", return_value=mock_conv), \
         patch("app.orchestration.service.save_message"), \
         patch("app.orchestration.service.load_conversation_history", return_value=[]), \
         patch("app.orchestration.service.classify_intent", return_value=mock_intent), \
         patch("app.orchestration.service.generate_execution_plan", return_value=mock_plan_obj), \
         patch("app.orchestration.service.DAGExecutor") as mock_executor_cls:

        mock_executor = AsyncMock()
        mock_executor.execute_plan.return_value = {
            "status": "needs_confirmation",
            "pending_actions": [{"pending_action_id": "act1", "action_type": "calendar.create_event"}],
            "step_statuses": {"create_cal": "waiting_confirmation"},
        }
        mock_executor_cls.return_value = mock_executor

        res = await orchestrate_query(
            db=mock_db,
            user_id=user_id,
            query="Create a calendar event for Team Sync tomorrow at 3 PM.",
            conversation_id=conv_id,
        )

        assert res["status"] == "needs_confirmation"
        assert res["pending_actions"][0]["action_type"] == "calendar.create_event"
