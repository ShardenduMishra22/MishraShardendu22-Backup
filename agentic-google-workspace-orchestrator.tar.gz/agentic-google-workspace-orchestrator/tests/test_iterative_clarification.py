"""
Integration tests for iterative clarification workflow.
"""
import pytest
from app.orchestration.parameter_validator import validate_tool_parameters, generate_clarification_prompt
from app.orchestration.clarification_engine import ClarificationEngine
from app.orchestration.models import IntentClassification


def test_parameter_validation_send_email_missing_all():
    """Test parameter validation for send_email with all parameters missing."""
    intent = IntentClassification(
        intent="send_email",
        services=["gmail"],
        entities={},
        ambiguous=False,
    )

    result = validate_tool_parameters(intent)

    assert not result.is_complete
    assert len(result.missing_parameters) == 3  # recipient, subject, body
    assert any(p["parameter"] == "recipient" for p in result.missing_parameters)
    assert any(p["parameter"] == "subject" for p in result.missing_parameters)
    assert any(p["parameter"] == "body" for p in result.missing_parameters)
    assert len(result.clarification_questions) > 0


def test_parameter_validation_send_email_partial():
    """Test parameter validation with some parameters provided."""
    intent = IntentClassification(
        intent="send_email",
        services=["gmail"],
        entities={"recipient": "test@example.com", "subject": "Test Subject"},
        ambiguous=False,
    )

    result = validate_tool_parameters(intent)

    assert not result.is_complete
    assert len(result.missing_parameters) == 1  # only body missing
    assert result.missing_parameters[0]["parameter"] == "body"


def test_parameter_validation_send_email_complete():
    """Test parameter validation with all required parameters."""
    intent = IntentClassification(
        intent="send_email",
        services=["gmail"],
        entities={
            "recipient": "test@example.com",
            "subject": "Test Subject",
            "body": "Test message content",
        },
        ambiguous=False,
    )

    result = validate_tool_parameters(intent)

    assert result.is_complete
    assert len(result.missing_parameters) == 0
    assert len(result.clarification_questions) == 0


def test_parameter_validation_create_event_missing_time():
    """Test parameter validation for calendar event missing temporal info."""
    intent = IntentClassification(
        intent="create_event",
        services=["calendar"],
        entities={"summary": "Team Meeting", "attendees": "john@example.com"},
        ambiguous=False,
    )

    result = validate_tool_parameters(intent)

    assert not result.is_complete
    # Missing start_time and end_time
    assert any(p["parameter"] in ("start_time", "end_time") for p in result.missing_parameters)


def test_clarification_prompt_generation_single_field():
    """Test clarification prompt generation for single missing field."""
    intent = IntentClassification(
        intent="send_email",
        services=["gmail"],
        entities={"recipient": "test@example.com", "subject": "Test"},
        ambiguous=False,
    )

    result = validate_tool_parameters(intent)
    prompt = generate_clarification_prompt(result)

    # Should ask about email content/body
    assert "email" in prompt.lower()
    assert "?" in prompt  # Should be a question


def test_clarification_prompt_generation_multiple_fields():
    """Test clarification prompt generation for multiple missing fields."""
    intent = IntentClassification(
        intent="send_email",
        services=["gmail"],
        entities={},
        ambiguous=False,
    )

    result = validate_tool_parameters(intent)
    prompt = generate_clarification_prompt(result)

    # Should format as numbered list
    assert "1." in prompt or "2." in prompt
    assert len(result.missing_parameters) >= 2


def test_simple_extraction_email():
    """Test simple extraction heuristics for email addresses."""
    missing_params = [{"parameter": "recipient", "question": "Who should I email?"}]
    
    extracted = ClarificationEngine.extract_simple_responses(
        "john.doe@example.com",
        missing_params
    )

    assert "recipient" in extracted
    assert extracted["recipient"] == "john.doe@example.com"


def test_simple_extraction_single_parameter():
    """Test simple extraction when only one parameter is missing."""
    missing_params = [{"parameter": "subject", "question": "What subject?"}]
    
    extracted = ClarificationEngine.extract_simple_responses(
        "Project Update Meeting",
        missing_params
    )

    assert "subject" in extracted
    assert extracted["subject"] == "Project Update Meeting"


def test_simple_extraction_time_expression():
    """Test time expression detection."""
    missing_params = [{"parameter": "start_time", "question": "When?"}]
    
    extracted = ClarificationEngine.extract_simple_responses(
        "tomorrow at 3 PM",
        missing_params
    )

    assert "start_time" in extracted
    assert "tomorrow" in extracted["start_time"]
    assert "pm" in extracted["start_time"].lower()


@pytest.mark.asyncio
async def test_clarification_state_accumulation():
    """Test that clarification state accumulates across turns."""
    # Simulate first turn with partial information
    initial_intent = IntentClassification(
        intent="create_event",
        services=["calendar"],
        entities={"summary": "Team Standup"},
        ambiguous=False,
    )

    # Simulated clarification response providing time
    clarification_response = "tomorrow at 10 AM"
    
    # Merge the clarification (note: in real usage this would call LLM)
    # For testing, we'll manually construct the expected state
    existing_state = {"summary": "Team Standup"}
    
    # Simple extraction should pick up time
    missing_params = [{"parameter": "start_time", "question": "When?"}]
    extracted = ClarificationEngine.extract_simple_responses(
        clarification_response,
        missing_params
    )
    
    # Merge states
    merged_state = {**existing_state, **extracted}
    
    assert "summary" in merged_state
    assert "start_time" in merged_state
    assert "tomorrow" in merged_state["start_time"]


def test_validation_with_clarification_state():
    """Test parameter validation uses clarification state."""
    intent = IntentClassification(
        intent="send_email",
        services=["gmail"],
        entities={"recipient": "test@example.com"},
        ambiguous=False,
    )

    # First validation - missing subject and body
    result1 = validate_tool_parameters(intent)
    assert not result1.is_complete
    assert len(result1.missing_parameters) == 2

    # Simulate clarification state with subject provided
    clarification_state = {"recipient": "test@example.com", "subject": "Follow-up"}
    
    result2 = validate_tool_parameters(intent, clarification_state=clarification_state)
    assert not result2.is_complete
    assert len(result2.missing_parameters) == 1  # Only body missing now
    assert result2.missing_parameters[0]["parameter"] == "body"

    # Add body to clarification state
    clarification_state["body"] = "Thanks for your time"
    
    result3 = validate_tool_parameters(intent, clarification_state=clarification_state)
    assert result3.is_complete
    assert len(result3.missing_parameters) == 0
