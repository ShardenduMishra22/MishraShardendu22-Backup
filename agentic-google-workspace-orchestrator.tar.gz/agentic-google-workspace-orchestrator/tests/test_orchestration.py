import uuid
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import AuditLog, PendingAction
from app.orchestration.confirmation import confirm_pending_action, reject_pending_action
from app.orchestration.executor import DAGExecutor, resolve_argument_references
from app.orchestration.models import ExecutionPlan, IntentClassification, PlanStep
from app.orchestration.synthesizer import _deterministic_fallback_synthesis
from app.orchestration.validator import PlanValidationError, validate_execution_plan


def test_resolve_argument_references() -> None:
    """Verify string reference template resolution from completed step outputs."""
    step_outputs = {
        "search_booking": {"flight_no": "TK1234", "passenger": "Alice"},
        "search_calendar": "Event at 10:30 AM",
    }

    # Reference full dict output
    res1 = resolve_argument_references("$steps.search_booking.output", step_outputs)
    assert res1 == {"flight_no": "TK1234", "passenger": "Alice"}

    # Reference sub-field
    res2 = resolve_argument_references("$steps.search_booking.output.flight_no", step_outputs)
    assert res2 == "TK1234"

    # Reference simple string
    res3 = resolve_argument_references("$search_calendar", step_outputs)
    assert res3 == "Event at 10:30 AM"

    # Unrelated string
    res4 = resolve_argument_references("plain text", step_outputs)
    assert res4 == "plain text"


def test_validator_rejects_unknown_tool() -> None:
    """Verify DAG validator rejects steps referencing unknown tools."""
    plan = ExecutionPlan(
        goal="Test",
        steps=[PlanStep(id="s1", tool="non_existent_tool", arguments={})],
    )
    with pytest.raises(PlanValidationError, match="unknown tool"):
        validate_execution_plan(plan)


def test_validator_rejects_duplicate_step_id() -> None:
    """Verify DAG validator rejects duplicate step IDs."""
    plan = ExecutionPlan(
        goal="Test",
        steps=[
            PlanStep(id="s1", tool="gmail.search_emails", arguments={}),
            PlanStep(id="s1", tool="calendar.search_events", arguments={}),
        ],
    )
    with pytest.raises(PlanValidationError, match="Duplicate step ID"):
        validate_execution_plan(plan)


def test_validator_rejects_unknown_dependency() -> None:
    """Verify DAG validator rejects steps referencing non-existent dependency step IDs."""
    plan = ExecutionPlan(
        goal="Test",
        steps=[
            PlanStep(id="s1", tool="gmail.search_emails", arguments={}, depends_on=["missing_step"]),
        ],
    )
    with pytest.raises(PlanValidationError, match="unknown dependency"):
        validate_execution_plan(plan)


def test_validator_rejects_cyclic_dependencies() -> None:
    """Verify DAG validator detects cycles in execution graph."""
    plan = ExecutionPlan(
        goal="Test",
        steps=[
            PlanStep(id="s1", tool="gmail.search_emails", arguments={}, depends_on=["s2"]),
            PlanStep(id="s2", tool="calendar.search_events", arguments={}, depends_on=["s1"]),
        ],
    )
    with pytest.raises(PlanValidationError, match="Cyclic dependency"):
        validate_execution_plan(plan)


def test_validator_accepts_valid_dag() -> None:
    """Verify DAG validator approves valid parallel and dependent step structure."""
    plan = ExecutionPlan(
        goal="Test",
        steps=[
            PlanStep(id="s1", tool="gmail.search_emails", arguments={}),
            PlanStep(id="s2", tool="calendar.search_events", arguments={}),
            PlanStep(id="s3", tool="gmail.draft_email", arguments={}, depends_on=["s1", "s2"]),
        ],
    )
    order = validate_execution_plan(plan)
    assert len(order) == 3
    assert order.index("s1") < order.index("s3")
    assert order.index("s2") < order.index("s3")


@pytest.mark.asyncio
async def test_executor_confirmation_gate() -> None:
    """Verify mutating tool triggers confirmation gate and creates PendingAction."""
    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    mock_db = AsyncMock(spec=AsyncSession)

    plan = ExecutionPlan(
        goal="Send email",
        steps=[
            PlanStep(id="s1", tool="gmail.send_email", arguments={"to": "test@test.com", "subject": "Hi", "body": "Hello"}),
        ],
    )

    executor = DAGExecutor(mock_db, user_id=user_id, run_id=run_id)

    with patch("app.orchestration.executor.AsyncSessionLocal") as mock_session_cls:
        mock_session = AsyncMock(spec=AsyncSession)
        mock_res = MagicMock()
        mock_res.scalar_one_or_none.return_value = None
        mock_session.execute = AsyncMock(return_value=mock_res)

        mock_session_cls.return_value.__aenter__.return_value = mock_session

        res = await executor.execute_plan(plan, conversation_id=uuid.uuid4())

        assert res["status"] == "needs_confirmation"
        assert res["pending_action"]["tool"] == "gmail.send_email"
        mock_session.add.assert_called()


@pytest.mark.asyncio
async def test_confirm_pending_action_and_audit_log() -> None:
    """Verify confirm_pending_action executes tool and creates audit log entry."""
    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    action_id = uuid.uuid4()

    mock_action = PendingAction(
        id=action_id,
        orchestration_run_id=run_id,
        action_type="gmail.send_email",
        payload={"arguments": {"to": "test@test.com", "subject": "Subj", "body": "Body"}},
        status="pending",
    )

    mock_db = AsyncMock(spec=AsyncSession)
    mock_res = MagicMock()
    mock_res.scalar_one_or_none.return_value = mock_action
    mock_db.execute = AsyncMock(return_value=mock_res)

    with patch("app.tools.gmail.GmailSendTool.execute", new_callable=AsyncMock) as mock_tool_exec:
        mock_tool_exec.return_value = {"status": "completed", "message": "Email sent", "message_id": "msg_123"}
        res = await confirm_pending_action(mock_db, user_id=user_id, pending_action_id=action_id)

        assert res["status"] == "completed"
        assert mock_action.status == "completed"
        assert mock_db.add.call_count >= 1  # Audit log added


@pytest.mark.asyncio
async def test_replay_protection_on_confirmed_action() -> None:
    """Verify attempting to re-confirm an already processed action fails with 400."""
    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    action_id = uuid.uuid4()

    mock_action = PendingAction(
        id=action_id,
        orchestration_run_id=run_id,
        action_type="gmail.send_email",
        payload={"arguments": {}},
        status="confirmed",  # Already processed!
    )

    mock_db = AsyncMock(spec=AsyncSession)
    mock_res = MagicMock()
    mock_res.scalar_one_or_none.return_value = mock_action
    mock_db.execute = AsyncMock(return_value=mock_res)

    with pytest.raises(Exception, match="already been processed"):
        await confirm_pending_action(mock_db, user_id=user_id, pending_action_id=action_id)


def test_deterministic_fallback_synthesis() -> None:
    """Verify deterministic synthesis fallback formatting when LLM call is unavailable."""
    query = "Find flight booking"
    completed = {"search_gmail": [{"title": "Flight TK1234"}]}
    statuses = {"search_gmail": "completed", "calendar_lookup": "failed"}

    summary = _deterministic_fallback_synthesis(query, completed, statuses)

    assert "Summary for request: 'Find flight booking'" in summary
    assert "Found 1 item(s) from step 'search_gmail':" in summary
    assert "Step(s) calendar_lookup encountered an issue." in summary


@pytest.mark.asyncio
async def test_recipient_resolution_not_found_triggers_clarification() -> None:
    """Regression Test D: Recipient is a human name with 0 matches -> triggers clarification."""
    from app.orchestration.recipient_resolver import resolve_recipient_email
    mock_db = AsyncMock(spec=AsyncSession)
    user_id = uuid.uuid4()

    mock_res = MagicMock()
    mock_res.scalars.return_value.all.return_value = []
    mock_db.execute = AsyncMock(return_value=mock_res)

    res = await resolve_recipient_email(mock_db, user_id=user_id, recipient="Unknown Person")
    assert res["status"] == "not_found"
    assert res["recipient_name"] == "Unknown Person"


@pytest.mark.asyncio
async def test_recipient_resolution_ambiguous_matches() -> None:
    """Regression Test E: Recipient matches multiple email addresses -> returns ambiguous status."""
    from app.orchestration.recipient_resolver import resolve_recipient_email
    from app.models.models import WorkspaceItem

    mock_db = AsyncMock(spec=AsyncSession)
    user_id = uuid.uuid4()

    item1 = WorkspaceItem(
        id=uuid.uuid4(),
        user_id=user_id,
        service="gmail",
        item_type="email",
        external_id="m1",
        title="Email from John Doe",
        content="From john.doe@company.com",
        metadata_={"sender": "john.doe@company.com"},
    )
    item2 = WorkspaceItem(
        id=uuid.uuid4(),
        user_id=user_id,
        service="gmail",
        item_type="email",
        external_id="m2",
        title="Email from John Smith",
        content="From john.smith@company.com",
        metadata_={"sender": "john.smith@company.com"},
    )

    mock_res = MagicMock()
    mock_res.scalars.return_value.all.return_value = [item1, item2]
    mock_db.execute = AsyncMock(return_value=mock_res)

    res = await resolve_recipient_email(mock_db, user_id=user_id, recipient="John")
    assert res["status"] == "ambiguous"
    assert len(res["matches"]) == 2
    assert "john.doe@company.com" in res["matches"]
    assert "john.smith@company.com" in res["matches"]


@pytest.mark.asyncio
async def test_explicit_email_recipient_resolves_directly() -> None:
    """Regression Test F: Explicit valid email address resolves directly without DB lookup."""
    from app.orchestration.recipient_resolver import resolve_recipient_email
    mock_db = AsyncMock(spec=AsyncSession)
    user_id = uuid.uuid4()

    res = await resolve_recipient_email(mock_db, user_id=user_id, recipient="target@example.com")
    assert res["status"] == "resolved"
    assert res["email"] == "target@example.com"


@pytest.mark.asyncio
async def test_executor_json_serialization_boundary() -> None:
    """Regression Test: Verify executor serializes UUID, datetime, and nested structures into JSONB without errors."""
    from datetime import datetime, timezone
    from fastapi.encoders import jsonable_encoder

    item_id = uuid.uuid4()
    nested_id = uuid.uuid4()
    now = datetime.now(timezone.utc)

    raw_tool_output = {
        "item_id": item_id,
        "created_at": now,
        "nested": {
            "ids": [nested_id],
        },
    }

    serialized = jsonable_encoder(raw_tool_output)

    assert isinstance(serialized["item_id"], str)
    assert serialized["item_id"] == str(item_id)
    assert isinstance(serialized["created_at"], str)
    assert serialized["nested"]["ids"][0] == str(nested_id)


def test_extract_requested_limit_variations() -> None:
    """Regression Test: Verify count extraction across user query variations."""
    from app.orchestration.planner import extract_requested_limit

    assert extract_requested_limit("last 3 emails") == 3
    assert extract_requested_limit("latest 2 mails") == 2
    assert extract_requested_limit("newest email") == 1
    assert extract_requested_limit("last 10 emails") == 10
    assert extract_requested_limit("recent emails") == 5
    assert extract_requested_limit("can u summarise last 3 mails in my inbox") == 3


def test_fallback_planner_limit_propagation() -> None:
    """Regression Test: Verify fallback planner preserves extracted limit without LLM."""
    from app.orchestration.planner import _build_fallback_plan
    from app.orchestration.models import IntentClassification

    intent = IntentClassification(intent="search_email", services=["gmail"], entities={}, ambiguous=False)
    plan = _build_fallback_plan("can u summarise last 3 mails in my inbox", intent)

    assert len(plan.steps) == 1
    assert plan.steps[0].tool == "gmail.search_emails"
    assert plan.steps[0].arguments["limit"] == 3
    assert plan.steps[0].arguments["sort"] == "newest"
