import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from app.integrations.gemini import GeminiClient, GeminiError, GeminiRateLimitError


@pytest.mark.asyncio
async def test_gemini_client_missing_api_key() -> None:
    """Verify GeminiClient raises GeminiError when API key is missing."""
    client = GeminiClient(api_key="")
    with pytest.raises(GeminiError, match="GEMINI_API_KEY is not configured"):
        await client.chat_completion([{"role": "user", "content": "Hello"}])


@pytest.mark.asyncio
async def test_gemini_client_chat_completion_success() -> None:
    """Verify GeminiClient converts messages and parses response candidates correctly."""
    client = GeminiClient(api_key="test_key", model="gemini-3.5-flash-lite")

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "candidates": [
            {
                "content": {
                    "parts": [{"text": '{"intent": "search_email"}'}]
                }
            }
        ]
    }

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = mock_resp
        res = await client.chat_completion(
            messages=[{"role": "system", "content": "Instruction"}, {"role": "user", "content": "Hi"}],
            temperature=0.0,
        )

        assert res == '{"intent": "search_email"}'
        assert mock_post.called
        call_kwargs = mock_post.call_args.kwargs
        payload = call_kwargs["json"]
        assert payload["systemInstruction"]["parts"][0]["text"] == "Instruction"
        assert payload["contents"][0]["role"] == "user"
        assert payload["contents"][0]["parts"][0]["text"] == "Hi"


@pytest.mark.asyncio
async def test_gemini_client_rate_limit_handling() -> None:
    """Verify GeminiClient raises GeminiRateLimitError immediately on HTTP 429."""
    client = GeminiClient(api_key="test_key", model="gemini-3.5-flash-lite")

    mock_resp = MagicMock()
    mock_resp.status_code = 429
    mock_resp.text = "Quota exceeded"

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = mock_resp
        with pytest.raises(GeminiRateLimitError, match="Gemini API rate limit"):
            await client.chat_completion([{"role": "user", "content": "Test"}])
