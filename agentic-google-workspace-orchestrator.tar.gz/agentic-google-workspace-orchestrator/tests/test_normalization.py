import uuid
from app.services.normalization import (
    normalize_calendar_event,
    normalize_drive_file,
    normalize_gmail_message,
)


def test_normalize_gmail_message() -> None:
    user_id = uuid.uuid4()
    raw = {
        "external_id": "msg123",
        "thread_id": "thread456",
        "subject": "Team Meeting Update",
        "sender": "boss@company.com",
        "recipients": "team@company.com",
        "received_at": "Sun, 26 Jul 2026 19:00:00 +0000",
        "body": "Let's review Q3 goals tomorrow.",
        "labels": ["INBOX", "UNREAD"],
    }

    norm = normalize_gmail_message(raw, user_id)

    assert norm["user_id"] == user_id
    assert norm["service"] == "gmail"
    assert norm["item_type"] == "email"
    assert norm["external_id"] == "msg123"
    assert norm["title"] == "Team Meeting Update"
    assert norm["content"] == "Let's review Q3 goals tomorrow."
    assert norm["metadata"]["sender"] == "boss@company.com"
    assert norm["source_created_at"] is not None


def test_normalize_calendar_event() -> None:
    user_id = uuid.uuid4()
    raw = {
        "external_id": "evt789",
        "summary": "1-on-1 Sync",
        "description": "Weekly catchup meeting",
        "start": "2026-07-27T10:00:00Z",
        "end": "2026-07-27T10:30:00Z",
        "timezone": "UTC",
        "attendees": ["alice@company.com", "bob@company.com"],
        "organizer": "alice@company.com",
        "location": "Room 101",
        "status": "confirmed",
    }

    norm = normalize_calendar_event(raw, user_id)

    assert norm["user_id"] == user_id
    assert norm["service"] == "calendar"
    assert norm["item_type"] == "calendar_event"
    assert norm["external_id"] == "evt789"
    assert norm["title"] == "1-on-1 Sync"
    assert "Weekly catchup meeting" in norm["content"]
    assert norm["metadata"]["location"] == "Room 101"


def test_normalize_drive_file() -> None:
    user_id = uuid.uuid4()
    raw = {
        "external_id": "file999",
        "name": "Q3 Roadmap.docx",
        "mime_type": "application/vnd.google-apps.document",
        "content": "Roadmap document details and goals...",
        "owners": ["owner@company.com"],
        "created_time": "2026-07-01T00:00:00Z",
        "modified_time": "2026-07-20T12:00:00Z",
    }

    norm = normalize_drive_file(raw, user_id)

    assert norm["user_id"] == user_id
    assert norm["service"] == "drive"
    assert norm["item_type"] == "drive_file"
    assert norm["external_id"] == "file999"
    assert norm["title"] == "Q3 Roadmap.docx"
    assert norm["content"] == "Roadmap document details and goals..."
    assert norm["metadata"]["mime_type"] == "application/vnd.google-apps.document"
