import uuid
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import OrchestrationRun, PendingAction
from app.orchestration.confirmation import (
    confirm_all_pending_actions,
    reject_all_pending_actions,
)
from app.orchestration.executor import DAGExecutor
from app.orchestration.models import ExecutionPlan, IntentClassification, PlanStep
from app.orchestration.planner import generate_execution_plan


@pytest.mark.asyncio
async def test_e2e_multiservice_dag_generation() -> None:
    """End-to-end test for multi-service prompt DAG generation."""
    query = (
        "I'm interviewing Shardendu Mishra for a Software Engineer position.\n"
        "Find my latest resume in Google Drive and generate a shareable link.\n"
        "Schedule a 30-minute 'Resume Screening' meeting on July 29 at 5:00 PM in Google Calendar.\n"
        "Draft an invitation email to shardendumishra02@gmail.com mentioning the meeting details and including the resume link."
    )

    intent = IntentClassification(
        intent="prepare_meeting",
        services=["gmail", "calendar", "drive"],
        entities={
            "recipient": "shardendumishra02@gmail.com",
            "attendee": "shardendumishra02@gmail.com",
            "topic": "Resume Screening",
        },
        ambiguous=False,
    )

    with patch("app.orchestration.planner.llm_chat_completion") as mock_llm:
        mock_llm.return_value = """```json
{
  "goal": "Prepare interview meeting and invite candidate with resume link",
  "steps": [
    {
      "id": "search_resume",
      "tool": "drive.search_files",
      "arguments": {"query": "resume"},
      "depends_on": []
    },
    {
      "id": "generate_share_link",
      "tool": "drive.share_file",
      "arguments": {"external_id": "$steps.search_resume.output.files[0].id"},
      "depends_on": ["search_resume"]
    },
    {
      "id": "create_calendar_event",
      "tool": "calendar.create_event",
      "arguments": {
        "summary": "Resume Screening",
        "start_time": "2026-07-29T17:00:00+05:30",
        "end_time": "2026-07-29T17:30:00+05:30",
        "attendees": ["shardendumishra02@gmail.com"]
      },
      "depends_on": []
    },
    {
      "id": "send_invitation_email",
      "tool": "gmail.send_email",
      "arguments": {
        "to": "shardendumishra02@gmail.com",
        "subject": "Invitation: Resume Screening Meeting",
        "body": "Hi Shardendu, please join the meeting."
      },
      "depends_on": ["search_resume"]
    }
  ]
}
```"""

        plan = await generate_execution_plan(query, intent=intent, conversation_history=[])
        assert len(plan.steps) == 4
        tools = [s.tool for s in plan.steps]
        assert "drive.search_files" in tools
        assert "drive.share_file" in tools
        assert "calendar.create_event" in tools
        assert "gmail.send_email" in tools


@pytest.mark.asyncio
async def test_executor_returns_single_confirmation_with_all_pending_actions() -> None:
    """Verify the executor pauses with ALL pending write actions listed."""
    plan = ExecutionPlan(
        goal="Test multi-service workflow",
        steps=[
            PlanStep(id="search", tool="drive.search_files", arguments={"query": "resume"}, depends_on=[]),
            PlanStep(id="share", tool="drive.share_file", arguments={"file_id": "123"}, depends_on=["search"]),
            PlanStep(id="create_event", tool="calendar.create_event", arguments={"summary": "Test"}, depends_on=[]),
            PlanStep(id="send_email", tool="gmail.send_email", arguments={"to": "test@test.com"}, depends_on=["search"]),
        ],
    )

    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    mock_db = AsyncMock(spec=AsyncSession)

    executor = DAGExecutor(mock_db, user_id=user_id, run_id=run_id)

    with patch("app.orchestration.executor.AsyncSessionLocal") as mock_session_cls, \
         patch("app.tools.registry.tool_registry.get_tool") as mock_get_tool:

        mock_session = AsyncMock(spec=AsyncSession)
        mock_res = MagicMock()
        mock_res.scalar_one_or_none.return_value = None
        mock_session.execute = AsyncMock(return_value=mock_res)
        mock_session_cls.return_value.__aenter__.return_value = mock_session

        mock_search_tool = MagicMock()
        mock_search_tool.requires_confirmation = False
        mock_search_tool.execute = AsyncMock(return_value={"files": [{"id": "res_123"}]})

        mock_mutating_tool = MagicMock()
        mock_mutating_tool.requires_confirmation = True

        def tool_side_effect(name):
            if name == "drive.search_files":
                return mock_search_tool
            return mock_mutating_tool

        mock_get_tool.side_effect = tool_side_effect

        exec_res = await executor.execute_plan(plan, conversation_id=uuid.uuid4())

        # Single confirmation gate with all 3 write actions
        assert exec_res["status"] == "needs_confirmation"
        pending_actions = exec_res["pending_actions"]
        assert len(pending_actions) == 3

        action_types = {a["action_type"] for a in pending_actions}
        assert "drive.share_file" in action_types
        assert "calendar.create_event" in action_types
        assert "gmail.send_email" in action_types


@pytest.mark.asyncio
async def test_batch_confirm_all_executes_every_action() -> None:
    """Case 1: Approve all → all 3 actions execute in order → status completed."""
    user_id = uuid.uuid4()
    run_id = uuid.uuid4()

    run = OrchestrationRun(id=run_id, user_id=user_id, query="test", status="needs_confirmation")
    act1 = PendingAction(id=uuid.uuid4(), orchestration_run_id=run_id, action_type="drive.share_file", payload={"arguments": {"file_id": "123"}}, status="pending")
    act2 = PendingAction(id=uuid.uuid4(), orchestration_run_id=run_id, action_type="calendar.create_event", payload={"arguments": {"summary": "Test"}}, status="pending")
    act3 = PendingAction(id=uuid.uuid4(), orchestration_run_id=run_id, action_type="gmail.send_email", payload={"arguments": {"to": "a@b.com"}}, status="pending")

    mock_db = AsyncMock(spec=AsyncSession)

    # First call: run lookup, second: pending actions query
    mock_run_res = MagicMock()
    mock_run_res.scalar_one_or_none.return_value = run

    mock_actions_res = MagicMock()
    mock_actions_res.scalars.return_value.all.return_value = [act1, act2, act3]

    mock_db.execute = AsyncMock(side_effect=[mock_run_res, mock_actions_res])

    with patch("app.orchestration.confirmation.tool_registry.get_tool") as mock_get_tool:
        mock_tool = MagicMock()
        mock_tool.execute = AsyncMock(return_value={"message": "OK"})
        mock_get_tool.return_value = mock_tool

        res = await confirm_all_pending_actions(mock_db, user_id=user_id, run_id=run_id)

        assert res["status"] == "completed"
        assert "✓ drive.share_file" in res["message"]
        assert "✓ calendar.create_event" in res["message"]
        assert "✓ gmail.send_email" in res["message"]
        assert len(res["results"]) == 3
        assert all(r["status"] == "completed" for r in res["results"])


@pytest.mark.asyncio
async def test_batch_reject_all_cancels_workflow() -> None:
    """Case 2: Reject all → no actions execute → status cancelled."""
    user_id = uuid.uuid4()
    run_id = uuid.uuid4()

    run = OrchestrationRun(id=run_id, user_id=user_id, query="test", status="needs_confirmation")
    act1 = PendingAction(id=uuid.uuid4(), orchestration_run_id=run_id, action_type="drive.share_file", payload={"arguments": {}}, status="pending")
    act2 = PendingAction(id=uuid.uuid4(), orchestration_run_id=run_id, action_type="calendar.create_event", payload={"arguments": {}}, status="pending")
    act3 = PendingAction(id=uuid.uuid4(), orchestration_run_id=run_id, action_type="gmail.send_email", payload={"arguments": {}}, status="pending")

    mock_db = AsyncMock(spec=AsyncSession)

    mock_run_res = MagicMock()
    mock_run_res.scalar_one_or_none.return_value = run

    mock_actions_res = MagicMock()
    mock_actions_res.scalars.return_value.all.return_value = [act1, act2, act3]

    mock_db.execute = AsyncMock(side_effect=[mock_run_res, mock_actions_res])

    res = await reject_all_pending_actions(mock_db, user_id=user_id, run_id=run_id)

    assert res["status"] == "cancelled"
    assert res["message"] == "The workflow was cancelled. No changes were made."
    assert len(res["rejected_actions"]) == 3
    assert all(a.status == "rejected" for a in [act1, act2, act3])


@pytest.mark.asyncio
async def test_e2e_forced_drive_share_failure_blocks_workflow() -> None:
    """Failure test: Force drive.share_file to fail.

    Expected:
    - search_resume -> COMPLETED
    - share_resume -> FAILED
    - send_invitation_email -> BLOCKED (because share_resume failed)
    - workflow -> FAILED
    """
    plan = ExecutionPlan(
        goal="Prepare interview meeting and invite candidate with resume link",
        steps=[
            PlanStep(id="search_resume", tool="drive.search_files", arguments={"query": "resume"}, depends_on=[]),
            PlanStep(id="share_resume", tool="drive.share_file", arguments={"external_id": "$steps.search_resume.output"}, depends_on=["search_resume"]),
            PlanStep(id="create_calendar_event", tool="calendar.create_event", arguments={"summary": "Resume Screening"}, depends_on=[]),
            PlanStep(id="send_invitation_email", tool="gmail.send_email", arguments={"to": "shardendumishra02@gmail.com", "body": "See $steps.share_resume.output"}, depends_on=["share_resume"]),
        ],
    )

    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    mock_db = AsyncMock(spec=AsyncSession)

    executor = DAGExecutor(mock_db, user_id=user_id, run_id=run_id)

    with patch("app.orchestration.executor.AsyncSessionLocal") as mock_session_cls, \
         patch("app.tools.registry.tool_registry.get_tool") as mock_get_tool:

        mock_session = AsyncMock(spec=AsyncSession)
        mock_res = MagicMock()
        mock_res.scalar_one_or_none.return_value = None
        mock_session.execute = AsyncMock(return_value=mock_res)
        mock_session_cls.return_value.__aenter__.return_value = mock_session

        mock_search_tool = MagicMock()
        mock_search_tool.requires_confirmation = False
        mock_search_tool.execute = AsyncMock(return_value=[{"id": "doc1", "external_id": "ext1"}])

        # Forced failing share tool
        mock_share_tool = MagicMock()
        mock_share_tool.name = "drive.share_file"
        mock_share_tool.requires_confirmation = False
        mock_share_tool.execute = AsyncMock(side_effect=Exception("Google Drive API permission error: file not found"))

        mock_calendar_tool = MagicMock()
        mock_calendar_tool.requires_confirmation = True

        mock_send_email_tool = MagicMock()
        mock_send_email_tool.requires_confirmation = True

        def tool_side_effect(name):
            if name == "drive.search_files":
                return mock_search_tool
            elif name == "drive.share_file":
                return mock_share_tool
            elif name == "calendar.create_event":
                return mock_calendar_tool
            return mock_send_email_tool

        mock_get_tool.side_effect = tool_side_effect

        exec_res = await executor.execute_plan(plan, conversation_id=uuid.uuid4())

        assert exec_res["status"] == "failed"
        step_statuses = exec_res["step_statuses"]
        assert step_statuses["search_resume"] == "completed"
        assert step_statuses["share_resume"] == "failed"
        assert step_statuses["send_invitation_email"] == "blocked"


@pytest.mark.asyncio
async def test_e2e_full_workflow_approval_and_execution_send_email() -> None:
    """Complete E2E Test:
    1. Search resume succeeds
    2. Share file, Create Calendar, Send Email queued for confirmation
    3. User approves workflow
    4. Share file executes -> generates link
    5. Calendar event created
    6. Email is SENT via gmail.send_email with the generated Drive link in body
    7. Workflow status -> COMPLETED
    """
    plan = ExecutionPlan(
        goal="Prepare interview meeting and send invitation email with resume link",
        steps=[
            PlanStep(id="search_resume", tool="drive.search_files", arguments={"query": "resume"}, depends_on=[]),
            PlanStep(id="share_resume", tool="drive.share_file", arguments={"external_id": "$steps.search_resume[0].external_id", "target_email": "shardendumishra02@gmail.com"}, depends_on=["search_resume"]),
            PlanStep(id="create_calendar_event", tool="calendar.create_event", arguments={"summary": "Resume Screening", "start_time": "2026-07-29T17:00:00+05:30", "end_time": "2026-07-29T17:30:00+05:30"}, depends_on=[]),
            PlanStep(id="send_invitation_email", tool="gmail.send_email", arguments={"to": "shardendumishra02@gmail.com", "subject": "Invitation: Resume Screening", "body": "Hi Shardendu, link: $steps.share_resume.output.web_view_link"}, depends_on=["share_resume"]),
        ],
    )

    user_id = uuid.uuid4()
    run_id = uuid.uuid4()
    mock_db = AsyncMock(spec=AsyncSession)

    executor = DAGExecutor(mock_db, user_id=user_id, run_id=run_id)

    with patch("app.orchestration.executor.AsyncSessionLocal") as mock_session_cls, \
         patch("app.tools.registry.tool_registry.get_tool") as mock_get_tool, \
         patch("app.orchestration.confirmation.tool_registry.get_tool") as mock_confirm_get_tool:

        mock_session = AsyncMock(spec=AsyncSession)
        mock_res = MagicMock()
        mock_res.scalar_one_or_none.return_value = None
        mock_session.execute = AsyncMock(return_value=mock_res)
        mock_session_cls.return_value.__aenter__.return_value = mock_session

        from app.tools.drive import DriveShareInput
        from app.tools.calendar import CalendarCreateInput
        from app.tools.gmail import GmailSendInput

        mock_search_tool = MagicMock()
        mock_search_tool.requires_confirmation = False
        mock_search_tool.execute = AsyncMock(return_value=[{"id": "doc123", "external_id": "ext_resume_999", "title": "Shardendu_Resume.pdf"}])

        mock_share_tool = MagicMock()
        mock_share_tool.name = "drive.share_file"
        mock_share_tool.input_model = DriveShareInput
        mock_share_tool.requires_confirmation = True

        mock_calendar_tool = MagicMock()
        mock_calendar_tool.name = "calendar.create_event"
        mock_calendar_tool.input_model = CalendarCreateInput
        mock_calendar_tool.requires_confirmation = True

        mock_send_email_tool = MagicMock()
        mock_send_email_tool.name = "gmail.send_email"
        mock_send_email_tool.input_model = GmailSendInput
        mock_send_email_tool.requires_confirmation = True

        def tool_side_effect(name):
            if name == "drive.search_files":
                return mock_search_tool
            elif name == "drive.share_file":
                return mock_share_tool
            elif name == "calendar.create_event":
                return mock_calendar_tool
            return mock_send_email_tool

        mock_get_tool.side_effect = tool_side_effect
        mock_confirm_get_tool.side_effect = tool_side_effect

        exec_res = await executor.execute_plan(plan, conversation_id=uuid.uuid4())

        assert exec_res["status"] == "needs_confirmation"
        assert len(exec_res["pending_actions"]) == 3

        # Create mock run and pending actions for batch confirmation
        run = OrchestrationRun(id=run_id, user_id=user_id, query="test", status="needs_confirmation")
        actions = []
        for act_dict in exec_res["pending_actions"]:
            actions.append(
                PendingAction(
                    id=uuid.uuid4(),
                    orchestration_run_id=run_id,
                    action_type=act_dict["action_type"],
                    payload={"arguments": act_dict["payload"], "step_id": act_dict["step_id"]},
                    status="pending",
                )
            )

        mock_run_res = MagicMock()
        mock_run_res.scalar_one_or_none.return_value = run

        mock_actions_res = MagicMock()
        mock_actions_res.scalars.return_value.all.return_value = actions

        mock_empty_res = MagicMock()
        mock_empty_res.scalars.return_value.all.return_value = []
        mock_empty_res.scalars.return_value.first.return_value = None

        mock_db.execute = AsyncMock(side_effect=[
            mock_run_res,
            mock_actions_res,
            mock_empty_res,
            mock_empty_res,
            mock_empty_res,
            mock_empty_res,
            mock_empty_res,
            mock_empty_res,
        ])

        # Mock actual execution of tools during batch confirm
        mock_share_tool.execute = AsyncMock(return_value={"status": "completed", "external_id": "ext_resume_999", "web_view_link": "https://drive.google.com/file/d/ext_resume_999/view"})
        mock_calendar_tool.execute = AsyncMock(return_value={"status": "completed", "event_id": "cal_evt_789", "summary": "Resume Screening"})
        mock_send_email_tool.execute = AsyncMock(return_value={"status": "completed", "message_id": "msg_sent_001", "to": "shardendumishra02@gmail.com"})

        confirm_res = await confirm_all_pending_actions(mock_db, user_id=user_id, run_id=run_id)

        assert confirm_res["status"] == "completed"
        assert "✓ drive.share_file" in confirm_res["message"]
        assert "✓ calendar.create_event" in confirm_res["message"]
        assert "✓ gmail.send_email" in confirm_res["message"]

        # Verify gmail.send_email was invoked with resolved Drive URL in body
        mock_send_email_tool.execute.assert_called_once()
        call_kwargs = mock_send_email_tool.execute.call_args.kwargs
        assert call_kwargs.get("to") == "shardendumishra02@gmail.com"
        assert "https://drive.google.com/file/d/ext_resume_999/view" in call_kwargs.get("body", "")


