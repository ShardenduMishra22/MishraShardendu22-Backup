import uuid
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Conversation, OrchestrationRun
from app.orchestration.models import ExecutionPlan, IntentClassification, PlanStep
from app.orchestration.service import orchestrate_query


@pytest.mark.asyncio
async def test_clarification_continuation_case1_calendar_and_email() -> None:
    """Case 1: User asks to create a meeting with John and send him the agenda.
    After clarification 'Tomorrow 5 PM.', BOTH calendar.create_event and gmail.send_email must execute.
    """
    user_id = uuid.uuid4()
    conv_id = uuid.uuid4()

    # 1. Setup mock conversation and pending clarification run
    mock_conv = Conversation(id=conv_id, user_id=user_id)
    mock_pending_run = OrchestrationRun(
        id=uuid.uuid4(),
        user_id=user_id,
        conversation_id=conv_id,
        query="Create a meeting with John (john@example.com) and send him the agenda.",
        status="needs_clarification",
    )

    mock_db = AsyncMock(spec=AsyncSession)

    def mock_execute_side_effect(stmt):
        mock_res = MagicMock()
        stmt_str = str(stmt)
        if "orchestration_runs" in stmt_str:
            mock_res.scalars.return_value.first.return_value = mock_pending_run
        else:
            mock_res.scalars.return_value.first.return_value = None
            mock_res.scalars.return_value.all.return_value = []
        return mock_res

    mock_db.execute.side_effect = mock_execute_side_effect

    # Mock conversation getters and history
    with patch("app.orchestration.service.get_or_create_conversation", return_value=mock_conv), \
         patch("app.orchestration.service.save_message"), \
         patch("app.orchestration.service.load_conversation_history", return_value=[]), \
         patch("app.orchestration.clarification_engine.classify_intent") as mock_classify, \
         patch("app.orchestration.service.generate_execution_plan") as mock_plan, \
         patch("app.orchestration.service.DAGExecutor") as mock_executor_cls, \
         patch("app.orchestration.service.synthesize_response", return_value="Meeting scheduled and email sent."):

        # Mock classify_intent returning non-ambiguous multi-service intent
        mock_classify.return_value = IntentClassification(
            intent="create_event",
            services=["calendar", "gmail"],
            entities={"recipient": "john@example.com", "attendee": "john@example.com"},
            ambiguous=False,
        )

        # Mock planner returning plan with BOTH calendar and gmail steps
        planned_steps = [
            PlanStep(id="step1", tool="calendar.create_event", arguments={"summary": "Meeting with John", "start_time": "2026-07-29T17:00:00+05:30"}),
            PlanStep(id="step2", tool="gmail.send_email", arguments={"to": "john@example.com", "subject": "Agenda", "body": "Here is the agenda"}),
        ]
        mock_plan.return_value = ExecutionPlan(goal="Create meeting and send agenda", steps=planned_steps)

        mock_executor = AsyncMock()
        mock_executor.execute_plan.return_value = {
            "status": "needs_confirmation",
            "pending_actions": [
                {"pending_action_id": "act1", "action_type": "calendar.create_event"},
                {"pending_action_id": "act2", "action_type": "gmail.send_email"},
            ],
            "step_statuses": {"step1": "waiting_confirmation", "step2": "waiting_confirmation"},
        }
        mock_executor_cls.return_value = mock_executor

        res = await orchestrate_query(
            db=mock_db,
            user_id=user_id,
            query="Tomorrow 5 PM.",
            conversation_id=conv_id,
        )

        # Verify effective query passed to classify_intent and generate_execution_plan contains original request
        classified_query = mock_classify.call_args[0][0]
        assert "Create a meeting with John" in classified_query
        assert "User's answer: " in classified_query

        # Verify pending run status updated
        assert mock_pending_run.status == "needs_confirmation"

        # Verify BOTH pending actions (calendar + gmail) are returned in response
        assert res["status"] == "needs_confirmation"
        assert len(res["pending_actions"]) == 2
        tool_names = [a["action_type"] for a in res["pending_actions"]]
        assert "calendar.create_event" in tool_names
        assert "gmail.send_email" in tool_names


@pytest.mark.asyncio
async def test_clarification_continuation_case2_calendar_drive_gmail() -> None:
    """Case 2: Original 'Invite Sarah, attach my resume, and schedule a meeting.'
    Clarification: 'Friday 3 PM for one hour.'
    Expected: Calendar, Drive, and Gmail tools all present in execution plan.
    """
    user_id = uuid.uuid4()
    conv_id = uuid.uuid4()

    mock_conv = Conversation(id=conv_id, user_id=user_id)
    mock_pending_run = OrchestrationRun(
        id=uuid.uuid4(),
        user_id=user_id,
        conversation_id=conv_id,
        query="Invite Sarah (sarah@example.com), attach my resume, and schedule a meeting.",
        status="needs_clarification",
    )

    mock_db = AsyncMock(spec=AsyncSession)

    def mock_execute_side_effect(stmt):
        mock_res = MagicMock()
        stmt_str = str(stmt)
        if "orchestration_runs" in stmt_str:
            mock_res.scalars.return_value.first.return_value = mock_pending_run
        else:
            mock_res.scalars.return_value.first.return_value = None
            mock_res.scalars.return_value.all.return_value = []
        return mock_res

    mock_db.execute.side_effect = mock_execute_side_effect

    with patch("app.orchestration.service.get_or_create_conversation", return_value=mock_conv), \
         patch("app.orchestration.service.save_message"), \
         patch("app.orchestration.service.load_conversation_history", return_value=[]), \
         patch("app.orchestration.clarification_engine.classify_intent") as mock_classify, \
         patch("app.orchestration.service.generate_execution_plan") as mock_plan, \
         patch("app.orchestration.service.DAGExecutor") as mock_executor_cls, \
         patch("app.orchestration.service.synthesize_response", return_value="Meeting scheduled, resume shared, email sent."):

        mock_classify.return_value = IntentClassification(
            intent="prepare_meeting",
            services=["calendar", "drive", "gmail"],
            entities={"recipient": "sarah@example.com", "attendee": "sarah@example.com", "topic": "resume"},
            ambiguous=False,
        )

        planned_steps = [
            PlanStep(id="step1", tool="calendar.create_event", arguments={"summary": "Meeting with Sarah", "start_time": "2026-07-31T15:00:00+05:30"}),
            PlanStep(id="step2", tool="drive.search_files", arguments={"query": "resume"}),
            PlanStep(id="step3", tool="drive.share_file", arguments={"file_id": "$steps.step2.output", "email": "sarah@example.com"}, depends_on=["step2"]),
            PlanStep(id="step4", tool="gmail.send_email", arguments={"to": "sarah@example.com", "subject": "Invitation", "body": "See attached resume"}, depends_on=["step1", "step3"]),
        ]
        mock_plan.return_value = ExecutionPlan(goal="Schedule meeting, share resume, send invite", steps=planned_steps)

        mock_executor = AsyncMock()
        mock_executor.execute_plan.return_value = {
            "status": "needs_confirmation",
            "pending_actions": [
                {"pending_action_id": "act1", "action_type": "calendar.create_event"},
                {"pending_action_id": "act3", "action_type": "drive.share_file"},
                {"pending_action_id": "act4", "action_type": "gmail.send_email"},
            ],
            "step_statuses": {"step1": "waiting_confirmation", "step2": "completed", "step3": "waiting_confirmation", "step4": "waiting_confirmation"},
        }
        mock_executor_cls.return_value = mock_executor

        res = await orchestrate_query(
            db=mock_db,
            user_id=user_id,
            query="Friday 3 PM for one hour.",
            conversation_id=conv_id,
        )

        classified_query = mock_classify.call_args[0][0]
        assert "Invite Sarah" in classified_query
        assert "Friday 3 PM for one hour." in classified_query

        # Check all 3 services are represented in pending actions
        assert res["status"] == "needs_confirmation"
        assert len(res["pending_actions"]) == 3
        tools = [a["action_type"] for a in res["pending_actions"]]
        assert "calendar.create_event" in tools
        assert "drive.share_file" in tools
        assert "gmail.send_email" in tools


@pytest.mark.asyncio
async def test_clarification_continuation_case3_acme_meeting_preparation() -> None:
    """Case 3: Original 'Prepare for tomorrow's meeting with Acme.'
    Clarification: 'Meeting is at 2 PM.'
    Expected: Calendar, Drive, and Gmail search & execution steps all included.
    """
    user_id = uuid.uuid4()
    conv_id = uuid.uuid4()

    mock_conv = Conversation(id=conv_id, user_id=user_id)
    mock_pending_run = OrchestrationRun(
        id=uuid.uuid4(),
        user_id=user_id,
        conversation_id=conv_id,
        query="Prepare for tomorrow's meeting with Acme.",
        status="needs_clarification",
    )

    mock_db = AsyncMock(spec=AsyncSession)

    def mock_execute_side_effect(stmt):
        mock_res = MagicMock()
        stmt_str = str(stmt)
        if "orchestration_runs" in stmt_str:
            mock_res.scalars.return_value.first.return_value = mock_pending_run
        else:
            mock_res.scalars.return_value.first.return_value = None
            mock_res.scalars.return_value.all.return_value = []
        return mock_res

    mock_db.execute.side_effect = mock_execute_side_effect

    with patch("app.orchestration.service.get_or_create_conversation", return_value=mock_conv), \
         patch("app.orchestration.service.save_message"), \
         patch("app.orchestration.service.load_conversation_history", return_value=[]), \
         patch("app.orchestration.clarification_engine.classify_intent") as mock_classify, \
         patch("app.orchestration.service.generate_execution_plan") as mock_plan, \
         patch("app.orchestration.service.DAGExecutor") as mock_executor_cls, \
         patch("app.orchestration.service.synthesize_response", return_value="Prepared meeting brief for Acme."):

        mock_classify.return_value = IntentClassification(
            intent="prepare_meeting",
            services=["calendar", "drive", "gmail"],
            entities={"company": "Acme"},
            ambiguous=False,
        )

        planned_steps = [
            PlanStep(id="search_cal", tool="calendar.search_events", arguments={"query": "Acme"}),
            PlanStep(id="search_mail", tool="gmail.search_emails", arguments={"query": "Acme"}),
            PlanStep(id="search_doc", tool="drive.search_files", arguments={"query": "Acme"}),
        ]
        mock_plan.return_value = ExecutionPlan(goal="Prepare for Acme meeting", steps=planned_steps)

        mock_executor = AsyncMock()
        mock_executor.execute_plan.return_value = {
            "status": "completed",
            "completed_outputs": {
                "search_cal": [{"summary": "Acme Sync"}],
                "search_mail": [{"subject": "Acme Notes"}],
                "search_doc": [{"name": "Acme Proposal.pdf"}],
            },
            "step_statuses": {"search_cal": "completed", "search_mail": "completed", "search_doc": "completed"},
        }
        mock_executor_cls.return_value = mock_executor

        res = await orchestrate_query(
            db=mock_db,
            user_id=user_id,
            query="Meeting is at 2 PM.",
            conversation_id=conv_id,
        )

        classified_query = mock_classify.call_args[0][0]
        assert "Prepare for tomorrow's meeting with Acme." in classified_query
        assert "Meeting is at 2 PM." in classified_query

        assert res["status"] == "completed"
        actions = res["actions_taken"]
        executed_tools = [a["step_id"] for a in actions]
        assert "search_cal" in executed_tools
        assert "search_mail" in executed_tools
        assert "search_doc" in executed_tools
