import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import User, WorkspaceChunk, WorkspaceItem
from app.retrieval.fts import search_lexical_candidates
from app.retrieval.fusion import perform_rrf_fusion
from app.retrieval.models import CandidateChunk, SearchFilters
from app.retrieval.search import search_workspace
from app.retrieval.vector import search_vector_candidates


@pytest.mark.asyncio
async def test_rrf_scoring_and_deduplication() -> None:
    """Verify Reciprocal Rank Fusion calculation and chunk deduplication per item."""
    item1_id = uuid.uuid4()
    item2_id = uuid.uuid4()
    chunk1_id = uuid.uuid4()
    chunk2_id = uuid.uuid4()
    chunk3_id = uuid.uuid4()

    # Candidate lists
    lexical = [
        CandidateChunk(chunk_id=chunk1_id, workspace_item_id=item1_id, chunk_index=0, content="chunk 1 text", rank=1, raw_score=0.9, search_type="lexical"),
        CandidateChunk(chunk_id=chunk2_id, workspace_item_id=item2_id, chunk_index=0, content="chunk 2 text", rank=2, raw_score=0.5, search_type="lexical"),
    ]
    semantic = [
        CandidateChunk(chunk_id=chunk1_id, workspace_item_id=item1_id, chunk_index=0, content="chunk 1 text", rank=1, raw_score=0.95, search_type="semantic"),
        CandidateChunk(chunk_id=chunk3_id, workspace_item_id=item1_id, chunk_index=1, content="chunk 3 text", rank=3, raw_score=0.4, search_type="semantic"),
    ]

    mock_db = AsyncMock(spec=AsyncSession)
    mock_item1 = WorkspaceItem(id=item1_id, service="gmail", item_type="email", external_id="ext1", title="Title 1", content="chunk 1 text", metadata_={})
    mock_item2 = WorkspaceItem(id=item2_id, service="calendar", item_type="calendar_event", external_id="ext2", title="Title 2", content="chunk 2 text", metadata_={})

    mock_res = MagicMock()
    mock_res.scalars.return_value.all.return_value = [mock_item1, mock_item2]
    mock_db.execute = AsyncMock(return_value=mock_res)

    results = await perform_rrf_fusion(mock_db, lexical_candidates=lexical, semantic_candidates=semantic, limit=5)

    assert len(results) == 2
    # Item 1 appeared in rank 1 in both lists, so RRF score = 1/(60+1) + 1/(60+1) = 2/61 ≈ 0.032787
    # Plus boost for second chunk
    assert results[0].item_id == item1_id
    assert results[0].lexical_rank == 1
    assert results[0].semantic_rank == 1
    assert results[0].score > 0.03


@pytest.mark.asyncio
async def test_multi_tenant_user_isolation() -> None:
    """MANDATORY SECURITY TEST: Verify user A search NEVER returns user B's workspace items."""
    user_a = uuid.uuid4()
    user_b = uuid.uuid4()

    mock_db = AsyncMock(spec=AsyncSession)

    with (
        patch("app.retrieval.search.search_lexical_candidates", new_callable=AsyncMock) as mock_fts,
        patch("app.retrieval.search.search_vector_candidates", new_callable=AsyncMock) as mock_vec,
        patch("app.retrieval.search.perform_rrf_fusion", new_callable=AsyncMock) as mock_fusion,
    ):
        mock_fts.return_value = []
        mock_vec.return_value = []
        mock_fusion.return_value = []

        # Execute search for User A
        await search_workspace(mock_db, user_id=user_a, query="confidential proposal")

        # Verify both FTS and Vector functions were explicitly called with user_id=user_a
        assert mock_fts.call_args[1]["user_id"] == user_a
        assert mock_vec.call_args[1]["user_id"] == user_a
        assert mock_fts.call_args[1]["user_id"] != user_b
        assert mock_vec.call_args[1]["user_id"] != user_b


@pytest.mark.asyncio
async def test_search_filters_structure() -> None:
    """Verify SearchFilters object constructs correctly with all supported metadata constraints."""
    dt_start = datetime(2026, 7, 1, tzinfo=timezone.utc)
    dt_end = datetime(2026, 7, 31, tzinfo=timezone.utc)

    filters = SearchFilters(
        services=["gmail", "drive"],
        item_types=["email"],
        date_from=dt_start,
        date_to=dt_end,
        sender="sarah@company.com",
        recipient="john@company.com",
        attendee="boss@company.com",
        mime_type="application/pdf",
    )

    assert filters.services == ["gmail", "drive"]
    assert filters.sender == "sarah@company.com"
    assert filters.mime_type == "application/pdf"
    assert filters.date_from == dt_start
