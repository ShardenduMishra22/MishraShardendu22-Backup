"use client";

import React from "react";
import {
  CheckCircle2,
  Clock,
  AlertTriangle,
  Mail,
  Calendar,
  FileText,
  Layers,
  ExternalLink,
  Check,
  X,
  Loader2,
} from "lucide-react";

/* ================================================================ */
/*  TYPE DEFINITIONS                                                  */
/* ================================================================ */

interface ClarificationProgress {
  resolved: number;
  total: number;
}

interface MissingField {
  parameter: string;
  question: string;
}

interface ActionTaken {
  step_id: string;
  status: string;
  tool?: string;
  output?: any;
  started_at?: string | null;
  completed_at?: string | null;
  input?: any;
  error?: string | null;
}

/* ================================================================ */
/*  CLARIFICATION CARD COMPONENT                                      */
/* ================================================================ */

interface ClarificationCardProps {
  question: string;
  missingFields?: string[];
  candidates?: string[];
  progress?: ClarificationProgress;
}

export function ClarificationCard({ question, missingFields, candidates, progress }: ClarificationCardProps) {
  return (
    <div className="p-4 rounded-lg bg-zinc-900 border border-zinc-700 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
        <div className="flex items-center gap-2 text-sm font-mono font-semibold text-white">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          <span>Missing Information</span>
        </div>
        {progress && (
          <span className="text-xs font-mono px-2 py-0.5 rounded bg-zinc-800 text-zinc-300">
            {progress.resolved} / {progress.total} complete
          </span>
        )}
      </div>

      {/* Progress bar */}
      {progress && progress.total > 0 && (
        <div className="w-full bg-zinc-800 rounded-full h-1.5">
          <div
            className="bg-white h-1.5 rounded-full transition-all duration-300"
            style={{ width: `${(progress.resolved / progress.total) * 100}%` }}
          />
        </div>
      )}

      {/* Missing fields checklist */}
      {missingFields && missingFields.length > 0 && (
        <div className="space-y-1.5">
          {missingFields.map((field) => (
            <div key={field} className="flex items-center gap-2 text-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-500" />
              <span className="text-zinc-300 font-mono">{field}</span>
              <span className="text-zinc-500 text-[10px]">awaiting input</span>
            </div>
          ))}
        </div>
      )}

      {/* Clarification question */}
      <div className="p-3 rounded bg-black border border-zinc-800">
        <p className="text-xs text-zinc-200 leading-relaxed">{question}</p>
      </div>

      {/* Candidates (for ambiguous resolution) */}
      {candidates && candidates.length > 0 && (
        <div className="space-y-1.5">
          <span className="text-[10px] text-zinc-500 font-mono uppercase">Available Options:</span>
          {candidates.map((candidate, idx) => (
            <div key={idx} className="p-2 rounded bg-black border border-zinc-800 text-xs text-zinc-300 font-mono">
              {candidate}
            </div>
          ))}
        </div>
      )}

      {/* Footer instruction */}
      <div className="flex items-center gap-2 pt-2 border-t border-zinc-800 text-[10px] text-zinc-500">
        <Clock className="w-3 h-3" />
        <span>Waiting for your response to continue...</span>
      </div>
    </div>
  );
}

/* ================================================================ */
/*  EXECUTION PROGRESS CARD COMPONENT                                 */
/* ================================================================ */

interface ExecutionProgressCardProps {
  steps: ActionTaken[];
  status: string;
}

export function ExecutionProgressCard({ steps, status }: ExecutionProgressCardProps) {
  const getStepIcon = (tool?: string) => {
    if (!tool) return Layers;
    if (tool.includes("gmail")) return Mail;
    if (tool.includes("calendar")) return Calendar;
    if (tool.includes("drive")) return FileText;
    return Layers;
  };

  const getStatusIcon = (stepStatus: string) => {
    switch (stepStatus) {
      case "completed":
        return <CheckCircle2 className="w-4 h-4 text-white" />;
      case "running":
        return <Loader2 className="w-4 h-4 text-white animate-spin" />;
      case "failed":
      case "blocked":
        return <X className="w-4 h-4 text-red-400" />;
      default:
        return <div className="w-4 h-4 rounded-full border-2 border-zinc-600" />;
    }
  };

  const calculateDuration = (started?: string | null, completed?: string | null) => {
    if (!started || !completed) return null;
    const start = new Date(started).getTime();
    const end = new Date(completed).getTime();
    const durationMs = end - start;
    if (durationMs < 1000) return `${durationMs}ms`;
    return `${(durationMs / 1000).toFixed(2)}s`;
  };

  return (
    <div className="p-4 rounded-lg bg-zinc-900 border border-zinc-700 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
        <div className="flex items-center gap-2 text-sm font-mono font-semibold text-white">
          <Layers className="w-4 h-4" />
          <span>Execution Progress</span>
        </div>
        <span className="text-xs font-mono px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 capitalize">
          {status}
        </span>
      </div>

      {/* Timeline */}
      <div className="space-y-3">
        {steps.map((step, idx) => {
          const StepIcon = getStepIcon(step.tool);
          const duration = calculateDuration(step.started_at, step.completed_at);
          const isLastStep = idx === steps.length - 1;

          return (
            <div key={step.step_id} className="flex gap-3">
              {/* Timeline connector */}
              <div className="flex flex-col items-center">
                {getStatusIcon(step.status)}
                {!isLastStep && <div className="w-0.5 flex-1 bg-zinc-800 my-1" />}
              </div>

              {/* Step content */}
              <div className="flex-1 pb-2">
                <div className="flex items-center gap-2 mb-1">
                  <StepIcon className="w-3.5 h-3.5 text-zinc-400" />
                  <span className="text-xs font-mono font-semibold text-white">{step.step_id}</span>
                  {step.tool && (
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-zinc-400">
                      {step.tool}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-[10px] text-zinc-500">
                  <span className="capitalize">{step.status}</span>
                  {duration && (
                    <>
                      <span>•</span>
                      <span>{duration}</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ================================================================ */
/*  COMPLETION SUMMARY CARD COMPONENT                                 */
/* ================================================================ */

interface CompletionSummaryCardProps {
  summary: string;
  actions: ActionTaken[];
  status: "completed" | "failed" | "error";
}

export function CompletionSummaryCard({ summary, actions, status }: CompletionSummaryCardProps) {
  const extractLinks = (output: any): Array<{ label: string; url: string }> => {
    if (!output) return [];
    const links: Array<{ label: string; url: string }> = [];

    if (output.web_view_link) {
      links.push({ label: "Drive Link", url: output.web_view_link });
    }
    if (output.html_link) {
      links.push({ label: "Calendar Event", url: output.html_link });
    }
    if (output.message_id) {
      links.push({ label: `Gmail ${output.message_id}`, url: `https://mail.google.com/mail/u/0/#all/${output.message_id}` });
    }

    return links;
  };

  const successfulActions = actions.filter((a) => a.status === "completed");
  const failedActions = actions.filter((a) => ["failed", "blocked"].includes(a.status));

  return (
    <div className="p-4 rounded-lg bg-zinc-900 border border-zinc-700 space-y-3">
      {/* Header */}
      <div className="flex items-center gap-2 text-sm font-mono font-semibold text-white border-b border-zinc-800 pb-2">
        {status === "completed" ? (
          <>
            <CheckCircle2 className="w-4 h-4 text-white" />
            <span>Workflow Completed</span>
          </>
        ) : (
          <>
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span>Workflow {status === "failed" ? "Failed" : "Error"}</span>
          </>
        )}
      </div>

      {/* Summary text */}
      <p className="text-xs text-zinc-200 leading-relaxed">{summary}</p>

      {/* Success summary */}
      {successfulActions.length > 0 && (
        <div className="space-y-2">
          <span className="text-[10px] text-zinc-500 font-mono uppercase">Actions Completed:</span>
          {successfulActions.map((action) => {
            const links = extractLinks(action.output);
            return (
              <div key={action.step_id} className="p-3 rounded bg-black border border-zinc-800 space-y-2">
                <div className="flex items-center gap-2">
                  <Check className="w-3 h-3 text-white" />
                  <span className="text-xs font-mono font-semibold text-white">{action.step_id}</span>
                  {action.tool && (
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
                      {action.tool}
                    </span>
                  )}
                </div>
                {links.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pl-5">
                    {links.map((link, idx) => (
                      <a
                        key={idx}
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-1 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:border-zinc-600 transition-colors"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>{link.label}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Failure summary */}
      {failedActions.length > 0 && (
        <div className="space-y-2">
          <span className="text-[10px] text-red-400 font-mono uppercase">Actions Failed:</span>
          {failedActions.map((action) => (
            <div key={action.step_id} className="p-3 rounded bg-red-950/20 border border-red-900/50 space-y-1">
              <div className="flex items-center gap-2">
                <X className="w-3 h-3 text-red-400" />
                <span className="text-xs font-mono font-semibold text-red-300">{action.step_id}</span>
              </div>
              {(action.error || action.output?.error) && (
                <p className="text-[10px] text-red-300 pl-5">{action.error || action.output.error}</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
