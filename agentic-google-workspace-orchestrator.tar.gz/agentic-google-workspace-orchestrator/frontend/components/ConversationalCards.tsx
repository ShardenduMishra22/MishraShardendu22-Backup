"use client";

import React from "react";
import {
  CheckCircle2,
  Clock,
  AlertTriangle,
  Mail,
  Calendar,
  FileText,
  Layers,
  ExternalLink,
  Check,
  X,
  Loader2,
} from "lucide-react";

/* ================================================================ */
/*  TYPE DEFINITIONS                                                  */
/* ================================================================ */

interface ClarificationProgress {
  resolved: number;
  total: number;
}

interface MissingField {
  parameter: string;
  question: string;
}

interface ActionTaken {
  step_id: string;
  status: string;
  tool?: string;
  output?: any;
  started_at?: string | null;
  completed_at?: string | null;
  input?: any;
  error?: string | null;
}

/* ================================================================ */
/*  CLARIFICATION CARD COMPONENT                                      */
/* ================================================================ */

interface ClarificationCardProps {
  question: string;
  missingFields?: string[];
  candidates?: string[];
  progress?: ClarificationProgress;
}

export function ClarificationCard({ question, missingFields, candidates, progress }: ClarificationCardProps) {
  return (
    <div className="p-4 rounded-lg bg-[#1b1b1a] border border-[#343431] space-y-3 shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#2a2a28] pb-2">
        <div className="flex items-center gap-2 text-sm font-mono font-semibold text-[#faf9f5]">
          <AlertTriangle className="w-4 h-4 text-[#d8a84a]" />
          <span>Missing Information</span>
        </div>
        {progress && (
          <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#232321] border border-[#343431] text-[#b1ada1]">
            {progress.resolved} / {progress.total} complete
          </span>
        )}
      </div>

      {/* Progress bar */}
      {progress && progress.total > 0 && (
        <div className="w-full bg-[#232321] rounded-full h-1.5 overflow-hidden">
          <div
            className="bg-[#d97757] h-1.5 rounded-full transition-all duration-300"
            style={{ width: `${(progress.resolved / progress.total) * 100}%` }}
          />
        </div>
      )}

      {/* Missing fields checklist */}
      {missingFields && missingFields.length > 0 && (
        <div className="space-y-1.5">
          {missingFields.map((field) => (
            <div key={field} className="flex items-center gap-2 text-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-[#d97757]" />
              <span className="text-[#faf9f5] font-mono">{field}</span>
              <span className="text-[#847f72] text-[10px]">awaiting input</span>
            </div>
          ))}
        </div>
      )}

      {/* Clarification question */}
      <div className="p-3 rounded bg-[#141413] border border-[#2a2a28]">
        <p className="text-xs text-[#faf9f5] leading-relaxed">{question}</p>
      </div>

      {/* Candidates (for ambiguous resolution) */}
      {candidates && candidates.length > 0 && (
        <div className="space-y-1.5">
          <span className="text-[10px] text-[#847f72] font-mono uppercase tracking-wider">Available Options:</span>
          {candidates.map((candidate, idx) => (
            <div key={idx} className="p-2 rounded bg-[#141413] border border-[#2a2a28] text-xs text-[#b1ada1] font-mono">
              {candidate}
            </div>
          ))}
        </div>
      )}

      {/* Footer instruction */}
      <div className="flex items-center gap-2 pt-2 border-t border-[#2a2a28] text-[10px] text-[#847f72]">
        <Clock className="w-3 h-3 text-[#d97757]" />
        <span>Waiting for your response to continue...</span>
      </div>
    </div>
  );
}

/* ================================================================ */
/*  EXECUTION PROGRESS CARD COMPONENT                                 */
/* ================================================================ */

interface ExecutionProgressCardProps {
  steps: ActionTaken[];
  status: string;
}

export function ExecutionProgressCard({ steps, status }: ExecutionProgressCardProps) {
  const getStepIcon = (tool?: string) => {
    if (!tool) return Layers;
    if (tool.includes("gmail")) return Mail;
    if (tool.includes("calendar")) return Calendar;
    if (tool.includes("drive")) return FileText;
    return Layers;
  };

  const getStatusIcon = (stepStatus: string) => {
    switch (stepStatus) {
      case "completed":
        return <CheckCircle2 className="w-4 h-4 text-[#788c5d]" />;
      case "running":
        return <Loader2 className="w-4 h-4 text-[#d97757] animate-spin" />;
      case "failed":
      case "blocked":
        return <X className="w-4 h-4 text-[#cf5656]" />;
      default:
        return <div className="w-4 h-4 rounded-full border-2 border-[#494844]" />;
    }
  };

  const calculateDuration = (started?: string | null, completed?: string | null) => {
    if (!started || !completed) return null;
    const start = new Date(started).getTime();
    const end = new Date(completed).getTime();
    const durationMs = end - start;
    if (durationMs < 1000) return `${durationMs}ms`;
    return `${(durationMs / 1000).toFixed(2)}s`;
  };

  return (
    <div className="p-4 rounded-lg bg-[#1b1b1a] border border-[#343431] space-y-3 shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#2a2a28] pb-2">
        <div className="flex items-center gap-2 text-sm font-mono font-semibold text-[#faf9f5]">
          <Layers className="w-4 h-4 text-[#d97757]" />
          <span>Execution Progress</span>
        </div>
        <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#232321] border border-[#343431] text-[#b1ada1] capitalize">
          {status}
        </span>
      </div>

      {/* Timeline */}
      <div className="space-y-3">
        {steps.map((step, idx) => {
          const StepIcon = getStepIcon(step.tool);
          const duration = calculateDuration(step.started_at, step.completed_at);
          const isLastStep = idx === steps.length - 1;

          return (
            <div key={step.step_id} className="flex gap-3">
              {/* Timeline connector */}
              <div className="flex flex-col items-center">
                {getStatusIcon(step.status)}
                {!isLastStep && <div className="w-0.5 flex-1 bg-[#2a2a28] my-1" />}
              </div>

              {/* Step content */}
              <div className="flex-1 pb-2">
                <div className="flex items-center gap-2 mb-1">
                  <StepIcon className="w-3.5 h-3.5 text-[#b1ada1]" />
                  <span className="text-xs font-mono font-semibold text-[#faf9f5]">{step.step_id}</span>
                  {step.tool && (
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#232321] border border-[#343431] text-[#b1ada1]">
                      {step.tool}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-[10px] text-[#847f72]">
                  <span className="capitalize">{step.status}</span>
                  {duration && (
                    <>
                      <span>•</span>
                      <span>{duration}</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ================================================================ */
/*  COMPLETION SUMMARY CARD COMPONENT                                 */
/* ================================================================ */

interface CompletionSummaryCardProps {
  summary: string;
  actions: ActionTaken[];
  status: "completed" | "failed" | "error";
}

export function CompletionSummaryCard({ summary, actions, status }: CompletionSummaryCardProps) {
  const extractLinks = (output: any): Array<{ label: string; url: string }> => {
    if (!output) return [];
    const links: Array<{ label: string; url: string }> = [];

    if (output.web_view_link) {
      links.push({ label: "Drive Link", url: output.web_view_link });
    }
    if (output.html_link) {
      links.push({ label: "Calendar Event", url: output.html_link });
    }
    if (output.message_id) {
      links.push({ label: `Gmail ${output.message_id}`, url: `https://mail.google.com/mail/u/0/#all/${output.message_id}` });
    }

    return links;
  };

  const successfulActions = actions.filter((a) => a.status === "completed");
  const failedActions = actions.filter((a) => ["failed", "blocked"].includes(a.status));

  return (
    <div className="p-4 rounded-lg bg-[#1b1b1a] border border-[#343431] space-y-3 shadow-sm">
      {/* Header */}
      <div className="flex items-center gap-2 text-sm font-mono font-semibold text-[#faf9f5] border-b border-[#2a2a28] pb-2">
        {status === "completed" ? (
          <>
            <CheckCircle2 className="w-4 h-4 text-[#788c5d]" />
            <span>Workflow Completed</span>
          </>
        ) : (
          <>
            <AlertTriangle className="w-4 h-4 text-[#cf5656]" />
            <span>Workflow {status === "failed" ? "Failed" : "Error"}</span>
          </>
        )}
      </div>

      {/* Summary text */}
      <p className="text-xs text-[#faf9f5] leading-relaxed">{summary}</p>

      {/* Success summary */}
      {successfulActions.length > 0 && (
        <div className="space-y-2">
          <span className="text-[10px] text-[#847f72] font-mono uppercase tracking-wider">Actions Completed:</span>
          {successfulActions.map((action) => {
            const links = extractLinks(action.output);
            return (
              <div key={action.step_id} className="p-3 rounded bg-[#141413] border border-[#2a2a28] space-y-2">
                <div className="flex items-center gap-2">
                  <Check className="w-3 h-3 text-[#788c5d]" />
                  <span className="text-xs font-mono font-semibold text-[#faf9f5]">{action.step_id}</span>
                  {action.tool && (
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#232321] border border-[#343431] text-[#b1ada1]">
                      {action.tool}
                    </span>
                  )}
                </div>
                {links.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pl-5">
                    {links.map((link, idx) => (
                      <a
                        key={idx}
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-1 rounded bg-[#232321] border border-[#343431] text-[#faf9f5] hover:text-[#d97757] hover:border-[#d97757]/50 transition-colors"
                      >
                        <ExternalLink className="w-3 h-3 text-[#d97757]" />
                        <span>{link.label}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Failure summary */}
      {failedActions.length > 0 && (
        <div className="space-y-2">
          <span className="text-[10px] text-[#cf5656] font-mono uppercase tracking-wider">Actions Failed:</span>
          {failedActions.map((action) => (
            <div key={action.step_id} className="p-3 rounded bg-[#cf5656]/10 border border-[#cf5656]/30 space-y-1">
              <div className="flex items-center gap-2">
                <X className="w-3 h-3 text-[#cf5656]" />
                <span className="text-xs font-mono font-semibold text-[#cf5656]">{action.step_id}</span>
              </div>
              {(action.error || action.output?.error) && (
                <p className="text-[10px] text-[#cf5656] pl-5">{action.error || action.output.error}</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
