"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Send,
  ShieldCheck,
  Mail,
  Calendar,
  FileText,
  ChevronDown,
  ChevronUp,
  Plus,
  MessageSquare,
  Hash,
  Clock,
  Terminal,
  Layers,
  Wrench,
  Check,
  X,
  ExternalLink,
  Trash2,
  Sparkles,
  LogOut,
} from "lucide-react";
import { ClarificationCard, ExecutionProgressCard, CompletionSummaryCard } from "@/components/ConversationalCards";

const API =
  process.env.NEXT_PUBLIC_API_BASE_URL ||
  (typeof window !== "undefined" &&
  window.location.hostname !== "localhost" &&
  window.location.hostname !== "127.0.0.1"
    ? "https://agentic-google-workspace-backend.vercel.app"
    : "http://localhost:8000");

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface ActionTaken {
  step_id: string;
  status: string;
  tool?: string;
  output?: any;
  input?: any;
  error?: string | null;
  started_at?: string | null;
  completed_at?: string | null;
}

interface PendingActionItem {
  pending_action_id: string;
  action_type: string;
  step_id?: string;
  tool_name?: string;
  payload: any;
}

interface ChatMessage {
  id: string;
  sender: "user" | "assistant";
  text: string;
  timestamp: string;
  status?: "completed" | "needs_clarification" | "needs_confirmation" | "completed_with_errors" | "cancelled" | "error";
  clarification_question?: string;
  clarification?: {
    question: string;
    missing_fields?: string[];
    candidates?: string[];
    progress?: {
      resolved: number;
      total: number;
    };
  };
  pending_actions?: PendingActionItem[];
  actions_taken?: ActionTaken[];
  orchestration_id?: string;
}

interface ConversationPreview {
  id: string;
  title: string;
  message_count: number;
  created_at: string | null;
  updated_at: string | null;
}

interface SyncServiceInfo {
  items_synced?: number;
  last_synced_at?: string;
}

/* ------------------------------------------------------------------ */
/*  Markdown Formatting Helpers                                        */
/* ------------------------------------------------------------------ */

function renderInlineMarkdown(text: string) {
  const regex = /(\[.*?\]\(.*?\)|\*\*.*?\*\*|__.*?__|`.*?`)/g;
  const parts = text.split(regex);

  return parts.map((part, idx) => {
    if (!part) return null;

    // Link: [label](url)
    const linkMatch = part.match(/^\[(.*?)\]\((.*?)\)$/);
    if (linkMatch) {
      const [, label, url] = linkMatch;
      return (
        <a
          key={idx}
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 font-medium text-white hover:text-zinc-300 underline underline-offset-2 transition-colors font-mono text-[11px] bg-zinc-900 px-1.5 py-0.5 rounded border border-zinc-800 my-0.5"
        >
          <span>{label}</span>
          <ExternalLink className="w-3 h-3 text-zinc-400 flex-shrink-0" />
        </a>
      );
    }

    // Bold: **text** or __text__
    const boldMatch = part.match(/^(\*\*|__)(.*?)\1$/);
    if (boldMatch) {
      return (
        <strong key={idx} className="font-semibold text-white">
          {boldMatch[2]}
        </strong>
      );
    }

    // Code: `code`
    const codeMatch = part.match(/^`(.*?)`$/);
    if (codeMatch) {
      return (
        <code key={idx} className="font-mono text-[11px] bg-zinc-900 px-1.5 py-0.5 rounded text-zinc-200 border border-zinc-800">
          {codeMatch[1]}
        </code>
      );
    }

    return <span key={idx}>{part}</span>;
  });
}

function FormattedMarkdownMessage({ content }: { content: string }) {
  if (!content) return null;

  const lines = content.split("\n");

  return (
    <div className="space-y-1.5 leading-relaxed text-xs">
      {lines.map((line, lineIdx) => {
        const trimmed = line.trim();
        if (!trimmed) {
          return <div key={lineIdx} className="h-1.5" />;
        }

        // Bullet level detection
        const indentMatch = line.match(/^(\s*)/);
        const indentSpaces = indentMatch ? indentMatch[1].length : 0;
        const isSubBullet = indentSpaces >= 2;

        // Check if line starts with bullet (* or -)
        if (trimmed.startsWith("* ") || trimmed.startsWith("- ")) {
          const bulletContent = trimmed.slice(2);
          return (
            <div
              key={lineIdx}
              className={`flex items-start gap-2 ${
                isSubBullet ? "pl-5 text-zinc-300" : "pl-1 text-zinc-100 font-medium"
              }`}
            >
              <span className={`select-none mt-1.5 flex-shrink-0 ${isSubBullet ? "w-1 h-1 rounded-full bg-zinc-500" : "w-1.5 h-1.5 rounded-full bg-white"}`} />
              <div className="flex-1 min-w-0">{renderInlineMarkdown(bulletContent)}</div>
            </div>
          );
        }

        // Numbered list (1. item)
        const numMatch = trimmed.match(/^(\d+)\.\s+(.*)$/);
        if (numMatch) {
          const [, num, itemContent] = numMatch;
          return (
            <div key={lineIdx} className="flex items-start gap-2 pl-1 text-zinc-100">
              <span className="font-mono text-zinc-400 text-[11px] min-w-[16px] flex-shrink-0">{num}.</span>
              <div className="flex-1 min-w-0">{renderInlineMarkdown(itemContent)}</div>
            </div>
          );
        }

        // Heading (# Heading)
        if (trimmed.startsWith("#")) {
          const headingText = trimmed.replace(/^#+\s*/, "");
          return (
            <h4 key={lineIdx} className="font-semibold text-sm text-white pt-1 pb-0.5">
              {renderInlineMarkdown(headingText)}
            </h4>
          );
        }

        // Regular paragraph line
        return (
          <p key={lineIdx} className="text-zinc-200">
            {renderInlineMarkdown(line)}
          </p>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Page Component                                                     */
/* ------------------------------------------------------------------ */

export default function Home() {
  // Conversation state
  const [conversations, setConversations] = useState<ConversationPreview[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputQuery, setInputQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Auth & sync
  const [authStatus, setAuthStatus] = useState<{
    connected: boolean;
    email: string | null;
    user_id: string | null;
  }>({ connected: false, email: null, user_id: null });
  const [syncStatus, setSyncStatus] = useState<Record<string, SyncServiceInfo> | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [showSteps, setShowSteps] = useState<Record<string, boolean>>({});
  const [showToolDetails, setShowToolDetails] = useState<Record<string, boolean>>({});
  const [confirmingActionIds, setConfirmingActionIds] = useState<Record<string, boolean>>({});
  const [llmProvider, setLlmProvider] = useState<"gemini" | "groq">("gemini");

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  /* ---- Auto-scroll to bottom ---- */
  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading, scrollToBottom]);

  /* ---- Auth & API Helper ---- */
  const getStoredUserId = (): string => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("gws_user_id") || "";
    }
    return "";
  };

  const apiFetch = useCallback(async (path: string, init?: RequestInit): Promise<Response> => {
    const uid = getStoredUserId();
    const headers = new Headers(init?.headers || {});
    if (uid && !headers.has("X-User-ID")) {
      headers.set("X-User-ID", uid);
    }
    const url = path.startsWith("http") ? path : `${API}${path}`;
    return fetch(url, {
      ...init,
      headers,
      credentials: "include",
    });
  }, []);

  /* ---- Initial load ---- */
  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const urlUid = params.get("user_id");
      if (urlUid) {
        localStorage.setItem("gws_user_id", urlUid);
        window.history.replaceState({}, document.title, window.location.pathname);
      }
    }
    fetchAuthStatus();
    fetchSyncStatus();
    fetchConversations();
  }, []);

  /* ---- Data fetchers ---- */

  const fetchAuthStatus = async () => {
    try {
      const res = await apiFetch("/api/v1/auth/google/status");
      if (res.ok) {
        const data = await res.json();
        setAuthStatus(data);
        if (data.connected && data.user_id) {
          localStorage.setItem("gws_user_id", data.user_id);
        } else if (!data.connected) {
          localStorage.removeItem("gws_user_id");
          setConversations([]);
          setMessages([]);
        }
      }
    } catch (e) {
      if (authStatus.connected) {
        console.error("Auth status error:", e);
      }
    }
  };

  const fetchSyncStatus = async () => {
    try {
      const res = await apiFetch("/api/v1/sync/status");
      if (res.ok) {
        const data = await res.json();
        setSyncStatus(data.sync_states || data.services || null);
      }
    } catch (e) {
      // Silently fail on initial load when backend might not be ready
    }
  };

  const fetchConversations = async () => {
    try {
      const res = await apiFetch("/api/v1/conversations");
      if (res.ok) {
        const data: ConversationPreview[] = await res.json();
        setConversations(data);
      }
    } catch (e) {
      // Silently fail on initial load when backend might not be ready
    }
  };

  const loadConversation = async (convId: string) => {
    setActiveConversationId(convId);
    setMessages([]);
    try {
      const res = await apiFetch(`/api/v1/conversations/${convId}/messages`);
      if (res.ok) {
        const data = await res.json();
        const mapped: ChatMessage[] = data.map((m: any) => {
          const context = m.structured_context || {};
          const missing = context.missing_parameters || [];
          const resolved = Object.keys(context.partial_state || {}).filter(
            (key) => !key.startsWith("_") && context.partial_state[key] != null && context.partial_state[key] !== "",
          );
          return {
            id: m.id,
            sender: m.role === "user" ? "user" : "assistant",
            text: m.content,
            timestamp: m.created_at || new Date().toISOString(),
            status: context.status,
            clarification: context.status === "needs_clarification" ? {
              question: m.content,
              missing_fields: missing.map((field: any) => typeof field === "string" ? field : field.parameter),
              candidates: context.matches || [],
              progress: {
                resolved: resolved.length,
                total: resolved.length + missing.length,
              },
            } : undefined,
            pending_actions: context.pending_actions,
            actions_taken: context.actions_taken,
            orchestration_id: context.orchestration_id,
          };
        });
        setMessages(mapped);
      }
    } catch (e) {
      console.error("Load conversation error:", e);
    }
  };

  const toMessageStatus = (workflowStatus: string): ChatMessage["status"] => {
    if (workflowStatus === "failed") return "error";
    if (workflowStatus === "cancelled") return "cancelled";
    if (["needs_clarification", "needs_confirmation", "completed"].includes(workflowStatus)) {
      return workflowStatus as ChatMessage["status"];
    }
    return undefined;
  };

  const refreshWorkflow = useCallback(async (runId: string) => {
    try {
      const [runRes, stepsRes] = await Promise.all([
        apiFetch(`/api/v1/orchestration/runs/${runId}`),
        apiFetch(`/api/v1/orchestration/runs/${runId}/steps`),
      ]);
      if (!runRes.ok) return;
      const run = await runRes.json();
      const steps = stepsRes.ok ? await stepsRes.json() : [];
      const actions: ActionTaken[] = steps.map((step: any) => ({
        step_id: step.step_key,
        status: step.status,
        tool: step.tool_name,
        input: step.input,
        output: step.output,
        error: step.error,
        started_at: step.started_at,
        completed_at: step.completed_at,
      }));

      setMessages((current) => current.map((message) => {
        if (message.orchestration_id !== runId) return message;
        const status = toMessageStatus(run.status);
        return {
          ...message,
          status: status || message.status,
          actions_taken: actions.length ? actions : message.actions_taken,
          pending_actions: run.status === "needs_confirmation" ? message.pending_actions : undefined,
        };
      }));
    } catch (error) {
      console.error("Workflow refresh error:", error);
    }
  }, [apiFetch]);

  /* Keep visible workflow cards synchronized while the backend changes state. */
  useEffect(() => {
    const activeRuns = messages
      .filter((message) => message.orchestration_id && ["needs_confirmation"].includes(message.status || ""))
      .map((message) => message.orchestration_id as string);
    if (!activeRuns.length) return;

    void Promise.all(activeRuns.map(refreshWorkflow));
    const interval = window.setInterval(() => void Promise.all(activeRuns.map(refreshWorkflow)), 1500);
    return () => window.clearInterval(interval);
  }, [messages, refreshWorkflow]);

  /* ---- Actions ---- */

  const handleConnectGoogle = () => {
    window.location.href = `${API}/api/v1/auth/google`;
  };

  const handleTriggerSync = async () => {
    setSyncing(true);
    try {
      const res = await apiFetch("/api/v1/sync/trigger", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ services: ["gmail", "calendar", "drive"] }),
      });
      if (res.ok) await fetchSyncStatus();
    } catch (e) {
      console.error("Sync trigger error:", e);
    } finally {
      setSyncing(false);
    }
  };

  const handleNewChat = () => {
    setActiveConversationId(null);
    setMessages([]);
    setShowSteps({});
    inputRef.current?.focus();
  };

  const handleDeleteConversation = async (convId: string) => {
    try {
      const res = await apiFetch(`/api/v1/conversations/${convId}`, {
        method: "DELETE",
      });
      if (res.ok) {
        setConversations((prev) => prev.filter((c) => c.id !== convId));
        if (activeConversationId === convId) {
          handleNewChat();
        }
      } else {
        console.error("Failed to delete conversation:", res.status, res.statusText);
      }
    } catch (e) {
      // Network error - only log if we expect the API to be available
      console.error("Delete conversation error:", e);
    }
  };

  const handleSendQuery = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || loading) return;

    const now = new Date().toISOString();
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: textToSend,
      timestamp: now,
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!queryText) setInputQuery("");
    setLoading(true);

    try {
      const res = await apiFetch("/api/v1/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: textToSend,
          conversation_id: activeConversationId,
          user_timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
          llm_provider: llmProvider,
        }),
      });

      if (!res.ok) {
        if (res.status === 429) {
          const errData = await res.json();
          setMessages((prev) => [
            ...prev,
            {
              id: `error-${Date.now()}`,
              sender: "assistant",
              text: errData.detail || "Rate limit exceeded (100 queries/hour). Please try again later.",
              status: "error",
              timestamp: new Date().toISOString(),
            },
          ]);
          return;
        }
        throw new Error(`Server returned ${res.status}`);
      }

      const data = await res.json();

      if (data.conversation_id && !activeConversationId) {
        setActiveConversationId(data.conversation_id);
      }

      const assistantMsg: ChatMessage = {
        id: data.message_id || (data.orchestration_id ? `${data.orchestration_id}-${Date.now()}` : `assist-${Date.now()}`),
        sender: "assistant",
        text:
          data.response ||
          (data.status === "needs_clarification"
            ? data.clarification?.question || "Clarification needed:"
            : "Pending confirmation required:"),
        timestamp: new Date().toISOString(),
        status: data.status,
        clarification: data.clarification,
        pending_actions: data.pending_actions,
        actions_taken: data.actions_taken,
        orchestration_id: data.orchestration_id,
      };

      setMessages((prev) => [...prev, assistantMsg]);
      fetchConversations();
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `error-${Date.now()}`,
          sender: "assistant",
          text: `Request failed: ${e.message || "Unable to reach backend service."}`,
          status: "error",
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleWorkflowApproval = async (msgId: string, runId: string, approve: boolean) => {
    if (confirmingActionIds[runId]) return;
    setConfirmingActionIds((prev) => ({ ...prev, [runId]: true }));

    const endpoint = approve
      ? `/api/v1/actions/runs/${runId}/confirm-all`
      : `/api/v1/actions/runs/${runId}/reject-all`;

    try {
      const res = await apiFetch(endpoint, { method: "POST" });
      const data = await res.json();

      if (!res.ok || data.status === "failed") {
        const reason = data.error?.message || data.detail || data.message || `Execution failed (HTTP ${res.status})`;
        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === msgId
              ? { ...msg, text: `Workflow execution failed.\nReason: ${reason}`, status: "error" as const, pending_actions: undefined }
              : msg,
          ),
        );
        return;
      }

      // Poll for updated execution steps and workflow status after approval
      let updatedActions: ActionTaken[] = data.actions_taken || [];
      let workflowStatus = data.status;
      
      if (approve) {
        try {
          // Poll for up to 10 seconds to get final execution state
          const maxAttempts = 20;
          const pollInterval = 500; // 500ms
          
          for (let attempt = 0; attempt < maxAttempts; attempt++) {
            // Fetch workflow status
            const runRes = await apiFetch(`/api/v1/orchestration/runs/${runId}`);
            if (runRes.ok) {
              const runData = await runRes.json();
              workflowStatus = runData.status;
            }

            // Fetch execution steps
            const stepsRes = await apiFetch(`/api/v1/orchestration/runs/${runId}/steps`);
            if (stepsRes.ok) {
              const stepsData = await stepsRes.json();
              updatedActions = stepsData.map((step: any) => ({
                step_id: step.step_key,
                status: step.status,
                tool: step.tool_name,
                output: step.output,
                input: step.input,
                error: step.error,
                started_at: step.started_at,
                completed_at: step.completed_at,
              }));

              // Check if all steps are in terminal state
              const allCompleted = updatedActions.every((act) =>
                ["completed", "failed", "blocked", "skipped"].includes(act.status)
              );

              if (allCompleted && (workflowStatus === "completed" || workflowStatus === "failed")) {
                break;
              }
            }

            // Wait before next poll
            if (attempt < maxAttempts - 1) {
              await new Promise((resolve) => setTimeout(resolve, pollInterval));
            }
          }
        } catch (err) {
          console.error("Failed to poll execution state:", err);
        }
      }

      setMessages((prev) =>
        prev.map((msg) => {
          if (msg.id !== msgId) return msg;
          return {
            ...msg,
            text: data.message || (approve ? "All actions executed successfully." : "The workflow was cancelled. No changes were made."),
            status: (workflowStatus === "cancelled" ? "cancelled" : workflowStatus === "failed" ? "error" : "completed") as ChatMessage["status"],
            pending_actions: undefined,
            actions_taken: approve && updatedActions.length > 0 ? updatedActions : msg.actions_taken,
          };
        }),
      );
      await refreshWorkflow(runId);
      fetchConversations();
    } catch (e: any) {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === msgId
            ? { ...msg, text: `Workflow execution failed: ${e.message}`, status: "error" as const, pending_actions: undefined }
            : msg,
        ),
      );
    } finally {
      setConfirmingActionIds((prev) => {
        const copy = { ...prev };
        delete copy[runId];
        return copy;
      });
    }
  };

  const handleLogout = async () => {
    try {
      await apiFetch("/api/v1/auth/google/logout", { method: "POST" });
    } catch (e) {
      console.error("Logout error:", e);
    } finally {
      localStorage.removeItem("gws_user_id");
      setAuthStatus({ connected: false, email: null, user_id: null });
      setSyncStatus(null);
      setMessages([]);
      setConversations([]);
      setActiveConversationId(null);
    }
  };

  const toggleStepVisibility = (msgId: string) => {
    setShowSteps((prev) => ({ ...prev, [msgId]: !prev[msgId] }));
  };

  const toggleToolDetails = (stepKey: string) => {
    setShowToolDetails((prev) => ({ ...prev, [stepKey]: !prev[stepKey] }));
  };

  /* ---- Helpers ---- */

  const formatRelativeTime = (iso: string | null): string => {
    if (!iso) return "";
    const d = new Date(iso);
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 1) return "just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHrs = Math.floor(diffMins / 60);
    if (diffHrs < 24) return `${diffHrs}h ago`;
    const diffDays = Math.floor(diffHrs / 24);
    if (diffDays < 7) return `${diffDays}d ago`;
    return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  };

  const formatTimestamp = (iso: string): string => {
    const d = new Date(iso);
    return d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
  };

  const SERVICE_CONFIG = [
    { key: "gmail", label: "Gmail", icon: Mail },
    { key: "calendar", label: "Calendar", icon: Calendar },
    { key: "drive", label: "Drive", icon: FileText },
  ] as const;

  const SAMPLE_QUERIES = [
    "send a mail to Shardendu Mishra",
    "Summarize the last 3 emails in my inbox",
    "What's on my calendar for this week?",
    "Find documents in Drive about proposal",
    "Draft an email to sarah@example.com about project update",
    "What meetings do I have tomorrow?",
    "Find emails with subject budget",
    "Show me PDFs in my Google Drive",
    "Create a calendar meeting Team Sync tomorrow at 10 AM",
    "Prepare for tomorrow's meeting",
  ];

  /* ---------------------------------------------------------------- */
  /*  Render                                                           */
  /* ---------------------------------------------------------------- */

  return (
    <div className="h-screen flex overflow-hidden bg-[#141413] text-[#faf9f5] font-sans">
      {/* ============== SIDEBAR ============== */}
      <aside
        className="flex flex-col border-r border-[#343431] bg-[#171716] transition-all duration-200 flex-shrink-0"
        style={{
          width: sidebarOpen ? 280 : 0,
          minWidth: sidebarOpen ? 280 : 0,
          overflow: "hidden",
        }}
      >
        {/* Sidebar header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#2a2a28] flex-shrink-0">
          <span className="text-xs font-mono tracking-wider text-[#847f72] uppercase">
            Conversations
          </span>
          <button
            onClick={handleNewChat}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#d97757] text-white text-xs font-medium hover:bg-[#e28b6d] transition-colors shadow-sm"
            title="New conversation"
          >
            <Plus className="w-3.5 h-3.5" />
            New
          </button>
        </div>

        {/* Conversation list */}
        <div className="flex-1 overflow-y-auto py-1">
          {conversations.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <MessageSquare className="w-6 h-6 mx-auto mb-2 text-[#847f72]" />
              <p className="text-xs text-[#847f72]">
                No conversations yet.
                <br />
                Select a sample query to start.
              </p>
            </div>
          ) : (
            conversations.map((conv) => (
              <div key={conv.id} className="group relative flex items-center">
                <button
                  onClick={() => loadConversation(conv.id)}
                  className={`sidebar-item w-full text-left px-4 py-2.5 flex flex-col gap-0.5 border-l-2 transition-colors pr-9 ${
                    activeConversationId === conv.id
                      ? "bg-[#232321] border-[#d97757] text-[#faf9f5]"
                      : "border-transparent text-[#b1ada1] hover:bg-[#1b1b1a] hover:text-[#faf9f5]"
                  }`}
                >
                  <span className="text-xs font-medium truncate block">
                    {conv.title}
                  </span>
                  <span className="flex items-center gap-2 text-[10px] text-[#847f72]">
                    <span className="flex items-center gap-0.5">
                      <Hash className="w-3 h-3" />
                      {conv.message_count}
                    </span>
                    <span className="flex items-center gap-0.5">
                      <Clock className="w-3 h-3" />
                      {formatRelativeTime(conv.updated_at)}
                    </span>
                  </span>
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteConversation(conv.id);
                  }}
                  className="absolute right-2.5 p-1 rounded text-[#847f72] hover:text-[#cf5656] hover:bg-[#232321] transition-all opacity-0 group-hover:opacity-100"
                  title="Delete chat"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Sidebar footer — auth */}
        <div className="px-4 py-3 border-t border-[#2a2a28] flex-shrink-0 bg-[#171716]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 min-w-0">
              <span
                className={`w-2 h-2 rounded-full flex-shrink-0 ${
                  authStatus.connected ? "bg-[#788c5d]" : "bg-[#494844]"
                }`}
              />
              <span className="text-xs truncate text-[#b1ada1]">
                {authStatus.connected ? authStatus.email : "Not connected"}
              </span>
            </div>
            {authStatus.connected && (
              <button
                onClick={handleLogout}
                className="p-1 rounded text-[#847f72] hover:text-[#cf5656] hover:bg-[#232321] transition-colors"
                title="Sign out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          {!authStatus.connected && (
            <button
              onClick={handleConnectGoogle}
              className="mt-2.5 w-full py-1.5 rounded text-xs font-medium bg-[#1b1b1a] hover:bg-[#232321] border border-[#343431] text-[#faf9f5] transition-colors flex items-center justify-center gap-1.5"
            >
              Connect Google Account <ExternalLink className="w-3 h-3 text-[#d97757]" />
            </button>
          )}
        </div>
      </aside>

      {/* ============== MAIN PANEL ============== */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#141413]">
        {/* Top bar */}
        <header className="flex items-center justify-between px-4 py-3 border-b border-[#343431] bg-[#1b1b1a] flex-shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-1.5 rounded text-[#b1ada1] hover:text-[#faf9f5] hover:bg-[#232321] transition-colors"
              title={sidebarOpen ? "Collapse sidebar" : "Expand sidebar"}
            >
              {sidebarOpen ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>
              ) : (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
              )}
            </button>
            <div>
              <div className="m-kicker text-[10px] tracking-[0.16em]">Multi-Service DAG Orchestration</div>
              <h1 className="text-sm font-semibold tracking-tight text-[#faf9f5] flex items-center gap-2 font-[family-name:var(--font-serif)]">
                Google Workspace <em className="italic text-[#d97757]">Orchestrator</em>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#232321] border border-[#343431] text-[#b1ada1] font-mono not-italic">v0.5.0</span>
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Sync status badges */}
            {syncStatus && (
              <div className="hidden sm:flex items-center gap-2">
                {SERVICE_CONFIG.map(({ key, label, icon: Icon }) => {
                  const info = syncStatus[key];
                  return (
                    <div
                      key={key}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#232321] border border-[#343431] text-[11px]"
                      title={`${label}: ${info?.items_synced ?? 0} items synced`}
                    >
                      <Icon className="w-3 h-3 text-[#d97757]" />
                      <span className="text-[#847f72] font-mono">{label}:</span>
                      <span className="font-mono text-[#faf9f5] font-medium">
                        {info?.items_synced ?? 0}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}

            {/* LLM Model Selector */}
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-[#232321] border border-[#343431] text-xs font-mono">
              <span className="text-[#847f72] text-[11px]">Model:</span>
              <select
                value={llmProvider}
                onChange={(e) => setLlmProvider(e.target.value as "gemini" | "groq")}
                className="bg-[#141413] text-[#faf9f5] text-xs font-mono rounded px-2 py-0.5 border border-[#343431] focus:outline-none focus:border-[#d97757] cursor-pointer"
              >
                <option value="gemini">Gemini Flash</option>
                <option value="groq">Groq (gpt-oss-120b)</option>
              </select>
            </div>

            {/* Sync button */}
            <button
              onClick={handleTriggerSync}
              disabled={syncing}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#1b1b1a] hover:bg-[#232321] border border-[#343431] text-xs font-medium text-[#faf9f5] transition-colors disabled:opacity-40"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#d97757] ${syncing ? "sync-spinning" : ""}`} />
              {syncing ? "Syncing..." : "Sync Workspace"}
            </button>
          </div>
        </header>

        {/* ============== MESSAGES AREA ============== */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-6 bg-[#141413]">
          <div className="max-w-3xl mx-auto space-y-4">
            {messages.length === 0 ? (
              /* ---- Empty state ---- */
              <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
                <div className="w-12 h-12 rounded-xl bg-[#1b1b1a] border border-[#343431] flex items-center justify-center mb-4 text-[#d97757] shadow-sm">
                  <Terminal className="w-6 h-6" />
                </div>
                <h2 className="text-2xl font-[family-name:var(--font-serif)] font-normal text-[#faf9f5] mb-1">
                  Workspace Orchestration <em className="italic text-[#d97757]">Engine</em>
                </h2>
                <p className="text-xs text-[#b1ada1] mb-6 max-w-md">
                  Executes queries across Gmail, Calendar, and Drive using typed DAG plans, hybrid search retrieval, and security confirmation gates.
                </p>

                {/* Sample queries grid */}
                <div className="w-full max-w-xl">
                  <p className="text-[11px] font-mono uppercase tracking-wider text-[#847f72] mb-3 text-left">
                    Sample Queries:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left">
                    {SAMPLE_QUERIES.map((q) => (
                      <button
                        key={q}
                        onClick={() => handleSendQuery(q)}
                        className="text-xs px-3 py-2.5 rounded bg-[#1b1b1a] hover:bg-[#232321] border border-[#343431] hover:border-[#d97757]/40 text-[#faf9f5] transition-colors flex items-center justify-between group"
                      >
                        <span className="truncate">{q}</span>
                        <ChevronDown className="w-3 h-3 text-[#847f72] group-hover:text-[#d97757] flex-shrink-0 -rotate-90 transition-colors" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              /* ---- Message thread ---- */
              messages.map((msg, index) => (
                <div key={`${msg.id}-${index}`} className="msg-animate">
                  {/* ---- User message ---- */}
                  {msg.sender === "user" && (
                    <div className="flex justify-end mb-4">
                      <div className="max-w-[80%]">
                        <div className="px-4 py-3 text-xs leading-relaxed bg-[#232321] border border-[#343431] text-[#faf9f5] font-medium rounded-lg shadow-sm">
                          <p className="whitespace-pre-wrap">{msg.text}</p>
                        </div>
                        <p className="text-[10px] mt-1 text-right text-[#847f72] font-mono">
                          {formatTimestamp(msg.timestamp)}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* ---- Assistant message ---- */}
                  {msg.sender === "assistant" && (
                    <div className="flex justify-start mb-6">
                      <div className="max-w-[90%] w-full">
                        <div className="px-4 py-4 text-xs leading-relaxed space-y-4 bg-[#1b1b1a] border border-[#343431] rounded-lg text-[#faf9f5] shadow-sm">
                          {/* Status header badge */}
                          {msg.status === "error" && (
                            <div className="flex items-center gap-1.5 text-xs font-mono text-[#cf5656] border-b border-[#2a2a28] pb-2">
                              <AlertTriangle className="w-3.5 h-3.5" />
                              <span>Execution Error</span>
                            </div>
                          )}

                          {/* Plain text is a fallback. Workflow states use compact cards below. */}
                          {!msg.status && <FormattedMarkdownMessage content={msg.text} />}

                          {/* Clarification card */}
                          {msg.status === "needs_clarification" && msg.clarification && (
                            <ClarificationCard
                              question={msg.clarification.question}
                              missingFields={msg.clarification.missing_fields}
                              candidates={msg.clarification.candidates}
                              progress={msg.clarification.progress}
                            />
                          )}

                          {/* Unified workflow confirmation panel */}
                          {msg.status === "needs_confirmation" &&
                            msg.pending_actions &&
                            msg.pending_actions.length > 0 &&
                            msg.orchestration_id && (
                              <div className="p-4 rounded bg-zinc-900 border border-zinc-700 space-y-4">
                                <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                                  <div className="flex items-center gap-2 text-xs font-mono font-semibold text-white">
                                    <ShieldCheck className="w-4 h-4 text-white" />
                                    <span>Workflow Confirmation Required</span>
                                  </div>
                                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-800 text-zinc-300">
                                    {msg.pending_actions.length} action{msg.pending_actions.length > 1 ? "s" : ""} pending
                                  </span>
                                </div>

                                <p className="text-xs text-zinc-400">
                                  The following actions are ready to execute. Review and approve the entire workflow:
                                </p>

                                <div className="space-y-2">
                                  {msg.pending_actions.map((act, idx) => {
                                    const toolIcon = act.action_type.startsWith("calendar") ? Calendar
                                      : act.action_type.startsWith("gmail") ? Mail
                                      : act.action_type.startsWith("drive") ? FileText
                                      : Layers;
                                    const ToolIcon = toolIcon;
                                    const params = act.payload?.arguments || act.payload || {};

                                    return (
                                      <div
                                        key={act.pending_action_id || idx}
                                        className="p-3 rounded bg-black border border-zinc-800 text-xs space-y-1.5"
                                      >
                                        <div className="flex items-center gap-2">
                                          <ToolIcon className="w-3.5 h-3.5 text-zinc-400 flex-shrink-0" />
                                          <span className="font-mono font-semibold text-white">
                                            {act.action_type}
                                          </span>
                                        </div>
                                        <div className="pl-5.5 space-y-0.5 text-zinc-400">
                                          {Object.entries(params).map(([key, val]) => (
                                            <div key={key} className="flex gap-1.5">
                                              <span className="text-zinc-500 font-mono">{key}:</span>
                                              <span className="text-zinc-300 truncate">
                                                {typeof val === "string" ? val : JSON.stringify(val)}
                                              </span>
                                            </div>
                                          ))}
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>

                                {/* Workflow action buttons */}
                                <div className="flex gap-2 pt-1">
                                  <button
                                    onClick={() => handleWorkflowApproval(msg.id, msg.orchestration_id!, true)}
                                    disabled={confirmingActionIds[msg.orchestration_id!]}
                                    className="flex-1 py-2.5 rounded bg-white hover:bg-zinc-200 text-black font-semibold text-xs transition-colors disabled:opacity-40 flex items-center justify-center gap-1.5"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    {confirmingActionIds[msg.orchestration_id!]
                                      ? "Executing all actions..."
                                      : "Approve All"}
                                  </button>
                                  <button
                                    onClick={() => handleWorkflowApproval(msg.id, msg.orchestration_id!, false)}
                                    disabled={confirmingActionIds[msg.orchestration_id!]}
                                    className="flex-1 py-2.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 font-medium text-xs transition-colors disabled:opacity-40 flex items-center justify-center gap-1.5"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                    Reject
                                  </button>
                                </div>
                              </div>
                            )}

                          {/* Live execution timeline and concise completion result. */}
                          {msg.actions_taken && msg.actions_taken.length > 0 &&
                            (msg.status === "needs_confirmation" || msg.status === "completed" || msg.status === "error") && (
                              <ExecutionProgressCard
                                steps={msg.actions_taken}
                                status={msg.status === "error" ? "failed" : msg.status}
                              />
                            )}

                          {(msg.status === "completed" || msg.status === "error") && (
                            <CompletionSummaryCard
                              summary={msg.text}
                              actions={msg.actions_taken || []}
                              status={msg.status === "completed" ? "completed" : "failed"}
                            />
                          )}

                          {/* Executed Tools & DAG Step Trace Drawer */}
                          {msg.actions_taken && msg.actions_taken.length > 0 && (
                            <div className="pt-3 border-t border-zinc-800">
                              <button
                                onClick={() => toggleStepVisibility(msg.id)}
                                className="flex items-center justify-between w-full text-xs font-mono text-zinc-400 hover:text-white transition-colors"
                              >
                                <span className="flex items-center gap-2">
                                  <Wrench className="w-3.5 h-3.5 text-white" />
                                  <span>
                                    Tools Executed ({msg.actions_taken.length})
                                  </span>
                                </span>
                                {showSteps[msg.id] ? (
                                  <ChevronUp className="w-3.5 h-3.5" />
                                ) : (
                                  <ChevronDown className="w-3.5 h-3.5" />
                                )}
                              </button>

                              {showSteps[msg.id] && (
                                <div className="mt-3 space-y-2 pl-3 border-l border-zinc-800">
                                  {msg.actions_taken.map((act) => {
                                    const stepKey = `${msg.id}-${act.step_id}`;
                                    return (
                                      <div
                                        key={act.step_id}
                                        className="p-2.5 rounded bg-black border border-zinc-800 text-xs space-y-2 font-mono"
                                      >
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-2">
                                            <span className="text-zinc-500">Step:</span>
                                            <span className="text-white font-semibold">
                                              {act.step_id}
                                            </span>
                                            {act.tool && (
                                              <span className="px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 text-[10px]">
                                                {act.tool}
                                              </span>
                                            )}
                                          </div>
                                          <div className="flex items-center gap-2">
                                            <span
                                              className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                                                act.status === "completed"
                                                  ? "bg-zinc-800 text-white border border-zinc-700"
                                                  : "bg-zinc-900 text-zinc-400"
                                              }`}
                                            >
                                              {act.status}
                                            </span>
                                            {act.output && (
                                              <button
                                                onClick={() => toggleToolDetails(stepKey)}
                                                className="text-[10px] text-zinc-400 hover:text-white underline"
                                              >
                                                {showToolDetails[stepKey] ? "Hide Details" : "View Details"}
                                              </button>
                                            )}
                                          </div>
                                        </div>

                                        {/* Expanded tool details: inputs, outputs, timings, and failures. */}
                                        {showToolDetails[stepKey] && (
                                          <div className="pt-2 border-t border-zinc-900 space-y-1">
                                            <p className="text-[10px] text-zinc-500">Input</p>
                                            <pre className="text-[10px] overflow-x-auto p-2 rounded bg-zinc-950 border border-zinc-900 text-zinc-300">
                                              {JSON.stringify(act.input ?? {}, null, 2)}
                                            </pre>
                                            <p className="text-[10px] text-zinc-500">Output</p>
                                            <pre className="text-[10px] overflow-x-auto p-2 rounded bg-zinc-950 border border-zinc-900 text-zinc-300">
                                              {JSON.stringify(act.output ?? {}, null, 2)}
                                            </pre>
                                            {act.error && <p className="text-[10px] text-rose-300">Error: {act.error}</p>}
                                            {(act.started_at || act.completed_at) && (
                                              <p className="text-[10px] text-zinc-500">
                                                Started: {act.started_at ? new Date(act.started_at).toLocaleTimeString() : "—"} · Ended: {act.completed_at ? new Date(act.completed_at).toLocaleTimeString() : "—"}
                                              </p>
                                            )}
                                          </div>
                                        )}
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                        <p className="text-[10px] mt-1 text-zinc-600 font-mono">
                          {formatTimestamp(msg.timestamp)}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}

            {/* Thinking indicator */}
            {loading && (
              <div className="flex justify-start mb-4 msg-animate">
                <div className="px-4 py-3 flex items-center gap-2 bg-[#1b1b1a] border border-[#343431] rounded-lg shadow-sm">
                  <div className="flex items-center gap-0.5">
                    <span className="thinking-dot" />
                    <span className="thinking-dot" />
                    <span className="thinking-dot" />
                  </div>
                  <span className="text-xs font-mono text-[#b1ada1]">
                    Thinking &amp; Orchestrating DAG Plan...
                  </span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* ============== INPUT BAR ============== */}
        <div className="px-4 sm:px-6 py-3 border-t border-[#343431] bg-[#171716] flex-shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendQuery();
            }}
            className="max-w-3xl mx-auto flex gap-2"
          >
            <input
              ref={inputRef}
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="Ask about your Gmail, Calendar, or Drive..."
              className="flex-1 px-4 py-2.5 rounded bg-[#141413] border border-[#343431] text-xs text-[#faf9f5] placeholder-[#847f72] focus:border-[#d97757] transition-colors"
            />
            <button
              type="submit"
              disabled={loading || !inputQuery.trim()}
              className="px-4 py-2.5 rounded bg-[#d97757] hover:bg-[#e28b6d] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-30 disabled:cursor-not-allowed shadow-sm"
            >
              <span>Send</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
