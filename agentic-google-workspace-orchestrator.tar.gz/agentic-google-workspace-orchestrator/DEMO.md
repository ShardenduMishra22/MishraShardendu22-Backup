# Demo Script & 12 Evaluation Query Guide

This document outlines the recommended **5-minute video demo sequence** and documents the **12 evaluation test queries** along with their expected system behavior.

---

## 1. 5-Minute Video Demo Script Sequence

### Timestamp Breakdown

```text
0:00 - 0:30  |  Architecture & Technical Stack Overview
0:30 - 1:00  |  Google Connection & Multi-Service Sync (Gmail, Calendar, Drive)
1:00 - 2:15  |  Multi-Service Orchestration Demo ("Prepare for tomorrow's Acme meeting")
2:15 - 3:15  |  Write Operation & Confirmation Gate ("Cancel my Turkish Airlines flight")
3:15 - 3:45  |  Ambiguity Handling & Clarification Request ("Move the meeting with John")
3:45 - 4:20  |  Hybrid Retrieval Benchmark & Precision@5 Metrics
4:20 - 5:00  |  Docker Compose Verification & 1M-User Production Scaling Plan
```

### Detailed Demo Actions

1. **0:00 - 0:30 (Stack Overview)**:
   - Show Next.js Frontend at `http://localhost:3000` and Swagger docs at `http://localhost:8000/docs`.
   - Highlight core technical stack: FastAPI, PostgreSQL 16 + `pgvector`, Redis, OpenRouter LLM, Next.js.
   - Emphasize **No LangChain/LlamaIndex**: Python DAG Validator & Parallel Executor strictly control execution.

2. **0:30 - 1:00 (Google OAuth & Sync)**:
   - Click **Connect Google** button to demonstrate Google OAuth 2.0 consent flow.
   - Click **Sync Workspace** button to demonstrate parallel ingestion across Gmail, Calendar, and Drive.

3. **1:00 - 2:15 (Multi-Service Query Demo)**:
   - Enter query: *"Prepare for tomorrow's meeting with Acme Corp"*.
   - Point out parallel execution of search tools across Gmail, Calendar, and Drive.
   - Show collapsed **Executed DAG Steps** UI card.

4. **2:15 - 3:15 (Confirmation Gate Demo)**:
   - Enter query: *"Cancel my Turkish Airlines flight"*.
   - Point out that `gmail.send_email` tool has `requires_confirmation = True`.
   - Show the interactive **User Confirmation Required** card on the frontend with `[Confirm]` and `[Reject]` buttons.
   - Click **Confirm Execution** and show atomic status update.

5. **3:15 - 3:45 (Ambiguity Handling)**:
   - Enter query: *"Move the meeting with John"*.
   - Show the **Clarification Needed** warning card asking the user for missing details instead of executing arbitrary actions.

6. **3:45 - 4:20 (Benchmark & Metrics)**:
   - Run `docker compose exec api uv run python scripts/benchmark_retrieval.py`.
   - Show **Mean Precision@5 = 0.80** and **Total Retrieval Latency = 2.57 ms**.

7. **4:20 - 5:00 (Docker & Production Design)**:
   - Show `docker compose ps` displaying all 4 healthy containers (`api`, `frontend`, `postgres`, `redis`).
   - Conclude with high-level summary of `DESIGN.md` 1M-user production scaling plan.

---

## 2. 10+ Evaluation Test Queries & Expected Outputs

### Single Service Queries

#### 1. "What's on my calendar next week?"
- **Intent**: `search_calendar`
- **Services**: `["calendar"]`
- **Tools**: `calendar.search_events`
- **Clarification Expected**: No
- **Confirmation Expected**: No
- **Expected Outcome**: Returns upcoming calendar events within next week's date bounds.

#### 2. "Find emails from sarah@company.com about the budget"
- **Intent**: `search_email`
- **Services**: `["gmail"]`
- **Tools**: `gmail.search_emails`
- **Clarification Expected**: No
- **Confirmation Expected**: No
- **Expected Outcome**: Returns matching budget emails sent by `sarah@company.com`.

#### 3. "Show me PDFs in Drive from last month"
- **Intent**: `search_drive`
- **Services**: `["drive"]`
- **Tools**: `drive.search_files`
- **Clarification Expected**: No
- **Confirmation Expected**: No
- **Expected Outcome**: Applies `mime_type="application/pdf"` and date range filters to return Drive PDFs.

#### 4. "Find my latest email about the proposal"
- **Intent**: `search_email`
- **Services**: `["gmail"]`
- **Tools**: `gmail.search_emails`
- **Clarification Expected**: No
- **Confirmation Expected**: No
- **Expected Outcome**: Returns most recent proposal email.

---

### Multi-Service Queries

#### 5. "Cancel my Turkish Airlines flight"
- **Intent**: `cancel_flight`
- **Services**: `["gmail", "calendar"]`
- **Tools**: `gmail.search_emails`, `calendar.search_events`, `gmail.send_email`
- **Clarification Expected**: No
- **Confirmation Expected**: **Yes** (`gmail.send_email`)
- **Expected Outcome**: Retrieves booking details, prepares draft cancellation email, and pauses for explicit user confirmation.

#### 6. "Prepare for tomorrow's meeting with Acme Corp"
- **Intent**: `prepare_meeting`
- **Services**: `["calendar", "gmail", "drive"]`
- **Tools**: `calendar.search_events`, `gmail.search_emails`, `drive.search_files`
- **Clarification Expected**: No
- **Confirmation Expected**: No
- **Expected Outcome**: Executes parallel search across all 3 services and synthesizes preparation summary brief.

#### 7. "Find events next week that conflict with my out-of-office doc"
- **Intent**: `cross_service_search`
- **Services**: `["drive", "calendar"]`
- **Tools**: `drive.search_files`, `calendar.search_events`
- **Clarification Expected**: No
- **Confirmation Expected**: No
- **Expected Outcome**: Reads out-of-office document, checks calendar events in date range, and highlights conflicts.

#### 8. "Find the meeting related to the budget proposal and show me the related emails"
- **Intent**: `cross_service_search`
- **Services**: `["calendar", "gmail"]`
- **Tools**: `calendar.search_events`, `gmail.search_emails`
- **Clarification Expected**: No
- **Confirmation Expected**: No
- **Expected Outcome**: Finds budget meeting and retrieves corresponding email threads.

---

### Hard Cases (Ambiguity & Temporal Interpretation)

#### 9. "Move the meeting with John"
- **Intent**: `move_meeting`
- **Services**: `["calendar"]`
- **Tools**: N/A (Halted before planning)
- **Clarification Expected**: **Yes**
- **Confirmation Expected**: No
- **Expected Outcome**: Classifier flags `"ambiguous": true` and returns a clarification question asking for target meeting time.

#### 10. "That email about the proposal"
- **Intent**: `search_email`
- **Services**: `["gmail"]`
- **Tools**: `gmail.search_emails`
- **Clarification Expected**: No
- **Confirmation Expected**: No
- **Expected Outcome**: Context window loads recent messages to resolve reference to proposal email.

#### 11. "What's happening next Tuesday?"
- **Intent**: `search_calendar`
- **Services**: `["calendar"]`
- **Tools**: `calendar.search_events`
- **Clarification Expected**: No
- **Confirmation Expected**: No
- **Expected Outcome**: Resolves relative phrase "next Tuesday" to exact ISO start/end date bounds.

#### 12. "Send the cancellation email"
- **Intent**: `send_email`
- **Services**: `["gmail"]`
- **Tools**: `gmail.send_email`
- **Clarification Expected**: No
- **Confirmation Expected**: **Yes** (`gmail.send_email`)
- **Expected Outcome**: Halts execution and presents confirmation card with recipient, subject, and body before sending.
