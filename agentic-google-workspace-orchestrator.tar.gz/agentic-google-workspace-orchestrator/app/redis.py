# Check Redis connectivity for readiness probe and close Redis client connection on application shutdown.

from redis.asyncio import Redis
from app.config import settings

redis_client = Redis.from_url(settings.REDIS_URL, decode_responses=True)


async def check_redis_health() -> bool:
    """Check Redis connectivity for readiness probe."""
    try:
        return await redis_client.ping()
    except Exception:
        return False


async def close_redis_connection() -> None:
    """Close Redis client connection."""
    await redis_client.close()
