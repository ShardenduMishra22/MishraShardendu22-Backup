# return top semantic vector candidates from pgvector cosine similarity search

import uuid
from typing import Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import WorkspaceChunk, WorkspaceItem
from app.retrieval.models import CandidateChunk, SearchFilters
from app.services.embedding_service import embedding_service

VECTOR_CANDIDATES = 20


async def search_vector_candidates(
    db: AsyncSession,
    user_id: uuid.UUID,
    query: str,
    filters: Optional[SearchFilters] = None,
    candidate_limit: int = VECTOR_CANDIDATES,
) -> list[CandidateChunk]:
    """Retrieve top semantic vector candidates using pgvector cosine similarity.

    Mandatory multi-tenant scoping: workspace_items.user_id == user_id.
    """
    if not query or not query.strip():
        return []

    # Generate query embedding using Redis cache + OpenRouter
    try:
        query_vector = await embedding_service.get_embedding(query)
    except Exception:
        # Fallback gracefully if embedding service fails
        return []

    if not query_vector:
        return []

    distance_col = WorkspaceChunk.embedding.cosine_distance(query_vector).label("distance")

    stmt = (
        select(
            WorkspaceChunk.id.label("chunk_id"),
            WorkspaceChunk.workspace_item_id,
            WorkspaceChunk.chunk_index,
            WorkspaceChunk.content,
            distance_col,
        )
        .join(WorkspaceItem, WorkspaceItem.id == WorkspaceChunk.workspace_item_id)
        .where(
            WorkspaceItem.user_id == user_id,
            WorkspaceChunk.embedding.is_not(None),
        )
    )

    # Apply structured filters
    if filters:
        if filters.services:
            stmt = stmt.where(WorkspaceItem.service.in_([s.lower() for s in filters.services]))
        if filters.item_types:
            stmt = stmt.where(WorkspaceItem.item_type.in_([t.lower() for t in filters.item_types]))
        if filters.date_from:
            stmt = stmt.where(
                (WorkspaceItem.source_created_at >= filters.date_from)
                | (WorkspaceItem.source_updated_at >= filters.date_from)
            )
        if filters.date_to:
            stmt = stmt.where(
                (WorkspaceItem.source_created_at <= filters.date_to)
                | (WorkspaceItem.source_updated_at <= filters.date_to)
            )
        if filters.sender:
            stmt = stmt.where(WorkspaceItem.metadata_["sender"].astext.ilike(f"%{filters.sender}%"))
        if filters.recipient:
            stmt = stmt.where(WorkspaceItem.metadata_["recipients"].astext.ilike(f"%{filters.recipient}%"))
        if filters.attendee:
            stmt = stmt.where(WorkspaceItem.metadata_["attendees"].astext.ilike(f"%{filters.attendee}%"))
        if filters.mime_type:
            stmt = stmt.where(WorkspaceItem.metadata_["mime_type"].astext == filters.mime_type)

    stmt = stmt.order_by(distance_col.asc()).limit(candidate_limit)

    res = await db.execute(stmt)
    rows = res.fetchall()

    candidates = []
    for idx, row in enumerate(rows, start=1):
        # Convert distance to similarity score (1 - distance)
        similarity = 1.0 - float(row.distance) if row.distance is not None else 0.0
        candidates.append(
            CandidateChunk(
                chunk_id=row.chunk_id,
                workspace_item_id=row.workspace_item_id,
                chunk_index=row.chunk_index,
                content=row.content,
                rank=idx,
                raw_score=similarity,
                search_type="semantic",
            )
        )

    return candidates
