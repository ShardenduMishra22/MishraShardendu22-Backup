"""Unified hybrid retrieval package."""
