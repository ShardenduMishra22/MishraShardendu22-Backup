# fusion of the results from lexical and semantic search using Reciprocal Rank Fusion (RRF)

import uuid
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import WorkspaceItem
from app.retrieval.models import CandidateChunk, SearchResult

# K is small, rank position matters a lot.
# K is large, rank position does not matters a lot.
RRF_K = 60.0

async def perform_rrf_fusion(
    db: AsyncSession,
    lexical_candidates: list[CandidateChunk],
    semantic_candidates: list[CandidateChunk],
    limit: int = 5,
    k: float = RRF_K,
) -> list[SearchResult]:
    """Perform Reciprocal Rank Fusion over candidate chunks and aggregate into deduplicated Top-5 Workspace Items.
    Formula: RRF_score(chunk) = (1 / (k + rank_lexical)) + (1 / (k + rank_semantic))
    """
    chunk_scores: dict[uuid.UUID, float] = {}
    chunk_lexical_ranks: dict[uuid.UUID, int] = {}
    chunk_semantic_ranks: dict[uuid.UUID, int] = {}
    chunk_map: dict[uuid.UUID, CandidateChunk] = {}

    # 1. Process Lexical Candidates
    for c in lexical_candidates:
        chunk_map[c.chunk_id] = c
        chunk_lexical_ranks[c.chunk_id] = c.rank
        rrf_contrib = 1.0 / (k + c.rank)
        chunk_scores[c.chunk_id] = chunk_scores.get(c.chunk_id, 0.0) + rrf_contrib

    # 2. Process Semantic Candidates
    for c in semantic_candidates:
        chunk_map[c.chunk_id] = c
        chunk_semantic_ranks[c.chunk_id] = c.rank
        rrf_contrib = 1.0 / (k + c.rank)
        chunk_scores[c.chunk_id] = chunk_scores.get(c.chunk_id, 0.0) + rrf_contrib

    if not chunk_scores:
        return []

    # 3. Item-Level Aggregation & Deduplication
    # Group matching chunks by workspace_item_id to prevent multiple chunks of 1 doc from crowding out top 5
    item_chunk_groups: dict[uuid.UUID, list[uuid.UUID]] = {}
    for chunk_id, c_obj in chunk_map.items():
        item_id = c_obj.workspace_item_id
        if item_id not in item_chunk_groups:
            item_chunk_groups[item_id] = []
        item_chunk_groups[item_id].append(chunk_id)

    item_scores: list[tuple[uuid.UUID, float, uuid.UUID, float]] = []  # (item_id, item_score, best_chunk_id, best_chunk_score)

    for item_id, c_ids in item_chunk_groups.items():
        # Pick highest scoring chunk for this item as representative
        best_c_id = max(c_ids, key=lambda cid: chunk_scores[cid])
        best_c_score = chunk_scores[best_c_id]
        
        # Aggregate item score: max chunk score + small boost for additional matching chunks
        item_score = best_c_score + 0.01 * (len(c_ids) - 1)
        item_scores.append((item_id, item_score, best_c_id, best_c_score))

    # Sort items by item_score descending
    item_scores.sort(key=lambda x: x[1], reverse=True)
    top_items_slice = item_scores[: min(limit, 50)]

    if not top_items_slice:
        return []

    # 4. Fetch WorkspaceItem details from database
    target_item_ids = [t[0] for t in top_items_slice]
    stmt = select(WorkspaceItem).where(WorkspaceItem.id.in_(target_item_ids))
    res = await db.execute(stmt)
    db_items = {item.id: item for item in res.scalars().all()}

    # 5. Build final SearchResult list
    results = []
    for item_id, item_score, best_chunk_id, _ in top_items_slice:
        item = db_items.get(item_id)
        if not item:
            continue

        best_chunk = chunk_map[best_chunk_id]
        lex_rank = chunk_lexical_ranks.get(best_chunk_id)
        sem_rank = chunk_semantic_ranks.get(best_chunk_id)

        results.append(
            SearchResult(
                item_id=item.id,
                service=item.service,
                item_type=item.item_type,
                external_id=item.external_id,
                title=item.title,
                content=best_chunk.content,
                metadata=item.metadata_ or {},
                score=round(item_score, 6),
                lexical_rank=lex_rank,
                semantic_rank=sem_rank,
            )
        )

    return results
