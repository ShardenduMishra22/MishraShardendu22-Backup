import uuid
from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field


class SearchFilters(BaseModel):
    """Structured search filters for hybrid retrieval."""

    services: Optional[list[str]] = Field(None, description="Filter by service: gmail, calendar, drive")
    item_types: Optional[list[str]] = Field(None, description="Filter by item_type: email, calendar_event, drive_file")
    date_from: Optional[datetime] = Field(None, description="Start date filter (timezone aware)")
    date_to: Optional[datetime] = Field(None, description="End date filter (timezone aware)")
    sender: Optional[str] = Field(None, description="Filter by email sender")
    recipient: Optional[str] = Field(None, description="Filter by email recipient")
    attendee: Optional[str] = Field(None, description="Filter by calendar attendee email")
    mime_type: Optional[str] = Field(None, description="Filter by Drive file MIME type")


class CandidateChunk(BaseModel):
    """Internal representation of a candidate chunk retrieved from FTS or Vector search."""

    chunk_id: uuid.UUID
    workspace_item_id: uuid.UUID
    chunk_index: int
    content: str
    rank: int  # 1-indexed rank within candidate list
    raw_score: float
    search_type: str  # 'lexical' or 'semantic'


class SearchResult(BaseModel):
    """External result model representing a top workspace item match."""

    item_id: uuid.UUID
    service: str
    item_type: str
    external_id: str
    title: Optional[str] = None
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    score: float  # RRF score
    lexical_rank: Optional[int] = None
    semantic_rank: Optional[int] = None
