# 

import logging
import time
import uuid
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession

from app.retrieval.fts import search_lexical_candidates
from app.retrieval.fusion import perform_rrf_fusion
from app.retrieval.models import SearchFilters, SearchResult
from app.retrieval.vector import search_vector_candidates

import re
from sqlalchemy import select
from app.models.models import WorkspaceItem

logger = logging.getLogger(__name__)


def is_temporal_list_query(query: Optional[str]) -> bool:
    """Check if query is a deterministic temporal/listing query without specific search keywords."""
    if not query or not query.strip():
        return True
    q_clean = query.strip().lower()

    temporal_words = {"last", "latest", "recent", "newest", "inbox", "mails", "emails", "messages"}
    stop_words = {"can", "u", "you", "summarise", "summarize", "show", "get", "fetch", "list", "my", "the", "for", "me", "1", "2", "3", "4", "5", "10"}

    # Extract non-stop words
    tokens = re.findall(r"\w+", q_clean)
    content_tokens = [t for t in tokens if t not in stop_words and t not in temporal_words]

    # If all non-stop tokens are temporal/listing tokens and no distinct content keywords remain
    if any(t in temporal_words for t in tokens) and len(content_tokens) == 0:
        return True

    return False


async def search_structured_items(
    db: AsyncSession,
    user_id: uuid.UUID,
    filters: Optional[SearchFilters] = None,
    limit: int = 5,
    sort_by: str = "newest",
) -> list[SearchResult]:
    """Retrieve items directly via structured SQL metadata query ordered by timestamp."""
    stmt = select(WorkspaceItem).where(WorkspaceItem.user_id == user_id)
    if filters:
        if filters.services:
            stmt = stmt.where(WorkspaceItem.service.in_(filters.services))
        if filters.item_types:
            stmt = stmt.where(WorkspaceItem.item_type.in_(filters.item_types))
        if filters.sender:
            stmt = stmt.where(WorkspaceItem.metadata_["sender"].astext.ilike(f"%{filters.sender}%"))
        if filters.recipient:
            stmt = stmt.where(WorkspaceItem.metadata_["recipients"].astext.ilike(f"%{filters.recipient}%"))

    if sort_by == "oldest":
        stmt = stmt.order_by(WorkspaceItem.source_created_at.asc())
    else:
        stmt = stmt.order_by(WorkspaceItem.source_created_at.desc().nulls_last())

    stmt = stmt.limit(limit)
    res = await db.execute(stmt)
    items = res.scalars().all()

    results = []
    for item in items:
        results.append(
            SearchResult(
                item_id=item.id,
                service=item.service,
                item_type=item.item_type,
                external_id=item.external_id,
                title=item.title,
                content=item.content,
                metadata=item.metadata_ or {},
                source_created_at=item.source_created_at,
                source_updated_at=item.source_updated_at,
                score=1.0,
                retrieval_method="structured_metadata",
            )
        )
    return results


async def search_workspace(
    db: AsyncSession,
    user_id: uuid.UUID,
    query: str,
    services: Optional[list[str]] = None,
    item_types: Optional[list[str]] = None,
    filters: Optional[SearchFilters] = None,
    limit: int = 5,
) -> list[SearchResult]:
    """Unified hybrid workspace search combining FTS and pgvector via RRF.

    Mandatory multi-tenant requirement: user_id MUST be provided.
    """
    if not user_id:
        raise ValueError("Multi-tenant security boundary error: user_id is required for workspace search.")

    # Construct search filters
    search_filters = filters or SearchFilters()
    if services:
        search_filters.services = services
    if item_types:
        search_filters.item_types = item_types

    # Structured Metadata Search for empty or purely temporal listing queries
    if not query or not query.strip() or is_temporal_list_query(query):
        return await search_structured_items(db, user_id=user_id, filters=search_filters, limit=limit)

    start_total = time.perf_counter()

    # 1. Lexical FTS Search
    start_fts = time.perf_counter()
    lexical_candidates = await search_lexical_candidates(
        db, user_id=user_id, query=query, filters=search_filters
    )
    fts_ms = (time.perf_counter() - start_fts) * 1000.0

    # 2. Vector Semantic Search
    start_vec = time.perf_counter()
    vector_candidates = await search_vector_candidates(
        db, user_id=user_id, query=query, filters=search_filters
    )
    vec_ms = (time.perf_counter() - start_vec) * 1000.0

    # 3. Reciprocal Rank Fusion & Item Deduplication
    start_fusion = time.perf_counter()
    results = await perform_rrf_fusion(
        db, lexical_candidates=lexical_candidates, semantic_candidates=vector_candidates, limit=limit
    )
    fusion_ms = (time.perf_counter() - start_fusion) * 1000.0

    # 4. Resume Search Fallback (if hybrid search yielded 0 items and query is looking for a resume/CV)
    if not results and query and any(k in query.lower() for k in ("resume", "cv", "curriculum")):
        logger.info(f"Hybrid search returned 0 results for '{query}'. Running resume fallback title/MIME search.")
        stmt_fb = (
            select(WorkspaceItem)
            .where(
                WorkspaceItem.user_id == user_id,
                WorkspaceItem.service == "drive",
                (
                    WorkspaceItem.title.ilike("%resume%")
                    | WorkspaceItem.title.ilike("%cv%")
                    | WorkspaceItem.title.ilike("%curriculum%")
                    | WorkspaceItem.metadata_["mime_type"].astext.ilike("%pdf%")
                ),
            )
            .order_by(WorkspaceItem.source_updated_at.desc().nulls_last(), WorkspaceItem.created_at.desc())
            .limit(limit)
        )
        res_fb = await db.execute(stmt_fb)
        fb_items = res_fb.scalars().all()
        results = [
            SearchResult(
                item_id=item.id,
                service=item.service,
                item_type=item.item_type,
                external_id=item.external_id,
                title=item.title,
                content=item.content,
                metadata=item.metadata_ or {},
                source_created_at=item.source_created_at,
                source_updated_at=item.source_updated_at,
                score=0.9,
                retrieval_method="resume_fallback_search",
            )
            for item in fb_items
        ]

    total_ms = (time.perf_counter() - start_total) * 1000.0

    logger.info(
        f"Workspace Search for user {user_id} | query='{query}' | "
        f"Total: {total_ms:.1f}ms (FTS: {fts_ms:.1f}ms, Vector: {vec_ms:.1f}ms, Fusion: {fusion_ms:.1f}ms) | "
        f"Results: {len(results)}"
    )

    return results
