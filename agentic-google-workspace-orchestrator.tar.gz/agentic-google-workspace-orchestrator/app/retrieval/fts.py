# fts search for candidate chunks using PostgreSQL Full-Text Search (FTS)

import uuid
from typing import Optional
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import WorkspaceChunk, WorkspaceItem
from app.retrieval.models import CandidateChunk, SearchFilters

LEXICAL_CANDIDATES = 20


async def search_lexical_candidates(
    db: AsyncSession,
    user_id: uuid.UUID,
    query: str,
    filters: Optional[SearchFilters] = None,
    candidate_limit: int = LEXICAL_CANDIDATES,
) -> list[CandidateChunk]:
    """Retrieve top lexical candidates using PostgreSQL Full-Text Search.

    Mandatory multi-tenant scoping: workspace_items.user_id == user_id.
    """
    if not query or not query.strip():
        return []

    ts_query = func.websearch_to_tsquery("english", query)
    rank_col = func.ts_rank_cd(WorkspaceChunk.search_vector, ts_query).label("rank_score")

    base_stmt = (
        select(
            WorkspaceChunk.id.label("chunk_id"),
            WorkspaceChunk.workspace_item_id,
            WorkspaceChunk.chunk_index,
            WorkspaceChunk.content,
            rank_col,
        )
        .join(WorkspaceItem, WorkspaceItem.id == WorkspaceChunk.workspace_item_id)
        .where(
            WorkspaceItem.user_id == user_id,
            WorkspaceChunk.search_vector.op("@@")(ts_query),
        )
    )

    stmt = base_stmt

    # Apply structured filters
    if filters:
        if filters.services:
            stmt = stmt.where(WorkspaceItem.service.in_([s.lower() for s in filters.services]))
        if filters.item_types:
            stmt = stmt.where(WorkspaceItem.item_type.in_([t.lower() for t in filters.item_types]))
        if filters.date_from:
            stmt = stmt.where(
                (WorkspaceItem.source_created_at >= filters.date_from)
                | (WorkspaceItem.source_updated_at >= filters.date_from)
            )
        if filters.date_to:
            stmt = stmt.where(
                (WorkspaceItem.source_created_at <= filters.date_to)
                | (WorkspaceItem.source_updated_at <= filters.date_to)
            )
        if filters.sender:
            stmt = stmt.where(WorkspaceItem.metadata_["sender"].astext.ilike(f"%{filters.sender}%"))
        if filters.recipient:
            stmt = stmt.where(WorkspaceItem.metadata_["recipients"].astext.ilike(f"%{filters.recipient}%"))
        if filters.attendee:
            stmt = stmt.where(WorkspaceItem.metadata_["attendees"].astext.ilike(f"%{filters.attendee}%"))
        if filters.mime_type:
            stmt = stmt.where(WorkspaceItem.metadata_["mime_type"].astext == filters.mime_type)

    stmt = stmt.order_by(rank_col.desc()).limit(candidate_limit)
    res = await db.execute(stmt)
    rows = res.fetchall()

    if not rows:
        ts_query_plain = func.plainto_tsquery("english", query)
        rank_col_plain = func.ts_rank_cd(WorkspaceChunk.search_vector, ts_query_plain).label("rank_score")
        stmt_fb = (
            select(
                WorkspaceChunk.id.label("chunk_id"),
                WorkspaceChunk.workspace_item_id,
                WorkspaceChunk.chunk_index,
                WorkspaceChunk.content,
                rank_col_plain,
            )
            .join(WorkspaceItem, WorkspaceItem.id == WorkspaceChunk.workspace_item_id)
            .where(
                WorkspaceItem.user_id == user_id,
                WorkspaceChunk.search_vector.op("@@")(ts_query_plain),
            )
        )
        if filters and filters.services:
            stmt_fb = stmt_fb.where(WorkspaceItem.service.in_([s.lower() for s in filters.services]))

        stmt_fb = stmt_fb.order_by(rank_col_plain.desc()).limit(candidate_limit)
        res_fb = await db.execute(stmt_fb)
        rows = res_fb.fetchall()

    candidates = []
    for idx, row in enumerate(rows, start=1):
        candidates.append(
            CandidateChunk(
                chunk_id=row.chunk_id,
                workspace_item_id=row.workspace_item_id,
                chunk_index=row.chunk_index,
                content=row.content,
                rank=idx,
                raw_score=float(row.rank_score),
                search_type="lexical",
            )
        )

    return candidates
