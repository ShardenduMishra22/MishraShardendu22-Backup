# used for testing retrieval performance against a benchmark dataset (used in test and evaluation)

import logging
import uuid
from typing import Any, Optional
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.retrieval.models import SearchFilters
from app.retrieval.search import search_workspace

logger = logging.getLogger(__name__)


class EvaluationQuery(BaseModel):
    """Model representing a test query and ground truth expected external IDs or titles."""

    query_id: str
    query: str
    services: Optional[list[str]] = None
    filters: Optional[SearchFilters] = None
    expected_external_ids: list[str]  # Ground truth relevant item external IDs


def calculate_precision_at_k(retrieved_external_ids: list[str], ground_truth_ids: set[str], k: int = 5) -> float:
    """Calculate Precision@K metric."""
    if not ground_truth_ids:
        return 0.0

    top_k = retrieved_external_ids[:k]
    relevant_retrieved = sum(1 for ext_id in top_k if ext_id in ground_truth_ids)
    
    # Precision relative to available relevant items (min(K, |ground_truth|))
    max_possible = min(k, len(ground_truth_ids))
    return round(relevant_retrieved / float(max_possible), 4)


async def evaluate_retrieval_benchmark(
    db: AsyncSession,
    user_id: uuid.UUID,
    dataset: list[EvaluationQuery],
    k: int = 5,
) -> dict[str, Any]:
    """Execute retrieval evaluation benchmark and compute Precision@K metrics."""
    query_results = []
    total_precision = 0.0

    for eval_item in dataset:
        results = await search_workspace(
            db,
            user_id=user_id,
            query=eval_item.query,
            services=eval_item.services,
            filters=eval_item.filters,
            limit=k,
        )

        retrieved_ids = [r.external_id for r in results]
        ground_truth = set(eval_item.expected_external_ids)
        prec = calculate_precision_at_k(retrieved_ids, ground_truth, k=k)

        total_precision += prec
        query_results.append({
            "query_id": eval_item.query_id,
            "query": eval_item.query,
            "precision_at_5": prec,
            "retrieved_count": len(results),
            "expected_count": len(ground_truth),
            "retrieved_external_ids": retrieved_ids,
        })

    avg_precision = round(total_precision / float(len(dataset)), 4) if dataset else 0.0

    return {
        "benchmark_count": len(dataset),
        "mean_precision_at_5": avg_precision,
        "queries": query_results,
    }
