# Database connection and session management for the FastAPI application
# using SQLAlchemy with asyncpg driver.
import re
from typing import AsyncGenerator
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.config import settings

# normalise the database URL to ensure compatibility with SQLAlchemy asyncpg driver
# (usually needed if the URL is in the form of postgresql:// or postgres://)
def normalize_database_url(url: str) -> str:
    """Normalize PostgreSQL database URL for SQLAlchemy asyncpg driver.

    Converts 'postgresql://' or 'postgres://' to 'postgresql+asyncpg://'.
    If driver is already specified (e.g., 'postgresql+asyncpg://'), leaves it untouched.
    """

    if not url:
        return url
    # Replace starting postgresql:// or postgres:// with postgresql+asyncpg://
    url = re.sub(r"^(postgres(?:ql)?)(?:\+[a-zA-Z0-9_-]+)?://", "postgresql+asyncpg://", url)
    # Strip unsupported libpq query parameters like channel_binding=...
    url = re.sub(r"([?&])channel_binding=[^&]+&?", r"\1", url)
    # Replace sslmode= query parameter with ssl= for asyncpg compatibility
    url = re.sub(r"([?&])sslmode=([a-zA-Z0-9_-]+)", r"\1ssl=\2", url)
    # Clean up trailing ? or & if created by parameter removal
    url = re.sub(r"[?&]$", "", url)
    return url

normalized_db_url = normalize_database_url(settings.DATABASE_URL)

engine = create_async_engine(
    normalized_db_url,
    echo=False,
    future=True,
    pool_pre_ping=True,
)

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
    class_=AsyncSession,
    expire_on_commit=False,
)

# Dependency to provide async DB session
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Dependency to provide async DB session."""
    async with AsyncSessionLocal() as session:
        yield session

# Health check function for database connectivity
async def check_database_health() -> bool:
    """Check database connectivity for readiness probe."""
    try:
        async with AsyncSessionLocal() as session:
            result = await session.execute(text("SELECT 1"))
            return result.scalar() == 1
    except Exception:
        return False


async def init_db() -> None:
    """Ensure pgvector extension and all database tables exist."""
    from app.models.models import Base
    async with engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector;"))
        await conn.run_sync(Base.metadata.create_all)