# Base file with base router, health check, and readiness check endpoints for the FastAPI application.
# Rest of the endpoints are defined in their respective routers and included in the main application.

from contextlib import asynccontextmanager
from typing import AsyncGenerator
from fastapi import FastAPI, Response, status
from fastapi.middleware.cors import CORSMiddleware

from app.api.actions import router as actions_router
from app.api.conversations import router as conversations_router
from app.api.auth import router as auth_router
from app.api.orchestration import router as orchestration_router
from app.api.query import router as query_router
from app.api.search import router as search_router
from app.api.sync import router as sync_router
from app.config import settings
from app.db import check_database_health, init_db
from app.middleware.rate_limit import RateLimitMiddleware
from app.redis import check_redis_health, close_redis_connection


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application startup and shutdown lifespan context."""
    try:
        await init_db()
    except Exception as e:
        import logging
        logging.getLogger("app.main").warning(f"Startup database initialization notice: {e}")
    yield
    await close_redis_connection()


app = FastAPI(
    title="Agentic Google Workspace Orchestrator",
    version="0.5.0",
    description="Backend orchestration service for Google Workspace operations.",
    lifespan=lifespan,
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "https://gws.mishrashardendu22.is-a.dev",
        "https://repo-transfer.mishrashardendu22.is-a.dev",
    ],
    allow_origin_regex=r"^https://.*(\.vercel\.app|\.is-a\.dev)$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rate limiting middleware
app.add_middleware(RateLimitMiddleware)

# Include API routers
app.include_router(auth_router)
app.include_router(sync_router)
app.include_router(search_router)
app.include_router(query_router)
app.include_router(actions_router)
app.include_router(orchestration_router)
app.include_router(conversations_router)


@app.get("/health", status_code=status.HTTP_200_OK)
async def health_check() -> dict[str, str]:
    """Process liveness probe."""
    return {"status": "ok"}


@app.get("/ready")
async def readiness_check(response: Response) -> dict[str, str]:
    """Dependency readiness probe checking database and redis connectivity."""
    db_healthy = await check_database_health()
    redis_healthy = await check_redis_health()

    db_status = "connected" if db_healthy else "disconnected"
    redis_status = "connected" if redis_healthy else "disconnected"

    if db_healthy and redis_healthy:
        response.status_code = status.HTTP_200_OK
        return {
            "status": "ready",
            "database": db_status,
            "redis": redis_status,
        }

    response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return {
        "status": "not_ready",
        "database": db_status,
        "redis": redis_status,
    }
