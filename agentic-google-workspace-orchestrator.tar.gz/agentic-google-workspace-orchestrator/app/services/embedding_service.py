# embedding chunks
# Normalized Workspace Item
#         ↓
#       Chunker
#         ↓
#   EmbeddingService   ← THIS CODE
#      ↙       ↘
#  Redis           OpenRouter
#  cache         embedding API
#      ↘       ↙
#     2048-d vector
#          ↓
#  PostgreSQL / pgvector


import hashlib
import json
import logging
from typing import Optional

from app.config import settings
from app.integrations.openrouter import OpenRouterClient, openrouter_client
from app.redis import redis_client

logger = logging.getLogger(__name__)

CACHE_TTL_SECONDS = 604800  # 7 days


class EmbeddingService:
    """Service to handle embedding generation with Redis caching."""

    def __init__(self, client: Optional[OpenRouterClient] = None):
        self.client = client or openrouter_client

    def _get_cache_key(self, text: str) -> str:
        """Compute Redis cache key using model name and SHA256 of text."""
        content_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
        return f"embedding:{settings.EMBEDDING_MODEL}:{content_hash}"

    async def get_embedding(self, text: str) -> list[float]:
        """Get embedding for a single text string, checking Redis cache first."""
        embeddings = await self.get_embeddings([text])
        return embeddings[0]

    async def get_embeddings(self, texts: list[str]) -> list[list[float]]:
        """Get embeddings for a list of text strings with batch Redis caching.

        Args:
            texts: List of input strings.

        Returns:
            List of float vectors, matched by position to input texts.
        """
        if not texts:
            return []

        cache_keys = [self._get_cache_key(t) for t in texts]
        results: list[Optional[list[float]]] = [None] * len(texts)

        # 1. Attempt Redis batch lookup
        try:
            cached_values = await redis_client.mget(cache_keys)
            for idx, cached_str in enumerate(cached_values):
                if cached_str:
                    try:
                        results[idx] = json.loads(cached_str)
                    except Exception as e:
                        logger.warning(f"Failed to parse cached embedding JSON at index {idx}: {e}")
        except Exception as e:
            logger.warning(f"Redis lookup error for embeddings: {e}")

        # 2. Identify cache misses
        missed_indices = [idx for idx, val in enumerate(results) if val is None]

        if not missed_indices:
            return [val for val in results if val is not None]

        # 3. Call OpenRouter for missing texts
        missed_texts = [texts[idx] for idx in missed_indices]

        logger.info(f"Embedding cache miss for {len(missed_texts)}/{len(texts)} chunks. Calling OpenRouter...")
        fetched_embeddings = await self.client.embed_texts(missed_texts)

        # 4. Fill in results and populate Redis cache
        cache_pipeline_data: dict[str, str] = {}
        for idx_in_missed, original_idx in enumerate(missed_indices):
            embedding = fetched_embeddings[idx_in_missed]
            results[original_idx] = embedding
            cache_key = cache_keys[original_idx]
            cache_pipeline_data[cache_key] = json.dumps(embedding)

        if cache_pipeline_data:
            try:
                pipe = redis_client.pipeline(transaction=False)
                for key, val_json in cache_pipeline_data.items():
                    pipe.set(key, val_json, ex=CACHE_TTL_SECONDS)
                await pipe.execute()
            except Exception as e:
                logger.warning(f"Failed to save embeddings to Redis cache: {e}")

        return [val for val in results if val is not None]


embedding_service = EmbeddingService()
