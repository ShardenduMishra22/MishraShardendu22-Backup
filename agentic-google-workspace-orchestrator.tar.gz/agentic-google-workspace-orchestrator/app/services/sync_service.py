# It does not fetch ALL Gmail, Calendar, and Drive data. In the code you showed, it fetches a limited number of
# If the user has 4,000 emails, this sync processes only up to 30 emails returned by fetch_recent_emails()

import asyncio
from datetime import datetime, timezone
import logging
from typing import Any, Optional
from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.integrations.google.auth import get_valid_access_token
from app.integrations.google.calendar import calendar_client
from app.integrations.google.drive import drive_client
from app.integrations.google.gmail import gmail_client
from app.models.models import GoogleAccount, SyncState, WorkspaceChunk, WorkspaceItem
from app.services.chunker import text_chunker
from app.services.embedding_service import embedding_service
from app.services.normalization import (
    normalize_calendar_event,
    normalize_drive_file,
    normalize_gmail_message,
)
from app.utils.serialization import serialize_for_jsonb

logger = logging.getLogger(__name__)


class SyncService:
    """Service handling synchronization, normalization, chunking, and embedding storage."""

    async def update_sync_state(
        self,
        db: AsyncSession,
        user_id: Any,
        service: str,
        status: str,
        last_error: Optional[str] = None,
        sync_cursor: Optional[str] = None,
    ) -> SyncState:
        """Update or create sync_state entry for a user and service."""
        stmt = select(SyncState).where(
            SyncState.user_id == user_id,
            SyncState.service == service,
        )
        res = await db.execute(stmt)
        state = res.scalar_one_or_none()

        now = datetime.now(timezone.utc)
        if not state:
            state = SyncState(
                user_id=user_id,
                service=service,
                status=status,
                last_synced_at=now if status == "success" else None,
                last_error=last_error,
                sync_cursor=sync_cursor,
            )
            db.add(state)
        else:
            state.status = status
            state.last_error = last_error
            if status == "success":
                state.last_synced_at = now
            if sync_cursor:
                state.sync_cursor = sync_cursor

        await db.commit()
        await db.refresh(state)
        return state

    async def upsert_workspace_item_and_chunks(
        self, db: AsyncSession, item_data: dict[str, Any]
    ) -> bool:
        """Idempotently upsert a normalized workspace item and its chunks.

        Returns True if item was created/updated, False if unchanged.
        """
        user_id = item_data["user_id"]
        service = item_data["service"]
        external_id = item_data["external_id"]

        stmt = select(WorkspaceItem).where(
            WorkspaceItem.user_id == user_id,
            WorkspaceItem.service == service,
            WorkspaceItem.external_id == external_id,
        )
        res = await db.execute(stmt)
        existing = res.scalar_one_or_none()

        now = datetime.now(timezone.utc)

        # Check if unchanged
        if existing:
            content_unchanged = (existing.content == item_data["content"]) and (
                existing.title == item_data["title"]
            )
            if content_unchanged:
                logger.debug(f"Workspace item {service}/{external_id} unchanged. Skipping.")
                return False

            # Update existing item fields
            existing.title = item_data["title"]
            existing.content = item_data["content"]
            existing.metadata_ = serialize_for_jsonb(item_data["metadata"])
            existing.source_created_at = item_data.get("source_created_at")
            existing.source_updated_at = item_data.get("source_updated_at")
            existing.indexed_at = now
            workspace_item = existing
        else:
            workspace_item = WorkspaceItem(
                user_id=user_id,
                service=service,
                item_type=item_data["item_type"],
                external_id=external_id,
                title=item_data["title"],
                content=item_data["content"],
                metadata_=serialize_for_jsonb(item_data["metadata"]),
                source_created_at=item_data.get("source_created_at"),
                source_updated_at=item_data.get("source_updated_at"),
                indexed_at=now,
            )
            db.add(workspace_item)

        await db.flush()

        # Delete existing chunks for this item if updating
        await db.execute(
            delete(WorkspaceChunk).where(WorkspaceChunk.workspace_item_id == workspace_item.id)
        )

        # Generate chunks
        chunks_raw = text_chunker.chunk_item(item_data)
        if not chunks_raw:
            await db.commit()
            return True

        chunk_texts = [c["content"] for c in chunks_raw]

        # Generate vector embeddings with Redis cache lookup
        embeddings = await embedding_service.get_embeddings(chunk_texts)

        # Create WorkspaceChunk instances with full-text tsvector
        for idx, chunk_data in enumerate(chunks_raw):
            emb_vector = embeddings[idx] if idx < len(embeddings) else None
            content_text = chunk_data["content"]

            chunk_obj = WorkspaceChunk(
                workspace_item_id=workspace_item.id,
                chunk_index=chunk_data["chunk_index"],
                content=content_text,
                embedding=emb_vector,
                search_vector=func.to_tsvector("english", content_text),
            )
            db.add(chunk_obj)

        await db.commit()
        return True

    async def sync_gmail(self, db: AsyncSession, google_acc: GoogleAccount) -> int:
        """Fetch and sync Gmail messages for a user."""
        await self.update_sync_state(db, google_acc.user_id, "gmail", "syncing")
        try:
            token = await get_valid_access_token(db, google_acc)
            raw_emails = await gmail_client.fetch_recent_emails(token, max_results=30)

            upserted_count = 0
            for raw in raw_emails:
                norm = normalize_gmail_message(raw, google_acc.user_id)
                changed = await self.upsert_workspace_item_and_chunks(db, norm)
                if changed:
                    upserted_count += 1

            await self.update_sync_state(db, google_acc.user_id, "gmail", "success")
            return upserted_count
        except Exception as e:
            logger.error(f"Gmail sync failed for user {google_acc.user_id}: {e}", exc_info=True)
            await self.update_sync_state(db, google_acc.user_id, "gmail", "failed", last_error=str(e))
            raise

    async def sync_calendar(self, db: AsyncSession, google_acc: GoogleAccount) -> int:
        """Fetch and sync Calendar events for a user."""
        await self.update_sync_state(db, google_acc.user_id, "calendar", "syncing")
        try:
            token = await get_valid_access_token(db, google_acc)
            raw_events = await calendar_client.fetch_recent_events(token, max_results=50)

            upserted_count = 0
            for raw in raw_events:
                norm = normalize_calendar_event(raw, google_acc.user_id)
                changed = await self.upsert_workspace_item_and_chunks(db, norm)
                if changed:
                    upserted_count += 1

            await self.update_sync_state(db, google_acc.user_id, "calendar", "success")
            return upserted_count
        except Exception as e:
            logger.error(f"Calendar sync failed for user {google_acc.user_id}: {e}", exc_info=True)
            await self.update_sync_state(db, google_acc.user_id, "calendar", "failed", last_error=str(e))
            raise

    async def sync_drive(self, db: AsyncSession, google_acc: GoogleAccount) -> int:
        """Fetch and sync Drive files for a user."""
        await self.update_sync_state(db, google_acc.user_id, "drive", "syncing")
        try:
            token = await get_valid_access_token(db, google_acc)
            raw_files = await drive_client.fetch_recent_files(token, max_results=30)

            upserted_count = 0
            for raw in raw_files:
                norm = normalize_drive_file(raw, google_acc.user_id)
                changed = await self.upsert_workspace_item_and_chunks(db, norm)
                if changed:
                    upserted_count += 1

            await self.update_sync_state(db, google_acc.user_id, "drive", "success")
            return upserted_count
        except Exception as e:
            logger.error(f"Drive sync failed for user {google_acc.user_id}: {e}", exc_info=True)
            await self.update_sync_state(db, google_acc.user_id, "drive", "failed", last_error=str(e))
            raise

    async def sync_services(
        self, db: AsyncSession, google_acc: GoogleAccount, services: list[str]
    ) -> dict[str, Any]:
        """Run service sync tasks sequentially with error isolation."""
        target_services = [s.lower() for s in services]
        summary = {}

        for svc in ["gmail", "calendar", "drive"]:
            if svc in target_services:
                try:
                    if svc == "gmail":
                        res = await self.sync_gmail(db, google_acc)
                    elif svc == "calendar":
                        res = await self.sync_calendar(db, google_acc)
                    elif svc == "drive":
                        res = await self.sync_drive(db, google_acc)
                    summary[svc] = {"status": "success", "items_processed": res}
                except Exception as e:
                    logger.error(f"{svc.capitalize()} sync failed for user {google_acc.user_id}: {e}")
                    summary[svc] = {"status": "failed", "error": str(e)}

        return {"status": "completed", "results": summary}


sync_service = SyncService()
