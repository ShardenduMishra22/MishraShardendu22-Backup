# chunk items

import logging
from typing import Any

from app.config import settings

logger = logging.getLogger(__name__)

class TextChunker:
    """Deterministic text chunking service for Workspace items."""

    def __init__(self, chunk_size: int = None, chunk_overlap: int = None):
        self.chunk_size = chunk_size or settings.CHUNK_SIZE
        self.chunk_overlap = chunk_overlap or settings.CHUNK_OVERLAP

    def _split_text(self, text: str) -> list[str]:
        """Split raw text into sliding window chunks based on chunk_size and chunk_overlap."""
        if not text:
            return []

        text = text.strip()
        if len(text) <= self.chunk_size:
            return [text]

        chunks = []
        start = 0
        text_len = len(text)

        while start < text_len:
            end = min(start + self.chunk_size, text_len)
            
            # If not at the very end, try to break cleanly at paragraph or sentence boundary
            if end < text_len:
                last_newline = text.rfind("\n", start + int(self.chunk_size * 0.5), end)
                if last_newline != -1:
                    end = last_newline + 1
                else:
                    last_space = text.rfind(" ", start + int(self.chunk_size * 0.5), end)
                    if last_space != -1:
                        end = last_space + 1

            chunk_content = text[start:end].strip()
            if chunk_content:
                chunks.append(chunk_content)

            if end >= text_len:
                break

            # Move start forward with overlap
            advance = max(1, (end - start) - self.chunk_overlap)
            start += advance

        return chunks

    def chunk_item(self, item: dict[str, Any]) -> list[dict[str, Any]]:
        """Chunk a normalized Workspace item based on service and content.

        Args:
            item: Normalized item dictionary containing service, title, content, metadata.

        Returns:
            List of dicts with 'chunk_index' and 'content'.
        """
        service = item.get("service")
        title = item.get("title") or ""
        content = item.get("content") or ""
        meta = item.get("metadata") or {}

        # 1. Gmail Email
        if service == "gmail":
            headers_prefix = (
                f"Subject: {title}\n"
                f"From: {meta.get('sender', '')}\n"
                f"To: {meta.get('recipients', '')}\n"
                f"Date: {meta.get('received_at', '')}\n\n"
            )
            full_text = headers_prefix + content
            raw_chunks = self._split_text(full_text)

        # 2. Calendar Event
        elif service == "calendar":
            attendees_str = ", ".join(meta.get("attendees", [])) if meta.get("attendees") else "None"
            event_text = (
                f"Title: {title}\n"
                f"Start: {meta.get('start', '')}\n"
                f"End: {meta.get('end', '')}\n"
                f"Location: {meta.get('location', '') or 'None'}\n"
                f"Attendees: {attendees_str}\n"
                f"Status: {meta.get('status', '')}\n\n"
                f"Description:\n{content}"
            )
            raw_chunks = [event_text.strip()]

        # 3. Drive File & Default
        else:
            doc_prefix = f"Document: {title}\nMIME Type: {meta.get('mime_type', '')}\n\n"
            full_text = doc_prefix + content
            raw_chunks = self._split_text(full_text)

        return [
            {"chunk_index": idx, "content": chunk_text}
            for idx, chunk_text in enumerate(raw_chunks)
        ]

text_chunker = TextChunker()