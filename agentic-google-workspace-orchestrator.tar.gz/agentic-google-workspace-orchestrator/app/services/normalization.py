# file converts all of them into the same WorkspaceItem structure so the rest of your 
# system can process them uniformly.

from datetime import datetime, timezone
import logging
from typing import Any, Optional
from dateutil import parser as date_parser

logger = logging.getLogger(__name__)


def parse_datetime_safe(dt_val: Any) -> Optional[datetime]:
    """Parse string or timestamp into timezone-aware datetime."""
    if not dt_val:
        return None
    if isinstance(dt_val, datetime):
        return dt_val if dt_val.tzinfo else dt_val.replace(tzinfo=timezone.utc)
    try:
        if isinstance(dt_val, (int, float)):
            # Epoch milliseconds or seconds
            if dt_val > 1e11:  # milliseconds
                return datetime.fromtimestamp(dt_val / 1000.0, tz=timezone.utc)
            return datetime.fromtimestamp(dt_val, tz=timezone.utc)

        parsed = date_parser.parse(str(dt_val))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except Exception as e:
        logger.warning(f"Failed to parse datetime value '{dt_val}': {e}")
        return None


def normalize_gmail_message(raw_msg: dict[str, Any], user_id: Any) -> dict[str, Any]:
    """Normalize Gmail message dictionary for workspace_items table."""
    subject = raw_msg.get("subject") or "(No Subject)"
    body = raw_msg.get("body") or ""
    sender = raw_msg.get("sender") or ""
    recipients = raw_msg.get("recipients") or ""
    date_str = raw_msg.get("received_at")
    internal_date = raw_msg.get("internal_date")

    parsed_date = parse_datetime_safe(date_str) or parse_datetime_safe(internal_date)

    metadata = {
        "thread_id": raw_msg.get("thread_id"),
        "sender": sender,
        "recipients": recipients,
        "received_at": date_str,
        "labels": raw_msg.get("labels", []),
    }

    return {
        "user_id": user_id,
        "service": "gmail",
        "item_type": "email",
        "external_id": raw_msg["external_id"],
        "title": subject,
        "content": body,
        "metadata": metadata,
        "source_created_at": parsed_date,
        "source_updated_at": parsed_date,
    }


def normalize_calendar_event(raw_event: dict[str, Any], user_id: Any) -> dict[str, Any]:
    """Normalize Google Calendar event dictionary for workspace_items table."""
    summary = raw_event.get("summary") or "(No Title)"
    description = raw_event.get("description") or ""

    start_dt = parse_datetime_safe(raw_event.get("start"))
    end_dt = parse_datetime_safe(raw_event.get("end"))
    created_dt = parse_datetime_safe(raw_event.get("source_created_at"))
    updated_dt = parse_datetime_safe(raw_event.get("source_updated_at")) or start_dt

    metadata = {
        "start": raw_event.get("start"),
        "end": raw_event.get("end"),
        "timezone": raw_event.get("timezone", "UTC"),
        "attendees": raw_event.get("attendees", []),
        "organizer": raw_event.get("organizer"),
        "location": raw_event.get("location"),
        "status": raw_event.get("status"),
        "html_link": raw_event.get("html_link"),
    }

    # Format structured content string if description is sparse
    content_parts = []
    if description:
        content_parts.append(description)
    if raw_event.get("location"):
        content_parts.append(f"Location: {raw_event['location']}")
    if raw_event.get("attendees"):
        content_parts.append(f"Attendees: {', '.join(raw_event['attendees'])}")

    content = "\n".join(content_parts) if content_parts else summary

    return {
        "user_id": user_id,
        "service": "calendar",
        "item_type": "calendar_event",
        "external_id": raw_event["external_id"],
        "title": summary,
        "content": content,
        "metadata": metadata,
        "source_created_at": created_dt or start_dt,
        "source_updated_at": updated_dt or start_dt,
    }


def normalize_drive_file(raw_file: dict[str, Any], user_id: Any) -> dict[str, Any]:
    """Normalize Google Drive file dictionary for workspace_items table."""
    name = raw_file.get("name") or "(Unnamed File)"
    content = raw_file.get("content") or ""
    created_dt = parse_datetime_safe(raw_file.get("created_time"))
    updated_dt = parse_datetime_safe(raw_file.get("modified_time"))

    metadata = {
        "mime_type": raw_file.get("mime_type"),
        "owners": raw_file.get("owners", []),
        "size": raw_file.get("size"),
        "web_view_link": raw_file.get("web_view_link"),
        "created_time": raw_file.get("created_time"),
        "modified_time": raw_file.get("modified_time"),
    }

    return {
        "user_id": user_id,
        "service": "drive",
        "item_type": "drive_file",
        "external_id": raw_file["external_id"],
        "title": name,
        "content": content if content else f"Filename: {name}\nMIME Type: {raw_file.get('mime_type')}",
        "metadata": metadata,
        "source_created_at": created_dt,
        "source_updated_at": updated_dt,
    }
