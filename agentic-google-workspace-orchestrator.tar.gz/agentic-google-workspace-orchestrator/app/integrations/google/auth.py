# it handles getting and maintaining the Google access token that those Gmail/Drive/Calendar integrations need. 

from datetime import datetime, timezone, timedelta
import logging
import urllib.parse
from typing import Optional
import httpx
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.models import GoogleAccount

logger = logging.getLogger(__name__)

# Centrally defined Google OAuth Scopes for all eventual assignment features
GOOGLE_SCOPES = [
    "openid",

    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",

    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.compose",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/gmail.labels",

    "https://www.googleapis.com/auth/calendar.readonly",
    "https://www.googleapis.com/auth/calendar.events",

    "https://www.googleapis.com/auth/drive",
]

AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo"


class GoogleAuthError(Exception):
    """Exception raised for Google OAuth errors."""

    pass


def get_google_auth_url(state: str) -> str:
    """Generate Google OAuth authorization URL."""
    if not settings.GOOGLE_CLIENT_ID:
        raise GoogleAuthError("GOOGLE_CLIENT_ID is not configured.")

    params = {
        "client_id": settings.GOOGLE_CLIENT_ID,
        "redirect_uri": settings.GOOGLE_REDIRECT_URI,
        "response_type": "code",
        "scope": " ".join(GOOGLE_SCOPES),
        "access_type": "offline",
        "prompt": "consent",
        "state": state,
    }
    return f"{AUTH_URL}?{urllib.parse.urlencode(params)}"


async def exchange_code_for_tokens(code: str) -> dict:
    """Exchange authorization code for access and refresh tokens."""
    if not settings.GOOGLE_CLIENT_ID or not settings.GOOGLE_CLIENT_SECRET:
        raise GoogleAuthError("Google OAuth credentials are not fully configured.")

    payload = {
        "code": code,
        "client_id": settings.GOOGLE_CLIENT_ID,
        "client_secret": settings.GOOGLE_CLIENT_SECRET,
        "redirect_uri": settings.GOOGLE_REDIRECT_URI,
        "grant_type": "authorization_code",
    }

    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.post(TOKEN_URL, data=payload)

    if response.status_code != 200:
        raise GoogleAuthError(f"Token exchange failed (HTTP {response.status_code}): {response.text}")

    return response.json()


async def get_google_user_info(access_token: str) -> dict:
    """Retrieve Google user profile details."""
    headers = {"Authorization": f"Bearer {access_token}"}
    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.get(USERINFO_URL, headers=headers)

    if response.status_code != 200:
        raise GoogleAuthError(f"Failed to fetch user info (HTTP {response.status_code}): {response.text}")

    return response.json()


async def refresh_access_token(refresh_token: str) -> dict:
    """Refresh an expired access token using the stored refresh token."""
    if not settings.GOOGLE_CLIENT_ID or not settings.GOOGLE_CLIENT_SECRET:
        raise GoogleAuthError("Google OAuth credentials are not configured for token refresh.")

    payload = {
        "client_id": settings.GOOGLE_CLIENT_ID,
        "client_secret": settings.GOOGLE_CLIENT_SECRET,
        "refresh_token": refresh_token,
        "grant_type": "refresh_token",
    }

    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.post(TOKEN_URL, data=payload)

    if response.status_code != 200:
        raise GoogleAuthError(f"Failed to refresh access token (HTTP {response.status_code}): {response.text}")

    return response.json()


async def get_valid_access_token(db: AsyncSession, google_account: GoogleAccount) -> str:
    """Return valid access token, automatically refreshing and persisting if expired."""
    now = datetime.now(timezone.utc)

    # Check if current token expires within 60 seconds
    if google_account.token_expires_at and (google_account.token_expires_at - now).total_seconds() > 60:
        return google_account.access_token

    logger.info(f"Access token for Google account {google_account.email} expired or expiring soon. Refreshing...")
    token_data = await refresh_access_token(google_account.refresh_token)

    new_access_token = token_data["access_token"]
    expires_in = token_data.get("expires_in", 3600)
    new_expires_at = now + timedelta(seconds=expires_in)

    google_account.access_token = new_access_token
    google_account.token_expires_at = new_expires_at

    # Do not overwrite stored refresh token if Google does not return a new one
    if "refresh_token" in token_data and token_data["refresh_token"]:
        google_account.refresh_token = token_data["refresh_token"]

    await db.commit()
    await db.refresh(google_account)

    return new_access_token
