import logging
import time
from typing import Any, Optional
import httpx

from app.integrations.google.exceptions import GoogleValidationError, raise_for_google_status

logger = logging.getLogger(__name__)

DRIVE_BASE_URL = "https://www.googleapis.com/drive/v3/files"


class DriveClient:
    """Client for Google Drive REST API operations."""

    async def _fetch_file_content(
        self, access_token: str, file_id: str, mime_type: str
    ) -> str:
        """Fetch or export textual content of a file."""
        headers = {"Authorization": f"Bearer {access_token}"}

        async with httpx.AsyncClient(timeout=15.0) as client:
            if mime_type == "application/vnd.google-apps.document":
                resp = await client.get(
                    f"{DRIVE_BASE_URL}/{file_id}/export",
                    headers=headers,
                    params={"mimeType": "text/plain"},
                )
                if resp.status_code == 200:
                    return resp.text
                logger.warning(f"Failed to export Google Doc {file_id}: {resp.status_code}")
                return ""

            if mime_type.startswith("text/") or mime_type in (
                "application/json",
                "application/x-sh",
                "application/javascript",
            ):
                resp = await client.get(
                    f"{DRIVE_BASE_URL}/{file_id}",
                    headers=headers,
                    params={"alt": "media"},
                )
                if resp.status_code == 200:
                    return resp.text
                logger.warning(f"Failed to download text file {file_id}: {resp.status_code}")
                return ""

        return ""

    async def fetch_recent_files(
        self, access_token: str, max_results: int = 50
    ) -> list[dict[str, Any]]:
        """Fetch list of files and content from Google Drive."""
        headers = {"Authorization": f"Bearer {access_token}"}
        params = {
            "pageSize": max_results,
            "fields": "files(id, name, mimeType, owners, createdTime, modifiedTime, webViewLink, size)",
            "q": "trashed = false",
        }

        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(DRIVE_BASE_URL, headers=headers, params=params)

        if resp.status_code != 200:
            logger.error(f"Google Drive API list failed (HTTP {resp.status_code}): {resp.text}")
            return []

        data = resp.json()
        files = data.get("files", [])
        results = []

        for f in files:
            file_id = f.get("id")
            mime_type = f.get("mimeType", "")
            name = f.get("name") or "(Unnamed File)"

            owners = [o.get("emailAddress") for o in f.get("owners", []) if o.get("emailAddress")]
            content = await self._fetch_file_content(access_token, file_id, mime_type)

            results.append({
                "external_id": file_id,
                "name": name,
                "mime_type": mime_type,
                "content": content,
                "owners": owners,
                "created_time": f.get("createdTime"),
                "modified_time": f.get("modifiedTime"),
                "web_view_link": f.get("webViewLink"),
                "size": f.get("size"),
            })

        return results

    async def create_folder(
        self, access_token: str, folder_name: str, parent_id: Optional[str] = None
    ) -> dict[str, Any]:
        """Create a folder in Google Drive."""
        if not folder_name or not str(folder_name).strip():
            raise GoogleValidationError("Folder name is required for drive.create_folder", status_code=400)

        headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
        payload: dict[str, Any] = {
            "name": folder_name.strip(),
            "mimeType": "application/vnd.google-apps.folder",
        }
        if parent_id and str(parent_id).strip():
            payload["parents"] = [str(parent_id).strip()]

        t0 = time.perf_counter()
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(DRIVE_BASE_URL, headers=headers, json=payload)
        duration_ms = (time.perf_counter() - t0) * 1000.0

        logger.info(f"Google Drive create_folder response | status={resp.status_code} | duration={duration_ms:.1f}ms")

        raise_for_google_status(resp, "drive.create_folder")
        return resp.json()

    async def share_file(
        self, access_token: str, file_id: str, email: str, role: str = "reader"
    ) -> dict[str, Any]:
        """Share a file with an email address."""
        if not file_id or not str(file_id).strip():
            raise GoogleValidationError("File ID is required for drive.share_file", status_code=400)
        if not email or "@" not in str(email):
            raise GoogleValidationError(f"Invalid email address '{email}' for drive.share_file", status_code=400)

        headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
        payload = {"role": role, "type": "user", "emailAddress": email.strip()}

        t0 = time.perf_counter()
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                f"{DRIVE_BASE_URL}/{file_id}/permissions", headers=headers, json=payload
            )
        duration_ms = (time.perf_counter() - t0) * 1000.0

        logger.info(f"Google Drive share_file response | status={resp.status_code} | duration={duration_ms:.1f}ms")

        raise_for_google_status(resp, "drive.share_file")
        return resp.json()

    async def move_file(
        self, access_token: str, file_id: str, destination_folder_id: str
    ) -> dict[str, Any]:
        """Move a file to a new folder in Google Drive."""
        if not file_id or not str(file_id).strip():
            raise GoogleValidationError("File ID is required for drive.move_file", status_code=400)
        if not destination_folder_id or not str(destination_folder_id).strip():
            raise GoogleValidationError("Destination folder ID is required for drive.move_file", status_code=400)

        headers = {"Authorization": f"Bearer {access_token}"}
        params = {"addParents": destination_folder_id.strip(), "enforceSingleParent": "true"}

        t0 = time.perf_counter()
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.patch(
                f"{DRIVE_BASE_URL}/{file_id}", headers=headers, params=params
            )
        duration_ms = (time.perf_counter() - t0) * 1000.0

        logger.info(f"Google Drive move_file response | Do it for advance queriesstatus={resp.status_code} | duration={duration_ms:.1f}ms")

        raise_for_google_status(resp, "drive.move_file")
        return resp.json()


drive_client = DriveClient()
