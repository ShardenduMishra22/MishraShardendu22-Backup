import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Optional
from zoneinfo import ZoneInfo
from dateutil import parser as date_parser

logger = logging.getLogger(__name__)

DEFAULT_APP_TIMEZONE = "Asia/Kolkata"


def resolve_timezone(tz_input: Optional[str] = None, fallback_tz: Optional[str] = None) -> str:
    """Resolve IANA timezone string following priority order:
    1. Direct tool input parameter / user setting
    2. Fallback context / app timezone
    3. Default APP_TIMEZONE / UTC fallback
    """
    for candidate in [tz_input, fallback_tz, DEFAULT_APP_TIMEZONE, "UTC"]:
        if candidate and isinstance(candidate, str) and candidate.strip():
            candidate_clean = candidate.strip()
            try:
                ZoneInfo(candidate_clean)
                return candidate_clean
            except Exception:
                continue
    return "UTC"


def normalize_datetime_string(
    dt_val: Any,
    tz_name: str = DEFAULT_APP_TIMEZONE,
) -> tuple[datetime, str]:
    """Parse datetime input and convert to timezone-aware datetime object and ISO 8601 string.
    If datetime is naive, attaches the target timezone.
    """
    tz_obj = ZoneInfo(resolve_timezone(tz_name))

    if isinstance(dt_val, datetime):
        dt = dt_val
    elif isinstance(dt_val, str) and dt_val.strip():
        try:
            dt = date_parser.parse(dt_val.strip())
        except Exception as e:
            raise ValueError(f"Invalid datetime string '{dt_val}': {e}")
    else:
        raise ValueError("Datetime value cannot be empty")

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=tz_obj)
    else:
        dt = dt.astimezone(tz_obj)

    return dt, dt.isoformat()


def build_calendar_event_payload(
    summary: str,
    start_time: Any,
    end_time: Optional[Any] = None,
    description: Optional[str] = None,
    location: Optional[str] = None,
    attendees: Optional[list[str]] = None,
    timezone_str: Optional[str] = None,
) -> tuple[dict[str, Any], str]:
    """Construct and validate Google Calendar event payload with mandatory timezone definitions
    and default 1-hour duration for start/end times.
    """
    if not summary or not str(summary).strip():
        raise ValueError("Calendar event summary/title is required.")

    tz_name = resolve_timezone(timezone_str)
    start_dt, start_iso = normalize_datetime_string(start_time, tz_name)

    if not end_time or str(end_time).strip() == "" or end_time == start_time:
        end_dt = start_dt + timedelta(hours=1)
        _, end_iso = normalize_datetime_string(end_dt, tz_name)
    else:
        end_dt, end_iso = normalize_datetime_string(end_time, tz_name)

    if end_dt <= start_dt:
        end_dt = start_dt + timedelta(hours=1)
        _, end_iso = normalize_datetime_string(end_dt, tz_name)

    payload: dict[str, Any] = {
        "summary": summary.strip(),
        "start": {
            "dateTime": start_iso,
            "timeZone": tz_name,
        },
        "end": {
            "dateTime": end_iso,
            "timeZone": tz_name,
        },
    }

    if description and str(description).strip():
        payload["description"] = str(description).strip()
    if location and str(location).strip():
        payload["location"] = str(location).strip()
    if attendees:
        clean_attendees = [a.strip() for a in attendees if a and "@" in str(a)]
        if clean_attendees:
            payload["attendees"] = [{"email": a} for a in clean_attendees]

    return payload, tz_name


def sanitize_payload_for_logging(payload: Any) -> Any:
    """Sanitize request payload to ensure OAuth tokens or secrets are never logged."""
    if isinstance(payload, dict):
        sanitized = {}
        for k, v in payload.items():
            if k.lower() in ("access_token", "refresh_token", "authorization", "secret", "client_secret", "bearer"):
                sanitized[k] = "[REDACTED]"
            else:
                sanitized[k] = sanitize_payload_for_logging(v)
        return sanitized
    elif isinstance(payload, list):
        return [sanitize_payload_for_logging(item) for item in payload]
    return payload
