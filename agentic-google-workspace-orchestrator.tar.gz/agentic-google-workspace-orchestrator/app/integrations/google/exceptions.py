import logging
from typing import Any, Optional
import httpx

logger = logging.getLogger(__name__)


class GoogleAPIError(Exception):
    """Base exception for Google Workspace API failures."""
    error_type: str = "google_api_error"
    status_code: int = 500

    def __init__(self, message: str, status_code: int = 500, details: Optional[dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details or {}


class GoogleValidationError(GoogleAPIError):
    """Raised when Google API rejects request payload due to validation rules (HTTP 400)."""
    error_type: str = "google_validation_error"
    status_code: int = 400


class GoogleAuthError(GoogleAPIError):
    """Raised when Google authentication fails or token is invalid (HTTP 401)."""
    error_type: str = "google_auth_error"
    status_code: int = 401


class GooglePermissionError(GoogleAPIError):
    """Raised when access is forbidden or permissions are missing (HTTP 403)."""
    error_type: str = "google_permission_error"
    status_code: int = 403


class GoogleNotFoundError(GoogleAPIError):
    """Raised when target resource is not found in Google Workspace (HTTP 404)."""
    error_type: str = "google_not_found_error"
    status_code: int = 404


class GoogleRateLimitError(GoogleAPIError):
    """Raised when Google API quota or rate limit is exceeded (HTTP 429)."""
    error_type: str = "google_rate_limit_error"
    status_code: int = 429


class GoogleServerError(GoogleAPIError):
    """Raised when Google API server encounters internal error (HTTP 5xx)."""
    error_type: str = "google_server_error"
    status_code: int = 502


def raise_for_google_status(resp: httpx.Response, tool_name: str) -> None:
    """Inspect HTTP status code and raise appropriate structured GoogleAPIError subclass."""
    if resp.is_success:
        return

    details: dict[str, Any] = {}
    error_message = f"Google API error ({resp.status_code})"

    try:
        data = resp.json()
        if isinstance(data, dict) and "error" in data:
            err_obj = data["error"]
            if isinstance(err_obj, dict):
                error_message = err_obj.get("message") or error_message
                details = err_obj
            elif isinstance(err_obj, str):
                error_message = err_obj
        elif isinstance(data, dict):
            details = data
    except Exception:
        error_message = resp.text or error_message

    log_msg = f"Google API Call Failed [{tool_name}] | Status: {resp.status_code} | Error: {error_message}"
    logger.error(log_msg)

    if resp.status_code == 400:
        raise GoogleValidationError(
            f"Google validation error in {tool_name}: {error_message}",
            status_code=400,
            details=details,
        )
    elif resp.status_code == 401:
        raise GoogleAuthError(
            f"Google authentication error in {tool_name}: {error_message}",
            status_code=401,
            details=details,
        )
    elif resp.status_code == 403:
        raise GooglePermissionError(
            f"Google permission error in {tool_name}: {error_message}",
            status_code=403,
            details=details,
        )
    elif resp.status_code == 404:
        raise GoogleNotFoundError(
            f"Google resource not found in {tool_name}: {error_message}",
            status_code=404,
            details=details,
        )
    elif resp.status_code == 429:
        raise GoogleRateLimitError(
            f"Google rate limit exceeded in {tool_name}: {error_message}",
            status_code=429,
            details=details,
        )
    elif resp.status_code >= 500:
        raise GoogleServerError(
            f"Google server error in {tool_name}: {error_message}",
            status_code=502,
            details=details,
        )
    else:
        raise GoogleAPIError(
            f"Google API request failed in {tool_name}: {error_message}",
            status_code=resp.status_code,
            details=details,
        )
