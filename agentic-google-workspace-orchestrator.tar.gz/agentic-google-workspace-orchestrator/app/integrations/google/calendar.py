# client for Google Calendar REST API operations

import logging
import time
from typing import Any, Optional
import httpx

from app.integrations.google.exceptions import raise_for_google_status
from app.integrations.google.utils import (
    build_calendar_event_payload,
    resolve_timezone,
    sanitize_payload_for_logging,
)

logger = logging.getLogger(__name__)

CALENDAR_BASE_URL = "https://www.googleapis.com/calendar/v3/calendars/primary"


class CalendarClient:
    """Client for Google Calendar REST API operations."""

    async def fetch_recent_events(
        self, access_token: str, max_results: int = 100
    ) -> list[dict[str, Any]]:
        """Fetch primary calendar events."""
        headers = {"Authorization": f"Bearer {access_token}"}
        params = {
            "maxResults": max_results,
            "singleEvents": "true",
            "orderBy": "startTime",
        }

        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(f"{CALENDAR_BASE_URL}/events", headers=headers, params=params)

        if resp.status_code != 200:
            logger.error(f"Google Calendar API fetch failed (HTTP {resp.status_code}): {resp.text}")
            return []

        data = resp.json()
        items = data.get("items", [])
        events = []

        for item in items:
            start_data = item.get("start", {})
            end_data = item.get("end", {})

            start_time = start_data.get("dateTime") or start_data.get("date")
            end_time = end_data.get("dateTime") or end_data.get("date")
            tz = start_data.get("timeZone") or data.get("timeZone") or "UTC"

            attendees = [
                a.get("email") for a in item.get("attendees", []) if a.get("email")
            ]
            organizer = item.get("organizer", {}).get("email")

            events.append({
                "external_id": item.get("id"),
                "summary": item.get("summary") or "(No Title)",
                "description": item.get("description") or "",
                "start": start_time,
                "end": end_time,
                "timezone": tz,
                "attendees": attendees,
                "organizer": organizer,
                "location": item.get("location") or "",
                "status": item.get("status") or "confirmed",
                "html_link": item.get("htmlLink"),
                "source_updated_at": item.get("updated"),
                "source_created_at": item.get("created"),
            })

        return events

    async def create_event(
        self,
        access_token: str,
        summary: str,
        start_time: Any,
        end_time: Optional[Any] = None,
        description: Optional[str] = None,
        location: Optional[str] = None,
        attendees: Optional[list[str]] = None,
        timezone_str: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new event in Google Calendar with mandatory timeZone definition and normalized start/end times."""
        payload, resolved_tz = build_calendar_event_payload(
            summary=summary,
            start_time=start_time,
            end_time=end_time,
            description=description,
            location=location,
            attendees=attendees,
            timezone_str=timezone_str,
        )

        headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
        sanitized_log_payload = sanitize_payload_for_logging(payload)

        logger.info(
            f"Sending Google Calendar create_event payload: {sanitized_log_payload} | timezone={resolved_tz}"
        )

        t0 = time.perf_counter()
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(f"{CALENDAR_BASE_URL}/events", headers=headers, json=payload)
        duration_ms = (time.perf_counter() - t0) * 1000.0

        logger.info(
            f"Google Calendar create_event response | status={resp.status_code} | duration={duration_ms:.1f}ms"
        )

        raise_for_google_status(resp, "calendar.create_event")
        return resp.json()

    async def update_event(
        self,
        access_token: str,
        event_id: str,
        summary: Optional[str] = None,
        start_time: Optional[Any] = None,
        end_time: Optional[Any] = None,
        timezone_str: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update an existing event in Google Calendar."""
        if not event_id or not str(event_id).strip():
            from app.integrations.google.exceptions import GoogleValidationError
            raise GoogleValidationError("Event ID is required for calendar.update_event", status_code=400)

        headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
        tz_name = resolve_timezone(timezone_str)
        payload: dict[str, Any] = {}

        if summary and str(summary).strip():
            payload["summary"] = str(summary).strip()

        if start_time:
            from app.integrations.google.utils import normalize_datetime_string
            _, start_iso = normalize_datetime_string(start_time, tz_name)
            payload["start"] = {"dateTime": start_iso, "timeZone": tz_name}

        if end_time:
            from app.integrations.google.utils import normalize_datetime_string
            _, end_iso = normalize_datetime_string(end_time, tz_name)
            payload["end"] = {"dateTime": end_iso, "timeZone": tz_name}

        if not payload:
            from app.integrations.google.exceptions import GoogleValidationError
            raise GoogleValidationError("At least one attribute (summary, start_time, end_time) must be provided for update.", status_code=400)

        t0 = time.perf_counter()
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.patch(f"{CALENDAR_BASE_URL}/events/{event_id}", headers=headers, json=payload)
        duration_ms = (time.perf_counter() - t0) * 1000.0

        logger.info(f"Google Calendar update_event response | status={resp.status_code} | duration={duration_ms:.1f}ms")

        raise_for_google_status(resp, "calendar.update_event")
        return resp.json()

    async def delete_event(self, access_token: str, event_id: str) -> bool:
        """Delete an event from Google Calendar."""
        if not event_id or not str(event_id).strip():
            from app.integrations.google.exceptions import GoogleValidationError
            raise GoogleValidationError("Event ID is required for calendar.delete_event", status_code=400)

        headers = {"Authorization": f"Bearer {access_token}"}
        t0 = time.perf_counter()
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.delete(f"{CALENDAR_BASE_URL}/events/{event_id}", headers=headers)
        duration_ms = (time.perf_counter() - t0) * 1000.0

        logger.info(f"Google Calendar delete_event response | status={resp.status_code} | duration={duration_ms:.1f}ms")

        raise_for_google_status(resp, "calendar.delete_event")
        return True


calendar_client = CalendarClient()
