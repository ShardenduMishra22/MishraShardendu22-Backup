import base64
import logging
import time
from typing import Any, Optional
import httpx

from app.integrations.google.exceptions import GoogleValidationError, raise_for_google_status

logger = logging.getLogger(__name__)

GMAIL_BASE_URL = "https://gmail.googleapis.com/gmail/v1/users/me"


class GmailClient:
    """Client for Gmail REST API operations."""

    def _extract_header(self, headers: list[dict[str, str]], name: str) -> Optional[str]:
        for h in headers:
            if h.get("name", "").lower() == name.lower():
                return h.get("value")
        return None

    def _decode_body_data(self, data: str) -> str:
        try:
            decoded_bytes = base64.urlsafe_b64encode(data.encode("utf-8"))
            return decoded_bytes.decode("utf-8", errors="replace")
        except Exception:
            return ""

    def _extract_message_body(self, payload: dict[str, Any]) -> str:
        """Recursively extract plain text or HTML body from message payload."""
        if not payload:
            return ""

        body_data = payload.get("body", {}).get("data")
        mime_type = payload.get("mimeType", "")

        if body_data and mime_type.startswith("text/plain"):
            return self._decode_body_data(body_data)

        parts = payload.get("parts", [])
        plain_text = ""
        html_text = ""

        for part in parts:
            part_mime = part.get("mimeType", "")
            part_body = part.get("body", {}).get("data")
            if part_mime == "text/plain" and part_body:
                plain_text += self._decode_body_data(part_body) + "\n"
            elif part_mime == "text/html" and part_body:
                html_text += self._decode_body_data(part_body) + "\n"
            elif "parts" in part:
                sub_body = self._extract_message_body(part)
                if sub_body:
                    plain_text += sub_body + "\n"

        if plain_text.strip():
            return plain_text.strip()
        
        if html_text.strip():
            import re
            return re.sub(r"<[^>]+>", "", html_text).strip()

        if body_data:
            return self._decode_body_data(body_data)

        return ""

    async def list_messages(
        self, access_token: str, max_results: int = 50, page_token: Optional[str] = None
    ) -> dict[str, Any]:
        """Fetch list of message stubs."""
        headers = {"Authorization": f"Bearer {access_token}"}
        params: dict[str, Any] = {"maxResults": max_results}
        if page_token:
            params["pageToken"] = page_token

        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(f"{GMAIL_BASE_URL}/messages", headers=headers, params=params)

        if resp.status_code != 200:
            logger.error(f"Gmail list_messages failed (HTTP {resp.status_code}): {resp.text}")
            return {"messages": [], "nextPageToken": None}

        return resp.json()

    async def get_message_detail(self, access_token: str, message_id: str) -> Optional[dict[str, Any]]:
        """Fetch full details of a specific message."""
        headers = {"Authorization": f"Bearer {access_token}"}
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                f"{GMAIL_BASE_URL}/messages/{message_id}",
                headers=headers,
                params={"format": "full"},
            )

        if resp.status_code != 200:
            logger.error(f"Gmail get_message_detail failed for {message_id}: {resp.text}")
            return None

        msg_json = resp.json()
        payload = msg_json.get("payload", {})
        headers_list = payload.get("headers", [])

        subject = self._extract_header(headers_list, "Subject") or "(No Subject)"
        sender = self._extract_header(headers_list, "From") or ""
        recipients = self._extract_header(headers_list, "To") or ""
        date_str = self._extract_header(headers_list, "Date") or ""
        body_text = self._extract_message_body(payload)

        return {
            "external_id": msg_json.get("id"),
            "thread_id": msg_json.get("threadId"),
            "subject": subject,
            "sender": sender,
            "recipients": recipients,
            "received_at": date_str,
            "body": body_text,
            "labels": msg_json.get("labelIds", []),
            "internal_date": msg_json.get("internalDate"),
        }

    async def fetch_recent_emails(
        self, access_token: str, max_results: int = 50
    ) -> list[dict[str, Any]]:
        """Fetch details for the most recent emails."""
        list_res = await self.list_messages(access_token, max_results=max_results)
        msg_stubs = list_res.get("messages", [])
        if not msg_stubs:
            return []

        results = []
        for stub in msg_stubs:
            msg_id = stub.get("id")
            if msg_id:
                detail = await self.get_message_detail(access_token, msg_id)
                if detail:
                    results.append(detail)
        return results

    async def send_message(
        self, access_token: str, to: str, subject: str, body: str
    ) -> dict[str, Any]:
        """Send an email message using the Gmail REST API."""
        if not to or "@" not in str(to):
            raise GoogleValidationError(f"Invalid or missing recipient email address '{to}' for gmail.send_email", status_code=400)

        from email.message import EmailMessage

        msg = EmailMessage()
        msg["To"] = to.strip()
        msg["Subject"] = (subject or "(No Subject)").strip()
        msg.set_content(body or "")

        raw_bytes = msg.as_bytes()
        encoded_raw = base64.urlsafe_b64encode(raw_bytes).decode("utf-8")

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
        payload = {"raw": encoded_raw}

        t0 = time.perf_counter()
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(f"{GMAIL_BASE_URL}/messages/send", headers=headers, json=payload)
        duration_ms = (time.perf_counter() - t0) * 1000.0

        logger.info(f"Gmail send_message response | status={resp.status_code} | duration={duration_ms:.1f}ms | to={to}")

        raise_for_google_status(resp, "gmail.send_email")
        return resp.json()

    async def create_draft(
        self, access_token: str, to: str, subject: str, body: str
    ) -> dict[str, Any]:
        """Create a draft message using the Gmail REST API."""
        if not to or "@" not in str(to):
            raise GoogleValidationError(f"Invalid or missing recipient email address '{to}' for gmail.create_draft", status_code=400)

        from email.message import EmailMessage

        msg = EmailMessage()
        msg["To"] = to.strip()
        msg["Subject"] = (subject or "(No Subject)").strip()
        msg.set_content(body or "")

        raw_bytes = msg.as_bytes()
        encoded_raw = base64.urlsafe_b64encode(raw_bytes).decode("utf-8")

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
        payload = {"message": {"raw": encoded_raw}}

        t0 = time.perf_counter()
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(f"{GMAIL_BASE_URL}/drafts", headers=headers, json=payload)
        duration_ms = (time.perf_counter() - t0) * 1000.0

        logger.info(f"Gmail create_draft response | status={resp.status_code} | duration={duration_ms:.1f}ms | to={to}")

        raise_for_google_status(resp, "gmail.create_draft")
        return resp.json()


gmail_client = GmailClient()
