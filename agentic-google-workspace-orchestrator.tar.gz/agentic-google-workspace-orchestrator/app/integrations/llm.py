import logging
from typing import Any, Optional
import httpx

from app.config import settings
from app.integrations.gemini import GeminiError, GeminiRateLimitError, gemini_client

logger = logging.getLogger(__name__)


class LLMError(Exception):
    """Base exception for provider-agnostic LLM operations."""

    pass


class GroqError(LLMError):
    """Base exception for Groq API errors."""

    pass


class GroqRateLimitError(GroqError):
    """Raised when Groq API rate limit or quota is exhausted."""

    pass


class GroqClient:
    """Async client for Groq API operations using model openai/gpt-oss-120b."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        base_url: str = "https://api.groq.com/openai/v1",
    ):
        import os
        self.api_key = api_key or settings.GROQ_API_KEY or settings.GROQ or os.getenv("GROQ") or os.getenv("GROQ_API_KEY")
        self.model = model or getattr(settings, "GROQ_MODEL", "openai/gpt-oss-120b")
        self.base_url = base_url.rstrip("/")

    async def chat_completion(
        self,
        messages: list[dict[str, str]],
        *,
        model: Optional[str] = None,
        temperature: float = 0.0,
        max_tokens: int = 2048,
    ) -> str:
        """Execute chat completion call via Groq API (OpenAI-compatible REST API)."""
        import os
        api_key = self.api_key or settings.GROQ_API_KEY or settings.GROQ or os.getenv("GROQ") or os.getenv("GROQ_API_KEY")
        if not api_key:
            raise GroqError("GROQ_API_KEY or GROQ environment variable is not configured in environment or settings.")

        target_model = model or self.model
        url = f"{self.base_url}/chat/completions"

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        payload = {
            "model": target_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        async with httpx.AsyncClient(timeout=45.0) as client:
            response = await client.post(url, headers=headers, json=payload)

        if response.status_code == 429:
            raise GroqRateLimitError(f"Groq API rate limit / quota exhausted (HTTP 429): {response.text}")

        if response.status_code != 200:
            raise GroqError(f"Groq API returned HTTP {response.status_code}: {response.text}")

        data = response.json()
        choices = data.get("choices", [])
        if not choices:
            raise GroqError(f"Empty choices in Groq response: {data}")

        content = choices[0].get("message", {}).get("content", "")
        if not content:
            raise GroqError(f"Empty message content from Groq API: {data}")

        return content


class OpenRouterClient:
    """Async client for OpenRouter REST API operations."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        self.api_key = api_key or settings.OPENROUTER_API_KEY
        self.model = model or getattr(settings, "OPENROUTER_MODEL", "google/gemini-3.5-flash-lite")
        base = base_url or settings.OPENROUTER_BASE_URL
        self.base_url = base.rstrip("/")

    async def chat_completion(
        self,
        messages: list[dict[str, str]],
        *,
        model: Optional[str] = None,
        temperature: float = 0.0,
        max_tokens: int = 2048,
    ) -> str:
        """Execute chat completion call via OpenRouter REST API."""
        api_key = self.api_key or settings.OPENROUTER_API_KEY
        if not api_key:
            raise LLMError("OPENROUTER_API_KEY is not configured.")

        target_model = model or self.model
        url = f"{self.base_url}/chat/completions"

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        payload = {
            "model": target_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        async with httpx.AsyncClient(timeout=45.0) as client:
            response = await client.post(url, headers=headers, json=payload)

        if response.status_code != 200:
            raise LLMError(f"OpenRouter API returned HTTP {response.status_code}: {response.text}")

        data = response.json()
        choices = data.get("choices", [])
        if not choices:
            raise LLMError(f"Empty choices in OpenRouter response: {data}")

        content = choices[0].get("message", {}).get("content", "")
        if not content:
            raise LLMError(f"Empty message content from OpenRouter API: {data}")

        return content


groq_client = GroqClient()
openrouter_client = OpenRouterClient()


async def llm_chat_completion(
    messages: list[dict[str, str]],
    *,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    temperature: float = 0.0,
    max_tokens: int = 2048,
) -> str:
    """Provider-agnostic unified LLM router interface for Gemini, Groq, and OpenRouter."""
    selected_provider = (provider or getattr(settings, "DEFAULT_LLM_PROVIDER", "gemini")).lower().strip()

    if selected_provider in ("openrouter", "open_router"):
        try:
            logger.info("Dispatching LLM completion to OpenRouter...")
            return await openrouter_client.chat_completion(
                messages, model=model, temperature=temperature, max_tokens=max_tokens
            )
        except Exception as exc:
            logger.warning(f"OpenRouter LLM completion failed ({exc}). Falling back to Gemini.")
            return await gemini_client.chat_completion(
                messages, model=model, temperature=temperature, max_tokens=max_tokens
            )

    elif selected_provider in ("groq", "openai/gpt-oss-120b"):
        try:
            logger.info("Dispatching LLM completion to Groq (model: openai/gpt-oss-120b)...")
            return await groq_client.chat_completion(
                messages,
                model=model or "openai/gpt-oss-120b",
                temperature=temperature,
                max_tokens=max_tokens,
            )
        except Exception as exc:
            logger.warning(f"Groq LLM completion failed ({exc}). Falling back to Gemini.")
            return await gemini_client.chat_completion(
                messages, temperature=temperature, max_tokens=max_tokens
            )

    else:
        logger.info(f"Dispatching LLM completion to Gemini (model: {model or settings.GEMINI_MODEL})...")
        return await gemini_client.chat_completion(
            messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
        )
