# This file provides a client for interacting with the OpenRouter API for embedding generation, including error handling and retry logic.

import asyncio
import logging
from typing import Optional
import httpx

from app.config import settings

logger = logging.getLogger(__name__)


class OpenRouterError(Exception):
    """Base exception for OpenRouter API errors."""

    pass


class OpenRouterClient:
    """Minimal client for OpenRouter API embedding operations."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        embedding_model: Optional[str] = None,
    ):
        self.api_key = api_key or settings.OPENROUTER_API_KEY
        self.base_url = (base_url or settings.OPENROUTER_BASE_URL).rstrip("/")
        self.embedding_model = embedding_model or getattr(settings, "OPENROUTER_EMBEDDING_MODEL", settings.EMBEDDING_MODEL)

    async def embed_texts(self, texts: list[str]) -> list[list[float]]:
        """Generate text embeddings for a batch of strings using OpenRouter.

        Args:
            texts: List of strings to generate embeddings for.

        Returns:
            List of float vectors, each matching settings.EMBEDDING_DIMENSION (2048).

        Raises:
            OpenRouterError: On API failure, invalid configuration, or unexpected response format.
        """
        if not texts:
            return []

        # Filter out empty or whitespace-only strings with a fallback default space if all are empty
        clean_texts = [t.strip() if t.strip() else " " for t in texts]

        if not self.api_key:
            raise OpenRouterError("OPENROUTER_API_KEY is not configured.")

        url = f"{self.base_url}/embeddings"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.embedding_model,
            "input": clean_texts if len(clean_texts) > 1 else clean_texts[0],
        }

        max_retries = 2
        for attempt in range(max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    response = await client.post(url, headers=headers, json=payload)

                if response.status_code in (429, 500, 502, 503, 504) and attempt < max_retries:
                    logger.warning(
                        f"OpenRouter transient error {response.status_code}, retrying ({attempt + 1}/{max_retries})..."
                    )
                    await asyncio.sleep(1.0 * (attempt + 1))
                    continue

                if response.status_code != 200:
                    raise OpenRouterError(
                        f"OpenRouter API returned HTTP {response.status_code}: {response.text}"
                    )

                data = response.json()
                if "data" not in data or not isinstance(data["data"], list):
                    raise OpenRouterError(f"Malformed response from OpenRouter: {data}")

                # Sort response items by index to preserve order
                sorted_items = sorted(data["data"], key=lambda x: x.get("index", 0))
                embeddings = [item["embedding"] for item in sorted_items]

                if len(embeddings) != len(clean_texts):
                    raise OpenRouterError(
                        f"Expected {len(clean_texts)} embeddings, got {len(embeddings)}"
                    )

                # Validate dimension
                for idx, emb in enumerate(embeddings):
                    if not isinstance(emb, list) or len(emb) != settings.EMBEDDING_DIMENSION:
                        raise OpenRouterError(
                            f"Embedding at index {idx} dimension mismatch: expected {settings.EMBEDDING_DIMENSION}, got {len(emb) if isinstance(emb, list) else type(emb)}"
                        )

                return embeddings

            except httpx.RequestError as exc:
                if attempt < max_retries:
                    logger.warning(f"Network error calling OpenRouter: {exc}, retrying...")
                    await asyncio.sleep(1.0 * (attempt + 1))
                    continue
                raise OpenRouterError(f"Network error calling OpenRouter API: {exc}") from exc

        raise OpenRouterError("Max retries exceeded for OpenRouter API embeddings")

    async def embed_text(self, text: str) -> list[float]:
        """Generate embedding for a single text string."""
        results = await self.embed_texts([text])
        return results[0]


openrouter_client = OpenRouterClient()
