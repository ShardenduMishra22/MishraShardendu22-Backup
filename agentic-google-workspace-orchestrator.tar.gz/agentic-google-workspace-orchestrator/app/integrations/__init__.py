"""External service integrations package."""
