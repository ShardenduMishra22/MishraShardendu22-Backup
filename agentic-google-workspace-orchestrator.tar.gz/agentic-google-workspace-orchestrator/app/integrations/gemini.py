# gemini client for LLM-based intent classification and entity extraction

import asyncio
import logging
from typing import Any, Optional
import httpx

from app.config import settings

logger = logging.getLogger(__name__)


class GeminiError(Exception):
    """Base exception for Gemini API errors."""

    pass


class GeminiRateLimitError(GeminiError):
    """Raised when Gemini API rate limit or quota is exhausted."""

    pass


class GeminiClient:
    """Async client for Gemini REST API operations."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        base_url: str = "https://generativelanguage.googleapis.com/v1beta",
    ):
        self.api_key = settings.GEMINI_API_KEY if api_key is None else api_key
        self.model = model or settings.GEMINI_MODEL
        self.base_url = base_url.rstrip("/")

    async def chat_completion(
        self,
        messages: list[dict[str, str]],
        system_instruction: Optional[str] = None,
        *,
        model: Optional[str] = None,
        temperature: float = 0.0,
        max_tokens: int = 1500,
    ) -> str:
        """Execute text generation/chat completion call via Gemini REST API.

        Args:
            messages: List of message dictionaries (role: 'user'|'assistant'|'system', content: str).
            system_instruction: Optional system instruction prompt.
            model: Optional model override (defaults to settings.GEMINI_MODEL).
            temperature: Sampling temperature.
            max_tokens: Maximum tokens in response.

        Returns:
            String text response from Gemini model.

        Raises:
            GeminiRateLimitError: On HTTP 429 rate limit.
            GeminiError: On API failure or malformed response.
        """
        if not self.api_key:
            raise GeminiError("GEMINI_API_KEY is not configured.")

        target_model = model or self.model
        url = f"{self.base_url}/models/{target_model}:generateContent?key={self.api_key}"

        # Convert standard role-based messages to Gemini contents format
        contents = []
        extracted_sys_instruction = system_instruction

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                if extracted_sys_instruction:
                    extracted_sys_instruction += f"\n\n{content}"
                else:
                    extracted_sys_instruction = content
            else:
                gemini_role = "model" if role in ("assistant", "model") else "user"
                contents.append({
                    "role": gemini_role,
                    "parts": [{"text": content}]
                })

        if not contents and extracted_sys_instruction:
            contents.append({
                "role": "user",
                "parts": [{"text": extracted_sys_instruction}]
            })
            extracted_sys_instruction = None

        payload: dict[str, Any] = {
            "contents": contents,
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            }
        }

        if extracted_sys_instruction:
            payload["systemInstruction"] = {
                "parts": [{"text": extracted_sys_instruction}]
            }

        headers = {"Content-Type": "application/json"}

        max_retries = 2
        for attempt in range(max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=45.0) as client:
                    response = await client.post(url, headers=headers, json=payload)

                if response.status_code == 429:
                    txt = response.text
                    raise GeminiRateLimitError(f"Gemini API rate limit / quota exhausted (HTTP 429): {txt}")

                if response.status_code in (500, 502, 503, 504) and attempt < max_retries:
                    logger.warning(
                        f"Gemini API transient error {response.status_code}, retrying ({attempt + 1}/{max_retries})..."
                    )
                    await asyncio.sleep(1.5 * (attempt + 1))
                    continue

                if response.status_code != 200:
                    raise GeminiError(
                        f"Gemini API returned HTTP {response.status_code}: {response.text}"
                    )

                data = response.json()
                candidates = data.get("candidates", [])
                if not candidates or not isinstance(candidates, list):
                    raise GeminiError(f"Malformed Gemini API response (no candidates): {data}")

                parts = candidates[0].get("content", {}).get("parts", [])
                if not parts or not isinstance(parts, list):
                    raise GeminiError(f"Empty or malformed parts in Gemini response candidate: {data}")

                text_response = parts[0].get("text", "")
                if not text_response:
                    raise GeminiError("Empty text returned from Gemini API.")

                return text_response

            except httpx.RequestError as exc:
                if attempt < max_retries:
                    logger.warning(f"Network error calling Gemini API: {exc}, retrying...")
                    await asyncio.sleep(1.5 * (attempt + 1))
                    continue
                raise GeminiError(f"Network error calling Gemini API: {exc}") from exc

        raise GeminiError("Max retries exceeded for Gemini API chat completion")


gemini_client = GeminiClient()
