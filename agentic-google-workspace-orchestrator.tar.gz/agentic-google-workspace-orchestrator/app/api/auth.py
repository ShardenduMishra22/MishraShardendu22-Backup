# auth for google login

import uuid
from typing import Optional
from datetime import datetime, timezone, timedelta
import secrets
from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, Response, status
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import extract_user_id_str
from app.config import settings
from app.db import get_db
from app.integrations.google.auth import (
    GOOGLE_SCOPES,
    GoogleAuthError,
    exchange_code_for_tokens,
    get_google_auth_url,
    get_google_user_info,
)
from app.models.models import GoogleAccount, User

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


@router.get("/google")
async def google_auth_initiate() -> RedirectResponse:
    """Initiate Google OAuth consent flow."""
    state = secrets.token_urlsafe(16)
    try:
        url = get_google_auth_url(state=state)
        return RedirectResponse(url=url)
    except GoogleAuthError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )


@router.get("/google/callback", response_class=RedirectResponse)
async def google_auth_callback(
    code: str = Query(..., description="Authorization code from Google"),
    state: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
) -> RedirectResponse:
    """OAuth callback endpoint to exchange code for tokens, persist user session, and redirect to frontend."""
    if not code:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing authorization code.",
        )

    try:
        token_data = await exchange_code_for_tokens(code)
        access_token = token_data["access_token"]
        refresh_token = token_data.get("refresh_token")
        expires_in = token_data.get("expires_in", 3600)
        token_expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)

        user_info = await get_google_user_info(access_token)
        email = user_info.get("email")
        google_account_id = user_info.get("id")

        if not email or not google_account_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Unable to retrieve email or account ID from Google profile.",
            )

        # 1. Find or create User
        try:
            stmt = select(User).where(User.email == email)
            result = await db.execute(stmt)
            user = result.scalar_one_or_none()
        except Exception as db_exc:
            if "does not exist" in str(db_exc).lower() or "undefinedtable" in str(type(db_exc).__name__).lower():
                from app.db import init_db
                await init_db()
                stmt = select(User).where(User.email == email)
                result = await db.execute(stmt)
                user = result.scalar_one_or_none()
            else:
                raise

        if not user:
            user = User(email=email)
            db.add(user)
            await db.flush()

        # 2. Find or create GoogleAccount
        stmt_ga = select(GoogleAccount).where(
            GoogleAccount.user_id == user.id,
            GoogleAccount.email == email,
        )
        res_ga = await db.execute(stmt_ga)
        google_acc = res_ga.scalar_one_or_none()

        if not google_acc:
            if not refresh_token:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="No refresh token returned by Google during initial authentication.",
                )
            google_acc = GoogleAccount(
                user_id=user.id,
                google_account_id=google_account_id,
                email=email,
                access_token=access_token,
                refresh_token=refresh_token,
                token_expires_at=token_expires_at,
                scopes={"scopes": GOOGLE_SCOPES},
            )
            db.add(google_acc)
        else:
            google_acc.access_token = access_token
            google_acc.token_expires_at = token_expires_at
            google_acc.scopes = {"scopes": GOOGLE_SCOPES}
            # Only update refresh_token if Google provided a new one
            if refresh_token:
                google_acc.refresh_token = refresh_token

        await db.commit()
        await db.refresh(user)

        frontend_url = settings.FRONTEND_URL.rstrip("/")
        redirect_url = f"{frontend_url}/?user_id={user.id}"
        response = RedirectResponse(url=redirect_url, status_code=status.HTTP_302_FOUND)
        response.set_cookie(
            key="user_id",
            value=str(user.id),
            httponly=False,
            samesite="lax",
            max_age=30 * 86400,
        )
        return response

    except GoogleAuthError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )


@router.get("/google/status")
async def google_auth_status(
    request: Request,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Check current Google connection status for the authenticated user only."""
    raw_id = extract_user_id_str(request, user_id, x_user_id)
    if not raw_id:
        return {
            "connected": False,
            "email": None,
            "user_id": None,
        }

    try:
        target_uuid = uuid.UUID(raw_id)
    except (ValueError, TypeError):
        return {
            "connected": False,
            "email": None,
            "user_id": None,
        }

    try:
        stmt = (
            select(GoogleAccount)
            .where(GoogleAccount.user_id == target_uuid)
            .order_by(GoogleAccount.updated_at.desc())
        )
        res = await db.execute(stmt)
        google_acc = res.scalars().first()
    except Exception as db_exc:
        if "does not exist" in str(db_exc).lower() or "undefinedtable" in str(type(db_exc).__name__).lower():
            from app.db import init_db
            await init_db()
            stmt = (
                select(GoogleAccount)
                .where(GoogleAccount.user_id == target_uuid)
                .order_by(GoogleAccount.updated_at.desc())
            )
            res = await db.execute(stmt)
            google_acc = res.scalars().first()
        else:
            raise

    if not google_acc:
        return {
            "connected": False,
            "email": None,
            "user_id": None,
        }

    return {
        "connected": True,
        "email": google_acc.email,
        "user_id": str(google_acc.user_id),
    }


@router.post("/google/logout")
async def google_auth_logout(
    request: Request,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Logout current Google account. Deletes stored credentials and revokes token."""
    import httpx

    raw_id = extract_user_id_str(request, user_id, x_user_id)
    if not raw_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required.",
        )

    try:
        target_uuid = uuid.UUID(raw_id)
    except (ValueError, TypeError):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid user identification token.",
        )

    stmt = select(GoogleAccount).where(GoogleAccount.user_id == target_uuid)
    res = await db.execute(stmt)
    google_accounts = res.scalars().all()

    if not google_accounts:
        return {
            "status": "logged_out",
            "message": "No Google account is currently connected for this user.",
        }

    email = None
    for google_acc in google_accounts:
        email = google_acc.email
        # Attempt to revoke the access token with Google (best-effort)
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    "https://oauth2.googleapis.com/revoke",
                    params={"token": google_acc.access_token},
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                    timeout=5.0,
                )
        except Exception:
            pass

        await db.delete(google_acc)

    await db.commit()

    return {
        "status": "logged_out",
        "email": email,
        "message": f"Successfully disconnected Google account for {email}." if email else "Successfully logged out.",
    }
