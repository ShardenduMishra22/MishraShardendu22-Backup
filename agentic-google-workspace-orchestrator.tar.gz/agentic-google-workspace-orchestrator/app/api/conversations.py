"""Conversation history endpoints for multi-chat support."""

import uuid
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import resolve_authenticated_user_id
from app.db import get_db
from app.models.models import Conversation, GoogleAccount, Message, User

router = APIRouter(prefix="/api/v1/conversations", tags=["conversations"])


async def _resolve_user_id(
    db: AsyncSession,
    request: Request,
    user_id: Optional[str] = None,
    x_user_id: Optional[str] = None,
) -> uuid.UUID:
    """Resolve active authenticated user UUID strictly."""
    return await resolve_authenticated_user_id(
        db, request=request, user_id=user_id, x_user_id=x_user_id
    )


@router.get("")
async def list_conversations(
    request: Request,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> list[dict]:
    """List all conversations for the current authenticated user, newest first.

    Each entry includes the conversation id, timestamps, and a preview
    of the first user message (used as the conversation title).
    """
    uid = await _resolve_user_id(db, request=request, user_id=user_id, x_user_id=x_user_id)

    # Subquery: first user message per conversation (title preview)
    first_msg_sq = (
        select(
            Message.conversation_id,
            func.min(Message.created_at).label("first_at"),
        )
        .where(Message.role == "user")
        .group_by(Message.conversation_id)
        .subquery()
    )

    # Subquery: message count per conversation
    msg_count_sq = (
        select(
            Message.conversation_id,
            func.count(Message.id).label("message_count"),
        )
        .group_by(Message.conversation_id)
        .subquery()
    )

    stmt = (
        select(Conversation)
        .where(Conversation.user_id == uid)
        .order_by(Conversation.updated_at.desc())
    )
    result = await db.execute(stmt)
    conversations = result.scalars().all()

    out: list[dict] = []
    for conv in conversations:
        # Fetch first user message as title
        title_stmt = (
            select(Message.content)
            .where(Message.conversation_id == conv.id, Message.role == "user")
            .order_by(Message.created_at.asc())
            .limit(1)
        )
        title_res = await db.execute(title_stmt)
        first_content = title_res.scalar_one_or_none()

        # Message count
        count_stmt = (
            select(func.count(Message.id))
            .where(Message.conversation_id == conv.id)
        )
        count_res = await db.execute(count_stmt)
        msg_count = count_res.scalar() or 0

        title = first_content or "New conversation"
        if len(title) > 80:
            title = title[:77] + "..."

        out.append({
            "id": str(conv.id),
            "title": title,
            "message_count": msg_count,
            "created_at": conv.created_at.isoformat() if conv.created_at else None,
            "updated_at": conv.updated_at.isoformat() if conv.updated_at else None,
        })

    return out


@router.get("/{conversation_id}/messages")
async def get_conversation_messages(
    conversation_id: uuid.UUID,
    request: Request,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> list[dict]:
    """Fetch all messages for a given conversation, chronologically."""
    uid = await _resolve_user_id(db, request=request, user_id=user_id, x_user_id=x_user_id)

    # Verify ownership
    conv_stmt = select(Conversation).where(
        Conversation.id == conversation_id,
        Conversation.user_id == uid,
    )
    conv_res = await db.execute(conv_stmt)
    conv = conv_res.scalar_one_or_none()
    if not conv:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found.",
        )

    msg_stmt = (
        select(Message)
        .where(Message.conversation_id == conversation_id)
        .order_by(Message.created_at.asc())
    )
    msg_res = await db.execute(msg_stmt)
    messages = msg_res.scalars().all()

    return [
        {
            "id": str(m.id),
            "role": m.role,
            "content": m.content,
            "created_at": m.created_at.isoformat() if m.created_at else None,
            "structured_context": m.structured_context or {},
        }
        for m in messages
    ]


@router.delete("/{conversation_id}")
async def delete_conversation(
    conversation_id: uuid.UUID,
    request: Request,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Delete a conversation and all associated messages."""
    uid = await _resolve_user_id(db, request=request, user_id=user_id, x_user_id=x_user_id)

    conv_stmt = select(Conversation).where(
        Conversation.id == conversation_id,
        Conversation.user_id == uid,
    )
    conv_res = await db.execute(conv_stmt)
    conv = conv_res.scalar_one_or_none()
    if not conv:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conversation not found or access denied.",
        )

    await db.delete(conv)
    await db.commit()

    return {
        "status": "deleted",
        "conversation_id": str(conversation_id),
        "message": "Conversation deleted successfully.",
    }
