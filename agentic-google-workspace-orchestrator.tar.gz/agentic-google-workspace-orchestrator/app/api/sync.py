from typing import Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, Header, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import get_db
from app.models.models import GoogleAccount, SyncState
from app.services.sync_service import sync_service

router = APIRouter(prefix="/api/v1/sync", tags=["sync"])

class SyncTriggerRequest(BaseModel):
    services: list[str] = Field(
        default=["gmail", "calendar", "drive"],
        description="List of services to synchronize: gmail, calendar, drive",
    )


@router.post("/trigger")
async def trigger_sync(
    request: SyncTriggerRequest,
    user_id: Optional[str] = Query(None, description="Optional target user UUID"),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Trigger manual/initial synchronization for requested Google services."""
    target_user_id = user_id or x_user_id

    # Development Auth Resolution: Select explicit user account or fallback to active google_account
    stmt = select(GoogleAccount).order_by(GoogleAccount.updated_at.desc())
    if target_user_id:
        stmt = stmt.where(GoogleAccount.user_id == target_user_id)

    res = await db.execute(stmt)
    google_acc = res.scalars().first()

    if not google_acc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No connected Google account found. Please authorize via /api/v1/auth/google first.",
        )

    results = await sync_service.sync_services(db, google_acc, request.services)

    return {
        "user_id": str(google_acc.user_id),
        "email": google_acc.email,
        "services": request.services,
        "sync_results": results["results"],
    }


@router.get("/status")
async def get_sync_status(
    user_id: Optional[str] = Query(None, description="Optional target user UUID"),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get current sync status per service."""
    target_user_id = user_id or x_user_id

    stmt_acc = select(GoogleAccount).order_by(GoogleAccount.updated_at.desc())
    if target_user_id:
        stmt_acc = stmt_acc.where(GoogleAccount.user_id == target_user_id)

    res_acc = await db.execute(stmt_acc)
    google_acc = res_acc.scalars().first()

    if not google_acc:
        return {"status": "no_account", "sync_states": {}}

    stmt_sync = select(SyncState).where(SyncState.user_id == google_acc.user_id)
    res_sync = await db.execute(stmt_sync)
    states = res_sync.scalars().all()

    sync_map = {
        state.service: {
            "status": state.status,
            "last_synced_at": state.last_synced_at.isoformat() if state.last_synced_at else None,
            "last_error": state.last_error,
            "sync_cursor": state.sync_cursor,
        }
        for state in states
    }

    return {
        "user_id": str(google_acc.user_id),
        "email": google_acc.email,
        "sync_states": sync_map,
    }
