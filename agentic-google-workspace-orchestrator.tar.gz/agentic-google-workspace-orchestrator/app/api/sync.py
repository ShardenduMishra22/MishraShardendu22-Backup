import uuid
from typing import Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import extract_user_id_str, get_user_google_account, resolve_authenticated_user_id
from app.db import get_db
from app.models.models import GoogleAccount, SyncState
from app.services.sync_service import sync_service

router = APIRouter(prefix="/api/v1/sync", tags=["sync"])

class SyncTriggerRequest(BaseModel):
    services: list[str] = Field(
        default=["gmail", "calendar", "drive"],
        description="List of services to synchronize: gmail, calendar, drive",
    )


@router.post("/trigger")
async def trigger_sync(
    sync_req: SyncTriggerRequest,
    request: Request,
    user_id: Optional[str] = Query(None, description="Optional target user UUID"),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Trigger manual/initial synchronization for requested Google services for authenticated user."""
    resolved_uid = await resolve_authenticated_user_id(
        db, request=request, user_id=user_id, x_user_id=x_user_id
    )

    google_acc = await get_user_google_account(db, resolved_uid)
    if not google_acc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No connected Google account found for this user. Please authorize via /api/v1/auth/google first.",
        )

    results = await sync_service.sync_services(db, google_acc, sync_req.services)

    return {
        "user_id": str(google_acc.user_id),
        "email": google_acc.email,
        "services": sync_req.services,
        "sync_results": results["results"],
    }


@router.get("/status")
async def get_sync_status(
    request: Request,
    user_id: Optional[str] = Query(None, description="Optional target user UUID"),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get current sync status per service for authenticated user only."""
    raw_id = extract_user_id_str(request, user_id, x_user_id)
    if not raw_id:
        return {"status": "no_account", "sync_states": {}}

    try:
        target_uuid = uuid.UUID(raw_id)
    except (ValueError, TypeError):
        return {"status": "no_account", "sync_states": {}}

    google_acc = await get_user_google_account(db, target_uuid)
    if not google_acc:
        return {"status": "no_account", "sync_states": {}}

    stmt_sync = select(SyncState).where(SyncState.user_id == google_acc.user_id)
    res_sync = await db.execute(stmt_sync)
    states = res_sync.scalars().all()

    sync_map = {
        state.service: {
            "status": state.status,
            "last_synced_at": state.last_synced_at.isoformat() if state.last_synced_at else None,
            "last_error": state.last_error,
            "sync_cursor": state.sync_cursor,
        }
        for state in states
    }

    return {
        "user_id": str(google_acc.user_id),
        "email": google_acc.email,
        "sync_states": sync_map,
    }
