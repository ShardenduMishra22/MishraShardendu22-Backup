import uuid
from typing import Optional
from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import resolve_authenticated_user_id
from app.db import get_db
from app.orchestration.confirmation import (
    confirm_all_pending_actions,
    confirm_pending_action,
    reject_all_pending_actions,
    reject_pending_action,
)

router = APIRouter(prefix="/api/v1/actions", tags=["actions"])


async def resolve_active_user(
    db: AsyncSession,
    request: Request,
    user_id: Optional[str] = None,
    x_user_id: Optional[str] = None,
) -> uuid.UUID:
    """Resolve current user UUID strictly requiring valid authenticated user."""
    return await resolve_authenticated_user_id(
        db, request=request, user_id=user_id, x_user_id=x_user_id
    )


# ---------------------------------------------------------------------------
# Batch workflow-level confirmation endpoints (primary)
# ---------------------------------------------------------------------------


@router.post("/runs/{run_id}/confirm-all", response_model=dict)
async def confirm_all_actions_endpoint(
    run_id: uuid.UUID,
    request: Request,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Approve and execute ALL pending write actions for an orchestration run."""
    resolved_uid = await resolve_active_user(db, request=request, user_id=user_id, x_user_id=x_user_id)
    return await confirm_all_pending_actions(db, user_id=resolved_uid, run_id=run_id)


@router.post("/runs/{run_id}/reject-all", response_model=dict)
async def reject_all_actions_endpoint(
    run_id: uuid.UUID,
    request: Request,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Reject ALL pending write actions for an orchestration run. No changes are made."""
    resolved_uid = await resolve_active_user(db, request=request, user_id=user_id, x_user_id=x_user_id)
    return await reject_all_pending_actions(db, user_id=resolved_uid, run_id=run_id)


# ---------------------------------------------------------------------------
# Per-action confirmation endpoints (legacy — kept for backward compatibility)
# ---------------------------------------------------------------------------


@router.post("/{pending_action_id}/confirm", response_model=dict)
async def confirm_action_endpoint(
    pending_action_id: uuid.UUID,
    request: Request,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Confirm and execute a pending mutating workspace action."""
    resolved_uid = await resolve_active_user(db, request=request, user_id=user_id, x_user_id=x_user_id)
    return await confirm_pending_action(db, user_id=resolved_uid, pending_action_id=pending_action_id)


@router.post("/{pending_action_id}/reject", response_model=dict)
async def reject_action_endpoint(
    pending_action_id: uuid.UUID,
    request: Request,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Reject a pending mutating workspace action."""
    resolved_uid = await resolve_active_user(db, request=request, user_id=user_id, x_user_id=x_user_id)
    return await reject_pending_action(db, user_id=resolved_uid, pending_action_id=pending_action_id)
