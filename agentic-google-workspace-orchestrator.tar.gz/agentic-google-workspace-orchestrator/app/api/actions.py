import uuid
from typing import Optional
from fastapi import APIRouter, Depends, Header, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import get_db
from app.models.models import GoogleAccount, User
from app.orchestration.confirmation import (
    confirm_all_pending_actions,
    confirm_pending_action,
    reject_all_pending_actions,
    reject_pending_action,
)

router = APIRouter(prefix="/api/v1/actions", tags=["actions"])

async def resolve_active_user(
    db: AsyncSession,
    user_id: Optional[str] = None,
    x_user_id: Optional[str] = None,
) -> uuid.UUID:
    """Resolve current user UUID matching development authentication mechanism."""
    target_id = user_id or x_user_id

    stmt_acc = select(GoogleAccount).order_by(GoogleAccount.updated_at.desc())
    if target_id:
        stmt_acc = stmt_acc.where(GoogleAccount.user_id == target_id)

    res_acc = await db.execute(stmt_acc)
    google_acc = res_acc.scalars().first()

    if google_acc:
        return google_acc.user_id

    if target_id:
        stmt_u = select(User).where(User.id == target_id)
        res_u = await db.execute(stmt_u)
        u_obj = res_u.scalar_one_or_none()
        if u_obj:
            return u_obj.id

    stmt_any = select(User).order_by(User.created_at.desc())
    res_any = await db.execute(stmt_any)
    any_u = res_any.scalars().first()
    if any_u:
        return any_u.id

    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail="No application user found. Please authenticate via /api/v1/auth/google first.",
    )


# ---------------------------------------------------------------------------
# Batch workflow-level confirmation endpoints (primary)
# ---------------------------------------------------------------------------


@router.post("/runs/{run_id}/confirm-all", response_model=dict)
async def confirm_all_actions_endpoint(
    run_id: uuid.UUID,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Approve and execute ALL pending write actions for an orchestration run."""
    resolved_uid = await resolve_active_user(db, user_id=user_id, x_user_id=x_user_id)
    return await confirm_all_pending_actions(db, user_id=resolved_uid, run_id=run_id)


@router.post("/runs/{run_id}/reject-all", response_model=dict)
async def reject_all_actions_endpoint(
    run_id: uuid.UUID,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Reject ALL pending write actions for an orchestration run. No changes are made."""
    resolved_uid = await resolve_active_user(db, user_id=user_id, x_user_id=x_user_id)
    return await reject_all_pending_actions(db, user_id=resolved_uid, run_id=run_id)


# ---------------------------------------------------------------------------
# Per-action confirmation endpoints (legacy — kept for backward compatibility)
# ---------------------------------------------------------------------------


@router.post("/{pending_action_id}/confirm", response_model=dict)
async def confirm_action_endpoint(
    pending_action_id: uuid.UUID,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Confirm and execute a pending mutating workspace action."""
    resolved_uid = await resolve_active_user(db, user_id=user_id, x_user_id=x_user_id)
    return await confirm_pending_action(db, user_id=resolved_uid, pending_action_id=pending_action_id)


@router.post("/{pending_action_id}/reject", response_model=dict)
async def reject_action_endpoint(
    pending_action_id: uuid.UUID,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Reject a pending mutating workspace action."""
    resolved_uid = await resolve_active_user(db, user_id=user_id, x_user_id=x_user_id)
    return await reject_pending_action(db, user_id=resolved_uid, pending_action_id=pending_action_id)
