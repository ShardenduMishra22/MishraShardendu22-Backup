"""Authentication and user resolution dependencies for multi-tenant isolation."""

import uuid
from typing import Optional
from fastapi import Header, HTTPException, Query, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import GoogleAccount, User


def extract_user_id_str(
    request: Request,
    user_id_query: Optional[str] = None,
    x_user_id_header: Optional[str] = None,
) -> Optional[str]:
    """Extract raw user ID string from Header, Query, Cookie, or Authorization Bearer."""
    # 1. Header takes precedence
    if x_user_id_header and x_user_id_header.strip():
        return x_user_id_header.strip()

    # 2. Query param
    if user_id_query and user_id_query.strip():
        return user_id_query.strip()

    # 3. Cookie
    cookie_uid = request.cookies.get("user_id")
    if cookie_uid and cookie_uid.strip():
        return cookie_uid.strip()

    # 4. Bearer token (if formatted as UUID)
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        token = auth_header[7:].strip()
        if token:
            return token

    return None


async def resolve_authenticated_user_id(
    db: AsyncSession,
    request: Request,
    user_id: Optional[str] = None,
    x_user_id: Optional[str] = None,
) -> uuid.UUID:
    """Enforce strict user authentication for protected endpoints.

    Raises 401 Unauthorized if no valid user credentials are provided.
    NEVER falls back to any arbitrary user in the system.
    """
    raw_id = extract_user_id_str(request, user_id, x_user_id)
    if not raw_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required. Please connect your Google account.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        parsed_uuid = uuid.UUID(raw_id)
    except (ValueError, TypeError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid user identification token format.",
        )

    # Check if user exists in the database
    stmt = select(User.id).where(User.id == parsed_uuid)
    res = await db.execute(stmt)
    if not res.scalar_one_or_none():
        # Check if user exists as owner of a GoogleAccount
        stmt_ga = select(GoogleAccount.user_id).where(GoogleAccount.user_id == parsed_uuid)
        res_ga = await db.execute(stmt_ga)
        if not res_ga.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User session not found. Please log in again.",
            )

    return parsed_uuid


async def get_user_google_account(
    db: AsyncSession,
    user_id: uuid.UUID,
) -> Optional[GoogleAccount]:
    """Retrieve connected GoogleAccount strictly belonging to the given user_id."""
    stmt = (
        select(GoogleAccount)
        .where(GoogleAccount.user_id == user_id)
        .order_by(GoogleAccount.updated_at.desc())
    )
    res = await db.execute(stmt)
    return res.scalars().first()
