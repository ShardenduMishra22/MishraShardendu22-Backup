import uuid
from typing import Optional
from fastapi import APIRouter, Depends, Header, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import get_db
from app.models.models import ExecutionStep, GoogleAccount, OrchestrationRun, User

router = APIRouter(prefix="/api/v1/orchestration", tags=["orchestration"])


async def resolve_active_user(
    db: AsyncSession,
    user_id: Optional[str] = None,
    x_user_id: Optional[str] = None,
) -> uuid.UUID:
    """Resolve current user UUID matching development authentication mechanism."""
    target_id = user_id or x_user_id

    stmt_acc = select(GoogleAccount).order_by(GoogleAccount.updated_at.desc())
    if target_id:
        stmt_acc = stmt_acc.where(GoogleAccount.user_id == target_id)

    res_acc = await db.execute(stmt_acc)
    google_acc = res_acc.scalars().first()

    if google_acc:
        return google_acc.user_id

    if target_id:
        stmt_u = select(User).where(User.id == target_id)
        res_u = await db.execute(stmt_u)
        u_obj = res_u.scalar_one_or_none()
        if u_obj:
            return u_obj.id

    stmt_any = select(User).order_by(User.created_at.desc())
    res_any = await db.execute(stmt_any)
    any_u = res_any.scalars().first()
    if any_u:
        return any_u.id

    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail="No application user found. Please authenticate via /api/v1/auth/google first.",
    )


@router.get("/runs/{run_id}", response_model=dict)
async def get_orchestration_run(
    run_id: uuid.UUID,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get orchestration run status and metadata."""
    resolved_uid = await resolve_active_user(db, user_id=user_id, x_user_id=x_user_id)

    stmt = select(OrchestrationRun).where(
        OrchestrationRun.id == run_id,
        OrchestrationRun.user_id == resolved_uid,
    )
    run = (await db.execute(stmt)).scalar_one_or_none()

    if not run:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Orchestration run '{run_id}' not found or access denied.",
        )

    return {
        "id": str(run.id),
        "status": run.status,
        "query": run.query,
        "created_at": run.created_at.isoformat() if run.created_at else None,
        # OrchestrationRun does not have a mutable updated_at column. A
        # terminal timestamp is the best available freshness signal.
        "updated_at": (run.completed_at or run.created_at).isoformat() if (run.completed_at or run.created_at) else None,
        "clarification_state": run.clarification_state or {},
        "plan": run.plan or {},
    }


@router.get("/runs/{run_id}/steps", response_model=list[dict])
async def get_execution_steps(
    run_id: uuid.UUID,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> list[dict]:
    """Get all execution steps for an orchestration run."""
    resolved_uid = await resolve_active_user(db, user_id=user_id, x_user_id=x_user_id)

    # Validate run ownership
    run_stmt = select(OrchestrationRun).where(
        OrchestrationRun.id == run_id,
        OrchestrationRun.user_id == resolved_uid,
    )
    run = (await db.execute(run_stmt)).scalar_one_or_none()

    if not run:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Orchestration run '{run_id}' not found or access denied.",
        )

    # Fetch execution steps
    steps_stmt = (
        select(ExecutionStep)
        .where(ExecutionStep.orchestration_run_id == run_id)
        .order_by(ExecutionStep.created_at.asc())
    )
    steps = (await db.execute(steps_stmt)).scalars().all()

    return [
        {
            "id": str(step.id),
            "step_key": step.step_key,
            "tool_name": step.tool_name,
            "status": step.status,
            "input": step.input,
            "output": step.output,
            "error": step.error,
            "dependencies": step.dependencies,
            "created_at": step.created_at.isoformat() if step.created_at else None,
            "started_at": step.started_at.isoformat() if step.started_at else None,
            "completed_at": step.completed_at.isoformat() if step.completed_at else None,
        }
        for step in steps
    ]
