import uuid
from typing import Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, Header, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import get_db
from app.models.models import GoogleAccount, User
from app.orchestration.service import orchestrate_query

router = APIRouter(prefix="/api/v1/query", tags=["query"])


class QueryRequest(BaseModel):
    query: str = Field(..., description="Natural language workspace request")
    conversation_id: Optional[uuid.UUID] = Field(None, description="Optional ongoing conversation UUID")
    user_timezone: str = Field("UTC", description="Optional user timezone string")
    llm_provider: Optional[str] = Field("gemini", description="Optional LLM provider ('gemini' or 'groq')")


async def resolve_active_user(
    db: AsyncSession,
    user_id: Optional[str] = None,
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
) -> uuid.UUID:
    """Resolve active user UUID matching development authentication pattern."""
    target_id = user_id or x_user_id

    stmt_acc = select(GoogleAccount).order_by(GoogleAccount.updated_at.desc())
    if target_id:
        stmt_acc = stmt_acc.where(GoogleAccount.user_id == target_id)

    res_acc = await db.execute(stmt_acc)
    google_acc = res_acc.scalars().first()

    if google_acc:
        return google_acc.user_id

    if target_id:
        stmt_u = select(User).where(User.id == target_id)
        res_u = await db.execute(stmt_u)
        u_obj = res_u.scalar_one_or_none()
        if u_obj:
            return u_obj.id

    stmt_any = select(User).order_by(User.created_at.desc())
    res_any = await db.execute(stmt_any)
    any_u = res_any.scalars().first()
    if any_u:
        return any_u.id

    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail="No application user found. Please authenticate via /api/v1/auth/google first.",
    )


@router.post("", response_model=dict)
async def process_user_query(
    request: QueryRequest,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Execute end-to-end intelligent workspace query orchestration."""
    resolved_uid = await resolve_active_user(db, user_id=user_id, x_user_id=x_user_id)
    return await orchestrate_query(
        db,
        user_id=resolved_uid,
        query=request.query,
        conversation_id=request.conversation_id,
        user_timezone=request.user_timezone,
        llm_provider=request.llm_provider or "gemini",
    )
