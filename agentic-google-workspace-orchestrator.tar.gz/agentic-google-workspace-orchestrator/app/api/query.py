import uuid
from typing import Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_user_google_account, resolve_authenticated_user_id
from app.db import get_db
from app.orchestration.service import orchestrate_query

router = APIRouter(prefix="/api/v1/query", tags=["query"])


class QueryRequest(BaseModel):
    query: str = Field(..., description="Natural language workspace request")
    conversation_id: Optional[uuid.UUID] = Field(None, description="Optional ongoing conversation UUID")
    user_timezone: str = Field("UTC", description="Optional user timezone string")
    llm_provider: Optional[str] = Field("gemini", description="Optional LLM provider ('gemini' or 'groq')")


async def resolve_active_user(
    db: AsyncSession,
    request: Request,
    user_id: Optional[str] = None,
    x_user_id: Optional[str] = None,
) -> uuid.UUID:
    """Resolve active user UUID strictly requiring valid authenticated user."""
    resolved_uid = await resolve_authenticated_user_id(
        db, request=request, user_id=user_id, x_user_id=x_user_id
    )
    acc = await get_user_google_account(db, resolved_uid)
    if not acc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No connected Google account found for this user. Please authenticate via /api/v1/auth/google first.",
        )
    return resolved_uid


@router.post("", response_model=dict)
async def process_user_query(
    query_req: QueryRequest,
    request: Request,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Execute end-to-end intelligent workspace query orchestration."""
    resolved_uid = await resolve_active_user(db, request=request, user_id=user_id, x_user_id=x_user_id)
    return await orchestrate_query(
        db,
        user_id=resolved_uid,
        query=query_req.query,
        conversation_id=query_req.conversation_id,
        user_timezone=query_req.user_timezone,
        llm_provider=query_req.llm_provider or "gemini",
    )
