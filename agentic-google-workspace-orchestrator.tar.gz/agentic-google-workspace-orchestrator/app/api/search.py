from typing import Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, Header, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import get_db
from app.models.models import GoogleAccount, User
from app.retrieval.models import SearchFilters, SearchResult
from app.retrieval.search import search_workspace

router = APIRouter(prefix="/api/v1/search", tags=["search"])


class SearchApiRequest(BaseModel):
    query: str = Field(..., description="Natural language search query")
    services: Optional[list[str]] = Field(None, description="Optional list of services: gmail, calendar, drive")
    item_types: Optional[list[str]] = Field(None, description="Optional list of item types: email, calendar_event, drive_file")
    limit: int = Field(5, ge=1, le=50, description="Max results to return")
    filters: Optional[SearchFilters] = Field(None, description="Optional structured metadata filters")


@router.post("", response_model=dict)
async def debug_search_endpoint(
    request: SearchApiRequest,
    user_id: Optional[str] = Query(None, description="Optional target user UUID"),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Debug search API endpoint executing unified hybrid retrieval."""
    target_user_id = user_id or x_user_id

    # Development User Resolution: Find specified user or latest GoogleAccount/User
    stmt_acc = select(GoogleAccount).order_by(GoogleAccount.updated_at.desc())
    if target_user_id:
        stmt_acc = stmt_acc.where(GoogleAccount.user_id == target_user_id)

    res_acc = await db.execute(stmt_acc)
    google_acc = res_acc.scalars().first()

    resolved_user_id = None
    if google_acc:
        resolved_user_id = google_acc.user_id
    elif target_user_id:
        # Check if user exists directly in users table
        stmt_u = select(User).where(User.id == target_user_id)
        res_u = await db.execute(stmt_u)
        u_obj = res_u.scalar_one_or_none()
        if u_obj:
            resolved_user_id = u_obj.id

    if not resolved_user_id:
        # Fallback to any user in the system for local dev search testing
        stmt_any_user = select(User).order_by(User.created_at.desc())
        res_any = await db.execute(stmt_any_user)
        any_u = res_any.scalars().first()
        if any_u:
            resolved_user_id = any_u.id

    if not resolved_user_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No application user found. Please authenticate via /api/v1/auth/google first.",
        )

    results = await search_workspace(
        db,
        user_id=resolved_user_id,
        query=request.query,
        services=request.services,
        item_types=request.item_types,
        filters=request.filters,
        limit=request.limit,
    )

    return {
        "user_id": str(resolved_user_id),
        "query": request.query,
        "result_count": len(results),
        "results": [r.model_dump() for r in results],
    }
