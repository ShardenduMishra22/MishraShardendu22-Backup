from typing import Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import resolve_authenticated_user_id
from app.db import get_db
from app.retrieval.models import SearchFilters, SearchResult
from app.retrieval.search import search_workspace

router = APIRouter(prefix="/api/v1/search", tags=["search"])


class SearchApiRequest(BaseModel):
    query: str = Field(..., description="Natural language search query")
    services: Optional[list[str]] = Field(None, description="Optional list of services: gmail, calendar, drive")
    item_types: Optional[list[str]] = Field(None, description="Optional list of item types: email, calendar_event, drive_file")
    limit: int = Field(5, ge=1, le=50, description="Max results to return")
    filters: Optional[SearchFilters] = Field(None, description="Optional structured metadata filters")


@router.post("", response_model=dict)
async def debug_search_endpoint(
    request: SearchApiRequest,
    req: Request,
    user_id: Optional[str] = Query(None, description="Optional target user UUID"),
    x_user_id: Optional[str] = Header(None, alias="X-User-ID"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Debug search API endpoint executing unified hybrid retrieval for authenticated user."""
    resolved_user_id = await resolve_authenticated_user_id(
        db, request=req, user_id=user_id, x_user_id=x_user_id
    )

    results = await search_workspace(
        db,
        user_id=resolved_user_id,
        query=request.query,
        services=request.services,
        item_types=request.item_types,
        filters=request.filters,
        limit=request.limit,
    )

    return {
        "user_id": str(resolved_user_id),
        "query": request.query,
        "result_count": len(results),
        "results": [r.model_dump() for r in results],
    }
