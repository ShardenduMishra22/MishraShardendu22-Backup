"""
Response synthesizer that generates structured conversational cards for polished UI rendering.
Replaces wall-of-text responses with rich, structured cards.
"""
import logging
from typing import Any, Optional, List
from datetime import datetime
from uuid import UUID

from app.integrations.llm import llm_chat_completion
from app.orchestration.models import IntentClassification
from app.orchestration.response_models import (
    CompletionSummaryCard,
    ExecutionProgressCard,
    ExecutionStepCard,
    ClarificationCard,
    ClarificationProgress,
    ConfirmationCard,
    ResourceLink,
)

logger = logging.getLogger(__name__)


async def synthesize_completion_card(
    query: str,
    intent: IntentClassification,
    completed_outputs: dict[str, Any],
    step_statuses: dict[str, str],
    execution_steps: Optional[list[dict[str, Any]]] = None,
    llm_provider: str = "gemini",
) -> CompletionSummaryCard:
    """
    Generate a structured completion summary card from execution results.
    
    Args:
        query: Original user query
        intent: Classified intent
        completed_outputs: Step outputs by step ID
        step_statuses: Step status map
        execution_steps: Optional list of execution step details with timing
        llm_provider: LLM provider for summary text generation
    
    Returns:
        Structured completion summary card
    """
    # Calculate overall status
    has_failures = any(s in ("failed", "blocked") for s in step_statuses.values())
    status = "failed" if has_failures else "completed"
    
    # Extract completed and failed actions
    completed_actions = []
    failed_actions = []
    resources: List[ResourceLink] = []
    
    for step_id, step_status in step_statuses.items():
        output = completed_outputs.get(step_id, {})
        
        if step_status == "completed":
            # Extract action description
            action_desc = _describe_action(step_id, output)
            completed_actions.append(action_desc)
            
            # Extract resource links
            resources.extend(_extract_resources(step_id, output))
            
        elif step_status in ("failed", "blocked"):
            action_desc = _describe_action(step_id, output, is_failed=True)
            failed_actions.append(action_desc)
    
    # Calculate total duration if execution_steps provided
    total_duration_ms = None
    if execution_steps:
        durations = []
        for step in execution_steps:
            started = step.get("started_at")
            completed = step.get("completed_at")
            if started and completed:
                if isinstance(started, str):
                    started = datetime.fromisoformat(started.replace('Z', '+00:00'))
                if isinstance(completed, str):
                    completed = datetime.fromisoformat(completed.replace('Z', '+00:00'))
                duration = (completed - started).total_seconds() * 1000
                durations.append(duration)
        if durations:
            total_duration_ms = sum(durations)
    
    # Generate natural language summary
    summary_text = await _generate_summary_text(
        query, intent, completed_actions, failed_actions, llm_provider
    )
    
    return CompletionSummaryCard(
        status=status,
        summary_text=summary_text,
        completed_actions=completed_actions,
        failed_actions=failed_actions,
        resources=resources,
        total_duration_ms=total_duration_ms,
        timestamp=datetime.utcnow(),
    )


def synthesize_progress_card(
    step_statuses: dict[str, str],
    execution_steps: list[dict[str, Any]],
    workflow_status: str = "executing",
) -> ExecutionProgressCard:
    """
    Generate a structured execution progress card.
    
    Args:
        step_statuses: Step status map
        execution_steps: List of execution step details with timing
        workflow_status: Overall workflow status
    
    Returns:
        Structured execution progress card
    """
    step_cards = []
    current_step = None
    
    for step_detail in execution_steps:
        step_id = step_detail.get("step_key", step_detail.get("id", ""))
        status = step_detail.get("status", "pending")
        
        # Calculate duration if timestamps available
        duration_ms = None
        started_at = step_detail.get("started_at")
        completed_at = step_detail.get("completed_at")
        
        if started_at and completed_at:
            if isinstance(started_at, str):
                started_at = datetime.fromisoformat(started_at.replace('Z', '+00:00'))
            if isinstance(completed_at, str):
                completed_at = datetime.fromisoformat(completed_at.replace('Z', '+00:00'))
            duration_ms = (completed_at - started_at).total_seconds() * 1000
        
        step_card = ExecutionStepCard(
            step_id=step_id,
            step_name=step_detail.get("step_name", step_id),
            tool_name=step_detail.get("tool_name", ""),
            status=status,
            started_at=started_at if isinstance(started_at, datetime) else None,
            completed_at=completed_at if isinstance(completed_at, datetime) else None,
            duration_ms=duration_ms,
            input_summary=_sanitize_input(step_detail.get("input")),
            output_summary=_sanitize_output(step_detail.get("output")),
            error=step_detail.get("error"),
        )
        step_cards.append(step_card)
        
        if status == "running":
            current_step = step_card.step_name
    
    completed_count = sum(1 for s in step_statuses.values() if s == "completed")
    total_count = len(step_statuses)
    
    return ExecutionProgressCard(
        workflow_status=workflow_status,
        steps=step_cards,
        completed_count=completed_count,
        total_count=total_count,
        current_step=current_step,
    )


def synthesize_clarification_card(
    question: str,
    resolved_fields: list[str],
    missing_fields: list[str],
    candidates: Optional[list[str]] = None,
    context: Optional[dict[str, Any]] = None,
) -> ClarificationCard:
    """
    Generate a structured clarification request card.
    
    Args:
        question: Natural language clarification question
        resolved_fields: List of already-resolved parameter names
        missing_fields: List of still-missing parameter names
        candidates: Optional list of suggested values (for disambiguation)
        context: Additional clarification context
    
    Returns:
        Structured clarification card
    """
    return ClarificationCard(
        question=question,
        progress=ClarificationProgress(
            resolved_count=len(resolved_fields),
            total_count=len(resolved_fields) + len(missing_fields),
            missing_fields=missing_fields,
            resolved_fields=resolved_fields,
        ),
        candidates=candidates or [],
        context=context or {},
    )


async def synthesize_response(
    query: str,
    intent: IntentClassification,
    completed_outputs: dict[str, Any],
    step_statuses: dict[str, str],
    llm_provider: str = "gemini",
) -> str:
    """
    Generate a final natural language response summarizing execution results.

    Args:
        query: Original user query
        intent: Classified intent
        completed_outputs: Completed step outputs
        step_statuses: Status map for each step
        llm_provider: LLM provider for summary generation

    Returns:
        Natural language response string
    """
    completed_actions = []
    failed_actions = []

    for step_id, status in step_statuses.items():
        output = completed_outputs.get(step_id, {})

        if status == "completed":
            completed_actions.append(_describe_action(step_id, output))
        elif status in ("failed", "blocked"):
            failed_actions.append(_describe_action(step_id, output, is_failed=True))

    try:
        return await _generate_summary_text(
            query=query,
            intent=intent,
            completed_actions=completed_actions,
            failed_actions=failed_actions,
            llm_provider=llm_provider,
        )
    except Exception as exc:
        logger.warning(f"Response synthesis failed: {exc}. Falling back to deterministic summary.")
        return _deterministic_fallback_synthesis(query, completed_outputs, step_statuses)


def _deterministic_fallback_synthesis(
    query: str,
    completed_outputs: dict[str, Any],
    step_statuses: dict[str, str],
) -> str:
    """
    Generate a deterministic natural language summary when LLM synthesis is unavailable.

    Args:
        query: Original user query
        completed_outputs: Completed step outputs
        step_statuses: Status map for each step

    Returns:
        Deterministic summary string
    """
    completed_items = []
    failed_steps = []

    for step_id, status in step_statuses.items():
        output = completed_outputs.get(step_id)

        if status == "completed":
            if isinstance(output, list):
                completed_items.append(
                    f"Found {len(output)} item(s) from step '{step_id}': {output}"
                )
            elif isinstance(output, dict):
                completed_items.append(
                    f"Completed step '{step_id}' with output: {output}"
                )
            else:
                completed_items.append(f"Completed step '{step_id}'.")

        elif status in ("failed", "blocked"):
            failed_steps.append(step_id)

    summary_parts = [f"Summary for request: '{query}'"]

    if completed_items:
        summary_parts.append("; ".join(completed_items))
    else:
        summary_parts.append("No completed actions were recorded.")

    if failed_steps:
        summary_parts.append(
            f"Step(s) {', '.join(failed_steps)} encountered an issue."
        )

    return " ".join(summary_parts)


def synthesize_confirmation_card(
    message: str,
    pending_actions: list[dict[str, Any]],
    orchestration_id: UUID,
) -> ConfirmationCard:
    """
    Generate a structured confirmation request card.
    
    Args:
        message: Confirmation prompt message
        pending_actions: List of actions requiring approval
        orchestration_id: Orchestration run ID
    
    Returns:
        Structured confirmation card
    """
    return ConfirmationCard(
        message=message,
        actions=pending_actions,
        orchestration_id=orchestration_id,
    )


# ============================================================================
# PRIVATE HELPER FUNCTIONS
# ============================================================================

def _describe_action(step_id: str, output: Any, is_failed: bool = False) -> str:
    """Generate natural language description of an action."""
    if is_failed:
        return f"Step '{step_id}' failed"
    
    if isinstance(output, dict):
        if "message" in output:
            return output["message"]
        if "result" in output:
            return f"Step '{step_id}': {output['result']}"
    
    if isinstance(output, list):
        return f"Step '{step_id}': Retrieved {len(output)} items"
    
    return f"Step '{step_id}' completed"


def _extract_resources(step_id: str, output: Any) -> List[ResourceLink]:
    """Extract resource links from step output."""
    resources = []
    
    if isinstance(output, dict):
        # Check for Drive file links
        if "web_view_link" in output:
            resources.append(ResourceLink(
                type="drive_link",
                url=output["web_view_link"],
                name=output.get("name", "Drive File"),
                metadata={"file_id": output.get("id")},
            ))
        
        # Check for email links
        if "email_id" in output:
            resources.append(ResourceLink(
                type="email",
                url=f"https://mail.google.com/mail/u/0/#inbox/{output['email_id']}",
                name=output.get("subject", "Email"),
                metadata={"email_id": output["email_id"]},
            ))
        
        # Check for calendar event links
        if "event_id" in output or "htmlLink" in output:
            resources.append(ResourceLink(
                type="calendar_event",
                url=output.get("htmlLink"),
                name=output.get("summary", "Calendar Event"),
                metadata={"event_id": output.get("event_id", output.get("id"))},
            ))
    
    elif isinstance(output, list):
        # Extract resources from list of items
        for item in output[:5]:  # Limit to first 5 items
            if isinstance(item, dict):
                resources.extend(_extract_resources(step_id, item))
    
    return resources


def _sanitize_input(input_data: Optional[dict]) -> Optional[dict[str, Any]]:
    """Sanitize input parameters for display (remove sensitive data)."""
    if not input_data:
        return None
    
    sanitized = {}
    for key, value in input_data.items():
        # Skip internal fields
        if key.startswith("_"):
            continue
        
        # Truncate long strings
        if isinstance(value, str) and len(value) > 100:
            sanitized[key] = value[:100] + "..."
        else:
            sanitized[key] = value
    
    return sanitized


def _sanitize_output(output_data: Optional[dict]) -> Optional[dict[str, Any]]:
    """Sanitize output data for display."""
    if not output_data:
        return None
    
    sanitized = {}
    for key, value in output_data.items():
        if key.startswith("_"):
            continue
        
        # For lists, show count instead of full content
        if isinstance(value, list):
            sanitized[key] = f"{len(value)} items"
        elif isinstance(value, str) and len(value) > 100:
            sanitized[key] = value[:100] + "..."
        else:
            sanitized[key] = value
    
    return sanitized


async def _generate_summary_text(
    query: str,
    intent: IntentClassification,
    completed_actions: list[str],
    failed_actions: list[str],
    llm_provider: str,
) -> str:
    """Generate natural language summary using LLM with deterministic fallback."""
    
    system_prompt = """You are an expert Google Workspace Assistant. Generate a concise, helpful summary of what was accomplished.

CRITICAL RULES:
1. Be clear and direct about what was done
2. NEVER claim an action succeeded unless it's in the completed_actions list
3. If any actions failed, acknowledge them transparently
4. Keep the response under 3 sentences
5. Use natural, conversational language"""
    
    user_prompt = f"""User Query: {query}
Intent: {intent.intent}

Completed Actions:
{chr(10).join(f"- {action}" for action in completed_actions) if completed_actions else "(none)"}

Failed Actions:
{chr(10).join(f"- {action}" for action in failed_actions) if failed_actions else "(none)"}

Generate a brief, natural summary:"""
    
    try:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        
        summary = await llm_chat_completion(
            messages,
            provider=llm_provider,
            temperature=0.2,
            max_tokens=150,
        )
        return summary.strip()
    
    except Exception as exc:
        logger.warning(f"Summary generation failed: {exc}. Using deterministic fallback.")
        
        # Deterministic fallback
        if failed_actions:
            return f"Completed {len(completed_actions)} action(s) for: '{query}'. {len(failed_actions)} action(s) failed."
        else:
            return f"Successfully completed {len(completed_actions)} action(s) for: '{query}'."
