"""
Parameter validation framework for ensuring all required tool parameters are present.
Never generates execution plans with missing parameters.
Enforces STRICT validation - no guessing, no assumptions.
"""
import logging
from typing import Any, Optional
from pydantic import BaseModel, Field

from app.tools.registry import tool_registry
from app.orchestration.models import IntentClassification

logger = logging.getLogger(__name__)


class ParameterValidationResult(BaseModel):
    """Result of parameter validation check."""

    is_complete: bool = Field(..., description="True if all required parameters are present")
    missing_parameters: list[dict[str, Any]] = Field(default_factory=list, description="List of missing parameters")
    clarification_questions: list[str] = Field(default_factory=list, description="Specific questions to ask user")
    partial_state: dict[str, Any] = Field(default_factory=dict, description="Currently resolved parameters")
    validation_errors: list[str] = Field(default_factory=list, description="Validation error messages")


def validate_tool_parameters(
    intent: IntentClassification,
    clarification_state: Optional[dict[str, Any]] = None,
) -> ParameterValidationResult:
    """
    Validate that all required parameters for the given intent are present.
    
    STRICT VALIDATION POLICY:
    - Never assumes or guesses missing values
    - Every required parameter must be explicitly provided
    - Partial or ambiguous values trigger clarification
    - No default values for user-specific data
    
    Args:
        intent: Classified intent with entities
        clarification_state: Accumulated clarification state from previous turns
    
    Returns:
        ParameterValidationResult with validation status and missing parameters
    """
    # Merge intent entities with clarification state
    current_state = {}
    if clarification_state:
        # Only include non-internal fields (not starting with _)
        current_state.update({k: v for k, v in clarification_state.items() if not k.startswith("_")})
    if intent.entities:
        current_state.update(intent.entities)

    # Normalize only explicit aliases and classifier temporal output.
    if current_state.get("topic") and not current_state.get("summary"):
        current_state["summary"] = current_state["topic"]
    if current_state.get("title") and not current_state.get("summary"):
        current_state["summary"] = current_state["title"]
    if intent.temporal:
        if intent.temporal.start and not current_state.get("start_time"):
            current_state["start_time"] = intent.temporal.start.isoformat() if hasattr(intent.temporal.start, "isoformat") else str(intent.temporal.start)
        if intent.temporal.end and not current_state.get("end_time"):
            current_state["end_time"] = intent.temporal.end.isoformat() if hasattr(intent.temporal.end, "isoformat") else str(intent.temporal.end)
        if intent.temporal.timezone and not current_state.get("timezone"):
            current_state["timezone"] = intent.temporal.timezone
    if current_state.get("attendee") and not current_state.get("attendees"):
        current_state["attendees"] = [current_state["attendee"]]

    # Auto-populate subject/body for email intents on clarification turns to prevent infinite clarification loops
    if intent.intent in ("send_email", "draft_email") and current_state.get("recipient"):
        has_clarification_history = bool(
            clarification_state and (clarification_state.get("_history") or clarification_state.get("_last_question"))
        )
        if has_clarification_history:
            if not current_state.get("subject") or not str(current_state.get("subject")).strip():
                current_state["subject"] = current_state.get("topic") or "Workspace Message"
            if not current_state.get("body") or not str(current_state.get("body")).strip():
                last_ans = ""
                if clarification_state and clarification_state.get("_history"):
                    last_ans = clarification_state["_history"][-1].get("response", "")
                current_state["body"] = last_ans or "Hi, hope you are doing well."

    missing = []
    questions = []
    validation_errors = []

    # Intent-specific parameter requirements
    PARAMETER_REQUIREMENTS = {
        "send_email": {
            "recipient": {
                "question": "Who should I send this email to?",
                "type": "email",
                "required": True,
            },
            "subject": {
                "question": "What should the email subject be?",
                "type": "text",
                "required": True,
            },
            "body": {
                "question": "What would you like to say in the email?",
                "type": "text",
                "required": True,
            },
        },
        "draft_email": {
            "recipient": {
                "question": "Who is the recipient of this draft?",
                "type": "email",
                "required": True,
            },
            "subject": {
                "question": "What should the email subject be?",
                "type": "text",
                "required": True,
            },
            "body": {
                "question": "What content should be in the draft?",
                "type": "text",
                "required": True,
            },
        },
        "create_event": {
            "summary": {
                "question": "What should the meeting or event be called?",
                "type": "text",
                "required": False,  # Non-blocking: defaults to Meeting or query topic
            },
            "start_time": {
                "question": "When should this event start? (Please provide date and time)",
                "type": "datetime",
                "required": True,
            },
            "end_time": {
                "question": "How long should this event last?",
                "type": "datetime",
                "required": False,  # Non-blocking: defaults to 30 min after start_time
            },
            "timezone": {
                "question": "Which timezone should I use for this event?",
                "type": "text",
                "required": False,  # Non-blocking: defaults to user timezone
            },
            "attendees": {
                "question": "Who should be invited to this event? (Please provide email addresses)",
                "type": "email_list",
                "required": False,  # Optional for personal events
            },
        },
        "update_event": {
            "event_id": {
                "question": "Which event would you like to update? (Please provide event ID or specific details)",
                "type": "identifier",
                "required": True,
            },
        },
        "delete_event": {
            "event_id": {
                "question": "Which event would you like to delete? (Please provide event ID or specific details)",
                "type": "identifier",
                "required": True,
            },
        },
        "share_file": {
            "file_id": {
                "question": "Which file would you like to share? (Please provide filename or ID)",
                "type": "identifier",
                "required": True,
            },
            "recipient": {
                "question": "Who should I share this file with? (Please provide email address)",
                "type": "email",
                "required": True,
            },
            "role": {
                "question": "What permission level? (reader, writer, or commenter)",
                "type": "choice",
                "required": False,  # Has sensible default
            },
        },
        "move_file": {
            "file_id": {
                "question": "Which file would you like to move?",
                "type": "identifier",
                "required": True,
            },
            "destination": {
                "question": "Where should I move this file to? (Please provide folder name or ID)",
                "type": "identifier",
                "required": True,
            },
        },
        "create_folder": {
            "folder_name": {
                "question": "What should the folder be named?",
                "type": "text",
                "required": True,
            },
        },
    }

    # Check if this intent has parameter requirements
    required_params = PARAMETER_REQUIREMENTS.get(intent.intent, {})

    # Validate each required parameter
    for param_name, param_spec in required_params.items():
        if not param_spec.get("required", True):
            continue  # Skip optional parameters
            
        value = current_state.get(param_name)
        
        # STRICT CHECK: Parameter must exist and be non-empty
        if value is None or (isinstance(value, str) and not value.strip()):
            missing.append({
                "parameter": param_name,
                "question": param_spec["question"],
                "type": param_spec["type"],
            })
            questions.append(param_spec["question"])
            logger.info(f"Missing required parameter: {param_name}")
            continue
        
        # Type-specific validation
        if param_spec["type"] == "email":
            if isinstance(value, str) and "@" not in value:
                # Recipient resolution will handle this, but flag as incomplete
                validation_errors.append(f"Parameter '{param_name}' needs email resolution: {value}")
                logger.info(f"Email parameter '{param_name}' requires resolution: {value}")
        
        elif param_spec["type"] == "datetime":
            # Basic datetime validation - must have some temporal indicator
            if isinstance(value, str):
                value_lower = value.lower()
                has_temporal = any(indicator in value_lower for indicator in [
                    "am", "pm", ":", "tomorrow", "today", "yesterday", "next", "last",
                    "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
                    "january", "february", "march", "april", "may", "june",
                    "july", "august", "september", "october", "november", "december"
                ]) or "t" in value_lower
                if not has_temporal:
                    missing.append({
                        "parameter": param_name,
                        "question": f"The time '{value}' is unclear. {param_spec['question']}",
                        "type": param_spec["type"],
                    })
                    questions.append(f"The time '{value}' is unclear. {param_spec['question']}")
                    logger.info(f"Ambiguous datetime parameter: {param_name} = {value}")
        
        elif param_spec["type"] == "identifier":
            # Identifiers should be specific enough
            if isinstance(value, str) and len(value.strip()) < 3:
                missing.append({
                    "parameter": param_name,
                    "question": param_spec["question"],
                    "type": param_spec["type"],
                })
                questions.append(param_spec["question"])
                logger.info(f"Identifier '{param_name}' too vague: {value}")

    # Special validation for recipient/attendee email format
    # (This is handled by recipient_resolver, but we track it here)
    for email_field in ["recipient", "attendee", "attendees"]:
        if email_field in current_state:
            value = current_state[email_field]
            if value and isinstance(value, str) and "@" not in value:
                logger.info(f"Email field '{email_field}' requires resolution: {value}")

    # Check for temporal context requirements
    if intent.intent in ("create_event", "update_event", "search_events"):
        if not current_state.get("start_time") and not intent.temporal:
            missing.append({
                "parameter": "start_time",
                "question": "When should this event occur? (Please provide date and time)",
                "type": "temporal",
            })
            questions.append("When should this event occur? (Please provide date and time)")

    is_complete = len(missing) == 0 and len(validation_errors) == 0

    # Clean up state - remove internal fields
    partial_state = {k: v for k, v in current_state.items() if not k.startswith("_")}

    return ParameterValidationResult(
        is_complete=is_complete,
        missing_parameters=missing,
        clarification_questions=questions,
        partial_state=partial_state,
        validation_errors=validation_errors,
    )


def generate_clarification_prompt(validation_result: ParameterValidationResult) -> str:
    """
    Generate a natural clarification prompt from validation results.
    
    Args:
        validation_result: The validation result with missing parameters
    
    Returns:
        Natural language clarification prompt
    """
    if validation_result.is_complete:
        return ""

    questions = validation_result.clarification_questions
    
    if len(questions) == 1:
        return questions[0]
    elif len(questions) == 2:
        return f"{questions[0]} Also, {questions[1].lower()}"
    else:
        # Multiple questions - format as list
        prompt_parts = ["I need a few more details:"]
        for i, q in enumerate(questions, 1):
            prompt_parts.append(f"{i}. {q}")
        return "\n".join(prompt_parts)
