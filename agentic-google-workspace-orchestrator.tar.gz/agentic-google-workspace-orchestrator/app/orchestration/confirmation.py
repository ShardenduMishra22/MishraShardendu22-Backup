import logging
import uuid
from typing import Any
from datetime import datetime, timezone
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.encoders import jsonable_encoder

from app.models.models import AuditLog, OrchestrationRun, PendingAction
from app.tools.registry import tool_registry
from app.utils.serialization import serialize_for_jsonb

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Batch workflow-level confirmation (unified approve / reject)
# ---------------------------------------------------------------------------


async def confirm_all_pending_actions(
    db: AsyncSession, user_id: uuid.UUID, run_id: uuid.UUID
) -> dict[str, Any]:
    """Execute ALL pending actions for an orchestration run upon user approval.

    Actions are executed in creation order (which mirrors DAG dependency order
    because the executor creates PendingAction records during topological traversal).
    If any action fails, subsequent actions are skipped.
    """
    # Validate run ownership
    run_stmt = select(OrchestrationRun).where(
        OrchestrationRun.id == run_id,
        OrchestrationRun.user_id == user_id,
    )
    run = (await db.execute(run_stmt)).scalar_one_or_none()
    if not run:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Orchestration run '{run_id}' not found or access denied.",
        )

    # Fetch all pending actions ordered by creation time (dependency order)
    stmt = (
        select(PendingAction)
        .where(
            PendingAction.orchestration_run_id == run_id,
            PendingAction.status == "pending",
        )
        .order_by(PendingAction.created_at.asc())
    )
    actions = list((await db.execute(stmt)).scalars().all())

    if not actions:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No pending actions found for this orchestration run.",
        )

    # Transition run status to EXECUTING_APPROVED_ACTIONS
    run.status = "executing_approved_actions"
    await db.commit()

    from app.models.models import ExecutionStep as DBExecutionStep
    from app.orchestration.executor import resolve_argument_references

    # Build step_outputs map from BOTH completed AND waiting_confirmation DB execution steps
    step_outputs: dict[str, Any] = {}
    try:
        stmt_all_steps = select(DBExecutionStep).where(
            DBExecutionStep.orchestration_run_id == run_id,
            DBExecutionStep.status.in_(["completed", "waiting_confirmation"]),
        )
        existing_steps = list((await db.execute(stmt_all_steps)).scalars().all())
        for es in existing_steps:
            if es.output:
                step_outputs[es.step_key] = es.output
                # Also index by tool_name for backward compatibility
                if es.tool_name:
                    step_outputs[es.tool_name] = es.output
    except Exception as e:
        logger.warning(f"Could not rebuild step_outputs from DB: {e}")

    results: list[dict[str, Any]] = []
    failed = False

    for action in actions:
        step_id = action.payload.get("step_id") if isinstance(action.payload, dict) else None
        
        # Query corresponding ExecutionStep record and update its status
        db_step = None
        if step_id:
            try:
                stmt_step = select(DBExecutionStep).where(
                    DBExecutionStep.orchestration_run_id == run_id,
                    DBExecutionStep.step_key == step_id
                )
                db_step = (await db.execute(stmt_step)).scalars().first()
            except Exception as e:
                logger.warning(f"Could not find ExecutionStep for step_id '{step_id}': {e}")
        
        if not db_step:
            # Fallback: try matching by tool_name if step_key didn't work
            try:
                stmt_step = select(DBExecutionStep).where(
                    DBExecutionStep.orchestration_run_id == run_id,
                    DBExecutionStep.tool_name == action.action_type,
                    DBExecutionStep.status == "waiting_confirmation"
                )
                db_step = (await db.execute(stmt_step)).scalars().first()
            except Exception:
                pass

        if failed:
            action.status = "skipped"
            if db_step:
                db_step.status = "blocked"
                db_step.error = "Blocked due to earlier step failure."
            await db.commit()
            results.append({"action_type": action.action_type, "status": "blocked"})
            continue

        action.status = "executing"
        if db_step:
            db_step.status = "running"
            db_step.started_at = datetime.now(timezone.utc)
        await db.commit()

        tool = tool_registry.get_tool(action.action_type)
        
        raw_params = {}
        if isinstance(action.payload, dict):
            if "arguments" in action.payload and isinstance(action.payload["arguments"], dict):
                raw_params = dict(action.payload["arguments"])
            else:
                raw_params = dict(action.payload)

        # Strip internal orchestration metadata keys before tool invocation
        for meta_key in ("step_id", "pending_action_id", "action_type", "tool"):
            raw_params.pop(meta_key, None)

        # Re-resolve arguments against current step_outputs (e.g. inject Drive link generated in previous batch action)
        input_params = resolve_argument_references(raw_params, step_outputs)

        logger.info(f"[Batch Confirm] Executing PendingAction [{action.id}] | Tool: {action.action_type}")

        try:
            tool_result = await tool.execute(db, user_id=user_id, **input_params)
            action.status = "completed"
            action.error = None

            # Record result in step_outputs for subsequent actions in the batch
            if step_id:
                step_outputs[step_id] = tool_result
            step_outputs[action.action_type] = tool_result

            if db_step:
                db_step.status = "completed"
                db_step.output = serialize_for_jsonb(tool_result)
                db_step.completed_at = datetime.now(timezone.utc)
                db_step.error = None
            action.resolved_at = datetime.now(timezone.utc)

            audit_entry = AuditLog(
                id=uuid.uuid4(),
                user_id=user_id,
                action=action.action_type,
                resource_type=action.action_type.split(".")[0] if "." in action.action_type else "workspace",
                metadata_=serialize_for_jsonb({
                    "pending_action_id": str(action.id),
                    "input_params": input_params,
                    "status": "completed",
                    "result": tool_result,
                }),
            )
            db.add(audit_entry)
            await db.commit()

            results.append({
                "step_id": step_id,
                "action_type": action.action_type,
                "status": "completed",
                "result": tool_result,
            })

        except Exception as exc:
            action.status = "failed"
            action.error = str(exc)
            failed = True
            if db_step:
                db_step.status = "failed"
                db_step.error = str(exc)
                db_step.completed_at = datetime.now(timezone.utc)
            action.resolved_at = datetime.now(timezone.utc)

            error_type = getattr(exc, "error_type", "google_execution_error")
            error_message = getattr(exc, "message", str(exc))

            logger.error(
                f"[Batch Confirm] PendingAction [{action.id}] failed | Tool: {action.action_type} | Error: {error_message}"
            )

            audit_entry = AuditLog(
                id=uuid.uuid4(),
                user_id=user_id,
                action=f"{action.action_type}.failed",
                resource_type=action.action_type.split(".")[0] if "." in action.action_type else "workspace",
                metadata_=serialize_for_jsonb({
                    "pending_action_id": str(action.id),
                    "input_params": input_params,
                    "status": "failed",
                    "error_type": error_type,
                    "error": error_message,
                }),
            )
            db.add(audit_entry)
            await db.commit()

            results.append({
                "step_id": step_id,
                "action_type": action.action_type,
                "status": "failed",
                "error": error_message,
            })

    # Update orchestration run status
    run.status = "failed" if failed else "completed"
    run.completed_at = datetime.now(timezone.utc)
    await db.commit()

    # Validate that all execution steps are in terminal state
    try:
        stmt_verify = select(DBExecutionStep).where(
            DBExecutionStep.orchestration_run_id == run_id
        )
        all_steps = list((await db.execute(stmt_verify)).scalars().all())
        non_terminal = [
            s for s in all_steps 
            if s.status not in ("completed", "failed", "blocked", "skipped")
        ]
        if non_terminal:
            logger.warning(
                f"Workflow {run_id} marked as '{run.status}' but {len(non_terminal)} steps are not in terminal state: "
                f"{[(s.step_key, s.status) for s in non_terminal]}"
            )
    except Exception as e:
        logger.warning(f"Could not verify execution step states for workflow {run_id}: {e}")

    # Build summary message
    completed_items = [r for r in results if r["status"] == "completed"]
    failed_items = [r for r in results if r["status"] == "failed"]
    blocked_items = [r for r in results if r["status"] in ("blocked", "skipped")]

    header = "Everything has been completed successfully.\n" if not failed else "I stopped the workflow because an action failed.\n"
    msg_lines = [header]

    if completed_items:
        msg_lines.append("Completed:")
        for r in completed_items:
            msg_lines.append(f"✓ {r['action_type']}")
    if failed_items:
        msg_lines.append("\nFailed:")
        for r in failed_items:
            msg_lines.append(f"✗ {r['action_type']} — {r.get('error', 'Unknown error')}")
        msg_lines.append("\nRemaining dependent actions were not run. You can correct the issue and retry the workflow.")
    if blocked_items:
        msg_lines.append("\nBlocked:")
        for r in blocked_items:
            msg_lines.append(f"⛔ {r['action_type']} — Blocked due to upstream failure")

    return {
        "status": "completed" if not failed else "failed",
        "run_id": str(run_id),
        "results": results,
        "actions_taken": [
            {
                "step_id": r.get("step_id") or r["action_type"],
                "tool": r["action_type"],
                "status": r["status"],
                "output": r.get("result"),
                "error": r.get("error"),
            }
            for r in results
        ],
        "message": "\n".join(msg_lines),
    }


async def reject_all_pending_actions(
    db: AsyncSession, user_id: uuid.UUID, run_id: uuid.UUID
) -> dict[str, Any]:
    """Reject ALL pending actions for an orchestration run. No write operations are executed."""
    # Validate run ownership
    run_stmt = select(OrchestrationRun).where(
        OrchestrationRun.id == run_id,
        OrchestrationRun.user_id == user_id,
    )
    run = (await db.execute(run_stmt)).scalar_one_or_none()
    if not run:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Orchestration run '{run_id}' not found or access denied.",
        )

    # Fetch all pending actions
    stmt = select(PendingAction).where(
        PendingAction.orchestration_run_id == run_id,
        PendingAction.status == "pending",
    )
    actions = list((await db.execute(stmt)).scalars().all())

    if not actions:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No pending actions found for this orchestration run.",
        )

    # Reject all actions
    for action in actions:
        action.status = "rejected"
        action.resolved_at = datetime.now(timezone.utc)

        audit_entry = AuditLog(
            id=uuid.uuid4(),
            user_id=user_id,
            action=f"{action.action_type}.rejected",
            resource_type=action.action_type.split(".")[0] if "." in action.action_type else "workspace",
            metadata_=serialize_for_jsonb({
                "pending_action_id": str(action.id),
                "status": "rejected_by_user",
                "batch_rejection": True,
            }),
        )
        db.add(audit_entry)

    # Update orchestration run status
    from app.models.models import ExecutionStep as DBExecutionStep
    try:
        steps_stmt = select(DBExecutionStep).where(
            DBExecutionStep.orchestration_run_id == run_id,
            DBExecutionStep.status == "waiting_confirmation",
        )
        waiting_steps = list((await db.execute(steps_stmt)).scalars().all())
        for execution_step in waiting_steps:
            execution_step.status = "blocked"
            execution_step.error = "Cancelled by user before confirmation."
            execution_step.completed_at = datetime.now(timezone.utc)
    except Exception as exc:
        # Older workflows and lightweight test doubles may not have step rows;
        # cancellation of the PendingAction records still remains authoritative.
        logger.debug("Could not mark waiting execution steps as cancelled: %s", exc)

    run.status = "cancelled"
    run.completed_at = datetime.now(timezone.utc)
    await db.commit()

    return {
        "status": "cancelled",
        "run_id": str(run_id),
        "rejected_actions": [
            {"action_type": a.action_type, "pending_action_id": str(a.id)}
            for a in actions
        ],
        "message": "The workflow was cancelled. No changes were made.",
    }


# ---------------------------------------------------------------------------
# Individual action approval / rejection (legacy compatibility)
# ---------------------------------------------------------------------------


async def confirm_pending_action(
    db: AsyncSession, user_id: uuid.UUID, pending_action_id: uuid.UUID
) -> dict[str, Any]:
    """Confirm and execute a single pending action."""
    stmt = (
        select(PendingAction)
        .join(OrchestrationRun, OrchestrationRun.id == PendingAction.orchestration_run_id)
        .where(
            PendingAction.id == pending_action_id,
            OrchestrationRun.user_id == user_id,
        )
    )
    res = await db.execute(stmt)
    action = res.scalar_one_or_none()

    if not action:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Pending action '{pending_action_id}' not found or access denied.",
        )

    if action.status != "pending":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Action '{pending_action_id}' has already been processed (current status: '{action.status}').",
        )

    tool = tool_registry.get_tool(action.action_type)
    if not tool:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown tool type: '{action.action_type}'",
        )

    raw_params = {}
    if action.payload and isinstance(action.payload, dict):
        if "arguments" in action.payload and isinstance(action.payload["arguments"], dict):
            raw_params = dict(action.payload["arguments"])
        else:
            raw_params = dict(action.payload)

    for meta_key in ("step_id", "pending_action_id", "action_type", "tool"):
        raw_params.pop(meta_key, None)

    input_params = raw_params
    logger.info(f"Executing confirmed PendingAction [{action.id}] | Tool: {action.action_type}")

    try:
        tool_result = await tool.execute(db, user_id=user_id, **input_params)
        action.status = "completed"
        action.error = None
        action.resolved_at = datetime.now(timezone.utc)

        audit_entry = AuditLog(
            id=uuid.uuid4(),
            user_id=user_id,
            action=action.action_type,
            resource_type=action.action_type.split(".")[0] if "." in action.action_type else "workspace",
            metadata_=serialize_for_jsonb({
                "pending_action_id": str(action.id),
                "input_params": input_params,
                "status": "completed",
                "result": tool_result,
            }),
        )
        db.add(audit_entry)
        await db.commit()

        stmt_all = select(PendingAction).where(PendingAction.orchestration_run_id == action.orchestration_run_id)
        all_actions = list((await db.execute(stmt_all)).scalars().all())
        pending_remaining = [a for a in all_actions if a.status == "pending"]

        if pending_remaining:
            return {
                "status": "needs_confirmation",
                "pending_action_id": str(action.id),
                "tool": action.action_type,
                "result": tool_result,
                "pending_actions": [
                    {
                        "pending_action_id": str(a.id),
                        "action_type": a.action_type,
                        "tool": a.action_type,
                        "payload": a.payload.get("arguments") if isinstance(a.payload, dict) else a.payload,
                    }
                    for a in pending_remaining
                ],
                "message": f"Action '{action.action_type}' executed. {len(pending_remaining)} action(s) remaining for approval.",
            }

        completed_items = [a for a in all_actions if a.status == "completed"]
        rejected_items = [a for a in all_actions if a.status == "rejected"]

        msg_lines = ["All requested workspace actions have been processed.\n\nCompleted:"]
        for a in completed_items:
            msg_lines.append(f"✓ {a.action_type}")
        if rejected_items:
            msg_lines.append("\nSkipped/Rejected:")
            for a in rejected_items:
                msg_lines.append(f"✗ {a.action_type} (rejected by user)")

        final_msg = "\n".join(msg_lines)

        return {
            "status": "completed" if not rejected_items else "completed_with_rejected_actions",
            "pending_action_id": str(action.id),
            "tool": action.action_type,
            "result": tool_result,
            "pending_actions": [],
            "message": final_msg,
        }
    except Exception as exc:
        action.status = "failed"
        action.error = str(exc)
        action.resolved_at = datetime.now(timezone.utc)

        error_type = getattr(exc, "error_type", "google_execution_error")
        error_message = getattr(exc, "message", str(exc))

        logger.error(
            f"PendingAction [{action.id}] execution failed | Tool: {action.action_type} | ErrorType: {error_type} | Message: {error_message}"
        )

        audit_entry = AuditLog(
            id=uuid.uuid4(),
            user_id=user_id,
            action=f"{action.action_type}.failed",
            resource_type=action.action_type.split(".")[0] if "." in action.action_type else "workspace",
            metadata_=serialize_for_jsonb({
                "pending_action_id": str(action.id),
                "input_params": input_params,
                "status": "failed",
                "error_type": error_type,
                "error": error_message,
            }),
        )
        db.add(audit_entry)
        await db.commit()

        return {
            "status": "failed",
            "pending_action_id": str(action.id),
            "tool": action.action_type,
            "error": {
                "type": error_type,
                "message": error_message,
            },
            "message": f"Action failed: {error_message}",
        }


async def reject_pending_action(
    db: AsyncSession, user_id: uuid.UUID, pending_action_id: uuid.UUID
) -> dict[str, Any]:
    """Reject pending action without executing tool operations."""
    stmt = (
        select(PendingAction)
        .join(OrchestrationRun, OrchestrationRun.id == PendingAction.orchestration_run_id)
        .where(
            PendingAction.id == pending_action_id,
            OrchestrationRun.user_id == user_id,
        )
    )
    res = await db.execute(stmt)
    action = res.scalar_one_or_none()

    if not action:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Pending action '{pending_action_id}' not found or access denied.",
        )

    if action.status != "pending":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Action '{pending_action_id}' has already been processed (current status: '{action.status}').",
        )

    action.status = "rejected"
    action.resolved_at = datetime.now(timezone.utc)

    audit_entry = AuditLog(
        id=uuid.uuid4(),
        user_id=user_id,
        action=f"{action.action_type}.rejected",
        resource_type=action.action_type.split(".")[0] if "." in action.action_type else "workspace",
        metadata_=serialize_for_jsonb({
            "pending_action_id": str(action.id),
            "status": "rejected_by_user",
        }),
    )
    db.add(audit_entry)
    await db.commit()

    stmt_all = select(PendingAction).where(PendingAction.orchestration_run_id == action.orchestration_run_id)
    all_actions = list((await db.execute(stmt_all)).scalars().all())

    pending_remaining = [a for a in all_actions if a.status == "pending"]

    if pending_remaining:
        return {
            "status": "needs_confirmation",
            "pending_action_id": str(action.id),
            "tool": action.action_type,
            "pending_actions": [
                {
                    "pending_action_id": str(a.id),
                    "action_type": a.action_type,
                    "tool": a.action_type,
                    "payload": a.payload.get("arguments") if isinstance(a.payload, dict) else a.payload,
                }
                for a in pending_remaining
            ],
            "message": f"Action '{action.action_type}' rejected by user. {len(pending_remaining)} action(s) remaining for approval.",
        }

    completed_items = [a for a in all_actions if a.status == "completed"]
    rejected_items = [a for a in all_actions if a.status == "rejected"]

    msg_lines = ["Workflow finished. Approvals resolved.\n"]
    if completed_items:
        msg_lines.append("Completed:")
        for a in completed_items:
            msg_lines.append(f"✓ {a.action_type}")
    if rejected_items:
        msg_lines.append("\nSkipped/Rejected:")
        for a in rejected_items:
            msg_lines.append(f"✗ {a.action_type} (rejected by user)")

    final_msg = "\n".join(msg_lines)

    return {
        "status": "completed_with_rejected_actions",
        "pending_action_id": str(action.id),
        "tool": action.action_type,
        "pending_actions": [],
        "message": final_msg,
    }

