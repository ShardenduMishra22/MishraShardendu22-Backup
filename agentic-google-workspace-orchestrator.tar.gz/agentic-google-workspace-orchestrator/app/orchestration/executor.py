# executes level by level parallely topo sort order

import asyncio
import logging
import re
import time
import uuid
from typing import Any, Optional
from datetime import datetime, timezone
from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import AsyncSessionLocal
from app.models.models import ExecutionStep as DBExecutionStep, OrchestrationRun, PendingAction
from app.orchestration.models import ExecutionPlan, PlanStep
from app.orchestration.validator import validate_execution_plan
from app.tools.base import Tool, ToolExecutionError
from app.tools.registry import tool_registry
from app.utils.serialization import serialize_for_jsonb

logger = logging.getLogger(__name__)


def resolve_path_expression(obj: Any, path: str, step_id: str = "", strict: bool = True) -> Any:
    """Evaluate a navigation path like '.files[0].id' or '[0].external_id' or '.external_id' on an object.
    
    Args:
        obj: Object to navigate
        path: Navigation path string
        step_id: Step ID for error messages
        strict: If True, raise error on out-of-bounds list access or missing dict keys
    """
    if not path or obj is None:
        return obj

    curr = obj
    tokens = re.findall(r'\.([a-zA-Z0-9_\-]+)|\[(\d+)\]', path)
    for token_index, (attr, idx_str) in enumerate(tokens):
        if curr is None:
            if strict:
                raise ToolExecutionError(
                    f"Cannot resolve path '{path}' on step '{step_id}': intermediate value is None"
                )
            return None
        if attr:
            if token_index == 0 and attr == "output" and not (
                isinstance(curr, dict) and attr in curr
            ):
                # Compatibility identity alias for persisted plans generated
                # before output values were stored without a wrapper.
                continue
            if isinstance(curr, dict):
                # Older saved plans use an explicit `.output` wrapper even
                # though executor results are stored directly. Treat only
                # this leading wrapper as an identity alias; it does not pick
                # a field or infer a value.
                if strict and attr not in curr:
                    raise ToolExecutionError(
                        f"Cannot resolve path '{path}' on step '{step_id}': field '{attr}' not found in dict. Available keys: {list(curr.keys())}"
                    )
                curr = curr.get(attr)
            elif hasattr(curr, attr):
                curr = getattr(curr, attr)
            else:
                if strict:
                    raise ToolExecutionError(
                        f"Cannot resolve path '{path}' on step '{step_id}': field '{attr}' not found"
                    )
                return None
        elif idx_str != '':
            idx = int(idx_str)
            if isinstance(curr, (list, tuple)):
                if strict and (idx < 0 or idx >= len(curr)):
                    raise ToolExecutionError(
                        f"Cannot resolve path '{path}' on step '{step_id}': list index [{idx}] out of range (list has {len(curr)} items). "
                        f"This typically means the search returned fewer results than expected."
                    )
                if 0 <= idx < len(curr):
                    curr = curr[idx]
                else:
                    return None
            else:
                if strict:
                    raise ToolExecutionError(
                        f"Cannot resolve path '{path}' on step '{step_id}': cannot apply index [{idx}] to non-list value"
                    )
                return None
    return curr


def resolve_argument_references(arg_val: Any, step_outputs: dict[str, Any], step_id: str = "") -> Any:
    """Recursively resolve explicit field path references in tool arguments.

    Supports:
    - Exact reference: '$steps.<step_id>[0].field' or '$steps.<step_id>.field'
    - Embedded reference inside text: 'Hi, link: $steps.share_resume.web_view_link'
    
    NO HEURISTIC EXTRACTION. Every reference must be explicit.
    """
    if isinstance(arg_val, str):
        if "$" not in arg_val:
            return arg_val

        # Exact match (non-embedded) where scalar or complex type can be directly returned
        if arg_val.startswith("$") and " " not in arg_val and "\n" not in arg_val:
            ref = arg_val[1:]
            if ref.startswith("steps."):
                ref = ref[6:]

            m = re.match(r"^([a-zA-Z0-9_\-]+)(.*)$", ref)
            if m:
                sid, remainder = m.group(1), m.group(2)
                if sid in step_outputs:
                    out = step_outputs[sid]
                    resolved = resolve_path_expression(out, remainder, step_id=sid, strict=True)
                    if resolved is not None:
                        return resolved

        # Embedded regex replacement for substrings within text
        def repl(match: re.Match) -> str:
            raw_ref = match.group(1).rstrip(".,;")
            ref = raw_ref
            if ref.startswith("steps."):
                ref = ref[6:]

            m = re.match(r"^([a-zA-Z0-9_\-]+)(.*)$", ref)
            if not m:
                return match.group(0)

            sid, remainder = m.group(1), m.group(2)
            if sid not in step_outputs:
                return match.group(0)

            out = step_outputs[sid]
            resolved = resolve_path_expression(out, remainder, step_id=sid, strict=True)
            if resolved is not None:
                return str(resolved)
            return match.group(0)

        return re.sub(r"\$([a-zA-Z0-9_\-\.\[\]]+)", repl, arg_val)

    elif isinstance(arg_val, dict):
        return {k: resolve_argument_references(v, step_outputs, step_id) for k, v in arg_val.items()}
    elif isinstance(arg_val, list):
        return [resolve_argument_references(item, step_outputs, step_id) for item in arg_val]

    return arg_val


def bind_and_map_step_arguments(
    step: PlanStep,
    step_outputs: dict[str, Any],
    tool: Tool,
) -> dict[str, Any]:
    """Resolve step arguments with explicit field paths and validate schema.
    
    NO HEURISTIC EXTRACTION. All dependency references must be explicit field paths.
    """
    resolved_args: dict[str, Any] = {}

    for param_name, arg_val in step.arguments.items():
        val = resolve_argument_references(arg_val, step_outputs, step_id=step.id)
        resolved_args[param_name] = val

    # Pre-execution schema validation
    try:
        validated_model = tool.input_model(**resolved_args)
        return validated_model.model_dump(exclude_unset=True)
    except ValidationError as ve:
        err_details = []
        for err in ve.errors():
            loc = ".".join(str(l) for l in err.get("loc", []))
            msg = err.get("msg", "")
            err_details.append(f"field '{loc}': {msg}")
        raise ToolExecutionError(
            f"Pre-execution schema validation failed for step '{step.id}' (tool '{tool.name}'): " + "; ".join(err_details)
        )


class DAGExecutor:
    """Async dependency-aware parallel DAG executor with confirmation gating."""

    def __init__(self, db: AsyncSession, user_id: uuid.UUID, run_id: uuid.UUID):
        self.db = db
        self.user_id = user_id
        self.run_id = run_id

    async def execute_plan(
        self, plan: ExecutionPlan, conversation_id: uuid.UUID
    ) -> dict[str, Any]:
        """Execute validated ExecutionPlan DAG."""
        # 1. Validate plan and topological ordering
        sorted_step_ids = validate_execution_plan(plan)

        step_map: dict[str, PlanStep] = {s.id: s for s in plan.steps}
        step_outputs: dict[str, Any] = {}
        step_statuses: dict[str, str] = {s.id: "pending" for s in plan.steps}
        step_errors: dict[str, str] = {}

        # Dependencies graph
        in_degree = {s.id: len(s.depends_on) for s in plan.steps}
        dependents = {s.id: [] for s in plan.steps}
        for s in plan.steps:
            for dep in s.depends_on:
                dependents[dep].append(s.id)

        # Create DB ExecutionStep records
        from app.utils.serialization import serialize_for_jsonb

        for s in plan.steps:
            db_step = DBExecutionStep(
                id=uuid.uuid4(),
                orchestration_run_id=self.run_id,
                step_key=s.id,
                tool_name=s.tool,
                dependencies={"depends_on": s.depends_on},
                input=serialize_for_jsonb(s.arguments),
                status="pending",
            )
            self.db.add(db_step)
        await self.db.commit()

        pending_action_records: list[dict[str, Any]] = []

        while True:
            # Find all ready steps (in_degree == 0 and all dependencies completed or waiting confirmation)
            ready_step_ids = []
            for sid, status in step_statuses.items():
                if status == "pending":
                    step_deps = step_map[sid].depends_on

                    # Check if any upstream dependency failed, blocked, or skipped
                    any_dep_failed = any(
                        step_statuses[dep] in ("failed", "blocked", "skipped")
                        for dep in step_deps
                    )
                    if any_dep_failed:
                        step_statuses[sid] = "blocked"
                        await self._update_db_step(sid, "blocked", error=f"Blocked due to upstream dependency failure.")
                        self._cascade_skip(sid, dependents, in_degree, step_statuses)
                        continue

                    # Step is ready if all dependencies are satisfied (completed or queued for confirmation)
                    all_deps_satisfied = all(
                        step_statuses[dep] in ("completed", "waiting_confirmation")
                        for dep in step_deps
                    )
                    if all_deps_satisfied:
                        ready_step_ids.append(sid)

            if not ready_step_ids:
                break

            # Execute independent ready steps concurrently
            tasks = []
            step_start_times = {}
            for sid in ready_step_ids:
                step_statuses[sid] = "running"
                step_start_times[sid] = datetime.now(timezone.utc)
                await self._update_db_step(sid, "running", started_at=step_start_times[sid])
                tasks.append(self._execute_single_step(step_map[sid], step_outputs))

            results = await asyncio.gather(*tasks, return_exceptions=True)

            for sid, result in zip(ready_step_ids, results):
                completed_at = datetime.now(timezone.utc)
                
                if isinstance(result, Exception):
                    logger.error(f"Step '{sid}' failed with exception: {result}")
                    step_statuses[sid] = "failed"
                    step_errors[sid] = str(result)
                    await self._update_db_step(
                        sid, "failed", 
                        error=str(result),
                        completed_at=completed_at
                    )

                    # Cascade block dependent steps
                    self._cascade_skip(sid, dependents, in_degree, step_statuses)

                elif isinstance(result, dict) and result.get("needs_confirmation"):
                    # Step triggered confirmation gate
                    step_statuses[sid] = "waiting_confirmation"
                    if result.get("pending_action"):
                        pending_action_records.append(result["pending_action"])
                    await self._update_db_step(
                        sid, "waiting_confirmation",
                        completed_at=completed_at
                    )

                else:
                    # Step completed successfully
                    step_statuses[sid] = "completed"
                    step_outputs[sid] = result
                    await self._update_db_step(
                        sid, "completed", 
                        output=result,
                        completed_at=completed_at
                    )

                    # Unlock dependent steps
                    for dep in dependents[sid]:
                        in_degree[dep] -= 1

        has_failures = any(s in ("failed", "blocked") for s in step_statuses.values())

        if has_failures:
            # If any prerequisite or dependent step failed/blocked, fail the workflow and do not ask for confirmation
            return {
                "status": "failed",
                "pending_actions": [],
                "completed_outputs": step_outputs,
                "step_statuses": step_statuses,
                "step_errors": step_errors,
                "error": f"Workflow failed due to step failures: {[sid for sid, st in step_statuses.items() if st in ('failed', 'blocked')]}",
            }

        if pending_action_records:
            # Pause DAG execution for user confirmation gate returning ALL pending actions
            return {
                "status": "needs_confirmation",
                "pending_actions": pending_action_records,
                "pending_action": pending_action_records[0],
                "completed_outputs": step_outputs,
                "step_statuses": step_statuses,
                "step_errors": step_errors,
            }

        return {
            "status": "completed",
            "completed_outputs": step_outputs,
            "step_statuses": step_statuses,
            "step_errors": step_errors,
        }

    def _cascade_skip(
        self,
        failed_sid: str,
        dependents: dict[str, list[str]],
        in_degree: dict[str, int],
        step_statuses: dict[str, str],
    ) -> None:
        """Mark all downstream dependent steps as BLOCKED due to upstream failure."""
        queue = list(dependents.get(failed_sid, []))
        while queue:
            curr = queue.pop(0)
            if step_statuses[curr] in ("pending", "waiting_confirmation"):
                step_statuses[curr] = "blocked"
                asyncio.create_task(
                    self._update_db_step(
                        curr, "blocked", error=f"Blocked due to upstream failure in step '{failed_sid}'."
                    )
                )
                for child in dependents.get(curr, []):
                    queue.append(child)

    async def _execute_single_step(
        self, step: PlanStep, step_outputs: dict[str, Any]
    ) -> Any:
        """Execute a single step, resolving references and checking confirmation gate."""
        from fastapi.encoders import jsonable_encoder

        tool = tool_registry.get_tool(step.tool)

        # CONFIRMATION GATE INTERCEPTION FOR WRITE ACTIONS
        if tool.requires_confirmation or not tool.read_only:
            logger.info(f"Step '{step.id}' tool '{step.tool}' is a write tool requiring user confirmation gate.")

            try:
                resolved_args = bind_and_map_step_arguments(step, step_outputs, tool)
            except Exception as exc:
                # If an upstream dependency is currently unexecuted (waiting confirmation),
                # defer argument mapping until post-approval batch execution.
                # If all dependencies have completed (e.g. search completed with 0 items), fail immediately.
                waiting_deps = [dep for dep in step.depends_on if dep not in step_outputs]
                if waiting_deps:
                    logger.info(
                        "Step '%s' has dependency-derived write arguments; deferring final argument validation until the approved execution batch.",
                        step.id,
                    )
                    resolved_args = step.arguments
                else:
                    raise exc

            async with AsyncSessionLocal() as session:
                pending_action = PendingAction(
                    id=uuid.uuid4(),
                    orchestration_run_id=self.run_id,
                    action_type=step.tool,
                    payload=serialize_for_jsonb({"arguments": resolved_args, "step_id": step.id}),
                    status="pending",
                )
                session.add(pending_action)
                await session.commit()
                await session.refresh(pending_action)

                return {
                    "needs_confirmation": True,
                    "pending_action": {
                        "pending_action_id": str(pending_action.id),
                        "action_type": step.tool,
                        "tool": step.tool,
                        "step_id": step.id,
                        "payload": resolved_args,
                    },
                }

        # Execute read-only tool with resolved arguments
        resolved_args = bind_and_map_step_arguments(step, step_outputs, tool)

        # Execute read-only or safe write tool with dedicated session context
        async with AsyncSessionLocal() as session:
            start_time = time.perf_counter()
            result = await tool.execute(session, user_id=self.user_id, **resolved_args)
            execution_ms = (time.perf_counter() - start_time) * 1000.0
            logger.info(f"Step '{step.id}' (tool: {step.tool}) executed in {execution_ms:.1f}ms")
            return result

    async def _update_db_step(
        self,
        step_id: str,
        status: str,
        output: Optional[Any] = None,
        error: Optional[str] = None,
        started_at: Optional[datetime] = None,
        completed_at: Optional[datetime] = None,
    ) -> None:
        """
        Update ExecutionStep state in database with timing information.
        
        Args:
            step_id: Step identifier
            status: New status
            output: Step output (if completed)
            error: Error message (if failed)
            started_at: Step start timestamp (for 'running' status)
            completed_at: Step completion timestamp (for terminal states)
        """
        from app.utils.serialization import serialize_for_jsonb

        async with AsyncSessionLocal() as session:
            stmt = select(DBExecutionStep).where(
                DBExecutionStep.orchestration_run_id == self.run_id,
                DBExecutionStep.step_key == step_id,
            )
            res = await session.execute(stmt)
            db_step = res.scalar_one_or_none()
            if db_step:
                db_step.status = status
                
                # Track timing
                if started_at:
                    db_step.started_at = started_at
                if completed_at:
                    db_step.completed_at = completed_at
                
                if output is not None:
                    encoded = serialize_for_jsonb(output)
                    db_step.output = encoded if isinstance(encoded, dict) else {"result": encoded}
                if error:
                    db_step.error = error
                await session.commit()
