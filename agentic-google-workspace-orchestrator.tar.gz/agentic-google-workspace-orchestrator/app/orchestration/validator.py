# checking if plan is not too long, if it sues valid tools and 
# which step depends on what and then using khan algo if its a dag or not.

import logging
import re
from typing import Any
from app.orchestration.models import ExecutionPlan
from app.tools.registry import tool_registry

logger = logging.getLogger(__name__)

MAX_PLAN_STEPS = 10


class PlanValidationError(ValueError):
    """Raised when an execution plan fails structural, tool, or graph validation."""

    pass


def extract_dependency_references(value: Any) -> list[str]:
    """Recursively extract all $steps.<step_id> references from argument values."""
    references = []
    
    if isinstance(value, str):
        # Find all $steps.<step_id>... patterns
        matches = re.findall(r'\$steps\.([a-zA-Z0-9_\-]+)', value)
        references.extend(matches)
        # Also check for shorthand $<step_id> patterns
        shorthand_matches = re.findall(r'\$([a-zA-Z0-9_\-]+)(?![a-zA-Z0-9_\-\.])', value)
        references.extend(shorthand_matches)
    elif isinstance(value, dict):
        for v in value.values():
            references.extend(extract_dependency_references(v))
    elif isinstance(value, list):
        for item in value:
            references.extend(extract_dependency_references(item))
    
    return references


def validate_explicit_field_references(plan: ExecutionPlan) -> None:
    """Validate that all dependency references include explicit field paths.
    
    Rejects ambiguous references like:
    - $search_resume (no field path)
    - $steps.search_resume (no field path)
    
    Requires explicit paths like:
    - $steps.search_resume[0].external_id (for list results)
    - $steps.share_resume.web_view_link (for dict results)
    
    Raises:
        PlanValidationError: If any dependency reference lacks explicit field path.
    """
    step_ids = {s.id for s in plan.steps}
    
    for step in plan.steps:
        for arg_name, arg_value in step.arguments.items():
            if not isinstance(arg_value, str) or "$" not in arg_value:
                continue
            
            # Find all $steps.<step_id> or $<step_id> patterns
            # Pattern 1: $steps.<step_id>... (full syntax)
            full_refs = re.findall(r'\$steps\.([a-zA-Z0-9_\-]+)([^\s,;]*)', arg_value)
            
            for ref_step_id, path_suffix in full_refs:
                if ref_step_id not in step_ids:
                    continue  # Will be caught by dependency validation
                
                # Check if there's an explicit field path after step_id
                # Valid: [0].external_id or .web_view_link
                # Invalid: (empty)
                
                if not path_suffix:
                    raise PlanValidationError(
                        f"Step '{step.id}' argument '{arg_name}' contains ambiguous reference "
                        f"'$steps.{ref_step_id}' without explicit field path. "
                        f"Required format: '$steps.{ref_step_id}[0].<field>' or '$steps.{ref_step_id}.<field>'. "
                        f"Example: '$steps.{ref_step_id}[0].external_id'"
                    )
                
                # Check for minimal field path structure (at least .something or [index].something)
                has_field = re.search(r'\.[a-zA-Z_][a-zA-Z0-9_]*', path_suffix)
                if not has_field:
                    raise PlanValidationError(
                        f"Step '{step.id}' argument '{arg_name}' reference "
                        f"'$steps.{ref_step_id}{path_suffix}' lacks explicit field selector. "
                        f"Required: '$steps.{ref_step_id}.<field>' or '$steps.{ref_step_id}[0].<field>'."
                    )
            
            # Pattern 2: $<step_id> shorthand (always ambiguous, reject immediately)
            shorthand_refs = re.findall(r'\$([a-zA-Z0-9_\-]+)(?![a-zA-Z0-9_\-\.])', arg_value)
            
            for ref_step_id in shorthand_refs:
                if ref_step_id in step_ids:
                    raise PlanValidationError(
                        f"Step '{step.id}' argument '{arg_name}' contains ambiguous shorthand reference "
                        f"'${ref_step_id}'. Must use full explicit path: '$steps.{ref_step_id}[0].<field>'"
                    )


def validate_execution_plan(plan: ExecutionPlan) -> list[str]:
    """Validate DAG structural integrity, tool existence, step bounds, and cycle-freedom.

    Returns:
        List of step IDs in topologically sorted execution order.

    Raises:
        PlanValidationError: If plan is invalid, exceeds bounds, contains cycles, or references unknown tools.
    """
    if not plan.steps:
        raise PlanValidationError("Execution plan contains no steps.")

    if len(plan.steps) > MAX_PLAN_STEPS:
        raise PlanValidationError(f"Execution plan exceeds maximum step limit ({len(plan.steps)} > {MAX_PLAN_STEPS}).")

    step_ids = set()
    step_map = {}

    # 1. Validate uniqueness & tool registration
    for step in plan.steps:
        if not step.id or not step.id.strip():
            raise PlanValidationError("Step ID cannot be empty.")

        if step.id in step_ids:
            raise PlanValidationError(f"Duplicate step ID '{step.id}' detected in plan.")

        # Verify tool existence in registry
        try:
            tool_registry.get_tool(step.tool)
        except Exception:
            raise PlanValidationError(f"Step '{step.id}' references unknown tool '{step.tool}'.")

        step_ids.add(step.id)
        step_map[step.id] = step

    # 2. Validate explicit field references (NEW: reject ambiguous dependencies)
    validate_explicit_field_references(plan)

    # 3. Validate dependency references & self-dependencies
    in_degree = {sid: 0 for sid in step_ids}
    adj_list = {sid: [] for sid in step_ids}

    for step in plan.steps:
        for dep_id in step.depends_on:
            if dep_id == step.id:
                raise PlanValidationError(f"Step '{step.id}' contains self-dependency.")

            if dep_id not in step_ids:
                raise PlanValidationError(f"Step '{step.id}' references unknown dependency '{dep_id}'.")

            adj_list[dep_id].append(step.id)
            in_degree[step.id] += 1

    # 4. Topological Sort (Kahn's Algorithm) for Cycle Detection
    queue = [sid for sid, deg in in_degree.items() if deg == 0]
    sorted_steps = []

    while queue:
        curr = queue.pop(0)
        sorted_steps.append(curr)

        for neighbor in adj_list[curr]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if len(sorted_steps) != len(step_ids):
        raise PlanValidationError("Cyclic dependency detected in execution plan DAG.")

    return sorted_steps
