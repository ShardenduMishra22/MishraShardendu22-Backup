"""Orchestration package for query classification, DAG planning, execution, and synthesis."""

#              service.py
#                  │
#      ┌───────────┴───────────┐
#      │                       │
#  context.py        recipient_resolver.py
#      │                       │
#      └───────────┬───────────┘
#                  ▼
#            classifier.py
#                  │
#         IntentClassification
#            [models.py]
#                  │
#                  ▼
#             planner.py
#                  │
#            ExecutionPlan
#            [models.py]
#                  │
#                  ▼
#            validator.py
#                  │
#                  ▼
#             executor.py
#                  │
#     ┌────────────┼────────────┐
#     ▼            ▼            ▼
#   Gmail       Calendar       Drive
#     │            │            │
#     └────────────┼────────────┘
#                  │
#         write operation?
#            /          \
#          yes           no
#           │             │
#    confirmation.py     │
#           │             │
#           └──────┬──────┘
#                  ▼
#           synthesizer.py
#                  │
#                  ▼
#            Final response