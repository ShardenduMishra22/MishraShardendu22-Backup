"""
Formal state machine definitions for conversational orchestration lifecycle.
Enforces strict state transitions and prevents invalid state changes.
"""
from enum import Enum
from typing import Optional


class OrchestrationState(str, Enum):
    """
    Orchestration run lifecycle states.
    
    State Transition Flow:
    PLANNING → CLARIFICATION_REQUIRED → READY → WAITING_CONFIRMATION → EXECUTING → COMPLETED/FAILED
    
    Clarification Loop:
    CLARIFICATION_REQUIRED can loop back to itself multiple times until all parameters are resolved.
    """
    PLANNING = "planning"  # Initial state - analyzing user query
    CLARIFICATION_REQUIRED = "clarification_required"  # Missing parameters, waiting for user input
    READY = "ready"  # All parameters validated, ready to generate execution plan
    WAITING_CONFIRMATION = "waiting_confirmation"  # Execution plan generated, awaiting user approval
    EXECUTING = "executing"  # Execution in progress
    COMPLETED = "completed"  # Successfully completed
    FAILED = "failed"  # Failed with error
    CANCELLED = "cancelled"  # User cancelled the workflow


class ExecutionStepState(str, Enum):
    """
    Individual execution step lifecycle states.
    
    State Transition Flow:
    PENDING → RUNNING → COMPLETED/FAILED
    or
    PENDING → SKIPPED (if dependency failed)
    """
    PENDING = "pending"  # Waiting for dependencies
    RUNNING = "running"  # Currently executing
    COMPLETED = "completed"  # Successfully completed
    FAILED = "failed"  # Failed with error
    SKIPPED = "skipped"  # Skipped due to dependency failure


# Valid state transitions for OrchestrationRun
VALID_ORCHESTRATION_TRANSITIONS = {
    OrchestrationState.PLANNING: {
        OrchestrationState.CLARIFICATION_REQUIRED,
        OrchestrationState.READY,
        OrchestrationState.FAILED,
    },
    OrchestrationState.CLARIFICATION_REQUIRED: {
        OrchestrationState.CLARIFICATION_REQUIRED,  # Can loop back to itself
        OrchestrationState.READY,
        OrchestrationState.FAILED,
        OrchestrationState.CANCELLED,
    },
    OrchestrationState.READY: {
        OrchestrationState.WAITING_CONFIRMATION,
        OrchestrationState.EXECUTING,  # Direct execution for read-only operations
        OrchestrationState.FAILED,
    },
    OrchestrationState.WAITING_CONFIRMATION: {
        OrchestrationState.EXECUTING,
        OrchestrationState.CANCELLED,
        OrchestrationState.FAILED,
    },
    OrchestrationState.EXECUTING: {
        OrchestrationState.COMPLETED,
        OrchestrationState.FAILED,
    },
    OrchestrationState.COMPLETED: set(),  # Terminal state
    OrchestrationState.FAILED: set(),  # Terminal state
    OrchestrationState.CANCELLED: set(),  # Terminal state
}


# Valid state transitions for ExecutionStep
VALID_STEP_TRANSITIONS = {
    ExecutionStepState.PENDING: {
        ExecutionStepState.RUNNING,
        ExecutionStepState.SKIPPED,
        ExecutionStepState.FAILED,
    },
    ExecutionStepState.RUNNING: {
        ExecutionStepState.COMPLETED,
        ExecutionStepState.FAILED,
    },
    ExecutionStepState.COMPLETED: set(),  # Terminal state
    ExecutionStepState.FAILED: set(),  # Terminal state
    ExecutionStepState.SKIPPED: set(),  # Terminal state
}


def is_valid_orchestration_transition(
    from_state: OrchestrationState,
    to_state: OrchestrationState
) -> bool:
    """Check if an orchestration state transition is valid."""
    if from_state not in VALID_ORCHESTRATION_TRANSITIONS:
        return False
    return to_state in VALID_ORCHESTRATION_TRANSITIONS[from_state]


def is_valid_step_transition(
    from_state: ExecutionStepState,
    to_state: ExecutionStepState
) -> bool:
    """Check if an execution step state transition is valid."""
    if from_state not in VALID_STEP_TRANSITIONS:
        return False
    return to_state in VALID_STEP_TRANSITIONS[from_state]


def is_terminal_orchestration_state(state: OrchestrationState) -> bool:
    """Check if an orchestration state is terminal (no further transitions allowed)."""
    return state in {
        OrchestrationState.COMPLETED,
        OrchestrationState.FAILED,
        OrchestrationState.CANCELLED,
    }


def is_terminal_step_state(state: ExecutionStepState) -> bool:
    """Check if an execution step state is terminal (no further transitions allowed)."""
    return state in {
        ExecutionStepState.COMPLETED,
        ExecutionStepState.FAILED,
        ExecutionStepState.SKIPPED,
    }


class StateTransitionError(Exception):
    """Raised when an invalid state transition is attempted."""
    
    def __init__(self, from_state: str, to_state: str, message: Optional[str] = None):
        self.from_state = from_state
        self.to_state = to_state
        default_message = f"Invalid state transition from '{from_state}' to '{to_state}'"
        super().__init__(message or default_message)
