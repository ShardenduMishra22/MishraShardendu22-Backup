"""
Structured conversational response models for polished UI rendering.
Replaces wall-of-text responses with structured cards.
"""
from typing import Any, Optional
from datetime import datetime
from pydantic import BaseModel, Field
from uuid import UUID


class ClarificationProgress(BaseModel):
    """Progress tracking for clarification workflow."""
    resolved_count: int = Field(..., description="Number of parameters already resolved")
    total_count: int = Field(..., description="Total number of required parameters")
    missing_fields: list[str] = Field(default_factory=list, description="List of missing parameter names")
    resolved_fields: list[str] = Field(default_factory=list, description="List of resolved parameter names")


class ClarificationCard(BaseModel):
    """Structured clarification request card."""
    type: str = Field(default="clarification", description="Card type identifier")
    question: str = Field(..., description="Natural language clarification question")
    progress: ClarificationProgress = Field(..., description="Clarification progress tracker")
    candidates: list[str] = Field(default_factory=list, description="Suggested options for ambiguous parameters")
    context: dict[str, Any] = Field(default_factory=dict, description="Additional clarification context")


class ExecutionStepCard(BaseModel):
    """Individual execution step status card."""
    step_id: str = Field(..., description="Unique step identifier")
    step_name: str = Field(..., description="Human-readable step name")
    tool_name: str = Field(..., description="Tool being executed")
    status: str = Field(..., description="Step status: pending, running, completed, failed, skipped")
    started_at: Optional[datetime] = Field(None, description="Step start timestamp")
    completed_at: Optional[datetime] = Field(None, description="Step completion timestamp")
    duration_ms: Optional[float] = Field(None, description="Step execution duration in milliseconds")
    input_summary: Optional[dict[str, Any]] = Field(None, description="Sanitized input parameters")
    output_summary: Optional[dict[str, Any]] = Field(None, description="Sanitized output summary")
    error: Optional[str] = Field(None, description="Error message if failed")


class ExecutionProgressCard(BaseModel):
    """Structured execution progress tracking card."""
    type: str = Field(default="execution_progress", description="Card type identifier")
    workflow_status: str = Field(..., description="Overall workflow status")
    steps: list[ExecutionStepCard] = Field(default_factory=list, description="Execution step statuses")
    completed_count: int = Field(default=0, description="Number of completed steps")
    total_count: int = Field(default=0, description="Total number of steps")
    current_step: Optional[str] = Field(None, description="Currently executing step name")


class ResourceLink(BaseModel):
    """Resource link with metadata."""
    type: str = Field(..., description="Resource type: drive_link, calendar_event, email, etc.")
    url: Optional[str] = Field(None, description="Resource URL")
    name: str = Field(..., description="Resource display name")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional resource metadata")


class CompletionSummaryCard(BaseModel):
    """Structured completion summary card."""
    type: str = Field(default="completion_summary", description="Card type identifier")
    status: str = Field(..., description="Final workflow status: completed or failed")
    summary_text: str = Field(..., description="Natural language summary")
    completed_actions: list[str] = Field(default_factory=list, description="List of completed action descriptions")
    failed_actions: list[str] = Field(default_factory=list, description="List of failed action descriptions")
    resources: list[ResourceLink] = Field(default_factory=list, description="Generated or accessed resources")
    total_duration_ms: Optional[float] = Field(None, description="Total workflow execution time")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Completion timestamp")


class ConfirmationCard(BaseModel):
    """Structured confirmation request card."""
    type: str = Field(default="confirmation", description="Card type identifier")
    message: str = Field(..., description="Confirmation prompt message")
    actions: list[dict[str, Any]] = Field(default_factory=list, description="Pending actions requiring approval")
    orchestration_id: UUID = Field(..., description="Orchestration run ID for confirmation")


class ConversationalResponse(BaseModel):
    """
    Unified conversational response envelope.
    Contains one or more structured cards for frontend rendering.
    """
    status: str = Field(..., description="Response status: planning, clarification_required, ready, waiting_confirmation, executing, completed, failed")
    conversation_id: UUID = Field(..., description="Conversation ID")
    orchestration_id: Optional[UUID] = Field(None, description="Orchestration run ID if created")
    
    # Response can contain one or more of these structured cards
    clarification: Optional[ClarificationCard] = Field(None, description="Clarification request card")
    progress: Optional[ExecutionProgressCard] = Field(None, description="Execution progress card")
    completion: Optional[CompletionSummaryCard] = Field(None, description="Completion summary card")
    confirmation: Optional[ConfirmationCard] = Field(None, description="Confirmation request card")
    
    # Fallback text response for backwards compatibility
    text_response: Optional[str] = Field(None, description="Plain text response (fallback)")
    
    # Metadata
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Response timestamp")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional response metadata")
