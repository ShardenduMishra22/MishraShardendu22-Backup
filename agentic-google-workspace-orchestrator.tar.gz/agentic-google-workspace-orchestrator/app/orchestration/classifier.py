# Classifier for user intent and entity extraction using Gemini LLM.

import json
import logging
from datetime import datetime, timezone
from typing import Optional
from pydantic import ValidationError

from app.integrations.llm import GeminiRateLimitError, GroqRateLimitError, llm_chat_completion
from app.orchestration.models import IntentClassification
from app.utils.json_parser import extract_and_parse_json

logger = logging.getLogger(__name__)

CLASSIFIER_SYSTEM_PROMPT = """You are an expert Intent Classifier and Entity Extractor for a Google Workspace Orchestrator.
Your job is to analyze user requests, extract structured entities and temporal date ranges, and detect ambiguity.

STRICT JSON OBJECT OUTPUT REQUIREMENT:
1. Output EXACTLY ONE JSON OBJECT (a dictionary starting with '{{' and ending with '}}').
2. Do NOT output a JSON array (list starting with '[').
3. Do NOT output markdown code fences (like ```json), intro text, commentary, or postscript explanations.
4. Do NOT output multiple JSON objects or comments.
5. Current Reference Date/Time: {current_time_iso} (Timezone: {user_timezone}). Use this reference date to resolve relative temporal expressions like "today", "tomorrow", "next week", "last month", "next Tuesday".
6. Services MUST be a subset of ["gmail", "calendar", "drive"].
7. Canonical Intent examples: "send_email", "create_event", "prepare_meeting", "search_email", "search_calendar", "search_drive", "cross_service_search".
8. If the request is ambiguous (e.g., "Move the meeting with John" without specifying which meeting or new time), set "ambiguous": true and provide a helpful "clarification_question".
9. NEVER invent a person, email address, date, duration, file, event, message content, or permission. Omit unknown entity values; values are known only when explicit in the conversation or resolved from Workspace data.

REQUIRED JSON OBJECT SCHEMA:
{{
  "intent": "<string>",
  "services": ["<gmail|calendar|drive>"],
  "entities": {{
    "sender": "<string|null>",
    "recipient": "<string|null>",
    "attendee": "<string|null>",
    "company": "<string|null>",
    "topic": "<string|null>",
    "location": "<string|null>",
    "mime_type": "<string|null>"
  }},
  "temporal": {{
    "original_text": "<string|null>",
    "start": "<ISO-8601 string or null>",
    "end": "<ISO-8601 string or null>",
    "timezone": "{user_timezone}"
  }},
  "ambiguous": <boolean>,
  "clarification_question": "<string|null>"
}}
"""


def _conservative_fallback_intent(query: str) -> IntentClassification:
    """Classify only an explicit action category when the model is unavailable.

    Parameters deliberately remain empty.  This forces the normal validator to
    ask questions instead of turning a failed model call into an executable
    mutating workflow.
    """
    query_lower = query.lower()
    if any(word in query_lower for word in ("schedule", "meeting", "calendar event", "appointment")):
        return IntentClassification(intent="create_event", services=["calendar"], entities={}, ambiguous=True)
    if any(word in query_lower for word in ("email", "mail", "send", "message")):
        return IntentClassification(
            intent="draft_email" if "draft" in query_lower else "send_email",
            services=["gmail"],
            entities={},
            ambiguous=True,
        )
    if any(word in query_lower for word in ("share", "move", "folder")):
        return IntentClassification(intent="share_file", services=["drive"], entities={}, ambiguous=True)
    return IntentClassification(intent="cross_service_search", services=["gmail", "calendar", "drive"], entities={}, ambiguous=False)


async def classify_intent(
    query: str,
    conversation_history: list[dict[str, str]],
    user_timezone: str = "UTC",
    current_time: Optional[datetime] = None,
    llm_provider: str = "gemini",
) -> IntentClassification:
    """Classify user query intent, extract entities/temporal bounds, and detect ambiguity."""
    now = current_time or datetime.now(timezone.utc)
    system_prompt = CLASSIFIER_SYSTEM_PROMPT.format(
        current_time_iso=now.isoformat(),
        user_timezone=user_timezone,
    )

    messages = [{"role": "system", "content": system_prompt}]
    for msg in conversation_history:
        messages.append({"role": msg["role"], "content": msg["content"]})
    messages.append({"role": "user", "content": query})

    for attempt in range(2):
        raw_response = ""
        try:
            raw_response = await llm_chat_completion(messages, provider=llm_provider, temperature=0.0)
            
            logger.info(f"--- [Classifier Attempt {attempt + 1}] RAW LLM RESPONSE ---\n{raw_response}\n-----------------------------------------")

            parsed, clean_json, parse_err = extract_and_parse_json(raw_response)
            logger.info(f"--- [Classifier Attempt {attempt + 1}] CLEANED JSON ---\n{clean_json}\n-----------------------------------------")

            if parse_err:
                raise ValueError(f"JSON extraction failed: {parse_err}")

            # Top-level type validation and safe unwrapping
            if isinstance(parsed, list):
                logger.warning(f"Classifier received JSON array (list) with {len(parsed)} element(s) instead of JSON object (dict).")
                if len(parsed) == 1 and isinstance(parsed[0], dict):
                    logger.info("Safely unwrapping single-item array into JSON object.")
                    parsed = parsed[0]
                else:
                    raise ValueError(f"Expected JSON object (dict), but received JSON array (list) with {len(parsed)} items.")

            if not isinstance(parsed, dict):
                raise ValueError(f"Expected JSON object (dict) for IntentClassification, but received {type(parsed).__name__}.")

            classification = IntentClassification(**parsed)
            logger.info(f"--- [Classifier Attempt {attempt + 1}] PARSED INTENT ---\n{classification.model_dump()}\n-----------------------------------------")
            return classification

        except Exception as exc:
            if isinstance(exc, (GeminiRateLimitError, GroqRateLimitError)):
                logger.warning(f"LLM quota limit reached ({exc}). Using conservative fallback intent classification.")
                return _conservative_fallback_intent(query)

            validation_detail = str(exc)
            if isinstance(exc, ValidationError):
                validation_detail = json.dumps(exc.errors(), indent=2)

            logger.warning(f"Intent classification attempt {attempt + 1} failed: {exc} | Detail: {validation_detail}")
            if attempt == 1:
                logger.error("Fallback classification due to repeated LLM output error.")
                return _conservative_fallback_intent(query)
            
            messages.append({"role": "assistant", "content": raw_response})
            messages.append({
                "role": "user",
                "content": "Your previous response was invalid JSON or violated schema. Output ONLY valid JSON matching the exact schema without prose, code fences, or arrays.",
            })

    return _conservative_fallback_intent(query)
