from datetime import datetime
from typing import Any, Literal, Optional
from pydantic import BaseModel, Field


class TemporalContext(BaseModel):
    """Resolved temporal expressions and date range context."""

    original_text: Optional[str] = Field(None, description="Original natural language expression e.g. 'next week'")
    start: Optional[datetime] = Field(None, description="Start date/time (timezone aware)")
    end: Optional[datetime] = Field(None, description="End date/time (timezone aware)")
    timezone: str = Field("UTC", description="Resolved IANA timezone string e.g. 'UTC'")


class IntentClassification(BaseModel):
    """Structured LLM output from Intent Classifier."""

    intent: str = Field(..., description="Canonical workspace intent string e.g. 'search_email', 'cancel_flight', 'prepare_meeting'")
    services: list[Literal["gmail", "calendar", "drive"]] = Field(default_factory=list, description="Target Workspace services")
    entities: dict[str, Any] = Field(default_factory=dict, description="Extracted entities e.g. sender, attendee, company, topic")
    temporal: Optional[TemporalContext] = Field(None, description="Resolved temporal context")
    ambiguous: bool = Field(False, description="True if query requires clarification due to missing or ambiguous parameters")
    clarification_question: Optional[str] = Field(None, description="Clarification question to present to user if ambiguous")


class PlanStep(BaseModel):
    """Single node/step in a typed Execution Plan DAG."""

    id: str = Field(..., description="Unique step identifier e.g. 'search_booking'")
    tool: str = Field(..., description="Registered tool name from ToolRegistry e.g. 'gmail.search_emails'")
    arguments: dict[str, Any] = Field(default_factory=dict, description="Input parameters or reference string templates")
    depends_on: list[str] = Field(default_factory=list, description="List of step IDs that must complete before this step runs")
    requires_confirmation: bool = Field(False, description="True if step tool requires user confirmation")


class ExecutionPlan(BaseModel):
    """Typed execution DAG plan produced by Query Planner."""

    goal: Optional[str] = Field(None, description="Brief plan summary or goal description")
    steps: list[PlanStep] = Field(default_factory=list, description="Ordered/parallel steps composing the DAG")


class ClarificationRequest(BaseModel):
    """Structured clarification payload returned to user."""

    reason: str = Field(..., description="Reason why clarification is needed")
    question: str = Field(..., description="Question to ask the user")
    missing_fields: list[str] = Field(default_factory=list, description="List of missing fields")
    candidates: list[dict[str, Any]] = Field(default_factory=list, description="Optional candidate choices")
