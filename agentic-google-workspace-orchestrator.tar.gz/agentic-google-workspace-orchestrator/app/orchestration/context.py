"""
Conversation context management with accumulated clarification state tracking.
Manages conversation lifecycle, message persistence, and clarification memory.
"""
import uuid
import logging
from typing import Any, Optional
from datetime import datetime
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Conversation, Message, OrchestrationRun
from app.utils.serialization import serialize_for_jsonb

logger = logging.getLogger(__name__)


async def get_or_create_conversation(
    db: AsyncSession, user_id: uuid.UUID, conversation_id: Optional[uuid.UUID] = None
) -> Conversation:
    """Load existing conversation verifying user ownership or create a new one."""
    if conversation_id:
        stmt = select(Conversation).where(
            Conversation.id == conversation_id,
            Conversation.user_id == user_id,
        )
        res = await db.execute(stmt)
        conv = res.scalar_one_or_none()
        if not conv:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Conversation '{conversation_id}' not found or access denied.",
            )
        return conv

    conv = Conversation(id=uuid.uuid4(), user_id=user_id)
    db.add(conv)
    await db.commit()
    await db.refresh(conv)
    return conv


async def load_conversation_history(
    db: AsyncSession, conversation_id: uuid.UUID, max_messages: Optional[int] = None
) -> list[dict[str, str]]:
    """Load conversation history in chronological order.

    Orchestration decisions must be made from the accumulated conversation, not
    an arbitrary trailing window.  ``max_messages`` remains available for
    callers that explicitly need a bounded view (for example, a compact UI).
    """
    stmt = (
        select(Message)
        .where(Message.conversation_id == conversation_id)
        .order_by(Message.created_at.desc())
    )
    if max_messages is not None:
        stmt = stmt.limit(max_messages)
    res = await db.execute(stmt)
    recent_msgs = list(res.scalars().all())
    recent_msgs.reverse()  # Return in chronological order

    return [{"role": m.role, "content": m.content} for m in recent_msgs]


async def save_message(
    db: AsyncSession,
    conversation_id: uuid.UUID,
    role: str,
    content: str,
    structured_context: Optional[dict[str, Any]] = None,
) -> Message:
    """Save a user or assistant message to the database."""
    msg = Message(
        id=uuid.uuid4(),
        conversation_id=conversation_id,
        role=role,
        content=content,
        structured_context=serialize_for_jsonb(structured_context) if structured_context else {},
    )
    db.add(msg)
    await db.commit()
    await db.refresh(msg)
    return msg


async def get_active_clarification_workflow(
    db: AsyncSession, conversation_id: uuid.UUID
) -> Optional[OrchestrationRun]:
    """
    Retrieve the most recent pending clarification workflow for a conversation.
    Returns None if no active clarification workflow exists.
    """
    stmt = (
        select(OrchestrationRun)
        .where(
            OrchestrationRun.conversation_id == conversation_id,
            OrchestrationRun.status.in_(["needs_clarification", "clarifying"]),
        )
        .order_by(OrchestrationRun.created_at.desc())
    )
    result = await db.execute(stmt)
    pending_run = result.scalars().first()
    
    if pending_run:
        logger.info(
            f"Found active clarification workflow: run_id={pending_run.id}, "
            f"status={pending_run.status}, query='{pending_run.query}'"
        )
    
    return pending_run


def merge_clarification_state(
    existing_state: Optional[dict[str, Any]],
    new_entities: dict[str, Any],
) -> dict[str, Any]:
    """
    Merge new entities into existing clarification state.
    Preserves internal fields (prefixed with _) and history.
    
    Args:
        existing_state: Current accumulated state
        new_entities: Newly extracted entities to merge
    
    Returns:
        Merged state dictionary
    """
    merged = existing_state.copy() if existing_state else {}
    
    # Update with new entities (non-internal fields take precedence)
    for key, value in new_entities.items():
        if not key.startswith("_") and value is not None:
            merged[key] = value
            logger.debug(f"Merged entity: {key} = {value}")
    
    return merged


def append_clarification_turn(
    clarification_state: dict[str, Any],
    question: str,
    response: str,
    extracted_entities: dict[str, Any],
) -> dict[str, Any]:
    """
    Append a clarification turn to the state history.
    
    Args:
        clarification_state: Current state with history
        question: The clarification question asked
        response: User's response
        extracted_entities: Entities extracted from the response
    
    Returns:
        Updated state with new history entry
    """
    history = clarification_state.get("_history", [])
    
    history.append({
        "question": question,
        "response": response,
        "timestamp": datetime.utcnow().isoformat(),
        "extracted_entities": extracted_entities,
    })
    
    clarification_state["_history"] = history
    logger.info(f"Appended clarification turn. Total history: {len(history)} turns")
    
    return clarification_state


def get_resolved_and_missing_parameters(
    clarification_state: dict[str, Any],
    missing_parameters: list[dict[str, Any]],
) -> tuple[list[str], list[str]]:
    """
    Calculate resolved and still-missing parameter names for progress tracking.
    
    Args:
        clarification_state: Current accumulated state
        missing_parameters: List of missing parameter specifications
    
    Returns:
        Tuple of (resolved_fields, missing_fields)
    """
    # Extract resolved fields (non-internal, non-empty values)
    resolved = [
        key for key, value in clarification_state.items()
        if not key.startswith("_") and value is not None and value != ""
    ]
    
    # Extract missing field names
    missing = [param.get("parameter", "") for param in missing_parameters if param.get("parameter")]
    
    return resolved, missing
