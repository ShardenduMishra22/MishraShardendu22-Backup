# convert a human-friendly recipient into an actual email address.

import re
import uuid
from typing import Any, Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import WorkspaceItem

EMAIL_REGEX = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")


async def resolve_recipient_email(
    db: AsyncSession, user_id: uuid.UUID, recipient: Optional[str]
) -> dict[str, Any]:
    """Resolve a recipient string (name or email) to a validated email address.

    Returns:
        {"status": "resolved", "email": "..."}
        {"status": "not_found", "recipient_name": "..."}
        {"status": "ambiguous", "recipient_name": "...", "matches": [...]}
        {"status": "missing"}
    """
    if not recipient or not recipient.strip():
        return {"status": "missing"}

    clean_recipient = recipient.strip()

    # 1. Direct valid email check
    if "@" in clean_recipient and EMAIL_REGEX.search(clean_recipient):
        email_match = EMAIL_REGEX.search(clean_recipient)
        if email_match:
            return {"status": "resolved", "email": email_match.group(0).lower()}

    # 2. Search workspace items (emails & calendar events) for recipient name match
    stmt = select(WorkspaceItem).where(
        WorkspaceItem.user_id == user_id,
        WorkspaceItem.service.in_(["gmail", "calendar"]),
    )
    res = await db.execute(stmt)
    items = res.scalars().all()

    found_emails: set[str] = set()
    name_words = set(clean_recipient.lower().split())

    for item in items:
        meta = item.metadata_ or {}

        candidates: list[str] = []
        if isinstance(meta.get("sender"), str):
            candidates.append(meta["sender"])
        if isinstance(meta.get("recipients"), str):
            candidates.append(meta["recipients"])
        elif isinstance(meta.get("recipients"), list):
            candidates.extend([r for r in meta["recipients"] if isinstance(r, str)])
        if isinstance(meta.get("attendees"), list):
            candidates.extend([a for a in meta["attendees"] if isinstance(a, str)])
        if isinstance(meta.get("organizer"), str):
            candidates.append(meta["organizer"])

        full_text = f"{item.title or ''} {item.content or ''}".lower()
        if any(w in full_text for w in name_words):
            extracted = EMAIL_REGEX.findall(f"{full_text} {' '.join(candidates)}")
            candidates.extend(extracted)

        for cand in candidates:
            cand_lower = cand.lower()
            if any(w in cand_lower for w in name_words):
                emails = EMAIL_REGEX.findall(cand_lower)
                found_emails.update(emails)

    unique_matches = sorted(list(found_emails))

    if len(unique_matches) == 1:
        return {"status": "resolved", "email": unique_matches[0]}
    elif len(unique_matches) > 1:
        return {"status": "ambiguous", "recipient_name": clean_recipient, "matches": unique_matches}
    else:
        return {"status": "not_found", "recipient_name": clean_recipient}
