"""Deterministic execution-plan enrichment from already resolved entities.

This module intentionally performs no entity discovery.  It only carries a
known, validated recipient into equivalent tool argument names when a planner
omits it from a dependent write step.
"""
from app.orchestration.models import ExecutionPlan, IntentClassification


def _resolved_email(intent: IntentClassification) -> str | None:
    """Return one explicitly resolved email address, if the context has one."""
    for key in ("recipient", "attendee"):
        value = intent.entities.get(key)
        if isinstance(value, str) and "@" in value:
            return value

    attendees = intent.entities.get("attendees")
    if isinstance(attendees, list):
        for value in attendees:
            if isinstance(value, str) and "@" in value:
                return value
    return None


def enrich_plan_with_resolved_entities(
    plan: ExecutionPlan, intent: IntentClassification
) -> ExecutionPlan:
    """Fill omitted recipient fields using only the resolved intent context.

    The query planner often uses the same recipient for a Drive share, calendar
    invitation, and email.  These aliases are tool-specific, so preserving the
    known email here prevents a partial workflow where Calendar succeeds but
    Drive or Gmail fail due to an omitted parameter.
    """
    recipient = _resolved_email(intent)
    if not recipient:
        return plan

    for step in plan.steps:
        args = step.arguments
        if step.tool == "drive.share_file":
            current = args.get("target_email") or args.get("email")
            if not isinstance(current, str) or "@" not in current:
                args["target_email"] = recipient
        elif step.tool == "gmail.send_email":
            current = args.get("to")
            if not isinstance(current, str) or "@" not in current:
                args["to"] = recipient
        elif step.tool == "calendar.create_event":
            attendees = args.get("attendees")
            if not attendees:
                args["attendees"] = [recipient]

    return plan
