import logging
import uuid
from typing import Any, Optional
from datetime import datetime
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.encoders import jsonable_encoder

from app.models.models import OrchestrationRun
from app.orchestration.classifier import classify_intent
from app.orchestration.context import (
    get_or_create_conversation,
    load_conversation_history,
    save_message,
)
from app.orchestration.executor import DAGExecutor
from app.orchestration.planner import generate_execution_plan
from app.orchestration.synthesizer import synthesize_response
from app.orchestration.parameter_validator import validate_tool_parameters, generate_clarification_prompt
from app.orchestration.plan_enrichment import enrich_plan_with_resolved_entities
from app.orchestration.clarification_engine import ClarificationEngine
from app.utils.serialization import serialize_for_jsonb

logger = logging.getLogger(__name__)


async def orchestrate_query(
    db: AsyncSession,
    user_id: uuid.UUID,
    query: str,
    conversation_id: Optional[uuid.UUID] = None,
    user_timezone: str = "UTC",
    llm_provider: str = "gemini",
) -> dict[str, Any]:
    """Execute complete end-to-end orchestration pipeline with iterative clarification support."""
    
    # ====================================================================================
    # STEP 1: CONVERSATION MANAGEMENT
    # ====================================================================================
    conv = await get_or_create_conversation(db, user_id=user_id, conversation_id=conversation_id)
    await save_message(db, conversation_id=conv.id, role="user", content=query)

    # ====================================================================================
    # STEP 2: CHECK FOR PENDING CLARIFICATION WORKFLOW
    # ====================================================================================
    stmt_pending = (
        select(OrchestrationRun)
        .where(
            OrchestrationRun.conversation_id == conv.id,
            OrchestrationRun.status == "needs_clarification",
        )
        .order_by(OrchestrationRun.created_at.desc())
    )
    pending_run = (await db.execute(stmt_pending)).scalars().first()

    # ====================================================================================
    # STEP 3: LOAD CONVERSATION HISTORY
    # ====================================================================================
    # Keep the original request, every answer, and prior assistant responses in
    # the planner context.  A clarification can span any number of turns.
    history = await load_conversation_history(db, conversation_id=conv.id)

    # ====================================================================================
    # STEP 4: HANDLE CLARIFICATION CONTINUATION
    # ====================================================================================
    if pending_run:
        logger.info(f"Resuming clarification workflow [{pending_run.id}] with user response: '{query}'")
        
        # Merge clarification response into existing state
        existing_intent = pending_run.intent
        existing_state = pending_run.clarification_state or {}
        
        intent, merged_state, clarification_history = await ClarificationEngine.merge_clarification_response(
            original_query=pending_run.query,
            clarification_response=query,
            existing_state=existing_state,
            existing_intent=existing_intent,
            conversation_history=history,
            user_timezone=user_timezone,
            llm_provider=llm_provider,
        )

        # Also try simple extraction as fallback
        missing_params = existing_state.get("_missing_parameters", [])
        simple_extracts = ClarificationEngine.extract_simple_responses(query, missing_params)
        merged_state.update(simple_extracts)
        intent.entities.update(simple_extracts)

        # Update the pending run with merged state
        pending_run.intent = serialize_for_jsonb(intent)
        pending_run.clarification_state = serialize_for_jsonb(merged_state)
        pending_run.clarification_history = serialize_for_jsonb(clarification_history)
        pending_run.status = "clarifying"
        await db.commit()

        # Proceed with this updated intent and state
        logger.info(f"Accumulated clarification state: {merged_state}")
    else:
        # ====================================================================================
        # STEP 5: NEW QUERY - CLASSIFY INTENT
        # ====================================================================================
        intent = await classify_intent(query, conversation_history=history, user_timezone=user_timezone, llm_provider=llm_provider)
        merged_state = {}
        clarification_history = []

    # ====================================================================================
    # STEP 6: RECIPIENT EMAIL RESOLUTION (Gmail/Calendar Write Actions)
    # ====================================================================================
    from app.orchestration.recipient_resolver import resolve_recipient_email
    
    raw_recipient = intent.entities.get("recipient") or intent.entities.get("attendee") or merged_state.get("recipient") or merged_state.get("attendee")
    
    if intent.intent in ("send_email", "draft_email", "create_event") or raw_recipient:
        if raw_recipient and isinstance(raw_recipient, str) and "@" not in raw_recipient:
            rec_res = await resolve_recipient_email(db, user_id=user_id, recipient=raw_recipient)
            
            if rec_res["status"] == "resolved":
                resolved_email = rec_res["email"]
                if intent.entities.get("recipient"):
                    intent.entities["recipient"] = resolved_email
                if intent.entities.get("attendee"):
                    intent.entities["attendee"] = resolved_email
                merged_state["recipient"] = resolved_email
                merged_state["attendee"] = resolved_email
                logger.info(f"Resolved recipient '{raw_recipient}' to '{resolved_email}'")
                
            elif rec_res["status"] == "ambiguous":
                matches_str = ", ".join(rec_res["matches"])
                clarification_question = f"I found multiple email addresses for '{raw_recipient}': {matches_str}. Which email address would you like to use?"
                
                # Store the ambiguous state
                run = pending_run or OrchestrationRun(
                    id=uuid.uuid4(),
                    user_id=user_id,
                    conversation_id=conv.id,
                    query=pending_run.query if pending_run else query,
                    intent=serialize_for_jsonb(intent),
                    status="needs_clarification",
                    clarification_state=serialize_for_jsonb(merged_state),
                    clarification_history=serialize_for_jsonb(clarification_history),
                )
                
                if not pending_run:
                    db.add(run)
                    
                merged_state["_last_question"] = clarification_question
                merged_state["_missing_parameters"] = [{"parameter": "recipient", "question": clarification_question}]
                run.clarification_state = serialize_for_jsonb(merged_state)
                
                await db.commit()
                await save_message(
                    db,
                    conversation_id=conv.id,
                    role="assistant",
                    content=clarification_question,
                    structured_context={"status": "needs_clarification", "ambiguous_recipient": True, "matches": rec_res["matches"]},
                )

                return {
                    "status": "needs_clarification",
                    "conversation_id": str(conv.id),
                    "orchestration_id": str(run.id),
                    "clarification": {
                        "question": clarification_question,
                        "missing_fields": ["recipient"],
                        "candidates": rec_res["matches"],
                        "progress": {
                            "resolved": len([k for k in merged_state.keys() if not k.startswith("_")]),
                            "total": len(merged_state.get("_missing_parameters", [])) + len([k for k in merged_state.keys() if not k.startswith("_")]),
                        },
                    },
                }
                
            elif rec_res["status"] in ("not_found", "missing"):
                clarification_question = f"I couldn't find an email address for '{raw_recipient}' in your workspace. What email address should I use?"
                
                run = pending_run or OrchestrationRun(
                    id=uuid.uuid4(),
                    user_id=user_id,
                    conversation_id=conv.id,
                    query=pending_run.query if pending_run else query,
                    intent=serialize_for_jsonb(intent),
                    status="needs_clarification",
                    clarification_state=serialize_for_jsonb(merged_state),
                    clarification_history=serialize_for_jsonb(clarification_history),
                )
                
                if not pending_run:
                    db.add(run)
                    
                merged_state["_last_question"] = clarification_question
                merged_state["_missing_parameters"] = [{"parameter": "recipient", "question": clarification_question}]
                run.clarification_state = serialize_for_jsonb(merged_state)
                
                await db.commit()
                await save_message(
                    db,
                    conversation_id=conv.id,
                    role="assistant",
                    content=clarification_question,
                    structured_context={"status": "needs_clarification", "recipient_not_found": True},
                )

                return {
                    "status": "needs_clarification",
                    "conversation_id": str(conv.id),
                    "orchestration_id": str(run.id),
                    "clarification": {
                        "question": clarification_question,
                        "missing_fields": ["recipient"],
                        "candidates": [],
                        "progress": {
                            "resolved": len([k for k in merged_state.keys() if not k.startswith("_")]),
                            "total": len(merged_state.get("_missing_parameters", [])) + len([k for k in merged_state.keys() if not k.startswith("_")]),
                        },
                    },
                }

    # ====================================================================================
    # STEP 7: PARAMETER VALIDATION - CHECK COMPLETENESS
    # ====================================================================================
    validation_result = validate_tool_parameters(intent, clarification_state=merged_state)
    # Preserve canonical aliases (for example topic -> summary and resolved
    # temporal fields) so subsequent clarification turns never lose them.
    merged_state.update(validation_result.partial_state)
    
    if not validation_result.is_complete:
        logger.info(f"Parameter validation failed. Missing: {validation_result.missing_parameters}")
        
        clarification_question = generate_clarification_prompt(validation_result)
        
        # Create or update orchestration run with clarification needed
        run = pending_run or OrchestrationRun(
            id=uuid.uuid4(),
            user_id=user_id,
            conversation_id=conv.id,
            query=pending_run.query if pending_run else query,
            intent=serialize_for_jsonb(intent),
            status="needs_clarification",
            clarification_state=serialize_for_jsonb(validation_result.partial_state),
            clarification_history=serialize_for_jsonb(clarification_history),
        )
        
        if not pending_run:
            db.add(run)
        
        # Store the missing parameters and question for next turn
        merged_state["_last_question"] = clarification_question
        merged_state["_missing_parameters"] = validation_result.missing_parameters
        run.clarification_state = serialize_for_jsonb(merged_state)
        run.status = "needs_clarification"
        
        await db.commit()
        await save_message(
            db,
            conversation_id=conv.id,
            role="assistant",
            content=clarification_question,
            structured_context={
                "status": "needs_clarification",
                "missing_parameters": validation_result.missing_parameters,
                "partial_state": validation_result.partial_state,
            },
        )

        resolved_fields = [k for k, v in validation_result.partial_state.items() if v not in (None, "")]
        return {
            "status": "needs_clarification",
            "conversation_id": str(conv.id),
            "orchestration_id": str(run.id),
            "clarification": {
                "question": clarification_question,
                "missing_fields": [p["parameter"] for p in validation_result.missing_parameters],
                "candidates": [],
                "progress": {
                    "resolved": len(resolved_fields),
                    "total": len(validation_result.missing_parameters) + len(resolved_fields),
                },
            },
        }

    # ====================================================================================
    # STEP 8: ALL PARAMETERS COMPLETE - UPDATE INTENT WITH ACCUMULATED STATE
    # ====================================================================================
    logger.info(f"All parameters validated. Proceeding with execution. Intent: {intent.intent}, Entities: {intent.entities}")
    
    # Merge accumulated state into intent entities
    clean_state = {k: v for k, v in merged_state.items() if not k.startswith("_")}
    intent.entities.update(clean_state)

    # Update pending run status if it exists
    if pending_run:
        pending_run.status = "ready"
        pending_run.intent = serialize_for_jsonb(intent)
        pending_run.clarification_state = serialize_for_jsonb(merged_state)
        await db.commit()

    # ====================================================================================
    # STEP 9: GENERATE EXECUTION PLAN (DAG)
    # ====================================================================================
    plan = await generate_execution_plan(pending_run.query if pending_run else query, intent=intent, conversation_history=history, llm_provider=llm_provider)
    # Apply only explicit, already-resolved entities across service-specific
    # argument names. This prevents the planner omitting a share recipient
    # while retaining the no-guessing policy.
    plan = enrich_plan_with_resolved_entities(plan, intent)

    # ====================================================================================
    # STEP 10: CREATE OR UPDATE ORCHESTRATION RUN
    # ====================================================================================
    run = pending_run or OrchestrationRun(
        id=uuid.uuid4(),
        user_id=user_id,
        conversation_id=conv.id,
        query=query,
        intent=serialize_for_jsonb(intent),
        plan=serialize_for_jsonb(plan),
        status="running",
        clarification_state=serialize_for_jsonb(merged_state),
        clarification_history=serialize_for_jsonb(clarification_history),
    )
    
    if not pending_run:
        db.add(run)
    else:
        run.plan = serialize_for_jsonb(plan)
        run.status = "running"
    
    await db.commit()
    await db.refresh(run)

    # ====================================================================================
    # STEP 11: EXECUTE DAG VIA DAGExecutor
    # ====================================================================================
    executor = DAGExecutor(db, user_id=user_id, run_id=run.id)
    exec_result = await executor.execute_plan(plan, conversation_id=conv.id)

    # ====================================================================================
    # STEP 12: HANDLE CONFIRMATION GATE
    # ====================================================================================
    if exec_result["status"] == "needs_confirmation":
        pending_actions = exec_result.get("pending_actions", [])
        if not pending_actions and exec_result.get("pending_action"):
            pending_actions = [exec_result["pending_action"]]

        confirm_msg = "Please review and approve the following actions before I execute them:"
        
        run.status = "needs_confirmation"
        await db.commit()

        actions_taken_info = [
            {"step_id": sid, "status": st} for sid, st in exec_result.get("step_statuses", {}).items()
        ]

        await save_message(
            db,
            conversation_id=conv.id,
            role="assistant",
            content=confirm_msg,
            structured_context=jsonable_encoder({
                "status": "needs_confirmation",
                "orchestration_id": str(run.id),
                "pending_actions": pending_actions,
                "actions_taken": actions_taken_info,
            }),
        )

        return {
            "status": "needs_confirmation",
            "conversation_id": str(conv.id),
            "orchestration_id": str(run.id),
            "response": confirm_msg,
            "pending_actions": pending_actions,
            "actions_taken": actions_taken_info,
        }

    # ====================================================================================
    # STEP 13: SYNTHESIZE FINAL RESPONSE
    # ====================================================================================
    completed_outputs = exec_result.get("completed_outputs", {})
    step_statuses = exec_result.get("step_statuses", {})
    
    final_response = await synthesize_response(
        query=pending_run.query if pending_run else query,
        intent=intent,
        completed_outputs=completed_outputs,
        step_statuses=step_statuses,
        llm_provider=llm_provider,
    )

    run.status = exec_result["status"]
    run.completed_at = datetime.utcnow() if exec_result["status"] in ("completed", "failed") else None
    await db.commit()

    action_errors = exec_result.get("step_errors", {})
    actions_taken_info = [
        {
            "step_id": sid,
            "status": st,
            "output": completed_outputs.get(sid),
            "error": action_errors.get(sid),
        }
        for sid, st in step_statuses.items()
    ]

    await save_message(
        db,
        conversation_id=conv.id,
        role="assistant",
        content=final_response,
        structured_context=jsonable_encoder({
            "status": exec_result["status"],
            "actions_taken": actions_taken_info,
        }),
    )

    return {
        "status": exec_result["status"],
        "conversation_id": str(conv.id),
        "orchestration_id": str(run.id),
        "response": final_response,
        "actions_taken": actions_taken_info,
    }
