# create an execution plan
import json
import logging
import re
from typing import Any, Optional
from pydantic import ValidationError

from app.integrations.llm import llm_chat_completion
from app.orchestration.models import ExecutionPlan, IntentClassification, PlanStep
from app.tools.registry import tool_registry
from app.utils.json_parser import extract_and_parse_json

logger = logging.getLogger(__name__)

PLANNER_SYSTEM_PROMPT = """You are an expert Query Planner for a Google Workspace Orchestrator.
Your task is to take a classified intent, extracted entities, temporal constraints, and user query, and construct a valid Execution Plan DAG (Directed Acyclic Graph).

STRICT JSON OUTPUT REQUIREMENT:
1. Output EXACTLY ONE JSON object matching the ExecutionPlan schema below.
2. Do NOT output markdown code fences (like ```json), intro text, commentary, or postscript explanations.
3. Use ONLY tool names present in the REGISTERED TOOLS list. Never invent or synthesize tool names.
4. Keep the plan minimal (maximum 10 steps).
5. NEVER invent missing values. Use only values explicitly present in the user request or supplied Context. Missing write parameters must be clarified before a write step is created.

REGISTERED TOOLS:
{registered_tools_json}

CRITICAL: EXPLICIT FIELD MAPPING REQUIREMENT
All dependency references MUST include explicit field paths. The executor will NEVER guess which field to extract.

TOOL OUTPUT SCHEMAS (use these for field references):
- drive.search_files → [{{"external_id": "...", "title": "...", "mime_type": "...", "metadata": {{"web_view_link": "...", ...}}, ...}}]
- drive.share_file → {{"external_id": "...", "web_view_link": "...", "permission_id": "...", ...}}
- gmail.search_emails → [{{"message_id": "...", "subject": "...", "from": "...", "date": "...", ...}}]
- gmail.send_email → {{"message_id": "...", "thread_id": "...", ...}}
- calendar.create_event → {{"event_id": "...", "html_link": "...", "start": "...", "end": "...", ...}}
- calendar.search_events → [{{"event_id": "...", "summary": "...", "start": "...", "end": "...", ...}}]

EXAMPLES OF REQUIRED EXPLICIT FIELD REFERENCES:
✅ CORRECT: "$steps.search_resume[0].external_id" (search returns list, access first item)
✅ CORRECT: "$steps.search_resume[0].metadata.web_view_link" (nested field access)
✅ CORRECT: "$steps.share_resume.web_view_link" (share returns dict, direct field)
✅ CORRECT: "$steps.create_meeting.html_link" (direct field from dict result)
❌ WRONG: "$steps.search_resume" (ambiguous - which field?)
❌ WRONG: "$search_resume" (missing explicit field path)
❌ WRONG: "$steps.search_resume.result[0].external_id" (incorrect - no .result wrapper)

MULTI-SERVICE ORCHESTRATION RULES:
1. When the user request involves multiple actions (e.g. creating a meeting, searching/sharing a file in Drive, and sending an email):
   - Step for finding file: 'drive.search_files' (returns list of files)
   - Step for sharing file: 'drive.share_file' with external_id="$steps.<search_step>[0].external_id"
   - Step for creating calendar event: 'calendar.create_event' (returns dict)
   - Step for sending email: 'gmail.send_email' with body referencing "$steps.<share_step>.web_view_link" and "$steps.<calendar_step>.html_link"
2. EMAIL SEND vs DRAFT RULE (CRITICAL - HIGHEST PRIORITY):
   ⚠️ ALWAYS prefer 'gmail.send_email' unless explicitly told to create a draft.
   
   USE 'gmail.send_email' when user says:
   - "send", "send email", "send an email", "email someone"
   - "invite", "send invitation", "notify"
   - "mail", "message"
   - ANY action verb indicating delivery/transmission
   - If the request is part of a workflow with approval, the approval happens BEFORE sending
   
   USE 'gmail.draft_email' ONLY when user EXPLICITLY says:
   - "draft", "create a draft", "prepare a draft"
   - "compose only", "save draft", "don't send"
   - Clear indication to NOT send
   
   EXAMPLES:
   ✅ "Send an email to..." → gmail.send_email
   ✅ "Send invitation email..." → gmail.send_email  
   ✅ "Email them about..." → gmail.send_email
   ✅ "Notify via email..." → gmail.send_email
   ❌ "Draft an email to..." → gmail.draft_email
   ❌ "Prepare a draft for..." → gmail.draft_email
   
   DEFAULT: If ambiguous, use 'gmail.send_email' (confirmation gate will protect user)
3. Dependencies: Add dependencies ONLY when a step strictly requires the output of a prior step.
4. ALL dependency references MUST use explicit JSONPath field syntax: "$steps.<step_id>[<index>].<field>" or "$steps.<step_id>.<field>".

REQUIRED JSON OUTPUT SCHEMA:
{{
  "goal": "<string description of plan goal>",
  "steps": [
    {{
      "id": "<unique_step_id_string>",
      "tool": "<registered_tool_name>",
      "arguments": {{
        "<arg_name>": "<arg_value or $steps.<step_id>[0].<field>>"
      }},
      "depends_on": ["<dependency_step_id>"]
    }}
  ]
}}
"""


def is_write_or_multi_service_intent(query: str, intent: IntentClassification) -> bool:
    """Check if query or intent represents a write operation or multi-service request."""
    q_low = query.lower()
    write_keywords = [
        "send", "create", "delete", "update", "draft", "move", "schedule", "invite", "share", "attach"
    ]
    if any(w in q_low for w in write_keywords):
        return True
    if len(intent.services) > 1:
        return True
    if intent.intent in ("send_email", "draft_email", "create_event", "update_event", "delete_event", "prepare_meeting"):
        return True
    return False


def validate_plan_schema_and_tools(plan: ExecutionPlan) -> None:
    """Validate that all tool names exist in registry and step dependencies are valid."""
    step_ids = {s.id for s in plan.steps}
    if len(step_ids) != len(plan.steps):
        raise ValueError("Duplicate step IDs found in execution plan.")

    registered_tool_names = {t["name"] for t in tool_registry.list_tools()}

    for s in plan.steps:
        if s.tool not in registered_tool_names:
            raise ValueError(f"Tool '{s.tool}' in step '{s.id}' is not a registered tool. Registered tools: {sorted(registered_tool_names)}")
        tool_obj = tool_registry.get_tool(s.tool)
        s.requires_confirmation = tool_obj.requires_confirmation
        for dep in s.depends_on:
            if dep not in step_ids:
                raise ValueError(f"Step '{s.id}' depends on step '{dep}', which does not exist in the plan.")


async def generate_execution_plan(
    query: str,
    intent: IntentClassification,
    conversation_history: list[dict[str, str]],
    llm_provider: str = "gemini",
) -> ExecutionPlan:
    """Generate typed ExecutionPlan DAG using registered tools."""
    tools_list = tool_registry.list_tools()
    tools_json = json.dumps(tools_list, indent=2)

    system_prompt = PLANNER_SYSTEM_PROMPT.format(registered_tools_json=tools_json)

    conversation_context = "\n".join(
        f"{entry['role']}: {entry['content']}" for entry in conversation_history
    )
    context_str = (
        f"Intent: {intent.intent}\nServices: {intent.services}\nEntities: {intent.entities}\n"
        f"Temporal: {intent.temporal}\nConversation history:\n{conversation_context}"
    )
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"User Query: '{query}'\nContext:\n{context_str}"},
    ]

    last_error: Optional[Exception] = None

    for attempt in range(2):
        raw_response = ""
        try:
            raw_response = await llm_chat_completion(messages, provider=llm_provider, temperature=0.0)

            logger.info(f"--- [Planner Attempt {attempt + 1}] RAW LLM RESPONSE ---\n{raw_response}\n-----------------------------------------")

            parsed, clean_json, parse_err = extract_and_parse_json(raw_response)
            logger.info(f"--- [Planner Attempt {attempt + 1}] CLEANED JSON ---\n{clean_json}\n-----------------------------------------")

            if parse_err:
                raise ValueError(f"JSON extraction failed: {parse_err}")

            plan = ExecutionPlan(**parsed)
            validate_plan_schema_and_tools(plan)
            
            logger.info(f"--- [Planner Attempt {attempt + 1}] PARSED PLAN ---\n{plan.model_dump()}\n-----------------------------------------")
            return plan

        except Exception as exc:
            last_error = exc
            if isinstance(exc, GeminiRateLimitError):
                logger.warning(f"Gemini quota limit reached ({exc}).")
                if is_write_or_multi_service_intent(query, intent):
                    raise ValueError(f"Quota limit reached during multi-service planning: {exc}")
                return _build_fallback_plan(query, intent)

            validation_detail = str(exc)
            if isinstance(exc, ValidationError):
                validation_detail = json.dumps(exc.errors(), indent=2)

            logger.warning(f"Planner attempt {attempt + 1} failed: {exc} | Detail: {validation_detail}")
            
            if attempt == 1:
                logger.error(f"Planner failed all attempts. Strict fallback policy evaluation for query: '{query}'")
                # STRICT FALLBACK POLICY: Do NOT downgrade write/multi-service queries to retrieval
                if is_write_or_multi_service_intent(query, intent):
                    logger.error(f"Refusing to downgrade write/multi-service request '{query}' to search retrieval.")
                    raise ValueError(f"Failed to generate execution plan for request '{query}': {exc}")
                
                return _build_fallback_plan(query, intent)

            messages.append({"role": "assistant", "content": raw_response})
            messages.append({
                "role": "user",
                "content": f"Your previous plan was invalid or violated schema/tool names: {exc}. Output ONLY valid JSON matching schema and registered tools without markdown fences.",
            })

    if is_write_or_multi_service_intent(query, intent):
        raise ValueError(f"Failed to generate execution plan for request '{query}': {last_error}")

    return _build_fallback_plan(query, intent)


def extract_requested_limit(text: str, default_limit: int = 5) -> int:
    """Extract explicit numeric limit requested in user query (e.g., 'last 3 emails' -> 3)."""
    if not text:
        return default_limit

    clean = text.lower().strip()

    if re.search(r"\b(newest|latest|last)\s+(email|mail|message|event|file)\b", clean):
        return 1

    match_num = re.search(r"\b(last|latest|recent|newest|top)\s+(\d+)\b", clean)
    if match_num:
        return max(1, min(50, int(match_num.group(2))))

    match_count = re.search(r"\b(\d+)\s+(mails|emails|messages|events|files)\b", clean)
    if match_count:
        return max(1, min(50, int(match_count.group(1))))

    return default_limit


def _build_fallback_plan(query: str, intent: IntentClassification) -> ExecutionPlan:
    """Construct minimal fallback plan with extracted limit for pure retrieval queries."""
    limit = extract_requested_limit(query, default_limit=5)
    steps = []
    if "gmail" in intent.services or not intent.services:
        steps.append(
            PlanStep(
                id="search_gmail",
                tool="gmail.search_emails",
                arguments={"query": query, "limit": limit, "sort": "newest"},
            )
        )
    if "calendar" in intent.services:
        steps.append(
            PlanStep(
                id="search_calendar",
                tool="calendar.search_events",
                arguments={"query": query, "limit": limit},
            )
        )
    if "drive" in intent.services:
        steps.append(
            PlanStep(
                id="search_drive",
                tool="drive.search_files",
                arguments={"query": query, "limit": limit},
            )
        )

    if not steps:
        steps.append(
            PlanStep(
                id="search_gmail",
                tool="gmail.search_emails",
                arguments={"query": query, "limit": limit, "sort": "newest"},
            )
        )

    return ExecutionPlan(goal=f"Search workspace for {query}", steps=steps)
