# basically like if u gave clarification once and missed a few things it keep that in mind and ask for those things in the next clarification round. It never forgets what it has already clarified and resolved. It accumulates all resolved parameters across multiple turns and never resets or loses them. 
# It also re-classifies intent with full context of previous clarifications to ensure accurate understanding of user intent.


"""
Iterative clarification engine that accumulates information across multiple conversation turns.
Never restarts workflows - always resumes and enhances existing clarification state.
Supports unlimited clarification rounds with full context preservation.
"""
import logging
from typing import Any, Optional
from datetime import datetime

from app.orchestration.models import IntentClassification
from app.orchestration.classifier import classify_intent
from app.orchestration.context import merge_clarification_state, append_clarification_turn

logger = logging.getLogger(__name__)


class ClarificationEngine:
    """
    Manages iterative clarification across multiple conversation turns.
    Accumulates resolved parameters and tracks clarification history.
    """

    @staticmethod
    async def merge_clarification_response(
        original_query: str,
        clarification_response: str,
        existing_state: Optional[dict[str, Any]],
        existing_intent: Optional[dict[str, Any]],
        conversation_history: list[dict[str, str]],
        user_timezone: str = "UTC",
        llm_provider: str = "gemini",
    ) -> tuple[IntentClassification, dict[str, Any], list[dict[str, Any]]]:
        """
        Merge new clarification response into existing workflow state.
        
        This method:
        1. Accumulates all previously resolved parameters
        2. Re-classifies intent with full conversation context
        3. Merges newly extracted entities with existing state
        4. Records clarification turn in history
        5. Never loses or resets previously resolved parameters
        
        Args:
            original_query: The original user request
            clarification_response: User's response to clarification question
            existing_state: Accumulated clarification state from previous turns
            existing_intent: Previously classified intent
            conversation_history: Full conversation history
            user_timezone: User's timezone
            llm_provider: LLM provider to use
        
        Returns:
            Tuple of (updated_intent, merged_state, clarification_history)
        """
        # Initialize state from existing accumulated state
        merged_state = existing_state.copy() if existing_state else {}
        last_question = merged_state.get("_last_question", "")
        
        # Build context-aware query for re-classification
        context_parts = [f"Original request: {original_query}"]
        
        # Add clarification history context
        clarification_history = merged_state.get("_history", [])
        if clarification_history:
            context_parts.append("\nPrevious clarifications:")
            for entry in clarification_history:
                q = entry.get("question", "")
                r = entry.get("response", "")
                if q and r:
                    context_parts.append(f"- Q: {q}")
                    context_parts.append(f"  A: {r}")
        
        # Add current clarification
        if last_question:
            context_parts.append(f"\nCurrent question: {last_question}")
        context_parts.append(f"User's answer: {clarification_response}")
        
        # Reconstruct full context query
        full_context_query = "\n".join(context_parts)

        # Re-classify intent with accumulated context
        logger.info(f"Re-classifying intent with {len(clarification_history)} previous turns of context")
        logger.debug(f"Full context query: {full_context_query}")
        
        updated_intent = await classify_intent(
            full_context_query,
            conversation_history=conversation_history,
            user_timezone=user_timezone,
            llm_provider=llm_provider,
        )

        # Merge entities: old entities first, then new entities (new takes precedence)
        if existing_intent:
            old_entities = existing_intent.get("entities", {})
            logger.debug(f"Preserving old entities: {old_entities}")
            merged_state = merge_clarification_state(merged_state, old_entities)

        if updated_intent.entities:
            logger.debug(f"Merging new entities: {updated_intent.entities}")
            merged_state = merge_clarification_state(merged_state, updated_intent.entities)

        # Record this clarification turn in history
        merged_state = append_clarification_turn(
            clarification_state=merged_state,
            question=last_question,
            response=clarification_response,
            extracted_entities=updated_intent.entities or {},
        )

        # Update clarification history reference
        clarification_history = merged_state.get("_history", [])
        
        # Remove internal tracking fields from intent entities
        clean_entities = {k: v for k, v in merged_state.items() if not k.startswith("_")}
        updated_intent.entities = clean_entities

        logger.info(
            f"Clarification merge complete. "
            f"Total turns: {len(clarification_history)}, "
            f"Resolved parameters: {list(clean_entities.keys())}"
        )

        return updated_intent, merged_state, clarification_history

    @staticmethod
    def extract_simple_responses(clarification_response: str, missing_parameters: list[dict[str, Any]]) -> dict[str, Any]:
        """
        Extract simple parameter values from user response using heuristics.
        Used as fallback when LLM re-classification doesn't extract entities.
        
        Args:
            clarification_response: User's clarification text
            missing_parameters: List of parameters that were requested
        
        Returns:
            Dictionary of extracted parameter values
        """
        extracted = {}
        response_lower = clarification_response.lower().strip()

        # If only one parameter was missing, assume the entire response is the value
        if len(missing_parameters) == 1:
            param_name = missing_parameters[0].get("parameter")
            if param_name:
                # Clean up the response
                extracted[param_name] = clarification_response.strip()
                logger.info(f"Extracted single parameter '{param_name}': {extracted[param_name]}")

        # Email detection
        if "@" in clarification_response:
            import re
            email_match = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', clarification_response)
            if email_match:
                extracted["recipient"] = email_match.group(0)
                extracted["attendee"] = email_match.group(0)  # For calendar events
                logger.info(f"Extracted email: {email_match.group(0)}")

        # Time expressions
        time_keywords = ["am", "pm", "o'clock", ":", "tomorrow", "today", "next", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
        if any(keyword in response_lower for keyword in time_keywords):
            extracted["start_time"] = clarification_response.strip()
            logger.info(f"Extracted time expression: {clarification_response.strip()}")

        # Duration
        duration_keywords = ["minute", "hour", "min", "hr"]
        if any(keyword in response_lower for keyword in duration_keywords):
            extracted["duration"] = clarification_response.strip()
            logger.info(f"Extracted duration: {clarification_response.strip()}")

        return extracted
