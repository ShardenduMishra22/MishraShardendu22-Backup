# L7 Rate limiting middleware for FastAPI using Redis to enforce a 
# fixed window of 100 queries per user per hour on the /api/v1/query endpoint.

import logging
import time
from fastapi import Request, Response, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from app.redis import redis_client

logger = logging.getLogger(__name__)

RATE_LIMIT_QUERIES_PER_HOUR = 100


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Redis-backed fixed-window rate limiter middleware enforcing 100 queries/user/hour on /api/v1/query."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        if request.method == "POST" and request.url.path == "/api/v1/query":
            # Extract user_id or X-User-ID or query parameter
            user_id = request.headers.get("X-User-ID") or request.query_params.get("user_id") or "anonymous_dev_user"
            
            hour_window = int(time.time() // 3600)
            redis_key = f"rate_limit:query:{user_id}:{hour_window}"

            try:
                pipe = redis_client.pipeline()
                pipe.incr(redis_key)
                pipe.expire(redis_key, 3600)
                results = await pipe.execute()

                current_count = results[0]

                if current_count > RATE_LIMIT_QUERIES_PER_HOUR:
                    logger.warning(f"Rate limit exceeded for user '{user_id}': {current_count}/{RATE_LIMIT_QUERIES_PER_HOUR}")
                    return JSONResponse(
                        status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                        content={"detail": "Rate limit exceeded (100 queries/hour per user). Please try again later."},
                    )
            except Exception as exc:
                # Log redis error and gracefully pass request
                logger.warning(f"Rate limiter Redis check failed ({exc}), allowing request.")

        return await call_next(request)
