# gmail tools for searching, retrieving, creating, updating, and deleting Gmail messages and drafts.
import uuid
from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import GoogleAccount, WorkspaceItem
from app.retrieval.models import SearchFilters
from app.retrieval.search import search_workspace
from app.tools.base import Tool, ToolExecutionError
from app.tools.registry import tool_registry

# --- 1. gmail.search_emails ---

class GmailSearchInput(BaseModel):
    query: Optional[str] = Field(None, description="Natural language, keyword search query, or subject filter for emails")
    sender: Optional[str] = Field(None, description="Sender email address filter")
    recipient: Optional[str] = Field(None, description="Recipient email address filter")
    date_from: Optional[datetime] = Field(None, description="Start date filter")
    date_to: Optional[datetime] = Field(None, description="End date filter")
    sort: str = Field("newest", description="Sorting order: 'newest' or 'relevance'")
    limit: int = Field(5, ge=1, le=50, description="Max results to return")


class GmailSearchTool(Tool):
    name = "gmail.search_emails"
    description = "Search indexed Gmail messages using structured metadata, lexical FTS, or semantic hybrid search."
    input_model = GmailSearchInput
    read_only = True
    requires_confirmation = False

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> list[dict[str, Any]]:
        inputs = self.input_model(**kwargs)
        filters = SearchFilters(
            services=["gmail"],
            item_types=["email"],
            sender=inputs.sender,
            recipient=inputs.recipient,
            date_from=inputs.date_from,
            date_to=inputs.date_to,
        )
        results = await search_workspace(
            db, user_id=user_id, query=inputs.query or "", filters=filters, limit=inputs.limit
        )
        return [r.model_dump() for r in results]


# --- 2. gmail.get_email ---

class GmailGetInput(BaseModel):
    external_id: str = Field(..., description="Google Gmail message ID")


class GmailGetTool(Tool):
    name = "gmail.get_email"
    description = "Retrieve full details of a specific indexed Gmail message by its external ID."
    input_model = GmailGetInput
    read_only = True
    requires_confirmation = False

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        stmt = select(WorkspaceItem).where(
            WorkspaceItem.user_id == user_id,
            WorkspaceItem.service == "gmail",
            WorkspaceItem.external_id == inputs.external_id,
        )
        res = await db.execute(stmt)
        item = res.scalar_one_or_none()
        if not item:
            raise ToolExecutionError(f"Email with ID '{inputs.external_id}' was not found.")

        return {
            "item_id": str(item.id),
            "external_id": item.external_id,
            "title": item.title,
            "content": item.content,
            "metadata": item.metadata_ or {},
            "source_created_at": item.source_created_at.isoformat() if item.source_created_at else None,
        }


# --- 3. gmail.draft_email ---

class GmailDraftInput(BaseModel):
    to: str = Field(..., description="Recipient email address")
    subject: str = Field(..., description="Email subject line")
    body: str = Field(..., description="Email body text")


class GmailDraftTool(Tool):
    name = "gmail.draft_email"
    description = "Create a draft email in Gmail."
    input_model = GmailDraftInput
    read_only = False
    requires_confirmation = False  # Creating a draft is safe

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        if "@" not in inputs.to:
            raise ToolExecutionError(f"Invalid or missing recipient email address '{inputs.to}'. Please specify a valid email address.")

        stmt = select(GoogleAccount).where(GoogleAccount.user_id == user_id).order_by(GoogleAccount.updated_at.desc())
        res = await db.execute(stmt)
        google_acc = res.scalars().first()
        if not google_acc:
            raise ToolExecutionError("No connected Google account found for current user. Please authenticate via /api/v1/auth/google first.")

        from app.integrations.google.auth import get_valid_access_token
        from app.integrations.google.gmail import gmail_client

        token = await get_valid_access_token(db, google_acc)
        draft_res = await gmail_client.create_draft(token, to=inputs.to, subject=inputs.subject, body=inputs.body)

        return {
            "status": "draft_created",
            "to": inputs.to,
            "subject": inputs.subject,
            "draft_id": draft_res.get("id"),
            "message_id": draft_res.get("message", {}).get("id"),
            "message": "Draft created successfully via Gmail API.",
        }


# --- 4. gmail.send_email ---

class GmailSendInput(BaseModel):
    to: str = Field(..., description="Recipient email address")
    subject: str = Field(..., description="Email subject line")
    body: str = Field(..., description="Email body text")


class GmailSendTool(Tool):
    name = "gmail.send_email"
    description = "Send an email to a recipient via Gmail."
    input_model = GmailSendInput
    read_only = False
    requires_confirmation = True  # External side-effect requires human confirmation

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        if "@" not in inputs.to:
            raise ToolExecutionError(f"Invalid or missing recipient email address '{inputs.to}'. Please specify a valid recipient email address.")

        stmt = select(GoogleAccount).where(GoogleAccount.user_id == user_id).order_by(GoogleAccount.updated_at.desc())
        res = await db.execute(stmt)
        google_acc = res.scalars().first()
        if not google_acc:
            raise ToolExecutionError("No connected Google account found for current user. Please authenticate via /api/v1/auth/google first.")

        from app.integrations.google.auth import get_valid_access_token
        from app.integrations.google.gmail import gmail_client

        token = await get_valid_access_token(db, google_acc)
        send_res = await gmail_client.send_message(token, to=inputs.to, subject=inputs.subject, body=inputs.body)

        return {
            "status": "completed",
            "to": inputs.to,
            "subject": inputs.subject,
            "message_id": send_res.get("id"),
            "thread_id": send_res.get("threadId"),
            "message": "Email sent successfully via Gmail API.",
        }


# --- 5. gmail.update_labels ---

class GmailUpdateLabelsInput(BaseModel):
    external_id: str = Field(..., description="Gmail message ID")
    add_labels: list[str] = Field(default=[], description="List of labels to add")
    remove_labels: list[str] = Field(default=[], description="List of labels to remove")


class GmailUpdateLabelsTool(Tool):
    name = "gmail.update_labels"
    description = "Add or remove labels on a Gmail message."
    input_model = GmailUpdateLabelsInput
    read_only = False
    requires_confirmation = True

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        return {
            "status": "labels_updated",
            "external_id": inputs.external_id,
            "add_labels": inputs.add_labels,
            "remove_labels": inputs.remove_labels,
        }


# Register all Gmail tools
tool_registry.register_tool(GmailSearchTool())
tool_registry.register_tool(GmailGetTool())
tool_registry.register_tool(GmailDraftTool())
tool_registry.register_tool(GmailSendTool())
tool_registry.register_tool(GmailUpdateLabelsTool())
