# 
from abc import ABC, abstractmethod
import uuid
from typing import Any, Optional
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession


class ToolError(Exception):
    """Base exception for service tool operations."""
    pass


class ToolNotFoundError(ToolError):
    """Raised when an unknown tool name is requested."""
    pass



class ToolValidationError(ToolError):
    """Raised when tool inputs fail schema validation."""
    pass


class ToolExecutionError(ToolError):
    """Raised when tool execution fails."""
    pass


class Tool(ABC):
    """Abstract base class for all deterministic service tools."""

    name: str
    description: str
    read_only: bool = True
    input_model: type[BaseModel]
    output_model: Optional[type[BaseModel]] = None
    requires_confirmation: bool = False

    @abstractmethod
    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> Any:
        """Execute tool operation for a specific user within a database session."""
        pass
