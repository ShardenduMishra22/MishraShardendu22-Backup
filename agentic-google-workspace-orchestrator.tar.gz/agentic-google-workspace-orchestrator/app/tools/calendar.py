# Calender tools for searching, retrieving, creating, updating, and deleting Google Calendar events.
import uuid
from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import WorkspaceItem
from app.retrieval.models import SearchFilters
from app.retrieval.search import search_workspace
from app.tools.base import Tool, ToolExecutionError
from app.tools.registry import tool_registry

# --- 1. calendar.search_events ---

class CalendarSearchInput(BaseModel):
    query: str = Field(..., description="Natural language search query for calendar events")
    attendee: Optional[str] = Field(None, description="Filter by attendee email address")
    date_from: Optional[datetime] = Field(None, description="Start time range filter")
    date_to: Optional[datetime] = Field(None, description="End time range filter")
    limit: int = Field(5, ge=1, le=50, description="Max results to return")


class CalendarSearchTool(Tool):
    name = "calendar.search_events"
    description = "Search indexed Google Calendar events using hybrid semantic/lexical search."
    input_model = CalendarSearchInput
    read_only = True
    requires_confirmation = False

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> list[dict[str, Any]]:
        inputs = self.input_model(**kwargs)
        filters = SearchFilters(
            services=["calendar"],
            item_types=["calendar_event"],
            attendee=inputs.attendee,
            date_from=inputs.date_from,
            date_to=inputs.date_to,
        )
        results = await search_workspace(
            db, user_id=user_id, query=inputs.query, filters=filters, limit=inputs.limit
        )
        return [r.model_dump() for r in results]


# --- 2. calendar.get_event ---

class CalendarGetInput(BaseModel):
    external_id: str = Field(..., description="Google Calendar event ID")


class CalendarGetTool(Tool):
    name = "calendar.get_event"
    description = "Retrieve details of a specific indexed calendar event."
    input_model = CalendarGetInput
    read_only = True
    requires_confirmation = False

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        stmt = select(WorkspaceItem).where(
            WorkspaceItem.user_id == user_id,
            WorkspaceItem.service == "calendar",
            WorkspaceItem.external_id == inputs.external_id,
        )
        res = await db.execute(stmt)
        item = res.scalar_one_or_none()
        if not item:
            raise ToolExecutionError(f"Calendar event '{inputs.external_id}' was not found.")

        return {
            "item_id": str(item.id),
            "external_id": item.external_id,
            "title": item.title,
            "content": item.content,
            "metadata": item.metadata_ or {},
            "start": item.metadata_.get("start") if item.metadata_ else None,
            "end": item.metadata_.get("end") if item.metadata_ else None,
        }


# --- 3. calendar.create_event ---

class CalendarCreateInput(BaseModel):
    summary: str = Field(..., description="Event title/summary")
    start_time: str = Field(..., description="Start time (ISO 8601 string)")
    end_time: Optional[str] = Field(None, description="End time (ISO 8601 string)")
    description: Optional[str] = Field(None, description="Event description")
    location: Optional[str] = Field(None, description="Event location")
    attendees: list[str] = Field(default=[], description="List of attendee email addresses")
    timezone: Optional[str] = Field(None, description="Timezone string e.g. Asia/Kolkata")


class CalendarCreateTool(Tool):
    name = "calendar.create_event"
    description = "Create a new event in Google Calendar."
    input_model = CalendarCreateInput
    read_only = False
    requires_confirmation = True

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        from app.models.models import GoogleAccount
        from app.integrations.google.auth import get_valid_access_token
        from app.integrations.google.calendar import calendar_client

        stmt = select(GoogleAccount).where(GoogleAccount.user_id == user_id).order_by(GoogleAccount.updated_at.desc())
        res = await db.execute(stmt)
        google_acc = res.scalars().first()
        if not google_acc:
            raise ToolExecutionError("No connected Google account found for current user.")

        token = await get_valid_access_token(db, google_acc)
        event_res = await calendar_client.create_event(
            token,
            summary=inputs.summary,
            start_time=inputs.start_time,
            end_time=inputs.end_time,
            description=inputs.description,
            location=inputs.location,
            attendees=inputs.attendees,
            timezone_str=inputs.timezone,
        )

        return {
            "status": "completed",
            "summary": inputs.summary,
            "event_id": event_res.get("id"),
            "html_link": event_res.get("htmlLink"),
            "message": "Calendar event created successfully via Google Calendar API.",
        }


# --- 4. calendar.update_event ---

class CalendarUpdateInput(BaseModel):
    external_id: str = Field(..., description="Event ID to update")
    summary: Optional[str] = Field(None, description="Updated event title")
    start_time: Optional[str] = Field(None, description="Updated start time")
    end_time: Optional[str] = Field(None, description="Updated end time")


class CalendarUpdateTool(Tool):
    name = "calendar.update_event"
    description = "Update an existing Google Calendar event."
    input_model = CalendarUpdateInput
    read_only = False
    requires_confirmation = True

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        from app.models.models import GoogleAccount
        from app.integrations.google.auth import get_valid_access_token
        from app.integrations.google.calendar import calendar_client

        stmt = select(GoogleAccount).where(GoogleAccount.user_id == user_id).order_by(GoogleAccount.updated_at.desc())
        res = await db.execute(stmt)
        google_acc = res.scalars().first()
        if not google_acc:
            raise ToolExecutionError("No connected Google account found for current user.")

        token = await get_valid_access_token(db, google_acc)
        event_res = await calendar_client.update_event(
            token,
            event_id=inputs.external_id,
            summary=inputs.summary,
            start_time=inputs.start_time,
            end_time=inputs.end_time,
        )

        return {
            "status": "completed",
            "event_id": event_res.get("id"),
            "message": "Calendar event updated successfully via Google Calendar API.",
        }


# --- 5. calendar.delete_event ---

class CalendarDeleteInput(BaseModel):
    external_id: str = Field(..., description="Event ID to delete")


class CalendarDeleteTool(Tool):
    name = "calendar.delete_event"
    description = "Delete a Google Calendar event."
    input_model = CalendarDeleteInput
    read_only = False
    requires_confirmation = True

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        from app.models.models import GoogleAccount
        from app.integrations.google.auth import get_valid_access_token
        from app.integrations.google.calendar import calendar_client

        stmt = select(GoogleAccount).where(GoogleAccount.user_id == user_id).order_by(GoogleAccount.updated_at.desc())
        res = await db.execute(stmt)
        google_acc = res.scalars().first()
        if not google_acc:
            raise ToolExecutionError("No connected Google account found for current user.")

        token = await get_valid_access_token(db, google_acc)
        await calendar_client.delete_event(token, event_id=inputs.external_id)

        return {
            "status": "completed",
            "external_id": inputs.external_id,
            "message": "Calendar event deleted successfully via Google Calendar API.",
        }


# Register all Calendar tools
tool_registry.register_tool(CalendarSearchTool())
tool_registry.register_tool(CalendarGetTool())
tool_registry.register_tool(CalendarCreateTool())
tool_registry.register_tool(CalendarUpdateTool())
tool_registry.register_tool(CalendarDeleteTool())
