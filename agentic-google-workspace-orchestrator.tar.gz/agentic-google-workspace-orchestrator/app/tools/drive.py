# drive tools for searching, retrieving, creating, updating, and deleting Google Drive files and folders.+-
import uuid
from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import WorkspaceItem
from app.retrieval.models import SearchFilters
from app.retrieval.search import search_workspace
from app.tools.base import Tool, ToolExecutionError
from app.tools.registry import tool_registry

# --- 1. drive.search_files ---

class DriveSearchInput(BaseModel):
    query: str = Field(..., description="Natural language search query for Drive files")
    mime_type: Optional[str] = Field(None, description="MIME type filter (e.g., application/pdf)")
    date_from: Optional[datetime] = Field(None, description="Start date filter")
    date_to: Optional[datetime] = Field(None, description="End date filter")
    limit: int = Field(5, ge=1, le=50, description="Max results to return")


class DriveSearchTool(Tool):
    name = "drive.search_files"
    description = "Search indexed Google Drive documents using hybrid semantic/lexical search."
    input_model = DriveSearchInput
    read_only = True
    requires_confirmation = False

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> list[dict[str, Any]]:
        inputs = self.input_model(**kwargs)
        filters = SearchFilters(
            services=["drive"],
            item_types=["drive_file"],
            mime_type=inputs.mime_type,
            date_from=inputs.date_from,
            date_to=inputs.date_to,
        )
        results = await search_workspace(
            db, user_id=user_id, query=inputs.query, filters=filters, limit=inputs.limit
        )
        if results:
            return [r.model_dump() for r in results]

        # Live Drive API Fallback if local index search returned 0 items
        try:
            from app.models.models import GoogleAccount
            from app.integrations.google.auth import get_valid_access_token
            from app.integrations.google.drive import drive_client

            stmt = select(GoogleAccount).where(GoogleAccount.user_id == user_id).order_by(GoogleAccount.updated_at.desc())
            res = await db.execute(stmt)
            google_acc = res.scalars().first()
            if google_acc:
                token = await get_valid_access_token(db, google_acc)
                live_files = await drive_client.fetch_recent_files(token, max_results=50)

                q_low = inputs.query.lower()
                is_resume_query = any(k in q_low for k in ("resume", "cv", "curriculum"))
                matched_files = []

                for f in live_files:
                    fname = (f.get("name") or "").lower()
                    fmime = (f.get("mime_type") or "").lower()
                    if is_resume_query:
                        if any(term in fname for term in ("resume", "cv", "curriculum")) or ("pdf" in fmime):
                            matched_files.append({
                                "item_id": f.get("external_id"),
                                "service": "drive",
                                "item_type": "drive_file",
                                "external_id": f.get("external_id"),
                                "title": f.get("name"),
                                "content": f.get("content", ""),
                                "metadata": {"web_view_link": f.get("web_view_link"), "mime_type": f.get("mime_type")},
                                "score": 0.95,
                                "retrieval_method": "live_drive_api",
                            })
                    elif q_low in fname or any(tok in fname for tok in q_low.split() if len(tok) > 2):
                        matched_files.append({
                            "item_id": f.get("external_id"),
                            "service": "drive",
                            "item_type": "drive_file",
                            "external_id": f.get("external_id"),
                            "title": f.get("name"),
                            "content": f.get("content", ""),
                            "metadata": {"web_view_link": f.get("web_view_link"), "mime_type": f.get("mime_type")},
                            "score": 0.90,
                            "retrieval_method": "live_drive_api",
                        })

                if matched_files:
                    return matched_files[:inputs.limit]
        except Exception as exc:
            import logging
            logging.getLogger(__name__).warning(f"Live Google Drive API fallback search failed: {exc}")

        return []


# --- 2. drive.get_file ---

class DriveGetInput(BaseModel):
    external_id: str = Field(..., description="Google Drive file ID")


class DriveGetTool(Tool):
    name = "drive.get_file"
    description = "Retrieve details of a specific indexed Drive file."
    input_model = DriveGetInput
    read_only = True
    requires_confirmation = False

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        stmt = select(WorkspaceItem).where(
            WorkspaceItem.user_id == user_id,
            WorkspaceItem.service == "drive",
            WorkspaceItem.external_id == inputs.external_id,
        )
        res = await db.execute(stmt)
        item = res.scalar_one_or_none()
        if not item:
            raise ToolExecutionError(f"Drive file '{inputs.external_id}' was not found.")

        return {
            "item_id": str(item.id),
            "external_id": item.external_id,
            "title": item.title,
            "content": item.content,
            "metadata": item.metadata_ or {},
        }


# --- 3. drive.share_file ---

class DriveShareInput(BaseModel):
    external_id: Optional[str] = Field(None, description="File ID to share")
    file_id: Optional[str] = Field(None, description="File ID to share (alias)")
    target_email: Optional[str] = Field(None, description="User email address to share file with")
    email: Optional[str] = Field(None, description="User email address to share file with (alias)")
    role: str = Field("reader", description="Permission role: reader, commenter, writer")


class DriveShareTool(Tool):
    name = "drive.share_file"
    description = "Share a Google Drive file with another user."
    input_model = DriveShareInput
    read_only = False
    requires_confirmation = True

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        target_file_id = inputs.file_id or inputs.external_id
        target_email_addr = inputs.email or inputs.target_email
        if not target_file_id:
            raise ToolExecutionError("drive.share_file requires 'file_id' or 'external_id'.")
        if not target_email_addr:
            raise ToolExecutionError("drive.share_file requires 'email' or 'target_email'.")

        from app.models.models import GoogleAccount
        from app.integrations.google.auth import get_valid_access_token
        from app.integrations.google.drive import drive_client

        stmt = select(GoogleAccount).where(GoogleAccount.user_id == user_id).order_by(GoogleAccount.updated_at.desc())
        res = await db.execute(stmt)
        google_acc = res.scalars().first()
        if not google_acc:
            raise ToolExecutionError("No connected Google account found for current user.")

        token = await get_valid_access_token(db, google_acc)
        share_res = await drive_client.share_file(
            token, file_id=target_file_id, email=target_email_addr, role=inputs.role
        )

        web_view_link = f"https://drive.google.com/file/d/{target_file_id}/view"
        return {
            "status": "completed",
            "external_id": target_file_id,
            "permission_id": share_res.get("id"),
            "target_email": target_email_addr,
            "web_view_link": web_view_link,
            "share_link": web_view_link,
            "message": f"File shared successfully via Google Drive API: {web_view_link}",
        }


# --- 4. drive.create_folder ---

class DriveCreateFolderInput(BaseModel):
    folder_name: str = Field(..., description="Folder name")
    parent_id: Optional[str] = Field(None, description="Parent folder ID")


class DriveCreateFolderTool(Tool):
    name = "drive.create_folder"
    description = "Create a new folder in Google Drive."
    input_model = DriveCreateFolderInput
    read_only = False
    requires_confirmation = True

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        from app.models.models import GoogleAccount
        from app.integrations.google.auth import get_valid_access_token
        from app.integrations.google.drive import drive_client

        stmt = select(GoogleAccount).where(GoogleAccount.user_id == user_id).order_by(GoogleAccount.updated_at.desc())
        res = await db.execute(stmt)
        google_acc = res.scalars().first()
        if not google_acc:
            raise ToolExecutionError("No connected Google account found for current user.")

        token = await get_valid_access_token(db, google_acc)
        folder_res = await drive_client.create_folder(
            token, folder_name=inputs.folder_name, parent_id=inputs.parent_id
        )

        return {
            "status": "completed",
            "folder_name": inputs.folder_name,
            "folder_id": folder_res.get("id"),
            "message": "Drive folder created successfully via Google Drive API.",
        }


# --- 5. drive.move_file ---

class DriveMoveFileInput(BaseModel):
    external_id: str = Field(..., description="File ID to move")
    target_folder_id: str = Field(..., description="Destination folder ID")


class DriveMoveFileTool(Tool):
    name = "drive.move_file"
    description = "Move a file to a specified folder in Google Drive."
    input_model = DriveMoveFileInput
    read_only = False
    requires_confirmation = True

    async def execute(self, db: AsyncSession, user_id: uuid.UUID, **kwargs) -> dict[str, Any]:
        inputs = self.input_model(**kwargs)
        from app.models.models import GoogleAccount
        from app.integrations.google.auth import get_valid_access_token
        from app.integrations.google.drive import drive_client

        stmt = select(GoogleAccount).where(GoogleAccount.user_id == user_id).order_by(GoogleAccount.updated_at.desc())
        res = await db.execute(stmt)
        google_acc = res.scalars().first()
        if not google_acc:
            raise ToolExecutionError("No connected Google account found for current user.")

        token = await get_valid_access_token(db, google_acc)
        await drive_client.move_file(
            token, file_id=inputs.external_id, destination_folder_id=inputs.target_folder_id
        )

        return {
            "status": "completed",
            "external_id": inputs.external_id,
            "target_folder_id": inputs.target_folder_id,
            "message": "File moved successfully via Google Drive API.",
        }


# Register all Drive tools
tool_registry.register_tool(DriveSearchTool())
tool_registry.register_tool(DriveGetTool())
tool_registry.register_tool(DriveShareTool())
tool_registry.register_tool(DriveCreateFolderTool())
tool_registry.register_tool(DriveMoveFileTool())
