# Registry for managing and inspecting deterministic service tools.
import logging
from typing import Any, Optional
from app.tools.base import Tool, ToolNotFoundError

logger = logging.getLogger(__name__)


class ToolRegistry:
    """Registry for managing and inspecting deterministic service tools."""

    def __init__(self):
        self._tools: dict[str, Tool] = {}

    def register_tool(self, tool: Tool) -> None:
        """Register a tool instance."""
        if tool.name in self._tools:
            logger.warning(f"Overwriting existing tool registration for '{tool.name}'.")
        self._tools[tool.name] = tool
        logger.debug(f"Registered tool: {tool.name}")

    def get_tool(self, name: str) -> Tool:
        """Retrieve tool by registered name or raise ToolNotFoundError."""
        if name not in self._tools:
            raise ToolNotFoundError(f"Tool '{name}' is not registered.")
        return self._tools[name]

    def list_tools(self) -> list[dict[str, Any]]:
        """List metadata and JSON schemas for all registered tools."""
        descriptors = []
        for name, tool in sorted(self._tools.items()):
            descriptors.append({
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.input_model.model_json_schema(),
                "output_schema": tool.output_model.model_json_schema() if getattr(tool, "output_model", None) else None,
                "read_only": tool.read_only,
                "requires_confirmation": tool.requires_confirmation,
            })
        return descriptors


tool_registry = ToolRegistry()
