import json
import logging
import re
from typing import Any, Tuple, Optional

logger = logging.getLogger(__name__)


def repair_json_string(text: str) -> str:
    """Attempt basic repairs on malformed JSON string (remove comments, trailing commas, fix single quotes)."""
    # Remove C/C++ style comments
    cleaned = re.sub(r"//.*?\n", "\n", text)
    cleaned = re.sub(r"/\*.*?\*/", "", cleaned, flags=re.DOTALL)

    # Fix trailing commas in objects and arrays
    cleaned = re.sub(r",\s*([}\]])", r"\1", cleaned)

    # Replace single quotes surrounding keys/string values if double quotes missing
    if "'" in cleaned and '"' not in cleaned:
        cleaned = re.sub(r"'([^'\\]*(?:\\.[^'\\]*)*)'", r'"\1"', cleaned)

    return cleaned.strip()


def extract_and_parse_json(raw_text: str) -> Tuple[Optional[Any], str, Optional[str]]:
    """Extract JSON object from raw LLM text (handling markdown code blocks, prose, comments, trailing commas).
    Returns (parsed_object, clean_json_str, error_message).
    """
    if not raw_text or not isinstance(raw_text, str):
        return None, "", "Raw text is empty"

    text = raw_text.strip()

    # 1. Try code block extraction ```json ... ``` or ``` ... ```
    code_block_match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", text, re.IGNORECASE)
    if code_block_match:
        extracted = code_block_match.group(1).strip()
    else:
        # 2. Try substring match between first { and last } or first [ and last ]
        first_brace = text.find("{")
        last_brace = text.rfind("}")
        first_bracket = text.find("[")
        last_bracket = text.rfind("]")

        if first_brace != -1 and last_brace != -1 and last_brace > first_brace:
            # Prefer object over array if both exist or brace is earlier
            if first_bracket == -1 or first_brace < first_bracket or last_brace > last_bracket:
                extracted = text[first_brace : last_brace + 1].strip()
            else:
                extracted = text[first_bracket : last_bracket + 1].strip()
        elif first_bracket != -1 and last_bracket != -1 and last_bracket > first_bracket:
            extracted = text[first_bracket : last_bracket + 1].strip()
        else:
            extracted = text

    # Attempt 1: Direct json.loads
    try:
        parsed = json.loads(extracted)
        return parsed, extracted, None
    except json.JSONDecodeError as exc1:
        logger.warning(f"Standard json.loads failed ({exc1}). Attempting JSON repair.")

    # Attempt 2: Repaired string
    repaired = repair_json_string(extracted)
    try:
        parsed = json.loads(repaired)
        return parsed, repaired, None
    except json.JSONDecodeError as exc2:
        logger.warning(f"Repaired json.loads failed ({exc2}).")
        return None, extracted, f"JSONDecodeError: {exc2}"
