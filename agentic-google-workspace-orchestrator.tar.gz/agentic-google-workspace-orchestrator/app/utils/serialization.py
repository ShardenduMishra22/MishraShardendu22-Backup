# this is basically a copy of the serialize_for_jsonb function from the app/utils/serialization.py file, but with some modifications to handle custom objects and Pydantic models more gracefully. It recursively converts datetimes, UUIDs, Enums, Pydantic models, and custom objects into JSON-serializable primitives (ISO-8601 strings for dates/datetimes, strings for UUIDs). It preserves dictionary key-value structure and ensures PostgreSQL JSONB insertion safety.

import logging
from datetime import date, datetime
from enum import Enum
from typing import Any
from uuid import UUID
from pydantic import BaseModel

logger = logging.getLogger(__name__)

def serialize_for_jsonb(val: Any) -> Any:
    """Recursively convert datetimes, UUIDs, Enums, Pydantic models, and custom objects
    into JSON-serializable primitives (ISO-8601 strings for dates/datetimes, strings for UUIDs).
    Preserves dictionary key-value structure and ensures PostgreSQL JSONB insertion safety.
    """
    if val is None:
        return None
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if isinstance(val, UUID):
        return str(val)
    if isinstance(val, Enum):
        return val.value
    if isinstance(val, BaseModel):
        return serialize_for_jsonb(val.model_dump(mode="json"))
    if isinstance(val, dict):
        return {str(k): serialize_for_jsonb(v) for k, v in val.items()}
    if isinstance(val, (list, tuple, set)):
        return [serialize_for_jsonb(item) for item in val]
    if hasattr(val, "isoformat"):
        return val.isoformat()
    if hasattr(val, "model_dump"):
        return serialize_for_jsonb(val.model_dump(mode="json"))
    if hasattr(val, "__dict__") and not isinstance(val, (str, int, float, bool)):
        return serialize_for_jsonb(val.__dict__)
    return val
