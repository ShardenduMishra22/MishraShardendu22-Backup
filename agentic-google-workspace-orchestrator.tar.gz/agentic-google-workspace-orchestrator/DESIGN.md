# Deep Architectural Design & Production Scaling Document

This document provides a comprehensive technical design analysis for the **Agentic Google Workspace Orchestrator**, detailing storage schemas, hybrid search algorithms, DAG orchestration mechanics, confirmation safety gates, and a production scaling roadmap for 1 Million users.

---

## 1. System Architecture & Component Rationale

The orchestrator integrates three Google Workspace services (Gmail, Calendar, Drive) into a unified intelligence plane.

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                          Google Workspace APIs                          │
│                      (Gmail, Calendar, Google Drive)                    │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │ REST REST Sync
┌────────────────────────────────────▼────────────────────────────────────┐
│                        Workspace Sync Engine                           │
│     - Fetch Raw Resource → Normalize Schema → Recursive Text Chunking   │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │
┌────────────────────────────────────▼────────────────────────────────────┐
│                       PostgreSQL 16 + pgvector                          │
│   - workspace_items (Primary data)  - workspace_chunks (Embeddings & FTS) │
└───────────────────┬─────────────────────────────────┬───────────────────┘
                    │                                 │
          PostgreSQL FTS (GIN)               pgvector Cosine (HNSW)
                    │                                 │
                    └────────────────┬────────────────┘
                                     │
┌────────────────────────────────────▼────────────────────────────────────┐
│                   Reciprocal Rank Fusion (RRF k=60.0)                   │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │ Top-5 Deduplicated Results
┌────────────────────────────────────▼────────────────────────────────────┐
│                        Typed Service Tools                              │
│       (gmail.*, calendar.*, drive.* - central ToolRegistry)             │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │ Tool Schemas Injection
┌────────────────────────────────────▼────────────────────────────────────┐
│                   LLM Intent Classifier & Planner                       │
│    - Intent & Entity Resolver    - Typed ExecutionPlan DAG Generator    │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │
┌────────────────────────────────────▼────────────────────────────────────┐
│                     Python DAG Validation Engine                        │
│    - Unique Step IDs - Tool Verification - Kahn's Topological Cycle     │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │
┌────────────────────────────────────▼────────────────────────────────────┐
│                Parallel DAG Executor & Confirmation Gate                │
│    - asyncio.gather Parallel Run - Reference Resolution - PendingAction │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Entity-Relationship (ER) Diagram

```mermaid
erDiagram
    users ||--o{ google_accounts : owns
    users ||--o{ conversations : initiates
    users ||--o{ workspace_items : owns
    users ||--o{ sync_states : tracks
    users ||--o{ orchestration_runs : executes
    users ||--o{ audit_logs : logs

    conversations ||--o{ messages : contains
    conversations ||--o{ orchestration_runs : scopes

    workspace_items ||--o{ workspace_chunks : contains

    orchestration_runs ||--o{ execution_steps : generates
    orchestration_runs ||--o{ pending_actions : creates

    users {
        uuid id PK
        string email UK
        timestamp created_at
        timestamp updated_at
    }

    google_accounts {
        uuid id PK
        uuid user_id FK
        string google_account_id
        string email
        string access_token
        string refresh_token
        timestamp token_expires_at
        jsonb scopes
    }

    conversations {
        uuid id PK
        uuid user_id FK
        timestamp created_at
        timestamp updated_at
    }

    messages {
        uuid id PK
        uuid conversation_id FK
        string sender
        text content
        jsonb metadata_
        timestamp created_at
    }

    workspace_items {
        uuid id PK
        uuid user_id FK
        string service
        string item_type
        string external_id
        string title
        text content
        jsonb metadata_
        timestamp source_created_at
        timestamp source_updated_at
        timestamp sync_timestamp
    }

    workspace_chunks {
        uuid id PK
        uuid workspace_item_id FK
        integer chunk_index
        text content
        vector_2048 embedding
        tsvector search_vector
        timestamp created_at
    }

    sync_states {
        uuid id PK
        uuid user_id FK
        string service
        string sync_type
        string status
        string page_token
        timestamp last_sync_timestamp
    }

    orchestration_runs {
        uuid id PK
        uuid user_id FK
        uuid conversation_id FK
        text query
        jsonb intent
        jsonb plan
        string status
        text error
    }

    execution_steps {
        uuid id PK
        uuid orchestration_run_id FK
        string step_key
        string tool_name
        jsonb dependencies
        jsonb input
        jsonb output
        string status
        text error
    }

    pending_actions {
        uuid id PK
        uuid orchestration_run_id FK
        string action_type
        jsonb payload
        string status
    }

    audit_logs {
        uuid id PK
        uuid user_id FK
        string action
        string resource_type
        jsonb metadata_
        timestamp created_at
    }
```

---

## 3. Storage & Retrieval Strategy

### 3.1 Unified `workspace_items` → `workspace_chunks` Schema
To avoid service-specific siloed tables (e.g. `emails`, `calendar_events`, `drive_files`), all Google Workspace items map to `workspace_items` with a common schema:
- **`service`**: `gmail` | `calendar` | `drive`
- **`item_type`**: `email` | `calendar_event` | `drive_file`
- **`metadata_`**: JSONB container storing domain-specific attributes (sender, recipients, attendees, mime_type, file_extension, web_view_link).

### 3.2 Hybrid Search Architecture (FTS + pgvector + RRF)
Lexical search alone misses semantic synonyms; vector search alone misses exact codes ("TK1234", "Room 302").

1. **PostgreSQL Full-Text Search**:
   - `search_vector` column indexed via GIN (`CREATE INDEX idx_workspace_chunks_fts ON workspace_chunks USING gin(search_vector)`).
   - Ranked using `ts_rank_cd(search_vector, query)`.

2. **pgvector Cosine Distance**:
   - 2048-dim embedding column (`vector(2048)`).
   - HNSW index (`CREATE INDEX idx_workspace_chunks_embedding ON workspace_chunks USING hnsw(embedding vector_cosine_ops)`).
   - Ranked using `embedding <=> query_vector`.

3. **Reciprocal Rank Fusion (RRF)**:
   - Combines rank positions independently of raw score scaling:
     $$\text{RRF\_Score}(d) = \sum_{m \in \{\text{lexical}, \text{semantic}\}} \frac{1}{k + \text{rank}_m(d)} \quad (k = 60.0)$$
   - Chunks are aggregated to parent `workspace_items` and deduplicated.

---

## 4. Orchestration Engine Architecture

### 4.1 Execution Flow
```text
User Query → Intent Classifier → DAG Planner → Python Validator → Parallel Executor → Synthesizer
```

### 4.2 LLM vs. Python Responsibilities
- **LLM**: Reasoning, entity extraction, temporal range resolution, ambiguity detection, typed DAG plan proposal.
- **Python**: Structural validation, tool registry lookup, dependency cycle detection (Kahn's algorithm), parallel step execution (`asyncio.gather`), confirmation enforcement, reference template resolution, error boundary handling, and DB state persistence.

### 4.3 Confirmation Safety Gate
Mutating tools (`gmail.send_email`, `calendar.create_event`, `calendar.delete_event`) specify `requires_confirmation = True`.
When executed:
1. Executor pauses step execution and creates a `PendingAction` in PostgreSQL with status `"pending"`.
2. Step status transitions to `"waiting_confirmation"`.
3. Orchestration run halts with status `"needs_confirmation"`.
4. Execution resumes only when the user invokes `POST /api/v1/actions/{id}/confirm`. Replay is blocked by atomic DB status checks.

---

## 5. Caching & Resilience

1. **Redis Embedding Cache**: SHA256 content hashes cached with 7-day TTL (`embedding:{model}:{sha256}`). Reduces OpenRouter embedding API calls by >90%.
2. **Fixed-Window API Rate Limiting**: Enforces 100 queries/user/hour (`rate_limit:query:{user_id}:{window}`) returning HTTP 429.
3. **Deterministic Fallbacks**: If OpenRouter is unavailable or rate-limited, fallback logic executes standard hybrid search DAG plans without crashing.

---

## 6. Production Scaling Strategy (1 Million Users)

To scale this assignment architecture from single-node Docker Compose to a 1M active user production deployment:

### 6.1 Stateless API Layer
- Deploy FastAPI application instances in Kubernetes (EKS/GKE) behind an AWS ALB / NGINX Ingress Controller with auto-scaling (HPA based on CPU/Memory and request concurrency).

### 6.2 PostgreSQL Database Sharding & Partitioning
- **Declarative Partitioning**: Partition `workspace_items` and `workspace_chunks` by `HASH(user_id)` across 64 database partitions.
- **Read Replicas**: Direct hybrid search read traffic to PostgreSQL Read Replicas, reserving Primary node for sync writes.
- **PgBouncer**: Deploy PgBouncer connection poolers in transaction mode to handle 50,000+ open client connections.

### 6.3 Redis Cluster
- Replace single Redis container with a 6-node Redis Cluster with primary/replica pairs for distributed embedding caching and rate limiting.

### 6.4 Asynchronous Worker Queue (Celery / Temporal / RabbitMQ)
- Move initial & periodic Google Workspace synchronization out of HTTP worker threads into a dedicated distributed task queue (Celery + RabbitMQ or Temporal.io).
- Implement Google API rate-limit quota backoff handling per user token.
