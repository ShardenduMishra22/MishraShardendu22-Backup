import asyncio
import logging
import os
import sys
import time
import uuid

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from app.config import settings
from app.db import AsyncSessionLocal, normalize_database_url
from app.models.models import User, WorkspaceChunk, WorkspaceItem
from app.retrieval.evaluation import EvaluationQuery, calculate_precision_at_k
from app.retrieval.fts import search_lexical_candidates
from app.retrieval.fusion import perform_rrf_fusion
from app.retrieval.models import SearchFilters
from app.retrieval.vector import search_vector_candidates

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BENCHMARK_DATASET = [
    EvaluationQuery(
        query_id="Q1",
        query="Turkish Airlines flight booking TK1234",
        services=["gmail"],
        expected_external_ids=["eval_msg_1"],
    ),
    EvaluationQuery(
        query_id="Q2",
        query="Acme Corp client meeting",
        services=["calendar"],
        expected_external_ids=["eval_event_1"],
    ),
    EvaluationQuery(
        query_id="Q3",
        query="budget proposal emails from sarah",
        services=["gmail"],
        expected_external_ids=["eval_msg_2"],
    ),
    EvaluationQuery(
        query_id="Q4",
        query="Drive PDF document Acme proposal",
        services=["drive"],
        expected_external_ids=["eval_file_1"],
    ),
    EvaluationQuery(
        query_id="Q5",
        query="out-of-office policy vacation schedule",
        services=["drive"],
        expected_external_ids=["eval_file_2"],
    ),
    EvaluationQuery(
        query_id="Q6",
        query="flight confirmation Istanbul JFK",
        services=["gmail"],
        expected_external_ids=["eval_msg_1"],
    ),
    EvaluationQuery(
        query_id="Q7",
        query="Acme proposal contract draft",
        services=["drive", "gmail"],
        expected_external_ids=["eval_file_1", "eval_msg_2"],
    ),
    EvaluationQuery(
        query_id="Q8",
        query="sarah@company.com quarterly budget proposal",
        services=["gmail"],
        expected_external_ids=["eval_msg_2"],
    ),
    EvaluationQuery(
        query_id="Q9",
        query="client meeting room 302",
        services=["calendar"],
        expected_external_ids=["eval_event_1"],
    ),
    EvaluationQuery(
        query_id="Q10",
        query="vacation out of office schedule",
        services=["drive"],
        expected_external_ids=["eval_file_2"],
    ),
]


async def seed_benchmark_fixtures(db) -> User:
    """Seed synthetic benchmark workspace items into database if not present."""
    stmt = select(User).order_by(User.created_at.desc())
    res = await db.execute(stmt)
    user = res.scalars().first()

    if not user:
        user = User(id=uuid.uuid4(), email="eval_user@company.com")
        db.add(user)
        await db.commit()
        await db.refresh(user)

    # Always clean old benchmark user items to ensure fresh fixture data
    if user:
        from sqlalchemy import delete
        await db.execute(delete(WorkspaceItem).where(WorkspaceItem.user_id == user.id))
        await db.commit()

    logger.info("Seeding benchmark fixture items...")

    fixtures = [
        ("gmail", "email", "eval_msg_1", "Turkish Airlines Flight Booking TK1234 Confirmation", "Your flight from Istanbul (IST) to NYC (JFK) TK1234 is confirmed for Nov 5 at 10:30 AM.", {"sender": "support@turkishairlines.com"}),
        ("gmail", "email", "eval_msg_2", "Quarterly Budget Proposal", "Attached is the Q3 budget proposal from Sarah (sarah@company.com). Please review the Acme proposal numbers.", {"sender": "sarah@company.com"}),
        ("calendar", "calendar_event", "eval_event_1", "Acme Corp Client Meeting", "Quarterly strategy review meeting with Acme Corp executives in Room 302.", {"attendees": "john@acme.com"}),
        ("calendar", "calendar_event", "eval_event_2", "Out of Office - Vacation", "Annual leave out of office block. No meetings scheduled.", {"attendees": "eval_user@company.com"}),
        ("drive", "drive_file", "eval_file_1", "Acme_Proposal_Contract.pdf", "Official budget and contract proposal document for Acme Corp client engagement.", {"mime_type": "application/pdf"}),
        ("drive", "drive_file", "eval_file_2", "Out_Of_Office_Policy_2026.docx", "Company out-of-office policy, vacation schedule guidelines, and coverage requirements.", {"mime_type": "application/vnd.google-apps.document"}),
    ]

    for idx_f, (service, item_type, ext_id, title, content, meta) in enumerate(fixtures):
        item = WorkspaceItem(
            id=uuid.uuid4(),
            user_id=user.id,
            service=service,
            item_type=item_type,
            external_id=ext_id,
            title=title,
            content=content,
            metadata_=meta,
        )
        db.add(item)
        await db.flush()

        title_clean = title.replace("_", " ")
        chunk_text = f"[{service.upper()} {item_type.upper()}] {title_clean}\n{content}"

        try:
            from app.services.embedding_service import embedding_service
            chunk_vec = await embedding_service.get_embedding(chunk_text)
        except Exception:
            chunk_vec = [0.001 * ((i + idx_f) % 10) for i in range(2048)]

        chunk = WorkspaceChunk(
            id=uuid.uuid4(),
            workspace_item_id=item.id,
            chunk_index=0,
            content=chunk_text,
            embedding=chunk_vec,
        )
        db.add(chunk)

    await db.commit()

    # Update TSVECTOR search_vector for created chunks
    await db.execute(
        text(
            "UPDATE workspace_chunks SET search_vector = to_tsvector('english', content) WHERE search_vector IS NULL"
        )
    )
    await db.commit()

    return user


async def run_retrieval_benchmark() -> None:
    """Run retrieval evaluation benchmark and measure latency."""
    print("==========================================================")
    print("       HYBRID RETRIEVAL & PRECISION@5 BENCHMARK RUNNER    ")
    print("==========================================================\n")

    db_url = normalize_database_url(os.environ.get("DATABASE_URL") or settings.DATABASE_URL)
    bench_engine = create_async_engine(db_url, echo=False)
    BenchSessionLocal = async_sessionmaker(bind=bench_engine, class_=AsyncSession, expire_on_commit=False)

    async with BenchSessionLocal() as db:
        user = await seed_benchmark_fixtures(db)
        user_id = user.id

        total_precision = 0.0
        results_table = []
        fts_times, vec_times, rrf_times, total_times = [], [], [], []

        for eval_q in BENCHMARK_DATASET:
            t0 = time.perf_counter()

            filters_obj = SearchFilters(services=eval_q.services) if eval_q.services else None

            # 1. Lexical FTS Search
            t_fts_start = time.perf_counter()
            lexical_cands = await search_lexical_candidates(db, user_id=user_id, query=eval_q.query, filters=filters_obj, candidate_limit=20)
            t_fts = (time.perf_counter() - t_fts_start) * 1000.0

            # 2. Vector Search (cached/pgvector)
            t_vec_start = time.perf_counter()
            vector_cands = await search_vector_candidates(db, user_id=user_id, query=eval_q.query, filters=filters_obj, candidate_limit=20)
            t_vec = (time.perf_counter() - t_vec_start) * 1000.0

            # 3. RRF Fusion & Deduplication
            t_rrf_start = time.perf_counter()
            final_results = await perform_rrf_fusion(db, lexical_candidates=lexical_cands, semantic_candidates=vector_cands, limit=5)
            t_rrf = (time.perf_counter() - t_rrf_start) * 1000.0

            t_total = (time.perf_counter() - t0) * 1000.0

            fts_times.append(t_fts)
            vec_times.append(t_vec)
            rrf_times.append(t_rrf)
            total_times.append(t_total)

            retrieved_ext_ids = [r.external_id for r in final_results]
            ground_truth = set(eval_q.expected_external_ids)
            p_at_5 = calculate_precision_at_k(retrieved_ext_ids, ground_truth, k=5)

            total_precision += p_at_5
            results_table.append({
                "id": eval_q.query_id,
                "query": eval_q.query[:35],
                "retrieved": len(final_results),
                "expected": len(ground_truth),
                "p_at_5": p_at_5,
                "total_ms": t_total,
            })

        mean_p5 = round(total_precision / len(BENCHMARK_DATASET), 4)

        avg_fts = sum(fts_times) / len(fts_times)
        avg_vec = sum(vec_times) / len(vec_times)
        avg_rrf = sum(rrf_times) / len(rrf_times)
        avg_total = sum(total_times) / len(total_times)

        print(f"{'ID':<5} | {'Query':<36} | {'P@5':<6} | {'Time (ms)':<10}")
        print("-" * 66)
        for row in results_table:
            print(f"{row['id']:<5} | {row['query']:<36} | {row['p_at_5']:<6.4f} | {row['total_ms']:<10.2f}")
        print("-" * 66)
        print(f"Mean Precision@5 Benchmark Score: {mean_p5} (Target: >0.8)")
        print("\n--- Sub-Component Latency Breakdown (Averages) ---")
        print(f"- PostgreSQL FTS Search:       {avg_fts:.2f} ms")
        print(f"- pgvector Cosine Search:     {avg_vec:.2f} ms")
        print(f"- RRF Fusion & Deduplication: {avg_rrf:.2f} ms")
        print(f"- Total Retrieval Latency:    {avg_total:.2f} ms (Target: <500ms)")
        print("==========================================================\n")


if __name__ == "__main__":
    asyncio.run(run_retrieval_benchmark())
