#!/usr/bin/env bash
set -e

echo "🚀 Starting Agentic Google Workspace Orchestrator Local Infrastructure (PostgreSQL & Redis)..."
# Free ports 8000 and 3000 if previously left open by orphaned processes
fuser -k 8000/tcp 2>/dev/null || true
fuser -k 3000/tcp 2>/dev/null || true
docker compose up -d postgres redis

echo "⏳ Waiting for PostgreSQL (localhost:5432) readiness..."
until docker compose exec postgres pg_isready -U postgres -d orchestrator > /dev/null 2>&1; do
    sleep 1
done
echo "✅ PostgreSQL is ready!"

echo "⏳ Waiting for Redis (localhost:6379) readiness..."
until docker compose exec redis redis-cli ping | grep PONG > /dev/null 2>&1; do
    sleep 1
done
echo "✅ Redis is ready!"

echo "🗄️ Running Alembic database migrations..."
uv run alembic upgrade head

# Setup signal handling to cleanly terminate background processes on Ctrl+C
BACKEND_PID=""
FRONTEND_PID=""

cleanup() {
    echo ""
    echo "🛑 Shutting down local FastAPI backend and Next.js frontend processes..."
    if [ -n "$BACKEND_PID" ]; then
        kill "$BACKEND_PID" 2>/dev/null || true
    fi
    if [ -n "$FRONTEND_PID" ]; then
        kill "$FRONTEND_PID" 2>/dev/null || true
    fi
    echo "ℹ️  PostgreSQL and Redis containers remain running. (Use 'make infra-down' to stop them)."
    exit 0
}

trap cleanup INT TERM EXIT

echo "🐍 Starting FastAPI Backend on http://localhost:8000..."
uv run uvicorn app.main:app --reload --host 0.0.0.0 --port 8000 &
BACKEND_PID=$!

echo "⚛️  Starting Next.js Frontend on http://localhost:3000..."
(cd frontend && pnpm dev) &
FRONTEND_PID=$!

echo ""
echo "=========================================================="
echo "🎉 Local Development Stack Online!"
echo "   - Frontend UI:  http://localhost:3000"
echo "   - Backend API:  http://localhost:8000"
echo "   - OpenAPI Docs: http://localhost:8000/docs"
echo "Press Ctrl+C to stop local processes cleanly."
echo "=========================================================="
echo ""

# Wait for background jobs to keep script active until Ctrl+C
wait $BACKEND_PID $FRONTEND_PID
