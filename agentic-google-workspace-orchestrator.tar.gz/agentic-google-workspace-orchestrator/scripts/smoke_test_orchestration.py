import asyncio
import logging
import os
import sys

# Ensure root directory in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.config import settings
from app.integrations.gemini import gemini_client
from app.orchestration.classifier import classify_intent
from app.orchestration.planner import generate_execution_plan

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def run_smoke_test() -> None:
    """Run real Gemini smoke test if API key is configured."""
    if not settings.GEMINI_API_KEY:
        print("GEMINI_API_KEY is not set. Skipping live smoke test.")
        return

    print(f"Executing Live Gemini Smoke Test using model: '{settings.GEMINI_MODEL}'...")

    # Test 1: Single-service query classification & planning
    q1 = "Find emails from sarah@company.com about the budget"
    print(f"\n--- Testing Query 1: '{q1}' ---")
    intent1 = await classify_intent(q1, conversation_history=[])
    print(f"Intent Classification: {intent1.model_dump_json(indent=2)}")

    plan1 = await generate_execution_plan(q1, intent=intent1, conversation_history=[])
    print(f"Execution Plan: {plan1.model_dump_json(indent=2)}")

    # Test 2: Multi-service query classification & planning
    q2 = "Prepare for tomorrow's meeting with Acme Corp"
    print(f"\n--- Testing Query 2: '{q2}' ---")
    intent2 = await classify_intent(q2, conversation_history=[])
    print(f"Intent Classification: {intent2.model_dump_json(indent=2)}")

    plan2 = await generate_execution_plan(q2, intent=intent2, conversation_history=[])
    print(f"Execution Plan: {plan2.model_dump_json(indent=2)}")

    print("\nLive Gemini Smoke Test Completed Successfully!")


if __name__ == "__main__":
    asyncio.run(run_smoke_test())
