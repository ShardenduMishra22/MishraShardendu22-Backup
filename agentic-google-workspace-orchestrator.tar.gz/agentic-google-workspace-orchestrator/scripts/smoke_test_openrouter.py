import asyncio
import os
import sys

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.config import settings
from app.integrations.openrouter import openrouter_client


async def main() -> None:
    """Manual smoke test script to verify OpenRouter embedding integration."""
    print("=== OpenRouter Embedding Integration Smoke Test ===")
    print(f"Model: {settings.EMBEDDING_MODEL}")
    print(f"Expected Dimension: {settings.EMBEDDING_DIMENSION}")

    if not settings.OPENROUTER_API_KEY:
        print("\n[SKIP] OPENROUTER_API_KEY is not set in environment or .env file.")
        print("To run live verification, set OPENROUTER_API_KEY in .env and rerun this script.")
        return

    test_text = "The quick brown fox jumps over the lazy dog."
    print(f"\nSending embedding request for test input: '{test_text}'...")

    try:
        embedding = await openrouter_client.embed_text(test_text)
        print("\n[SUCCESS] OpenRouter Embedding Verification Passed!")
        print(f"- Request Status: 200 OK")
        print(f"- Model: {settings.EMBEDDING_MODEL}")
        print(f"- Embedding Vector Dimension: {len(embedding)}")
        print(f"- Sample Vector Slice (first 3 values): {embedding[:3]}")
    except Exception as e:
        print(f"\n[FAILURE] OpenRouter Embedding Request Failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
