# Agentic Google Workspace Orchestrator

An agentic, multi-service orchestrator for Google Workspace built with Python, FastAPI, PostgreSQL (`pgvector`), Redis, and Next.js.

The system synchronizes, normalizes, and indexes Workspace data (Gmail, Google Calendar, Google Drive), executes **hybrid retrieval (PostgreSQL FTS + pgvector cosine similarity + Reciprocal Rank Fusion)**, dynamically generates typed **Execution Plan DAGs** via OpenRouter LLM, enforces a **Python-governed confirmation gate** for mutating actions, and provides a Next.js chat & orchestration interface.

> **Engineering Constraints Preserved**: No LangChain, no LlamaIndex, no external vector databases, no ReAct loops. Python strictly owns validation, DAG scheduling, parallel execution, confirmation enforcement, and state persistence.

---

## Target Local Architecture

Local development runs FastAPI and Next.js directly on the host machine using `uv` and `pnpm`, with PostgreSQL and Redis running in Docker Compose infrastructure containers:

```text
Host Machine:
   ├── Next.js Frontend     http://localhost:3000
   └── FastAPI Backend      http://localhost:8000

Docker Compose (Infrastructure):
   ├── PostgreSQL + pgvector localhost:5432
   └── Redis 7              localhost:6379

External Services:
   ├── Google Workspace REST APIs / OAuth 2.0
   └── OpenRouter API (gpt-oss-120b & llama-nemotron embeddings)
```

---

## One-Command Quick Start

### 1. Initial Setup (One-Time)
Install backend and frontend dependencies:
```bash
# Sync Python environment
uv sync

# Install Next.js frontend dependencies
cd frontend && pnpm install && cd ..

# Configure environment variables
cp .env.example .env
```

### 2. Configure Environment (`.env`)
Ensure `.env` contains your OpenRouter API key and Google OAuth credentials:
```ini
DATABASE_URL=postgresql+asyncpg://postgres:postgres@localhost:5432/orchestrator
REDIS_URL=redis://localhost:6379/0

OPENROUTER_API_KEY=sk-or-v1-...
OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
LLM_MODEL=openai/gpt-oss-120b:free
EMBEDDING_MODEL=nvidia/llama-nemotron-embed-vl-1b-v2:free

GOOGLE_CLIENT_ID=your-client-id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your-client-secret
GOOGLE_REDIRECT_URI=http://localhost:8000/api/v1/auth/google/callback

CORS_ORIGINS=http://localhost:3000
FRONTEND_URL=http://localhost:3000
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000
```

> **Google Cloud Console Requirement**: Ensure your Google OAuth Web Application credentials include the following **Authorized Redirect URI**:
> ```text
> http://localhost:8000/api/v1/auth/google/callback
> ```

### 3. Launch Local Application (`make dev`)
```bash
make dev
```
`make dev` automatically:
1. Starts PostgreSQL and Redis Docker containers (`make infra`).
2. Waits for PostgreSQL and Redis health probes.
3. Runs Alembic database schema migrations (`uv run alembic upgrade head`).
4. Starts local FastAPI backend on `http://localhost:8000`.
5. Starts local Next.js frontend on `http://localhost:3000`.
6. Attaches both processes cleanly with Ctrl+C termination handling.

---

## Makefile Targets

```text
make dev         Start PostgreSQL + Redis in Docker and launch local FastAPI and Next.js processes
make infra       Start PostgreSQL and Redis infrastructure containers only
make infra-down  Stop PostgreSQL and Redis infrastructure containers
make migrate     Run Alembic database migrations locally
make backend     Run FastAPI backend locally on port 8000
make frontend    Run Next.js frontend locally on port 3000
make test        Run complete backend pytest suite and frontend production build check
make benchmark   Run hybrid retrieval Precision@5 and latency benchmark locally
make clean       Clean local temporary caches (__pycache__, .next, .pytest_cache)
make reset       Stop local infrastructure and remove PostgreSQL/Redis Docker volumes (DESTRUCTIVE)
make help        Display available Makefile commands
```

---

## Endpoints

- **Frontend Interface**: [http://localhost:3000](http://localhost:3000)
- **Backend API Base**: [http://localhost:8000](http://localhost:8000)
- **Interactive OpenAPI Docs**: [http://localhost:8000/docs](http://localhost:8000/docs)
- **API Readiness Check**: `curl http://localhost:8000/ready`
- **Google OAuth Status Check**: `curl http://localhost:8000/api/v1/auth/google/status`

---

## Benchmarks & Evaluation Metrics

Run local retrieval evaluation benchmark:
```bash
make benchmark
```

Results across 10 evaluation test queries:
- **Mean Precision@5 Score**: **`1.00`** (Target $>0.80$ **MET**)
- **Local DB Search Latency**: PostgreSQL FTS = `4.83 ms`, RRF Fusion = `2.82 ms` (Total DB latency: `~7.65 ms`)
- **Uncached Vector Latency**: Includes OpenRouter embedding API roundtrip (`~974 ms`)

---

## Testing & Quality Assurance

Run complete test suite and frontend build validation:
```bash
make test
```

- **Backend Pytest Suite**: 37 unit & integration tests passing (`uv run pytest`).
- **Frontend Build Validation**: Next.js production build (`pnpm build`) compiled successfully with 0 errors.

---

## Documentation Links

- [DESIGN.md](file:///home/mishrashardendu22/Coding_Stuff_Fedora/Agentic%20Google%20Workspace%20Orchestrator/DESIGN.md): Architectural design document, ER diagram, and 1M-user production scaling plan.
- [API.md](file:///home/mishrashardendu22/Coding_Stuff_Fedora/Agentic%20Google%20Workspace%20Orchestrator/API.md): Reference for all 11 REST API endpoints.
- [DEMO.md](file:///home/mishrashardendu22/Coding_Stuff_Fedora/Agentic%20Google%20Workspace%20Orchestrator/DEMO.md): 5-minute video demo walkthrough sequence and 12 evaluation query test cases.
