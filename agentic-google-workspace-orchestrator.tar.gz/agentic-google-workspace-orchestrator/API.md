# API Reference Specification

Base URL: `http://localhost:8000`

---

## Health & Readiness Probes

### 1. `GET /health`
- **Purpose**: Process liveness probe.
- **Response `200 OK`**:
```json
{
  "status": "ok"
}
```

### 2. `GET /ready`
- **Purpose**: Dependency readiness probe checking PostgreSQL database and Redis connectivity.
- **Response `200 OK`**:
```json
{
  "status": "ready",
  "database": "connected",
  "redis": "connected"
}
```

---

## Google Authentication

### 3. `GET /api/v1/auth/google`
- **Purpose**: Initiate Google OAuth consent flow.
- **Response `307 Temporary Redirect`**: Redirects user browser to Google OAuth consent page.

### 4. `GET /api/v1/auth/google/callback`
- **Purpose**: OAuth callback endpoint exchanging code for tokens and persisting user session.
- **Query Parameters**: `code` (string), `state` (string optional)
- **Response `200 OK`**:
```json
{
  "status": "authenticated",
  "user_id": "8f3b2a1c-...",
  "email": "user@example.com",
  "google_account_id": "1098237461..."
}
```

### 5. `GET /api/v1/auth/google/status`
- **Purpose**: Check current Google OAuth connection status.
- **Response `200 OK`**:
```json
{
  "connected": true,
  "email": "user@example.com",
  "user_id": "8f3b2a1c-..."
}
```

---

## Workspace Synchronization

### 6. `POST /api/v1/sync/trigger`
- **Purpose**: Trigger manual synchronization across Gmail, Calendar, and Drive.
- **Request Body**:
```json
{
  "services": ["gmail", "calendar", "drive"],
  "force_full_sync": false
}
```
- **Response `200 OK`**:
```json
{
  "status": "completed",
  "user_id": "8f3b2a1c-...",
  "synced_services": {
    "gmail": {"status": "success", "items_synced": 42},
    "calendar": {"status": "success", "items_synced": 18},
    "drive": {"status": "success", "items_synced": 12}
  }
}
```

### 7. `GET /api/v1/sync/status`
- **Purpose**: Retrieve workspace synchronization state for active user.
- **Response `200 OK`**:
```json
{
  "user_id": "8f3b2a1c-...",
  "services": {
    "gmail": {"status": "success", "items_synced": 42, "last_sync": "2026-07-27T01:30:00Z"},
    "calendar": {"status": "success", "items_synced": 18, "last_sync": "2026-07-27T01:30:00Z"},
    "drive": {"status": "success", "items_synced": 12, "last_sync": "2026-07-27T01:30:00Z"}
  }
}
```

---

## Hybrid Search & Orchestration

### 8. `POST /api/v1/search`
- **Purpose**: Execute unified hybrid search (FTS + pgvector + RRF).
- **Request Body**:
```json
{
  "query": "Acme Corp budget proposal",
  "services": ["gmail", "drive"],
  "limit": 5
}
```
- **Response `200 OK`**:
```json
{
  "query": "Acme Corp budget proposal",
  "total_results": 2,
  "results": [
    {
      "workspace_item_id": "...",
      "external_id": "eval_file_1",
      "service": "drive",
      "title": "Acme Proposal Contract.pdf",
      "snippet": "Official budget proposal document for Acme Corp...",
      "score": 0.0322
    }
  ]
}
```

### 9. `POST /api/v1/query`
- **Purpose**: Main intelligent orchestration endpoint.
- **Request Body**:
```json
{
  "query": "Prepare for tomorrow's meeting with Acme Corp",
  "conversation_id": null,
  "user_timezone": "UTC"
}
```
- **Response `200 OK` (`completed`)**:
```json
{
  "status": "completed",
  "conversation_id": "a6184bfa-...",
  "orchestration_id": "7801ba37-...",
  "response": "Here is your preparation brief for tomorrow's meeting with Acme Corp...",
  "actions_taken": [
    {"step_id": "search_gmail", "status": "completed"},
    {"step_id": "search_calendar", "status": "completed"},
    {"step_id": "search_drive", "status": "completed"}
  ]
}
```
- **Response `200 OK` (`needs_clarification`)**:
```json
{
  "status": "needs_clarification",
  "conversation_id": "a6184bfa-...",
  "orchestration_id": "7801ba37-...",
  "clarification": {
    "question": "Which meeting with John do you mean, and what time would you like to move it to?"
  }
}
```
- **Response `200 OK` (`needs_confirmation`)**:
```json
{
  "status": "needs_confirmation",
  "conversation_id": "a6184bfa-...",
  "orchestration_id": "7801ba37-...",
  "pending_actions": [
    {
      "pending_action_id": "c91e4a2f-...",
      "action_type": "gmail.send_email",
      "payload": {
        "to": "support@turkishairlines.com",
        "subject": "Cancellation Request",
        "body": "Please cancel TK1234 booking."
      }
    }
  ]
}
```

---

## Action Confirmation Gating

### 10. `POST /api/v1/actions/{pending_action_id}/confirm`
- **Purpose**: Explicitly authorize and execute a pending mutating action.
- **Response `200 OK`**:
```json
{
  "status": "confirmed",
  "pending_action_id": "c91e4a2f-...",
  "message": "Action 'gmail.send_email' executed successfully."
}
```

### 11. `POST /api/v1/actions/{pending_action_id}/reject`
- **Purpose**: Explicitly reject a pending action without executing mutations.
- **Response `200 OK`**:
```json
{
  "status": "rejected",
  "pending_action_id": "c91e4a2f-...",
  "message": "Action rejected by user."
}
```
