# Contributing to Agentic Google Workspace Orchestrator

Thank you for contributing! This project values clear issues, good test coverage, and a secure codebase.

## How to contribute

1. Fork the repository.
2. Create a feature branch from `main`:
   ```bash
git checkout -b feature/short-description
```
3. Make your changes.
4. Run tests locally.
5. Open a pull request with a concise description of the change.

## Code standards

- Use Python 3.12+ syntax and typing where appropriate.
- Keep API contract changes backward-compatible when possible.
- Document new functionality in `README.md`, `API.md`, and/or `DESIGN.md`.
- Keep frontend changes small and test interactive flows.

## Local development

### Backend

Install Python dependencies:
```bash
uv sync
```

Apply database migrations:
```bash
make migrate
```

Run backend locally:
```bash
make backend
```

### Frontend

Install frontend dependencies:
```bash
cd frontend && pnpm install && cd ..
```

Run the frontend locally:
```bash
make frontend
```

## Testing

Run the full backend test suite:
```bash
make test
```

If your change touches frontend code, use `pnpm build` inside `frontend/` to validate the production build.

## Issue and pull request guidelines

- Search existing issues before creating a new one.
- Provide a clear summary and reproduction steps for bugs.
- For feature requests, explain the problem being solved and the expected user experience.

### Pull requests

- Keep PRs focused and small when possible.
- Include test coverage for bug fixes and new features.
- Link to any related issues or documentation updates.

## Security and credentials

Never commit secrets, API keys, OAuth credentials, or `.env` values. Use the `.env.example` file as a template only.
