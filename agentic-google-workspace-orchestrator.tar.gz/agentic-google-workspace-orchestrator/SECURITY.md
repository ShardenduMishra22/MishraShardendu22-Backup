# Security Policy

## Reporting a vulnerability

If you discover a security issue in this project, please report it by opening an issue with the label `security` or by contacting the repository maintainer directly.

Do not publish sensitive details publicly until the issue has been addressed.

## Supported versions

This project is built for Python 3.12+ and relies on FastAPI, PostgreSQL, Redis, and OpenRouter integrations.

## Security best practices

- Keep `.env` files out of source control.
- Do not commit API keys, Google OAuth secrets, or access tokens.
- Use strong, unique credentials for database and Redis access in production.
- Rotate keys and tokens immediately if they are accidentally exposed.

## Vulnerability disclosure

If you report a security vulnerability, include:
- A short summary of the issue
- Steps to reproduce
- Potential impact

The maintainers will acknowledge receipt and work to address the issue promptly.
