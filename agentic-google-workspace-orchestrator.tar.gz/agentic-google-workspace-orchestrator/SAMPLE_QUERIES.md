# SAMPLE QUERIES & ORCHESTRATION EVALUATION SUITE

This document lists the 10+ required sample queries for the **Agentic Google Workspace Orchestrator**, detailing expected service routes, execution plans, clarification requirements, confirmation behavior, and expected system response.

---

## 1. Single Service Queries

### Query 1: Calendar Search
- **Input**: `"What's on my calendar next week?"`
- **Services**: `["calendar"]`
- **Expected Flow**:
  1. Temporal reasoning normalizes `"next week"` into start/end datetimes.
  2. `calendar.search_events` tool executes against indexed events.
  3. Synthesizes formatted chronological event list.
- **Clarification**: No.
- **Confirmation**: No (Read-Only).

### Query 2: Email Search with Sender Filter
- **Input**: `"Find emails from sarah@company.com about the budget"`
- **Services**: `["gmail"]`
- **Expected Flow**:
  1. `gmail.search_emails` executes with `sender="sarah@company.com"` and `query="budget"`.
  2. RRF hybrid retrieval matches subject and email body.
  3. Synthesizes summary of matching emails.
- **Clarification**: No.
- **Confirmation**: No (Read-Only).

### Query 3: Drive File Search with MIME Filter
- **Input**: `"Show me PDFs in Drive from last month"`
- **Services**: `["drive"]`
- **Expected Flow**:
  1. Temporal utility resolves `"last month"` start/end range.
  2. `drive.search_files` tool executes with `mime_type="application/pdf"`.
  3. Returns list of PDF documents modified in the target date range.
- **Clarification**: No.
- **Confirmation**: No (Read-Only).

---

## 2. Multi-Service Queries

### Query 4: Flight Cancellation (Gmail + Calendar)
- **Input**: `"Cancel my Turkish Airlines flight"`
- **Services**: `["gmail", "calendar"]`
- **Expected DAG Flow**:
  ```
  Step 1: gmail.search_emails (query: "Turkish Airlines booking TK1234") [Parallel]
  Step 2: calendar.search_events (query: "Turkish Airlines flight")       [Parallel]
  Step 3: gmail.draft_email (to: "support@turkishairlines.com", subject: "Cancellation TK1234")
  ```
- **Clarification**: No.
- **Confirmation**: Required for Step 3 (`gmail.draft_email` / `send_email`).

### Query 5: Meeting Preparation (Calendar + Gmail + Drive)
- **Input**: `"Prepare for tomorrow's meeting with Acme Corp"`
- **Services**: `["calendar", "gmail", "drive"]`
- **Expected DAG Flow**:
  ```
  Step 1: calendar.search_events (query: "Acme Corp")           [Parallel]
  Step 2: gmail.search_emails (query: "Acme Corp budget contract") [Parallel]
  Step 3: drive.search_files (query: "Acme Corp proposal")      [Parallel]
  ```
- **Execution**: Independent search steps execute concurrently via `asyncio.gather()`.
- **Response**: Synthesizes combined executive briefing across all 3 services.
- **Confirmation**: No (Read-Only).

### Query 6: OOO Conflict Detection (Calendar + Drive)
- **Input**: `"Find events next week that conflict with my out-of-office doc"`
- **Services**: `["calendar", "drive"]`
- **Expected DAG Flow**:
  ```
  Step 1: drive.search_files (query: "out of office policy vacation schedule")
  Step 2: calendar.search_events (date_from: next_week_start, date_to: next_week_end)
  ```
- **Conflict Analysis**: Python interval comparison checks overlapping meeting intervals against OOO range.
- **Confirmation**: No.

---

## 3. Hard / Edge Case Queries

### Query 7: Ambiguous Name Clarification
- **Input**: `"Move the meeting with John"`
- **Services**: `["calendar"]`
- **Expected Flow**:
  1. Recipient/attendee resolution checks workspace contacts for `"John"`.
  2. Finds multiple candidates: `John Smith (john.smith@acme.com)` and `John Doe (john.doe@company.com)`.
  3. Flags `intent.ambiguous = True`.
  4. Returns status `"needs_clarification"` with structured candidate choices.
- **Clarification**: **YES**.

### Query 8: Conversation Context Resolution
- **User Message 1**: `"Find emails about the proposal"`
- **User Message 2**: `"That email about the proposal"`
- **Expected Flow**:
  1. `load_conversation_history()` loads recent message context window.
  2. Planner uses conversation history to resolve `"That email"` to the previously returned email subject/id.
- **Confirmation**: No.

### Query 9: Timezone-Aware Temporal Reasoning
- **Input**: `"What meetings do I have next Tuesday?"`
- **Services**: `["calendar"]`
- **Expected Flow**:
  1. `normalize_temporal_expression("next Tuesday", user_timezone="Asia/Kolkata")` computes exact ISO 8601 start (`00:00:00+05:30`) and end (`23:59:59+05:30`).
  2. `calendar.search_events` applies exact date filters.
- **Confirmation**: No.

### Query 10: Human-in-the-Loop Mutating Action
- **Input**: `"Send an email to sarah@company.com with the subject Q3 Budget and body Approved"`
- **Services**: `["gmail"]`
- **Expected Flow**:
  1. Planner generates `gmail.send_email` step.
  2. `ConfirmationEngine` intercepts `is_mutating=True` tool.
  3. Creates `PendingAction` record in DB.
  4. Returns status `"needs_confirmation"` to client.
  5. Client clicks **Confirm Execution** (`POST /api/v1/actions/{id}/confirm`).
  6. Executes `gmail_client.send_message()` via real Gmail REST API.
  7. Returns `status: "completed"` with Gmail `message_id`.
- **Confirmation**: **YES**.
