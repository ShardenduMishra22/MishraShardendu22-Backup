package main

import (
	"log"
	"math/rand"
	"net/http"
	"sync"
	"time"
)

var urls = []string{
	"https://mishrashardendu22.is-a.dev",
	"https://blogs.mishrashardendu22.is-a.dev",
	"https://admin.mishrashardendu22.is-a.dev",
	"https://treasure-hunt.mishrashardendu22.is-a.dev",
	"https://pixel-art-8-bit.mishrashardendu22.is-a.dev",
}

const (
	iterations = 500
)

var concurrency = 5 + rand.Intn(10)

func request(client *http.Client, url string, wg *sync.WaitGroup) {
	defer wg.Done()

	start := time.Now()

	resp, err := client.Get(url)
	if err != nil {
		log.Printf("REQUEST_FAILED url=%s error=%v", url, err)
		return
	}

	resp.Body.Close()

	log.Printf(
		"REQUEST_DONE url=%s status=%d latency=%s",
		url,
		resp.StatusCode,
		time.Since(start),
	)
}

func main() {

	log.SetFlags(log.LstdFlags | log.Lmicroseconds)

	client := &http.Client{
		Timeout: 500 * time.Second,
	}

	log.Printf("START iterations=%d concurrency=%d urls=%d", iterations, concurrency, len(urls))

	for i := 0; i < iterations; i++ {

		batchStart := time.Now()
		log.Printf("BATCH_START iteration=%d", i+1)

		var wg sync.WaitGroup

		for _, u := range urls {
			for j := 0; j < concurrency; j++ {
				wg.Add(1)
				go request(client, u, &wg)
			}
		}

		wg.Wait()

		log.Printf(
			"BATCH_COMPLETE iteration=%d duration=%s",
			i+1,
			time.Since(batchStart),
		)

		log.Printf("WAITING 10s before next batch")
		time.Sleep(10 * time.Second)
	}

	log.Printf("FINISHED all iterations")
}