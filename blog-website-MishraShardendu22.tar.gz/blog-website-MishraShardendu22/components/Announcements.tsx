"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowRight, X } from "lucide-react";
import { Marquee } from "./Marquee";

const ANNOUNCEMENT_ENABLED = false;

const ANNOUNCEMENT = {
  enabled: ANNOUNCEMENT_ENABLED,
  eyebrow: "Event LIVE",
  href: "https://luma.com/lr79szro",
  ctaLabel: "Register NOW",
};

const setAnnouncementHeight = (value: string) => {
  document.documentElement.style.setProperty("--announcement-h", value);
};

const useIsomorphicLayoutEffect = typeof window !== "undefined" ? useLayoutEffect : useEffect;

function MarqueeContent() {
  const items = [
    "Keploy is hosting a community meetup in San Francisco!",
    "GitTogether SF • May 14, 2026 • San Francisco",
    "Tickets are selling fast, limited seats available-register now!",
  ];

  return (
    <>
      {items.map((item) => (
        <span
          key={item}
          className="inline-flex items-center gap-3 whitespace-nowrap text-[12px] text-[#23120a] sm:text-[13px] lg:text-[14px]"
        >
          <span className="font-semibold">{item}</span>
          <span className="inline-block h-[5px] w-[5px] shrink-0 rounded-full bg-[#23120a]/35" />
        </span>
      ))}
    </>
  );
}

export function Announcements() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const touchStartY = useRef<number | null>(null);
  const dismissTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isMarqueePaused, setIsMarqueePaused] = useState(false);
  const [dragY, setDragY] = useState(0);
  const [dismissing, setDismissing] = useState(false);

  useEffect(() => {
    if (!ANNOUNCEMENT.enabled) {
      setAnnouncementHeight("0px");
      return;
    }
    setIsVisible(true);
  }, []);

  // useLayoutEffect on the client so --announcement-h is written before paint,
  // preventing the one-frame flicker where the bar is visible but offsets are still 0.
  useIsomorphicLayoutEffect(() => {
    if (!isVisible || !containerRef.current) {
      setAnnouncementHeight("0px");
      return;
    }

    const node = containerRef.current;
    const syncHeight = () => setAnnouncementHeight(`${node.offsetHeight}px`);

    // rAF-debounced handler so rapid resize events collapse into a single measurement.
    let animationFrameId: number | null = null;
    const scheduleSyncHeight = () => {
      if (animationFrameId !== null) window.cancelAnimationFrame(animationFrameId);
      animationFrameId = window.requestAnimationFrame(() => {
        animationFrameId = null;
        syncHeight();
      });
    };

    syncHeight();

    // ResizeObserver is widely supported but guard for SSR / older environments.
    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== "undefined") {
      resizeObserver = new ResizeObserver(scheduleSyncHeight);
      resizeObserver.observe(node);
    }
    window.addEventListener("resize", scheduleSyncHeight);

    return () => {
      resizeObserver?.disconnect();
      window.removeEventListener("resize", scheduleSyncHeight);
      if (animationFrameId !== null) window.cancelAnimationFrame(animationFrameId);
    };
  }, [isVisible]);

  // Clear the swipe-dismiss timer if the component unmounts mid-animation.
  useEffect(() => {
    return () => {
      if (dismissTimerRef.current !== null) clearTimeout(dismissTimerRef.current);
    };
  }, []);

  const handleDismiss = () => {
    if (dismissTimerRef.current !== null) {
      clearTimeout(dismissTimerRef.current);
      dismissTimerRef.current = null;
    }

    // Reset height immediately so the header/nav offsets collapse on the same frame.
    setAnnouncementHeight("0px");
    setDismissing(false);
    setDragY(0);
    touchStartY.current = null;
    setIsVisible(false);
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchStartY.current === null) return;
    const dy = e.touches[0].clientY - touchStartY.current;
    if (dy < 0) setDragY(dy);
  };

  const handleTouchEnd = () => {
    if (dragY < -50) {
      setDismissing(true);
      dismissTimerRef.current = setTimeout(handleDismiss, 220);
    } else {
      setDragY(0);
    }
    touchStartY.current = null;
  };

  if (!ANNOUNCEMENT.enabled || !isVisible) {
    return null;
  }

  return (
    <div
      ref={containerRef}
      role="region"
      aria-label="Event announcement"
      className="fixed inset-x-0 top-0 z-[60] border-b border-white/40 bg-cover bg-center bg-no-repeat shadow-[0_12px_30px_rgba(234,88,12,0.16)] backdrop-blur"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      style={{
        backgroundImage: "url('https://keploy-devrel.s3.us-west-2.amazonaws.com/landing/announcement-bar-bg.webp')",
        transform: dismissing ? "translateY(-110%)" : dragY < 0 ? `translateY(${dragY}px)` : undefined,
        opacity: dismissing ? 0 : dragY < 0 ? Math.max(0.15, 1 + dragY / 60) : undefined,
        transition: dragY !== 0 && !dismissing ? "none" : "transform 0.22s ease, opacity 0.18s ease",
      }}
    >
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-white/10" />

      <div className="relative mx-auto max-w-[1440px] pl-3 pr-12 py-1 sm:px-5 sm:pr-12 lg:px-12 lg:py-1.5">
        {/* Mobile: single row — marquee + compact CTA. Swipe up to dismiss. */}
        <div className="flex min-w-0 items-center gap-2 lg:hidden">
          <div
            onMouseEnter={() => setIsMarqueePaused(true)}
            onMouseLeave={() => setIsMarqueePaused(false)}
            onPointerEnter={() => setIsMarqueePaused(true)}
            onPointerLeave={() => setIsMarqueePaused(false)}
            className="min-w-0 flex-1 overflow-hidden"
          >
            <Marquee
              paused={isMarqueePaused}
              repeat={10}
              className="max-w-full px-0 py-0 [--duration:25s] [--gap:1.25rem]"
            >
              <MarqueeContent />
            </Marquee>
          </div>

          <Link
            href={ANNOUNCEMENT.href}
            target="_blank"
            rel="noopener noreferrer"
            className="group shrink-0 inline-flex h-6 items-center gap-1 rounded-full border border-black/90 bg-black px-2.5 text-[10px] font-semibold text-white transition hover:bg-[#0a0a0a]"
          >
            <span className="transition-all group-hover:bg-gradient-to-r group-hover:from-[#39ff14] group-hover:to-[#00f5ff] group-hover:bg-clip-text group-hover:text-transparent">
              {ANNOUNCEMENT.ctaLabel}
            </span>
            <ArrowRight className="h-2.5 w-2.5 transition-colors group-hover:text-[#39ff14]" />
          </Link>
        </div>

        {/* Desktop layout */}
        <div className="hidden min-w-0 items-center gap-4 lg:flex">
          <span className="inline-flex h-8 shrink-0 items-center justify-center gap-2 rounded-full border border-white/20 bg-black px-4 text-[10px] font-extrabold tracking-[0.08em] leading-none text-white">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#00ff87]/75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[#00ff87]" />
            </span>
            {ANNOUNCEMENT.eyebrow}
          </span>

          <div
            className="min-w-0 flex-1"
            onMouseEnter={() => setIsMarqueePaused(true)}
            onMouseLeave={() => setIsMarqueePaused(false)}
            onPointerEnter={() => setIsMarqueePaused(true)}
            onPointerLeave={() => setIsMarqueePaused(false)}
          >
            <Marquee
              paused={isMarqueePaused}
              repeat={10}
              className="max-w-full px-0 py-0 [--duration:35s] [--gap:1.5rem]"
            >
              <MarqueeContent />
            </Marquee>
          </div>

          <Link
            href={ANNOUNCEMENT.href}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex h-8 shrink-0 items-center justify-center gap-1.5 rounded-full border border-black/90 bg-black px-4 text-[13px] font-semibold text-white shadow-[0_12px_28px_rgba(0,0,0,0.28)] transition hover:-translate-y-0.5 hover:bg-[#0a0a0a] hover:shadow-[0_16px_34px_rgba(0,0,0,0.36)]"
          >
            <span className="transition-all group-hover:bg-gradient-to-r group-hover:from-[#39ff14] group-hover:to-[#00f5ff] group-hover:bg-clip-text group-hover:text-transparent">
              {ANNOUNCEMENT.ctaLabel}
            </span>
            <ArrowRight className="h-3.5 w-3.5 transition-colors group-hover:text-[#39ff14]" />
          </Link>
        </div>
      </div>

      <button
        type="button"
        onClick={handleDismiss}
        aria-label="Dismiss announcement"
        className="absolute right-3 top-1/2 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full border border-white/75 bg-white/18 text-[#6f2b00] transition hover:bg-white/30 lg:right-4"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
