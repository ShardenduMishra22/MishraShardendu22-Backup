import Head from "next/head";
import Layout from "../../components/layout";
import Header from "../../components/header";
import Container from "../../components/container";
import {
  getAllPosts,
  getContent,
  getPostsByAuthorName,
} from "../../lib/api";
import { GetStaticPaths, GetStaticProps } from "next";
import PostByAuthorMapping from "../../components/postByAuthorMapping";
import { HOME_OG_IMAGE_URL } from "../../lib/constants";
import { sanitizeAuthorSlug } from "../../utils/sanitizeAuthorSlug";
import { getBreadcrumbListSchema, MAIN_SITE_URL, SITE_URL } from "../../lib/structured-data";

export default function AuthorPage({ preview, filteredPosts, content }) {
  if (!filteredPosts || filteredPosts.length === 0) {
    return (
      <div>
        <p>No posts found for this author.</p>
      </div>
    );
  }

  const authorName = filteredPosts[0]?.node?.ppmaAuthorName || "Keploy Author";
  const authorSlug = sanitizeAuthorSlug(authorName);
  const authorUrl = `${SITE_URL}/authors/${authorSlug}`;
  const pageTitle = `${authorName} — Keploy Blog Author`;
  const pageDescription = `Read all articles by ${authorName} on the Keploy blog — covering software testing, API development, automation, and engineering best practices.`;

  // Person JSON-LD for E-E-A-T author credibility (LIVE-11).
  // AI models use Person.url + sameAs to resolve author identity and
  // weight the authority of the pages they cite. worksFor.url points at
  // MAIN_SITE_URL (https://keploy.io) — not the blog subpath — so the
  // Organization entity is consistent across every JSON-LD payload.
  const personSchema = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: authorName,
    url: authorUrl,
    jobTitle: "Contributor",
    worksFor: {
      "@type": "Organization",
      name: "Keploy",
      url: MAIN_SITE_URL,
    },
    knowsAbout: [
      "API Testing",
      "Test Automation",
      "Software Engineering",
      "Developer Tools",
    ],
  };

  return (
    <div className="bg-accent-1">
      {/*
        LIVE-11 fix. Previously the <title> tag was absent from author
        pages because components/meta.tsx does not emit a <title>, and
        this page never added one locally. Authors pages returned 200
        with empty <title></title>, which kills CTR and AI extraction
        signal.
      */}
      <Head>
        <title>{pageTitle}</title>
      </Head>
      <Layout
        preview={preview}
        featuredImage={HOME_OG_IMAGE_URL}
        Title={pageTitle}
        Description={pageDescription}
        structuredData={[
          getBreadcrumbListSchema([
            { name: "Home", url: SITE_URL },
            { name: "Authors", url: `${SITE_URL}/authors` },
            { name: authorName, url: authorUrl },
          ]),
          personSchema,
        ]}
        canonicalUrl={authorUrl}
      >
        {/* DM Sans + Baloo 2 are preloaded globally in _document.tsx */}
        <Header />
        <Container>
          <PostByAuthorMapping filteredPosts={filteredPosts} Content={content} />
        </Container>
      </Layout>
    </div>
  );
}
export const getStaticPaths: GetStaticPaths = async ({ }) => {
  try {
    const allPosts = await getAllPosts();
    const uniqueNames = new Set<string>();

    allPosts?.edges?.forEach(({ node }) => {
      const authorName = node?.ppmaAuthorName;
      if (typeof authorName === "string" && authorName.trim().length > 0) {
        uniqueNames.add(authorName);
      }
    });

    const paths = Array.from(uniqueNames).map((name) => `/authors/${sanitizeAuthorSlug(name)}`);

    return {
      paths,
      fallback: true,
    };
  } catch (error) {
    console.error("authors/[slug] getStaticPaths error:", error);
    return {
      paths: [],
      fallback: true,
    };
  }
};

export const getStaticProps: GetStaticProps = async ({
  preview = false,
  params,
}) => {
  const slugParam = params?.slug;

  if (typeof slugParam !== "string" || slugParam.trim().length === 0) {
    return {
      notFound: true,
      revalidate: 60,
    };
  }

  const normalizedSlug = slugParam.toLowerCase();
  const slugWords = normalizedSlug.split(/[-_\s]+/).filter(Boolean);
  const capitalise = (word: string) => word.charAt(0).toUpperCase() + word.slice(1);
  const titleCaseName = slugWords.map(capitalise).join(" ");
  const spacedLower = slugWords.join(" ");
  const hyphenLower = slugWords.join("-");
  const titleHyphen = slugWords.map(capitalise).join("-");

  const candidateAuthorNames = new Set<string>();
  candidateAuthorNames.add(slugParam);
  candidateAuthorNames.add(normalizedSlug);
  if (spacedLower) candidateAuthorNames.add(spacedLower);
  if (hyphenLower) candidateAuthorNames.add(hyphenLower);
  if (titleCaseName) candidateAuthorNames.add(titleCaseName);
  if (titleHyphen) candidateAuthorNames.add(titleHyphen);
  if (slugWords.length) {
    candidateAuthorNames.add(capitalise(slugWords[0]));
    candidateAuthorNames.add(slugWords[0]);
  }

  let filteredPosts = [];

  for (const candidate of Array.from(candidateAuthorNames)) {
    if (!candidate) continue;
    try {
      const postsResponse = await getPostsByAuthorName(candidate);
      const edges = postsResponse?.edges || [];
      if (edges.length > 0) {
        filteredPosts = edges;
        break;
      }
    } catch (error) {
      console.error(`authors/[slug] failed to fetch posts for candidate "${candidate}":`, error);
    }
  }

  if (!filteredPosts.length) {
    try {
      const allPostsResponse = await getAllPosts();
      filteredPosts =
        allPostsResponse?.edges?.filter(({ node }) => {
          const candidateName = node?.ppmaAuthorName;
          if (!candidateName || Array.isArray(candidateName)) {
            return false;
          }
          return sanitizeAuthorSlug(candidateName) === sanitizeAuthorSlug(slugParam);
        }) || [];
    } catch (error) {
      console.error("authors/[slug] fallback to getAllPosts failed:", error);
      filteredPosts = [];
    }
  }

  // Return a proper 404 instead of rendering a page with empty content (soft 404)
  if (!filteredPosts.length) {
    return {
      notFound: true,
      revalidate: 60,
    };
  }

  let content = null;
  const postId = filteredPosts[0]?.node?.postId;
  if (postId) {
    try {
      content = await getContent(postId);
    } catch (error) {
      console.error(`authors/[slug] failed to fetch content for postId ${postId}:`, error);
    }
  }

  return {
    props: {
      preview,
      filteredPosts,
      content,
    },
    revalidate: 60,
  };
};

