import type { Metadata, Viewport } from "next";
import { Instrument_Serif, Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";

const instrumentSerif = Instrument_Serif({
  variable: "--font-heading",
  subsets: ["latin"],
  weight: ["400"],
  style: ["normal", "italic"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-body",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  display: "swap",
});

const ibmPlexMono = IBM_Plex_Mono({
  variable: "--font-mono",
  subsets: ["latin"],
  weight: ["400", "500"],
  display: "swap",
});

export const viewport: Viewport = {
  themeColor: "#141413",
  colorScheme: "dark",
};

export const metadata: Metadata = {
  title: "GitHub Repository Transfer Automation",
  description: "Automated bulk repository transfers across GitHub accounts and organizations.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${instrumentSerif.variable} ${inter.variable} ${ibmPlexMono.variable} bg-[#141413] text-[#faf8f5] antialiased selection:bg-[#d97757] selection:text-white font-sans`}>
        {children}
      </body>
    </html>
  );
}
