# Enterprise Git History Rewriting & Commit Telemetry Platform

<div align="center">

[![Maintenance: Actively Maintained](https://img.shields.io/badge/Maintenance-Actively%20Maintained-brightgreen.svg)](#maintenance-sla--support)
[![CI Quality Gate](https://github.com/MishraShardendu22/git-metadata-rewriter/actions/workflows/ci.yml/badge.svg)](https://github.com/MishraShardendu22/git-metadata-rewriter/actions)
[![License: Proprietary](https://img.shields.io/badge/License-Proprietary-red.svg)](LICENSE)
[![Architecture: Go Microservices](https://img.shields.io/badge/Architecture-Go%20Microservices-00ADD8?logo=go)](#conceptual-architecture)
[![Frontend: Go Templ](https://img.shields.io/badge/Frontend-Go%20Templ-3b82f6)](#core-capabilities)

</div>

> [!IMPORTANT]
> **PROPRIETARY & CLOSED-SOURCE SOFTWARE**
> This repository is a public product showcase and high-level architectural specification. The underlying codebase, microservices, sandboxed graph transformers, and AI distribution algorithms are strictly **closed source and proprietary**, owned by **Shardendu Mishra**.
> Unauthorized duplication, reproduction, reverse engineering, or commercial imitation is strictly prohibited under international copyright laws.

---

## Executive Summary

The **Enterprise Git History Rewriting & Commit Telemetry Platform** is a specialized distributed microservice suite engineered to programmatically manipulate, re-anchor, and simulate complex Git commit DAGs (Directed Acyclic Graphs) with realistic temporal distributions and cryptographic integrity verification.

Built for enterprise migrations, repository normalization, and audit compliance, the platform provides guaranteed object graph integrity while offering non-destructive dry-run simulations and visual telemetry.

---

## Core Capabilities

| Capability | Specification | Enterprise Benefit |
| :--- | :--- | :--- |
| **Sandboxed Workspace Isolation** | Ephemeral `/tmp/rewriter-workspaces/<job-id>` sandboxes with reflog backup | Zero risk of corrupting developer or production host repositories |
| **AI Diurnal Timestamp Modeling** | Interfaces with LLM reasoning models to generate human developer activity patterns | Avoids unnatural burst signatures, creating realistic historical activity curves |
| **Deterministic Time Interpolation** | Linear distribution algorithm with realistic working-hours offset | Predictable, audit-compliant commit spacing across defined temporal windows |
| **Cryptographic Integrity Verification** | Mandatory `git fsck --full` verification across all rewritten trees | Guarantees zero corrupted tree objects or missing blob hashes |
| **Dry-Run Non-Destructive Preview** | Interactive visual diff of original vs rewritten commit hashes and dates | Eliminates accidental overwrites; requires explicit verification before remote push |
| **Microservice Architecture** | Decoupled REST server (`backend/`) and background worker (`worker/`) | Scales independently and handles multi-repository batch jobs asynchronously |

---

## Conceptual Architecture

```text
┌─────────────────────────────────────────────────────────────┐
│                 Go + Templ Web Dashboard                   │
│         (Compiled Type-Safe SSR Frontend /web)              │
└───────────────┬─────────────────────────────┬───────────────┘
                │ Form Submission / Trigger   │ Live Telemetry Polling
                ▼                             ▼
┌─────────────────────────────────────────────────────────────┐
│                  Go Backend REST Server                     │
│        (HTTP API · Job Store · Preview Diff Service)        │
└───────────────┬─────────────────────────────────────────────┘
                │ Work Queue / Context Dispatch
                ▼
┌─────────────────────────────────────────────────────────────┐
│                 Rewriter Worker Engine                      │
│   (Sandboxed Git Executor · Graph Parser · LLM Client)      │
└───────┬──────────────────────┬──────────────────────┬───────┘
        │ Bare Clone / Fetch   │ AI Distribution API  │ Filter-Branch
        ▼                      ▼                      ▼
┌──────────────────┐   ┌──────────────────┐   ┌──────────────────┐
│ Sandboxed /tmp   │   │ OpenRouter /     │   │ Target Git       │
│ Workspace        │   │ Gemini APIs      │   │ Remote (SSH)     │
└──────────────────┘   └──────────────────┘   └──────────────────┘
```

---

## Pipeline Execution Stages

```text
[Stage 1: Sandboxed Clone]
    │ Clones bare repository into ephemeral /tmp workspace
    ▼
[Stage 2: Commit Graph Traversal]
    │ Parses DAG: git log --reverse --format="%H|%an|%ae|%ad|%s"
    ▼
[Stage 3: Temporal Simulation]
    │ Generates realistic timestamps (AI model or linear spacing)
    ▼
[Stage 4: History Rewrite Pipeline]
    │ Executes git filter-branch / git-filter-repo with environment hooks
    ▼
[Stage 5: Object Verification]
    │ Full verification: git fsck --full guarantees 100% object integrity
    ▼
[Stage 6: Preview / Remote Sync]
    │ Visual diff preview in Templ UI; optional force-with-lease push
```

---

## Maintenance, SLA & Support

- **Active Maintenance**: Specifications, Git internal compatibility checks, and security definitions are maintained under active governance.
- **Continuous Audit**: Automated CI quality gates test link integrity, specification schemas, and security standards on every commit.
- **Support SLA**: Enterprise support for high-throughput migration tooling is handled under commercial support SLA.

For guidelines, review [SECURITY.md](SECURITY.md) and [CONTRIBUTING.md](CONTRIBUTING.md).

---

## Commercial Licensing & Enterprise Inquiries

Access to the proprietary implementation codebase, pre-built Docker containers, and enterprise migration tooling is provided exclusively under commercial agreement.

- **Author & Copyright Holder**: Shardendu Mishra
- **Direct Email**: mishrashardendu22@gmail.com
- **Website**: [mishrashardendu22.is-a.dev](https://mishrashardendu22.is-a.dev)
- **GitHub Profile**: [@MishraShardendu22](https://github.com/MishraShardendu22)

---

## License

Copyright &copy; 2026 Shardendu Mishra. All Rights Reserved.
This project is proprietary and closed-source software. See [LICENSE](LICENSE) for full terms.
