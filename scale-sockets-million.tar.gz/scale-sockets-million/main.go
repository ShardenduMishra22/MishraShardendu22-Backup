package main

import (
	"log"
	"net/http"
	"os"

	"github.com/MishraShardendu22/scale-sockets-millions/handler"
)

var PORT = os.Getenv("PORT")

func main() {
	log.Println("Scaling to a Million Web Sockets with Go")
	app := http.NewServeMux()

	// Curious about why we dont pass "w http.ResponseWriter, r *http.Request" in function,
	// but want it as an argument?
	app.HandleFunc("/home", handler.HomeHandler)
	app.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("internal/static"))))

	app.HandleFunc("/", handler.LanderHandler)
	app.HandleFunc("/ws", handler.WSHandler)

	sub := handler.PubSub.Subscribe("global")

	ch := sub.Channel()

	go func() {
		for msg := range ch {
			handler.Hub.Broadcast(
				"global",
				[]byte(msg.Payload),
			)
		}
	}()

	server := &http.Server{
		Addr:    ":" + PORT,
		Handler: app,
	}

	if err := server.ListenAndServe(); err != nil {
		log.Fatalf("Server failed to start: %v", err)
	}
}

// app.HandleFunc("/", handlers.HomeHandler)
// you are passing the function itself, not calling it.

// HandleFunc
// func (mux *ServeMux) HandleFunc(pattern string, handler func(ResponseWriter, *Request)) {
// 	if use121 {
// 		mux.mux121.handleFunc(pattern, handler)
// 	} else {
// 		mux.register(pattern, HandlerFunc(handler))
// 	}
// }
