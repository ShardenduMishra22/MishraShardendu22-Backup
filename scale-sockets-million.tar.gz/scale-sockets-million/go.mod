module github.com/MishraShardendu22/scale-sockets-millions

go 1.26.2

require (
	github.com/a-h/templ v0.3.1020
	github.com/go-redis/redis/v8 v8.11.5
	github.com/gobwas/ws v1.4.0
)

require (
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/dgryski/go-rendezvous v0.0.0-20200823014737-9f7001d12a5f // indirect
	github.com/gobwas/httphead v0.1.0 // indirect
	github.com/gobwas/pool v0.2.1 // indirect
	golang.org/x/sys v0.41.0 // indirect
)
