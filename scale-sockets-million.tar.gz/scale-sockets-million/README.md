# Scale Sockets Million

A horizontally-scalable WebSocket server written in Go, using **Redis Pub/Sub** as a distributed message broker to scale beyond a single server's connection limit.

## Architecture Overview

```
┌───────────────────────────────────────────────────────────────────────────────────┐
│                            Clients (Browsers)                                     │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐      ┌─────────┐  ┌─────────┐  ┌─────────┐ │
│  │Client A1│  │Client A2│  │Client A3│      │Client B1│  │Client B2│  │Client B3│ │
│  └────┬────┘  └────┬────┘  └────┬────┘      └────┬────┘  └────┬────┘  └────┬────┘ │
│       │WS          │WS          │WS              │WS          │WS          │WS    │
└───────┼────────────┼────────────┼────────────────┼────────────┼────────────┼──────┘
        │            │            │                │            │            │
        ▼            ▼            ▼                ▼            ▼            ▼
┌───────────────────────────────┐  ┌───────────────────────────────┐
│      Go Server Instance A     │  │      Go Server Instance B     │
│                               │  │                               │
│  ┌─────────────────────────┐  │  │  ┌─────────────────────────┐  │
│  │   WebSocket Hub (Local) │  │  │  │   WebSocket Hub (Local) │  │
│  │   ┌───┐ ┌───┐ ┌───┐     │  │  │  | ┌───┐ ┌───┐ ┌───┐       │  │
│  │   │ A1│ │A2 │ │A3 │     │  │  │  | │ B1│ │B2 │ │B3 │       │  │
│  │   └───┘ └───┘ └───┘     │  │  │  | └───┘ └───┘ └───┘       │  │
│  └──────────┬──────────────┘  │  │  └──────────┬──────────────┘  │
│             │Subscribe        │  │             │Subscribe        │
│             │("global")       │  │             │("global")       │
│  ┌──────────▼──────────────┐  │  │  ┌──────────▼──────────────┐  │
│  │  Redis PubSub Client    │  │  │  │  Redis PubSub Client    │  │
│  │  (Publisher/Subscriber) │  │  │  │  (Publisher/Subscriber) │  │
│  └──────────┬──────────────┘  │  │  └──────────┬──────────────┘  │
└─────────────┼─────────────────┘  └─────────────┼─────────────────┘
              │Publish                           │Publish
              │("global", msg)                   │("global", msg)
              │                                  │
              ▼                                  ▼
    ┌─────────────────────────────────────────────────┐
    │                                                 │
    │              Redis Broker (Pub/Sub)             │
    │                                                 │
    │   ┌─────────────────────────────────────────┐   │
    │   │         Channel: "global"               │   │
    │   │  Message Queue ──────────────────────►  │   │
    │   │  Fan-out to all subscribed servers      │   │
    │   └─────────────────────────────────────────┘   │
    │                                                 │
    └─────────────────────────────────────────────────┘
```

## How It Works

### The Problem: WebSocket Scalability

A single WebSocket server has a finite connection limit (typically 10K–100K per machine due to OS file descriptors, memory, and CPU). To handle **millions** of concurrent WebSocket connections, you need multiple server instances — but WebSocket connections are **stateful** and **long-lived**, so a client sticks to one server.

When a client on Server A sends a message, clients on Server B need to receive it too. This is where **Redis Pub/Sub** acts as the broker.

### The Solution: Redis Broker Pattern

```
┌──────────────────┐
│ 1. Client sends  │
│    message       │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ 2. WS Handler    │
│    reads msg     │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ 3. Publish to    │
│    Redis channel │  ◄── PubSub.Publish("global", msg)
└────────┬─────────┘
         │
         ▼
┌──────────────────────────────────────┐
│ 4. Redis fans-out to all subscribed  │
│    server instances                  │
└────────┬──────────────────────┬──────┘
         │                      │
         ▼                      ▼
┌──────────────────┐  ┌──────────────────┐
│ 5. Server A      │  │ 5. Server B      │
│    receives msg  │  │    receives msg  │
│    via Subscribe │  │    via Subscribe │
└────────┬─────────┘  └────────┬─────────┘
         │                      │
         ▼                      ▼
┌──────────────────┐  ┌──────────────────┐
│ 6. Hub.Broadcast │  │ 6. Hub.Broadcast │
│    to local      │  │    to local      │
│    clients in    │  │    clients in    │
│    "global" room │  │    "global" room │
└────────┬─────────┘  └────────┬─────────┘
         │                      │
         ▼                      ▼
┌──────────────────┐  ┌──────────────────┐
│ Client A1,A2,A3  │  │ Client B1,B2,B3  │
│ receive message  │  │ receive message  │
└──────────────────┘  └──────────────────┘
```

### Data Flow (Step by Step)

1. **Client connects via WebSocket** to any server instance (load-balanced).
2. **WebSocket handler** upgrades the HTTP connection and registers the client in the local `Hub` with a room (e.g., `"global"`).
3. **Client sends a message** — the handler reads it via `wsutil.ReadClientData`.
4. **Message is published to Redis** on a channel matching the room name (e.g., `"global"`).
5. **Redis Pub/Sub fans out** the message to every server instance that subscribed to that channel.
6. **Each server's subscriber goroutine** (started in `main.go`) receives the message from the Redis channel.
7. **The message is broadcast** to all **locally connected clients** in that room via `Hub.Broadcast()`.
8. **Clients receive the message** — even though it originated from a client on a different server.

### Key Components

| Component | File | Role |
|-----------|------|------|
| **`Hub`** | `internal/websocket/hub.go` | In-memory registry of connected WebSocket clients, organized by room. Thread-safe with `sync.Mutex`. |
| **`Client`** | `internal/websocket/hub.go` | Represents a single WebSocket connection with its room and metadata. |
| **`PubSub`** | `internal/redis/pubsub.go` | Redis Pub/Sub client wrapper. Provides `Publish` and `Subscribe` methods. |
| **`WSHandler`** | `handler/ws.handler.go` | HTTP → WebSocket upgrade handler. Reads client messages and publishes them to Redis. |
| **`main.go`** | `main.go` | Entry point. Subscribes to Redis channels, runs a goroutine to forward Redis messages into the local Hub. |

### Scaling Strategy

```
                ┌──────────────┐
                │  Load        │
                │  Balancer    │
                │  (Round Robin│
                │   / Least    │
                │  Connections)│
                └──────┬───────┘
                       │
        ┌──────────────┼──────────────┐
        │              │              │
        ▼              ▼              ▼
    ┌────────┐     ┌────────┐     ┌────────┐
    │Server 1│     │Server 2│     │Server N│  ...  Horizontal scaling
    │  Hub   │     │  Hub   │     │  Hub   │       (add more servers)
    └───┬────┘     └───┬────┘     └───┬────┘
        │              │              │
        └──────────────┼──────────────┘
                       │
                       ▼
                ┌──────────────┐
                │    Redis     │
                │   Pub/Sub    │
                │   Broker     │
                └──────────────┘
```

- **No sticky sessions required** — Redis handles cross-server message delivery.
- **Add more servers** to handle more concurrent WebSocket connections.
- **Redis is the single source of truth** for room-based message routing across instances.
- **Each server only broadcasts to its own clients** — no direct inter-server communication.

### Code Walkthrough

**`internal/redis/pubsub.go`** — Redis client wrapper
```go
func NewPubSub() *PubSub {
    rdb := goredis.NewClient(&goredis.Options{Addr: "localhost:6379"})
    return &PubSub{Client: rdb, Ctx: context.Background()}
}
func (ps *PubSub) Publish(channel, message string) error {
    return ps.Client.Publish(ps.Ctx, channel, message).Err()
}
func (ps *PubSub) Subscribe(channel string) *goredis.PubSub {
    return ps.Client.Subscribe(ps.Ctx, channel)
}
```

**`main.go`** — Subscriber goroutine that bridges Redis → Hub
```go
sub := handler.PubSub.Subscribe("global")
ch := sub.Channel()
go func() {
    for msg := range ch {
        handler.Hub.Broadcast("global", []byte(msg.Payload))
    }
}()
```

**`handler/ws.handler.go`** — Publisher that bridges Hub → Redis
```go
msg, _, err := wsutil.ReadClientData(client.Conn)
// ...
PubSub.Publish(client.Room, string(msg))
```

## Getting Started

### Prerequisites

- Go 1.21+
- Redis (running on `localhost:6379`)

### Run Locally

```bash
# Clone the repo
git clone https://github.com/MishraShardendu22/scale-sockets-million.git
cd scale-sockets-million

# Start Redis (using Docker)
docker run -d -p 6379:6379 redis:7-alpine

# Run the server
go run main.go
```

### Scale Horizontally

```bash
# Terminal 1 — Server A on port 8080
PORT=8080 go run main.go

# Terminal 2 — Server B on port 8081
PORT=8081 go run main.go

# Terminal 3 — Server C on port 8082
PORT=8082 go run main.go
```

Open multiple browser tabs to different servers — messages from one will appear across all.

## Tech Stack

- **Go** — Fast, lightweight, excellent for concurrent WebSocket handling
- **`gobwas/ws`** — Zero-allocation WebSocket library (production-grade, no frameworks)
- **`go-redis/redis/v8`** — Redis client with native Pub/Sub support
- **Redis** — Distributed message broker enabling horizontal scaling

## Why Redis as a Broker?

| Requirement | Redis Pub/Sub |
|-------------|--------------|
| **Low latency** | ✅ Sub-millisecond publish/fan-out |
| **Fan-out** | ✅ One publish → all subscribers receive |
| **Simple** | ✅ No Kafka/ZMQ complexity for real-time chat |
| **At-most-once delivery** | ✅ Good for real-time messaging (no durability needed) |
| **Horizontal scaling** | ✅ Any number of servers can subscribe |

> **Note:** Redis Pub/Sub provides at-most-once delivery. If a server disconnects, it misses messages. For guaranteed delivery, consider Redis Streams or Kafka.