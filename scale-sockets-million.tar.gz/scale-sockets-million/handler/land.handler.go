package handler

import (
	"net/http"

	"github.com/MishraShardendu22/scale-sockets-millions/internal/views"
)

func LanderHandler(w http.ResponseWriter, r *http.Request) {
	views.Home().Render(r.Context(), w)
}
