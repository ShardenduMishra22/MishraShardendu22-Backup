package handler

import (
	"log"
	"net/http"

	"github.com/gobwas/ws"
	"github.com/gobwas/ws/wsutil"

	"github.com/MishraShardendu22/scale-sockets-millions/internal/redis"
	wsHub "github.com/MishraShardendu22/scale-sockets-millions/internal/websocket"
)

var Hub = wsHub.NewHub()
var PubSub = redis.NewPubSub()

func WSHandler(w http.ResponseWriter, r *http.Request) {
	conn, _, _, err := ws.UpgradeHTTP(r, w)
	if err != nil {
		log.Println(err)
		return
	}

	client := &wsHub.Client{
		Conn:     conn,
		Room:     "global",
		Username: "anonymous",
	}

	Hub.AddClient(client)
	log.Println("Client connected")

	defer func() {
		// Previously:
		// hub.RemoveClient(conn)
		Hub.RemoveClient(client)

		log.Println("Client disconnected")
	}()

	for {
		msg, _, err := wsutil.ReadClientData(client.Conn)
		if err != nil {
			log.Println("Disconnected")
			break
		}

		log.Printf("Message: %s\n", msg)

		// Previously:
		// hub.Broadcast(conn, msg)

		// Previously:
		// hub.Broadcast(client.Room, msg)

		PubSub.Publish(client.Room, string(msg))
	}
}

// Production grade Web Socket handler
// go get github.com/gobwas/ws
