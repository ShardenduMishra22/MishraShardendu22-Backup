package websocket

import (
	"net"
	"sync"

	"github.com/gobwas/ws/wsutil"
)

type Client struct {
	ID       string
	Room     string
	Conn     net.Conn
	Username string
}

type Hub struct {
	mu      sync.Mutex
	clients map[net.Conn]*Client
	rooms   map[string]map[net.Conn]*Client
}

func NewHub() *Hub {
	return &Hub{
		clients: make(map[net.Conn]*Client),
		rooms:   make(map[string]map[net.Conn]*Client),
	}
}

func (h *Hub) AddClient(client *Client) {
	h.mu.Lock()
	defer h.mu.Unlock()

	h.clients[client.Conn] = client
	if _, exists := h.rooms[client.Room]; !exists {
		h.rooms[client.Room] = make(map[net.Conn]*Client)
	}

	h.rooms[client.Room][client.Conn] = client
}

func (h *Hub) RemoveClient(client *Client) {
	h.mu.Lock()
	defer h.mu.Unlock()

	delete(h.clients, client.Conn)

	if roomClients, exists := h.rooms[client.Room]; exists {
		delete(roomClients, client.Conn)

		if len(roomClients) == 0 {
			delete(h.rooms, client.Room)
		}
	}

	client.Conn.Close()
}

func (h *Hub) Broadcast(room string, msg []byte) {
	h.mu.Lock()

	roomClients, exists := h.rooms[room]
	if !exists {
		h.mu.Unlock()
		return
	}

	clients := make([]*Client, 0, len(roomClients))

	for _, client := range roomClients {
		clients = append(clients, client)
	}

	h.mu.Unlock()
	var disconnected []*Client

	for _, client := range clients {
		err := wsutil.WriteServerText(client.Conn, msg)
		if err != nil {
			disconnected = append(disconnected, client)
		}
	}

	for _, client := range disconnected {
		h.RemoveClient(client)
	}

	// for client := range h.clients {
	// 	// not needed but can be used to avoid sending the message back to the sender
	// 	// if we are already adding the message as html when sent
	// 	// if client == sender {
	// 	// 	continue
	// 	// }

	// 	err := wsutil.WriteServerText(client, msg)
	// 	if err != nil {
	// 		h.RemoveClient(client)
	// 		client.Close()
	// 	}
	// }
}
