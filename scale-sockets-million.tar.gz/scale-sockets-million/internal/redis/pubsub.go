package redis

import (
	"context"

	goredis "github.com/go-redis/redis/v8"
)

type PubSub struct {
	Client *goredis.Client
	Ctx    context.Context
}

func NewPubSub() *PubSub {
	rdb := goredis.NewClient(&goredis.Options{
			Addr: "localhost:6379",
	})

	return &PubSub{
		Client: rdb,
		Ctx:    context.Background(),
	}
}


func (ps *PubSub) Publish(channel string, message string) error {
	return ps.Client.Publish(ps.Ctx,channel,message).Err()
}

func (ps *PubSub) Subscribe(channel string) *goredis.PubSub {
	return ps.Client.Subscribe(ps.Ctx, channel)
}
