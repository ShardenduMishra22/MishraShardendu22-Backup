if (window.scaleSocketsAppLoaded) {
    console.warn("scale sockets app already initialized");
} else {
    window.scaleSocketsAppLoaded = true;

    document.addEventListener("DOMContentLoaded", () => {
        const input = document.getElementById("msg");
        const messages = document.getElementById("messages");

        if (!input || !messages) {
            console.error("Missing DOM elements: #msg or #messages");
            return;
        }

        const protocol = location.protocol === "https:" ? "wss" : "ws";
        const ws = new WebSocket(`${protocol}://${location.host}/ws`);

        ws.onopen = () => {
            console.log("connected");
        };

        ws.onmessage = (event) => {
            const li = document.createElement("li");
            li.innerText = event.data;
            messages.appendChild(li);
        };

        ws.onclose = () => {
            console.log("disconnected");
        };

        ws.onerror = (err) => {
            console.error(err);
        };

        function sendMessage() {
            const value = input.value.trim();
            if (!value) {
                return;
            }

            ws.send(value);
            input.value = "";
        }

        input.addEventListener("keydown", (event) => {
            if (event.key === "Enter") {
                sendMessage();
            }
        });

        window.sendMessage = sendMessage;
    });
}
