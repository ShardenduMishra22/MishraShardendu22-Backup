// Package config provides configuration structures for the application.
package config

import (
	"fmt"
	"strings"
	"time"

	"go.keploy.io/server/v3/pkg/models"
)

type Config struct {
	Path                  string              `json:"path" yaml:"path" mapstructure:"path"`
	StorageFormat         string              `json:"storageFormat" yaml:"storageFormat" mapstructure:"storageFormat"` // serialization format for testcases/mocks/reports: "yaml" (default) or "json"
	AppName               string              `json:"appName" yaml:"appName" mapstructure:"appName"`
	AppID                 uint64              `json:"appId" yaml:"appId" mapstructure:"appId"` // deprecated field
	Command               string              `json:"command" yaml:"command" mapstructure:"command"`
	Templatize            Templatize          `json:"templatize" yaml:"templatize" mapstructure:"templatize"`
	Port                  uint32              `json:"port" yaml:"port" mapstructure:"port"`
	E2E                   bool                `json:"e2e" yaml:"e2e" mapstructure:"e2e"`
	DNSPort               uint32              `json:"dnsPort" yaml:"dnsPort" mapstructure:"dnsPort"`
	ProxyPort             uint32              `json:"proxyPort" yaml:"proxyPort" mapstructure:"proxyPort"`
	IncomingProxyPort     uint16              `json:"incomingProxyPort" yaml:"incomingProxyPort" mapstructure:"incomingProxyPort"`
	Debug                 bool                `json:"debug" yaml:"debug" mapstructure:"debug"`
	DisableTele           bool                `json:"disableTele" yaml:"disableTele" mapstructure:"disableTele"`
	DisableANSI           bool                `json:"disableANSI" yaml:"disableANSI" mapstructure:"disableANSI"`
	JSONOutput            bool                `json:"jsonOutput" yaml:"jsonOutput" mapstructure:"jsonOutput"`
	InDocker              bool                `json:"inDocker" yaml:"-" mapstructure:"inDocker"`
	ContainerName         string              `json:"containerName" yaml:"containerName" mapstructure:"containerName"`
	NetworkName           string              `json:"networkName" yaml:"networkName" mapstructure:"networkName"`
	BuildDelay            uint64              `json:"buildDelay" yaml:"buildDelay" mapstructure:"buildDelay"`
	Test                  Test                `json:"test" yaml:"test" mapstructure:"test"`
	Record                Record              `json:"record" yaml:"record" mapstructure:"record"`
	Report                Report              `json:"report" yaml:"report" mapstructure:"report"`
	Normalize             Normalize           `json:"normalize" yaml:"-" mapstructure:"normalize"`
	DisableMapping        bool                `json:"disableMapping" yaml:"disableMapping" mapstructure:"disableMapping"`
	RetryPassing          bool                `json:"retryPassing" yaml:"retryPassing" mapstructure:"retryPassing"`
	ConfigPath            string              `json:"configPath" yaml:"configPath" mapstructure:"configPath"`
	BypassRules           []models.BypassRule `json:"bypassRules" yaml:"bypassRules" mapstructure:"bypassRules"`
	MysqlPorts            []uint32            `json:"mysqlPorts" yaml:"mysqlPorts" mapstructure:"mysqlPorts"`
	EnableTesting         bool                `json:"enableTesting" yaml:"-" mapstructure:"enableTesting"`
	GenerateGithubActions bool                `json:"generateGithubActions" yaml:"generateGithubActions" mapstructure:"generateGithubActions"`
	KeployContainer       string              `json:"keployContainer" yaml:"keployContainer" mapstructure:"keployContainer"`
	KeployNetwork         string              `json:"keployNetwork" yaml:"keployNetwork" mapstructure:"keployNetwork"`
	CommandType           string              `json:"cmdType" yaml:"cmdType" mapstructure:"cmdType"`
	Contract              Contract            `json:"contract" yaml:"contract" mapstructure:"contract"`
	Agent                 Agent               `json:"agent" yaml:"agent" mapstructure:"agent"`
	InCi                  bool                `json:"inCi" yaml:"inCi" mapstructure:"inCi"`
	InstallationID        string              `json:"-" yaml:"-" mapstructure:"-"`
	ServerPort            uint32              `json:"serverPort" yaml:"serverPort" mapstructure:"serverPort"`
	Version               string              `json:"-" yaml:"-" mapstructure:"-"`
	APIServerURL          string              `json:"-" yaml:"-" mapstructure:"-"`
	GitHubClientID        string              `json:"-" yaml:"-" mapstructure:"-"`
	// InMemoryCompose holds docker-compose YAML content in memory to avoid writing
	// sensitive environment variables (secrets, tokens) to disk. When set, the
	// compose command uses "-f -" and pipes this content via stdin.
	InMemoryCompose []byte `json:"-" yaml:"-" mapstructure:"-"`
}

type Agent struct {
	models.SetupOptions
}

type Templatize struct {
	TestSets []string `json:"testSets" yaml:"testSets" mapstructure:"testSets"`
}

type Record struct {
	Filters     []models.Filter `json:"filters" yaml:"filters" mapstructure:"filters"`
	BasePath    string          `json:"basePath" yaml:"basePath" mapstructure:"basePath"`
	RecordTimer time.Duration   `json:"recordTimer" yaml:"recordTimer" mapstructure:"recordTimer"`
	Metadata    string          `json:"metadata" yaml:"metadata" mapstructure:"metadata"`
	// TestCaseNaming controls how default test case filenames are generated.
	// "descriptive" (default) derives a slug from the HTTP method+path or gRPC service/method.
	// "sequential" preserves the legacy `test-N.yaml` numbering.
	TestCaseNaming string `json:"testCaseNaming" yaml:"testCaseNaming" mapstructure:"testCaseNaming"`
	Synchronous    bool   `json:"sync" yaml:"sync" mapstructure:"sync"`
	EnableSampling int    `json:"enableSampling" yaml:"enableSampling"`
	// ChannelBindingShim enables the SCRAM-SHA-256-PLUS channel-binding shim.
	// The shim attaches eBPF uprobes to libcrypto's X509_digest and rewrites the
	// cert-hash libpq folds into the SCRAM proof, so postgres clients running
	// with channel_binding=require still authenticate through keploy's TLS MITM
	// against the REAL upstream postgres at record time. Replay does not forward
	// to the real database — postgres traffic is served from mocks, no SCRAM
	// handshake actually completes against postgres — so the shim is record-only.
	// OSS builds have no implementation registered and ignore this flag entirely;
	// builds with a registered factory respect it. Defaults to false; flip to
	// true in keploy.yml under record: to opt in. Requires CAP_BPF + a kernel
	// that allows bpf_probe_write_user; without those the factory returns an
	// error and the proxy keeps working for non-PLUS clients.
	ChannelBindingShim bool   `json:"channelBindingShim" yaml:"channelBindingShim" mapstructure:"channelBindingShim"`
	MemoryLimit        uint64 `json:"memoryLimit" yaml:"memoryLimit" mapstructure:"memoryLimit"`
	GlobalPassthrough  bool   `json:"globalPassthrough" yaml:"globalPassthrough" mapstructure:"globalPassthrough"`
	TLSPrivateKeyPath  string `json:"tlsPrivateKeyPath" yaml:"tlsPrivateKeyPath" mapstructure:"tlsPrivateKeyPath"`
	// MockFormat selects the on-disk format for recorded mocks.
	// "" or "yaml" (default) writes mocks.yaml — human-readable, the
	// format all tooling expects. "gob" writes a binary mocks.gob — a
	// ~28% CPU reduction on the record client at high throughput, at
	// the cost of not being grep/diff-friendly and having no cross-
	// Go-version stability contract. The env var KEPLOY_MOCK_FORMAT
	// takes precedence over this field for ad-hoc experimentation.
	MockFormat string `json:"mockFormat,omitempty" yaml:"mockFormat,omitempty" mapstructure:"mockFormat"`
	// CapturePackets toggles raw network packet capture on the proxy ports
	// during recording. When enabled, a pcap file is written into the
	// freshly-created test-set directory under the keploy folder.
	CapturePackets bool `json:"capturePackets" yaml:"capturePackets" mapstructure:"capturePackets"`
	// OpportunisticTLSIntercept enables a "sniff first, hijack if TLS"
	// passthrough mode. The proxy lets the app and upstream talk to
	// each other (relaying bytes verbatim, like GlobalPassthrough)
	// while peeking each chunk for the start of a TLS handshake.
	// As soon as a chunk on the client side starts with a TLS
	// ClientHello, the proxy hijacks: it terminates TLS with the
	// client (presenting keploy's MITM cert, with KeyLogWriter
	// wired so the keylog file populates), opens a fresh tls.Client
	// to the upstream, and then relays cleartext both ways without
	// parser dispatch or mock recording. This gives a decryptable
	// pcap for sessions that would otherwise have been pure
	// passthrough — handy for debugging captured TLS traffic.
	//
	// Independent of GlobalPassthrough — the two flags are
	// alternatives, not a hierarchy. When OpportunisticTLSIntercept
	// is set it takes precedence; the proxy ignores
	// GlobalPassthrough for that connection's outcome.
	//
	// Caveats: cert pinning breaks the same way it does for default
	// record mode (the app must trust keploy's CA); SCRAM-*-PLUS
	// and other channel-binding mechanisms reject the MITM cert and
	// must be disabled client-side; MITM-incompatible workloads
	// should stick with GlobalPassthrough.
	OpportunisticTLSIntercept bool `json:"opportunisticTlsIntercept" yaml:"opportunisticTlsIntercept" mapstructure:"opportunisticTlsIntercept"`

	// RecordBuffer tunes the per-connection record buffer. Defaults
	// suit ~99% of workloads; only touch these if you see "mock
	// incomplete" warnings with reason "per_conn_cap" or "channel_full"
	// in the agent logs.
	RecordBuffer RecordBuffer `json:"recordBuffer" yaml:"recordBuffer" mapstructure:"recordBuffer"`
}

// RecordBuffer tunes the per-connection recording queue used by the
// agent's relay. The two knobs guard the same in-flight queue but in
// different units: MaxMemoryPerConnection is a byte budget,
// QueueSize is a slot count. Whichever fills first triggers a drop
// and marks the in-flight mock incomplete (the forward path is
// unaffected — user traffic always succeeds).
//
// Env vars KEPLOY_RECORD_MAX_MEMORY_PER_CONN and KEPLOY_RECORD_QUEUE_SIZE
// override the yaml/flag values when set.
type RecordBuffer struct {
	// MaxMemoryPerConnection caps the bytes the recorder may hold
	// in the per-connection queue while the parser catches up.
	// Maps to relay.Config.PerConnCap. Zero resolves to the relay's
	// built-in default (64 MiB). Increase if you see drops with
	// reason "per_conn_cap" — usually means responses are larger
	// than the default budget (e.g. >10 MB query results).
	MaxMemoryPerConnection uint64 `json:"maxMemoryPerConnection" yaml:"maxMemoryPerConnection" mapstructure:"maxMemoryPerConnection"`

	// QueueSize is the number of chunk slots in the recording queue.
	// Each slot holds one ~32 KiB chunk. Maps to
	// relay.Config.TeeChanBuf. Zero resolves to the relay's built-in
	// default (1024). Increase if you see drops with reason
	// "channel_full" — usually means bursty traffic (many small
	// messages back-to-back) that the parser can't keep up with.
	QueueSize int `json:"queueSize" yaml:"queueSize" mapstructure:"queueSize"`
}

type Contract struct {
	Services []string `json:"services" yaml:"services" mapstructure:"services"`
	Tests    []string `json:"tests" yaml:"tests" mapstructure:"tests"`
	Path     string   `json:"path" yaml:"path" mapstructure:"path"`
	Download bool     `json:"download" yaml:"download" mapstructure:"download"`
	Generate bool     `json:"generate" yaml:"generate" mapstructure:"generate"`
	Driven   string   `json:"driven" yaml:"driven" mapstructure:"driven"`
	Mappings Mappings `json:"mappings" yaml:"mappings" mapstructure:"mappings"`
}

type Mappings struct {
	ServicesMapping map[string][]string `json:"servicesMapping" yaml:"servicesMapping" mapstructure:"servicesMapping"`
	Self            string              `json:"self" yaml:"self" mapstructure:"self"`
}

type Normalize struct {
	SelectedTests []SelectedTests `json:"selectedTests" yaml:"selectedTests" mapstructure:"selectedTests"`
	TestRun       string          `json:"testReport" yaml:"testReport" mapstructure:"testReport"`
	AllowHighRisk bool            `json:"allowHighRisk" yaml:"allowHighRisk" mapstructure:"allowHighRisk"`
	EditedBy      string          `json:"-" yaml:"-" mapstructure:"-"`
}

type Test struct {
	SelectedTests               map[string][]string `json:"selectedTests" yaml:"selectedTests" mapstructure:"selectedTests"`
	GlobalNoise                 Globalnoise         `json:"globalNoise" yaml:"globalNoise" mapstructure:"globalNoise"`
	ReplaceWith                 ReplaceWith         `json:"replaceWith" yaml:"replaceWith" mapstructure:"replaceWith"`
	Delay                       uint64              `json:"delay" yaml:"delay" mapstructure:"delay"`
	HealthURL                   string              `json:"healthUrl" yaml:"healthUrl" mapstructure:"healthUrl"`                         // optional HTTP(S) URL polled before firing the first test; empty preserves the fixed --delay behavior
	HealthPollTimeout           time.Duration       `json:"healthPollTimeout" yaml:"healthPollTimeout" mapstructure:"healthPollTimeout"` // ceiling for the pre-test health poll loop before falling back to --delay
	Host                        string              `json:"host" yaml:"host" mapstructure:"host"`
	Port                        uint32              `json:"port" yaml:"port" mapstructure:"port"`
	GRPCPort                    uint32              `json:"grpcPort" yaml:"grpcPort" mapstructure:"grpcPort"`
	SSEPort                     uint32              `json:"ssePort" yaml:"ssePort" mapstructure:"ssePort"`
	Protocol                    ProtocolConfig      `json:"protocol" yaml:"protocol" mapstructure:"protocol"`
	APITimeout                  uint64              `json:"apiTimeout" yaml:"apiTimeout" mapstructure:"apiTimeout"`
	SkipCoverage                bool                `json:"skipCoverage" yaml:"skipCoverage" mapstructure:"skipCoverage"`                   // boolean to capture the coverage in test
	CoverageReportPath          string              `json:"coverageReportPath" yaml:"coverageReportPath" mapstructure:"coverageReportPath"` // directory path to store the coverage files
	IgnoreOrdering              bool                `json:"ignoreOrdering" yaml:"ignoreOrdering" mapstructure:"ignoreOrdering"`
	MongoPassword               string              `json:"mongoPassword" yaml:"mongoPassword" mapstructure:"mongoPassword"`
	Language                    models.Language     `json:"language" yaml:"language" mapstructure:"language"`
	RemoveUnusedMocks           bool                `json:"removeUnusedMocks" yaml:"removeUnusedMocks" mapstructure:"removeUnusedMocks"`
	PreserveFailedMocks         bool                `json:"preserveFailedMocks" yaml:"preserveFailedMocks" mapstructure:"preserveFailedMocks"` // skip mock pruning when tests fail (set by k8s-proxy autoreplay)
	FallBackOnMiss              bool                `json:"fallBackOnMiss" yaml:"fallBackOnMiss" mapstructure:"fallBackOnMiss"`                // Deprecated: this flag is ignored. Replay is now always deterministic.
	JacocoAgentPath             string              `json:"jacocoAgentPath" yaml:"jacocoAgentPath" mapstructure:"jacocoAgentPath"`
	BasePath                    string              `json:"basePath" yaml:"basePath" mapstructure:"basePath"`
	Mocking                     bool                `json:"mocking" yaml:"mocking" mapstructure:"mocking"`
	IgnoredTests                map[string][]string `json:"ignoredTests" yaml:"ignoredTests" mapstructure:"ignoredTests"`
	DisableLineCoverage         bool                `json:"disableLineCoverage" yaml:"disableLineCoverage" mapstructure:"disableLineCoverage"`
	UpdateTemplate              bool                `json:"updateTemplate" yaml:"updateTemplate" mapstructure:"updateTemplate"`
	MustPass                    bool                `json:"mustPass" yaml:"mustPass" mapstructure:"mustPass"`
	MaxFailAttempts             uint32              `json:"maxFailAttempts" yaml:"maxFailAttempts" mapstructure:"maxFailAttempts"`
	MaxFlakyChecks              uint32              `json:"maxFlakyChecks" yaml:"maxFlakyChecks" mapstructure:"maxFlakyChecks"`
	ProtoFile                   string              `json:"protoFile" yaml:"protoFile" mapstructure:"protoFile"`
	ProtoDir                    string              `json:"protoDir" yaml:"protoDir" mapstructure:"protoDir"`
	ProtoInclude                []string            `json:"protoInclude" yaml:"protoInclude" mapstructure:"protoInclude"`
	CompareAll                  bool                `json:"compareAll" yaml:"compareAll" mapstructure:"compareAll"`
	SchemaMatch                 bool                `json:"schemaMatch" yaml:"schemaMatch" mapstructure:"schemaMatch"`
	UpdateTestMapping           bool                `json:"updateTestMapping" yaml:"updateTestMapping" mapstructure:"updateTestMapping"`
	DisableAutoHeaderNoise      bool                `json:"disableAutoHeaderNoise" yaml:"disableAutoHeaderNoise" mapstructure:"disableAutoHeaderNoise"`                                    // skip auto-noise for flaky headers (e.g. AWS SigV4)
	SchemaNoiseDetection        bool                `json:"schemaNoiseDetection" yaml:"schemaNoiseDetection" mapstructure:"schemaNoiseDetection"`                                          // detect request-body fields that drift between recording and replay and persist them as field-path noise (req_body_noise) on HTTP mocks during auto-replay matching
	SchemaNoiseStrict           bool                `json:"schemaNoiseStrict" yaml:"schemaNoiseStrict" mapstructure:"schemaNoiseStrict"`                                                   // replay-path enforcement: for an HTTP mock that already carries learned req_body_noise, match strictly — every request-body field must match except the learned-noise paths, so a non-noise drift fails the match. Left false on the auto-replay path so it can still learn noise leniently.
	StrictFailure               bool                `json:"strictFailure" yaml:"strictFailure" mapstructure:"strictFailure"`                                                               // when true, a response-failing test (testPass=false) is marked FAILED even if the consumed mock set diverged from the recorded mapping. Default false preserves the historical demotion: response failures with mock-set mismatch are marked OBSOLETE so the user can re-record without seeing the response diff as a hard failure. Set true to surface every response divergence as a real test failure for CI gating; the per-test OBSOLETE label is replaced by FAILED but the mappingDiff (expected vs actual mocks, missing calls) is still written to the report for diagnostics.
	StrictMockWindow            bool                `json:"strictMockWindow" yaml:"strictMockWindow" mapstructure:"strictMockWindow"`                                                      // Strict containment: per-test (LifetimePerTest) mocks whose request timestamp falls outside the outer test window are DROPPED rather than promoted to the cross-test unfiltered pool, which eliminates cross-test mock bleed. Default TRUE now that every stateful-protocol recorder classifies mocks finely enough (session vs per-test for connection-alive commands, per-connection data mocks) that legitimate cross-test sharing is encoded as session/connection lifetime rather than implicit out-of-window reuse. Opt out by setting this to false in keploy.yaml, or export KEPLOY_STRICT_MOCK_WINDOW=0 at process start — the env var wins over config.
	KeepAppAlive                bool                `json:"keepAppAlive" yaml:"keepAppAlive" mapstructure:"keepAppAlive"`                                                                  // Start the user app ONCE on the outer errgroup at Start() time instead of restarting it per test-set. Skips the per-test-set RunApplication spawn + NotifyGracefulShutdown (reuses the existing serveTest gating) and skips the --delay wait on every test-set after the first (the app is already warm after the boundary). Matches the production globality autoreplay shape where a single user-app process serves every test-set back-to-back; required for cross-test-set bugs that need a long-lived TCP connection (asyncpg pool, JDBC HikariCP pool, etc.) to surface — see keploy/integrations#203 for the session-tier staleness case. Works for every cmdType that manages a user application (docker-compose, docker-run, docker-start, native); cmdType == Empty (no -c) short-circuits the one-shot spawn since there's nothing to manage. Default FALSE preserves the historical per-test-set restart behaviour.
	ConnectionPoolIdleRetention time.Duration       `json:"connectionPoolIdleRetention,omitempty" yaml:"connectionPoolIdleRetention,omitempty" mapstructure:"connectionPoolIdleRetention"` // How long a per-connID connection-scoped mock pool survives without activity before the idle sweeper reclaims it. Default 5m — enough for HikariCP-style pooled connections bridging test boundaries without activity. Extend for long-running integration tests that may idle a connection between requests for more than 5 minutes; shorter values make the sweeper more aggressive at cost of potentially reclaiming active connections. Zero / negative reverts to the default.
	CmdUsed                     string              `json:"-" yaml:"-" mapstructure:"-"`                                                                                                   // Full command used for the test run (set at runtime)
}

type Report struct {
	SelectedTestSets map[string][]string `json:"selectedTestSets" yaml:"selectedTestSets" mapstructure:"selectedTestSets"`
	ShowFullBody     bool                `json:"showFullBody" yaml:"showFullBody" mapstructure:"showFullBody"`
	ReportPath       string              `json:"reportPath" yaml:"reportPath" mapstructure:"reportPath"`
	Summary          bool                `json:"summary" yaml:"summary" mapstructure:"summary"`
	TestCaseIDs      []string            `json:"testCaseIDs" yaml:"testCaseIDs" mapstructure:"testCaseIDs"`
	Format           string              `json:"format" yaml:"format" mapstructure:"format"`
}

type Globalnoise struct {
	Global   GlobalNoise  `json:"global" yaml:"global" mapstructure:"global"`
	Testsets TestsetNoise `json:"test-sets" yaml:"test-sets" mapstructure:"test-sets"`
}

type ReplaceWith struct {
	Global   ReplaceWithMap            `json:"global" yaml:"global" mapstructure:"global"`
	TestSets map[string]ReplaceWithMap `json:"test-sets" yaml:"test-sets" mapstructure:"test-sets"`
}

type ReplaceWithMap struct {
	URL  map[string]string `json:"url" yaml:"url" mapstructure:"url"`
	Port map[uint32]uint32 `json:"port" yaml:"port" mapstructure:"port"`
}

// ProtocolSettings holds per-protocol configuration. Add new fields here
// to extend all protocols without changing the map structure.
type ProtocolSettings struct {
	Port uint32 `json:"port" yaml:"port" mapstructure:"port"`
}

// ProtocolConfig maps protocol names (e.g. "http", "sse", "grpc") to their
// settings. The map schema allows additional protocol names in the config
// without schema changes, but only protocols recognized by the application
// are currently used by the replay and protocol-handling logic.
type ProtocolConfig map[string]ProtocolSettings

type SelectedTests struct {
	TestSet string   `json:"testSet" yaml:"testSet" mapstructure:"testSet"`
	Tests   []string `json:"tests" yaml:"tests" mapstructure:"tests"`
}

type (
	Noise        map[string][]string
	GlobalNoise  map[string]map[string][]string
	TestsetNoise map[string]map[string]map[string][]string
)

func SetByPassPorts(conf *Config, ports []uint) {
	for _, port := range ports {
		conf.BypassRules = append(conf.BypassRules, models.BypassRule{
			Path: "",
			Host: "",
			Port: port,
		})
	}
}

func GetByPassPorts(conf *Config) []uint {
	var ports []uint
	for _, rule := range conf.BypassRules {
		ports = append(ports, rule.Port)
	}
	return ports
}

func SetSelectedTests(conf *Config, testSets []string) {
	conf.Test.SelectedTests = make(map[string][]string)
	for _, testSet := range testSets {
		conf.Test.SelectedTests[testSet] = []string{}
	}
}

func SetSelectedServices(conf *Config, services []string) {
	// string is "s1,s2" so i want to get s1,s2
	conf.Contract.Services = services
}

func SetSelectedContractTests(conf *Config, tests []string) {
	conf.Contract.Tests = tests
}

func SetSelectedTestSets(conf *Config, testSets []string) {
	conf.Report.SelectedTestSets = make(map[string][]string)
	for _, testSet := range testSets {
		conf.Report.SelectedTestSets[testSet] = []string{}
	}
}

func SetSelectedTestsNormalize(conf *Config, value string) error {
	value = strings.TrimSpace(value)

	// No tests provided -> clear selection and return
	if value == "" {
		conf.Normalize.SelectedTests = nil
		return nil
	}

	// Split only on commas: each token represents one test-set specification.
	// Examples:
	//   "ts1, ts2:tc1 tc2" =>
	//      "ts1"
	//      "ts2:tc1 tc2"
	parts := strings.Split(value, ",")

	var selected []SelectedTests

	for _, part := range parts {
		spec := strings.TrimSpace(part)
		if spec == "" {
			continue
		}

		// Check if this spec has an explicit list of test cases, e.g. "ts2:tc1 tc2"
		idx := strings.Index(spec, ":")

		if idx != -1 {
			testSetName := strings.TrimSpace(spec[:idx])
			if testSetName == "" {
				return fmt.Errorf("invalid format (missing test set name): %q", spec)
			}

			testsPart := strings.TrimSpace(spec[idx+1:])
			var testCases []string
			if testsPart != "" {
				for _, tc := range strings.Fields(testsPart) {
					tc = strings.TrimSpace(tc)
					if tc != "" {
						testCases = append(testCases, tc)
					}
				}
			}

			selected = append(selected, SelectedTests{
				TestSet: testSetName,
				// Empty testCases slice means "all tests" in that test set.
				Tests: testCases,
			})
			continue
		}

		// No colon -> entire token is just the test-set name, implies "all tests in this set"
		selected = append(selected, SelectedTests{
			TestSet: spec,
			Tests:   []string{}, // empty slice => all tests in this test set
		})
	}

	conf.Normalize.SelectedTests = selected
	return nil
}
