// Package csharp impliments methods for Csharp coverage services.
package csharp

import (
	"context"
	"encoding/xml"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"go.keploy.io/server/v3/pkg/models"
	"go.keploy.io/server/v3/pkg/platform/coverage"
	"go.keploy.io/server/v3/utils"
	"go.uber.org/zap"
)

type Csharp struct {
	ctx                context.Context
	logger             *zap.Logger
	reportdb           coverage.ReportDB
	cmd                string
	executable         string
	dotnetCoveragePath string
}

type CoverageStructure struct {
	LineRate float64 `xml:"line-rate,attr"`

	Packages []struct {
		Classes []struct {
			FileName        string  `xml:"filename,attr"`
			ClassLineRate   float64 `xml:"line-rate,attr"`
			ClassBranchRate float64 `xml:"branch-rate,attr"`
		} `xml:"classes>class"`
	} `xml:"packages>package"`
}

func New(ctx context.Context, logger *zap.Logger, reportDB coverage.ReportDB, cmd, dotnetCoveragePath, executable string) *Csharp {
	return &Csharp{
		ctx:                ctx,
		logger:             logger,
		reportdb:           reportDB,
		cmd:                cmd,
		dotnetCoveragePath: dotnetCoveragePath,
		executable:         executable,
	}
}

func (cs *Csharp) PreProcess(_ bool) (string, error) {
	// default location for dotnet-coverage
	dotnetCoveragePath := "~/.dotnet/tools/dotnet-coverage"
	if cs.dotnetCoveragePath != "" {
		dotnetCoveragePath = cs.dotnetCoveragePath
	}

	isFileExists, err := utils.FileExists(dotnetCoveragePath)
	if err != nil {
		cs.logger.Debug("error checking dotnet-coverage tool existence: %s", zap.Error(err))
		return cs.cmd, err
	}

	if !isFileExists {
		return cs.cmd, fmt.Errorf("dotnet coverage tool not found at: %s", dotnetCoveragePath)
	}

	cs.cmd = strings.Replace(cs.cmd, cs.executable, fmt.Sprintf("%s collect --output target/${TESTSETID}.cobertura --output-format cobertura", cs.executable), 1)

	// download dotnet coverage
	dotnetPath := filepath.Join(os.TempDir(), "dotnet")
	err = os.MkdirAll(dotnetPath, 0777)

	if err != nil {
		cs.logger.Debug("failed to create dotnet directory: %s", zap.Error(err))
		return cs.cmd, err
	}

	err = downloadDotnetCoverage(cs.ctx)
	if err != nil {
		cs.logger.Debug("failed to download and extract dotnet binaries: %s", zap.Error(err))
		return cs.cmd, err
	}

	return cs.cmd, nil
}

func (cs *Csharp) GetCoverage() (models.TestCoverage, error) {
	testCov := models.TestCoverage{
		FileCov:  make(map[string]string),
		TotalCov: "",
	}

	// Define the path to cobertura file
	coberturaPath := filepath.Join("target", "site", "KeployE2E", "e2e.cobertura")

	file, err := os.Open(coberturaPath)
	if err != nil {
		return testCov, fmt.Errorf("failed to open cobertura file: %w", err)
	}
	defer func() {
		if err := file.Close(); err != nil {
			utils.LogError(cs.logger, err, "Error closing coverage cobertura file")
		}
	}()

	// complete line-by-line coverage
	coverageStruct := CoverageStructure{}
	if err := xml.Unmarshal([]byte(coberturaPath), &coverageStruct); err != nil {
		return testCov, fmt.Errorf("failed to unmarshal cobertura file: %w", err)
	}
	testCov.TotalCov = strconv.FormatFloat(coverageStruct.LineRate*100, 'E', -1, 64)

	// class coverage
	totalClasses, classCovered := 0.0, 0.0

	for _, pkg := range coverageStruct.Packages {
		for _, class := range pkg.Classes {
			totalClasses++
			if class.ClassLineRate > 0 || class.ClassBranchRate > 0 {
				classCovered++
			}

			classCoverage := (classCovered / totalClasses) * 100
			testCov.FileCov[class.FileName] = strconv.FormatFloat(classCoverage, 'E', -1, 64) + "%"
		}
	}

	return testCov, nil
}
