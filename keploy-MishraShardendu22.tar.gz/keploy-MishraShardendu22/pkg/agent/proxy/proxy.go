// Package proxy handles all the outgoing network calls and captures/forwards the request and response messages.
// It also handles the DNS resolution mechanism.
package proxy

import (
	"bufio"
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"math"
	"net"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	expirable "github.com/hashicorp/golang-lru/v2/expirable"
	"github.com/miekg/dns"
	"go.keploy.io/server/v3/config"
	"go.keploy.io/server/v3/pkg/agent"
	"golang.org/x/sync/errgroup"

	"go.keploy.io/server/v3/pkg/agent/proxy/cbshim"
	"go.keploy.io/server/v3/pkg/agent/proxy/integrations"
	syncMock "go.keploy.io/server/v3/pkg/agent/proxy/syncMock"
	pTls "go.keploy.io/server/v3/pkg/agent/proxy/tls"
	"go.keploy.io/server/v3/pkg/agent/proxy/util"
	"go.keploy.io/server/v3/pkg/models"
	"go.keploy.io/server/v3/utils"
	"go.uber.org/zap"
)

type ParserPriority struct {
	Priority   int
	ParserType integrations.IntegrationType
}

// probeFanoutEnabled toggles [PROBE/proxy] / [PROBE/dial] structured
// logs via KEPLOY_PROBE_FANOUT=1. The flag is read once at first use
// and cached in an atomic so hot-path branches are a single load.
// Used to diagnose the parallel-TLS-fanout stall (SAP + Postgres
// concurrent handshakes) without polluting normal record runs.
var (
	probeFanoutOnce    sync.Once
	probeFanoutEnabled atomic.Bool
)

func probeOn() bool {
	probeFanoutOnce.Do(func() {
		if os.Getenv("KEPLOY_PROBE_FANOUT") == "1" {
			probeFanoutEnabled.Store(true)
		}
	})
	return probeFanoutEnabled.Load()
}

// probeProxy emits a [PROBE/proxy] log tagged with a stable conn id
// and phase name. Cheap to call when the probe is off (single atomic
// load + early return); zero allocations on the hot disabled path.
func probeProxy(logger *zap.Logger, phase string, connID int64, fields ...zap.Field) {
	if !probeOn() {
		return
	}
	base := []zap.Field{
		zap.String("probe", "proxy"),
		zap.String("phase", phase),
		zap.Int64("connID", connID),
		zap.Int64("ts_ns", time.Now().UnixNano()),
	}
	logger.Info("[PROBE/proxy]", append(base, fields...)...)
}

var defaultMysqlPorts = []uint32{3306, 4000}

func isMysqlPort(port uint32, configured []uint32) bool {
	ports := configured
	if len(ports) == 0 {
		ports = defaultMysqlPorts
	}
	for _, p := range ports {
		if p == port {
			return true
		}
	}
	return false
}

// probeDial emits a [PROBE/dial] log for upstream dial timing.
func probeDial(logger *zap.Logger, phase string, connID int64, addr string, durNs int64, fields ...zap.Field) {
	if !probeOn() {
		return
	}
	base := []zap.Field{
		zap.String("probe", "dial"),
		zap.String("phase", phase),
		zap.Int64("connID", connID),
		zap.String("addr", addr),
		zap.Int64("dur_ns", durNs),
		zap.Int64("ts_ns", time.Now().UnixNano()),
	}
	logger.Info("[PROBE/dial]", append(base, fields...)...)
}

type Proxy struct {
	logger *zap.Logger

	IP4               string
	IP6               string
	Port              uint32
	IncomingProxyPort uint16
	DNSPort           uint32

	DestInfo     agent.DestInfo
	Integrations map[integrations.IntegrationType]integrations.Integrations

	integrationsPriority []ParserPriority
	errChannel           chan error

	// activeTestErrors accumulates mock-not-found errors during active test execution.
	// The continuous error drain goroutine routes errors here when non-nil,
	// and discards errors when nil (no test running). This prevents the
	// errChannel from filling up with background noise (OTel, health checks).
	activeTestErrors atomic.Pointer[testErrorAccumulator]
	errDrainOnce     sync.Once
	// session holds the single active session for this proxy.
	// Previously this was a sync.Map keyed by appID (always 0), which is
	// no longer needed since the proxy serves a single client-app.
	sessionMu   sync.RWMutex
	session     *agent.Session
	mockManager *MockManager

	synchronous bool

	connMutex *sync.Mutex
	ipMutex   *sync.Mutex
	// channel to mark client connection as closed
	clientClose chan bool

	// activeConns tracks outgoing handleConnection goroutines so
	// shutdown can wait for them to finish naturally (drain grace)
	// before tearing listeners down. Count-only — connections close
	// themselves via their own defers / context cancellation; we do
	// not need references to force-close them.
	activeConns sync.WaitGroup

	Listener net.Listener

	//to store the nsswitch.conf file data
	nsSwitchMutex             sync.Mutex
	nsswitchData              []byte // in test mode we change the configuration of "hosts" in nsswitch.conf file to disable resolution over unix socket
	UDPDNSServer              *dns.Server
	TCPDNSServer              *dns.Server
	GlobalPassthrough         bool
	OpportunisticTLSIntercept bool
	IsDocker                  bool

	// EnableIPv6Redirect mirrors config.Agent.EnableIPv6Redirect. When
	// true (the default), the synthetic DNS fallback answers AAAA
	// queries with ::1 so clients can reach the proxy via the IPv6
	// loopback that the BPF cgroup program redirects. When false, AAAA
	// is returned empty to preserve the legacy v4-only behaviour.
	EnableIPv6Redirect bool

	// appPID and caJavaHome are captured at proxy-construction time from
	// config.Agent (ClientNSPID + CAJavaHome) and passed to
	// pTls.SetupCAForApp so the Java keystore import targets the JDK the
	// instrumented application is actually running with — not the
	// arbitrary JDK first on PATH. On non-Java, Windows, or shared-volume
	// paths these are ignored. See pkg/agent/proxy/tls/java_detect.go for
	// the resolution order and rationale.
	appPID     uint32
	caJavaHome string

	// dnsCache is a TTL-expiring, size-bounded LRU cache for DNS responses.
	dnsCache *expirable.LRU[string, dnsCacheEntry]

	// recordedDNSMocks tracks DNS queries that have already been recorded
	// to avoid recording duplicate mocks. Key format: "name:qtype:qclass"
	// Uses bounded LRU with TTL to prevent unbounded memory growth.
	recordedDNSMocks *expirable.LRU[string, bool]

	// dnsUpstreamServers is the list of upstream DNS resolver IPs
	// captured from /etc/resolv.conf ONCE at proxy startup, BEFORE the
	// DNS server begins listening on p.DNSPort. This snapshot preserves
	// the original (pre-keploy) cluster resolver addresses (typically
	// CoreDNS in a Kubernetes pod) so that on a mock miss the
	// userspace DNS handler can forward queries upstream and return a
	// real answer for cluster-internal names (e.g.
	// `mysql.svc.cluster.local`) instead of the proxy's 127.0.0.1
	// fallback — which would cause the app to attempt DB connections
	// against the wrong IP.
	//
	// Captured via dns.ClientConfigFromFile. Empty when the file is
	// missing or unparseable; the forwarder falls back to the legacy
	// synthetic response in that case.
	dnsUpstreamServers []string
	// dnsUpstreamPort is the port read alongside dnsUpstreamServers.
	// Defaults to "53" when resolv.conf does not specify one.
	dnsUpstreamPort string
	// dnsForwardTimeout caps how long a single upstream Exchange is
	// allowed to block. Short by design — a flaky resolver must never
	// stall the app's DNS lookup. On timeout we fall through to the
	// legacy default/NXDOMAIN behaviour with a clear log line.
	dnsForwardTimeout time.Duration

	// isGracefulShutdown indicates the application is shutting down gracefully
	// When set, connection errors should be logged as debug instead of error
	isGracefulShutdown atomic.Bool

	auxiliaryHook agent.AuxiliaryProxyHook

	// skipListener disables the TCP accept loop. When true, the proxy
	// does not bind a port. DNS, parser init, and session state still run.
	skipListener bool

	// pcapMu guards the pcap-lifecycle fields below. The lifecycle is:
	// startPacketCapture spins up the afpacket goroutines and
	// installs a fresh broadcaster; stopPacketCapture cancels, waits
	// on done, and clears the broadcaster. Subscribers join via
	// SubscribePcap and receive every captured frame fanned out from
	// the capture loop — there is NO on-disk pcap file. In the k8s
	// live-recording use case the session never ends, so "fetch on
	// stop" is the wrong model; the recorder holds a long-lived
	// HTTP stream from the moment Record() is called.
	pcapMu          sync.Mutex
	pcapCancel      context.CancelFunc
	pcapDone        chan struct{}
	pcapBroadcaster *pcapBroadcaster

	// recordBufferCap and recordBufferQueueSize mirror
	// config.Record.RecordBuffer at proxy-construction time. Snapshotted
	// here (instead of plumbing the full *config.Config through every
	// per-connection helper) because these are read once per relay
	// construction in recordViaSupervisor and never mutated after the
	// proxy is built. Zero values fall through to the relay package's
	// own defaults via withDefaults().
	recordBufferCap       int64
	recordBufferQueueSize int

	// cbshim is the eBPF-backed channel-binding shim. When non-nil,
	// upstream-TLS-handshake captures publish (mitm_hash, real_hash)
	// pairs into its BPF map so SCRAM-SHA-256-PLUS auth succeeds across
	// keploy's TLS MITM. Nil on OSS builds (no cbshim implementation
	// registered), or when the enterprise impl failed to construct
	// (missing CAP_BPF / older kernel / feature flag off); the proxy
	// keeps working for non-PLUS clients in that case.
	cbshim cbshim.CBShim
}

// SetCBShim wires the eBPF channel-binding shim handle into the proxy.
// Typically called by the agent that owns the cbshim lifecycle, once
// per proxy instance, before StartProxy. Pass nil to disable.
//
// Also installs the tls.MITMPublishHook so CertForClient publishes the
// MITM half of every connection's cbshim rendezvous. Cleared (back to
// nil) when called with a nil cbshim.
func (p *Proxy) SetCBShim(c cbshim.CBShim) {
	p.cbshim = c
	if c == nil {
		pTls.SetMITMPublishHook(nil)
		return
	}
	pTls.SetMITMPublishHook(func(connID string, mitmDER []byte) {
		c.RegisterMITM(connID, mitmDER)
	})
}

// SetSkipListener disables the TCP accept loop.
func (p *Proxy) SetSkipListener(skip bool) {
	p.skipListener = skip
}

// Safe ranges for the user-tunable record buffer. Below the min the
// recorder drops on the first chunk for any non-trivial response;
// above the max the per-connection memory footprint becomes a footgun
// (with thousands of concurrent recorded connections, total RAM
// = max_conns × cap). Zero means "fall through to relay defaults"
// and is NOT clamped — that's the signal-to-defer path.
const (
	minRecordBufferCap   int64 = 1 << 20 // 1 MiB
	maxRecordBufferCap   int64 = 2 << 30 // 2 GiB
	minRecordBufferQueue       = 64
	maxRecordBufferQueue       = 1 << 16 // 65536
)

// clampRecordBuffer validates user-supplied record-buffer values
// and clamps them to safe ranges, logging adjustments at Debug.
// Returns values suitable for relay.Config.PerConnCap and TeeChanBuf.
//
// Zero inputs pass through as zero (relay.withDefaults applies
// built-in defaults). Out-of-range values are clamped + logged at
// Debug, NOT rejected — record-path failure must never crash the
// agent. Debug-level here matches the rest of the record-buffer
// pipeline observability (see tee.drop, MarkMockIncomplete) so
// --debug surfaces the whole story end-to-end on a single switch
// without polluting normal-run logs with config-time noise.
func clampRecordBuffer(logger *zap.Logger, capBytes uint64, queue int) (int64, int) {
	var outCap int64
	switch {
	case capBytes == 0:
		outCap = 0
	case capBytes > math.MaxInt64 || int64(capBytes) > maxRecordBufferCap:
		// uint64 overflow into int64-negative is also caught here.
		logger.Debug("record-buffer maxMemoryPerConnection above safe maximum; clamping",
			zap.Uint64("requested", capBytes),
			zap.Int64("clamped", maxRecordBufferCap),
			zap.Int64("max", maxRecordBufferCap),
		)
		outCap = maxRecordBufferCap
	case int64(capBytes) < minRecordBufferCap:
		logger.Debug("record-buffer maxMemoryPerConnection below safe minimum; clamping",
			zap.Uint64("requested", capBytes),
			zap.Int64("clamped", minRecordBufferCap),
			zap.Int64("min", minRecordBufferCap),
		)
		outCap = minRecordBufferCap
	default:
		outCap = int64(capBytes)
	}

	var outQueue int
	switch {
	case queue == 0:
		outQueue = 0
	case queue > maxRecordBufferQueue:
		logger.Debug("record-buffer queueSize above safe maximum; clamping",
			zap.Int("requested", queue),
			zap.Int("clamped", maxRecordBufferQueue),
			zap.Int("max", maxRecordBufferQueue),
		)
		outQueue = maxRecordBufferQueue
	case queue < minRecordBufferQueue:
		logger.Debug("record-buffer queueSize below safe minimum; clamping",
			zap.Int("requested", queue),
			zap.Int("clamped", minRecordBufferQueue),
			zap.Int("min", minRecordBufferQueue),
		)
		outQueue = minRecordBufferQueue
	default:
		outQueue = queue
	}

	return outCap, outQueue
}

// isNetworkClosedErr checks if the error is due to a closed network connection.
// This includes broken pipe, connection reset by peer, and use of closed network connection errors.
// These errors are expected during graceful shutdown and should not be logged as errors.
func isNetworkClosedErr(err error) bool {
	if err == nil {
		return false
	}
	errStr := err.Error()
	return strings.Contains(errStr, "broken pipe") ||
		strings.Contains(errStr, "connection reset by peer") ||
		strings.Contains(errStr, "use of closed network connection") ||
		// Windows-specific error patterns
		strings.Contains(errStr, "wsarecv") ||
		strings.Contains(errStr, "wsasend") ||
		strings.Contains(errStr, "forcibly closed by the remote host")
}

// isPostgresSSLRequest reports whether the first 8 bytes of a connection
// are a Postgres SSLRequest packet:
//
//	int32 length = 8
//	int32 code   = 80877103 (0x04D2162F)
//
// This is sent by libpq / pgx / pq when `sslmode` is prefer/require/
// verify-ca/verify-full, BEFORE the TLS handshake begins. The server is
// expected to reply with a single byte: 'S' (accept TLS) or 'N' (refuse).
func isPostgresSSLRequest(b []byte) bool {
	if len(b) < 8 {
		return false
	}
	return b[0] == 0x00 && b[1] == 0x00 && b[2] == 0x00 && b[3] == 0x08 &&
		b[4] == 0x04 && b[5] == 0xd2 && b[6] == 0x16 && b[7] == 0x2f
}

// isPostgresSSLRequestPrefix reports whether the first 5 bytes of a
// connection match the Postgres SSLRequest packet's prefix (length=8
// + first byte of the 80877103 code). This is the widest prefix we
// can detect after a 5-byte Peek — used to decide whether it's worth
// blocking on a second Peek(8) to verify the full signature. The
// prefix 00 00 00 08 04 does not collide with TLS (0x16 ...), any
// printable-ASCII protocol greeting, or any PG protocol message
// other than SSLRequest, so this check is effectively exact.
func isPostgresSSLRequestPrefix(b []byte) bool {
	if len(b) < 5 {
		return false
	}
	return b[0] == 0x00 && b[1] == 0x00 && b[2] == 0x00 && b[3] == 0x08 && b[4] == 0x04
}

// dialPostgresSSLUpstream opens a Postgres-aware TLS connection to
// addr: plain-TCP dial, write the 8-byte SSLRequest, read the
// 1-byte 'S'/'N' response, upgrade to TLS via tls.Client only on 'S'.
// A real Postgres server on 5432 expects this sequence; tls.Dial
// would send a ClientHello directly and the server would reject it.
//
// Used by the proxy when agent.InterceptPostgresSSLRequest is set
// and the destination port is 5432. The dial deadline is borrowed
// from the passed-in context so a hung upstream does not block the
// parser goroutine indefinitely; a 10 s default kicks in when the
// context has no deadline (typical for record/replay mode).
//
// connID is the app-side source-port string; if cb is non-nil the
// upstream peer cert is published via cb.RegisterReal so channel-
// binding substitution can rendezvous it with the MITM cert from
// CertForClient. Pass nil to disable cbshim publishing (unit tests).
func dialPostgresSSLUpstream(ctx context.Context, connID, addr string, cfg *tls.Config, logger *zap.Logger, cb cbshim.CBShim) (net.Conn, error) {
	deadline, ok := ctx.Deadline()
	if !ok {
		deadline = time.Now().Add(10 * time.Second)
	}
	dialer := net.Dialer{Deadline: deadline}
	rawConn, err := dialer.DialContext(ctx, "tcp", addr)
	if err != nil {
		return nil, fmt.Errorf("postgres SSL upstream: plain dial %s failed: %w", addr, err)
	}
	if err := rawConn.SetDeadline(deadline); err != nil {
		_ = rawConn.Close()
		return nil, fmt.Errorf("postgres SSL upstream: set deadline: %w", err)
	}
	// SSLRequest: int32 length=8, int32 code=80877103 (0x04D2162F).
	sslRequest := []byte{0x00, 0x00, 0x00, 0x08, 0x04, 0xd2, 0x16, 0x2f}
	if _, err := rawConn.Write(sslRequest); err != nil {
		_ = rawConn.Close()
		return nil, fmt.Errorf("postgres SSL upstream: write SSLRequest to %s failed: %w", addr, err)
	}
	reply := make([]byte, 1)
	if _, err := io.ReadFull(rawConn, reply); err != nil {
		_ = rawConn.Close()
		return nil, fmt.Errorf("postgres SSL upstream: read SSLRequest reply from %s failed: %w", addr, err)
	}
	switch reply[0] {
	case 'S':
		// Server accepted TLS. Upgrade the existing socket and run
		// the handshake. Clear the deadline on the raw conn first —
		// tls.Handshake manages its own.
		if err := rawConn.SetDeadline(time.Time{}); err != nil {
			_ = rawConn.Close()
			return nil, fmt.Errorf("postgres SSL upstream: clear deadline after 'S': %w", err)
		}
		tlsConn := tls.Client(rawConn, cfg)
		handshakeCtx, cancel := context.WithDeadline(ctx, deadline)
		defer cancel()
		if err := tlsConn.HandshakeContext(handshakeCtx); err != nil {
			_ = tlsConn.Close()
			return nil, fmt.Errorf("postgres SSL upstream: TLS handshake after 'S' failed: %w", err)
		}
		logger.Debug("Postgres SSLRequest accepted by upstream; TLS established",
			zap.String("addr", addr),
			zap.String("protocol", tlsConn.ConnectionState().NegotiatedProtocol))

		// Publish the real upstream cert to the cbshim rendezvous.
		// If CertForClient has already registered the MITM half for
		// the same connID this triggers cbmap.Publish into the BPF
		// map; otherwise the MITM half will publish when it arrives.
		if cb != nil && connID != "" {
			state := tlsConn.ConnectionState()
			if len(state.PeerCertificates) > 0 {
				leaf := state.PeerCertificates[0]
				cb.RegisterReal(connID, leaf.Raw, leaf.SignatureAlgorithm)
			}
		}

		return tlsConn, nil
	case 'N':
		_ = rawConn.Close()
		return nil, fmt.Errorf("postgres SSL upstream %s refused TLS (SSLRequest reply 'N'); the client expects TLS but the upstream was built without it — enable SSL on the Postgres server or disable InterceptPostgresSSLRequest for this deployment", addr)
	default:
		_ = rawConn.Close()
		return nil, fmt.Errorf("postgres SSL upstream %s returned unexpected byte 0x%02x as SSLRequest reply (expected 'S' or 'N'); check that the destination is actually a Postgres server and not something else listening on 5432", addr, reply[0])
	}
}

// speculativeUpstreamTLS holds the state of an upstream TLS dial that was
// kicked off concurrently with the MITM client-facing handshake. A completed
// dial (conn or err) is published on done; cancel aborts an in-flight dial
// if the caller decides the speculative config is unusable and wants to
// synchronously redial.
//
// The helper exists so the record-mode hot path can overlap the two
// handshakes (each ~1 RTT) instead of running them serially. Against slow
// remotes the saving is ~one full RTT of client-facing handshake time per
// intercepted TLS connection.
type speculativeUpstreamTLS struct {
	done    chan speculativeUpstreamTLSResult
	cancel  context.CancelFunc
	settled sync.Once // ensures exactly one of join()/abandon() consumes done
	// protos is the NextProtos slice the speculative dial offered upstream.
	// The caller compares it against the final (post-initialBuf) desired
	// ALPN; on mismatch the caller abandons the speculative conn and
	// synchronously redials. Keeping the slice here avoids re-deriving it.
	protos []string
}

type speculativeUpstreamTLSResult struct {
	conn *tls.Conn
	err  error
}

// startSpeculativeUpstreamTLS kicks off a background tls.Dial against addr
// using cfg. The returned *speculativeUpstreamTLS MUST either be joined via
// join() or cancelled via abandon(); otherwise the dial goroutine and its
// socket are leaked.
//
// parentCtx is typically the same ctx used by handleConnection so the dial
// participates in shutdown. The helper derives its own cancellable ctx so
// the caller can tear the dial down independently (e.g. on client-handshake
// failure or an ALPN mismatch).
func startSpeculativeUpstreamTLS(parentCtx context.Context, addr string, cfg *tls.Config) *speculativeUpstreamTLS {
	dialCtx, cancel := context.WithCancel(parentCtx)
	s := &speculativeUpstreamTLS{
		done:   make(chan speculativeUpstreamTLSResult, 1),
		cancel: cancel,
		protos: append([]string(nil), cfg.NextProtos...),
	}
	go func() {
		dialer := &tls.Dialer{Config: cfg}
		c, err := dialer.DialContext(dialCtx, "tcp", addr)
		var tlsConn *tls.Conn
		if err == nil {
			if tc, ok := c.(*tls.Conn); ok {
				tlsConn = tc
			} else {
				// DialContext returns net.Conn; for tls.Dialer the
				// concrete type is always *tls.Conn. Guard anyway
				// in case future stdlib refactors wrap it.
				_ = c.Close()
				err = errors.New("tls.Dialer returned non-*tls.Conn")
			}
		}
		s.done <- speculativeUpstreamTLSResult{conn: tlsConn, err: err}
	}()
	return s
}

// join waits for the speculative dial to finish and returns the result. The
// caller owns the returned conn (or nothing on error) and is responsible
// for closing it. join() must be called at most once and must not be
// interleaved with abandon().
func (s *speculativeUpstreamTLS) join(ctx context.Context) (*tls.Conn, error) {
	var (
		conn    *tls.Conn
		joinErr error
	)
	s.settled.Do(func() {
		select {
		case r := <-s.done:
			s.cancel() // free the derived ctx; no-op if dial already returned
			conn, joinErr = r.conn, r.err
		case <-ctx.Done():
			// Parent ctx expired; make sure the dial goroutine unblocks.
			s.cancel()
			// Drain the pending result so the goroutine can exit cleanly.
			r := <-s.done
			if r.conn != nil {
				_ = r.conn.Close()
			}
			joinErr = ctx.Err()
		}
	})
	return conn, joinErr
}

// abandon cancels the in-flight dial and closes the resulting conn if the
// dial had already succeeded. Safe to call multiple times. After abandon()
// join() becomes a no-op.
//
// The drain happens on a detached goroutine so callers on the hot path
// don't block waiting for an in-flight dial to observe the cancellation.
// We cannot skip the drain entirely: if the dial completed successfully
// just before cancel fired, the goroutine will publish a live *tls.Conn
// to the buffered channel — without a reader that conn leaks.
func (s *speculativeUpstreamTLS) abandon() {
	s.cancel()
	s.settled.Do(func() {
		go func() {
			r := <-s.done
			if r.conn != nil {
				_ = r.conn.Close()
			}
		}()
	})
}

// nextProtosSubset reports whether every element of want is also present in
// offered. It is used to decide whether a speculative dial's NextProtos set
// is still satisfactory once initialBuf has been read and the real
// per-connection ALPN preference is known. When the offered set is a
// superset of want, the server's negotiated protocol — which was picked
// from offered — is necessarily one the caller is also willing to accept.
func nextProtosSubset(want, offered []string) bool {
	if len(want) == 0 {
		return true
	}
	for _, w := range want {
		found := false
		for _, o := range offered {
			if o == w {
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	return true
}

func New(logger *zap.Logger, info agent.DestInfo, opts *config.Config) *Proxy {
	proxy := &Proxy{
		logger:                    logger,
		Port:                      opts.ProxyPort,
		IncomingProxyPort:         opts.IncomingProxyPort,
		DNSPort:                   opts.DNSPort, // default: 26789
		synchronous:               opts.Agent.Synchronous,
		IP4:                       "127.0.0.1", // default: "127.0.0.1" <-> (2130706433)
		IP6:                       "::1",       //default: "::1" <-> ([4]uint32{0000, 0000, 0000, 0001})
		ipMutex:                   &sync.Mutex{},
		connMutex:                 &sync.Mutex{},
		DestInfo:                  info,
		clientClose:               make(chan bool, 1),
		Integrations:              make(map[integrations.IntegrationType]integrations.Integrations),
		GlobalPassthrough:         opts.Agent.GlobalPassthrough,
		OpportunisticTLSIntercept: opts.Agent.OpportunisticTLSIntercept,
		errChannel:                make(chan error, 100), // buffered channel to prevent blocking
		IsDocker:                  opts.Agent.IsDocker,
		EnableIPv6Redirect:        opts.Agent.EnableIPv6Redirect,
		appPID:                    opts.Agent.ClientNSPID,
		caJavaHome:                opts.Agent.CAJavaHome,
		dnsCache:                  newDNSCache(),
		recordedDNSMocks:          newRecordedDNSMocksCache(),
		// dnsForwardTimeout is the per-forward deadline for upstream DNS
		// exchanges. 2 s is long enough to absorb a single UDP retransmit
		// against CoreDNS (~500 ms default) while keeping app-side lookup
		// latency bounded if the upstream is hard-down. Tuned to match the
		// task spec ("~2s"). Tests override by assigning to this field
		// directly on the Proxy struct; see
		// pkg/agent/proxy/dns_forward_test.go (newProxyWithUpstream). The
		// field is package-private, so sibling _test.go files have
		// legitimate direct access and we intentionally do not expose a
		// setter helper for a one-line test-only override.
		dnsForwardTimeout: 2 * time.Second,
		// Record-buffer tuning is set by clampRecordBuffer below — it
		// validates the operator-supplied uint64/int values against
		// safe ranges (1 MiB-2 GiB / 64-65536 slots), warns + clamps
		// rather than crashing, and detects uint64 → int64 wrap from
		// values > math.MaxInt64 explicitly. Setting these here would
		// be redundant and would risk a transient negative cap from a
		// bare uint64 → int64 reinterpretation cast.
	}
	proxy.recordBufferCap, proxy.recordBufferQueueSize = clampRecordBuffer(
		logger,
		opts.Record.RecordBuffer.MaxMemoryPerConnection,
		opts.Record.RecordBuffer.QueueSize,
	)

	// Plumb the proxy logger into the package-singleton SyncMockManager
	// so its drop-path Error emissions actually reach the host logger.
	// zap.L() would silently fall back to Nop here — syncMock loads at
	// package init, long before any zap.ReplaceGlobals call — which is
	// how the overflow warning became invisible on customer runs.
	if mgr := syncMock.Get(); mgr != nil {
		mgr.SetLogger(logger)
	}

	// Channel-binding shim: opt-in BPF-backed feature. Gate by the
	// config flag AND on a registered factory — OSS builds have no
	// factory and skip this branch entirely; enterprise builds
	// register a factory via init() but still respect the flag, which
	// defaults to false. Failure to construct (missing CAP_BPF, older
	// kernel without uprobe support, bpf_probe_write_user disabled by
	// the kernel hardener) is logged at Info and the proxy keeps
	// working for non-SCRAM-PLUS clients. The cbshim is nil-safe at
	// every consumer site, so a nil instance silently disables the
	// channel-binding fix without affecting anything else.
	// proxy.New runs in one of two contexts:
	//   - Docker / docker-compose: a dedicated `keploy agent`
	//     subprocess receives --channel-binding-shim via argv (set
	//     by the orchestrator from docker.go's command builder) and
	//     populates cfg.Agent.ChannelBindingShim.
	//   - Native (--cmd-type native): the orchestrator's own process
	//     runs the proxy; only cfg.Record.ChannelBindingShim is set
	//     by the CLI flag / keploy.yml.
	// Honour either — same pattern other propagation-via-argv flags
	// like CapturePackets use (read from whichever the current
	// process saw populated).
	if opts != nil && (opts.Agent.ChannelBindingShim || opts.Record.ChannelBindingShim) {
		if cb, err := cbshim.NewFromFactory(logger); err == nil && cb != nil {
			proxy.SetCBShim(cb)
			logger.Info("cbshim: BPF-backed channel-binding shim enabled")
		} else if err != nil {
			logger.Info("cbshim: factory returned an error — SCRAM-SHA-256-PLUS "+
				"clients will fail across the MITM as today",
				zap.Error(err),
				zap.String("next_step", "verify the agent has CAP_BPF + CAP_PERFMON (or CAP_SYS_ADMIN on older kernels), the kernel is >= 5.5 with bpf_probe_write_user permitted (not disabled by lockdown / hardened images), and clang/llvm BPF support is available. To opt out of cbshim entirely, set record.channelBindingShim: false (or unset) in keploy.yml; non-PLUS postgres clients work without it."))
		} else {
			logger.Info("cbshim: no implementation registered (OSS build) — "+
				"SCRAM-SHA-256-PLUS clients will fail across the MITM as today",
				zap.String("next_step", "this build does not include a cbshim implementation; the OSS binary cannot intercept SCRAM-SHA-256-PLUS across the TLS MITM. Run an enterprise build (which registers a cbshim factory at init()) to get the feature, or set record.channelBindingShim: false to silence this log if non-PLUS clients are sufficient."))
		}
	}

	return proxy
}

// buildRecordSession constructs a RecordSession for a parser in record mode.
// It wraps src/dst in SafeConn. The caller (handleConnection) is responsible
// for creating the TLSUpgrader using pointers to its own srcConn/dstConn
// variables, so the upgrader updates the correct references on TLS upgrade.
func (p *Proxy) buildRecordSession(
	srcConn, dstConn net.Conn,
	mocks chan<- *models.Mock,
	errGrp *errgroup.Group,
	logger *zap.Logger,
	clientConnID, destConnID int64,
	opts models.OutgoingOptions,
	tlsUpgrader models.TLSUpgrader,
) *integrations.RecordSession {
	return &integrations.RecordSession{
		Ingress:      util.NewSafeConnWithReader(srcConn, srcConn, logger),
		Egress:       util.NewSafeConn(dstConn, logger),
		Mocks:        mocks,
		ErrGroup:     errGrp,
		TLSUpgrader:  tlsUpgrader,
		Logger:       logger,
		ClientConnID: fmt.Sprint(clientConnID),
		DestConnID:   fmt.Sprint(destConnID),
		Opts:         opts,
	}
}

// getSession returns the current session in a thread-safe manner.
func (p *Proxy) getSession() *agent.Session {
	p.sessionMu.RLock()
	defer p.sessionMu.RUnlock()
	return p.session
}

// setSession replaces the current session in a thread-safe manner.
func (p *Proxy) setSession(s *agent.Session) {
	p.sessionMu.Lock()
	defer p.sessionMu.Unlock()
	p.session = s
}

// GetSession returns the current session in a thread-safe manner (exported for enterprise).
func (p *Proxy) GetSession() *agent.Session {
	return p.getSession()
}

func (p *Proxy) GetDestInfo() agent.DestInfo {
	return p.DestInfo
}

func (p *Proxy) GetIntegrations() map[integrations.IntegrationType]integrations.Integrations {
	result := make(map[integrations.IntegrationType]integrations.Integrations, len(p.Integrations))
	for k, v := range p.Integrations {
		result[k] = v
	}
	return result
}

// ResetRecordedDNSMocks clears the DNS mock deduplication tracker.
// This should be called when starting a new recording session to ensure
// DNS mocks are recorded fresh for the new session.
func (p *Proxy) ResetRecordedDNSMocks() {
	p.recordedDNSMocks = newRecordedDNSMocksCache()
	p.logger.Debug("DNS mock deduplication tracker reset")
}

// SetGracefulShutdown sets the graceful shutdown flag to indicate the application is shutting down
// When this flag is set, connection errors will be logged as debug instead of error
func (p *Proxy) SetGracefulShutdown(_ context.Context) error {
	p.isGracefulShutdown.Store(true)
	p.logger.Debug("Graceful shutdown flag set - connection errors will be logged as debug")
	// Flush any in-flight packet capture so the test-set's pcap is
	// finalised before the agent is allowed to exit.
	p.stopPacketCapture()
	return nil
}

// SubscribePcap registers w to receive every captured packet as a
// pcap byte stream (file header + one record per frame). The flush
// callback, if non-nil, is invoked after each record — agent HTTP
// handlers pass http.Flusher.Flush so packets reach the recorder
// over chunked transfer-encoding without buffering. Returns the
// unsubscribe func; safe to call once. Errors when no capture is
// active for this proxy (i.e., --capture-packets was not set on
// the recording session).
func (p *Proxy) SubscribePcap(w io.Writer, flush func()) (func(), error) {
	p.pcapMu.Lock()
	b := p.pcapBroadcaster
	p.pcapMu.Unlock()
	if b == nil {
		return nil, errors.New("packet capture is not active")
	}
	return b.subscribe(w, flush)
}

// IsGracefulShutdown returns whether the graceful shutdown flag is set
func (p *Proxy) IsGracefulShutdown() bool {
	return p.isGracefulShutdown.Load()
}

func (p *Proxy) SetAuxiliaryHook(h agent.AuxiliaryProxyHook) {
	p.auxiliaryHook = h
}

// getMockManager returns the current mock manager in a thread-safe manner.
func (p *Proxy) getMockManager() *MockManager {
	p.sessionMu.RLock()
	defer p.sessionMu.RUnlock()
	return p.mockManager
}

// setMockManager replaces the current mock manager in a thread-safe manner.
//
// Swaps the new manager in while holding sessionMu, then closes the
// PREVIOUS manager after releasing the lock — Close() must not run under
// sessionMu because Close() synchronises with its own internal workers.
// Closing the outgoing manager stops its background idle-sweeper
// goroutine; without this, every Record / Mock session would leak a
// goroutine since MockManager owns a per-instance ticker that only
// stops on Close().
func (p *Proxy) setMockManager(m *MockManager) {
	p.sessionMu.Lock()
	prev := p.mockManager
	p.mockManager = m
	p.sessionMu.Unlock()
	if prev != nil {
		prev.Close()
	}
}

func (p *Proxy) InitIntegrations(_ context.Context) error {
	// initialize the integrations
	for parserType, parser := range integrations.Registered {
		logger := p.logger.With(zap.Any("Type", parserType))
		prs := parser.Initializer(logger)
		p.Integrations[parserType] = prs
		logger.Debug("initialized the parser integration", zap.String("ParserType", string(parserType)))
		p.integrationsPriority = append(p.integrationsPriority, ParserPriority{Priority: parser.Priority, ParserType: parserType})
	}
	sort.Slice(p.integrationsPriority, func(i, j int) bool {
		return p.integrationsPriority[i].Priority > p.integrationsPriority[j].Priority
	})
	return nil
}

// In proxy.go
func (p *Proxy) StartProxy(ctx context.Context, opts agent.ProxyOptions) error {

	// Skip the TCP listener if configured. DNS + parsers + session still run.
	if agent.SkipProxyListener {
		p.skipListener = true
	}

	//first initialize the integrations
	err := p.InitIntegrations(ctx)
	if err != nil {
		utils.LogError(p.logger, err, "failed to initialize the integrations")
		return err
	}

	// Start the continuous error drain so the error channel never fills up.
	// This must happen before any connections are handled.
	p.StartErrorDrain(ctx)

	// set up the CA for tls connections.
	//
	// On failure we record the terminal error via MarkCAFailed so the
	// /agent/ready handler can return a clear "CA setup failed"
	// diagnostic instead of an indefinite "not yet ready". We still
	// continue starting the proxy — the proxy can serve non-TLS
	// traffic and surfacing the error to readiness probes is a better
	// signal to operators than hard-aborting the agent here.
	// Use the PID-aware SetupCAForApp so the Java truststore import
	// (installJavaCAForHome) targets the JDK the instrumented app is
	// actually running with. On non-Java workloads / shared-volume
	// mode / appPID==0 these extra args are harmless — SetupCAForApp
	// falls back to the legacy PATH-keytool behaviour. See
	// pkg/agent/proxy/tls/java_detect.go for the resolution order.
	err = pTls.SetupCAForApp(ctx, p.logger, p.IsDocker, int(p.appPID), p.caJavaHome)
	if err != nil {
		// Terminal: the CA cannot be installed in this process and
		// Keploy-proxied TLS will fail cert-verify for every workload
		// that gets routed through the proxy. Log at Error (not Warn)
		// to match the severity, and include a next_step so operators
		// see the likely fix without grepping source.
		p.logger.Error(
			"SetupCA failed — Keploy-proxied TLS will fail cert-verify. "+
				"The /agent/ready endpoint will return 503 with this error "+
				"so dependents don't wait forever for a readiness that "+
				"will never come.",
			zap.Error(err),
			zap.String("next_step",
				"Verify the agent container has write access to the "+
					"shared /tmp/keploy-tls volume (docker/k8s mode) or "+
					"to the host's CA trust store under /usr/local/share/"+
					"ca-certificates or /etc/pki/ca-trust/source/anchors "+
					"(native mode). Restart the agent after fixing."),
		)
		pTls.MarkCAFailed(err)
	}

	// Channel-binding shim: now that appPID is known, walk the app's
	// process tree, register every visible descendant in the BPF
	// allowlist, attach uprobes to whatever libcryptos they map, and
	// kick off a background rescan that picks up workers forked
	// later (gunicorn/uwsgi) and lazy dlopen'd wheels (psycopg2-
	// binary loads its bundled libssl only on the first connect).
	//
	// Nil-safe: if cbshim failed to load (no CAP_BPF, older kernel,
	// etc.) p.cbshim is nil and these calls are no-ops. p.appPID==0
	// means we don't yet know the app PID — also a no-op; future
	// session-bind paths can call this explicitly.
	if p.cbshim != nil && p.appPID != 0 {
		// PID membership is BPF-side via task_in_agent_ns (lazy
		// namespace classification — see cbshim.bpf.c). No userspace
		// PID-walking polling loop. The library-refresh loop below
		// only handles late-loaded libcrypto files (bundled wheel
		// libs that appear after worker fork-exec) — its job is
		// per-file uprobe attach, NOT PID tracking.
		p.logger.Info("cbshim: scanning process tree for libcrypto/libpq mappings",
			zap.Uint32("appPID", p.appPID))
		if err := p.cbshim.AttachToProcessTree(int(p.appPID)); err != nil {
			p.logger.Info("cbshim: AttachToProcessTree returned error (continuing — library refresh will retry)",
				zap.Uint32("appPID", p.appPID), zap.Error(err),
				zap.String("next_step", "the first-pass scan of /proc/<appPID>/maps + descendants failed to find or attach a uprobe for libcrypto/libpq; the BPF discovery hook (cbshim's security_mmap_file fentry) will catch them on the next library mmap, so this is non-fatal. If SCRAM-PLUS still fails after a few requests, rerun with --debug to see per-process scanProcessMaps results and confirm the agent has CAP_BPF + the kernel allows bpf_probe_write_user."))
		} else {
			p.logger.Info("cbshim: AttachToProcessTree completed", zap.Uint32("appPID", p.appPID))
		}
		// Kick the sched_process_exec ringbuf consumer. The kernel
		// emits an event every time a process in the agent's PID
		// namespace completes execve(); consumer walks /proc/<tgid>/
		// maps to discover late-loaded libcrypto/libpq files (bundled
		// wheel libs, etc.) and attaches uprobes. Replaces the old
		// 2s polling loop with an event-driven design.
		p.cbshim.StartProcEventConsumer(ctx)
	} else if p.cbshim == nil {
		// Neutral debug-level log — nil cbshim is the EXPECTED state
		// when the feature flag is off or no implementation is
		// registered (OSS builds), not just when BPF load failed.
		// At Info this would spam every record-mode start.
		p.logger.Debug("cbshim: not attached (feature disabled or no implementation registered)")
	} else {
		p.logger.Debug("cbshim: appPID==0 — skipping AttachToProcessTree (no app PID yet)")
	}

	g, ok := ctx.Value(models.ErrGroupKey).(*errgroup.Group)
	if !ok {
		return errors.New("failed to get the error group from the context")
	}
	// Create a channel to signal readiness of each server
	readyChan := make(chan error, 1)

	// start the proxy server. p.start is the sole writer of readyChan:
	// it sends the startup error (or nil on success) exactly once on
	// every code path — skipListener, listen failure, and successful
	// listen. Do not send again here; readyChan is buffered size 1
	// and a second send would block forever because the caller at
	// line below only reads it once. Before this was fixed, the
	// skipListener path leaked this goroutine at shutdown.
	g.Go(func() error {
		defer utils.Recover(p.logger)
		err := p.start(ctx, readyChan)
		if err != nil {
			utils.LogError(p.logger, err, "error while running the proxy server")
			return err
		}
		return nil
	})

	//change the ip4 and ip6 if provided in the opts in case of docker environment
	if len(opts.DNSIPv4Addr) != 0 {
		p.IP4 = opts.DNSIPv4Addr
	}

	if len(opts.DNSIPv6Addr) != 0 {
		p.IP6 = opts.DNSIPv6Addr
	}

	// Capture the ORIGINAL cluster resolver list from /etc/resolv.conf
	// BEFORE binding our own listener on p.DNSPort. This MUST happen
	// here (not lazily on first query) because in Kubernetes sidecar
	// deployments the injector rewrites the app container's resolv.conf
	// nameserver entry to 127.0.0.1 and redirects DNS traffic to the
	// agent's port 26789 via iptables/eBPF (resolv.conf itself has no
	// port syntax — standard `nameserver` lines are IP-only). If we
	// ever pick that loopback entry up as our "upstream" we forward
	// queries back to ourselves. The sidecar's own /etc/resolv.conf
	// still points at CoreDNS at this point, so the snapshot we take
	// here is the correct set of real upstream resolvers. Errors are
	// non-fatal: on failure the forwarder simply falls back to the
	// legacy default response.
	p.captureDNSUpstream()

	// start the TCP DNS server
	p.logger.Debug("Starting Tcp Dns Server for handling Dns queries over TCP")
	g.Go(func() error {
		defer utils.Recover(p.logger)
		errCh := make(chan error, 1)
		go func(errCh chan error) {
			defer utils.Recover(p.logger)
			err := p.startTCPDNSServer(ctx)
			if err != nil {
				errCh <- err
			}
		}(errCh)

		select {
		case <-ctx.Done():
			if p.TCPDNSServer != nil {
				err := p.TCPDNSServer.Shutdown()
				if err != nil {
					utils.LogError(p.logger, err, "failed to shutdown tcp dns server")
					return err
				}
			}
			return nil
		case err := <-errCh:
			return err
		}
	})

	// start the UDP DNS server
	p.logger.Debug("Starting Udp Dns Server for handling Dns queries over UDP")
	g.Go(func() error {
		defer utils.Recover(p.logger)
		errCh := make(chan error, 1)
		go func(errCh chan error) {
			defer utils.Recover(p.logger)
			err := p.startUDPDNSServer(ctx)
			if err != nil {
				errCh <- err
			}
		}(errCh)

		select {
		case <-ctx.Done():
			if p.UDPDNSServer != nil {
				err := p.UDPDNSServer.Shutdown()
				if err != nil {
					utils.LogError(p.logger, err, "failed to shutdown tcp dns server")
					return err
				}
			}
			return nil
		case err := <-errCh:
			return err
		}
	})

	// Wait for the proxy server to be ready or fail
	if err := <-readyChan; err != nil {
		return err
	}

	if p.auxiliaryHook != nil {
		if err := p.auxiliaryHook.AfterStart(ctx, p); err != nil {
			// Do NOT swallow the error. An auxiliary hook only gets
			// registered when a caller has explicitly opted into the
			// feature it implements (currently: --low-latency, which
			// registers the proxyless / sockmap BPF startup). Silently
			// continuing into userspace-proxy mode after the hook has
			// declared a failure would give the user a mode they
			// didn't ask for and no deterministic signal that the
			// requested mode wasn't delivered.
			//
			// The hook itself is expected to embed actionable
			// remediation in the returned error (e.g. the enterprise
			// proxyless/sockmap hook wraps the BPF verifier error
			// with a "Next steps: upgrade kernel / drop --low-latency
			// / rebuild without the BPF variant" message). Log once
			// here with the hook's message visible in zap.Error and
			// a generic next_step pointing at that embedded guidance,
			// then propagate so the caller can abort. Partial-proxy
			// goroutines started before this point are torn down by
			// the caller cancelling proxyCtx (see service/agent.go).
			utils.LogError(p.logger, err, "auxiliary proxy hook failed; requested feature cannot run on this host",
				zap.String("next_step", "the hook's error wraps its own 'Next steps:' remediation — read the full error chain for the feature-specific fix (kernel upgrade, disabling the feature flag, or rebuilding without the BPF variant)"),
			)
			return fmt.Errorf("auxiliary proxy hook failed: %w", err)
		}
	}

	p.logger.Info("Keploy has taken control of the DNS resolution mechanism, your application may misbehave if you have provided wrong domain name in your application code.")

	if p.skipListener {
		p.logger.Info("Proxy TCP listener intentionally not bound (SkipProxyListener is set); DNS and session services are live but no port is accepting connections")
	} else {
		p.logger.Info(fmt.Sprintf("Proxy started at port:%v", p.Port))
	}
	return nil
}

// start function starts the proxy server on the idle local port.
// When skipListener is true, no TCP listener is created.
// The function blocks on ctx.Done and handles cleanup on shutdown.
func (p *Proxy) start(ctx context.Context, readyChan chan<- error) error {

	if p.skipListener {
		// Info-level notice is emitted once in StartProxy (near the
		// DNS-control log, which is the conventional "startup banner"
		// spot). Here we only want a debug trace for the start()
		// internal entry point so logs aren't duplicated.
		p.logger.Debug("Proxy TCP listener skipped; DNS and session services active")
		readyChan <- nil
		// Block until context is cancelled, then run cleanup.
		<-ctx.Done()
		// Intentionally do NOT close p.session.MC in the skipListener
		// path. The non-skip path above closes MC only after
		// clientConnErrGrp.Wait() guarantees every per-conn producer
		// has exited, so no send-to-closed-channel panic can fire.
		// In skipListener mode there is no clientConnErrGrp — DNS
		// mock producers and any external capture-layer senders are
		// still running up to ctx cancellation and may race a close.
		// Shutdown of downstream consumers is driven by ctx.Done()
		// instead; the Go runtime garbage-collects MC once all
		// references drop.
		p.nsSwitchMutex.Lock()
		if string(p.nsswitchData) != "" {
			if err := p.resetNsSwitchConfig(); err != nil {
				utils.LogError(p.logger, err, "failed to reset the nsswitch config, please retry shutdown or restore the resolver configuration manually from /etc/nsswitch.conf")
			}
		}
		p.nsSwitchMutex.Unlock()
		p.logger.Debug("proxy (skipListener) stopped")
		return nil
	}

	// It will listen on all the interfaces
	listener, err := net.Listen("tcp", fmt.Sprintf(":%v", p.Port))
	if err != nil {
		utils.LogError(p.logger, err, fmt.Sprintf("failed to start proxy on port:%v", p.Port))
		// Notify failure
		readyChan <- err
		return err
	}
	p.Listener = listener
	p.logger.Debug(fmt.Sprintf("Proxy server is listening on %s", fmt.Sprintf(":%v", listener.Addr())))
	// Signal that the server is ready
	readyChan <- nil
	defer func(listener net.Listener) {
		err := listener.Close()

		if err != nil && !isNetworkClosedErr(err) {
			p.logger.Error("failed to close the listener", zap.Error(err))
		}
		p.logger.Debug("proxy stopped...")
	}(listener)

	clientConnCtx, clientConnCancel := context.WithCancel(ctx)
	clientConnErrGrp, _ := errgroup.WithContext(clientConnCtx)

	// Periodically drain attributable buffered mocks WHILE recording is
	// live. The request-driven drains (ResolveRange / DeleteMocksStrictlyBefore)
	// can't reach a per-test mock that lands after the final request's HTTP
	// window closed — e.g. a multi-MB Mongo document still decoding when its
	// response was captured. Without this, such a mock waits in the buffer
	// until shutdown, where the cancelled recorder ctx makes the relay, the
	// consumer, and InsertMock all drop it. Ticking here persists it through
	// the healthy write path. Stops when clientConnCtx is cancelled (the
	// shutdown defer's clientConnCancel), before CloseOutChan.
	go func() {
		ticker := time.NewTicker(1 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-clientConnCtx.Done():
				return
			case <-ticker.C:
				if mgr := syncMock.Get(); mgr != nil {
					mgr.FlushOwnedWindows()
				}
			}
		}
	}()

	defer func() {
		clientConnCancel()

		// Close the listener synchronously BEFORE waiting for connection
		// handlers. Defers are LIFO, so without this the listener-close
		// defer (func1) runs AFTER this defer (func2). The accept
		// goroutine blocks on listener.Accept() — if we wait for
		// clientConnErrGrp before closing the listener, the accept
		// goroutine never exits, and on 2-CPU CI runners the scheduler
		// may not run other unblocking goroutines promptly, causing a hang.
		if listener != nil {
			listener.Close()
		}

		err := clientConnErrGrp.Wait()
		if err != nil {
			p.logger.Debug("failed to handle the client connection", zap.Error(err))
		}
		// Close the mock channel (if any in record mode) via
		// SyncMockManager so the close is serialized with in-flight
		// AddMock sends. A bare close(p.session.MC) here races the
		// record session's parser goroutines — the race detector
		// flagged this on keploy#4045 during the petclinic
		// record_build_replay_latest job, where the race also
		// correlated with a 28-min process hang at runtime.
		// CloseOutChan takes an RWMutex that AddMock holds for read,
		// guaranteeing every send completes before close runs.
		if mgr := syncMock.Get(); mgr != nil {
			mgr.CloseOutChan()
		} else {
			p.sessionMu.RLock()
			if p.session != nil && p.session.MC != nil {
				close(p.session.MC)
			}
			p.sessionMu.RUnlock()
		}

		p.nsSwitchMutex.Lock()
		if string(p.nsswitchData) != "" {
			// reset the hosts config in nsswitch.conf of the system (in test mode)
			err = p.resetNsSwitchConfig()
			if err != nil {
				utils.LogError(p.logger, err, "failed to reset the nsswitch config")
			}
		}
		p.nsSwitchMutex.Unlock()
	}()

	for {
		clientConnCh := make(chan net.Conn, 1)
		errCh := make(chan error, 1)
		go func() {
			defer utils.Recover(p.logger)
			conn, err := listener.Accept()
			if err != nil {
				if strings.Contains(err.Error(), "use of closed network connection") {
					errCh <- nil
					return
				}
				utils.LogError(p.logger, err, "failed to accept connection to the proxy")
				errCh <- err
				return
			}
			clientConnCh <- conn
		}()
		select {
		case <-ctx.Done():
			return nil
		case err := <-errCh:
			return err
		// handle the client connection
		case clientConn := <-clientConnCh:
			// Track the connection BEFORE spawning the goroutine to
			// close the Add-vs-Wait race that sync.WaitGroup's
			// contract forbids. If Add ran inside the goroutine
			// (i.e. after clientConnErrGrp.Go returns), a concurrent
			// StopProxyServer calling waitForConnDrain -> Wait could
			// observe count=0 and return before this connection's
			// goroutine registered itself — the shutdown would
			// then proceed as if there were no in-flight work, and
			// the late Add could trigger "sync: WaitGroup misuse"
			// panics in some interleavings. Done() still runs in
			// the goroutine's deferred cleanup.
			p.activeConns.Add(1)
			clientConnErrGrp.Go(func() error {
				defer p.activeConns.Done()
				defer util.Recover(p.logger, clientConn, nil)
				err := p.handleConnection(clientConnCtx, clientConn)
				if err != nil && err != io.EOF {
					// Network closed errors are expected when client closes connection (e.g., app shutdown)
					// Only log as error if it's not a shutdown/network closed error
					if isShutdownError(err) || isNetworkClosedErr(err) {
						p.logger.Debug("failed to handle the client connection (connection closed)", zap.Error(err))
					} else {
						utils.LogError(p.logger, err, "failed to handle the client connection")
					}
				}
				return nil
			})
		}
	}
}

func (p *Proxy) MakeClientDeRegisterd(_ context.Context) error {
	p.logger.Info("Inside MakeClientDeregisterd of proxyServer")
	p.clientClose <- true
	return nil
}

// handleConnection function executes the actual outgoing network call and captures/forwards the request and response messages.
func (p *Proxy) handleConnection(ctx context.Context, srcConn net.Conn) error {
	// activeConns.Add/Done are paired at the goroutine-spawn site
	// in the accept loop (see caller) to avoid the "Add concurrent
	// with Wait" race sync.WaitGroup documents as a misuse.
	//checking how much time proxy takes to execute the flow.
	start := time.Now()

	// making a new client connection id for each client connection
	clientConnID := util.GetNextID()
	defer func(start time.Time) {
		duration := time.Since(start)
		p.logger.Debug("time taken by proxy to execute the flow", zap.Any("Client ConnectionID", clientConnID), zap.Int64("Duration(ms)", duration.Milliseconds()))
	}(start)

	// dstConn stores conn with actual destination for the outgoing network call
	var dstConn net.Conn

	//Dialing for tls conn
	destConnID := util.GetNextID()

	remoteAddr := srcConn.RemoteAddr().(*net.TCPAddr)
	sourcePort := remoteAddr.Port

	probeProxy(p.logger, "accept", clientConnID, zap.Int("srcPort", sourcePort))

	p.logger.Debug("Inside handleConnection of proxyServer", zap.Int("source port", sourcePort), zap.Int64("Time", time.Now().Unix()))
	destInfo, err := p.DestInfo.Get(ctx, uint16(sourcePort))
	if err != nil {
		// Gracefully handle untracked connections (eBPF lookup failed)
		// This can happen when:
		// 1. A new connection was opened after test completion (e.g., driver health check)
		// 2. The eBPF hook didn't fire for this connection (race condition, bypass rule)
		// 3. The entry was already deleted before this lookup
		//
		// Instead of failing with an error (which causes the app to see a broken connection),
		// we close the connection gracefully. The client will see "connection refused" or EOF,
		// which is cleaner than a partial/broken connection that causes "already closed" errors.
		p.logger.Debug("Untracked connection (eBPF lookup failed), closing gracefully",
			zap.Int("Source port", sourcePort), zap.Error(err))
		if srcConn != nil {
			srcConn.Close()
		}
		return nil
	}

	p.logger.Debug("Handling outgoing connection to destination port", zap.Uint32("Destination port", destInfo.Port))

	// releases the occupied source port when done fetching the destination info
	err = p.DestInfo.Delete(ctx, uint16(sourcePort))
	if err != nil {
		utils.LogError(p.logger, err, "failed to delete the destination info", zap.Int("Source port", sourcePort))
		return err
	}

	//get the session rule
	rule := p.getSession()
	if rule == nil {
		utils.LogError(p.logger, nil, "failed to fetch the session rule")
		return err
	}

	// Create a local copy of OutgoingOptions to avoid data race when multiple
	// goroutines handle connections concurrently and modify DstCfg/Synchronous
	outgoingOpts := rule.OutgoingOptions

	mgr := syncMock.Get()
	mgr.SetOutputChannel(rule.MC)
	var dstAddr string

	switch destInfo.Version {
	case 4:
		p.logger.Debug("the destination is ipv4")
		dstAddr = fmt.Sprintf("%v:%v", util.ToIP4AddressStr(destInfo.IPv4Addr), destInfo.Port)
		p.logger.Debug("", zap.Uint32("DestIp4", destInfo.IPv4Addr), zap.Uint32("DestPort", destInfo.Port))
	case 6:
		p.logger.Debug("the destination is ipv6")
		dstAddr = fmt.Sprintf("[%v]:%v", util.ToIPv6AddressStr(destInfo.IPv6Addr), destInfo.Port)
		p.logger.Debug("", zap.Any("DestIp6", destInfo.IPv6Addr), zap.Uint32("DestPort", destInfo.Port))
	}

	// This is used to handle the parser errors
	parserErrGrp, parserCtx := errgroup.WithContext(ctx)
	parserCtx = context.WithValue(parserCtx, models.ErrGroupKey, parserErrGrp)
	parserCtx = context.WithValue(parserCtx, models.ClientConnectionIDKey, fmt.Sprint(clientConnID))
	parserCtx = context.WithValue(parserCtx, models.DestConnectionIDKey, fmt.Sprint(destConnID))
	parserCtx, parserCtxCancel := context.WithCancel(parserCtx)

	// Capture the initial srcConn before it gets reassigned (TLS upgrade, wrapping).
	initialSrcConn := srcConn

	// connCloser is started later (after dstConn is established) to close
	// both connections on context cancellation, unblocking any goroutine
	// stuck in a blocking read (ReadBytes → reader.Read).
	var connCloserStarted bool
	startConnCloser := func() {
		if connCloserStarted {
			return
		}
		connCloserStarted = true
		// Capture dstConn NOW (after dial) so there's no data race.
		closeDst := dstConn
		go func() {
			<-parserCtx.Done()
			initialSrcConn.Close()
			if closeDst != nil {
				closeDst.Close()
			}
		}()
	}

	defer func() {
		parserCtxCancel()

		if srcConn != nil {
			err := srcConn.Close()
			if err != nil {
				if !strings.Contains(err.Error(), "use of closed network connection") {
					utils.LogError(p.logger, err, "failed to close the source connection", zap.Any("clientConnID", clientConnID))
				}
			}
		}

		if dstConn != nil {
			err = dstConn.Close()
			if err != nil {
				// Use string matching as a last resort to check for the specific error
				if !strings.Contains(err.Error(), "use of closed network connection") {
					// Log other errors
					utils.LogError(p.logger, err, "failed to close the destination connection")
				}
			}
		}

		err = parserErrGrp.Wait()
		if err != nil {
			utils.LogError(p.logger, err, "failed to handle the parser cleanUp")
		}
	}()

	// Opportunistic TLS intercept: a separate passthrough variant
	// where we relay bytes verbatim AND peek for a TLS handshake;
	// when one shows up, we hijack and MITM both halves so the keys
	// land in the keylog fanout sink. Strictly more capable than
	// GlobalPassthrough for sessions where MITM is acceptable, but
	// lives on its own flag so deployments that need true
	// no-MITM passthrough (cert pinning, channel-binding clients,
	// other parser-incompatible workloads) keep their existing
	// semantics. Takes precedence over GlobalPassthrough.
	if p.OpportunisticTLSIntercept {
		if err := p.opportunisticTLSIntercept(parserCtx, srcConn, dstAddr, rule.Backdate); err != nil {
			utils.LogError(p.logger, err, "opportunistic TLS intercept failed",
				zap.String("server address", dstAddr))
			return err
		}
		return nil
	}

	//check for global passthrough in test mode
	if p.GlobalPassthrough || (!rule.Mocking && (rule.Mode == models.MODE_TEST)) {
		dstConn, err = net.Dial("tcp", dstAddr)
		if err != nil {
			utils.LogError(p.logger, err, "failed to dial the conn to destination server", zap.Uint32("proxy port", p.Port), zap.String("server address", dstAddr), zap.String("next_step", util.NextStepDialDestination))
			return err
		}

		err = p.globalPassThrough(parserCtx, srcConn, dstConn)
		if err != nil {
			utils.LogError(p.logger, err, "failed to handle the global pass through")
			return err
		}
		return nil
	}
	if p.synchronous {
		outgoingOpts.Synchronous = true
	}

	// MySQL wire-protocol ports (MySQL, TiDB, MariaDB, custom proxies).
	// Configurable via outgoingOpts.MysqlPorts (Config.MysqlPorts in
	// keploy.yml); defaults to [3306, 4000] when unset.
	if isMysqlPort(uint32(destInfo.Port), outgoingOpts.MysqlPorts) {
		if rule.Mode != models.MODE_TEST {
			dstConn, err = net.Dial("tcp", dstAddr)
			if err != nil {
				utils.LogError(p.logger, err, "failed to dial the conn to destination server", zap.Uint32("proxy port", p.Port), zap.String("server address", dstAddr), zap.String("next_step", util.NextStepDialDestination))
				return err
			}
			dstCfg := &models.ConditionalDstCfg{
				Addr: dstAddr,
				Port: uint(destInfo.Port),
			}
			outgoingOpts.DstCfg = dstCfg

			mysqlLogger := p.logger.With(
				zap.String("Client ConnectionID", fmt.Sprint(clientConnID)),
				zap.String("Destination ConnectionID", fmt.Sprint(destConnID)),
				zap.String("Destination Address", dstAddr),
			)
			mysqlSession := &integrations.RecordSession{
				Ingress:      util.NewSafeConn(srcConn, mysqlLogger),
				Egress:       util.NewSafeConn(dstConn, mysqlLogger),
				Mocks:        rule.MC,
				ErrGroup:     parserErrGrp,
				TLSUpgrader:  util.NewConnTLSUpgrader(&srcConn, &dstConn, p.logger, pTls.HandleTLSConnection),
				Logger:       mysqlLogger,
				ClientConnID: fmt.Sprint(clientConnID),
				DestConnID:   fmt.Sprint(destConnID),
				Opts:         outgoingOpts,
			}

			// Record the outgoing message into a mock
			err := p.Integrations[integrations.MYSQL].RecordOutgoing(parserCtx, mysqlSession)
			if err != nil {
				utils.LogError(p.logger, err, "failed to record the outgoing message")
				return err
			}
			return nil
		}

		m := p.getMockManager()
		if m == nil {
			utils.LogError(p.logger, nil, "failed to fetch the mock manager")
			return err
		}

		//mock the outgoing message
		err := p.Integrations[integrations.MYSQL].MockOutgoing(parserCtx, srcConn, &models.ConditionalDstCfg{Addr: dstAddr}, m, outgoingOpts)
		if err != nil && err != io.EOF && !errors.Is(err, context.Canceled) && !isNetworkClosedErr(err) {
			p.logger.Debug("mysql mock outgoing finished with error", zap.Error(err))
			p.sendMockNotFoundError(err)
			return err
		}
		return nil
	}

	reader := bufio.NewReader(srcConn)
	// Peek 5 bytes first — exactly what the TLS record header needs,
	// and the widest Peek we can do without risking a deadlock on
	// short plaintext greetings (e.g. Redis 'PING\r\n' is 6 bytes and
	// some protocols send <8 bytes then wait for a server reply).
	testBuffer, err := reader.Peek(5)
	if err != nil {
		if err == io.EOF && len(testBuffer) == 0 {
			p.logger.Debug("received EOF, closing conn", zap.Any("connectionID", clientConnID), zap.Error(err))
			return nil
		}
		// Network closed errors are expected when client closes connection (e.g., app shutdown)
		if isShutdownError(err) || isNetworkClosedErr(err) {
			p.logger.Debug("failed to peek the request message in proxy (connection closed)", zap.Uint32("proxy port", p.Port), zap.Error(err))
		} else {
			utils.LogError(p.logger, err, "failed to peek the request message in proxy", zap.Uint32("proxy port", p.Port))
		}
		return err
	}

	// ── Postgres SSLRequest handshake (opt-in) ──
	// When agent.InterceptPostgresSSLRequest is enabled, the proxy itself
	// replies 'S' and upgrades to TLS. Disabled by default because the
	// default build registers a Postgres parser (via extraparsers.go)
	// that already handles SSLRequest through the TLSUpgrader interface;
	// double-handling breaks the parser-driven flow. Downstream builds
	// that ship without a Postgres parser (pure proxy-mode) flip the
	// flag on via agent.SetInterceptPostgresSSLRequest.
	//
	// This block handles the client-facing side of SSLRequest: read
	// the 8-byte preamble, reply 'S', and terminate TLS with the
	// client. It is NOT client-side-only for the whole handshake —
	// when the destination is port 5432, the upstream dial path
	// (dialPostgresSSLUpstream) independently originates its own
	// Postgres SSLRequest before wrapping the upstream socket in
	// tls.Client. See the runtime_hooks.go docstring on
	// InterceptPostgresSSLRequest for the full deployment-shape
	// matrix. End-to-end MITM against a vanilla Postgres now works
	// under this flag; a registered parser-driven TLSUpgrader, when
	// one is wired via pkg/agent/proxy/extraparsers.go, remains the
	// richer option when you want protocol-aware mocking.
	//
	// We only extend the Peek to 8 bytes when the first 5 bytes match
	// the SSLRequest prefix (`00 00 00 08 04`). That prefix is unique
	// enough to rule out TLS (0x16 ...), CONNECT ("CONN"), and other
	// common greetings, so the extra 3-byte wait is deterministic for
	// exactly the one client that's actually speaking SSLRequest.
	// This keeps the short-greeting deadlock (Redis PING, memcached
	// 'quit', etc.) off the default code path.
	if agent.InterceptPostgresSSLRequest && isPostgresSSLRequestPrefix(testBuffer) {
		sslBuf, perr := reader.Peek(8)
		if perr != nil {
			utils.LogError(p.logger, perr, "client started with a Postgres SSLRequest prefix (00 00 00 08 04) but did not deliver the full 8-byte packet; the connection likely dropped mid-handshake — verify the client is a standard libpq/pgx/pq and check for a mismatched sslmode or an intermediary terminating the TCP stream",
				zap.Uint32("sourcePort", uint32(sourcePort)),
				zap.String("dstAddr", dstAddr))
			return perr
		}
		testBuffer = sslBuf
	}
	if agent.InterceptPostgresSSLRequest && isPostgresSSLRequest(testBuffer) {
		p.logger.Debug("Postgres SSLRequest detected, accepting and upgrading to TLS",
			zap.Int("sourcePort", sourcePort),
			zap.String("dstAddr", dstAddr),
		)
		// Consume the 8-byte SSLRequest from the buffered reader so the
		// downstream parser never sees it.
		if _, derr := reader.Discard(8); derr != nil {
			utils.LogError(p.logger, derr, "failed to discard Postgres SSLRequest bytes; the 8-byte SSLRequest was peeked but the bufio reader could not be advanced. This usually means the underlying TCP connection was reset between peek and discard — retry the client connection, and if it persists capture a packet trace between the client and the proxy listener",
				zap.Uint32("sourcePort", uint32(sourcePort)),
				zap.String("dstAddr", dstAddr))
			return derr
		}
		// Reply 'S' (TLS accepted). Write straight to the underlying TCP
		// connection; writes bypass the buffered reader.
		if _, werr := srcConn.Write([]byte{'S'}); werr != nil {
			utils.LogError(p.logger, werr, "failed to write 'S' SSLResponse to Postgres client; the proxy accepted the SSLRequest but could not send the one-byte acknowledgment. Verify the client is still connected (not a half-closed stream), check for client-side read timeouts shorter than the proxy's accept latency, and confirm no firewall is dropping 1-byte segments",
				zap.Uint32("sourcePort", uint32(sourcePort)),
				zap.String("dstAddr", dstAddr))
			return werr
		}
		// Re-peek for the TLS ClientHello. The client app sends it as soon
		// as it gets 'S'. 5 bytes is enough for IsTLSHandshake().
		testBuffer, err = reader.Peek(5)
		if err != nil {
			if err == io.EOF && len(testBuffer) == 0 {
				p.logger.Debug("Postgres client closed conn after SSLRequest reply")
				return nil
			}
			// Any non-nil error here means we could not read a complete
			// 5-byte TLS record header — either the client sent fewer
			// than 5 bytes before closing (EOF with partial buffer) or
			// the network errored out. Falling through would leave the
			// downstream TLS detection running against a truncated
			// prefix and misclassify the stream as plaintext, so bail.
			utils.LogError(p.logger, err, "failed to read a complete 5-byte TLS record header after replying 'S' to the Postgres SSLRequest; the client did not deliver enough bytes to identify a TLS ClientHello. Check the client's sslmode (require/verify-* should always follow with ClientHello after 'S'), confirm InterceptPostgresSSLRequest is only enabled in pure-proxy builds without a Postgres parser, and capture the bytes sent immediately after 'S' to verify a full TLS record header arrives (starting with 0x16)",
				zap.Uint32("sourcePort", uint32(sourcePort)),
				zap.String("dstAddr", dstAddr),
				zap.Int("bytesRead", len(testBuffer)))
			return err
		}
	}

	srcConn = &util.Conn{
		Conn:   srcConn,
		Reader: reader,
		Logger: p.logger,
	}

	// ── CONNECT tunnel handling ──
	// If the first bytes are an HTTP CONNECT request (app is using a corporate
	// HTTP proxy), we handle the CONNECT handshake here, then re-enter the
	// normal TLS MITM + parser flow on the unwrapped tunnel.
	//
	// Record mode: forward CONNECT to the real proxy, relay the 200, then MITM.
	// Test mode:   respond with 200 directly (no external proxy needed).
	var connectResult *connectTunnelResult
	if isConnectRequest(testBuffer) {
		p.logger.Debug("Detected HTTP CONNECT request, handling tunnel",
			zap.Int("sourcePort", sourcePort),
			zap.String("dstAddr", dstAddr),
		)

		isTestMode := rule.Mode == models.MODE_TEST

		// In record mode, we need a connection to the corporate proxy.
		var proxyConn net.Conn
		if !isTestMode {
			proxyConn, err = net.Dial("tcp", dstAddr)
			if err != nil {
				utils.LogError(p.logger, err, "failed to dial corporate proxy for CONNECT; verify the proxy address is correct, DNS/network is reachable, and HTTP_PROXY/HTTPS_PROXY settings are configured correctly",
					zap.String("proxy_addr", dstAddr))
				return err
			}
		}

		connectResult, err = handleConnectTunnel(p.logger, srcConn, proxyConn, isTestMode)
		if err != nil {
			// Close proxyConn on error to avoid leaking the TCP connection,
			// since it won't be assigned to dstConn for deferred cleanup.
			if proxyConn != nil {
				proxyConn.Close()
			}
			utils.LogError(p.logger, err, "failed to handle CONNECT tunnel; check HTTP_PROXY/HTTPS_PROXY settings, proxy authentication (407), DNS/network reachability to the proxy, and egress firewall rules")
			return err
		}

		// The CONNECT handshake is now complete. The app will send the next
		// bytes (typically a TLS ClientHello) over the same srcConn.
		// We need to re-peek to detect TLS on the inner connection.
		//
		// Also update dstAddr and destInfo to reflect the real target
		// (e.g., api.example.com:443) instead of the corporate proxy.
		dstAddr = connectResult.TargetAddr
		destInfo.Port = 443 // CONNECT targets are almost always TLS on 443
		if connectResult.TargetPort != "" {
			if portNum, err := strconv.ParseUint(connectResult.TargetPort, 10, 16); err == nil && portNum >= 1 && portNum <= 65535 {
				destInfo.Port = uint32(portNum)
			}
		}

		// Re-peek the next bytes to detect TLS on the inner tunnel.
		// Use the BufferedReader from handleConnectTunnel to preserve any
		// bytes it read ahead (e.g., TLS ClientHello pipelined by the client).
		innerReader := connectResult.BufferedReader
		testBuffer, err = innerReader.Peek(5)
		if err != nil {
			if err == io.EOF && len(testBuffer) == 0 {
				p.logger.Debug("CONNECT tunnel closed immediately after handshake")
				return nil
			}
			if err != io.EOF {
				utils.LogError(p.logger, err, "failed to peek inner tunnel data after CONNECT")
				return err
			}
			// Partial read with EOF — proceed with what we have.
		}

		// Wrap the raw TCP connection with innerReader for subsequent reads.
		// innerReader is the bufio.Reader from handleConnectTunnel that may
		// hold pipelined bytes (TLS ClientHello) in its internal buffer.
		srcConn = &util.Conn{
			Conn:   stripUtilConn(srcConn),
			Reader: innerReader,
			Logger: p.logger,
		}

		// In record mode, dstConn is now the tunneled connection through the
		// corporate proxy (the CONNECT tunnel is established, raw bytes flow).
		// We'll set dstConn = proxyConn so the TLS dial below wraps it.
		if !isTestMode {
			dstConn = proxyConn
		}

		p.logger.Debug("CONNECT tunnel established, proceeding with inner connection",
			zap.String("target", connectResult.TargetAddr),
			zap.Bool("innerTLS", pTls.IsTLSHandshake(testBuffer)),
		)
	}

	var clientPeerCert *x509.Certificate
	var isMTLS bool
	isTLS := pTls.IsTLSHandshake(testBuffer)

	// Speculative upstream TLS dial — kicked off in parallel with the
	// MITM client-facing handshake below so the two ~1 RTT handshakes
	// overlap instead of running serially. This is a record-mode
	// HTTP-only optimization; parser-driven paths (Postgres v2/v3,
	// MySQL, gRPC) and the CONNECT-tunnel-piped path keep the original
	// serial dial to preserve their exact TLS sequencing.
	//
	// The speculative dial uses a generic ALPN set [h2, http/1.1]; if
	// the per-connection ALPN decision made after initialBuf is
	// readable turns out to be incompatible (e.g. mTLS requires a
	// client cert, or the caller ends up wanting http/1.1-only while
	// the server picked h2), the join site abandons the speculative
	// conn and redials synchronously.
	var speculativeDial *speculativeUpstreamTLS
	var speculativeDialAddr string
	if isTLS && rule.Mode != models.MODE_TEST &&
		!(connectResult != nil && dstConn != nil) &&
		!(agent.InterceptPostgresSSLRequest && destInfo.Port == 5432) &&
		outgoingOpts.TLSPrivateKey == "" {
		if sniVal, ok := pTls.SrcPortToDstURL.Load(sourcePort); ok {
			if sni, ok := sniVal.(string); ok && sni != "" {
				addr := net.JoinHostPort(sni, fmt.Sprint(destInfo.Port))
				// InsecureSkipVerify mirrors the synchronous dial
				// below and the current MITM model (keploy is a
				// man-in-the-middle by design; upstream cert chain
				// verification would require shipping a CA bundle).
				specCfg := &tls.Config{
					InsecureSkipVerify: true, // nolint:gosec
					ServerName:         sni,
					NextProtos:         []string{"h2", "http/1.1"},
					KeyLogWriter:       pTls.KeyLogWriter(),
				}
				speculativeDial = startSpeculativeUpstreamTLS(ctx, addr, specCfg)
				speculativeDialAddr = addr
				p.logger.Debug("started speculative upstream TLS dial",
					zap.String("addr", addr),
					zap.String("sni", sni),
					zap.Strings("offeredALPN", specCfg.NextProtos))
				// Belt-and-braces cleanup: covers every early
				// return path between here and the join/abandon
				// sites below (clientID/destID lookup, initialBuf
				// read, partial-header read, HTTP/2 HEADERS
				// read, mTLS client cert apply). The captured
				// pointer is a local scoped above; nilling it at
				// the explicit join/abandon sites makes this a
				// no-op when control flows normally.
				defer func() {
					if speculativeDial != nil {
						speculativeDial.abandon()
					}
				}()
			}
		}
	}

	if isTLS {
		probeProxy(p.logger, "tls-handshake-start", clientConnID,
			zap.Int("srcPort", sourcePort),
			zap.Uint32("dstPort", destInfo.Port),
			zap.String("dstAddr", dstAddr),
			zap.Bool("speculative", speculativeDial != nil),
		)
		tlsStart := time.Now()
		srcConn, isMTLS, err = pTls.HandleTLSConnection(ctx, p.logger, srcConn, rule.Backdate)
		probeProxy(p.logger, "tls-handshake-done", clientConnID,
			zap.Int("srcPort", sourcePort),
			zap.Int64("dur_ns", time.Since(tlsStart).Nanoseconds()),
			zap.Bool("isMTLS", isMTLS),
			zap.Error(err),
		)
		if err != nil {
			// Client-facing MITM handshake failed; abandon the
			// speculative upstream dial so its goroutine and socket
			// are not leaked.
			if speculativeDial != nil {
				speculativeDial.abandon()
				speculativeDial = nil
			}
			utils.LogError(p.logger, err, "failed to handle TLS conn")
			return err
		}

		if isMTLS {
			if tlsConn, ok := srcConn.(*tls.Conn); ok {
				state := tlsConn.ConnectionState()
				if len(state.PeerCertificates) > 0 {
					clientPeerCert = state.PeerCertificates[0]
				}
			}
			// mTLS requires applying the client cert to the upstream
			// TLS config before the handshake — our speculative dial
			// did not do that, so discard it.
			if speculativeDial != nil {
				speculativeDial.abandon()
				speculativeDial = nil
			}
		}
	} else if speculativeDial != nil {
		// isTLS flipped to false somewhere between the check above and
		// this branch — defensive; abandon.
		speculativeDial.abandon()
		speculativeDial = nil
	}

	clientID, ok := parserCtx.Value(models.ClientConnectionIDKey).(string)
	if !ok {
		utils.LogError(p.logger, err, "failed to fetch the client connection id")
		return err
	}

	destID, ok := parserCtx.Value(models.DestConnectionIDKey).(string)
	if !ok {
		utils.LogError(p.logger, err, "failed to fetch the destination connection id")
		return err
	}

	logger := p.logger.With(zap.String("Client ConnectionID", clientID), zap.String("Destination ConnectionID", destID), zap.String("Destination Address", dstAddr), zap.String("Client IP Address", srcConn.RemoteAddr().String()))

	var initialBuf []byte
	// attempt to read conn until buffer is either filled or conn is closed
	initialBuf, err = util.ReadInitialBuf(parserCtx, p.logger, srcConn)
	if err != nil {
		utils.LogError(logger, err, "failed to read the initial buffer")
		return err
	}

	if util.IsHTTPReq(initialBuf) && !util.HasCompleteHTTPHeaders(initialBuf) {
		// HTTP headers are never chunked according to the HTTP protocol,
		// but at the TCP layer, we cannot be sure if we have received the entire
		// header in the first buffer chunk. This is why we check if the headers are complete
		// and read more data if needed.

		// Some HTTP requests, like AWS SQS, may require special handling in Keploy Enterprise.
		// These cases may send partial headers in multiple chunks, so we need to read until
		// we get the complete headers.

		logger.Debug("Partial HTTP headers detected, reading more data to get complete headers")

		// Read more data from the TCP connection to get the complete HTTP headers.
		headerBuf, err := util.ReadHTTPHeadersUntilEnd(parserCtx, p.logger, srcConn)
		if err != nil {
			// Log the error if we fail to read the complete HTTP headers.
			utils.LogError(logger, err, "failed to read the complete HTTP headers from client")
			return err
		}
		// Append the additional data to the initial buffer.
		initialBuf = append(initialBuf, headerBuf...)
	}

	// For HTTP/2 connections, the initial buffer may only contain the client
	// preface and SETTINGS frames. Protocol matchers (gRPC vs h2c) need to
	// inspect the HEADERS frame's content-type to decide.
	//
	// We use a short timeout read instead of a blocking read because:
	//  - h2c clients typically send preface+SETTINGS+HEADERS in quick succession
	//  - gRPC clients send preface+SETTINGS, then WAIT for server SETTINGS_ACK
	//    before sending HEADERS — a blocking read would deadlock.
	//
	// If HEADERS arrives within the timeout → matchers can inspect content-type.
	// If it doesn't (gRPC pattern) → matchers treat missing HEADERS as gRPC.
	if util.IsHTTP2Preface(initialBuf) && !util.HasHTTP2HeadersFrame(initialBuf) {
		logger.Debug("HTTP/2 preface detected but no HEADERS frame yet, attempting short timeout read")

		const http2HeadersReadTimeout = 150 * time.Millisecond
		moreBuf, err := util.ReadWithTimeout(srcConn, http2HeadersReadTimeout)
		if err != nil {
			utils.LogError(logger, err, "failed to read HTTP/2 HEADERS frame from client")
			return err
		}
		if len(moreBuf) > 0 {
			initialBuf = append(initialBuf, moreBuf...)
		}
	}

	//update the src connection to have the initial buffer
	srcConn = &util.Conn{
		Conn:   srcConn,
		Reader: util.NewPrefixReader(initialBuf, srcConn),
		Logger: p.logger,
	}

	dstCfg := &models.ConditionalDstCfg{
		Port: uint(destInfo.Port),
	}

	//make new connection to the destination server
	if isTLS {

		// get the destinationUrl from the map for the tls connection
		url, ok := pTls.SrcPortToDstURL.Load(sourcePort)
		if !ok {
			utils.LogError(logger, err, "failed to fetch the destination url")
			return err
		}
		//type case the dstUrl to string
		dstURL, ok := url.(string)
		if !ok {
			utils.LogError(logger, err, "failed to type cast the destination url")
			return err
		}

		logger.Debug("the external call is tls-encrypted", zap.Bool("isTLS", isTLS))

		nextProtos := []string{"http/1.1"} // default safe

		isHTTP := util.IsHTTPReq(initialBuf)
		isCONNECT := bytes.HasPrefix(initialBuf, []byte("CONNECT "))
		logger.Debug("ALPN decision debug",
			zap.Bool("isHTTPReq", isHTTP),
			zap.Bool("isCONNECT", isCONNECT),
			zap.Int("initialBufLen", len(initialBuf)),
		)

		// Allow H2 if:
		// 1. It's not an HTTP/1.x request (could be gRPC/HTTP2 frames), OR
		// 2. It's a CONNECT request (used by gRPC parser for tunneling, ALB requires H2)
		if !isHTTP || isCONNECT {
			// not an HTTP/1.x request line; could be HTTP/2 (gRPC) frames
			nextProtos = []string{"h2", "http/1.1"}
			logger.Debug("Offering H2 for ALPN", zap.Strings("nextProtos", nextProtos))
		} else {
			logger.Debug("NOT offering H2 (HTTP/1.x detected)", zap.Strings("nextProtos", nextProtos))
		}

		serverName := dstURL
		// If SNI was not captured (e.g., client omitted it after CONNECT),
		// fall back to the CONNECT target hostname for the TLS handshake.
		// Skip IP literals — Go's TLS uses IP SANs, not ServerName for those.
		if serverName == "" && connectResult != nil && net.ParseIP(connectResult.TargetHost) == nil {
			serverName = connectResult.TargetHost
		}

		cfg := &tls.Config{
			InsecureSkipVerify: true,
			ServerName:         serverName,
			NextProtos:         nextProtos,
			KeyLogWriter:       pTls.KeyLogWriter(),
		}

		if isMTLS && rule.Mode != models.MODE_TEST && clientPeerCert != nil {
			err = p.applyMTLSClientCert(cfg, clientPeerCert, outgoingOpts.TLSPrivateKey)
			if err != nil {
				return err
			}
		}

		addr := dstAddr
		if dstURL != "" {
			addr = net.JoinHostPort(dstURL, fmt.Sprint(destInfo.Port))
		}

		if rule.Mode != models.MODE_TEST {
			if connectResult != nil && dstConn != nil {
				// CONNECT tunnel: dstConn is already connected through the
				// corporate proxy tunnel. If the proxyReader has buffered
				// bytes beyond the 200 response, wrap dstConn to preserve them.
				var tlsTransport net.Conn = dstConn
				if connectResult.DstReader != nil && connectResult.DstReader.Buffered() > 0 {
					tlsTransport = &util.Conn{
						Conn:   dstConn,
						Reader: connectResult.DstReader,
						Logger: p.logger,
					}
				}
				tlsConn := tls.Client(tlsTransport, cfg)
				if err := tlsConn.Handshake(); err != nil {
					utils.LogError(logger, err, "failed TLS handshake over CONNECT tunnel; verify the corporate proxy allows CONNECT to this target, check proxy auth/egress rules, and confirm the target hostname is reachable",
						zap.String("target", addr))
					return err
				}
				dstConn = tlsConn
				logger.Debug("TLS over CONNECT tunnel established",
					zap.String("protocol", tlsConn.ConnectionState().NegotiatedProtocol),
					zap.String("target", addr))
			} else {
				// When InterceptPostgresSSLRequest is on AND the
				// destination is a Postgres service (port 5432 is
				// the reliable-enough heuristic — documented in the
				// hook docstring), precede the TLS dial with the
				// Postgres SSLRequest preamble the server expects.
				// Otherwise tls.Dial to 5432 sends a ClientHello
				// directly, which a vanilla Postgres rejects — the
				// flag's client-side 'S' reply would then succeed
				// while the upstream connection fails, leaving the
				// replayed client staring at a broken stream.
				if agent.InterceptPostgresSSLRequest && destInfo.Port == 5432 {
					// Postgres SSL preamble — never use the
					// speculative conn (different wire sequence).
					if speculativeDial != nil {
						speculativeDial.abandon()
						speculativeDial = nil
					}
					probeProxy(p.logger, "upstream-dial-start", clientConnID, zap.String("branch", "pg-ssl"), zap.String("addr", addr))
					dialStart := time.Now()
					dstConn, err = dialPostgresSSLUpstream(ctx, strconv.Itoa(sourcePort), addr, cfg, p.logger, p.cbshim)
					probeDial(p.logger, "pg-ssl-upstream", clientConnID, addr, time.Since(dialStart).Nanoseconds(), zap.Error(err))
					// Release cbshim's per-connection rendezvous state
					// at connection exit. dialPostgresSSLUpstream may
					// have already called RegisterReal; if the matching
					// MITM half from CertForClient never arrives
					// (handshake fails, postgres rejects auth pre-SCRAM,
					// client disconnects mid-handshake, etc.), Publish
					// never fires and the pending entry would leak
					// until process exit. Snapshot the handle so a
					// concurrent SetCBShim(nil) during shutdown can't
					// race the deferred call. No-op when Publish has
					// already drained the entry.
					if cb := p.cbshim; cb != nil {
						connID := strconv.Itoa(sourcePort)
						defer cb.CleanupConnection(connID)
					}
				} else if speculativeDial != nil && addr == speculativeDialAddr &&
					nextProtosSubset(cfg.NextProtos, speculativeDial.protos) {
					// Fast path: the speculative dial targeted the
					// same addr and offered a superset of the ALPN
					// the caller now wants. Join it.
					probeProxy(p.logger, "upstream-dial-start", clientConnID, zap.String("branch", "speculative-join"), zap.String("addr", addr))
					joinStart := time.Now()
					var specConn *tls.Conn
					specConn, err = speculativeDial.join(ctx)
					probeDial(p.logger, "speculative-join", clientConnID, addr, time.Since(joinStart).Nanoseconds(), zap.Error(err))
					speculativeDial = nil
					if err == nil {
						negotiated := specConn.ConnectionState().NegotiatedProtocol
						// Guard against the server negotiating a
						// protocol that is NOT in the caller's
						// desired set. Offered was a superset, so
						// this is only possible when the server
						// negotiated h2 while cfg wanted http/1.1
						// exclusively. Redial synchronously with
						// the caller's exact cfg to preserve
						// record-mode semantics.
						if negotiated != "" && !nextProtosSubset([]string{negotiated}, cfg.NextProtos) {
							p.logger.Debug("speculative upstream TLS protocol mismatch, redialing",
								zap.String("negotiated", negotiated),
								zap.Strings("wanted", cfg.NextProtos))
							_ = specConn.Close()
							dstConn, err = tls.Dial("tcp", addr, cfg)
						} else {
							dstConn = specConn
						}
					}
				} else {
					// Conditions for speculation did not hold (different
					// addr, narrower ALPN than offered, or no speculation
					// was started). Abandon any in-flight speculative
					// dial and do a fresh synchronous dial with cfg.
					if speculativeDial != nil {
						speculativeDial.abandon()
						speculativeDial = nil
					}
					probeProxy(p.logger, "upstream-dial-start", clientConnID, zap.String("branch", "synchronous"), zap.String("addr", addr))
					dialStart := time.Now()
					dstConn, err = tls.Dial("tcp", addr, cfg)
					probeDial(p.logger, "synchronous-tls", clientConnID, addr, time.Since(dialStart).Nanoseconds(), zap.Error(err))
				}
				if err != nil {
					utils.LogError(logger, err, "failed to dial the conn to destination server", zap.Uint32("proxy port", p.Port), zap.String("server address", addr), zap.String("next_step", util.NextStepDialDestination))
					return err
				}

				conn := dstConn.(*tls.Conn)
				state := conn.ConnectionState()

				p.logger.Debug("Negotiated protocol:", zap.String("protocol", state.NegotiatedProtocol))
			}
		}

		dstCfg.TLSCfg = cfg
		dstCfg.Addr = addr
	} else {
		// Only dial if dstConn not already set (e.g., from PostgreSQL SSL handling)
		if rule.Mode != models.MODE_TEST && dstConn == nil {
			probeProxy(p.logger, "upstream-dial-start", clientConnID, zap.String("branch", "plain-tcp"), zap.String("addr", dstAddr))
			dialStart := time.Now()
			dstConn, err = net.Dial("tcp", dstAddr)
			probeDial(p.logger, "plain-tcp", clientConnID, dstAddr, time.Since(dialStart).Nanoseconds(), zap.Error(err))
			if err != nil {
				utils.LogError(logger, err, "failed to dial the conn to destination server", zap.Uint32("proxy port", p.Port), zap.String("server address", dstAddr), zap.String("next_step", util.NextStepDialDestination))
				return err
			}
		}
		dstCfg.Addr = dstAddr
	}

	outgoingOpts.DstCfg = dstCfg

	// Start the shutdown goroutine now that dstConn is established.
	startConnCloser()

	// get the mock manager for the current app
	m := p.getMockManager()
	if m == nil {
		utils.LogError(logger, err, "failed to fetch the mock manager")
		return err
	}

	generic := true

	var matchedParser integrations.Integrations
	var parserType integrations.IntegrationType

	//Checking for all the parsers according to their priority.
	for _, parserPair := range p.integrationsPriority { // Iterate over ordered priority list
		parser, exists := p.Integrations[parserPair.ParserType]
		if !exists {
			continue // Skip if parser not found
		}

		p.logger.Debug("Checking for the parser", zap.String("ParserType", string(parserPair.ParserType)))
		if parser.MatchType(parserCtx, initialBuf) {
			matchedParser = parser
			parserType = parserPair.ParserType
			generic = false
			break
		}
	}

	probeProxy(p.logger, "integration-select", clientConnID,
		zap.String("parser", string(parserType)),
		zap.Bool("generic", generic),
	)

	// Record-mode parsing kill switch: if record-time parsing has been
	// disabled via env var (KEPLOY_DISABLE_PARSING), SIGUSR1, or admin
	// endpoint, skip parser dispatch and hand the connection to
	// globalPassThrough. Existing connections whose parsers are already
	// running are unaffected; this only gates new dispatch.
	//
	// MODE_TEST is intentionally NOT gated here — the kill switch is a
	// record-time stability escape hatch only; replay must continue to
	// match mocks regardless of record-time kill-switch state.
	if rule.Mode == models.MODE_RECORD && util.DefaultKillSwitch.Enabled() {
		logger.Debug("record-mode parsing kill switch tripped; routing to passthrough",
			zap.String("parser", string(parserType)), zap.Bool("generic", generic))
		return p.globalPassThrough(parserCtx, srcConn, dstConn)
	}

	if !generic {
		p.logger.Debug("The external dependency is supported. Hence using the parser", zap.String("ParserType", string(parserType)))
		switch rule.Mode {
		case models.MODE_RECORD:
			// V2 path: parsers that have been migrated to the supervisor +
			// relay + FakeConn architecture declare it via IntegrationsV2.
			// The dispatcher routes them through recordViaSupervisor which
			// isolates parser panics/hangs and falls through to passthrough
			// on failure. The legacy path below is preserved for parsers
			// that have not yet migrated.
			if v2, ok := matchedParser.(integrations.IntegrationsV2); ok && v2.IsV2() && !newRelayDisabled() {
				if err := p.recordViaSupervisor(parserCtx, srcConn, dstConn, matchedParser, parserType, rule.MC, parserErrGrp, logger, clientConnID, destConnID, outgoingOpts); err != nil {
					if isNetworkClosedErr(err) {
						logger.Debug("V2 record path: connection closed", zap.Error(err))
					} else {
						utils.LogError(logger, err, "V2 record path failed",
							zap.String("parser", string(parserType)),
							zap.String("next_step", "set KEPLOY_NEW_RELAY=off to force the legacy record path for this parser while investigating, or KEPLOY_DISABLE_PARSING=1 / SIGUSR1 to disable parser dispatch entirely (raw passthrough); the supervisor has already fallen through to passthrough for this connection so user traffic continues"),
						)
					}
					return err
				}
				// Outcome-specific logging lives inside recordViaSupervisor
				// (success vs. fallthrough-to-passthrough look the same
				// from this layer — both return nil error — but mean
				// different things for the mocks captured). Here we only
				// know the record path completed without a caller-visible
				// error; the parser outcome was already logged.
				logger.Debug("V2 record path returned", zap.String("ParserType", string(parserType)))
				break
			}

			// Create TLSUpgrader in handleConnection scope so it holds pointers to
			// the real srcConn/dstConn variables (not copies in buildRecordSession).
			var upgrader models.TLSUpgrader
			if parserType == integrations.MYSQL ||
				parserType == integrations.POSTGRES_V2 ||
				parserType == integrations.POSTGRES_V3 {
				upgrader = util.NewConnTLSUpgrader(&srcConn, &dstConn, p.logger, pTls.HandleTLSConnection)
			}
			session := p.buildRecordSession(srcConn, dstConn, rule.MC, parserErrGrp, logger, clientConnID, destConnID, outgoingOpts, upgrader)
			err := matchedParser.RecordOutgoing(parserCtx, session)
			if err != nil {
				if isNetworkClosedErr(err) {
					logger.Debug("failed to record the outgoing message (connection closed)", zap.Error(err))
				} else {
					utils.LogError(logger, err, "failed to record the outgoing message")
				}
				return err
			}
			logger.Debug("successfully recorded outgoing message", zap.String("ParserType", string(parserType)))
		case models.MODE_TEST:
			err := matchedParser.MockOutgoing(parserCtx, srcConn, dstCfg, m, outgoingOpts)
			if err != nil && err != io.EOF && !errors.Is(err, context.Canceled) && !isNetworkClosedErr(err) {
				utils.LogError(logger, err, "failed to mock the outgoing message")
				// Send specific error type to error channel for external monitoring
				p.sendMockNotFoundError(err)
				return err
			}
		}
	}

	if generic {
		logger.Debug("The external dependency is not supported. Hence using generic parser")
		if rule.Mode == models.MODE_RECORD {
			genericSession := p.buildRecordSession(srcConn, dstConn, rule.MC, parserErrGrp, logger, clientConnID, destConnID, outgoingOpts, nil)
			err := p.Integrations[integrations.GENERIC].RecordOutgoing(parserCtx, genericSession)
			if err != nil && err != io.EOF && !errors.Is(err, context.Canceled) && !strings.Contains(err.Error(), "tls: user canceled") {
				utils.LogError(logger, err, "failed to record the outgoing message")
				return err
			}
		} else {
			err := p.Integrations[integrations.GENERIC].MockOutgoing(parserCtx, srcConn, dstCfg, m, outgoingOpts)
			if err != nil && err != io.EOF && !errors.Is(err, context.Canceled) && !isNetworkClosedErr(err) {
				utils.LogError(logger, err, "failed to mock the outgoing message")
				// Send specific error type to error channel for external monitoring
				p.sendMockNotFoundError(err)
				return err
			}
		}
	}
	return nil
}

func (p *Proxy) StopProxyServer(ctx context.Context) {
	<-ctx.Done()

	p.logger.Info("stopping proxy server...")

	// Coordinated shutdown sequence (PLAN.md §3.7, partial I8).
	//
	// 1. Trip the parsing kill switch first. Any connection still in
	//    flight between Accept and parser dispatch is routed to raw
	//    globalPassThrough instead of a parser — so we don't start a
	//    parser goroutine for a connection that's about to be torn
	//    down.
	// 2. Close the listener, stopping further Accepts.
	// 3. Give existing parser goroutines a bounded grace window to
	//    finish naturally via activeConns WaitGroup (they see
	//    ctx.Done via the parent context and return; their deferred
	//    srcConn/dstConn closes fire on return).
	// 4. Past the grace window, remaining goroutines continue to exit
	//    asynchronously via ctx cancellation — we do NOT hold
	//    references to their net.Conn values, which avoids
	//    double-close races with the deferred closes above. Shutdown
	//    is bounded by the grace timeout; stragglers are abandoned
	//    to the parent context, not force-closed from under their
	//    own defers.
	//
	// The kernel-side proxy_ready BPF gate that would prevent new
	// connects from being redirected here once the userspace process
	// is unhealthy requires BPF source changes (the source is not in
	// this repo) and is tracked as deferred work in PLAN.md.
	util.DefaultKillSwitch.Trip()
	defer util.DefaultKillSwitch.Reset()

	var cleanupErrors []error
	if p.Listener != nil {
		if err := p.Listener.Close(); err != nil {
			cleanupErrors = append(cleanupErrors, fmt.Errorf("failed to close listener: %w", err))
		}
		p.Listener = nil
	}

	// Drain grace: let in-flight parsers finish naturally before we
	// pull the rug on their client connections. 5 seconds is long
	// enough for typical request/response cycles but short enough
	// that shutdown doesn't hang indefinitely on a stuck parser.
	const drainGrace = 5 * time.Second
	drainCtx, drainCancel := context.WithTimeout(context.Background(), drainGrace)
	defer drainCancel()
	p.waitForConnDrain(drainCtx)

	// Any connections still in flight after the grace window have
	// already received parent-context cancellation (propagated into
	// the per-connection parserCtx in handleConnection). Their own
	// deferred srcConn/dstConn closes run on return. We intentionally
	// do NOT keep a shared slice of net.Conn values: that requires
	// tracking lifecycle hooks we don't own reliably, and the
	// WaitGroup + ctx cancellation combination already covers the
	// "stuck parser eventually exits" case without double-close
	// races on the real sockets.
	if p.UDPDNSServer != nil || p.TCPDNSServer != nil {
		if err := p.stopDNSServers(ctx); err != nil {
			cleanupErrors = append(cleanupErrors, fmt.Errorf("failed to stop DNS servers: %w", err))

		}
	}

	// Channel-binding shim teardown — detach uprobes, drop allowlist
	// entries, release BPF maps. Nil-safe so the no-BPF path doesn't
	// trip a panic here. WatchProcessTree's goroutine has already
	// exited via the proxy context being cancelled by the caller of
	// StopProxyServer; Close() is idempotent against an in-flight
	// goroutine racing it.
	if p.cbshim != nil {
		// Detach the global tls.MITMPublishHook so NEW CertForClient
		// callers can't observe the handle. SetMITMPublishHook(nil)
		// blocks until any in-flight publishMITM returns — see
		// pkg/agent/proxy/tls/ca.go for the RWMutex drain — so no
		// CertForClient → RegisterMITM call survives this point.
		//
		// We deliberately do NOT mutate p.cbshim here. In-flight
		// connection-scoped goroutines (notably the opportunistic-TLS
		// path) read p.cbshim multiple times within one connection;
		// a racing nil-write would tear those reads. Since shutdown
		// is in progress (listener closed, parent ctx cancelled, no
		// new accepts), leaving p.cbshim pointing at the (now-quiesced)
		// handle is safe — its publisher-facing surface is already
		// inert via the cleared global hook.
		//
		// The actual cb.Close() is deferred onto a goroutine that
		// waits for activeConns to drain. dialPostgresSSLUpstream
		// captures p.cbshim into a function-local at call time, so
		// goroutines mid-pg-SSL-handshake when shutdown starts are
		// covered by the WaitGroup. Drain already had drainGrace
		// seconds above; the deferred Close keeps the BPF maps +
		// uprobes alive until the last in-flight goroutine returns.
		// Kernel reclaims any leaked BPF resources at process exit
		// if Wait never returns.
		cb := p.cbshim
		pTls.SetMITMPublishHook(nil)
		go func() {
			p.activeConns.Wait()
			if err := cb.Close(); err != nil {
				p.logger.Debug("cbshim deferred close error",
					zap.Error(err))
			}
		}()
	}

	p.CloseErrorChannel()
	if len(cleanupErrors) > 0 {
		for _, err := range cleanupErrors {
			utils.LogError(p.logger, err, "cleanup error in StopProxyServer")
		}
		p.logger.Error("proxy stopped with cleanup errors", zap.Int("error_count", len(cleanupErrors)))
	} else {
		p.logger.Debug("proxy stopped cleanly...")
	}
}

func (p *Proxy) applyMTLSClientCert(cfg *tls.Config, clientPeerCert *x509.Certificate, tlsPrivateKey string) error {
	if cfg == nil || clientPeerCert == nil {
		return nil
	}

	if tlsPrivateKey == "" {
		err := errors.New("failed to read private key from outgoing options")
		utils.LogError(p.logger, err, "failed to apply mTLS client cert")
		return err
	}

	keyBytes := []byte(tlsPrivateKey)
	block, _ := pem.Decode(keyBytes)
	if block == nil {
		err := errors.New("failed to decode PEM block containing private key")
		utils.LogError(p.logger, err, "failed to apply mTLS client cert")
		return err
	}

	var privKey any
	if key, err := x509.ParsePKCS1PrivateKey(block.Bytes); err == nil {
		privKey = key
	} else if key, err := x509.ParsePKCS8PrivateKey(block.Bytes); err == nil {
		privKey = key
	} else if key, err := x509.ParseECPrivateKey(block.Bytes); err == nil {
		privKey = key
	}

	if privKey == nil {
		err := errors.New("failed to parse private key from PEM")
		utils.LogError(p.logger, err, "failed to apply mTLS client cert")
		return err
	}

	cfg.Certificates = []tls.Certificate{{
		Certificate: [][]byte{clientPeerCert.Raw},
		PrivateKey:  privKey,
	}}
	p.logger.Debug("Successfully constructed mTLS certificate using client peer cert and local key")
	return nil
}

func (p *Proxy) Record(ctx context.Context, mocks chan<- *models.Mock, opts models.OutgoingOptions) error {
	// Reset graceful shutdown flag for a new recording session.
	p.isGracefulShutdown.Store(false)
	// Reset DNS mock deduplication tracker for fresh recording
	p.ResetRecordedDNSMocks()
	// Lift the per-session opportunistic-TLS toggle onto the proxy
	// for handleConnection to read. Independent of GlobalPassthrough.
	p.OpportunisticTLSIntercept = opts.OpportunisticTLSIntercept
	p.setSession(&agent.Session{
		Mode:            models.MODE_RECORD,
		MC:              mocks,
		OutgoingOptions: opts,
	})
	p.setMockManager(NewMockManager(NewTreeDb(customComparator), NewTreeDb(customComparator), p.logger))

	if opts.CapturePackets {
		// Agent picks its own scratch dir on its OWN filesystem; the
		// recorder cannot pass a path here because the two processes
		// usually run in separate filesystems (Docker, k8s, separate
		// hosts). The recorder pulls the finalised bytes back via the
		// agent's /agent/pcap/{traffic,keylog} HTTP endpoints.
		// Use a context detached from the per-call ctx so the capture
		// outlives this Record() call and runs for the full session;
		// stopPacketCapture is invoked on the next Record()/Mock() or
		// when the proxy shuts down.
		if err := p.startPacketCapture(context.Background(), ""); err != nil {
			utils.LogError(p.logger, err, "failed to start packet capture; continuing without pcap")
		}
	} else {
		// New session without capture — make sure any previous capture
		// from a prior test-set is torn down.
		p.stopPacketCapture()
	}

	return nil
}

func (p *Proxy) Mock(_ context.Context, opts models.OutgoingOptions) error {
	// Reset graceful shutdown flag for a new mocking session.
	p.isGracefulShutdown.Store(false)
	// Mock is replay; no pcap capture during replay. Tear down any
	// capture left over from a previous record session.
	p.stopPacketCapture()
	p.setSession(&agent.Session{
		Mode:            models.MODE_TEST,
		OutgoingOptions: opts,
	})
	// Reuse the existing MockManager when this proxy has already been
	// put into mock mode at least once. Replay calls Mock() per test-set
	// (Agent.MockOutgoing → Proxy.Mock); allocating a fresh MockManager
	// on every call strands long-lived parser goroutines on the previous
	// instance. The postgres-v3 replayer's runLoop is the canonical
	// case — its PerTestProvider/SessionProvider/StartupProvider capture
	// the *MockManager handed in at MockOutgoing time and keep polling
	// it for the connection's lifetime. With a per-test-set replacement
	// the new manager's StoreMocks / UpdateMockParams (and the revision
	// bumps keploy/integrations#203 relies on for revision-gated
	// rebuilds) land on the new instance the parsers cannot see, while
	// the parsers keep reading test-set-N-1's cohort off the orphaned
	// manager. Production globality autoreplay exhibits exactly this
	// pattern: one user app survives the whole replay, the asyncpg pool
	// keeps its TCP connection to the proxy warm across test-set
	// boundaries, the v3 runLoop survives, and PerTestProvider.Current
	// never observes the swap. Reusing the manager keeps revision-
	// tracking continuous; the filtered / unfiltered / startup trees
	// still get replaced atomically by SetMocksWithWindow per test-set,
	// and ResetForReplaySession below clears connection-scoped state
	// (connectionTrees, noConnMocks, droppedOutOfWindow) so the
	// previous test-set's per-connID mock pool doesn't leak into the
	// next one — SetMocksWithWindow seeds new connection mocks via
	// AddConnectionMock but never evicts prior entries, so without the
	// explicit reset a long-lived connection could match
	// LifetimeConnection mocks from the prior test-set or merge them
	// with the current one's.
	if mm := p.getMockManager(); mm == nil {
		p.setMockManager(NewMockManager(NewTreeDb(customComparator), NewTreeDb(customComparator), p.logger))
	} else {
		mm.ResetForReplaySession()
	}

	if !opts.Mocking {
		p.logger.Info("🔀 Mocking is disabled, the response will be fetched from the actual service")
	}

	p.nsSwitchMutex.Lock()
	defer p.nsSwitchMutex.Unlock()
	if string(p.nsswitchData) == "" {
		// setup the nsswitch config to redirect the DNS queries to the proxy
		err := p.setupNsswitchConfig()
		if err != nil {
			utils.LogError(p.logger, err, "failed to setup nsswitch config")
			return errors.New("failed to mock the outgoing message")
		}
	}
	return nil
}

func (p *Proxy) SetMocks(_ context.Context, filtered []*models.Mock, unFiltered []*models.Mock) error {
	if m := p.getMockManager(); m != nil {
		m.SetFilteredMocks(filtered)
		m.SetUnFilteredMocks(unFiltered)
		p.dnsCache.Purge()
	}

	return nil
}

// SetMocksWithWindow atomically updates mocks AND the test window in a
// single call so concurrent readers cannot observe a torn (newMocks,
// oldWindow) view. Used to satisfy the WindowedProxy extension interface.
func (p *Proxy) SetMocksWithWindow(_ context.Context, filtered, unFiltered []*models.Mock, start, end time.Time) error {
	if m := p.getMockManager(); m != nil {
		m.SetMocksWithWindow(filtered, unFiltered, start, end)
		p.dnsCache.Purge()
	}
	return nil
}

// FirstTestWindowStart returns the earliest test window start observed
// by the underlying MockManager, or zero before any non-BaseTime
// SetMocksWithWindow has landed. Satisfies the agent's optional
// FirstWindowStartReader extension interface.
//
// Used by the agent's tier-aware strictMockWindow filter to preserve
// startup-init mocks (req < firstWindowStart) while still dropping
// stale cross-test bleed (firstWindowStart <= req < currentStart).
// Zero-time return means "no cutoff known yet" and callers should fall
// back to legacy strict-gate semantics.
func (p *Proxy) FirstTestWindowStart() time.Time {
	if m := p.getMockManager(); m != nil {
		return m.FirstTestWindowStart()
	}
	return time.Time{}
}

// GetConsumedMocks returns the consumed filtered mocks.
func (p *Proxy) GetConsumedMocks(_ context.Context) ([]models.MockState, error) {
	m := p.getMockManager()
	if m == nil {
		return nil, fmt.Errorf("mock manager not found to get consumed filtered mocks")
	}
	return m.GetConsumedMocks(), nil
}

// testErrorAccumulator collects errors during an active test case.
// It is goroutine-safe via an internal mutex.
type testErrorAccumulator struct {
	mu   sync.Mutex
	errs []error
}

func (a *testErrorAccumulator) add(err error) {
	a.mu.Lock()
	a.errs = append(a.errs, err)
	a.mu.Unlock()
}

func (a *testErrorAccumulator) drain() []error {
	a.mu.Lock()
	e := a.errs
	a.errs = nil
	a.mu.Unlock()
	return e
}

// StartErrorDrain launches a background goroutine that continuously reads from
// errChannel so it never fills up. Errors are routed to the activeTestErrors
// accumulator when a test is running, and discarded otherwise.
// This prevents background services (OTel, health checks) from saturating the
// 100-slot error channel and blocking test coordination.
func (p *Proxy) StartErrorDrain(ctx context.Context) {
	p.errDrainOnce.Do(func() {
		var discarded atomic.Int64
		go func() {
			defer utils.Recover(p.logger)
			for {
				select {
				case <-ctx.Done():
					return
				case err, ok := <-p.errChannel:
					if !ok {
						return
					}
					if acc := p.activeTestErrors.Load(); acc != nil {
						acc.add(err)
					} else {
						// Log only the first discard and then every 100th to reduce noise.
						n := discarded.Add(1)
						if n == 1 || n%100 == 0 {
							p.logger.Debug("discarding mock error outside active test",
								zap.Error(err), zap.Int64("totalDiscarded", n))
						}
					}
				}
			}
		}()
	})
}

// BeginTestErrorCapture starts collecting errors for the current test case.
// Call EndTestErrorCapture when the test finishes to retrieve collected errors.
func (p *Proxy) BeginTestErrorCapture() {
	p.activeTestErrors.Store(&testErrorAccumulator{})
}

// EndTestErrorCapture stops collecting errors and returns all accumulated errors.
func (p *Proxy) EndTestErrorCapture() []error {
	if acc := p.activeTestErrors.Swap(nil); acc != nil {
		return acc.drain()
	}
	return nil
}

// GetErrorChannel returns the error channel for external monitoring.
// When StartErrorDrain is active, this channel is continuously drained by the
// background goroutine. Direct consumers (monitorProxyErrors) will compete
// for reads. Prefer using BeginTestErrorCapture/EndTestErrorCapture instead.
func (p *Proxy) GetErrorChannel() <-chan error {
	return p.errChannel
}

// GetMockErrors drains all mock-not-found errors and returns them.
// When StartErrorDrain is active, it reads from the test accumulator instead
// of the channel (which is drained by the background goroutine).
func (p *Proxy) GetMockErrors(_ context.Context) ([]models.UnmatchedCall, error) {
	var rawErrs []error

	// Prefer test accumulator if active (StartErrorDrain is running)
	if acc := p.activeTestErrors.Load(); acc != nil {
		rawErrs = acc.drain()
	} else {
		// Fallback: drain from channel directly (legacy path)
	drainLoop:
		for {
			select {
			case err, ok := <-p.errChannel:
				if !ok {
					break drainLoop
				}
				rawErrs = append(rawErrs, err)
			default:
				break drainLoop
			}
		}
	}

	var errs []models.UnmatchedCall
	for _, err := range rawErrs {
		if parserErr, ok := err.(models.ParserError); ok && parserErr.ParserErrorType == models.ErrMockNotFound {
			if parserErr.MismatchReport != nil {
				errs = append(errs, models.UnmatchedCall{
					Protocol:      parserErr.MismatchReport.Protocol,
					ActualSummary: parserErr.MismatchReport.ActualSummary,
					ClosestMock:   parserErr.MismatchReport.ClosestMock,
					Diff:          parserErr.MismatchReport.Diff,
					NextSteps:     parserErr.MismatchReport.NextSteps,
				})
			}
		}
	}
	return errs, nil
}

// SendError sends an error to the error channel for external monitoring.
func (p *Proxy) SendError(err error) {
	select {
	case p.errChannel <- err:
	default:
		p.logger.Error("Error channel is full, dropping error", zap.Error(err))
	}
}

// sendMockNotFoundError builds a ParserError from a mock-miss error,
// extracting the MismatchReport if the error carries one.
func (p *Proxy) sendMockNotFoundError(err error) {
	proxyErr := models.ParserError{
		ParserErrorType: models.ErrMockNotFound,
		Err:             err,
	}
	// Extract diff report from the error chain if available.
	// Use errors.As to traverse wrapped errors.
	type mismatchReporter interface {
		MismatchReport() *models.MockMismatchReport
	}
	var reporter mismatchReporter
	if errors.As(err, &reporter) && reporter != nil {
		proxyErr.MismatchReport = reporter.MismatchReport()
	}
	p.SendError(proxyErr)
}

// CloseErrorChannel closes the error channel
func (p *Proxy) CloseErrorChannel() {
	close(p.errChannel)
}

func (p *Proxy) Mapping(ctx context.Context, mappingCh chan models.TestMockMapping) {
	mgr := syncMock.Get()
	if mgr != nil {
		mgr.SetMappingChannel(mappingCh)
	}
}

func isShutdownError(err error) bool {
	if errors.Is(err, context.Canceled) {
		return true
	}
	if errors.Is(err, net.ErrClosed) {
		return true
	}
	errStr := err.Error()
	if strings.Contains(errStr, "use of closed network connection") {
		return true
	}
	if errors.Is(err, syscall.ECONNRESET) || errors.Is(err, syscall.ECONNABORTED) {
		return true
	}
	if strings.Contains(errStr, "connection reset by peer") {
		return true
	}
	// Windows-specific error patterns for connection close during shutdown
	if strings.Contains(errStr, "wsarecv") || strings.Contains(errStr, "wsasend") ||
		strings.Contains(errStr, "forcibly closed by the remote host") {
		return true
	}
	return false
}
