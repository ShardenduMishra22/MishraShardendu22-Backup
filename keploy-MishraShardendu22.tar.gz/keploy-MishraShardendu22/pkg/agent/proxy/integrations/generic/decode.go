// Package generic provides functionality for decoding generic dependencies.
package generic

import (
	"context"
	"fmt"
	"io"
	"net"
	"time"

	"go.keploy.io/server/v3/pkg/agent/proxy/integrations"
	"go.keploy.io/server/v3/pkg/agent/proxy/integrations/util"
	pUtil "go.keploy.io/server/v3/pkg/agent/proxy/util"
	"go.keploy.io/server/v3/pkg/models"
	"go.keploy.io/server/v3/utils"
	"go.uber.org/zap"
)

func decodeGeneric(ctx context.Context, logger *zap.Logger, reqBuf []byte, clientConn net.Conn, dstCfg *models.ConditionalDstCfg, mockDb integrations.MockMemDb, _ models.OutgoingOptions) error {
	genericRequests := [][]byte{reqBuf}
	logger.Debug("Into the generic parser in test mode")
	errCh := make(chan error, 1)
	go func(errCh chan error, genericRequests [][]byte) {
		defer pUtil.Recover(logger, clientConn, nil)
		defer close(errCh)
		for {
			// Since protocol packets have to be parsed for checking stream end,
			// clientConnection have deadline for read to determine the end of stream.
			err := clientConn.SetReadDeadline(time.Now().Add(10 * time.Millisecond))
			if err != nil {
				utils.LogError(logger, err, "failed to set the read deadline for the client conn")
				return
			}

			// To read the stream of request packets from the client
			for {
				buffer, err := pUtil.ReadBytes(ctx, logger, clientConn)
				// Applied this nolint to ignore the staticcheck error here because of readability
				// nolint:staticcheck
				if netErr, ok := err.(net.Error); !(ok && netErr.Timeout()) && err != nil && err.Error() != "EOF" {
					utils.LogError(logger, err, "failed to read the request message in proxy for generic dependency")
					return
				}
				if netErr, ok := err.(net.Error); (ok && netErr.Timeout()) || (err != nil && err.Error() == "EOF") {
					logger.Debug("the timeout for the client read in generic or EOF")
					break
				}
				genericRequests = append(genericRequests, buffer)
			}

			if len(genericRequests) == 0 {
				logger.Debug("the generic request buffer is empty")
				continue
			}

			// bestMatchedIndx := 0
			// fuzzy match gives the index for the best matched generic mock
			matched, genericResponses, err := fuzzyMatch(ctx, logger, genericRequests, mockDb)
			if err != nil {
				utils.LogError(logger, err, "error while matching generic mocks")
			}

			if !matched {
				preview := genericRequests[0]
				if len(preview) > 64 {
					preview = preview[:64]
				}
				logger.Debug("mock miss",
					zap.String("protocol", "Generic"),
					zap.Int("requestCount", len(genericRequests)),
					zap.Int("firstRequestBytes", len(genericRequests[0])),
					zap.String("hint", "Re-record mocks if the wire protocol data has changed"),
					zap.Binary("preview", preview))
				errCh <- fmt.Errorf("no matching generic mock found")
				return
			}
			for _, genericResponse := range genericResponses {
				encoded := []byte(genericResponse.Message[0].Data)
				if genericResponse.Message[0].Type != models.String {
					encoded, err = util.DecodeBase64(genericResponse.Message[0].Data)
					if err != nil {
						utils.LogError(logger, err, "failed to decode the base64 response")
						return
					}
				}
				_, err := clientConn.Write(encoded)
				if err != nil {
					if ctx.Err() != nil {
						return
					}
					utils.LogError(logger, err, "failed to write the response message to the client application")
					return
				}
			}

			// Clear the genericRequests buffer for the next dependency call
			genericRequests = [][]byte{}
			logger.Debug("the genericRequests after the iteration", zap.Int("length", len(genericRequests)))
		}
	}(errCh, genericRequests)

	select {
	case <-ctx.Done():
		return ctx.Err()
	case err := <-errCh:
		if err == io.EOF {
			return nil
		}
		return err
	}
}
