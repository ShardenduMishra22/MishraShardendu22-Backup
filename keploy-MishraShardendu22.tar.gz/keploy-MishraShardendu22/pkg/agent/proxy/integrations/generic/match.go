package generic

import (
	"context"
	"fmt"

	"go.keploy.io/server/v3/pkg"
	"go.keploy.io/server/v3/pkg/agent/proxy/integrations"
	"go.uber.org/zap"

	"go.keploy.io/server/v3/pkg/agent/proxy/integrations/util"
	"go.keploy.io/server/v3/pkg/models"
)

// fuzzyMatch performs a fuzzy matching algorithm to find the best matching mock for the given request.
// It takes a context, a request buffer, and a mock database as input parameters.
// The function iterates over the mocks in the database and applies the fuzzy matching algorithm to find the best match.
// If a match is found, it returns the corresponding response mock and a boolean value indicating success.
// If no match is found, it returns false and a nil response.
// If an error occurs during the matching process, it returns an error.
func fuzzyMatch(ctx context.Context, logger *zap.Logger, reqBuff [][]byte, mockDb integrations.MockMemDb) (bool, []models.Payload, error) {
	for {
		select {
		case <-ctx.Done():
			return false, nil, ctx.Err()
		default:
			mocks, err := mockDb.GetSessionMocks()
			if err != nil {
				return false, nil, fmt.Errorf("error while getting session mocks: %w", err)
			}

			var filteredMocks []*models.Mock
			var unfilteredMocks []*models.Mock

			for _, mock := range mocks {
				if mock.Kind != "Generic" {
					continue
				}
				if mock.TestModeInfo.IsFiltered {
					filteredMocks = append(filteredMocks, mock)
				} else {
					unfilteredMocks = append(unfilteredMocks, mock)
				}
			}

			logger.Debug("List of mocks in the database", zap.Int("Filtered Mocks", len(filteredMocks)), zap.Int("Unfiltered Mocks", len(unfilteredMocks)))
			for i, mock := range filteredMocks {
				logger.Debug("Filtered Mocks", zap.String(fmt.Sprintf("Mock[%d]", i), mock.Name), zap.Int64("sortOrder", mock.TestModeInfo.SortOrder))
			}
			for i, mock := range unfilteredMocks {
				logger.Debug("Unfiltered Mocks", zap.String(fmt.Sprintf("Mock[%d]", i), mock.Name), zap.Int64("sortOrder", mock.TestModeInfo.SortOrder))
			}

			index := findExactMatch(filteredMocks, reqBuff)

			if index == -1 {
				index = findBinaryMatch(filteredMocks, reqBuff, 0.9)
			}

			// Concurrency note for both branches below: see HTTP's
			// updateMock — filteredMocks[index] / unfilteredMocks[index]
			// are pointers into the shared mock pool, so we mutate a
			// fresh copy rather than the pool pointer and pass the copy
			// to UpdateUnFilteredMock.
			if index != -1 {
				responseMock := make([]models.Payload, len(filteredMocks[index].Spec.GenericResponses))
				copy(responseMock, filteredMocks[index].Spec.GenericResponses)
				updatedMock := *filteredMocks[index]
				updatedMock.TestModeInfo.IsFiltered = false
				updatedMock.TestModeInfo.SortOrder = pkg.GetNextSortNum()
				isUpdated := mockDb.UpdateUnFilteredMock(filteredMocks[index], &updatedMock)
				if !isUpdated {
					continue
				}
				logger.Debug("Filtered mock found for generic request", zap.String("Mock", updatedMock.Name), zap.Int64("sortOrder", updatedMock.TestModeInfo.SortOrder))
				return true, responseMock, nil
			}

			index = findExactMatch(unfilteredMocks, reqBuff)

			if index == -1 {
				index = findBinaryMatch(unfilteredMocks, reqBuff, 0.4)
			}
			if index != -1 {
				responseMock := make([]models.Payload, len(unfilteredMocks[index].Spec.GenericResponses))
				copy(responseMock, unfilteredMocks[index].Spec.GenericResponses)
				updatedMock := *unfilteredMocks[index]
				updatedMock.TestModeInfo.IsFiltered = false
				updatedMock.TestModeInfo.SortOrder = pkg.GetNextSortNum()
				isUpdated := mockDb.UpdateUnFilteredMock(unfilteredMocks[index], &updatedMock)
				if !isUpdated {
					continue
				}
				logger.Debug("Unfiltered mock found for generic request", zap.String("Mock", updatedMock.Name), zap.Int64("sortOrder", updatedMock.TestModeInfo.SortOrder))
				return true, responseMock, nil
			}
			return false, nil, nil
		}
	}
}

// TODO: need to generalize this function for different types of integrations.
func findBinaryMatch(tcsMocks []*models.Mock, reqBuffs [][]byte, mxSim float64) int {
	// TODO: need find a proper similarity index to set a benchmark for matching or need to find another way to do approximate matching
	mxIdx := -1
	for idx, mock := range tcsMocks {
		if len(mock.Spec.GenericRequests) == len(reqBuffs) {
			nc := util.NewNoiseChecker(mock.Noise)
			var simSum float64
			var simCount int
			for requestIndex, reqBuff := range reqBuffs {
				mockData := mock.Spec.GenericRequests[requestIndex].Message[0].Data

				// Skip noisy (obfuscated) buffers — don't let them influence similarity
				if nc != nil && nc.IsNoisy(mockData) {
					continue
				}

				encoded, _ := util.DecodeBase64(mockData)

				similarity := fuzzyCheck(encoded, reqBuff)
				simSum += similarity
				simCount++
			}
			// Compute average similarity across non-noisy buffers.
			// If all buffers are noisy, treat as neutral (1.0) so the
			// mock remains matchable — schema/length already matched.
			if simCount > 0 {
				avgSim := simSum / float64(simCount)
				if avgSim > mxSim {
					mxSim = avgSim
					mxIdx = idx
				}
			} else if len(reqBuffs) > 0 {
				// All buffers were noisy — neutral match
				if 1.0 > mxSim {
					mxSim = 1.0
					mxIdx = idx
				}
			}
		}
	}
	return mxIdx
}

func fuzzyCheck(encoded, reqBuf []byte) float64 {
	k := util.AdaptiveK(len(reqBuf), 3, 8, 5)
	shingles1 := util.CreateShingles(encoded, k)
	shingles2 := util.CreateShingles(reqBuf, k)
	similarity := util.JaccardSimilarity(shingles1, shingles2)
	return similarity
}

func findExactMatch(tcsMocks []*models.Mock, reqBuffs [][]byte) int {
	for idx, mock := range tcsMocks {
		if len(mock.Spec.GenericRequests) == len(reqBuffs) {
			nc := util.NewNoiseChecker(mock.Noise)
			matched := true // Flag to track if all requests match

			for requestIndex, reqBuff := range reqBuffs {
				mockData := mock.Spec.GenericRequests[requestIndex].Message[0].Data

				// If mock data is noisy (obfuscated), skip comparison for this buffer
				if nc != nil && nc.IsNoisy(mockData) {
					continue
				}

				bufStr := string(reqBuff)
				if !util.IsASCII(string(reqBuff)) {
					bufStr = util.EncodeBase64(reqBuff)
				}

				// Compare the encoded data
				if mockData != bufStr {
					matched = false
					break // Exit the loop if any request doesn't match
				}
			}

			if matched {
				return idx
			}
		}
	}
	return -1
}
