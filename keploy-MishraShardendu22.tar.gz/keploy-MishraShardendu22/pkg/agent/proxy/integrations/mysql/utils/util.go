// Package utils provides utility functions for MySQL packets
package utils

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"

	"go.keploy.io/server/v3/pkg/agent/proxy/util"
	"go.keploy.io/server/v3/pkg/models/mysql"
	"go.keploy.io/server/v3/utils"
	"go.uber.org/zap"
)

// ReadFirstBuffer reads the first buffer from either clientConn or destConn
func ReadFirstBuffer(ctx context.Context, logger *zap.Logger, clientConn, destConn net.Conn) ([]byte, string, error) {
	// Attempt to read from destConn first
	buf, err := util.ReadBytes(ctx, logger, destConn)
	// If there is data from destConn, return it
	if err == nil {
		return buf, "destination", nil
	}
	// If the error is a timeout, try to read from clientConn
	if netErr, ok := err.(net.Error); ok && netErr.Timeout() {
		buf, err = util.ReadBytes(ctx, logger, clientConn)
		// If there is data from clientConn, return it
		if err == nil {
			return buf, "client", nil
		}
		// Return any error from reading clientConn
		return nil, "", err
	}
	// Return any other error from reading destConn
	return nil, "", err
}

// ReadPacketStream reads packets from the connection and sends them to the bufferChannel
func ReadPacketStream(ctx context.Context, logger *zap.Logger, conn net.Conn, bufferChannel chan []byte, errChannel chan error) {
	for {
		select {
		case <-ctx.Done():
			// errChannel <- ctx.Err()
			return
		default:
			if conn == nil {
				logger.Debug("the conn is nil")
			}
			buffer, err := ReadPacketBuffer(ctx, logger, conn)
			if err != nil {
				if ctx.Err() != nil { // to avoid sending buffer to closed channel if the context is cancelled
					return
				}
				if err != io.EOF {
					utils.LogError(logger, err, "failed to read mysql packet buffer")
				}
				errChannel <- err
				return
			}
			if ctx.Err() != nil { // to avoid sending buffer to closed channel if the context is cancelled
				return
			}
			bufferChannel <- buffer
		}
	}
}

// ReadPacketBuffer reads a MySQL packet from the connection
func ReadPacketBuffer(ctx context.Context, logger *zap.Logger, conn net.Conn) ([]byte, error) {
	var packetBuffer []byte
	// first read the header length
	header, err := util.ReadRequiredBytes(ctx, logger, conn, 4)
	if err != nil {
		if err == io.EOF {
			return nil, err
		}
		// return packetBuffer, fmt.Errorf("failed to read mysql packet header: %w", err)
		return packetBuffer, err
	}

	packetBuffer = append(packetBuffer, header...)

	// read the payload length
	payloadLength := GetPayloadLength(header[:3])
	if payloadLength > 0 {
		payload, err := util.ReadRequiredBytes(ctx, logger, conn, int(payloadLength))
		if err != nil {
			if err == io.EOF {
				return nil, err
			}
			// return packetBuffer, fmt.Errorf("failed to read mysql packet payload: %w", err)
			return packetBuffer, err
		}
		packetBuffer = append(packetBuffer, payload...)
	}

	return packetBuffer, nil
}

// BytesToMySQLPacket converts a byte slice to a MySQL packet
func BytesToMySQLPacket(buffer []byte) (mysql.Packet, error) {
	if len(buffer) < 4 {
		return mysql.Packet{}, errors.New("buffer is nil or too short to be a valid MySQL packet")
	}

	tempBuffer := make([]byte, 4)
	copy(tempBuffer, buffer[:3])
	length := binary.LittleEndian.Uint32(tempBuffer)
	sequenceID := buffer[3]

	payload := buffer[4:]

	return mysql.Packet{
		Header: mysql.Header{
			PayloadLength: length,
			SequenceID:    sequenceID,
		},
		Payload: payload,
	}, nil
}

// GetPayloadLength returns the length of the payload from the first 3 bytes of the packet.
func GetPayloadLength(src []byte) (length uint32) {
	length = uint32(src[0]) | uint32(src[1])<<8 | uint32(src[2])<<16
	return length
}

func ReadLengthEncodedInteger(b []byte) (num uint64, isNull bool, n int) {
	if len(b) == 0 {
		return 0, true, 0
	}

	switch b[0] {
	// 251: NULL
	case 0xfb:
		return 0, true, 1

		// 252: value of following 2
	case 0xfc:
		if len(b) < 3 {
			return 0, true, 0
		}
		return uint64(b[1]) | uint64(b[2])<<8, false, 3

		// 253: value of following 3
	case 0xfd:
		if len(b) < 4 {
			return 0, true, 0
		}
		return uint64(b[1]) | uint64(b[2])<<8 | uint64(b[3])<<16, false, 4

		// 254: value of following 8
	case 0xfe:
		if len(b) < 9 {
			return 0, true, 0
		}
		return uint64(b[1]) | uint64(b[2])<<8 | uint64(b[3])<<16 |
				uint64(b[4])<<24 | uint64(b[5])<<32 | uint64(b[6])<<40 |
				uint64(b[7])<<48 | uint64(b[8])<<56,
			false, 9
	}

	// 0-250: value of first byte
	return uint64(b[0]), false, 1
}

func IsEOFPacket(data []byte) bool {
	if len(data) < 5 {
		return false // Packet is too short to be valid
	}

	// First payload byte must be 0xFE (EOF marker).
	if data[4] != 0xFE {
		return false
	}

	// Validate the full 3-byte payload length (little-endian) to avoid
	// false positives on larger packets whose LSB happens to be 5 or 1.
	// Legacy EOF payload is 5 bytes (with CLIENT_PROTOCOL_41) or 1 byte.
	payloadLen := uint32(data[0]) | uint32(data[1])<<8 | uint32(data[2])<<16

	// Also verify the buffer is long enough to contain the claimed payload.
	if uint32(len(data)-4) < payloadLen {
		return false
	}
	return payloadLen == 5 || payloadLen == 1
}

func IsERRPacket(data []byte) bool {
	return len(data) > 9 && data[4] == mysql.ERR
}

func IsOKPacket(data []byte) bool {
	return len(data) > 7 && data[4] == mysql.OK
}

// maxOKReplacingEOFPayload is the maximum reasonable payload size for an
// OK-replacing-EOF terminator packet. An OK terminator for a SELECT carries
// header (1) + affected_rows (1) + last_insert_id (1) + status_flags (2) +
// warnings (2) + optional session state info. Even with large session state,
// this should never exceed 1024 bytes. Text row packets using 0xFE
// length-encoded integers encode values >= 16 MB, so their total payload
// will always exceed this bound — eliminating false positives.
const maxOKReplacingEOFPayload = 1024

// IsOKReplacingEOF detects the OK packet that replaces EOF when
// CLIENT_DEPRECATE_EOF is negotiated. This packet uses the 0xFE header
// byte (same as legacy EOF) but carries OK-packet structure. We validate
// strictly: header 0xFE, consistent payload length, both affected_rows and
// last_insert_id zero (always true for SELECT terminators), and a
// reasonable payload size upper bound to avoid false positives with text
// row packets whose first column uses the 0xFE length-encoded integer
// form (which encodes values >= 16 MB).
// See: https://dev.mysql.com/doc/dev/mysql-server/latest/page_protocol_basic_ok_packet.html
func IsOKReplacingEOF(data []byte) bool {
	if len(data) < 11 {
		return false
	}

	// Payload length is stored in the first 3 bytes (little-endian).
	payloadLen := uint32(data[0]) | uint32(data[1])<<8 | uint32(data[2])<<16
	if payloadLen != uint32(len(data)-4) {
		return false
	}

	// The payload starts at data[4]. Header byte must be 0xFE.
	if data[4] != 0xFE {
		return false
	}

	// For a result-set terminator the OK packet carries zero affected rows
	// and zero last-insert-id, both encoded as single-byte lenenc ints.
	if data[5] != 0x00 || data[6] != 0x00 {
		return false
	}

	// Payload must be at least 7 bytes (header + 2 zeroes + status_flags +
	// warnings) and at most maxOKReplacingEOFPayload. The upper bound rules
	// out text rows with 0xFE lenenc integers, which encode values >= 16 MB
	// and thus produce payloads far exceeding this limit.
	return payloadLen >= 7 && payloadLen <= maxOKReplacingEOFPayload
}

// IsResultSetTerminator checks if a packet terminates a result set row
// stream. When deprecateEOF is false, only legacy EOF packets terminate.
// When deprecateEOF is true, the 0xFE-based OK-replacing-EOF also
// terminates. Because row packets can begin with 0xFE (length-encoded
// integer 8-byte form), OK-replacing-EOF is identified by its packet
// structure (header + zero affected_rows + zero last_insert_id).
func IsResultSetTerminator(data []byte, deprecateEOF bool) bool {
	if IsEOFPacket(data) {
		return true
	}
	if deprecateEOF && IsOKReplacingEOF(data) {
		return true
	}
	return false
}

func IsGenericResponse(data []byte) (string, bool) {
	if IsOKPacket(data) {
		return "OK", true
	}
	if IsERRPacket(data) {
		return "ERR", true
	}
	if IsEOFPacket(data) {
		return "EOF", true
	}
	return "", false
}

func ReadUint24(b []byte) uint32 {
	return uint32(b[0]) | uint32(b[1])<<8 | uint32(b[2])<<16
}

func ReadLengthEncodedString(b []byte) ([]byte, bool, int, error) {
	// Get length
	num, isNull, n := ReadLengthEncodedInteger(b)
	if num < 1 {
		return b[n:n], isNull, n, nil
	}

	n += int(num)

	// Check data length
	if len(b) >= n {
		return b[n-int(num) : n : n], false, n, nil
	}
	return nil, false, n, io.EOF
}

// ReadNullTerminatedString reads a null-terminated string from a byte slice
func ReadNullTerminatedString(b []byte) ([]byte, int, error) {
	i := bytes.IndexByte(b, 0x00)
	if i == -1 {
		return nil, 0, io.EOF
	}
	return b[:i], i + 1, nil
}

func WriteStream(ctx context.Context, logger *zap.Logger, conn net.Conn, buff [][]byte) error {
	for _, b := range buff {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		_, err := conn.Write(b)
		if err != nil {
			utils.LogError(logger, err, "failed to write to connection")
			return err
		}
	}
	return nil
}

func WriteLengthEncodedString(buf *bytes.Buffer, s string) error {
	length := len(s)
	if err := WriteLengthEncodedInteger(buf, uint64(length)); err != nil {
		return err
	}
	if _, err := buf.WriteString(s); err != nil {
		return err
	}
	return nil
}

func WriteLengthEncodedInteger(buf *bytes.Buffer, num uint64) error {
	switch {
	case num <= 250:
		if err := buf.WriteByte(byte(num)); err != nil {
			return err
		}
	case num <= 0xFFFF:
		if err := buf.WriteByte(0xFC); err != nil {
			return err
		}
		if err := binary.Write(buf, binary.LittleEndian, uint16(num)); err != nil {
			return err
		}
	case num <= 0xFFFFFF:
		if err := buf.WriteByte(0xFD); err != nil {
			return err
		}
		num24 := []byte{byte(num), byte(num >> 8), byte(num >> 16)}
		if _, err := buf.Write(num24); err != nil {
			return err
		}
	default:
		if err := buf.WriteByte(0xFE); err != nil {
			return err
		}
		if err := binary.Write(buf, binary.LittleEndian, num); err != nil {
			return err
		}
	}
	return nil
}

func WriteUint24(buf *bytes.Buffer, value uint32) error {
	if value > 0xFFFFFF {
		return errors.New("value exceeds 24 bits")
	}
	buf.WriteByte(byte(value))
	buf.WriteByte(byte(value >> 8))
	buf.WriteByte(byte(value >> 16))
	return nil
}

// Use constants so encoder can key off them.
const (
	ZeroDateString     = "0000-00-00"
	ZeroDateTimeString = "0000-00-00 00:00:00"
	ZeroTimeString     = "00:00:00" // conventional textual form
)

func ParseBinaryDate(b []byte) (interface{}, int, error) {
	if len(b) == 0 {
		return nil, 0, nil
	}
	length := b[0]
	if length == 0 {
		// Non-NULL zero DATE (length byte present, payload length=0)
		return ZeroDateString, 1, nil
	}
	year := binary.LittleEndian.Uint16(b[1:3])
	month := b[3]
	day := b[4]
	return fmt.Sprintf("%04d-%02d-%02d", year, month, day), int(length) + 1, nil
}

func ParseBinaryDateTime(b []byte) (interface{}, int, error) {
	if len(b) == 0 {
		return nil, 0, nil
	}
	l := int(b[0])
	if l == 0 {
		// Non-NULL zero DATETIME/TIMESTAMP
		return ZeroDateTimeString, 1, nil
	}
	// DATETIME valid lengths in MySQL binary row: 4, 7, 11
	if l != 4 && l != 7 && l != 11 {
		return nil, 0, fmt.Errorf("invalid DATETIME length %d (expected 0|4|7|11) - likely misaligned buffer", l)
	}
	if len(b) < 1+l {
		return nil, 0, fmt.Errorf("unexpected end of buffer while reading DATETIME value , len(b)=%d, expected at least %d", len(b), 1+l)
	}

	p := b[1:] // start of payload after length
	year := int(binary.LittleEndian.Uint16(p[0:2]))
	month := int(p[2])
	day := int(p[3])

	switch l {
	case 4:
		// YYYY-MM-DD
		return fmt.Sprintf("%04d-%02d-%02d", year, month, day), 1 + l, nil
	case 7:
		hour := int(p[4])
		minute := int(p[5])
		second := int(p[6])
		// Basic sanity guard helps catch misalignment early
		if !validYMDHMS(year, month, day, hour, minute, second) {
			return nil, 0, fmt.Errorf("invalid DATETIME %04d-%02d-%02d %02d:%02d:%02d (misaligned?)",
				year, month, day, hour, minute, second)
		}
		return fmt.Sprintf("%04d-%02d-%02d %02d:%02d:%02d",
			year, month, day, hour, minute, second), 1 + l, nil
	case 11:
		hour := int(p[4])
		minute := int(p[5])
		second := int(p[6])
		us := binary.LittleEndian.Uint32(p[7:11])
		if !validYMDHMS(year, month, day, hour, minute, second) {
			return nil, 0, fmt.Errorf("invalid DATETIME %04d-%02d-%02d %02d:%02d:%02d.%06d (misaligned?)",
				year, month, day, hour, minute, second, us)
		}
		return fmt.Sprintf("%04d-%02d-%02d %02d:%02d:%02d.%06d",
			year, month, day, hour, minute, second, us), 1 + l, nil
	}
	panic(fmt.Sprintf("unreachable code reached in ParseBinaryDateTime: unexpected length l=%d", l))
}

func validYMDHMS(y, m, d, hh, mm, ss int) bool {
	return y >= 1 && y <= 9999 &&
		m >= 1 && m <= 12 &&
		d >= 1 && d <= 31 && // fine for a quick guard; deeper month/day checks optional
		hh >= 0 && hh <= 23 &&
		mm >= 0 && mm <= 59 &&
		ss >= 0 && ss <= 59
}

func ParseBinaryTime(b []byte) (interface{}, int, error) {
	if len(b) == 0 {
		return nil, 0, nil
	}
	length := b[0]
	if length == 0 {
		// Non-NULL zero TIME
		return ZeroTimeString, 1, nil
	}
	isNegative := b[1] == 1
	days := binary.LittleEndian.Uint32(b[2:6])
	hours := b[6]
	minutes := b[7]
	seconds := b[8]
	var microseconds uint32
	if length > 8 {
		microseconds = binary.LittleEndian.Uint32(b[9:13])
	}
	timeString := fmt.Sprintf("%d %02d:%02d:%02d.%06d", days, hours, minutes, seconds, microseconds)
	if isNegative {
		timeString = "-" + timeString
	}
	return timeString, int(length) + 1, nil
}
