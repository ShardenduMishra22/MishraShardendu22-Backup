package proxy

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"net"
	"os"
	"strings"
	"time"

	"go.keploy.io/server/v3/pkg/agent/proxy/directive"
	"go.keploy.io/server/v3/pkg/agent/proxy/fakeconn"
	"go.keploy.io/server/v3/pkg/agent/proxy/integrations"
	"go.keploy.io/server/v3/pkg/agent/proxy/relay"
	"go.keploy.io/server/v3/pkg/agent/proxy/supervisor"
	pTls "go.keploy.io/server/v3/pkg/agent/proxy/tls"
	"go.keploy.io/server/v3/pkg/agent/proxy/util"
	"go.keploy.io/server/v3/pkg/models"
	"go.uber.org/zap"
	"golang.org/x/sync/errgroup"
)

// newRelayDisabled reports whether the new supervisor+relay architecture
// is disabled via environment. Set KEPLOY_NEW_RELAY to 0/false/off/no to
// force the legacy path even for parsers that implement IntegrationsV2.
// Any other value (or unset) enables the new path.
func newRelayDisabled() bool {
	v := strings.ToLower(strings.TrimSpace(os.Getenv("KEPLOY_NEW_RELAY")))
	return v == "0" || v == "false" || v == "off" || v == "no"
}

// recordViaSupervisor runs a V2-capable parser's RecordOutgoing inside
// the new supervisor + relay architecture.
//
// Responsibilities:
//
//  1. Stand up a Relay that owns srcConn and dstConn as sole writer; tees
//     timestamped Chunks into a pair of FakeConns.
//  2. Stand up a Supervisor that wraps the parser call with a panic
//     firewall, an activity-based hang watchdog, and a per-connection
//     memory cap.
//  3. Build a supervisor.Session exposing the FakeConns, directive
//     channels, and legacy fields; attach the Session to RecordSession.V2
//     so the parser receives both surfaces through its existing
//     RecordOutgoing signature.
//  4. Invoke sv.Run; on a FallthroughToPassthrough result, drop the
//     parser and keep the existing relay forwarding raw bytes on the
//     real sockets until peer close so user traffic continues
//     regardless of the parser's fate. (Critically we do NOT call
//     globalPassThrough here: that would create a gap between the
//     relay stopping and a replacement read loop starting — exactly
//     the kind of stall the V2 architecture is meant to eliminate.
//     See invariant I1 in pkg/agent/proxy/README.md.)
//
// The caller remains responsible for closing srcConn/dstConn in its
// deferred cleanup; this helper never closes them.
func (p *Proxy) recordViaSupervisor(
	ctx context.Context,
	srcConn, dstConn net.Conn,
	parser integrations.Integrations,
	parserType integrations.IntegrationType,
	mocks chan<- *models.Mock,
	errGrp *errgroup.Group,
	logger *zap.Logger,
	clientConnID, destConnID int64,
	opts models.OutgoingOptions,
) error {
	sv := supervisor.New(supervisor.Config{
		Logger: logger,
		// Leave HangBudget / MemCap / PanicReporter defaulted by the
		// supervisor package. Tune via config once we have production
		// telemetry on the fallback rate.
	})
	defer sv.Close()

	// Parser-facing session is constructed before the relay so its
	// MarkMockIncomplete / ClearPendingWork hooks can be wired into
	// the relay's tee callbacks below. ClientStream/DestStream and
	// the directive channels are patched in after r := relay.New().
	// Ctx is overwritten by Supervisor.Run with the supervised
	// lifetime context.
	svSess := &supervisor.Session{
		Mocks:            mocks,
		Logger:           logger,
		ClientConnID:     fmt.Sprint(clientConnID),
		DestConnID:       fmt.Sprint(destConnID),
		Opts:             opts,
		OnPendingCleared: sv.ClearPendingWork,
		// Route EmitMock through the SyncMockManager (obtained via
		// syncMock.Get(), then mgr.AddMock) so V2 parsers pick up the
		// same firstReqSeen session-window buffering, lifetime
		// derivation, and drop accounting that legacy parsers (http,
		// mysql, generic) get. Without this, V2-recorded mocks
		// captured before the first app test request bypass the
		// session window and are lost at replay — the symptom that
		// broke postgres e2e record-build-replay-build runs in
		// integrations#133 (the app's startup DB queries never found
		// their mocks).
		RouteMocksViaSyncMock: true,
		// Legacy fields kept populated so a migrated parser can still
		// consult them for fields we haven't promoted yet. The parser
		// must not touch Ingress/Egress net.Conn values on the V2 path.
		TLSUpgrader: nil,
		ErrGroup:    errGrp,
	}

	// Build the relay. It owns srcConn/dstConn for the duration of its
	// Run call but never closes them. The caller's deferred Close still
	// runs on handleConnection return.
	//
	// OnMarkMockIncomplete wires the relay's drop signals (memoryguard
	// pressure / per-conn cap / channel full / write error / short
	// write / KindAbortMock directive) to the session's incomplete
	// flag so EmitMock drops any mock whose underlying tee chunks were
	// lost. Without this wiring partial mocks could still ship despite
	// the documented invariant I4 in PLAN.md.
	//
	// OnClientChunkTeed wires the relay's per-chunk "client bytes
	// delivered to parser" signal to the supervisor's pending-work
	// flag so the activity watchdog can distinguish an idle
	// connection (no pending requests) from a parser that received
	// bytes but isn't emitting a mock (hang candidate). EmitMock's
	// OnPendingCleared clears the flag after each successful emit.
	// Opt-in pre-dispatch pause: parsers that need to deterministically
	// observe the first chunk on a connection before any byte reaches
	// the real peer implement the WantsPreDispatchPause capability.
	// Today only postgres v3 sets this (to close the SSL preamble
	// race; see keploy/enterprise#2012). Most parsers don't need it
	// and would deadlock if their first action wasn't a ResumePreDispatch
	// directive — so we ONLY engage pre-dispatch when the parser
	// explicitly asks for it via this opt-in.
	//
	// Duck-typed instead of extending the IntegrationsV2 interface so
	// each parser stays free to add the method independently and we
	// don't have to touch every IntegrationsV2 implementation in this
	// change.
	var preDispatchPause bool
	if pp, ok := parser.(interface{ WantsPreDispatchPause() bool }); ok {
		preDispatchPause = pp.WantsPreDispatchPause()
	}

	// RealCertHook wires the V2-relay upstream-TLS chokepoint into
	// the cbshim. The post-handshake upgradeDstConn carries the real
	// upstream cert; we publish (connID = source-port-as-string,
	// realDER, sigAlgo) so cbshim can pair it with the MITM cert from
	// CertForClient. Nil-safe: p.cbshim is nil when BPF cbshim
	// failed to load, in which case the relay just skips publishing.
	var realCertHook func(connID string, realDER []byte, sigAlgo x509.SignatureAlgorithm)
	if p.cbshim != nil {
		realCertHook = p.cbshim.RegisterReal
	}

	r := relay.New(relay.Config{
		Logger:               logger,
		TLSUpgradeFn:         newProxyTLSUpgradeFn(logger),
		BumpActivity:         sv.BumpActivity,
		OnMarkMockIncomplete: svSess.MarkMockIncomplete,
		OnClientChunkTeed:    sv.MarkPendingWork,
		RealCertHook:         realCertHook,
		// User-tunable record-buffer caps. Snapshotted onto the Proxy
		// at startup from config.Record.RecordBuffer (yaml/flag/env).
		// Zero values fall through to relay package defaults via
		// withDefaults() — preserving the zero-config path.
		PerConnCap:       p.recordBufferCap,
		TeeChanBuf:       p.recordBufferQueueSize,
		PreDispatchPause: preDispatchPause,
	}, srcConn, dstConn)

	svSess.ClientStream = r.ClientStream()
	svSess.DestStream = r.DestStream()
	svSess.Directives = r.Directives()
	svSess.Acks = r.Acks()

	// Run the relay in its own goroutine under the supervisor's lifetime.
	// The supervisor's Close (via sv.SessionOnAbort below) closes the
	// FakeConns so the parser's reads unblock on abort.
	relayDone := make(chan error, 1)
	relayCtx, relayCancel := context.WithCancel(ctx)
	defer relayCancel()
	go func() { relayDone <- r.Run(relayCtx) }()

	sv.SessionOnAbort = func() {
		// Pause the tees FIRST so every subsequent chunk drops
		// cheaply via the pause fast-path (atomic-bool check) instead
		// of falling through to the channel-full DropChannelFull
		// branch, which also logs at Debug. On a long-lived
		// post-abort connection the spam would otherwise be one
		// log line per chunk for the rest of the connection.
		//
		// Pausing does NOT stop the real-socket forwarders — every
		// byte still reaches its peer. The relay's raw forwarding
		// continues until peer close; only parser-side delivery is
		// suppressed.
		r.PauseTees()

		// Then unblock the parser's ClientStream/DestStream reads so
		// the supervisor's cancel-select can observe the parser
		// goroutine exiting promptly.
		_ = r.ClientStream().Close()
		_ = r.DestStream().Close()
	}

	// Adapter: the parser's RecordOutgoing takes *integrations.RecordSession
	// but the supervisor's ParserFunc takes *supervisor.Session. Build a
	// RecordSession whose V2 field points at the supervisor.Session.
	//
	// On the V2 path, Ingress/Egress/TLSUpgrader are intentionally nil so
	// that a parser bug that reaches for the legacy fields surfaces as an
	// obvious nil panic (which the supervisor catches) rather than a
	// silent misuse of sockets the relay owns. ErrGroup remains populated
	// because the legacy integration helper layer (ReadBytes, etc.) still
	// retrieves it via context.Value in shared code; once every parser
	// migrates off that accessor the field will be set to nil here as
	// well.
	result := sv.Run(ctx, func(parserCtx context.Context, sv2sess *supervisor.Session) error {
		recSess := &integrations.RecordSession{
			Ingress:      nil,
			Egress:       nil,
			Mocks:        mocks,
			ErrGroup:     errGrp,
			TLSUpgrader:  nil,
			Logger:       logger,
			ClientConnID: fmt.Sprint(clientConnID),
			DestConnID:   fmt.Sprint(destConnID),
			Opts:         opts,
			V2:           sv2sess,
		}
		return parser.RecordOutgoing(parserCtx, recSess)
	}, svSess)

	if result.FallthroughToPassthrough {
		logger.Debug("parser supervisor triggered passthrough fallback; relay continues raw forwarding until peer close",
			zap.String("parser", string(parserType)),
			zap.String("status", result.Status.String()),
			zap.Error(result.Err),
			zap.String("next_step", "set KEPLOY_NEW_RELAY=off to force legacy path for this parser, or KEPLOY_DISABLE_PARSING=1 to disable record parsing entirely"),
		)
		// Crucial invariant (I1): the relay keeps forwarding client↔dest
		// bytes end-to-end during the fallback. We do NOT cancel it here
		// — cancelling would introduce a gap between the relay stopping
		// and any replacement read loop starting, exactly the kind of
		// stall the V2 architecture is meant to eliminate.
		//
		// SessionOnAbort has already closed the FakeConns so no further
		// tee chunks reach the parser side (no partial mocks, I4). The
		// relay's forwarder goroutines continue draining srcConn/dstConn
		// until either peer closes the connection, which triggers a
		// normal Run exit.
		<-relayDone
		return nil
	}

	// Non-fallthrough path: parser returned normally or with an error.
	// Cancel the relay and drain.
	relayCancel()
	relayErr := <-relayDone
	if relayErr != nil && !errors.Is(relayErr, context.Canceled) {
		logger.Debug("relay exited with error", zap.Error(relayErr))
	}

	if result.Err != nil {
		if isNetworkClosedErr(result.Err) {
			logger.Debug("V2 parser exited with network-closed error", zap.Error(result.Err))
			return nil
		}
		return result.Err
	}
	logger.Debug("V2 parser recorded outgoing message successfully",
		zap.String("parser", string(parserType)),
		zap.String("status", result.Status.String()),
	)
	return nil
}

// newProxyTLSUpgradeFn adapts keploy's existing TLS helpers into the
// relay.TLSUpgradeFn shape. The returned function:
//
//   - For isClient=true (upgrading the destination side — keploy
//     acts as TLS client to the real server), dials TLS over the
//     existing conn using tls.Client and performs the handshake.
//     Upstream cert verification is ALWAYS skipped here — see the
//     dest-side InsecureSkipVerify rationale on the cfg clone below.
//   - For isClient=false (upgrading the client side — keploy acts
//     as TLS server presenting the MITM cert), hands off to
//     pTls.HandleTLSConnection which already implements the server-
//     side handshake used elsewhere in the proxy.
//
// The conn pointer update (so the forwarders switch to the upgraded
// conn on subsequent iterations) is the relay's responsibility; this
// fn only performs the handshake and returns the new net.Conn —
// hence it does not need the caller's *net.Conn handles.
func newProxyTLSUpgradeFn(logger *zap.Logger) relay.TLSUpgradeFn {
	return func(ctx context.Context, conn net.Conn, isClient bool, cfg *tls.Config) (net.Conn, error) {
		if cfg == nil {
			return conn, nil
		}
		if isClient {
			// Upstream identity verification is keploy's responsibility
			// to NOT do. Keploy is a transparent MITM record/replay
			// proxy: the real client (pgx, asyncpg, libpq, JDBC, mongo
			// driver, etc.) already made its trust decision against
			// keploy's minted cert when it dialed in, and the upstream
			// it points at in record mode is whatever the application
			// would have dialed itself — typically a self-signed dev /
			// CI / staging Postgres or Mongo, or a Kubernetes service
			// reachable only by ClusterIP. Either way the upstream
			// cert's SAN/CN often does not match the IP literal keploy
			// sees in `Destination Address` (e.g. cert valid for
			// 127.0.0.1, dial target 10.224.0.152), and Go's default
			// hostname/IP verification would surface that as
			// `dest TLS handshake failed: x509: certificate is valid
			// for X, not Y` and trip the parser supervisor's
			// passthrough fallback — silently dropping all recording
			// for that connection.
			//
			// Parsers that build their DestTLSConfig already set
			// InsecureSkipVerify on it (see e.g.
			// integrations/pkg/postgres/v3/recorder.buildDestTLSConfigV2,
			// keploy/pkg/agent/proxy/integrations/mysql/recorder.buildDestTLSConfigV2)
			// — but if a parser ever forgets, or if some future call
			// site lands here with a strict config, we still need the
			// MITM-correct posture. So clone the parser's cfg, force
			// InsecureSkipVerify=true on the clone, and dial against
			// that. ServerName / RootCAs / NextProtos / ClientCert
			// material on the parser-supplied cfg is preserved
			// (shallow clone via tls.Config.Clone), so SNI for
			// vhosted PG-as-a-service providers (RDS, Cloud SQL, Neon)
			// and any upstream-mTLS material a parser might wire in
			// still reaches the wire.
			dialCfg := cfg.Clone()
			dialCfg.InsecureSkipVerify = true //#nosec G402 -- MITM record-time proxy: keploy intentionally never validates the upstream cert. See the docstring above.
			tlsConn := tls.Client(conn, dialCfg)
			if err := tlsConn.HandshakeContext(ctx); err != nil {
				return nil, fmt.Errorf("dest TLS handshake failed: %w", err)
			}
			return tlsConn, nil
		}
		// Server side: reuse the existing proxy TLS server plumbing.
		// HandleTLSConnection performs the TLS handshake presenting
		// keploy's MITM cert chain. It returns the TLS-wrapped conn
		// which we use for subsequent plaintext forwarding. The
		// backdate argument is left zero; the helper clamps it to
		// "now" internally.
		wrapped, _, err := pTls.HandleTLSConnection(ctx, logger, conn, time.Time{})
		if err != nil {
			return nil, fmt.Errorf("client TLS handshake failed: %w", err)
		}
		return wrapped, nil
	}
}

// Compile-time sanity: ensure the dispatcher-side V2 call site can be
// resolved. This guards against the package moving out from under us.
var _ = fakeconn.FromClient
var _ directive.Kind = directive.KindUpgradeTLS
var _ = util.DefaultKillSwitch

// waitForConnDrain blocks until either every in-flight
// handleConnection goroutine has returned or ctx is done (typically
// a 5-second shutdown grace). Called from StopProxyServer after the
// listener is closed and the kill switch is tripped.
//
// Implementation: each handleConnection invocation calls
// activeConns.Add(1)/Done(), so a single Wait() drains the whole
// active set. We can't wait on a WaitGroup with a deadline
// directly, so a sentinel goroutine closes a done channel when Wait
// returns and we select on that vs ctx. After ctx-done we leave the
// remaining goroutines to exit via the parent ctx cancellation they
// already inherited (their deferred srcConn/dstConn closes fire on
// their own return).
func (p *Proxy) waitForConnDrain(ctx context.Context) {
	done := make(chan struct{})
	go func() {
		p.activeConns.Wait()
		close(done)
	}()
	select {
	case <-done:
		return
	case <-ctx.Done():
		p.logger.Debug("shutdown drain grace expired; remaining connections will exit via ctx cancellation")
		return
	}
}
