package conn

import (
	"bytes"
	"context"
	"encoding/base64"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"sync/atomic"

	"go.keploy.io/server/v3/pkg"
	"go.keploy.io/server/v3/pkg/agent/memoryguard"
	syncMock "go.keploy.io/server/v3/pkg/agent/proxy/syncMock"
	"go.keploy.io/server/v3/pkg/models"
	"go.keploy.io/server/v3/utils"
	"go.uber.org/zap"
)

var GlobalTestCounter int64

// mapping (last bool before appPort) controls whether the synchronous
// branch tells SyncMockManager.ResolveRange to emit a TestMockMapping
// entry onto the agent's mappingChan. Mirrors !cfg.DisableMapping —
// before this parameter existed the OSS call site hardcoded false, so
// mappings.yaml production during record was silently a no-op (#3905).
type CaptureFunc func(ctx context.Context, logger *zap.Logger, t chan *models.TestCase, req *http.Request, resp *http.Response, reqTimeTest time.Time, resTimeTest time.Time, opts models.IncomingOptions, synchronous bool, mapping bool, appPort uint16)

var CaptureHook CaptureFunc = Capture

// MaxTestCaseSize is the maximum combined size of HTTP/gRPC request and response (5MB)
const MaxTestCaseSize = 5 * 1024 * 1024 // 5 MB

// LargeBodyThreshold is the size threshold (1MB) above which response bodies
// are skipped during recording and only body size is stored.
const LargeBodyThreshold = 1 * 1024 * 1024 // 1 MB

func Capture(ctx context.Context, logger *zap.Logger, t chan *models.TestCase, req *http.Request, resp *http.Response, reqTimeTest time.Time, resTimeTest time.Time, opts models.IncomingOptions, synchronous bool, mapping bool, appPort uint16) {
	if memoryguard.IsRecordingPaused() {
		// Close bodies even when skipping capture to avoid resource leaks.
		if req.Body != nil {
			req.Body.Close()
		}
		if resp.Body != nil {
			resp.Body.Close()
		}
		return
	}

	var reqBody []byte
	if req.Body != nil { // Read
		var err error
		reqBody, err = io.ReadAll(req.Body)
		if err != nil {
			logger.Debug("failed to read the http request body", zap.Any("metadata", utils.GetReqMeta(req)), zap.Int64("of size", int64(len(reqBody))), zap.String("body", base64.StdEncoding.EncodeToString(reqBody)), zap.Error(err))
		}

		if req.Header.Get("Content-Encoding") != "" {
			reqBody, err = pkg.Decompress(logger, req.Header.Get("Content-Encoding"), reqBody)
			if err != nil {
				utils.LogError(logger, err, "failed to decode the http request body", zap.Any("metadata", utils.GetReqMeta(req)))
				return
			}
		}
	}

	defer func() {
		err := resp.Body.Close()
		if err != nil {
			utils.LogError(logger, err, "failed to close the http response body")
		}
	}()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		utils.LogError(logger, err, "failed to read the http response body")
		return
	}

	if IsFiltered(logger, req, opts) {
		logger.Debug("The request is a filtered request")
		return
	}
	var formData []models.FormData
	if contentType := req.Header.Get("Content-Type"); strings.HasPrefix(contentType, "multipart/form-data") {
		parts := strings.Split(contentType, ";")
		if len(parts) > 1 {
			req.Header.Set("Content-Type", strings.TrimSpace(parts[0]))
		}
		formData = ExtractFormData(logger, reqBody, contentType)
		reqBody = []byte{}
	} else if contentType := req.Header.Get("Content-Type"); contentType == "application/x-www-form-urlencoded" {
		decodedBody, err := url.QueryUnescape(string(reqBody))
		if err != nil {
			utils.LogError(logger, err, "failed to decode the url-encoded request body")
			return
		}
		reqBody = []byte(decodedBody)
	}

	if resp.Header.Get("Content-Encoding") != "" {
		respBody, err = pkg.Decompress(logger, resp.Header.Get("Content-Encoding"), respBody)
		if err != nil {
			utils.LogError(logger, err, "failed to decompress the response body")
			return
		}
	}

	// Check if combined request and response size exceeds 5MB limit (after decompression)
	totalSize := len(reqBody) + len(respBody)
	if totalSize > MaxTestCaseSize {
		logger.Error("HTTP test case data exceeds 5MB limit, skipping capture",
			zap.Int("totalSize", totalSize),
			zap.Int("reqBodySize", len(reqBody)),
			zap.Int("respBodySize", len(respBody)),
			zap.String("url", req.URL.String()),
			zap.String("method", req.Method))
		return
	}

	// If response body exceeds 1MB, mark it as skipped and store only the size
	var respBodySkipped bool
	var respBodySize int64
	if len(respBody) > LargeBodyThreshold {
		respBodySkipped = true
		respBodySize = int64(len(respBody))
		logger.Debug("response body exceeds 1MB during recording, storing only body size",
			zap.Int64("body_size_bytes", respBodySize),
			zap.String("url", req.URL.String()),
			zap.String("method", req.Method))
		respBody = []byte{} // clear the body — only size is stored
	}

	hasBinaryFile := false
	for _, fd := range formData {
		if len(fd.Paths) > 0 {
			hasBinaryFile = true
			logger.Debug("Detected binary file in request form data", zap.String("key", fd.Key), zap.Strings("paths", fd.Paths))
			break
		}
	}

	testCase := &models.TestCase{
		Version:       models.GetVersion(),
		Name:          pkg.ToYamlHTTPHeader(req.Header)["Keploy-Test-Name"],
		Kind:          models.HTTP,
		Created:       time.Now().Unix(),
		HasBinaryFile: hasBinaryFile,
		HTTPReq: models.HTTPReq{
			Method:     models.Method(req.Method),
			ProtoMajor: req.ProtoMajor,
			ProtoMinor: req.ProtoMinor,
			URL:        fmt.Sprintf("http://%s%s", req.Host, req.URL.RequestURI()),
			Form:       formData,
			Header:     pkg.ToYamlHTTPHeader(req.Header),
			Body:       string(reqBody),
			URLParams:  pkg.URLParams(req),
			Timestamp:  reqTimeTest,
		},
		HTTPResp: models.HTTPResp{
			StatusCode:    resp.StatusCode,
			Header:        pkg.ToYamlHTTPHeader(resp.Header),
			Body:          string(respBody),
			BodySkipped:   respBodySkipped,
			BodySize:      respBodySize,
			Timestamp:     resTimeTest,
			StatusMessage: http.StatusText(resp.StatusCode),
		},
		Noise:   map[string][]string{},
		AppPort: appPort,
		// Mocks: mocks,
	}

	if synchronous {
		currentID := atomic.AddInt64(&GlobalTestCounter, 1)
		testName := fmt.Sprintf("test-%d", currentID)
		testCase.Name = testName
		// Pass testName (the locally-synthesised "test-N" identifier),
		// not testCase.Name. CodeQL flow analysis treats testCase as
		// HTTP-sourced and any read from its fields as potentially
		// sensitive — even though we just wrote a synthetic ID into
		// .Name a line earlier. Forwarding the local string severs
		// the taint flow and stops the go/clear-text-logging false
		// positives that fire downstream (syncMock.go diag/Info
		// logs include test_name for ResolveRange traceability).
		if mgr := syncMock.Get(); mgr != nil { // dumping the test case from mock manager in synchronous mode
			mgr.ResolveRange(reqTimeTest, resTimeTest, testName, true, mapping)
		}
	}
	select {
	case <-ctx.Done():
		return
	case t <- testCase:
		// Successfully sent test case
	}
}
func IsFiltered(logger *zap.Logger, req *http.Request, opts models.IncomingOptions) bool {
	dstPort := 0
	var err error
	if p := req.URL.Port(); p != "" {
		dstPort, err = strconv.Atoi(p)
		if err != nil {
			utils.LogError(logger, err, "failed to obtain destination port from request")
			return false
		}
	}

	hasInclude := false
	matchedInclude := false

	type cond struct {
		eligible bool
		match    bool
	}

	for _, filter := range opts.Filters {

		//  1. bypass rule
		bypassEligible := !(filter.BypassRule.Host == "" &&
			filter.BypassRule.Path == "" &&
			filter.BypassRule.Port == 0)

		outgoingOpts := models.OutgoingOptions{Rules: []models.BypassRule{filter.BypassRule}}
		byPassMatch := utils.IsPassThrough(logger, req, uint(dstPort), outgoingOpts)

		//  2. URL-method rule
		urlMethodEligible := len(filter.URLMethods) > 0
		urlMethodMatch := false
		if urlMethodEligible {
			for _, m := range filter.URLMethods {
				if m == req.Method {
					urlMethodMatch = true
					break
				}
			}
		}

		//  3. header rule
		headerEligible := len(filter.Headers) > 0
		headerMatch := false
		if headerEligible {
			for key, vals := range filter.Headers {
				rx, err := regexp.Compile(vals)
				if err != nil {
					utils.LogError(logger, err, "bad header regex")
					continue
				}
				for _, v := range req.Header.Values(key) {
					if rx.MatchString(v) {
						headerMatch = true
						break
					}
				}
				if headerMatch {
					break
				}
			}
		}

		conds := []cond{
			{bypassEligible, byPassMatch},
			{urlMethodEligible, urlMethodMatch},
			{headerEligible, headerMatch},
		}

		isMatch := false
		switch filter.MatchType {
		case models.AND:
			pass := true
			seen := false
			for _, c := range conds {
				if !c.eligible {
					continue
				} // ignore ineligible ones
				seen = true
				if !c.match {
					pass = false
					break
				}
			}
			if seen && pass {
				isMatch = true
			}

		case models.OR:
			fallthrough
		default:
			for _, c := range conds {
				if c.eligible && c.match {
					isMatch = true
					break
				}
			}
		}

		if filter.FilterPolicy == models.Include {
			hasInclude = true
			if isMatch {
				matchedInclude = true
			}
		} else { // Exclude (default)
			if isMatch {
				return true // Exclude ALWAYS takes priority
			}
		}
	}

	if hasInclude && !matchedInclude {
		return true
	}

	return false
}

func ExtractFormData(logger *zap.Logger, body []byte, contentType string) []models.FormData {
	boundary := ""
	if strings.HasPrefix(contentType, "multipart/form-data") {
		parts := strings.Split(contentType, "boundary=")
		if len(parts) > 1 {
			boundary = strings.TrimSpace(parts[1])
		} else {
			utils.LogError(logger, nil, "Invalid multipart/form-data content type")
			return nil
		}
	}
	reader := multipart.NewReader(bytes.NewReader(body), boundary)
	var formData []models.FormData

	for {
		part, err := reader.NextPart()
		if err == io.EOF {
			break
		}
		if err != nil {
			utils.LogError(logger, err, "Error reading part")
			continue
		}
		key := part.FormName()
		if key == "" {
			continue
		}

		fileName := part.FileName()
		var fileNames []string
		var values []string
		var paths []string

		if fileName != "" {
			file, err := os.CreateTemp("", "keploy-multipart-*.bin")
			if err != nil {
				utils.LogError(logger, err, "Error creating temp file")
				continue
			}
			tempPath := file.Name()
			_, err = io.Copy(file, part)
			if err != nil {
				utils.LogError(logger, err, "Error copying part to temp file")
				if cerr := file.Close(); cerr != nil {
					utils.LogError(logger, cerr, "Error closing temp file")
				}
				if rerr := os.Remove(tempPath); rerr != nil {
					utils.LogError(logger, rerr, "Error removing temp file", zap.String("path", tempPath))
				}
				continue
			}
			if err := file.Close(); err != nil {
				utils.LogError(logger, err, "Error closing temp file")
				if rerr := os.Remove(tempPath); rerr != nil {
					utils.LogError(logger, rerr, "Error removing temp file", zap.String("path", tempPath))
				}
				continue
			}

			paths = append(paths, tempPath)
			fileNames = append(fileNames, fileName)
		} else {

			value, err := io.ReadAll(part)
			if err != nil {
				utils.LogError(logger, err, "Error reading part value")
				continue
			}
			values = append(values, string(value))
		}

		formData = append(formData, models.FormData{
			Key:       key,
			Values:    values,
			FileNames: fileNames,
			Paths:     paths,
		})
	}

	return formData
}

// CaptureGRPC captures a gRPC request/response pair and sends it to the test case channel
func CaptureGRPC(ctx context.Context, logger *zap.Logger, t chan *models.TestCase, http2Stream *pkg.HTTP2Stream, appPort uint16) {
	if memoryguard.IsRecordingPaused() {
		return
	}

	if http2Stream == nil {
		logger.Error("Stream is nil")
		return
	}

	if http2Stream.GRPCReq == nil || http2Stream.GRPCResp == nil {
		logger.Error("gRPC request or response is nil")
		return
	}

	// Create test case from stream data
	testCase := &models.TestCase{
		Version:  models.GetVersion(),
		Name:     http2Stream.GRPCReq.Headers.OrdinaryHeaders["Keploy-Test-Name"],
		Kind:     models.GRPC_EXPORT,
		Created:  time.Now().Unix(),
		GrpcReq:  *http2Stream.GRPCReq,
		GrpcResp: *http2Stream.GRPCResp,
		Noise:    map[string][]string{},
		AppPort:  appPort,
	}

	select {
	case <-ctx.Done():
		return
	case t <- testCase:
		logger.Debug("Captured gRPC test case",
			zap.String("path", http2Stream.GRPCReq.Headers.PseudoHeaders[":path"]))
	}
}
