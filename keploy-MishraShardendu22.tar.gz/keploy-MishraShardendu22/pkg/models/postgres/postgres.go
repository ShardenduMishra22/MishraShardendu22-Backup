package postgres

import (
	"time"

	"gopkg.in/yaml.v3"
)

type Spec struct {
	Metadata         map[string]string `json:"metadata" yaml:"metadata"`
	Requests         []RequestYaml     `json:"requests" yaml:"requests"`
	Response         []ResponseYaml    `json:"responses" yaml:"responses"`
	CreatedAt        int64             `json:"created" yaml:"created,omitempty"`
	ReqTimestampMock time.Time         `json:"reqTimestampMock,omitempty"`
	ResTimestampMock time.Time         `json:"resTimestampMock,omitempty"`
}

type RequestYaml struct {
	Meta    map[string]string `json:"meta,omitempty" yaml:"meta,omitempty"`
	Message yaml.Node         `json:"message,omitempty" yaml:"message"`
}

type ResponseYaml struct {
	Meta    map[string]string `json:"meta,omitempty" yaml:"meta,omitempty"`
	Message yaml.Node         `json:"message,omitempty" yaml:"message"`
}

type PacketInfo struct {
	Header *Header `json:"header" yaml:"header"`
	Type   string  `json:"packet_type" yaml:"packet_type"`
}

type Request struct {
	PacketBundle `json:"packet_bundle" yaml:"packet_bundle"`
}

type Response struct {
	PacketBundle `json:"packet_bundle" yaml:"packet_bundle"`
	Payload      string `json:"payload,omitempty" yaml:"payload,omitempty"`
}

type PacketBundle struct {
	Packets []Packet `json:"packets" yaml:"packets"`
}

type Packet struct {
	Header  *PacketInfo       `json:"header" yaml:"header"`
	Message interface{}       `json:"message" yaml:"message"`
	Meta    map[string]string `json:"meta,omitempty" yaml:"meta,omitempty"`
}

type Header struct {
	PayloadLength uint32 `json:"payload_length" yaml:"payload_length"`
	PacketID      string `json:"packet_id" yaml:"packet_id"`
}
