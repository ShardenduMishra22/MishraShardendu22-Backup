// Package models provides data models for the keploy.
package models

type TestSet struct {
	PreScript  string                 `json:"pre_script" bson:"pre_script" yaml:"preScript"`
	PostScript string                 `json:"post_script" bson:"post_script" yaml:"postScript"`
	AppCommand string                 `json:"app_command" bson:"app_command" yaml:"appCommand"`
	Template   map[string]interface{} `json:"template" bson:"template" yaml:"template"`
	Secret     map[string]interface{} `json:"secret" bson:"secret" yaml:"secret,omitempty"`
	Metadata   map[string]interface{} `json:"metadata" bson:"metadata" yaml:"metadata"`
}

// Secret interface for types that support secret configuration.
type Secret interface {
	SetSecrets(secrets map[string]interface{})
}

func (ts *TestSet) SetSecrets(secrets map[string]interface{}) {
	ts.Secret = secrets
}

func (ts *TestSet) WithoutSecrets() *TestSet {
	if ts == nil {
		return &TestSet{}
	}

	testSetCopy := *ts
	testSetCopy.Secret = nil
	return &testSetCopy
}

type Plan struct {
	Type   string `json:"type"`
	Status string `json:"status"`
	KUnits int    `json:"kunits,omitempty"`
}
