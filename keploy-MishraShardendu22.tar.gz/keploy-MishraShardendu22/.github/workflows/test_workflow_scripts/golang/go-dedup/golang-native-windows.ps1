﻿<#
  PowerShell test runner for Keploy (Windows) - go-dedup sample
  - Synchronous (PID-controlled) record phase; no background jobs
  - Cleans keploy dirs/files up-front
  - Generates keploy.yml and adds noise filter for current_time
  - Sends a fixed set of HTTP calls to generate tests
  - Kills entire process tree (keploy + docker compose) to avoid hangs
  - Runs replay and validates the report
#>

$ErrorActionPreference = 'Stop'

# --- Resolve Keploy binaries (defaults for local dev) ---
$defaultKeploy = if ($env:GITHUB_WORKSPACE) { Join-Path $env:GITHUB_WORKSPACE 'bin\keploy.exe' } else { '.\keploy.exe' }
if (-not $env:RECORD_BIN) { $env:RECORD_BIN = $defaultKeploy }
if (-not $env:REPLAY_BIN) { $env:REPLAY_BIN = $defaultKeploy }

# Ensure USERPROFILE (needed for docker volume mounts inside keploy)
if (-not $env:USERPROFILE -or $env:USERPROFILE -eq '') {
  $candidate = "$env:HOMEDRIVE$env:HOMEPATH"
  if ($candidate -and $candidate -ne '') { $env:USERPROFILE = $candidate }
}

# Create Keploy config/home so docker doesn’t fall back to NetworkService
try {
  if ($env:USERPROFILE -and $env:USERPROFILE -ne '') {
    $keployCfg = Join-Path $env:USERPROFILE ".keploy-config"
    $keployHome = Join-Path $env:USERPROFILE ".keploy"
    New-Item -ItemType Directory -Path $keployCfg -Force -ErrorAction SilentlyContinue | Out-Null
    New-Item -ItemType Directory -Path $keployHome -Force -ErrorAction SilentlyContinue | Out-Null
  }
} catch {}

# Parameterize the application's base URL
$env:APP_BASE_URL = if ($env:APP_BASE_URL) { $env:APP_BASE_URL } else { 'http://localhost:8080' }

Write-Host "Using RECORD_BIN = $env:RECORD_BIN"
Write-Host "Using REPLAY_BIN = $env:REPLAY_BIN"
Write-Host "Using APP_BASE_URL = $env:APP_BASE_URL"

# --- Helper: runner work path ---
function Get-RunnerWorkPath {
  if ($env:GITHUB_WORKSPACE) { return $env:GITHUB_WORKSPACE }
  return (Get-Location).Path
}

# --- Helper: remove keploy dirs robustly ---
function Remove-KeployDirs {
  param([string[]]$Candidates)

  # Stop any leftover keploy processes so files aren't locked
  try {
    Get-Process -ErrorAction SilentlyContinue |
      Where-Object {
        $_.ProcessName -in @('keploy','keploy-record','keploy-replay') -or
        $_.Path -like '*\keploy*.exe' -or
        $_.CommandLine -like '*keploy*'
      } |
      Sort-Object StartTime -Descending |
      ForEach-Object {
        taskkill /PID $_.Id /T /F | Out-Null 2>$null
      }
  } catch {}

  foreach ($p in $Candidates) {
    if (-not $p -or -not (Test-Path -LiteralPath $p)) { continue }
    Write-Host "Cleaning keploy directory: $p"
    try {
      cmd /c "attrib -R -S -H `"$p\*`" /S /D" 2>$null | Out-Null
      Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction Stop
    } catch {
      Write-Warning "Remove-Item failed for $p, using rmdir fallback: $_"
      cmd /c "rmdir /S /Q `"$p`"" 2>$null | Out-Null
    }
  }
}

# --- Clean previous keploy outputs ---
$candidates = @(".\keploy")
if ($env:GITHUB_WORKSPACE) { $candidates += (Join-Path $env:GITHUB_WORKSPACE 'keploy') }
Remove-KeployDirs -Candidates $candidates
Remove-Item -LiteralPath ".\keploy.yml" -Force -ErrorAction SilentlyContinue
Write-Host "Pre-clean complete."

# --- Generate keploy.yml and add noise for timestamp endpoint ---
Write-Host "Generating keploy config..."
& $env:RECORD_BIN config --generate

$configFile = ".\keploy.yml"
if (-not (Test-Path $configFile)) { throw "Config file '$configFile' not found after generation." }

# Add noise to ignore current_time in body (go-dedup /timestamp endpoint)
(Get-Content $configFile -Raw) -replace 'global:\s*\{\s*\}', 'global: {"body": {"current_time":[]}}' |
  Set-Content -Path $configFile -Encoding UTF8
Write-Host "Updated global noise in keploy.yml to ignore 'current_time'."

# --- Helpers for record flow ---
function Test-RecordingComplete {
  param(
    [string]$root,
    [int]$idx,
    [int]$minFiles = 7,
    [int]$minBytes = 100
  )
  $p1 = Join-Path $root "keploy\test-set-$idx\tests"
  $p2 = ".\keploy\test-set-$idx\tests"
  foreach ($p in @($p1,$p2)) {
    if (-not (Test-Path $p)) { continue }
    $files = Get-ChildItem -Path $p -Filter "*.yaml" -ErrorAction SilentlyContinue
    if (-not $files) { continue }
    $valid = ($files | Where-Object { $_.Length -ge $minBytes }).Count
    if ($valid -ge $minFiles) { return $true }
  }
  return $false
}

function Kill-Tree {
  param([int]$ProcessId)
  try {
    Write-Host "Stopping Keploy process tree (root PID $ProcessId)…"
    cmd /c "taskkill /PID $ProcessId /T /F" | Out-Null
  } catch {
    Write-Warning "taskkill failed for $ProcessId : $_"
  }
}

# =========================
# ========== RECORD =======
# =========================
$containerName = "dedup-go"
$logPath = "$containerName.record.txt"
$expectedTestSetIndex = 0
$workDir = Get-RunnerWorkPath
$base = $env:APP_BASE_URL

# Configure image for recording (optional override via DOCKER_IMAGE_RECORD)
$env:KEPLOY_DOCKER_IMAGE = if ($env:DOCKER_IMAGE_RECORD) { $env:DOCKER_IMAGE_RECORD } else { 'keploy:record' }

# 1. Correctly quote the docker command for Keploy
$dockerCmd = "go run main.go"
$recArgs = @(
  'record',
  '-c', $dockerCmd,
  '--generate-github-actions=false'
)

Write-Host "Starting keploy record (expecting test-set-$expectedTestSetIndex)…"
Write-Host "Executing: $env:RECORD_BIN $($recArgs -join ' ')"

# 2. Start Keploy in a background job.
# This allows the script to continue while Keploy runs.
# We use Tee-Object to send output to BOTH the log file and the job's output stream.
$recJob = Start-Job -ScriptBlock {
    # Use the $using: scope to access variables from the parent script
    & $using:env:RECORD_BIN @($using:recArgs) 2>&1 | Tee-Object -FilePath $using:logPath
}

Write-Host "`n=========================================================="
Write-Host "Dumping full Keploy Record Logs from file: '$logPath'"
Write-Host "=========================================================="
Get-Content -Path $logPath -ErrorAction SilentlyContinue
Write-Host "=========================================================="

# This function will print any new logs from the background job
function Sync-Logs {
    param($job)
    try {
        Receive-Job -Job $job -ErrorAction SilentlyContinue
    } catch {}
}

# Wait for app readiness — same stability window + settle +
# per-request retry scheme as the docker variant. See that
# script's comment for the keploy#4076 flake that drove this.
Write-Host "Waiting for app to respond on $base/hello/keploy …"
$deadline       = (Get-Date).AddMinutes(10)  # go run on cold Windows runners can take 5+ minutes to compile
$stabilityCount = 3
$settleSec      = 5
$okStreak       = 0
# Gate the loop on the keploy PID, not the tail job's state —
# Get-Content -Wait can transiently drop out of 'Running' on
# Windows, which made the probe bail after ~5s on the docker
# variant's run 24630134970. Mirror that fix here.
do {
  Sync-Logs -job $recJob
  if ($REC_PID) {
    $keployAlive = [bool](Get-Process -Id $REC_PID -ErrorAction SilentlyContinue)
    if (-not $keployAlive) { break }
  }
  try {
    $r = Invoke-WebRequest -Method GET -Uri "$base/hello/keploy" -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
    if ($r.StatusCode -eq 200) {
      $okStreak++
      if ($okStreak -ge $stabilityCount) { break }
      Start-Sleep -Seconds 1
    } else {
      $okStreak = 0
    }
  } catch {
    $okStreak = 0
    Start-Sleep 3
  }
} while ((Get-Date) -lt $deadline)

if ($okStreak -lt $stabilityCount) {
  Write-Warning "App readiness probe did not reach ${stabilityCount} consecutive 200s before deadline; continuing with traffic anyway — downstream record validation will surface the failure."
} else {
  Write-Host "App readiness confirmed ($stabilityCount consecutive 200s). Settling ${settleSec}s before sending traffic…"
  Start-Sleep -Seconds $settleSec
}

function Invoke-WithRetry {
  param(
    [scriptblock]$Action,
    [string]$Name,
    [int]$MaxAttempts = 5,
    [int]$InitialSleepSec = 2
  )
  for ($i = 1; $i -le $MaxAttempts; $i++) {
    try {
      & $Action | Out-Null
      return $true
    } catch {
      if ($i -ge $MaxAttempts) {
        Write-Warning "Request '$Name' failed after $MaxAttempts attempts: $_"
        return $false
      }
      $sleep = [int]($InitialSleepSec * [Math]::Pow(1.5, $i - 1))
      Write-Host "Request '$Name' attempt $i failed ($_); retrying in ${sleep}s…"
      Start-Sleep -Seconds $sleep
    }
  }
  return $false
}

Write-Host "Sending HTTP requests to generate tests…"
$sent = 0
if (Invoke-WithRetry -Name "GET hello/Keploy"   -Action { Invoke-RestMethod -Method GET    -Uri "$base/hello/Keploy" -TimeoutSec 30 })                                                                      { $sent++ }
if (Invoke-WithRetry -Name "POST user"          -Action { Invoke-RestMethod -Method POST   -Uri "$base/user"         -Body (@{name="John Doe";email="john@keploy.io"}        | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 30 }) { $sent++ }
if (Invoke-WithRetry -Name "PUT item/item123"   -Action { Invoke-RestMethod -Method PUT    -Uri "$base/item/item123" -Body (@{id="item123";name="Updated Item";price=99.99} | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 30 }) { $sent++ }
if (Invoke-WithRetry -Name "GET products"       -Action { Invoke-RestMethod -Method GET    -Uri "$base/products"     -TimeoutSec 30 })                                                                                                           { $sent++ }
if (Invoke-WithRetry -Name "DELETE products/…"  -Action { Invoke-RestMethod -Method DELETE -Uri "$base/products/prod001" -TimeoutSec 30 })                                                                                                       { $sent++ }
if (Invoke-WithRetry -Name "GET api/v2/users"   -Action { Invoke-RestMethod -Method GET    -Uri "$base/api/v2/users" -TimeoutSec 30 })                                                                                                           { $sent++ }

Write-Host "Sent $sent request(s). Waiting for tests to flush to disk…"

$pollUntil = (Get-Date).AddSeconds(60)
do {
  Sync-Logs -job $recJob # <-- Print logs while waiting
  if (Test-RecordingComplete -root $workDir -idx $expectedTestSetIndex -minFiles 7) { break }
  Start-Sleep 3
} while ((Get-Date) -lt $pollUntil -and $recJob.State -eq 'Running')


$REC_PROC = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
  Where-Object {
    ($_.CommandLine -and ($_.CommandLine -match 'keploy.*record' -or $_.CommandLine -match 'keploy-record' -or $_.CommandLine -match 'keploy(\.exe)?')) -or
    ($_.Name -and $_.Name -match 'keploy')
  } |
  Select-Object -First 1

Write-Host "Value of REC_PROC: $REC_PROC"

$REC_PID = if ($REC_PROC) { $REC_PROC.ProcessId } else { $null }

if ($REC_PID -and $REC_PID -ne 0) {
    Write-Host "Found Keploy PID: $REC_PID"
    Write-Host "Killing keploy process tree..."
    cmd /c "taskkill /PID $REC_PID /T /F" 2>$null | Out-Null
    cmd /c "taskkill /PID $REC_PROC /T /F" 2>$null | Out-Null
} else {
    Write-Host "Keploy record process not found. Dumping candidate processes containing 'keploy' in CommandLine:"
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
      Where-Object { $_.CommandLine -and ($_.CommandLine -match 'keploy') } |
      Select-Object ProcessId, Name, @{Name='Cmd';Expression={$_.CommandLine}} |
      ForEach-Object { Write-Host "$($_.ProcessId)  $($_.Name)  $($_.Cmd)" }
}


# Stop Keploy (and docker compose) deterministically
# We get the process ID of the actual keploy.exe process started by the job
# $keployProcessId = (Get-Job -Id $recJob.Id).ChildJobs[0].ProcessId
# Kill-Tree -ProcessId $keployProcessId
# Stop-Job $recJob
# Remove-Job $recJob

# Verify recording
$testSetPath = ".\keploy\test-set-$expectedTestSetIndex\tests"
if (-not (Test-Path $testSetPath)) { Write-Error "Test directory not found at $testSetPath"; Get-Content .\keploy_agent.log; exit 1 }
$testCount = (Get-ChildItem -Path $testSetPath -Filter "*.yaml").Count
if ($testCount -eq 0) { Write-Error "No test files were created. Review the full logs in the file '$logPath'"; exit 1 }

Write-Host "Successfully recorded $testCount test file(s) in test-set-$expectedTestSetIndex"

# Supplemental json-format record. Windows workflows always run build-windows
# binaries which include --storage-format support, so we skip the bash gate.
$logPathJson = "$containerName.record.json.txt"
$recArgsJson = @(
  'record',
  '--storage-format', 'json',
  '-c', $dockerCmd,
  '--generate-github-actions=false'
)
Write-Host "Starting keploy record (json)…"
$recJobJson = Start-Job -ScriptBlock {
    & $using:env:RECORD_BIN @($using:recArgsJson) 2>&1 | Tee-Object -FilePath $using:logPathJson
}
Start-Sleep -Seconds 30
# Drive the same traffic
foreach ($call in @(
  @{ M='GET';    U="$base/hello/Keploy" },
  @{ M='POST';   U="$base/user";         B=@{name="John Doe";email="john@keploy.io"} },
  @{ M='PUT';    U="$base/item/item123"; B=@{id="item123";name="Updated Item";price=99.99} },
  @{ M='GET';    U="$base/products" },
  @{ M='DELETE'; U="$base/products/prod001" },
  @{ M='GET';    U="$base/api/v2/users" }
)) {
  try {
    if ($call.B) {
      Invoke-RestMethod -Method $call.M -Uri $call.U -Body ($call.B | ConvertTo-Json) -ContentType 'application/json' -TimeoutSec 30 | Out-Null
    } else {
      Invoke-RestMethod -Method $call.M -Uri $call.U -TimeoutSec 30 | Out-Null
    }
  } catch {}
}
Start-Sleep -Seconds 10
$recProcJson = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -match 'keploy.*record' } | Select-Object -First 1
if ($recProcJson) { cmd /c "taskkill /PID $($recProcJson.ProcessId) /T /F" 2>$null | Out-Null }
Stop-Job $recJobJson -ErrorAction SilentlyContinue
Remove-Job $recJobJson -Force -ErrorAction SilentlyContinue

# =========================
# ========== REPLAY =======
# =========================

# Bring down services before test mode (preserve volumes)
Write-Host "Shutting down docker compose services before test mode (preserving volumes)…"
docker compose down
Start-Sleep -Seconds 5

$testContainer = "dedup-go"
$testLog = "$testContainer.test.txt"

# Configure image for replay (optional override via DOCKER_IMAGE_REPLAY)
$env:KEPLOY_DOCKER_IMAGE = if ($env:DOCKER_IMAGE_REPLAY) { $env:DOCKER_IMAGE_REPLAY } else { 'keploy:replay' }

$testArgs = @(
  'test',
  '-c', 'go run main.go',
  '--api-timeout', '60',
  '--delay', '30',
  # '--port', '8080',
  '--generate-github-actions=false'
)

Write-Host "Starting keploy replay…"
Write-Host "Executing: $env:REPLAY_BIN $($testArgs -join ' ')"
# Native replay also writes benign stderr lines (`go: downloading
# …`, recover traces, etc.) that under ErrorActionPreference=Stop
# get promoted to a terminating NativeCommandError. See the
# docker variant's comment for the full RCA.
$prevEap = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
try {
  & $env:REPLAY_BIN @testArgs 2>&1 | Tee-Object -FilePath $testLog
  $replayExit = $LASTEXITCODE
} finally {
  $ErrorActionPreference = $prevEap
}
Write-Host "Replay exited with code $replayExit"

# Validate replay report
$report = ".\keploy\reports\test-run-0\test-set-0-report.yaml"
if (-not (Test-Path $report)) {
  Write-Error "Missing report file: $report (replay exit $replayExit)"
  Get-Content $testLog -ErrorAction SilentlyContinue | Select-Object -Last 200
  exit 1
}

$line = Select-String -Path $report -Pattern 'status:' | Select-Object -First 1
$status = ($line.ToString() -replace '.*status:\s*', '').Trim()
Write-Host "Test status for test-set-0: $status"

if ($status -ne 'PASSED') {
  Write-Error "Replay failed (status: $status). See logs below:"
  Get-Content $testLog -ErrorAction SilentlyContinue | Select-Object -Last 200
  exit 1
}

# Json-format replay
$testLogJson = "$testContainer.test.json.txt"
$testArgsJson = @(
  'test',
  '--storage-format', 'json',
  '-c', 'go run main.go',
  '--api-timeout', '60',
  '--delay', '30',
  '--generate-github-actions=false'
)
$prevEap = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
try {
  & $env:REPLAY_BIN @testArgsJson 2>&1 | Tee-Object -FilePath $testLogJson
} finally {
  $ErrorActionPreference = $prevEap
}

$reportFilesJson = Get-ChildItem -Path ".\keploy\reports" -Filter "*report.json" -Recurse -ErrorAction SilentlyContinue
if (-not $reportFilesJson) {
  Write-Error "No json report files found."
  Get-Content $testLogJson -ErrorAction SilentlyContinue | Select-Object -Last 200
  exit 1
}
$anyJsonFailed = $false
foreach ($file in $reportFilesJson) {
  try {
    $obj = Get-Content $file.FullName -Raw | ConvertFrom-Json
  } catch {
    Write-Error "Failed to parse json report $($file.Name): $_"
    $anyJsonFailed = $true
    continue
  }
  Write-Host "json report $($file.Name): $($obj.status)"
  if ($obj.status -ne "PASSED") { $anyJsonFailed = $true }
}
if ($anyJsonFailed) {
  Write-Error "Some json tests failed."
  exit 1
}

Write-Host "All tests passed successfully (yaml + json)!"
exit 0