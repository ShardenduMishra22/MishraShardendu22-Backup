#!/bin/bash

# This script tests the grpc-secret sample application with Keploy's sanitize functionality.
# It records gRPC requests with secrets in headers and body, sanitizes them, and validates test results.
#
# Expects:
#   RECORD_BIN -> path to keploy record binary (env)
#   REPLAY_BIN -> path to keploy test binary   (env)
#
set -Eeuo pipefail

echo "root ALL=(ALL:ALL) ALL" | sudo tee -a /etc/sudoers

# --- Sanity Checks ---
[ -x "${RECORD_BIN:-}" ] || { echo "RECORD_BIN not set or not executable"; exit 1; }
[ -x "${REPLAY_BIN:-}" ] || { echo "REPLAY_BIN not set or not executable"; exit 1; }
command -v go >/dev/null 2>&1 || { echo "go not found"; exit 1; }

# --- Install grpcurl ---
echo "Installing grpcurl..."
if ! command -v grpcurl &> /dev/null; then
    echo "grpcurl not found, installing..."
    go install github.com/fullstorydev/grpcurl/cmd/grpcurl@latest
    export PATH="$PATH:$HOME/go/bin"
fi
command -v grpcurl >/dev/null 2>&1 || { echo "grpcurl installation failed"; exit 1; }
echo "grpcurl installed successfully"

# --- Helper Functions ---

# Cleanup function to kill all running processes
cleanup() {
    echo "Cleaning up running processes..."
    pkill -f keploy || true
    pkill -f "go run" || true
    pkill -f grpc-secret || true
    sleep 2
    pkill -9 -f keploy || true
    pkill -9 -f "go run" || true
    pkill -9 -f grpc-secret || true
    echo "Cleanup complete."
}
trap cleanup EXIT

# Function to cleanup any remaining keploy processes
cleanup_keploy() {
    echo "Cleaning up any remaining keploy processes..."
    local pids=$(pgrep keploy)
    if [ -n "$pids" ]; then
        echo "Found keploy processes: $pids"
        echo "$pids" | xargs -r sudo kill -9 2>/dev/null || true
        sleep 1
        if pgrep keploy >/dev/null; then
            echo "Warning: Some keploy processes may still be running"
        else
            echo "All keploy processes cleaned up successfully"
        fi
    else
        echo "No keploy processes found to cleanup"
    fi
}

wait_for_port_release() {
    local port=$1
    local timeout_seconds=${2:-15}

    echo "Waiting for port ${port} to be released..."
    for ((i=0; i<timeout_seconds; i++)); do
        if ! (echo >"/dev/tcp/127.0.0.1/${port}") >/dev/null 2>&1; then
            echo "Port ${port} is free"
            return 0
        fi
        sleep 1
    done

    echo "Port ${port} is still in use after ${timeout_seconds}s"
    ss -ltnp | grep ":${port} " || true
    return 1
}

ensure_grpc_secret_stopped() {
    local port=50051

    if ! wait_for_port_release "${port}" 5; then
        echo "Found a lingering grpc-secret listener on port ${port}, cleaning it up..."
        pkill -f grpc-secret || true
        sleep 2
        pkill -9 -f grpc-secret || true
        wait_for_port_release "${port}" 15
    fi
}

# Checks a log file for critical errors or data races
check_for_errors() {
    local logfile=$1
    echo "Checking for errors in $logfile..."
    if [ -f "$logfile" ]; then
        # Check for ERROR lines (excluding non-critical ones)
        if awk '/ERROR/ && !/Unsupported DNS query type/ { exit 0 } END { exit 1 }' "$logfile"; then
            echo "Error found in $logfile"
            cat "$logfile"
            exit 1
        fi
        if grep -q "WARNING: DATA RACE" "$logfile"; then
            echo "Race condition detected in $logfile"
            cat "$logfile"
            exit 1
        fi
    fi
    echo "No critical errors found in $logfile."
}

# Kills the keploy process gracefully
kill_keploy_process() {
    pid=$(pgrep keploy | head -n 1)
    if [ -n "$pid" ]; then
        echo "$pid Keploy PID"
        echo "Killing keploy"
        
        # Try graceful shutdown first
        if ! kill "$pid" 2>/dev/null; then
            echo "Graceful kill failed, trying with sudo..."
            if ! sudo kill "$pid" 2>/dev/null; then
                echo "Sudo kill failed, trying SIGKILL..."
                if ! sudo kill -9 "$pid" 2>/dev/null; then
                    echo "Warning: Could not kill keploy process $pid"
                else
                    echo "Successfully killed keploy with SIGKILL"
                fi
            else
                echo "Successfully killed keploy with sudo"
            fi
        else
            echo "Successfully killed keploy gracefully"
        fi
        
        # Wait and verify the process is gone
        sleep 2
        if pgrep keploy >/dev/null; then
            echo "Warning: Keploy process may still be running"
            pgrep keploy | xargs -r sudo kill -9 2>/dev/null || true
        fi
    else
        echo "No keploy process found to kill"
    fi
}

# Send all 4 gRPC requests
send_grpc_requests() {
    echo "Waiting for gRPC server to be ready..."
    sleep 10

    # 0. Reflection probes — exercise the LifetimeSession mock path end-to-end.
    # The grpc-secret server registers grpc.reflection.v1.ServerReflection in
    # main.go. These two grpcurl invocations issue ServerReflectionInfo RPCs
    # that the keploy recorder tags as type=="config" / Lifetime==Session, so
    # replay must serve them from the session pool (not the per-test pool).
    # Without this, the matcher's per-test-only path could regress silently
    # because the regular Jwt/Curl/Cdn/GetSecret RPCs all live in per-test.
    echo "Probing gRPC reflection (list)..."
    grpcurl -plaintext -v localhost:50051 list >/dev/null 2>&1 || echo "reflection list completed"
    sleep 1
    echo "Probing gRPC reflection (describe SecretService)..."
    grpcurl -plaintext -v localhost:50051 describe secrets.SecretService >/dev/null 2>&1 || echo "reflection describe completed"
    sleep 1

    echo "Sending all 4 gRPC requests..."

    # 1. JwtLab
    echo "Sending JwtLab request..."
    grpcurl -plaintext -v \
      -H "authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWUsImlhdCI6MTUxNjIzOTAyMn0.TCYt5XsITJX1CxPCT8yAV-TVkIEq_PbChOMqsLfRoPsnsgw5WEuts01mq-pQy7UJiN5mgRxD-WUcX16dUEMGlv50aTquLy4H2jJL6QRTQFXBF9kGvUKL9Q" \
      -H "x-api-key: AIzaSyD-9tNxCeDNj3S0K_abcdefghijklmnopqr" \
      -H "x-session-token: SG.abc123xyz.789def012ghi345jkl678mno901pqr234stu" \
      -H "x-mongodb-password: mongodb+srv://user:SecretP@ssw0rd123@cluster.net" \
      -H "x-postgres-url: postgres://dbuser:MyS3cr3tP@ss@db.internal:5432/prod" \
      -H "x-datadog-key: 0123456789abcdef0123456789abcdef" \
      -d '{}' \
      localhost:50051 \
      secrets.SecretService/JwtLab >/dev/null 2>&1 || echo "JwtLab request completed"
    
    sleep 1
    
    # 2. CurlMix
    echo "Sending CurlMix request..."
    grpcurl -plaintext -v \
      -H "authorization: Bearer wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY" \
      -H "x-api-key: sk-1234567890abcdefghijklmnopqrstuvwxyzABCDEF" \
      -H "x-session-token: npm_abcdefghijklmnopqrstuvwxyz1234567890" \
      -H "x-github-token: ghp_9876543210ZYXWVUTSRQPONMLKJIHGFEDCBAzy" \
      -H "x-slack-webhook: https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXX" \
      -H "x-twilio-token: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6" \
      -d '{}' \
      localhost:50051 \
      secrets.SecretService/CurlMix >/dev/null 2>&1 || echo "CurlMix request completed"
    
    sleep 1
    
    # 3. Cdn
    echo "Sending Cdn request..."
    grpcurl -plaintext -v \
      -H "authorization: Bearer sk_live_4eC39HqLyjWDarjtT1zdp7dc" \
      -H "x-api-key: AKIAJ5XXXXXXXXXXXXXXXX" \
      -H "x-session-token: ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh1234" \
      -H "x-hmac-secret: 1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w4x5y6z" \
      -H "x-cloudflare-token: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0" \
      -H "x-azure-key: DefaultEndpointsProtocol=https;AccountName=myaccount;AccountKey=abc123xyz789==" \
      -H "x-sendgrid-key: SG.abcdefghijklmnopqrstuv.xyz0123456789abcdefghijklmnopqrstuvwxyz" \
      -d '{}' \
      localhost:50051 \
      secrets.SecretService/Cdn >/dev/null 2>&1 || echo "Cdn request completed"
    
    sleep 1
    
    # 4. GetSecret
    echo "Sending GetSecret request..."
    grpcurl -plaintext -v \
      -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJrZXBsb3ktdGVzdHMiLCJzdWIiOiJ1c2VyXzMxMDBfYWJjZDEyMzQiLCJ0cyI6IjIwMjUtMDEtMDFUMDA6MDA6MDBaIn0.c29tZV9zaWduYXR1cmVfaGVyZQ" \
      -H "x-api-key: sk-proj-abcd1234efgh5678ijkl9012mnop3456qrst" \
      -H "x-session-token: ghp_1234567890abcdefghijklmnopqrstuvwxyz" \
      -H "x-stripe-key: sk_live_51aBc123dEfghIjkLmnOp456qrSTuvWxYz789" \
      -H "x-aws-access: AKIAIOSFODNN7EXAMPLE" \
      -H "x-mongodb-uri: mongodb+srv://admin:p4ssw0rd@cluster0.mongodb.net/mydb" \
      -d '{"id": 1}' \
      localhost:50051 \
      secrets.SecretService/GetSecret >/dev/null 2>&1 || echo "GetSecret request completed"
    
    echo "All requests sent."
    sleep 3
}

# Validates the Keploy test report to ensure all replayed test sets passed.
#
# Robustness note: keploy's test-set numbering across repeated `record` runs
# is not stable — a second `keploy record` may append to test-set-0 instead of
# creating test-set-1. Hard-requiring an exact test-set count therefore flaked
# this job even when every replayed test set PASSED (e.g. only test-run-1/
# test-set-0-report.yaml exists, status PASSED, but the old loop demanded
# test-set-1 and bailed). We instead validate every test-set report that
# actually exists (mirroring json_scan_reports): require at least one, and
# require all present reports to be PASSED. A genuinely FAILED test set still
# fails the check; only the spurious "missing higher-index test set" path is
# tolerated. The first arg is the previously-expected count, kept for call-site
# compatibility and surfaced only as a log hint.
check_test_report() {
    local expected_test_sets="${1:-1}"
    echo "Checking test reports (recorded ~${expected_test_sets} set(s) expected; validating all present reports)..."

    if [ ! -d "./keploy/reports" ]; then
        echo "Test report directory not found!"
        return 1
    fi

    local latest_report_dir
    latest_report_dir=$(ls -td ./keploy/reports/test-run-* 2>/dev/null | head -n 1)
    if [ -z "$latest_report_dir" ]; then
        echo "No test run directory found in ./keploy/reports/"
        return 1
    fi

    shopt -s nullglob
    local reports=( "$latest_report_dir"/test-set-*-report.yaml )
    shopt -u nullglob
    if [ "${#reports[@]}" -eq 0 ]; then
        echo "No test-set report files found in $latest_report_dir"
        return 1
    fi

    local all_passed=true
    local total_success=0
    local report_file test_status fail_count succ_count
    for report_file in "${reports[@]}"; do
        # Top-level report fields. status:/success:/failure: appear before the
        # per-test 'tests:' list, so head -1 reads the report-level value.
        test_status=$(grep 'status:' "$report_file"  | head -n 1 | awk '{print $2}')
        fail_count=$(grep 'failure:' "$report_file"  | head -n 1 | awk '{print $2}')
        succ_count=$(grep 'success:' "$report_file"  | head -n 1 | awk '{print $2}')
        [[ "$fail_count" =~ ^[0-9]+$ ]] || fail_count=0
        [[ "$succ_count" =~ ^[0-9]+$ ]] || succ_count=0
        echo "$(basename "$report_file"): status=${test_status:-<none>} success=$succ_count failure=$fail_count"
        # A set passes only if status is PASSED AND no test failed. The
        # failure>0 guard is defensive belt-and-suspenders so a stale/incorrect
        # status field can never let a real test failure slip through.
        if [ "$test_status" != "PASSED" ] || [ "$fail_count" -ne 0 ]; then
            all_passed=false
            echo "$(basename "$report_file") did not pass."
        fi
        total_success=$(( total_success + succ_count ))
    done

    if [ "$all_passed" = false ]; then
        echo "One or more test sets failed."
        return 1
    fi
    # Guard against a vacuous pass: a PASSED report with zero tests would
    # otherwise satisfy the loop. Require that at least one test actually ran
    # and passed across all present reports.
    if [ "$total_success" -lt 1 ]; then
        echo "No tests ran/passed across ${#reports[@]} report(s) — treating as failure (empty or silent run)."
        return 1
    fi

    echo "All ${#reports[@]} present test set(s) passed ($total_success tests total)."
    return 0
}

# --- Main Logic ---

echo "🧪 Starting gRPC Secret Sanitize Testing"

# Reset state before each run
cleanup
ensure_grpc_secret_stopped
rm -rf ./keploy*
"$RECORD_BIN" config --generate
sleep 3

go build -o grpc-secret .
sleep 4

echo "✅ Built grpc-secret binary"

# --- Record 2 test sets ---
echo "📝 Phase 1: Recording 2 test sets with all 4 endpoints..."

do_record_iteration() {
    local i="$1"
    local extra_flags="${2:-}"
    local label="${extra_flags:+_json}"
    local app_name="grpcSecret_${i}${label}"
    echo "Recording iteration ${i}${label:+ (json)}..."

    ensure_grpc_secret_stopped

    # shellcheck disable=SC2086
    "$RECORD_BIN" record $extra_flags -c "./grpc-secret" --generateGithubActions=false > >(tee "${app_name}.txt") 2>&1 &
    local record_pid=$!

    send_grpc_requests &
    local request_pid=$!
    wait "${request_pid}"

    kill_keploy_process

    wait "${record_pid}" || true
    ensure_grpc_secret_stopped

    check_for_errors "${app_name}.txt"

    sleep 5
    echo "✅ Recorded test set ${i}${label:+ (json)}"
}

for i in 1 2; do
    do_record_iteration "$i"
done

# shellcheck disable=SC1091
source "${GITHUB_WORKSPACE:-${PWD%/samples-*}}/.github/workflows/test_workflow_scripts/json-pass-helpers.sh"

if json_pass_supported; then
    for i in 1 2; do
        do_record_iteration "$i" "--storage-format json"
    done
fi

# --- Run keploy test (before sanitize) ---
echo "🧪 Phase 2: Running keploy test (before sanitize)..."
"$REPLAY_BIN" test -c "./grpc-secret" --delay 10 --generateGithubActions=false 2>&1 | tee test_before_sanitize.txt || true

# Check for errors and race conditions
check_for_errors test_before_sanitize.txt

# Verify test sets passed
if ! check_test_report 2; then
    echo "⚠️ Test report check before sanitize: some tests may have failed (expected)"
else
    echo "✅ All tests passed before sanitize"
fi

# --- Run keploy sanitize ---
echo "🧹 Phase 3: Running keploy sanitize..."
"$RECORD_BIN" sanitize 2>&1 | tee sanitize_logs.txt

# Check for errors and race conditions
check_for_errors sanitize_logs.txt

sleep 5
echo "✅ Sanitization complete"

# --- Run keploy test (after sanitize) ---
echo "🧪 Phase 4: Running keploy test (after sanitize)..."
"$REPLAY_BIN" test -c "./grpc-secret" --delay 10 --generateGithubActions=false 2>&1 | tee test_after_sanitize.txt || true

# Check for errors and race conditions
check_for_errors test_after_sanitize.txt

# Verify all test sets passed
if ! check_test_report 2; then
    echo "❌ Test report check failed after sanitize."
    cat test_after_sanitize.txt
    exit 1
fi

echo "✅ All tests passed after sanitize!"

if json_pass_supported; then
    echo "🧪 Phase 5: Running keploy test (json) after sanitize..."
    "$REPLAY_BIN" test --storage-format json -c "./grpc-secret" --delay 10 --generateGithubActions=false 2>&1 | tee test_json_after_sanitize.txt || true
    check_for_errors test_json_after_sanitize.txt
    if ! json_scan_reports; then
        cat test_json_after_sanitize.txt
        exit 1
    fi
    echo "✅ All tests passed in json mode!"
fi

# --- Cleanup ---
cleanup_keploy

echo "🎉 gRPC Secret Sanitize Testing completed successfully!"
exit 0
