import dotenv from 'dotenv';

dotenv.config({ quiet: true });

interface ServerEnv {
  NODE_ENV: string;
  PORT: number;
  CLIENT_URI: string;
  MONGO_URI: string;
  JWT_SECRET_KEY: string;
  ADMIN_PASSWORD: string;
}

const readRequired = (key: keyof ServerEnv): string => {
  const value = process.env[key];
  if (!value || value.trim() === '') {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
};

const readPort = () => {
  const raw = process.env.PORT ?? '5000';
  const parsed = Number(raw);

  if (!Number.isInteger(parsed) || parsed <= 0) {
    throw new Error('PORT must be a positive integer');
  }

  return parsed;
};

const getServerEnv = (): ServerEnv => ({
  NODE_ENV: process.env.NODE_ENV ?? 'development',
  PORT: readPort(),
  CLIENT_URI: process.env.CLIENT_URI ?? '*',
  MONGO_URI: readRequired('MONGO_URI'),
  JWT_SECRET_KEY: readRequired('JWT_SECRET_KEY'),
  ADMIN_PASSWORD: readRequired('ADMIN_PASSWORD'),
});

export type { ServerEnv };
export { getServerEnv };
