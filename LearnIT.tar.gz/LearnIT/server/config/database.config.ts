import mongoose from 'mongoose';

const connectDatabase = async (mongoUri: string) => {
  if (!mongoUri) {
    throw new Error('Missing required environment variable: MONGO_URI');
  }

  if (mongoose.connection.readyState === 1) {
    return mongoose.connection;
  }

  const connection = await mongoose.connect(mongoUri);
  return connection.connection;
};

const disconnectDatabase = async () => {
  if (mongoose.connection.readyState !== 0) {
    await mongoose.disconnect();
  }
};

export { connectDatabase, disconnectDatabase };
