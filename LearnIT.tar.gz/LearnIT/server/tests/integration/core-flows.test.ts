import request from 'supertest';
import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { createApp } from '../../app';
import { connectDatabase, disconnectDatabase } from '../../config/database.config';

const ensureTestEnv = () => {
  process.env.NODE_ENV = 'test';
  process.env.JWT_SECRET_KEY = process.env.JWT_SECRET_KEY || 'test-jwt-secret';
  process.env.ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'test-admin-password';
  process.env.CLIENT_URI = process.env.CLIENT_URI || '*';
};

const uniqueFacultyEmail = () => `faculty.${Date.now()}.${Math.floor(Math.random() * 1000)}@iiitdwd.ac.in`;

let studentSequence = 100;
const uniqueStudentEmail = () => {
  studentSequence += 1;
  return `23bec${String(studentSequence).padStart(3, '0')}@iiitdwd.ac.in`;
};

describe('Core auth and enrollment flows', () => {
  let mongoServer: MongoMemoryServer;
  let app: ReturnType<typeof createApp>;

  beforeAll(async () => {
    ensureTestEnv();
    mongoServer = await MongoMemoryServer.create();
    process.env.MONGO_URI = mongoServer.getUri();

    await connectDatabase(process.env.MONGO_URI);
    app = createApp();
  });

  afterEach(async () => {
    const collections = mongoose.connection.collections;
    for (const key of Object.keys(collections)) {
      await collections[key].deleteMany({});
    }
  });

  afterAll(async () => {
    await disconnectDatabase();
    await mongoServer.stop();
  });

  it('supports student register, login, and verify', async () => {
    const studentEmail = uniqueStudentEmail();
    const password = 'Student@123';

    const registerResponse = await request(app)
      .post('/api/v1/student/register')
      .send({ email: studentEmail, password });

    expect(registerResponse.status).toBe(201);
    expect(registerResponse.body.message).toContain('registered');

    const loginResponse = await request(app)
      .post('/api/v1/student/login')
      .send({ email: studentEmail, password });

    expect(loginResponse.status).toBe(200);
    expect(typeof loginResponse.body.data).toBe('string');

    const token = loginResponse.body.data as string;
    const verifyResponse = await request(app)
      .get('/api/v1/student/verify')
      .set('Authorization', `Bearer ${token}`);

    expect(verifyResponse.status).toBe(200);
    expect(verifyResponse.body.data.email).toBe(studentEmail);
    expect(verifyResponse.body.data.role).toBe('student');
  });

  it('supports faculty course creation and student course/group joining', async () => {
    const facultyEmail = uniqueFacultyEmail();
    const studentEmail = uniqueStudentEmail();
    const password = 'Password@123';

    const facultyRegister = await request(app)
      .post('/api/v1/faculty/register')
      .send({ email: facultyEmail, password });
    expect(facultyRegister.status).toBe(201);

    const facultyLogin = await request(app)
      .post('/api/v1/faculty/login')
      .send({ email: facultyEmail, password });
    expect(facultyLogin.status).toBe(200);
    const facultyToken = facultyLogin.body.data as string;

    const studentRegister = await request(app)
      .post('/api/v1/student/register')
      .send({ email: studentEmail, password });
    expect(studentRegister.status).toBe(201);

    const studentLogin = await request(app)
      .post('/api/v1/student/login')
      .send({ email: studentEmail, password });
    expect(studentLogin.status).toBe(200);
    const studentToken = studentLogin.body.data as string;

    const courseCode = `CS${Math.floor(Math.random() * 900 + 100)}`;
    const createCourseResponse = await request(app)
      .post('/api/v1/faculty/course')
      .set('Authorization', `Bearer ${facultyToken}`)
      .send({
        courseName: 'Distributed Systems',
        courseCode,
        courseCredit: 4,
      });

    expect(createCourseResponse.status).toBe(201);
    expect(createCourseResponse.body.data.courseCode).toBe(courseCode);

    const courseId = createCourseResponse.body.data._id as string;
    const joinCourseResponse = await request(app)
      .post('/api/v1/student/course/register')
      .set('Authorization', `Bearer ${studentToken}`)
      .send({ courseId });

    expect(joinCourseResponse.status).toBe(201);
    expect(joinCourseResponse.body.message).toContain('successful');

    const createGroupResponse = await request(app)
      .post('/api/v1/faculty/group')
      .set('Authorization', `Bearer ${facultyToken}`)
      .send({
        name: 'DS - Section A',
        courseId,
        registrationOpen: true,
      });

    expect(createGroupResponse.status).toBe(201);
    const groupId = createGroupResponse.body.data._id as string;

    const joinGroupResponse = await request(app)
      .post('/api/v1/student/group/register')
      .set('Authorization', `Bearer ${studentToken}`)
      .send({ groupId });

    expect(joinGroupResponse.status).toBe(201);
    expect(joinGroupResponse.body.message).toContain('successful');
  });
});
