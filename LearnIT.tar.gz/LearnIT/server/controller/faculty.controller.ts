import { User, Course, Group, Quiz, CourseRegistration, GroupRegistration, QuizQuestion, QuizResult } from '../model/model';
import { IUser } from '../model/schema/user.schema';
import { ICourse } from '../model/schema/course.schema';
import { IGroup } from '../model/schema/group.schema';
import { IQuiz, IQuizSettings } from '../model/schema/quiz.schema';
import { IQuizQuestion, QuizQuestionType } from '../model/schema/quizQuestion.schema';
import { IQuizResult } from '../model/schema/quizResult.schema';
import { JwtPayload } from '../types/auth.types';
import ResponseApi from '../util/ApiResponse.util';
import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Types } from 'mongoose';
import { recomputeGroupGrades } from '../util/grade.util';


const register = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return ResponseApi(res, 400, 'Please provide all required fields');
    }

    // Check if email ends with @iiitdwd.ac.in
    if (!email.toLowerCase().endsWith('@iiitdwd.ac.in')) {
      return ResponseApi(res, 400, 'Only @iiitdwd.ac.in email addresses are allowed');
    }

    // Prevent student ID format from registering as faculty
    const emailPrefix = email.toLowerCase().split('@')[0];
    const studentIdPattern = /^\d{2}[a-z]{3}\d{3}$/;
    if (studentIdPattern.test(emailPrefix)) {
      return ResponseApi(res, 400, 'Student ID format emails cannot register as faculty');
    }

    if (password.length < 6 || password.length > 20) {
      return ResponseApi(
        res,
        400,
        'Password must be at least 6 and at most 20 characters'
      );
    }

    const existingUser = (await User.findOne({
      email: email.toLowerCase(),
    })) as IUser | null;
    if (existingUser) {
      return ResponseApi(res, 400, 'User already exists');
    }

    const genSalt = await bcrypt.genSalt(5);
    const hashedPassword = await bcrypt.hash(password, genSalt);

    const newFaculty: IUser = new User({
      email: email.toLowerCase(),
      password: hashedPassword,
      role: 'faculty'
    });
    await newFaculty.save();

    return ResponseApi(res, 201, 'Faculty registered successfully');
  } catch (error) {
    return ResponseApi(
      res,
      500,
      error instanceof Error
        ? error.message
        : 'An unknown error occurred while registering the faculty'
    );
  }
};

const login = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return ResponseApi(res, 400, 'Please provide all required fields');
    }

    const existingFaculty = (await User.findOne({
      email: email.toLowerCase(),
      role: 'faculty'
    })) as IUser | null;
    if (!existingFaculty) {
      return ResponseApi(res, 400, 'Faculty does not exist');
    }

    const isPasswordValid = await bcrypt.compare(
      password,
      existingFaculty.password
    );
    if (!isPasswordValid) {
      return ResponseApi(res, 400, 'Invalid password');
    }

    if (!process.env.JWT_SECRET_KEY) {
      return ResponseApi(res, 500, 'JWT secret key is not defined');
    }

    const payload: JwtPayload = {
      _id: String(existingFaculty._id),
      role: 'faculty',
    };

    const token = jwt.sign(
      payload,
      process.env.JWT_SECRET_KEY,
      { expiresIn: '30d' }
    );

    return ResponseApi(res, 200, 'Faculty logged in successfully', token);
  } catch (error) {
    return ResponseApi(
      res,
      500,
      error instanceof Error
        ? error.message
        : 'An unknown error occurred while logging in the faculty'
    );
  }
};

const createCourse = async (req: Request, res: Response) => {
  try {
    const { courseCode, courseCredit, courseName, _id } = req.body;
    // _id and role are provided by facultyMiddleware

    if (!courseCode || !courseCredit || !courseName) {
      return ResponseApi(res, 400, 'Please provide all required fields');
    }

    if (courseCredit < 1) {
      return ResponseApi(res, 400, 'Course credits must be at least 1');
    }

    const existingCourse = await Course.findOne({ courseCode });
    if (existingCourse) {
      return ResponseApi(res, 400, 'Course with this code already exists');
    }

    const newCourse = new Course({
      courseCode,
      courseCredit,
      courseName,
      createdBy: _id,
    });
    await newCourse.save();

    return ResponseApi(res, 201, 'Course created successfully', newCourse);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while creating the course');
  }
};

const getMyCourses = async (req: Request, res: Response) => {
  try {
    const { _id } = req.body; // Faculty ID from middleware

    const courses = await Course.find({ createdBy: _id }) as ICourse[];

    return ResponseApi(res, 200, 'Courses retrieved successfully', courses);
  } catch (error) {
    return ResponseApi(
      res,
      500,
      error instanceof Error ? error.message : 'An unknown error occurred while getting courses'
    );
  }
};

const getDashboardStats = async (req: Request, res: Response) => {
  try {
    const { _id } = req.body; // Faculty ID from middleware

    const [totalCourses, totalQuizzes, groups] = await Promise.all([
      Course.countDocuments({ createdBy: _id }),
      Quiz.countDocuments({ facultyId: _id }),
      Group.find({ facultyId: _id }).select('_id')
    ]);

    const groupIds = groups.map((group) => group._id);
    let totalStudents = 0;

    if (groupIds.length > 0) {
      const distinctStudents = await GroupRegistration.distinct('userId', {
        groupId: { $in: groupIds }
      });
      totalStudents = distinctStudents.length;
    }

    return ResponseApi(res, 200, 'Dashboard stats retrieved successfully', {
      totalCourses,
      totalGroups: groups.length,
      totalQuizzes,
      totalStudents,
      totalAssignments: 0
    });
  } catch (error) {
    return ResponseApi(
      res,
      500,
      error instanceof Error ? error.message : 'An unknown error occurred while getting dashboard stats'
    );
  }
};

const createGroup = async (req: Request, res: Response) => {
  try {
    const { name, courseId, registrationOpen } = req.body;
    const { _id } = req.body; // Faculty ID from middleware

    if (!name || !courseId) {
      return ResponseApi(res, 400, 'Please provide group name and course ID');
    }

    // Verify course exists
    const course = await Course.findById(courseId);
    if (!course) {
      return ResponseApi(res, 404, 'Course not found');
    }

    const newGroup = new Group({
      name,
      courseId,
      facultyId: _id,
      registrationOpen: registrationOpen || false
    });
    await newGroup.save();

    const populatedGroup = await Group.findById(newGroup._id)
      .populate('courseId', 'courseName courseCode')
      .populate('facultyId', 'email');

    return ResponseApi(res, 201, 'Group created successfully', populatedGroup);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while creating the group');
  }
};

const getMyGroups = async (req: Request, res: Response) => {
  try {
    const { _id } = req.body; // Faculty ID from middleware

    const groups = await Group.find({ facultyId: _id })
      .populate('courseId', 'courseName courseCode') as IGroup[];

    return ResponseApi(res, 200, 'Groups retrieved successfully', groups);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting groups');
  }
};

const updateGroup = async (req: Request, res: Response) => {
  try {
    const { groupId, name, registrationOpen } = req.body;
    const { _id } = req.body; // Faculty ID from middleware

    if (!groupId) {
      return ResponseApi(res, 400, 'Group ID is required');
    }

    // Verify faculty owns this group
    const group = await Group.findOne({ _id: groupId, facultyId: _id });
    if (!group) {
      return ResponseApi(res, 404, 'Group not found or you do not have permission to modify it');
    }

    const updateData: any = {};
    if (name !== undefined) updateData.name = name;
    if (registrationOpen !== undefined) updateData.registrationOpen = registrationOpen;

    const updatedGroup = await Group.findByIdAndUpdate(groupId, updateData, { new: true })
      .populate('courseId', 'courseName courseCode');

    return ResponseApi(res, 200, 'Group updated successfully', updatedGroup);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while updating the group');
  }
};

const createQuiz = async (req: Request, res: Response) => {
  try {
    const { name, groupId, settings } = req.body;
    const { _id } = req.body; // Faculty ID from middleware

    if (!name || !groupId) {
      return ResponseApi(res, 400, 'Please provide quiz name and group ID');
    }

    // Verify faculty owns this group
    const group = await Group.findOne({ _id: groupId, facultyId: _id });
    if (!group) {
      return ResponseApi(res, 404, 'Group not found or you do not have permission to create quiz in this group');
    }

    const sanitizedSettings: IQuizSettings = {
      timeLimitMinutes: typeof settings?.timeLimitMinutes === 'number' && settings.timeLimitMinutes > 0
        ? settings.timeLimitMinutes
        : null,
      shuffleQuestions: Boolean(settings?.shuffleQuestions),
      allowBackNavigation: settings?.allowBackNavigation === false ? false : true,
      passingScore: typeof settings?.passingScore === 'number' && settings.passingScore >= 0 && settings.passingScore <= 100
        ? settings.passingScore
        : null,
      instructions: typeof settings?.instructions === 'string' ? settings.instructions.trim() : ''
    };

    const newQuiz = new Quiz({
      name,
      facultyId: _id,
      groupId,
      settings: sanitizedSettings
    });
    await newQuiz.save();

    const populatedQuiz = await Quiz.findById(newQuiz._id)
      .populate({
        path: 'groupId',
        select: 'name courseId',
        populate: {
          path: 'courseId',
          select: 'courseName courseCode'
        }
      })
      .populate('facultyId', 'email');

    return ResponseApi(res, 201, 'Quiz created successfully', populatedQuiz);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while creating the quiz');
  }
};

const getMyQuizzes = async (req: Request, res: Response) => {
  try {
    const { _id } = req.body; // Faculty ID from middleware

    const quizzes = await Quiz.find({ facultyId: _id })
      .populate({
        path: 'groupId',
        select: 'name courseId',
        populate: {
          path: 'courseId',
          select: 'courseName courseCode'
        }
      })
        .populate('facultyId', 'email') as IQuiz[];

    return ResponseApi(res, 200, 'Quizzes retrieved successfully', quizzes);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting quizzes');
  }
};

  const updateQuizSettings = async (req: Request, res: Response) => {
    try {
      const { quizId } = req.params;
      const { _id } = req.body; // Faculty ID from middleware
      const { timeLimitMinutes, shuffleQuestions, allowBackNavigation, passingScore, instructions } = req.body;

      if (!quizId) {
        return ResponseApi(res, 400, 'Quiz ID is required');
      }

      const quiz = await Quiz.findOne({ _id: quizId, facultyId: _id });
      if (!quiz) {
        return ResponseApi(res, 404, 'Quiz not found or you do not have permission to update it');
      }

      const updatedSettings: Partial<IQuizSettings> = {};
      if (timeLimitMinutes === null || timeLimitMinutes === undefined) {
        updatedSettings.timeLimitMinutes = null;
      } else if (typeof timeLimitMinutes === 'number' && timeLimitMinutes > 0) {
        updatedSettings.timeLimitMinutes = timeLimitMinutes;
      }

      if (typeof shuffleQuestions === 'boolean') {
        updatedSettings.shuffleQuestions = shuffleQuestions;
      }

      if (typeof allowBackNavigation === 'boolean') {
        updatedSettings.allowBackNavigation = allowBackNavigation;
      }

      if (passingScore === null || passingScore === undefined) {
        updatedSettings.passingScore = null;
      } else if (typeof passingScore === 'number' && passingScore >= 0 && passingScore <= 100) {
        updatedSettings.passingScore = passingScore;
      }

      if (typeof instructions === 'string') {
        updatedSettings.instructions = instructions.trim();
      }

      quiz.settings = {
        ...quiz.settings,
        ...updatedSettings,
      };

      await quiz.save();

      return ResponseApi(res, 200, 'Quiz settings updated successfully', quiz);
    } catch (error) {
      return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while updating quiz settings');
    }
  };

const addQuizQuestion = async (req: Request, res: Response) => {
  try {
    const { quizId, questionText, questionImage, options, answer, questionType } = req.body;
    const { _id } = req.body; // Faculty ID from middleware

    if (!quizId || !questionText || !answer) {
      return ResponseApi(res, 400, 'Please provide required fields for the question');
    }

    // Verify faculty owns this quiz
    const quiz = await Quiz.findOne({ _id: quizId, facultyId: _id });
    if (!quiz) {
      return ResponseApi(res, 404, 'Quiz not found or you do not have permission to modify it');
    }

    const normalizedType: QuizQuestionType = questionType === 'text' ? 'text' : 'multiple-choice';
    const sanitizedOptions = Array.isArray(options)
      ? options.filter((opt: string) => typeof opt === 'string' && opt.trim() !== '').map((opt: string) => opt.trim())
      : [];

    if (normalizedType === 'multiple-choice') {
      if (sanitizedOptions.length < 2) {
        return ResponseApi(res, 400, 'At least 2 options are required for multiple choice questions');
      }
      if (!sanitizedOptions.includes(answer)) {
        return ResponseApi(res, 400, 'Answer must be one of the provided options');
      }
    }

    const newQuestion = new QuizQuestion({
      quizId,
      questionText,
      questionImage,
      questionType: normalizedType,
      options: normalizedType === 'multiple-choice' ? sanitizedOptions : [],
      answer: answer.trim()
    });
    await newQuestion.save();

    return ResponseApi(res, 201, 'Question added successfully', newQuestion);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while adding the question');
  }
};

const getQuizQuestions = async (req: Request, res: Response) => {
  try {
    const { quizId } = req.params;
    const { _id } = req.body; // Faculty ID from middleware

    // Verify faculty owns this quiz
    const quiz = await Quiz.findOne({ _id: quizId, facultyId: _id });
    if (!quiz) {
      return ResponseApi(res, 404, 'Quiz not found or you do not have permission to view it');
    }

    const questions = await QuizQuestion.find({ quizId }) as IQuizQuestion[];

    return ResponseApi(res, 200, 'Quiz questions retrieved successfully', questions);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting quiz questions');
  }
};

const getQuizResults = async (req: Request, res: Response) => {
  try {
    const { quizId } = req.params;
    const { _id } = req.body; // Faculty ID from middleware

    // Verify faculty owns this quiz
    const quiz = await Quiz.findOne({ _id: quizId, facultyId: _id });
    if (!quiz) {
      return ResponseApi(res, 404, 'Quiz not found or you do not have permission to view results');
    }

    const results = await QuizResult.find({ quizId })
      .populate('userId', 'email')
      .populate('quizId', 'name') as unknown as IQuizResult[];

    const formattedResults = results.map(result => {
      const studentDoc = result.userId as unknown as IUser | null;

      return {
        _id: result._id,
        studentId: studentDoc
          ? {
            _id: String(studentDoc._id),
            email: studentDoc.email
          }
          : null,
        score: result.correctAnswers,
        percentage: result.marks,
        totalQuestions: result.totalQuestions,
        submittedAt: result.createdAt
      };
    });

    return ResponseApi(res, 200, 'Quiz results retrieved successfully', formattedResults);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting quiz results');
  }
};

const updateStudentMarks = async (req: Request, res: Response) => {
  try {
    const { groupId, studentId } = req.params;
    const { _id } = req.body; // Faculty ID from middleware
    const {
      midSemMarks,
      endSemMarks,
      midSemMaxMarks,
      endSemMaxMarks,
    } = req.body;

    if (!groupId || !studentId) {
      return ResponseApi(res, 400, 'Group ID and student ID are required');
    }

    const group = await Group.findOne({ _id: groupId, facultyId: _id });
    if (!group) {
      return ResponseApi(res, 404, 'Group not found or you do not have permission to modify its assessments');
    }

    const registration = await GroupRegistration.findOne({ groupId, userId: studentId });
    if (!registration) {
      return ResponseApi(res, 404, 'Student is not registered in this group');
    }

    const parseOptionalNumber = (
      value: unknown,
      {
        allowNull = true,
        min = 0,
        fieldLabel,
      }: { allowNull?: boolean; min?: number; fieldLabel: string }
    ) => {
      if (value === undefined) {
        return { shouldUpdate: false as const };
      }

      if (value === null || (typeof value === 'string' && value.trim() === '')) {
        if (allowNull) {
          return { shouldUpdate: true as const, value: null };
        }
        return { error: `${fieldLabel} is required` };
      }

      const numericValue = Number(value);
      if (!Number.isFinite(numericValue)) {
        return { error: `${fieldLabel} must be a valid number` };
      }

      if (numericValue < min) {
        return { error: `${fieldLabel} cannot be less than ${min}` };
      }

      return { shouldUpdate: true as const, value: numericValue };
    };

    const updates: Record<string, unknown> = {};
    const midMarksResult = parseOptionalNumber(midSemMarks, {
      allowNull: true,
      min: 0,
      fieldLabel: 'Mid-semester marks',
    });
    if ('error' in midMarksResult) {
      return ResponseApi(res, 400, midMarksResult.error || 'Invalid end-semester maximum marks');
    }
    if (midMarksResult.shouldUpdate) {
      updates.midSemMarks = midMarksResult.value;
    }

    const endMarksResult = parseOptionalNumber(endSemMarks, {
      allowNull: true,
      min: 0,
      fieldLabel: 'End-semester marks',
    });
    if ('error' in endMarksResult) {
      return ResponseApi(res, 400, endMarksResult.error || 'Invalid end-semester maximum marks');
    }
    if (endMarksResult.shouldUpdate) {
      updates.endSemMarks = endMarksResult.value;
    }

    const midMaxResult = parseOptionalNumber(midSemMaxMarks, {
      allowNull: false,
      min: 1,
      fieldLabel: 'Mid-semester maximum marks',
    });
    if ('error' in midMaxResult) {
      return ResponseApi(res, 400, midMaxResult.error || 'Invalid end-semester maximum marks');
    }
    if (midMaxResult.shouldUpdate) {
      updates.midSemMaxMarks = midMaxResult.value;
    }

    const endMaxResult = parseOptionalNumber(endSemMaxMarks, {
      allowNull: false,
      min: 1,
      fieldLabel: 'End-semester maximum marks',
    });
    if ('error' in endMaxResult) {
      return ResponseApi(res, 400, endMaxResult.error || 'Invalid end-semester maximum marks');
    }
    if (endMaxResult.shouldUpdate) {
      updates.endSemMaxMarks = endMaxResult.value;
    }

    const resolvedMidMax = (updates.midSemMaxMarks as number | undefined) ?? registration.midSemMaxMarks ?? 100;
    const resolvedEndMax = (updates.endSemMaxMarks as number | undefined) ?? registration.endSemMaxMarks ?? 100;
    const resolvedMidMarks = (updates.midSemMarks as number | null | undefined) ?? registration.midSemMarks ?? null;
    const resolvedEndMarks = (updates.endSemMarks as number | null | undefined) ?? registration.endSemMarks ?? null;

    if (typeof resolvedMidMarks === 'number' && resolvedMidMarks > resolvedMidMax) {
      return ResponseApi(res, 400, 'Mid-semester marks cannot exceed the configured maximum');
    }

    if (typeof resolvedEndMarks === 'number' && resolvedEndMarks > resolvedEndMax) {
      return ResponseApi(res, 400, 'End-semester marks cannot exceed the configured maximum');
    }

    if (Object.keys(updates).length === 0) {
      return ResponseApi(res, 200, 'No assessment changes detected');
    }

    updates.assessmentUpdatedBy = _id;
    updates.assessmentUpdatedAt = new Date();
    updates.approved = true;
    updates.status = 'approved';

    const updatedRegistration = await GroupRegistration.findOneAndUpdate(
      { groupId, userId: studentId },
      { $set: updates },
      { new: true }
    )
      .populate('userId', 'email')
      .populate('groupId', 'name')
      .populate('assessmentUpdatedBy', 'email');

    if (!updatedRegistration) {
      return ResponseApi(res, 500, 'Unable to update student marks');
    }

    await recomputeGroupGrades(groupId);

    const refreshedRegistration = await GroupRegistration.findById(updatedRegistration._id)
      .populate('userId', 'email')
      .populate('groupId', 'name')
      .populate('assessmentUpdatedBy', 'email');

    const formatted = refreshedRegistration?.toObject() ?? updatedRegistration.toObject();

    return ResponseApi(res, 200, 'Student assessment updated successfully', {
      ...formatted,
      approved: formatted.approved ?? true,
      status: formatted.status ?? (formatted.approved ? 'approved' : 'pending'),
      midSemMarks: formatted.midSemMarks ?? null,
      endSemMarks: formatted.endSemMarks ?? null,
      midSemMaxMarks: formatted.midSemMaxMarks ?? resolvedMidMax,
      endSemMaxMarks: formatted.endSemMaxMarks ?? resolvedEndMax,
      totalEvaluatedScore: formatted.totalEvaluatedScore ?? null,
      totalEvaluatedMaxScore: formatted.totalEvaluatedMaxScore ?? null,
      finalPercentage: formatted.finalPercentage ?? null,
      finalGrade: formatted.finalGrade ?? null,
      relativeRank: formatted.relativeRank ?? null,
      hasCompleteAssessment: formatted.hasCompleteAssessment ?? false,
    });
  } catch (error) {
    return ResponseApi(
      res,
      500,
      error instanceof Error ? error.message : 'An unknown error occurred while updating student marks'
    );
  }
};

const getGroupRegistrations = async (req: Request, res: Response) => {
  try {
    const { groupId } = req.params;
    const { _id } = req.body; // Faculty ID from middleware

    const group = await Group.findOne({ _id: groupId, facultyId: _id });
    if (!group) {
      return ResponseApi(res, 404, 'Group not found or you do not have permission to view registrations');
    }

    await recomputeGroupGrades(groupId);

    const registrations = await GroupRegistration.find({ groupId })
      .populate('userId', 'email')
      .populate('groupId', 'name')
      .populate('assessmentUpdatedBy', 'email');

    const extractEntityId = (value: unknown): string | null => {
      if (!value) {
        return null;
      }

      if (typeof value === 'string') {
        return value;
      }

      if (value instanceof Types.ObjectId) {
        return value.toHexString();
      }

      if (typeof value === 'object' && '_id' in (value as Record<string, unknown>)) {
        const nested = (value as Record<string, unknown>)._id;
        if (typeof nested === 'string') {
          return nested;
        }
        if (nested instanceof Types.ObjectId) {
          return nested.toHexString();
        }
      }

      return null;
    };

    const userIds = registrations
      .map((registration) => extractEntityId(registration.userId))
      .filter((maybeId): maybeId is string => Boolean(maybeId));

    const quizzes = await Quiz.find({ groupId }).select('_id name').lean();
    const quizMap = new Map<string, { name: string }>();
    const quizIds = quizzes.map((quiz) => {
      const quizId = quiz._id instanceof Types.ObjectId ? quiz._id : new Types.ObjectId(String(quiz._id));
      quizMap.set(quizId.toHexString(), { name: quiz.name ?? 'Quiz' });
      return quizId;
    });

    const quizSummariesByUser = new Map<
      string,
      {
        totalCorrect: number;
        totalQuestions: number;
        perQuiz: Array<{ quizId: string; name: string; correctAnswers: number; totalQuestions: number }>;
      }
    >();

    if (quizIds.length > 0 && userIds.length > 0) {
      const quizResults = await QuizResult.find({
        quizId: { $in: quizIds },
        userId: { $in: userIds },
      })
        .select('quizId userId correctAnswers totalQuestions')
        .lean();

      const interim = new Map<string, Array<{ quizId: string; name: string; correctAnswers: number; totalQuestions: number }>>();

      quizResults.forEach((result) => {
        const userKey = extractEntityId(result.userId);
        const quizKey = extractEntityId(result.quizId);

        if (!userKey || !quizKey) {
          return;
        }

        const quizName = quizMap.get(quizKey)?.name ?? 'Quiz';
        const bucket = interim.get(userKey) ?? [];
        bucket.push({
          quizId: quizKey,
          name: quizName,
          correctAnswers: typeof result.correctAnswers === 'number' ? result.correctAnswers : 0,
          totalQuestions: typeof result.totalQuestions === 'number' ? result.totalQuestions : 0,
        });
        interim.set(userKey, bucket);
      });

      interim.forEach((entries, userKey) => {
        const sortedEntries = [...entries].sort((a, b) => a.name.localeCompare(b.name));
        const totalCorrect = sortedEntries.reduce((sum, entry) => sum + entry.correctAnswers, 0);
        const totalQuestions = sortedEntries.reduce((sum, entry) => sum + entry.totalQuestions, 0);

        quizSummariesByUser.set(userKey, {
          totalCorrect,
          totalQuestions,
          perQuiz: sortedEntries,
        });
      });
    }

    const formatted = registrations.map((entry) => {
      const payload = entry.toObject();
      const approved = payload.approved ?? true;
      const status = payload.status ?? (approved ? 'approved' : 'pending');
      const userKey = extractEntityId(payload.userId);
      const quizSummary = userKey ? quizSummariesByUser.get(userKey) ?? null : null;

      return {
        ...payload,
        approved,
        status,
        midSemMarks: payload.midSemMarks ?? null,
        endSemMarks: payload.endSemMarks ?? null,
        midSemMaxMarks: payload.midSemMaxMarks ?? 100,
        endSemMaxMarks: payload.endSemMaxMarks ?? 100,
        totalEvaluatedScore: payload.totalEvaluatedScore ?? null,
        totalEvaluatedMaxScore: payload.totalEvaluatedMaxScore ?? null,
        finalPercentage: payload.finalPercentage ?? null,
        finalGrade: payload.finalGrade ?? null,
        relativeRank: payload.relativeRank ?? null,
        hasCompleteAssessment: payload.hasCompleteAssessment ?? false,
        quizSummary,
        assessmentUpdatedBy: payload.assessmentUpdatedBy ?? null,
        assessmentUpdatedAt: payload.assessmentUpdatedAt ?? null,
      };
    });

    return ResponseApi(res, 200, 'Group registrations retrieved successfully', formatted);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting group registrations');
  }
};

const verifyFaculty = async (req: Request, res: Response) => {
  try {
    const { _id, role } = req.body;

    if (_id === undefined || role === undefined) {
      return ResponseApi(res, 403, 'Forbidden');
    }

    const faculty = await User.findById(_id).select('-password');
    if (!faculty || faculty.role !== 'faculty') {
      return ResponseApi(res, 400, "No Such Faculty")
    }

    return ResponseApi(res, 200, 'Faculty verified successfully', faculty);
  } catch (error) {
    return ResponseApi(
      res,
      500,
      error instanceof Error
        ? error.message
        : 'An unknown error occurred while verifying the faculty'
    )
  }
}

const updateProfile = async (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    const { _id, role } = req.body; // Provided by facultyMiddleware

    if (!email) {
      return ResponseApi(res, 400, 'Email is required');
    }

    if (role !== 'faculty') {
      return ResponseApi(res, 403, 'Forbidden: Faculty access required');
    }

    await User.findByIdAndUpdate(
      _id,
      {
        email: email.toLowerCase(),
      }
    )

    return ResponseApi(res, 200, 'Faculty profile updated successfully');
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while updating the faculty profile');
  }
}

const changePassword = async (req: Request, res: Response) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const { _id, role } = req.body; // Provided by facultyMiddleware

    if (!currentPassword || !newPassword) {
      return ResponseApi(res, 400, 'Current password and new password are required');
    }

    if (newPassword.length < 6 || newPassword.length > 20) {
      return ResponseApi(res, 400, 'New password must be at least 6 and at most 20 characters');
    }

    if (role !== 'faculty') {
      return ResponseApi(res, 403, 'Forbidden: Faculty access required');
    }

    const faculty = await User.findById(_id);
    if (!faculty) {
      return ResponseApi(res, 404, 'Faculty not found');
    }

    const isCurrentPasswordValid = await bcrypt.compare(currentPassword, faculty.password);
    if (!isCurrentPasswordValid) {
      return ResponseApi(res, 400, 'Current password is incorrect');
    }

    const genSalt = await bcrypt.genSalt(5);
    const hashedNewPassword = await bcrypt.hash(newPassword, genSalt);

    await User.findByIdAndUpdate(_id, { password: hashedNewPassword });

    return ResponseApi(res, 200, 'Password changed successfully');
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while changing the password');
  }
}

export {
  register,
  login,
  createCourse,
  getMyCourses,
  getDashboardStats,
  createGroup,
  getMyGroups,
  updateGroup,
  createQuiz,
  getMyQuizzes,
  updateQuizSettings,
  addQuizQuestion,
  getQuizQuestions,
  getQuizResults,
  updateStudentMarks,
  getGroupRegistrations,
  verifyFaculty,
  updateProfile,
  changePassword,
};
