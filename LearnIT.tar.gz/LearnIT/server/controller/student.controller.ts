import { User, Course, Group, Quiz, CourseRegistration, GroupRegistration, QuizQuestion, QuizResult } from '../model/model';
import { IUser } from '../model/schema/user.schema';
import { ICourse } from '../model/schema/course.schema';
import { IGroup } from '../model/schema/group.schema';
import { IQuiz } from '../model/schema/quiz.schema';
import { IQuizQuestion } from '../model/schema/quizQuestion.schema';
import { IQuizResult } from '../model/schema/quizResult.schema';
import { ICourseRegistration } from '../model/schema/courseRegistration.schema';
import { IGroupRegistration } from '../model/schema/groupRegistration.schema';
import { JwtPayload } from '../types/auth.types';
import ResponseApi from '../util/ApiResponse.util';
import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { recomputeGroupGrades } from '../util/grade.util';
import { Types } from 'mongoose';

const register = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return ResponseApi(res, 400, 'Please provide all required fields');
    }

    // Check if email ends with @iiitdwd.ac.in
    if (!email.toLowerCase().endsWith('@iiitdwd.ac.in')) {
      return ResponseApi(res, 400, 'Only @iiitdwd.ac.in email addresses are allowed');
    }

    // Check if email follows student ID format: 2 numbers, 3 letters, 3 numbers
    const emailPrefix = email.toLowerCase().split('@')[0];
    const studentIdPattern = /^\d{2}[a-z]{3}\d{3}$/;
    if (!studentIdPattern.test(emailPrefix)) {
      return ResponseApi(res, 400, 'Student email must follow format: 2 digits + 3 letters + 3 digits (e.g., 23bec001@iiitdwd.ac.in)');
    }

    if (password.length < 6 || password.length > 20) {
      return ResponseApi(
        res,
        400,
        'Password must be at least 6 and at most 20 characters'
      );
    }

    const existingUser = (await User.findOne({
      email: email.toLowerCase(),
    })) as IUser | null;
    if (existingUser) {
      return ResponseApi(res, 400, 'User already exists');
    }

    const genSalt = await bcrypt.genSalt(5);
    const hashedPassword = await bcrypt.hash(password, genSalt);

    const newStudent: IUser = new User({
      email: email.toLowerCase(),
      password: hashedPassword,
      role: 'student'
    });
    await newStudent.save();

    return ResponseApi(res, 201, 'Student registered successfully');
  } catch (error) {
    return ResponseApi(
      res,
      500,
      error instanceof Error
        ? error.message
        : 'An unknown error occurred while registering the student'
    );
  }
};

const login = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return ResponseApi(res, 400, 'Please provide all required fields');
    }

    const existingStudent = (await User.findOne({
      email: email.toLowerCase(),
      role: 'student'
    })) as IUser | null;
    if (!existingStudent) {
      return ResponseApi(res, 400, 'Student does not exist');
    }

    const isPasswordValid = await bcrypt.compare(
      password,
      existingStudent.password
    );
    if (!isPasswordValid) {
      return ResponseApi(res, 400, 'Invalid password');
    }

    if (!process.env.JWT_SECRET_KEY) {
      return ResponseApi(res, 500, 'JWT secret key is not defined');
    }

    const payload: JwtPayload = {
      _id: String(existingStudent._id),
      role: 'student',
    };

    const token = jwt.sign(
      payload,
      process.env.JWT_SECRET_KEY,
      { expiresIn: '30d' }
    );

    return ResponseApi(res, 200, 'Student logged in successfully', token);
  } catch (error) {
    return ResponseApi(
      res,
      500,
      error instanceof Error
        ? error.message
        : 'An unknown error occurred while logging in the student'
    );
  }
};

const getAllCourses = async (req: Request, res: Response) => {
  try {
    const courses = await Course.find({}) as ICourse[];
    return ResponseApi(res, 200, 'Courses retrieved successfully', courses);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting courses');
  }
};

const registerForCourse = async (req: Request, res: Response) => {
  try {
    const { courseId } = req.body;
    const { _id } = req.body; // Student ID from middleware

    if (!courseId) {
      return ResponseApi(res, 400, 'Course ID is required');
    }

    // Verify course exists
    const course = await Course.findById(courseId);
    if (!course) {
      return ResponseApi(res, 404, 'Course not found');
    }

    // Check if already registered
    const existingRegistration = await CourseRegistration.findOne({
      courseId,
      userId: _id
    });
    if (existingRegistration) {
      return ResponseApi(res, 400, 'Already registered for this course');
    }

    const newRegistration = new CourseRegistration({
      courseId,
      userId: _id
    });
    await newRegistration.save();

    const populatedRegistration = await CourseRegistration.findById(newRegistration._id)
      .populate('courseId', 'courseName courseCode courseCredit')
      .populate('userId', 'email');

    return ResponseApi(res, 201, 'Course registration successful', populatedRegistration);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while registering for the course');
  }
};

const getMyCourses = async (req: Request, res: Response) => {
  try {
    const { _id } = req.body; // Student ID from middleware

    const registrations = await CourseRegistration.find({ userId: _id })
      .populate('courseId', 'courseName courseCode courseCredit') as ICourseRegistration[];

    const courses = registrations.map(registration => registration.courseId);

    return ResponseApi(res, 200, 'My courses retrieved successfully', courses);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting your courses');
  }
};

const getAvailableGroups = async (req: Request, res: Response) => {
  try {
    const { _id } = req.body; // Student ID from middleware

    // Get courses the student is registered for
    const registrations = await CourseRegistration.find({ userId: _id });
    const courseIds = registrations.map((reg) => reg.courseId);

    if (courseIds.length === 0) {
      return ResponseApi(res, 200, 'Available groups retrieved successfully', []);
    }

    // Exclude groups the student is already part of
    const registeredGroupIds = await GroupRegistration.distinct('groupId', { userId: _id });

    // Get groups for those courses that have registration open and not already joined
    const groups = await Group.find({
      courseId: { $in: courseIds },
      registrationOpen: true,
      _id: { $nin: registeredGroupIds }
    })
      .populate('courseId', 'courseName courseCode')
      .populate('facultyId', 'email') as IGroup[];

    return ResponseApi(res, 200, 'Available groups retrieved successfully', groups);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting available groups');
  }
};

const registerForGroup = async (req: Request, res: Response) => {
  try {
    const { groupId } = req.body;
    const { _id } = req.body; // Student ID from middleware

    if (!groupId) {
      return ResponseApi(res, 400, 'Group ID is required');
    }

    // Verify group exists and registration is open
    const group = await Group.findById(groupId).populate('courseId');
    if (!group) {
      return ResponseApi(res, 404, 'Group not found');
    }

    if (!group.registrationOpen) {
      return ResponseApi(res, 400, 'Registration is not open for this group');
    }

    // Verify student is registered for the course
    const courseRegistration = await CourseRegistration.findOne({
      courseId: group.courseId,
      userId: _id
    });
    if (!courseRegistration) {
      return ResponseApi(res, 400, 'You must be registered for the course first');
    }

    // Check if already registered for this group
    const existingRegistration = await GroupRegistration.findOne({
      groupId,
      userId: _id
    });
    if (existingRegistration) {
      return ResponseApi(res, 400, 'Already registered for this group');
    }

    const newRegistration = new GroupRegistration({
      groupId,
      userId: _id
    });
    await newRegistration.save();

    const populatedRegistration = await GroupRegistration.findById(newRegistration._id)
      .populate('groupId', 'name')
      .populate('userId', 'email');

    return ResponseApi(res, 201, 'Group registration successful', populatedRegistration);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while registering for the group');
  }
};

const getMyGroups = async (req: Request, res: Response) => {
  try {
    const { _id } = req.body; // Student ID from middleware

    const registrations = await GroupRegistration.find({ userId: _id })
      .populate({
        path: 'groupId',
        populate: {
          path: 'courseId',
          select: 'courseName courseCode'
        }
      })
      .populate({
        path: 'groupId',
        populate: {
          path: 'facultyId',
          select: 'email'
        }
      }) as IGroupRegistration[];

    const groups = registrations.map(registration => registration.groupId);

    return ResponseApi(res, 200, 'My groups retrieved successfully', groups);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting your groups');
  }
};

const getMyCourseGrades = async (req: Request, res: Response) => {
  try {
    const { _id } = req.body; // Student ID from middleware

    const registrations = await GroupRegistration.find({ userId: _id })
      .populate({
        path: 'groupId',
        select: 'name courseId',
        populate: {
          path: 'courseId',
          select: 'courseName courseCode courseCredit',
        },
      })
      .populate('assessmentUpdatedBy', 'email');

    if (registrations.length === 0) {
      return ResponseApi(res, 200, 'No course registrations found', []);
    }

    const groupIds = registrations
      .map((registration) => {
        const groupDoc = registration.groupId as unknown as IGroup | null;
        return groupDoc?._id ? String(groupDoc._id) : null;
      })
      .filter((maybeId): maybeId is string => Boolean(maybeId));

    const uniqueGroupIds = Array.from(new Set(groupIds));

    const quizzes = await Quiz.find({ groupId: { $in: uniqueGroupIds } }).select('name groupId');

    const quizIds = quizzes.map((quiz) => quiz._id);
    const quizMap = new Map(
      quizzes.map((quiz) => [
        String(quiz._id),
        {
          _id: String(quiz._id),
          name: quiz.name,
          groupId: String(quiz.groupId),
        },
      ])
    );

    const quizResults = await QuizResult.find({
      userId: _id,
      quizId: { $in: quizIds },
    }).select('quizId marks createdAt');

    const quizResultsByGroup = new Map<string, Array<{ quizId: string; name: string; marks: number; attemptedAt: Date }>>();

    quizResults.forEach((result) => {
      const quizInfo = quizMap.get(String(result.quizId));
      if (!quizInfo) {
        return;
      }
      const groupKey = quizInfo.groupId;
      const bucket = quizResultsByGroup.get(groupKey) ?? [];
      bucket.push({
        quizId: quizInfo._id,
        name: quizInfo.name,
        marks: typeof result.marks === 'number' ? result.marks : 0,
        attemptedAt: result.createdAt,
      });
      quizResultsByGroup.set(groupKey, bucket);
    });

    const gradeSummaries = registrations.map((registration) => {
      const entry = registration.toObject();
      const groupDoc = entry.groupId as unknown as (IGroup & { courseId?: ICourse | string }) | undefined;
      const courseDoc = groupDoc?.courseId as (ICourse | { _id?: string; courseName?: string; courseCode?: string; courseCredit?: number }) | undefined;

      const groupIdValue = groupDoc?._id ? String(groupDoc._id) : '';
      const courseIdValue = courseDoc && typeof courseDoc === 'object' && '_id' in courseDoc && courseDoc._id
        ? String(courseDoc._id)
        : null;

      const quizBreakdown = quizResultsByGroup.get(groupIdValue) ?? [];
      const totalQuizMarks = quizBreakdown.reduce((sum, quiz) => sum + (typeof quiz.marks === 'number' ? quiz.marks : 0), 0);
      const quizOutOf = quizBreakdown.length * 100;

      const midSemMarks = typeof entry.midSemMarks === 'number' ? entry.midSemMarks : null;
      const endSemMarks = typeof entry.endSemMarks === 'number' ? entry.endSemMarks : null;
      const midSemMaxMarks = typeof entry.midSemMaxMarks === 'number'
        ? entry.midSemMaxMarks
        : midSemMarks !== null
          ? 100
          : null;
      const endSemMaxMarks = typeof entry.endSemMaxMarks === 'number'
        ? entry.endSemMaxMarks
        : endSemMarks !== null
          ? 100
          : null;

      const totalObtained = (midSemMarks ?? 0) + (endSemMarks ?? 0) + totalQuizMarks;
      const totalOutOf = (midSemMaxMarks ?? 0) + (endSemMaxMarks ?? 0) + quizOutOf;
      const snapshotTotalScore = typeof entry.totalEvaluatedScore === 'number' ? entry.totalEvaluatedScore : Number(totalObtained.toFixed(2));
      const snapshotMaxScore = typeof entry.totalEvaluatedMaxScore === 'number' ? entry.totalEvaluatedMaxScore : totalOutOf;
      const computedPercentage = snapshotMaxScore > 0 ? Number(((snapshotTotalScore / snapshotMaxScore) * 100).toFixed(2)) : null;
      const finalPercentage = typeof entry.finalPercentage === 'number' ? entry.finalPercentage : computedPercentage;

      const updatedBy = entry.assessmentUpdatedBy as (IUser | { _id?: string; email?: string }) | undefined;

      return {
        registrationId: String(entry._id),
        course: courseIdValue
          ? {
            _id: courseIdValue,
            courseName: (courseDoc as ICourse)?.courseName ?? 'Course',
            courseCode: (courseDoc as ICourse)?.courseCode ?? '',
            courseCredit: (courseDoc as ICourse)?.courseCredit ?? null,
          }
          : null,
        group: groupIdValue
          ? {
            _id: groupIdValue,
            name: groupDoc?.name ?? 'Group',
          }
          : null,
        assessments: {
          midSem: {
            obtained: midSemMarks,
            outOf: midSemMaxMarks,
          },
          endSem: {
            obtained: endSemMarks,
            outOf: endSemMaxMarks,
          },
          quizzes: quizBreakdown.map((quiz) => ({
            quizId: quiz.quizId,
            name: quiz.name,
            marks: quiz.marks,
            attemptedAt: quiz.attemptedAt,
          })),
        },
        totals: {
          obtained: snapshotTotalScore,
          outOf: snapshotMaxScore,
          percentage: finalPercentage,
        },
        grading: {
          hasCompleteAssessment: entry.hasCompleteAssessment ?? false,
          finalGrade: entry.finalGrade ?? null,
          finalPercentage,
          relativeRank: typeof entry.relativeRank === 'number' ? entry.relativeRank : null,
        },
        approved: entry.approved ?? true,
        status: entry.status ?? ((entry.approved ?? true) ? 'approved' : 'pending'),
        assessmentUpdatedAt: entry.assessmentUpdatedAt ?? null,
        assessmentUpdatedBy: updatedBy
          ? {
            _id: updatedBy._id ? String(updatedBy._id) : undefined,
            email: updatedBy.email,
          }
          : null,
      };
    });

    return ResponseApi(res, 200, 'Course grades retrieved successfully', gradeSummaries);
  } catch (error) {
    return ResponseApi(
      res,
      500,
      error instanceof Error ? error.message : 'An unknown error occurred while fetching course grades'
    );
  }
};

const getAvailableQuizzes = async (req: Request, res: Response) => {
  try {
    const { _id } = req.body; // Student ID from middleware

    // Get groups the student is registered for
    const registrations = await GroupRegistration.find({
      userId: _id,
      status: { $ne: 'rejected' },
    });

    const resolvedGroupIds = registrations
      .map((registration) => {
        const raw = registration.groupId;
        if (raw instanceof Types.ObjectId) {
          return raw;
        }

        if (raw && typeof raw === 'object' && '_id' in raw) {
          const potentialId = (raw as { _id?: unknown })._id;
          if (typeof potentialId === 'string' && Types.ObjectId.isValid(potentialId)) {
            return new Types.ObjectId(potentialId);
          }
          if (potentialId instanceof Types.ObjectId) {
            return potentialId;
          }
        }

        return undefined;
      })
      .filter((maybeId): maybeId is Types.ObjectId => Boolean(maybeId));

    const uniqueGroupIds = Array.from(
      new Set(resolvedGroupIds.map((id) => id.toHexString()))
    ).map((id) => new Types.ObjectId(id));

    if (uniqueGroupIds.length === 0) {
      return ResponseApi(res, 200, 'Available quizzes retrieved successfully', []);
    }

    const attemptedQuizIds = await QuizResult.distinct('quizId', { userId: _id });

    // Get quizzes for those groups excluding already attempted ones
    const quizzes = await Quiz.find({
      groupId: { $in: uniqueGroupIds },
      _id: { $nin: attemptedQuizIds }
    })
      .populate({
        path: 'groupId',
        select: 'name courseId',
        populate: {
          path: 'courseId',
          select: 'courseName courseCode'
        }
      })
      .populate('facultyId', 'email') as IQuiz[];

    return ResponseApi(res, 200, 'Available quizzes retrieved successfully', quizzes);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting available quizzes');
  }
};

const getQuizQuestions = async (req: Request, res: Response) => {
  try {
    const { quizId } = req.params;
    const { _id } = req.body; // Student ID from middleware

    // Verify student has access to this quiz
    const quiz = await Quiz.findById(quizId) as IQuiz | null;
    if (!quiz) {
      return ResponseApi(res, 404, 'Quiz not found');
    }

    // Check if student is registered for the group
    const groupRegistration = await GroupRegistration.findOne({
      groupId: quiz.groupId,
      userId: _id
    });
    if (!groupRegistration) {
      return ResponseApi(res, 403, 'You do not have access to this quiz');
    }

    // Get questions without answers for student
    let questions = await QuizQuestion.find({ quizId }).select('-answer') as IQuizQuestion[];

    if (quiz.settings?.shuffleQuestions) {
      questions = [...questions].sort(() => Math.random() - 0.5);
    }

    return ResponseApi(res, 200, 'Quiz questions retrieved successfully', questions);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting quiz questions');
  }
};

const submitQuiz = async (req: Request, res: Response) => {
  try {
    const { quizId, answers } = req.body; // answers should be an array of { questionId, selectedAnswer }
    const { _id } = req.body; // Student ID from middleware

    if (!quizId || !answers || !Array.isArray(answers)) {
      return ResponseApi(res, 400, 'Quiz ID and answers array are required');
    }

    // Verify student has access to this quiz
    const quiz = await Quiz.findById(quizId);
    if (!quiz) {
      return ResponseApi(res, 404, 'Quiz not found');
    }

    const groupRegistration = await GroupRegistration.findOne({
      groupId: quiz.groupId,
      userId: _id
    });
    if (!groupRegistration) {
      return ResponseApi(res, 403, 'You do not have access to this quiz');
    }

    // Check if already submitted
    const existingResult = await QuizResult.findOne({
      quizId,
      userId: _id
    });
    if (existingResult) {
      return ResponseApi(res, 400, 'Quiz already submitted');
    }

    // Get all questions with correct answers
    const questions = await QuizQuestion.find({ quizId }) as IQuizQuestion[];
    
    // Calculate score
    let correctAnswers = 0;
    let totalQuestions = questions.length;

    for (const answer of answers) {
      const question = questions.find(q => String(q._id) === answer.questionId);
      if (!question) {
        continue;
      }

      const submittedAnswer = typeof answer.selectedAnswer === 'string' ? answer.selectedAnswer : '';

      if (question.questionType === 'text') {
        if (submittedAnswer.trim().toLowerCase() === question.answer.trim().toLowerCase()) {
          correctAnswers++;
        }
      } else if (question.questionType === 'multiple-choice') {
        if (submittedAnswer === question.answer) {
          correctAnswers++;
        }
      }
    }

    const marks = totalQuestions > 0 ? (correctAnswers / totalQuestions) * 100 : 0;

    // Save result
    const quizResult = new QuizResult({
      quizId,
      userId: _id,
      marks,
      correctAnswers,
      totalQuestions
    });
    await quizResult.save();

    const populatedResult = await QuizResult.findById(quizResult._id)
      .populate('quizId', 'name')
      .populate('userId', 'email');

    await recomputeGroupGrades(quiz.groupId);

    return ResponseApi(res, 201, 'Quiz submitted successfully', {
      result: populatedResult,
      score: `${correctAnswers}/${totalQuestions}`,
      percentage: marks
    });
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while submitting the quiz');
  }
};

const getMyQuizResults = async (req: Request, res: Response) => {
  try {
    const { _id } = req.body; // Student ID from middleware

    const results = await QuizResult.find({ userId: _id })
      .populate('quizId', 'name')
      .populate('userId', 'email') as IQuizResult[];

    return ResponseApi(res, 200, 'Quiz results retrieved successfully', results);
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while getting your quiz results');
  }
};

const verifyStudent = async (req: Request, res: Response) => {
  try {
    const { _id, role } = req.body;

    if (_id === undefined || role === undefined) {
      return ResponseApi(res, 403, 'Forbidden');
    }

    const student = await User.findById(_id).select('-password');
    if (!student || student.role !== 'student') {
      return ResponseApi(res, 400, "No Such Student")
    }

    return ResponseApi(res, 200, 'Student verified successfully', student);
  } catch (error) {
    return ResponseApi(
      res,
      500,
      error instanceof Error
        ? error.message
        : 'An unknown error occurred while verifying the student'
    )
  }
}

const updateProfile = async (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    const { _id, role } = req.body; // Provided by studentMiddleware

    if (!email) {
      return ResponseApi(res, 400, 'Email is required');
    }

    if (role !== 'student') {
      return ResponseApi(res, 403, 'Forbidden: Student access required');
    }

    await User.findByIdAndUpdate(
      _id,
      {
        email: email.toLowerCase(),
      }
    )

    return ResponseApi(res, 200, 'Student profile updated successfully');
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while updating the student profile');
  }
}

const changePassword = async (req: Request, res: Response) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const { _id, role } = req.body; // Provided by studentMiddleware

    if (!currentPassword || !newPassword) {
      return ResponseApi(res, 400, 'Current password and new password are required');
    }

    if (newPassword.length < 6 || newPassword.length > 20) {
      return ResponseApi(res, 400, 'New password must be at least 6 and at most 20 characters');
    }

    if (role !== 'student') {
      return ResponseApi(res, 403, 'Forbidden: Student access required');
    }

    const student = await User.findById(_id);
    if (!student) {
      return ResponseApi(res, 404, 'Student not found');
    }

    const isCurrentPasswordValid = await bcrypt.compare(currentPassword, student.password);
    if (!isCurrentPasswordValid) {
      return ResponseApi(res, 400, 'Current password is incorrect');
    }

    const genSalt = await bcrypt.genSalt(5);
    const hashedNewPassword = await bcrypt.hash(newPassword, genSalt);

    await User.findByIdAndUpdate(_id, { password: hashedNewPassword });

    return ResponseApi(res, 200, 'Password changed successfully');
  } catch (error) {
    return ResponseApi(res, 500, error instanceof Error ? error.message : 'An unknown error occurred while changing the password');
  }
}

export {
  register,
  login,
  getAllCourses,
  registerForCourse,
  getMyCourses,
  getAvailableGroups,
  registerForGroup,
  getMyGroups,
  getMyCourseGrades,
  getAvailableQuizzes,
  getQuizQuestions,
  submitQuiz,
  getMyQuizResults,
  verifyStudent,
  updateProfile,
  changePassword,
};
