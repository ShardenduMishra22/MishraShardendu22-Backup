import { Types } from 'mongoose';
import { GroupRegistration, Quiz, QuizResult } from '../model/model';
import { IGroupRegistration } from '../model/schema/groupRegistration.schema';

export interface ComputedRegistrationGrade {
  registrationId: string;
  userId: string;
  totalEvaluatedScore: number | null;
  totalEvaluatedMaxScore: number | null;
  finalPercentage: number | null;
  finalGrade: string | null;
  relativeRank: number | null;
  hasCompleteAssessment: boolean;
}

interface InternalGradeComputation {
  registration: IGroupRegistration;
  totalScore: number;
  totalMaxScore: number;
  percentage: number;
}

const percentileGradeBands = [
  { upperBound: 0.1, grade: 'A' },
  { upperBound: 0.35, grade: 'B' },
  { upperBound: 0.65, grade: 'C' },
  { upperBound: 0.85, grade: 'D' },
  { upperBound: 1, grade: 'F' },
];

const absoluteGradeThresholds = [
  { minimum: 85, grade: 'A' },
  { minimum: 70, grade: 'B' },
  { minimum: 55, grade: 'C' },
  { minimum: 40, grade: 'D' },
  { minimum: 0, grade: 'F' },
];

const toObjectId = (input: Types.ObjectId | string): Types.ObjectId | null => {
  if (input instanceof Types.ObjectId) {
    return input;
  }

  if (typeof input === 'string' && Types.ObjectId.isValid(input)) {
    return new Types.ObjectId(input);
  }

  return null;
};

const roundToTwo = (value: number): number => {
  return Number(value.toFixed(2));
};

export const recomputeGroupGrades = async (
  groupId: Types.ObjectId | string
): Promise<Map<string, ComputedRegistrationGrade>> => {
  const resolvedGroupId = toObjectId(groupId);
  if (!resolvedGroupId) {
    return new Map();
  }

  const registrations = await GroupRegistration.find({ groupId: resolvedGroupId });
  if (registrations.length === 0) {
    return new Map();
  }

  const userIds = registrations.map((registration) => registration.userId);

  const quizzes = await Quiz.find({ groupId: resolvedGroupId }).select('_id');
  const quizIds = quizzes.map((quiz) => quiz._id);

  const quizResultsByUser = new Map<string, number>();
  const quizCountsByUser = new Map<string, number>();

  if (quizIds.length > 0) {
    const quizResults = await QuizResult.find({
      quizId: { $in: quizIds },
      userId: { $in: userIds },
    }).select('userId marks');

    quizResults.forEach((result) => {
      const userKey = String(result.userId);
      const accumulatedMarks = quizResultsByUser.get(userKey) ?? 0;
      const attemptCount = quizCountsByUser.get(userKey) ?? 0;

      quizResultsByUser.set(userKey, accumulatedMarks + (typeof result.marks === 'number' ? result.marks : 0));
      quizCountsByUser.set(userKey, attemptCount + 1);
    });
  }

  const evaluable: InternalGradeComputation[] = [];
  const computationLookup = new Map<string, ComputedRegistrationGrade>();

  registrations.forEach((registration) => {
    const midSemMarks = typeof registration.midSemMarks === 'number' ? registration.midSemMarks : null;
    const endSemMarks = typeof registration.endSemMarks === 'number' ? registration.endSemMarks : null;
    const hasMid = midSemMarks !== null;
    const hasEnd = endSemMarks !== null;
    const canCompute = hasMid && hasEnd;

    if (!canCompute) {
      computationLookup.set(String(registration._id), {
        registrationId: String(registration._id),
        userId: String(registration.userId),
        totalEvaluatedScore: null,
        totalEvaluatedMaxScore: null,
        finalPercentage: null,
        finalGrade: null,
        relativeRank: null,
        hasCompleteAssessment: false,
      });
      return;
    }

    const midSemMax = typeof registration.midSemMaxMarks === 'number' && registration.midSemMaxMarks > 0
      ? registration.midSemMaxMarks
      : 100;
    const endSemMax = typeof registration.endSemMaxMarks === 'number' && registration.endSemMaxMarks > 0
      ? registration.endSemMaxMarks
      : 100;

    const userKey = String(registration.userId);
    const quizScore = quizResultsByUser.get(userKey) ?? 0;
    const quizAttempts = quizCountsByUser.get(userKey) ?? 0;
    const quizMaxScore = quizAttempts * 100;

    const totalScore = midSemMarks! + endSemMarks! + quizScore;
    const totalMaxScore = midSemMax + endSemMax + quizMaxScore;
    const safeTotalMaxScore = totalMaxScore > 0 ? totalMaxScore : midSemMax + endSemMax;

    const finalPercentage = safeTotalMaxScore > 0
      ? roundToTwo((totalScore / safeTotalMaxScore) * 100)
      : null;

    if (finalPercentage === null) {
      computationLookup.set(String(registration._id), {
        registrationId: String(registration._id),
        userId: String(registration.userId),
        totalEvaluatedScore: roundToTwo(totalScore),
        totalEvaluatedMaxScore: roundToTwo(safeTotalMaxScore),
        finalPercentage: null,
        finalGrade: null,
        relativeRank: null,
        hasCompleteAssessment: true,
      });
      return;
    }

    evaluable.push({
      registration,
      totalScore,
      totalMaxScore: safeTotalMaxScore,
      percentage: finalPercentage,
    });
  });

  if (evaluable.length === 0) {
    const bulkFallbackUpdates = registrations.map((registration) => ({
      updateOne: {
        filter: { _id: registration._id },
        update: {
          $set: {
            totalEvaluatedScore: computationLookup.get(String(registration._id))?.totalEvaluatedScore ?? null,
            totalEvaluatedMaxScore: computationLookup.get(String(registration._id))?.totalEvaluatedMaxScore ?? null,
            finalPercentage: null,
            finalGrade: null,
            relativeRank: null,
            hasCompleteAssessment: computationLookup.get(String(registration._id))?.hasCompleteAssessment ?? false,
          },
        },
      },
    }));

    if (bulkFallbackUpdates.length > 0) {
      await GroupRegistration.bulkWrite(bulkFallbackUpdates);
    }

    return computationLookup;
  }

  const sortedByPercentage = [...evaluable].sort((a, b) => b.percentage - a.percentage);
  const gradeAssignments = new Map<string, { grade: string; rank: number }>();

  if (sortedByPercentage.length >= 5) {
    sortedByPercentage.forEach((entry, index) => {
      const percentileRank = (index + 1) / sortedByPercentage.length;
      const band = percentileGradeBands.find((candidate) => percentileRank <= candidate.upperBound) ?? percentileGradeBands[percentileGradeBands.length - 1];
      gradeAssignments.set(String(entry.registration._id), { grade: band.grade, rank: index + 1 });
    });
  } else {
    sortedByPercentage.forEach((entry, index) => {
      const band = absoluteGradeThresholds.find((candidate) => entry.percentage >= candidate.minimum) ?? absoluteGradeThresholds[absoluteGradeThresholds.length - 1];
      gradeAssignments.set(String(entry.registration._id), { grade: band.grade, rank: index + 1 });
    });
  }

  const bulkUpdates = evaluable.map((entry) => {
    const assignment = gradeAssignments.get(String(entry.registration._id));
    const roundedTotalScore = roundToTwo(entry.totalScore);
    const roundedTotalMaxScore = roundToTwo(entry.totalMaxScore);

    computationLookup.set(String(entry.registration._id), {
      registrationId: String(entry.registration._id),
      userId: String(entry.registration.userId),
      totalEvaluatedScore: roundedTotalScore,
      totalEvaluatedMaxScore: roundedTotalMaxScore,
      finalPercentage: entry.percentage,
      finalGrade: assignment?.grade ?? null,
      relativeRank: assignment?.rank ?? null,
      hasCompleteAssessment: true,
    });

    return {
      updateOne: {
        filter: { _id: entry.registration._id },
        update: {
          $set: {
            totalEvaluatedScore: roundedTotalScore,
            totalEvaluatedMaxScore: roundedTotalMaxScore,
            finalPercentage: entry.percentage,
            finalGrade: assignment?.grade ?? null,
            relativeRank: assignment?.rank ?? null,
            hasCompleteAssessment: true,
          },
        },
      },
    };
  });

  const incompleteUpdates = registrations
    .filter((registration) => !gradeAssignments.has(String(registration._id)))
    .map((registration) => {
      const snapshot = computationLookup.get(String(registration._id));
      return {
        updateOne: {
          filter: { _id: registration._id },
          update: {
            $set: {
              totalEvaluatedScore: snapshot?.totalEvaluatedScore ?? null,
              totalEvaluatedMaxScore: snapshot?.totalEvaluatedMaxScore ?? null,
              finalPercentage: snapshot?.finalPercentage ?? null,
              finalGrade: snapshot?.finalGrade ?? null,
              relativeRank: snapshot?.relativeRank ?? null,
              hasCompleteAssessment: snapshot?.hasCompleteAssessment ?? false,
            },
          },
        },
      };
    });

  const operations = [...bulkUpdates, ...incompleteUpdates];
  if (operations.length > 0) {
    await GroupRegistration.bulkWrite(operations);
  }

  return computationLookup;
};
