import express, { Request, Response } from 'express';
import cors from 'cors';
import router from './route/route';
import { getServerEnv } from './config/env.config';

const createApp = () => {
  const app = express();
  const env = getServerEnv();

  app.use(
    cors({
      origin: env.CLIENT_URI,
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    })
  );

  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  app.get('/health', (_req: Request, res: Response) => {
    res.status(200).json({ status: 'ok' });
  });

  if (env.NODE_ENV === 'development') {
    app.get('/', (_req: Request, res: Response) => {
      res.send('Hello, TypeScript Backend!');
    });
  }

  app.use('/api/v1/admin', router.AdminRouter);
  app.use('/api/v1/student', router.StudentRouter);
  app.use('/api/v1/faculty', router.FacultyRouter);

  return app;
};

export { createApp };
