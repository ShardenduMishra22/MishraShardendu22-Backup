import type { Server } from 'http';
import { createApp } from './app';
import { connectDatabase, disconnectDatabase } from './config/database.config';
import { getServerEnv } from './config/env.config';

const bootstrap = async () => {
  const env = getServerEnv();
  await connectDatabase(env.MONGO_URI);

  const app = createApp();
  const server = app.listen(env.PORT, () => {
    console.log(`Server is running at http://localhost:${env.PORT}`);
  });

  setupGracefulShutdown(server);
};

const setupGracefulShutdown = (server: Server) => {
  const shutdown = async (signal: string) => {
    console.log(`Received ${signal}, shutting down gracefully...`);

    server.close(async () => {
      try {
        await disconnectDatabase();
        console.log('HTTP server and database connections closed');
        process.exit(0);
      } catch (error) {
        console.error('Error while closing database connection', error);
        process.exit(1);
      }
    });
  };

  process.on('SIGINT', () => {
    void shutdown('SIGINT');
  });

  process.on('SIGTERM', () => {
    void shutdown('SIGTERM');
  });
};

void bootstrap().catch((error: unknown) => {
  console.error('Failed to start server', error);
  process.exit(1);
});
