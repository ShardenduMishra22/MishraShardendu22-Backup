import { Schema, Document, Types } from 'mongoose';

interface IGroupRegistration extends Document {
  groupId: Types.ObjectId;
  userId: Types.ObjectId;
  approved?: boolean;
  status?: 'pending' | 'approved' | 'rejected';
  midSemMarks?: number | null;
  endSemMarks?: number | null;
  midSemMaxMarks?: number | null;
  endSemMaxMarks?: number | null;
  assessmentUpdatedBy?: Types.ObjectId | null;
  assessmentUpdatedAt?: Date | null;
  totalEvaluatedScore?: number | null;
  totalEvaluatedMaxScore?: number | null;
  finalPercentage?: number | null;
  finalGrade?: string | null;
  relativeRank?: number | null;
  hasCompleteAssessment?: boolean;
}

const GroupRegistrationSchema = new Schema<IGroupRegistration>(
  {
    groupId: {
      type: Schema.Types.ObjectId,
      ref: 'Group',
      required: [true, 'Please provide a group ID'],
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Please provide a user ID'],
    },
    approved: {
      type: Boolean,
      default: true,
    },
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected'],
      default: 'approved',
    },
    midSemMarks: {
      type: Number,
      min: [0, 'Mid-semester marks cannot be negative'],
      default: null,
    },
    endSemMarks: {
      type: Number,
      min: [0, 'End-semester marks cannot be negative'],
      default: null,
    },
    midSemMaxMarks: {
      type: Number,
      min: [1, 'Mid-semester maximum must be at least 1'],
      default: 100,
    },
    endSemMaxMarks: {
      type: Number,
      min: [1, 'End-semester maximum must be at least 1'],
      default: 100,
    },
    assessmentUpdatedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    assessmentUpdatedAt: {
      type: Date,
      default: null,
    },
    totalEvaluatedScore: {
      type: Number,
      default: null,
      min: [0, 'Evaluated score cannot be negative'],
    },
    totalEvaluatedMaxScore: {
      type: Number,
      default: null,
      min: [0, 'Evaluated maximum score cannot be negative'],
    },
    finalPercentage: {
      type: Number,
      default: null,
      min: [0, 'Final percentage cannot be negative'],
      max: [100, 'Final percentage cannot exceed 100'],
    },
    finalGrade: {
      type: String,
      default: null,
      trim: true,
    },
    relativeRank: {
      type: Number,
      default: null,
      min: [1, 'Relative rank starts from 1'],
    },
    hasCompleteAssessment: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

// Create compound index to ensure a user can only register for a group once
GroupRegistrationSchema.index({ groupId: 1, userId: 1 }, { unique: true });

export { IGroupRegistration, GroupRegistrationSchema };
