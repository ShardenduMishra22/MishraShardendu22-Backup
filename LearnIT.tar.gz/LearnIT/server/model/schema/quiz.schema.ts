import { Schema, Document, Types } from 'mongoose';

interface IQuizSettings {
  timeLimitMinutes: number | null;
  shuffleQuestions: boolean;
  allowBackNavigation: boolean;
  passingScore: number | null;
  instructions: string;
}

interface IQuiz extends Document {
  name: string;
  facultyId: Types.ObjectId;
  groupId: Types.ObjectId;
  settings: IQuizSettings;
}

const QuizSchema = new Schema<IQuiz>(
  {
    name: {
      type: String,
      required: [true, 'Please provide a quiz name'],
    },
    facultyId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Please provide a faculty ID'],
    },
    groupId: {
      type: Schema.Types.ObjectId,
      ref: 'Group',
      required: [true, 'Please provide a group ID'],
    },
    settings: {
      timeLimitMinutes: {
        type: Number,
        min: [1, 'Time limit must be at least 1 minute'],
        default: null,
      },
      shuffleQuestions: {
        type: Boolean,
        default: false,
      },
      allowBackNavigation: {
        type: Boolean,
        default: true,
      },
      passingScore: {
        type: Number,
        min: [0, 'Passing score cannot be negative'],
        max: [100, 'Passing score cannot exceed 100'],
        default: null,
      },
      instructions: {
        type: String,
        default: '',
        trim: true,
      }
    }
  },
  {
    timestamps: true,
  }
);

export { IQuiz, IQuizSettings, QuizSchema };
