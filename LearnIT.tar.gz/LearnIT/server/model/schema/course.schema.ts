import { Schema, Document, Types } from 'mongoose';

interface ICourse extends Document {
  courseCode: string;
  courseCredit: number;
  courseName: string;
  createdBy?: Types.ObjectId;
}

const CourseSchema = new Schema<ICourse>(
  {
    courseCode: {
      type: String,
      required: [true, 'Please provide a course code'],
      unique: true,
    },
    courseCredit: {
      type: Number,
      required: [true, 'Please provide course credits'],
      min: [1, 'Course credits must be at least 1'],
    },
    courseName: {
      type: String,
      required: [true, 'Please provide a course name'],
    },
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

export { ICourse, CourseSchema };
