import { Schema, Document, Types } from 'mongoose';

type QuizQuestionType = 'multiple-choice' | 'text';

interface IQuizQuestion extends Document {
  quizId: Types.ObjectId;
  questionText: string;
  questionImage?: string;
  questionType: QuizQuestionType;
  options: string[];
  answer: string;
}

const QuizQuestionSchema = new Schema<IQuizQuestion>(
  {
    quizId: {
      type: Schema.Types.ObjectId,
      ref: 'Quiz',
      required: [true, 'Please provide a quiz ID'],
    },
    questionText: {
      type: String,
      required: [true, 'Please provide question text'],
    },
    questionImage: {
      type: String,
      required: false,
    },
    questionType: {
      type: String,
      enum: ['multiple-choice', 'text'],
      default: 'multiple-choice',
    },
    options: {
      type: [String],
      default: [],
      validate: {
        validator: function(options: string[]) {
          if (this.questionType === 'multiple-choice') {
            return Array.isArray(options) && options.length >= 2;
          }
          return true;
        },
        message: 'At least 2 options are required for multiple choice questions'
      }
    },
    answer: {
      type: String,
      required: [true, 'Please provide the correct answer'],
      trim: true,
      validate: {
        validator: function(answer: string) {
          if (this.questionType === 'multiple-choice') {
            return this.options.includes(answer);
          }
          return typeof answer === 'string' && answer.trim().length > 0;
        },
        message: 'Answer must be valid for the selected question type'
      }
    }
  },
  {
    timestamps: true,
  }
);

export { IQuizQuestion, QuizQuestionSchema, QuizQuestionType };
