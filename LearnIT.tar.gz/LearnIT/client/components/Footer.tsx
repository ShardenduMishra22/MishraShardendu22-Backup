'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    // Moodle Style: Solid Dark Color, No gradients, High Contrast Text
    <footer className="bg-emerald-900 text-white mt-auto border-t-4 border-emerald-700">
      
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          
          {/* Brand Section */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-emerald-800 border border-emerald-600 rounded flex items-center justify-center">
                <span className="text-white font-bold text-sm">L</span>
              </div>
              <h3 className="text-xl font-bold tracking-tight">LearnIT</h3>
            </div>
            <p className="text-sm text-emerald-100 leading-relaxed mb-6 opacity-80">
              Empowering education through innovation. <br/>
              The official Learning Management System for course delivery and student assessment.
            </p>
            
            {/* Contact Info - Compact */}
            <div className="space-y-2 text-sm text-emerald-100">
              <p className="flex items-center gap-2 opacity-80 hover:opacity-100 transition-opacity">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                <span>University Campus</span>
              </p>
              <p className="flex items-center gap-2 opacity-80 hover:opacity-100 transition-opacity">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                <a href="mailto:support@learnit.edu.in" className="hover:underline">helpdesk@learnit.edu.in</a>
              </p>
            </div>
          </div>

          {/* Links Section - styled as simple lists */}
          <div>
            <h3 className="text-lg font-bold mb-4 text-white">Navigation</h3>
            <ul className="space-y-2 text-sm text-emerald-100">
              <li><Link href="/" className="hover:underline hover:text-white opacity-80">Home</Link></li>
              <li><Link href="/about" className="hover:underline hover:text-white opacity-80">About Us</Link></li>
              <li><Link href="/courses" className="hover:underline hover:text-white opacity-80">All Courses</Link></li>
              <li><Link href="/contact" className="hover:underline hover:text-white opacity-80">Contact Support</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4 text-white">Portals</h3>
            <ul className="space-y-2 text-sm text-emerald-100">
              <li><Link href="/login/student" className="hover:underline hover:text-white opacity-80">Student Login</Link></li>
              <li><Link href="/login/faculty" className="hover:underline hover:text-white opacity-80">Faculty Login</Link></li>
              <li><Link href="/login/admin" className="hover:underline hover:text-white opacity-80">Site Administration</Link></li>
            </ul>
          </div>

          {/* Socials / Legal */}
          <div>
            <h3 className="text-lg font-bold mb-4 text-white">Connect</h3>
            <div className="flex gap-3 mb-6">
              {['Twitter', 'LinkedIn', 'Facebook', 'YouTube'].map((social) => (
                <a key={social} href="#" className="w-8 h-8 bg-emerald-800 hover:bg-emerald-700 rounded flex items-center justify-center transition-colors text-emerald-100" title={social}>
                  <span className="sr-only">{social}</span>
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                     <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                  </svg>
                </a>
              ))}
            </div>
            <div className="text-xs text-emerald-200 opacity-60 space-y-1">
               <Link href="/privacy" className="hover:underline block">Privacy Policy</Link>
               <Link href="/terms" className="hover:underline block">Terms & Conditions</Link>
               <Link href="/accessibility" className="hover:underline block">Accessibility</Link>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright Bar */}
      <div className="bg-emerald-950 py-4 px-6 text-center border-t border-emerald-800">
        <p className="text-xs text-emerald-400">
          © 2025 LearnIT LMS. All rights reserved.
        </p>
      </div>
    </footer>
  );
}