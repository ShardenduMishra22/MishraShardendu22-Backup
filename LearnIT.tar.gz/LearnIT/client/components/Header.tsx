'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { logout } from '@/lib/auth';
import { useUserStore } from '@/lib/store';
import { useState, useEffect } from 'react';

export default function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, initializeAuth, hydrationComplete } = useUserStore();
  const [isReady, setIsReady] = useState(false);
  const [showLoginDropdown, setShowLoginDropdown] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
      return;
    }

    const frame = window.requestAnimationFrame(() => setIsReady(true));
    return () => window.cancelAnimationFrame(frame);
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!isReady || !hydrationComplete) {
      return;
    }
    initializeAuth();
  }, [pathname, isReady, hydrationComplete, initializeAuth]);

  if (!isReady) {
    return null;
  }

  const isLoginPage = pathname?.startsWith('/login');

  return (
    <div className="flex flex-col font-sans">
      {/* Main App Bar - Moodle Style (White, solid border, distinct interactions) */}
      <header className="bg-white border-b border-gray-300 h-[70px] flex items-center z-50 sticky top-0">
        <div className="container mx-auto px-4 h-full">
          <div className="flex items-center justify-between h-full">
            
            {/* Logo - Squared off like Moodle App Icon */}
            <Link href="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 bg-emerald-700 rounded-md flex items-center justify-center text-white font-bold text-xl shadow-sm group-hover:bg-emerald-800 transition-colors">
                L
              </div>
              <div className="flex flex-col justify-center">
                <span className="text-xl font-bold text-gray-800 leading-none tracking-tight group-hover:text-emerald-700 transition-colors">
                  LearnIT
                </span>
              </div>
            </Link>

            {/* Navigation */}
            <nav className="hidden md:flex items-center gap-2 h-full">
              <Link
                href="/"
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  pathname === '/' 
                    ? 'bg-gray-100 text-gray-900 font-bold' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                Home
              </Link>

              {!user && !isLoginPage && (
                <div className="relative ml-4">
                  <button
                    onClick={() => setShowLoginDropdown(!showLoginDropdown)}
                    onBlur={() => setTimeout(() => setShowLoginDropdown(false), 200)}
                    className={`px-5 py-2.5 text-sm font-medium rounded-md transition-all flex items-center gap-2 ${
                       showLoginDropdown 
                       ? 'bg-emerald-800 text-white' 
                       : 'bg-emerald-700 text-white hover:bg-emerald-800'
                    }`}
                  >
                    <span>Log in</span>
                    <svg className={`w-4 h-4 transition-transform ${showLoginDropdown ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>

                  {/* Dropdown Menu - Clean, Flat Enterprise Style */}
                  {showLoginDropdown && (
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded shadow-lg border border-gray-200 overflow-hidden z-50">
                      <div className="py-1">
                        <button
                          onClick={() => router.push('/login/student')}
                          className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors flex items-center gap-3 border-b border-gray-100"
                        >
                          <span className="text-gray-400">
                             <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" /></svg>
                          </span>
                          <div>
                            <div className="text-sm font-bold text-gray-700">Student</div>
                            <div className="text-xs text-gray-500">Portal Access</div>
                          </div>
                        </button>

                        <button
                          onClick={() => router.push('/login/faculty')}
                          className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors flex items-center gap-3 border-b border-gray-100"
                        >
                          <span className="text-gray-400">
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                          </span>
                          <div>
                            <div className="text-sm font-bold text-gray-700">Faculty</div>
                            <div className="text-xs text-gray-500">Course Management</div>
                          </div>
                        </button>

                        <button
                          onClick={() => router.push('/login/admin')}
                          className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors flex items-center gap-3"
                        >
                          <span className="text-gray-400">
                             <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                          </span>
                          <div>
                            <div className="text-sm font-bold text-gray-700">Admin</div>
                            <div className="text-xs text-gray-500">Site Administration</div>
                          </div>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {user && (
                <>
                  <Link
                    href={`/${user.role}/dashboard`}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                      pathname?.includes('/dashboard') 
                        ? 'bg-gray-100 text-gray-900 font-bold' 
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                  >
                    Dashboard
                  </Link>
                  
                  {/* Profile Dropdown - Moodle Style User Menu */}
                  <div className="relative ml-2">
                    <button
                      onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                      onBlur={() => setTimeout(() => setShowProfileDropdown(false), 200)}
                      className="flex items-center gap-2 pl-2 pr-1 py-1 rounded-full hover:bg-gray-100 transition-colors border border-transparent hover:border-gray-200"
                    >
                      <span className="hidden sm:block text-sm font-medium text-gray-700 px-2">
                        {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                      </span>
                      <div className="w-9 h-9 bg-gray-200 rounded-full flex items-center justify-center text-gray-600 border border-gray-300">
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <svg className="w-3 h-3 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>

                    {/* Profile Menu */}
                    {showProfileDropdown && (
                      <div className="absolute right-0 mt-2 w-64 bg-white rounded shadow-lg border border-gray-200 overflow-hidden z-50">
                        {/* User Header */}
                        <div className="px-4 py-4 border-b border-gray-200 bg-gray-50">
                          <div className="font-bold text-gray-900 truncate">{user.email}</div>
                          <div className="text-xs text-gray-500 mt-1 uppercase tracking-wider">
                            Logged in as {user.role}
                          </div>
                        </div>

                        <div className="py-1">
                          <button
                            onClick={() => {
                              setShowProfileDropdown(false);
                              router.push(`/${user.role}/profile`);
                            }}
                            className="w-full px-4 py-2 text-left hover:bg-gray-50 text-sm text-gray-700 flex items-center gap-2"
                          >
                             <span>Profile</span>
                          </button>

                          <button
                            onClick={() => {
                              setShowProfileDropdown(false);
                              router.push(`/${user.role}/dashboard`);
                            }}
                            className="w-full px-4 py-2 text-left hover:bg-gray-50 text-sm text-gray-700 flex items-center gap-2"
                          >
                            <span>Dashboard</span>
                          </button>

                          <button
                            onClick={() => {
                              setShowProfileDropdown(false);
                              router.push(`/${user.role}/settings`);
                            }}
                            className="w-full px-4 py-2 text-left hover:bg-gray-50 text-sm text-gray-700 flex items-center gap-2"
                          >
                            <span>Preferences</span>
                          </button>

                          <div className="border-t border-gray-100 my-1"></div>

                          <button
                            onClick={() => {
                              setShowProfileDropdown(false);
                              logout();
                            }}
                            className="w-full px-4 py-2 text-left hover:bg-red-50 text-sm text-red-700 flex items-center gap-2"
                          >
                            <span>Log out</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </>
              )}
            </nav>

            {/* Mobile Menu Button */}
            <button className="md:hidden p-2 text-gray-500 hover:bg-gray-100 rounded-md">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* Utility Bar / Breadcrumb Area - Moodle Style (Light Gray Background) */}
      <div className="bg-[#f8f9fa] border-b border-gray-200">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center gap-6 text-xs font-medium text-gray-500 overflow-x-auto">
            <Link href="/about" className="hover:text-emerald-700 hover:underline whitespace-nowrap">About LearnIT</Link>
            <span className="text-gray-300">|</span>
            <Link href="/courses" className="hover:text-emerald-700 hover:underline whitespace-nowrap">Course Catalog</Link>
            <span className="text-gray-300">|</span>
            <Link href="/contact" className="hover:text-emerald-700 hover:underline whitespace-nowrap">Support</Link>
            <span className="text-gray-300">|</span>
            <Link href="/help" className="hover:text-emerald-700 hover:underline whitespace-nowrap">Documentation</Link>
          </div>
        </div>
      </div>
    </div>
  );
}