import React from 'react';

const StatsSection = () => {
  const stats = [
    { label: "Active Courses", value: "1,200+" },
    { label: "Registered Students", value: "45k+" },
    { label: "Faculty Members", value: "350+" },
    { label: "Quizzes Taken", value: "1M+" },
  ];

  return (
    <div className="bg-white border-b border-gray-200">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-gray-100">
          {stats.map((stat, index) => (
            <div key={index} className="py-8 text-center px-4">
              <div className="text-3xl md:text-4xl font-bold text-emerald-900 mb-1">
                {stat.value}
              </div>
              <div className="text-sm text-gray-500 uppercase tracking-wider font-semibold">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StatsSection;