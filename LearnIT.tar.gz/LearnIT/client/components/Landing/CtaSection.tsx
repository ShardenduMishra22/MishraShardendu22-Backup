import React from 'react';
import Link from 'next/link';

const CtaSection = () => {
  return (
    <section className="bg-emerald-900 py-16">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
          Ready to start learning?
        </h2>
        <p className="text-emerald-100 mb-10 max-w-2xl mx-auto text-lg">
          Join thousands of students and faculty members on the platform. 
          Access your dashboard now to begin.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/login/student"
            className="px-8 py-4 bg-white text-emerald-900 font-bold rounded-full hover:bg-emerald-50 transition-colors shadow-lg"
          >
            Student Login
          </Link>
          <Link
            href="/contact"
            className="px-8 py-4 bg-transparent border-2 border-emerald-400 text-white font-bold rounded-full hover:bg-emerald-800 transition-colors"
          >
            Contact Support
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;