import React from 'react';
import Link from 'next/link';

const LoginSection = () => {
  return (
    <section id="login" className="scroll-mt-24">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-slate-800 mb-4">
          Choose Your Portal
        </h2>
        <p className="text-slate-500 max-w-2xl mx-auto">
          Secure access for all institutional members. Please select your designated role to access the dashboard.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Student Card */}
        <Link
          href="/login/student"
          className="group relative bg-white rounded-2xl p-8 border border-slate-200 hover:border-blue-500/50 shadow-sm hover:shadow-xl hover:shadow-blue-500/10 transition-all duration-300 hover:-translate-y-1"
        >
          <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-t-2xl"></div>
          <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
            <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          </div>
          <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-blue-600 transition-colors">Student</h3>
          <p className="text-sm text-slate-500 mb-6 leading-relaxed">
            Access course materials, submit assignments, track grades, and participate in quizzes.
          </p>
          <div className="flex items-center text-sm font-semibold text-blue-600 group-hover:gap-2 transition-all">
            Login to Portal <span className="opacity-0 group-hover:opacity-100 transition-opacity">→</span>
          </div>
        </Link>

        {/* Faculty Card */}
        <Link
          href="/login/faculty"
          className="group relative bg-white rounded-2xl p-8 border border-slate-200 hover:border-emerald-500/50 shadow-sm hover:shadow-xl hover:shadow-emerald-500/10 transition-all duration-300 hover:-translate-y-1"
        >
          <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-emerald-500 to-teal-400 rounded-t-2xl"></div>
          <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
            <svg className="w-8 h-8 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-emerald-600 transition-colors">Faculty</h3>
          <p className="text-sm text-slate-500 mb-6 leading-relaxed">
            Manage course content, create groups, grade submissions, and monitor student progress.
          </p>
          <div className="flex items-center text-sm font-semibold text-emerald-600 group-hover:gap-2 transition-all">
            Login to Portal <span className="opacity-0 group-hover:opacity-100 transition-opacity">→</span>
          </div>
        </Link>

        {/* Admin Card */}
        <Link
          href="/login/admin"
          className="group relative bg-white rounded-2xl p-8 border border-slate-200 hover:border-purple-500/50 shadow-sm hover:shadow-xl hover:shadow-purple-500/10 transition-all duration-300 hover:-translate-y-1"
        >
          <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-purple-500 to-indigo-400 rounded-t-2xl"></div>
          <div className="w-16 h-16 bg-purple-50 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
            <svg className="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </div>
          <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-purple-600 transition-colors">Admin</h3>
          <p className="text-sm text-slate-500 mb-6 leading-relaxed">
            System configuration, user management, site settings, and overall platform analytics.
          </p>
          <div className="flex items-center text-sm font-semibold text-purple-600 group-hover:gap-2 transition-all">
            Login to Portal <span className="opacity-0 group-hover:opacity-100 transition-opacity">→</span>
          </div>
        </Link>
      </div>
    </section>
  );
};

export default LoginSection;