import React from 'react';
import Link from 'next/link';

const HeroSection = () => {
  return (
    <section className="relative bg-emerald-900 overflow-hidden">
      {/* Background Pattern - Abstract Educational Nodes */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <pattern id="grid" width="8" height="8" patternUnits="userSpaceOnUse">
            <path d="M 8 0 L 0 0 0 8" fill="none" stroke="white" strokeWidth="0.5" />
          </pattern>
          <rect width="100" height="100" fill="url(#grid)" />
        </svg>
      </div>

      <div className="container mx-auto px-6 py-20 md:py-28 relative z-10">
        <div className="flex flex-col md:flex-row items-center gap-12">
          
          {/* Left Content */}
          <div className="md:w-1/2 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 mb-6 text-xs font-bold tracking-wider uppercase bg-emerald-800/50 border border-emerald-700/50 rounded-full text-emerald-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              LMS Portal v2.0
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white leading-tight">
              Unlock Your <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-200 to-teal-400">
                Learning Potential
              </span>
            </h1>
            
            <p className="text-lg md:text-xl mb-8 text-emerald-100/90 font-light leading-relaxed max-w-lg">
              A unified platform for students, faculty, and administration. 
              Experience the future of education with seamless course management and real-time tracking.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="#login"
                className="px-8 py-4 bg-white text-emerald-900 font-bold rounded-lg hover:bg-emerald-50 transition-all shadow-lg hover:shadow-emerald-900/20 transform hover:-translate-y-1 text-center"
              >
                Access Portal
              </Link>
              <Link
                href="/about"
                className="px-8 py-4 bg-emerald-800/40 backdrop-blur-sm text-white font-bold rounded-lg border border-emerald-600/50 hover:bg-emerald-800/60 transition-all text-center"
              >
                View Documentation
              </Link>
            </div>
          </div>

          {/* Right Visual - Abstract Dashboard Preview */}
          <div className="md:w-1/2 relative">
            <div className="relative z-10 bg-emerald-950/40 border border-emerald-500/20 rounded-xl p-2 shadow-2xl backdrop-blur-md transform rotate-1 hover:rotate-0 transition-transform duration-500">
               {/* Mock Browser/App Header */}
               <div className="h-8 bg-emerald-900/50 rounded-t-lg flex items-center px-4 gap-2 border-b border-emerald-500/10">
                 <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                 <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                 <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
               </div>
               {/* Mock Content */}
               <div className="p-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="h-4 w-1/3 bg-emerald-400/20 rounded"></div>
                    <div className="h-8 w-8 rounded-full bg-emerald-400/20"></div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="h-24 bg-gradient-to-br from-emerald-800/50 to-emerald-900/50 rounded-lg border border-emerald-500/10"></div>
                    <div className="h-24 bg-gradient-to-br from-teal-800/50 to-teal-900/50 rounded-lg border border-teal-500/10"></div>
                    <div className="h-24 bg-gradient-to-br from-blue-800/50 to-blue-900/50 rounded-lg border border-blue-500/10"></div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-3 w-3/4 bg-emerald-200/10 rounded"></div>
                    <div className="h-3 w-1/2 bg-emerald-200/10 rounded"></div>
                  </div>
               </div>
            </div>
            
            {/* Decorative blob */}
            <div className="absolute -top-10 -right-10 w-64 h-64 bg-emerald-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default HeroSection;