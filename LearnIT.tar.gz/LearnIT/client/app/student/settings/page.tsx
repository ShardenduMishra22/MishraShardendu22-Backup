'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';

export default function StudentSettings() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/student');
      return;
    }

    if (user?.role !== 'student') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      
       {/* Breadcrumb Header */}
       <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-3xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
             <Link href="/student/dashboard" className="hover:underline hover:text-emerald-700">Dashboard</Link>
             <span>/</span>
             <Link href="/student/profile" className="hover:underline hover:text-emerald-700">Profile</Link>
             <span>/</span>
             <span className="text-gray-800 font-semibold">Preferences</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">
            User Preferences
          </h1>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-3xl pb-12">
        <div className="space-y-8">
          
          {/* User Account Section */}
          <div className="bg-white rounded-md border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
              <h2 className="text-lg font-bold text-gray-800">User Account</h2>
            </div>
            
            <div className="divide-y divide-gray-100">
               {/* Email Item */}
              <div className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors group">
                <div>
                  <h3 className="text-sm font-bold text-gray-900 group-hover:text-emerald-700 transition-colors">Edit profile</h3>
                  <p className="text-xs text-gray-500 mt-1">Update email address: {user.email}</p>
                </div>
                <button className="text-sm text-emerald-700 hover:underline font-medium">Edit</button>
              </div>

               {/* Password Item */}
              <div className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors group">
                <div>
                  <h3 className="text-sm font-bold text-gray-900 group-hover:text-emerald-700 transition-colors">Change password</h3>
                  <p className="text-xs text-gray-500 mt-1">Update your security credentials</p>
                </div>
                <button 
                  onClick={() => alert('Change password feature coming soon!')}
                  className="text-sm text-emerald-700 hover:underline font-medium"
                >
                  Edit
                </button>
              </div>
            </div>
          </div>

          {/* Notifications Section - Styled as Form Toggles */}
          <div className="bg-white rounded-md border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
              <h2 className="text-lg font-bold text-gray-800">Notification preferences</h2>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-sm font-bold text-gray-900">Email Notifications</h3>
                  <p className="text-xs text-gray-500 mt-1">Receive updates about courses via email</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-sm font-bold text-gray-900">Course Updates</h3>
                  <p className="text-xs text-gray-500 mt-1">Get notified when content is added</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-sm font-bold text-gray-900">Quiz Reminders</h3>
                  <p className="text-xs text-gray-500 mt-1">Alerts for upcoming deadlines</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>
          </div>

          {/* Privacy Section */}
          <div className="bg-white rounded-md border border-gray-200 shadow-sm overflow-hidden">
             <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
              <h2 className="text-lg font-bold text-gray-800">Privacy & Policies</h2>
            </div>
             <div className="divide-y divide-gray-100">
               <div className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
                 <div>
                    <h3 className="text-sm font-bold text-gray-900">Data export</h3>
                    <p className="text-xs text-gray-500 mt-1">Request a copy of all your personal data</p>
                 </div>
                 <button className="text-sm text-emerald-700 hover:underline font-medium">Request</button>
               </div>
               <div className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
                 <div>
                    <h3 className="text-sm font-bold text-gray-900">Security keys</h3>
                    <p className="text-xs text-gray-500 mt-1">Manage Two-Factor Authentication</p>
                 </div>
                 <button className="text-sm text-emerald-700 hover:underline font-medium">Manage</button>
               </div>
             </div>
          </div>

          {/* Danger Zone - Moodle Style "Alert" Box, not a fancy card */}
          <div className="border border-red-200 rounded-md bg-red-50 p-6">
             <div className="flex items-start gap-4">
               <div className="p-2 bg-red-100 rounded text-red-600">
                 <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
               </div>
               <div className="flex-1">
                 <h3 className="text-sm font-bold text-red-800">Delete Account</h3>
                 <p className="text-xs text-red-700 mt-1 mb-3">
                   Permanently delete your account and all associated data. This action cannot be undone.
                 </p>
                 <button 
                    onClick={() => {
                      if (confirm('Are you sure?')) {
                        alert('Coming soon');
                      }
                    }}
                    className="text-xs bg-red-600 text-white px-3 py-2 rounded font-bold hover:bg-red-700 transition-colors"
                  >
                    Delete my account
                 </button>
               </div>
             </div>
          </div>

        </div>
      </div>
    </div>
  );
}