'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/lib/store';
import { studentApi, type ApiResponse } from '@/lib/api';

interface ICourseSummary {
  _id: string;
  courseName: string;
  courseCode: string;
}

interface IUserSummary {
  _id: string;
  email: string;
}

interface IGroup {
  _id: string;
  name: string;
  registrationOpen?: boolean;
  courseId?: ICourseSummary;
  facultyId?: IUserSummary;
}

interface IGroupRegistration {
  _id: string;
  groupId: IGroup;
  userId: IUserSummary;
}

export default function StudentGroupsPage() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();

  const [loading, setLoading] = useState(true);
  const [groupsLoading, setGroupsLoading] = useState(true);
  const [error, setError] = useState('');
  const [availableGroups, setAvailableGroups] = useState<IGroup[]>([]);
  const [myGroups, setMyGroups] = useState<IGroup[]>([]);
  const [registeringId, setRegisteringId] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/student');
      return;
    }

    if (user?.role !== 'student') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  useEffect(() => {
    if (!hydrationComplete || !isAuthenticated || user?.role !== 'student') {
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setError('');
      setSuccess('');
      setGroupsLoading(true);
    });

    Promise.all([
      studentApi.getAvailableGroups(),
      studentApi.getMyGroups(),
    ])
      .then(([availableResponse, myGroupsResponse]) => {
        if (!isMounted) {
          return;
        }

        const available = (availableResponse as ApiResponse<IGroup[]>).data ?? [];
        const mine = (myGroupsResponse as ApiResponse<IGroup[]>).data ?? [];

        setAvailableGroups(available);
        setMyGroups(mine);
      })
      .catch((fetchError: unknown) => {
        if (!isMounted) {
          return;
        }
        const message = fetchError instanceof Error ? fetchError.message : 'Failed to load groups.';
        setError(message);
      })
      .finally(() => {
        if (isMounted) {
          setGroupsLoading(false);
        }
      });

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [hydrationComplete, isAuthenticated, user]);

  const handleRegister = async (groupId: string) => {
    setError('');
    setSuccess('');
    setRegisteringId(groupId);
    try {
      const response = await studentApi.registerForGroup(groupId);
      const registration = (response as ApiResponse<IGroupRegistration>).data;
      if (registration?.groupId) {
        setMyGroups((prev) => {
          const exists = prev.some((group) => group._id === registration.groupId._id);
          if (exists) {
            return prev;
          }
          return [...prev, registration.groupId];
        });
      }
      setAvailableGroups((prev) => prev.filter((group) => group._id !== groupId));
      setSuccess('Successfully joined the group.');
    } catch (registerError) {
      const message = registerError instanceof Error ? registerError.message : 'Failed to join group.';
      setError(message);
    } finally {
      setRegisteringId('');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-medium">Loading groups...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/student/dashboard" className="hover:underline hover:text-emerald-700">Dashboard</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Groups</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Groups & Collaboration</h1>
          <p className="text-sm text-gray-500 mt-1">Join course groups to collaborate with peers and access exclusive quizzes.</p>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12 space-y-8">
        {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-200">{error}</p>}
        {success && <p className="text-sm text-green-600 bg-green-50 p-3 rounded-md border border-green-200">{success}</p>}

        <section className="bg-white rounded-md border border-gray-200 shadow-sm">
          <header className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50">
            <div>
              <h2 className="text-lg font-semibold text-gray-800">Available Groups</h2>
              <p className="text-sm text-gray-500">Register for a group after enrolling in its course.</p>
            </div>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide">{groupsLoading ? 'Loading…' : `${availableGroups.length} Open`}</span>
          </header>

          {groupsLoading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3 text-gray-500">
              <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-sm font-medium">Fetching available groups…</p>
            </div>
          ) : availableGroups.length === 0 ? (
            <div className="py-12 text-center text-gray-500">
              <h3 className="text-lg font-semibold">No open groups right now</h3>
              <p className="text-sm">Once faculty publish new groups, they will appear here.</p>
            </div>
          ) : (
            <div className="p-6 grid gap-6 md:grid-cols-2">
              {availableGroups.map((group) => (
                <article key={group._id} className="border border-gray-200 rounded-md p-5 shadow-sm hover:border-emerald-500 transition-colors">
                  <header className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800">{group.name}</h3>
                      {group.courseId && (
                        <p className="text-sm text-gray-500 mt-1">{group.courseId.courseName} · <span className="font-medium">{group.courseId.courseCode}</span></p>
                      )}
                      {group.facultyId && (
                        <p className="text-xs text-gray-400 mt-0.5">Coordinator: {group.facultyId.email}</p>
                      )}
                    </div>
                    <span className={`text-xs font-bold uppercase tracking-wide px-2 py-1 rounded ${group.registrationOpen ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-500'}`}>
                      {group.registrationOpen ? 'Open' : 'Closed'}
                    </span>
                  </header>

                  <footer className="mt-4 flex justify-end">
                    <button
                      type="button"
                      onClick={() => handleRegister(group._id)}
                      disabled={registeringId === group._id}
                      className="inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 text-white text-sm font-semibold px-4 py-2 rounded-md transition-colors"
                    >
                      {registeringId === group._id ? 'Joining…' : 'Join Group'}
                    </button>
                  </footer>
                </article>
              ))}
            </div>
          )}
        </section>

        <section className="bg-white rounded-md border border-gray-200 shadow-sm">
          <header className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50">
            <div>
              <h2 className="text-lg font-semibold text-gray-800">My Groups</h2>
              <p className="text-sm text-gray-500">Groups you have already joined.</p>
            </div>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide">{groupsLoading ? '—' : `${myGroups.length} Joined`}</span>
          </header>

          {groupsLoading ? (
            <div className="py-12 text-center text-gray-500 text-sm">Loading your groups…</div>
          ) : myGroups.length === 0 ? (
            <div className="py-12 text-center text-gray-500">
              <h3 className="text-lg font-semibold">You have not joined any groups yet</h3>
              <p className="text-sm">Register for a course group to collaborate with classmates.</p>
            </div>
          ) : (
            <div className="p-6 grid gap-6 md:grid-cols-2">
              {myGroups.map((group) => (
                <article key={group._id} className="border border-gray-200 rounded-md p-5 shadow-sm">
                  <h3 className="text-lg font-semibold text-gray-800">{group.name}</h3>
                  {group.courseId && (
                    <p className="text-sm text-gray-500 mt-1">{group.courseId.courseName} · <span className="font-medium">{group.courseId.courseCode}</span></p>
                  )}
                  {group.facultyId && (
                    <p className="text-xs text-gray-400 mt-0.5">Coordinator: {group.facultyId.email}</p>
                  )}
                  <p className="text-xs text-gray-400 mt-3">Stay tuned for announcements and quizzes shared within this group.</p>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
