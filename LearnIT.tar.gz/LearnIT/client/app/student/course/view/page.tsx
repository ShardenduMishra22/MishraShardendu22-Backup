'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { studentApi, type ApiResponse } from '@/lib/api';

interface ICourse {
  _id: string;
  courseName: string;
  courseCode: string;
  courseCredit: number;
}

export default function AllCourses() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();
  const [loading, setLoading] = useState(true);
  const [courses, setCourses] = useState<ICourse[]>([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/student');
      return;
    }
    if (user?.role !== 'student') {
      router.push('/');
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setError('');
      setLoading(true);
    });

    const fetchCourses = async () => {
      try {
        const [allCoursesResponse, myCoursesResponse] = await Promise.all([
          studentApi.getAllCourses(),
          studentApi.getMyCourses(),
        ]);

        if (!isMounted) {
          return;
        }

        const allCourses = (allCoursesResponse as ApiResponse<ICourse[]>).data ?? [];
        const myCourses = (myCoursesResponse as ApiResponse<ICourse[]>).data ?? [];

        const registeredIds = new Set<string>(
          myCourses
            .map((course) => course?._id)
            .filter((id): id is string => typeof id === 'string')
        );

        const availableCourses = allCourses.filter((course) => !registeredIds.has(course._id));
        setCourses(availableCourses);
      } catch (err) {
        if (!isMounted) {
          return;
        }
        setError(err instanceof Error ? err.message : 'Failed to fetch courses.');
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchCourses();

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [hydrationComplete, isAuthenticated, user, router]);

  const handleRegister = async (courseId: string) => {
    setError('');
    setSuccess('');
    try {
      await studentApi.registerForCourse(courseId);
      setSuccess('Successfully registered for the course!');
      setCourses((prevCourses) => prevCourses.filter((course) => course._id !== courseId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to register for the course.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/student/dashboard" className="hover:underline hover:text-emerald-700">Dashboard</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">All Courses</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Available Courses</h1>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12">
        {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md mb-6">{error}</p>}
        {success && <p className="text-sm text-green-600 bg-green-50 p-3 rounded-md mb-6">{success}</p>}
        
        <div className="bg-white rounded-md border border-gray-200 shadow-sm overflow-x-auto">
          {courses.length === 0 && !error ? (
            <div className="text-center py-12 px-6">
              <h2 className="text-xl font-semibold text-gray-700">You have already registered to all courses available.</h2>
              <p className="text-gray-500 mt-2">Check back later for new course offerings.</p>
            </div>
          ) : (
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Course Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Code</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Credits</th>
                  <th scope="col" className="relative px-6 py-3"><span className="sr-only">Register</span></th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {courses.map((course) => (
                  <tr key={course._id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{course.courseName}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{course.courseCode}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{course.courseCredit}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button 
                        onClick={() => handleRegister(course._id)}
                        className="bg-emerald-600 text-white font-bold py-1 px-3 rounded-md hover:bg-emerald-700 transition-colors text-xs"
                      >
                        Register
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
