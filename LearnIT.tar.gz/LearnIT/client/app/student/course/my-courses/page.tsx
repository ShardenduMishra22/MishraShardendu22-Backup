'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { studentApi, type ApiResponse } from '@/lib/api';

interface ICourse {
  _id: string;
  courseName: string;
  courseCode: string;
  courseCredit: number;
}

export default function MyCourses() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();
  const [loading, setLoading] = useState(true);
  const [courses, setCourses] = useState<ICourse[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/student');
      return;
    }
    if (user?.role !== 'student') {
      router.push('/');
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setError('');
      setLoading(true);
    });

    studentApi
      .getMyCourses()
      .then((response) => {
        if (!isMounted) {
          return;
        }
        const courseData = (response as ApiResponse<ICourse[]>).data ?? [];
        setCourses(courseData);
      })
      .catch((err) => {
        if (!isMounted) {
          return;
        }
        setError(err instanceof Error ? err.message : 'Failed to fetch your courses.');
        setCourses([]);
      })
      .finally(() => {
        if (isMounted) {
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [hydrationComplete, isAuthenticated, user, router]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                <Link href="/student/dashboard" className="hover:underline hover:text-emerald-700">Dashboard</Link>
                <span>/</span>
                <span className="text-gray-800 font-semibold">My Courses</span>
              </div>
              <h1 className="text-3xl font-light text-gray-800">My Registered Courses</h1>
            </div>
            <Link href="/student/course/view">
              <button className="bg-emerald-600 text-white font-bold py-2 px-4 rounded-md hover:bg-emerald-700 transition-colors">
                Register for New Course
              </button>
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12">
        {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md mb-6">{error}</p>}
        
        {courses.length === 0 && !error ? (
          <div className="text-center py-12 px-6 bg-white rounded-md border border-gray-200 shadow-sm">
            <h2 className="text-xl font-semibold text-gray-700">You are not registered for any courses.</h2>
            <p className="text-gray-500 mt-2">Explore available courses and register to get started.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <div key={course._id} className="bg-white rounded-md border border-gray-200 shadow-sm p-6 flex flex-col justify-between hover:shadow-lg transition-shadow">
                <div>
                  <h2 className="text-xl font-bold text-gray-900">{course.courseName}</h2>
                  <p className="text-sm text-gray-600 mt-1">{course.courseCode}</p>
                  <p className="text-xs text-gray-400 mt-2">Credits: {course.courseCredit}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
