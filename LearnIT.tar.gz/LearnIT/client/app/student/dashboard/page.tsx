'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/lib/store';
import { studentApi, type ApiResponse } from '@/lib/api';

export default function StudentDashboard() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();
  const [loading, setLoading] = useState(true);
  const [statsLoading, setStatsLoading] = useState(true);
  const [statsError, setStatsError] = useState('');
  const [stats, setStats] = useState({
    courses: 0,
    totalCourses: 0,
    groups: 0,
    quizzes: 0,
    grades: 0,
  });

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/student');
      return;
    }

    if (user?.role !== 'student') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  useEffect(() => {
    if (!hydrationComplete || !isAuthenticated || user?.role !== 'student') {
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setStatsError('');
      setStatsLoading(true);
    });

    Promise.all([
      studentApi.getMyCourses(),
      studentApi.getAllCourses(),
      studentApi.getMyGroups(),
      studentApi.getAvailableQuizzes(),
      studentApi.getMyQuizResults(),
    ])
      .then(([myCoursesResponse, allCoursesResponse, groupsResponse, quizzesResponse, resultsResponse]) => {
        if (!isMounted) {
          return;
        }

        const myCoursesCount = (myCoursesResponse as ApiResponse<unknown[]>).data?.length ?? 0;
        const totalCoursesCount = (allCoursesResponse as ApiResponse<unknown[]>).data?.length ?? 0;
        const groupsCount = (groupsResponse as ApiResponse<unknown[]>).data?.length ?? 0;
        const quizzesCount = (quizzesResponse as ApiResponse<unknown[]>).data?.length ?? 0;
        const gradesCount = (resultsResponse as ApiResponse<unknown[]>).data?.length ?? 0;

        setStats({
          courses: myCoursesCount,
          totalCourses: totalCoursesCount,
          groups: groupsCount,
          quizzes: quizzesCount,
          grades: gradesCount,
        });
      })
      .catch((error: unknown) => {
        if (!isMounted) {
          return;
        }
        const message = error instanceof Error ? error.message : 'Unable to load your stats';
        setStatsError(message);
      })
      .finally(() => {
        if (isMounted) {
          setStatsLoading(false);
        }
      });

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [hydrationComplete, isAuthenticated, user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-medium">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const courseProgressRatio = stats.totalCourses > 0 ? stats.courses / stats.totalCourses : 0;
  const courseProgressPercent = Math.min(100, Math.round(courseProgressRatio * 100));
  const courseProgressWidth = statsLoading
    ? '0%'
    : `${Math.min(
        100,
        Math.max(courseProgressRatio * 100, stats.courses > 0 ? 8 : 0)
      ).toFixed(2)}%`;

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      
      {/* Dashboard Control Bar - Moodle 4.0 Style */}
      <div className="bg-white border-b border-gray-300 px-6 py-4">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
             <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
             <p className="text-sm text-gray-500">Welcome back, {user?.email}</p>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Visual "Edit Mode" Toggle - Iconic Moodle feature */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-gray-600">Edit mode</span>
              <div className="w-12 h-6 bg-gray-200 rounded-full relative cursor-pointer">
                <div className="w-6 h-6 bg-white border border-gray-300 rounded-full shadow-sm absolute left-0"></div>
              </div>
            </div>
            
        
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT COLUMN (Main Content - 2/3 width) */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* KPI Stats Row - Styled as "Overview Block" */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
               {/* Stat Card 1 */}
               <div className="bg-white p-4 rounded-md border border-gray-200 shadow-sm flex flex-col items-center justify-center text-center hover:border-emerald-500 transition-colors">
                 <span className="text-3xl font-light text-emerald-700 mb-1">
                   {statsLoading ? '—' : stats.courses}
                 </span>
                 <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Courses</span>
               </div>
               
               {/* Stat Card 2 */}
               <div className="bg-white p-4 rounded-md border border-gray-200 shadow-sm flex flex-col items-center justify-center text-center hover:border-emerald-500 transition-colors">
                 <span className="text-3xl font-light text-emerald-700 mb-1">
                   {statsLoading ? '—' : stats.groups}
                 </span>
                 <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Groups</span>
               </div>

               {/* Stat Card 3 */}
               <div className="bg-white p-4 rounded-md border border-gray-200 shadow-sm flex flex-col items-center justify-center text-center hover:border-emerald-500 transition-colors">
                 <span className="text-3xl font-light text-emerald-700 mb-1">
                   {statsLoading ? '—' : stats.quizzes}
                 </span>
                 <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Quizzes</span>
               </div>

               {/* Stat Card 4 */}
               <div className="bg-white p-4 rounded-md border border-gray-200 shadow-sm flex flex-col items-center justify-center text-center hover:border-emerald-500 transition-colors">
                 <span className="text-3xl font-light text-emerald-700 mb-1">
                   {statsLoading ? '—' : stats.grades}
                 </span>
                 <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Grades</span>
               </div>
            </div>

            {/* Course Overview / Quick Actions Grid */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
                <h2 className="text-lg font-bold text-gray-800">Course Overview</h2>
                
                {/* Moodle Style Filter Dropdown (Visual) */}
                <div className="relative hidden sm:block">
                    <button className="flex items-center gap-2 text-sm font-medium text-gray-600 bg-white border border-gray-300 px-3 py-1 rounded">
                      <span>All (except removed from view)</span>
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                    </button>
                </div>
              </div>

              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Action 1 */}
                  <Link href="/student/course/view" className="group flex flex-col h-full bg-white border border-gray-200 rounded-md hover:shadow-md transition-all text-left overflow-hidden">
                    <div className="h-24 bg-gray-200 w-full flex items-center justify-center group-hover:bg-blue-50 transition-colors">
                       <svg className="w-10 h-10 text-gray-400 group-hover:text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-gray-800 group-hover:text-blue-700 group-hover:underline decoration-2 underline-offset-2">Browse Courses</h3>
                      <div className="w-full bg-gray-200 rounded-full h-1.5 mt-3 mb-2 overflow-hidden">
                        <div
                          className="bg-blue-600 h-1.5 rounded-full transition-all"
                          style={{ width: courseProgressWidth }}
                        ></div>
                      </div>
                      <p className="text-xs text-gray-500">
                        {statsLoading
                          ? 'Calculating progress…'
                          : stats.totalCourses === 0
                          ? 'No courses available yet'
                          : `${stats.courses} / ${stats.totalCourses} courses registered (${courseProgressPercent}% complete)`}
                      </p>
                    </div>
                  </Link>

                  {/* Action 2 */}
                  <Link href="/student/groups" className="group flex flex-col h-full bg-white border border-gray-200 rounded-md hover:shadow-md transition-all text-left overflow-hidden">
                    <div className="h-24 bg-gray-200 w-full flex items-center justify-center group-hover:bg-emerald-50 transition-colors">
                       <svg className="w-10 h-10 text-gray-400 group-hover:text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-gray-800 group-hover:text-emerald-700 group-hover:underline decoration-2 underline-offset-2">Join Groups</h3>
                      <p className="text-sm text-gray-500 mt-2">Find your peers</p>
                    </div>
                  </Link>

                  {/* Action 3 */}
                  <Link href="/student/quizzes" className="group flex flex-col h-full bg-white border border-gray-200 rounded-md hover:shadow-md transition-all text-left overflow-hidden">
                    <div className="h-24 bg-gray-200 w-full flex items-center justify-center group-hover:bg-purple-50 transition-colors">
                       <svg className="w-10 h-10 text-gray-400 group-hover:text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-gray-800 group-hover:text-purple-700 group-hover:underline decoration-2 underline-offset-2">Attempt Quizzes</h3>
                       <p className="text-sm text-gray-500 mt-2">Pending assessments</p>
                    </div>
                  </Link>

                  {/* Action 4 */}
                  <Link href="/student/results" className="group flex flex-col h-full bg-white border border-gray-200 rounded-md hover:shadow-md transition-all text-left overflow-hidden">
                     <div className="h-24 bg-gray-200 w-full flex items-center justify-center group-hover:bg-amber-50 transition-colors">
                       <svg className="w-10 h-10 text-gray-400 group-hover:text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-gray-800 group-hover:text-amber-700 group-hover:underline decoration-2 underline-offset-2">Grades & Results</h3>
                      <p className="text-sm text-gray-500 mt-2">View performance</p>
                    </div>
                  </Link>
                </div>
              </div>
            </div>

            {statsError && (
              <div className="bg-red-50 border border-red-200 text-red-600 rounded-md px-4 py-3 text-sm">
                {statsError}
              </div>
            )}

             {/* Recent Activity - Styled as Moodle "Recently Accessed" */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
               <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <h2 className="text-lg font-bold text-gray-800">Recently accessed courses</h2>
              </div>
              <div className="p-12 text-center">
                 <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                 </div>
                 <p className="text-gray-500">No recent activity</p>
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN (Sidebar - 1/3 width - "Blocks") */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* Timeline Block */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
                <h3 className="font-bold text-gray-800 text-sm">Timeline</h3>
              </div>
              <div className="p-5">
                 <div className="flex flex-col items-center justify-center py-6 text-center">
                   <svg className="w-10 h-10 text-gray-300 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                   <p className="text-xs text-gray-500">No upcoming activities due</p>
                 </div>
              </div>
            </div>

            {/* Announcements Block */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
                <h3 className="font-bold text-gray-800 text-sm">Latest announcements</h3>
              </div>
              <div className="p-5">
                <div className="text-xs text-gray-400 mb-1">Today</div>
                <Link href="#" className="block text-sm font-bold text-emerald-700 hover:underline mb-2">
                  Welcome to the new academic year
                </Link>
                <p className="text-xs text-gray-600 line-clamp-2">
                  Welcome to LearnIT LMS. Please ensure you have registered for all your core modules...
                </p>
                <div className="mt-4 pt-3 border-t border-gray-100">
                   <span className="text-xs text-gray-400">Older topics...</span>
                </div>
              </div>
            </div>

            {/* Private Files / User Block */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
                <h3 className="font-bold text-gray-800 text-sm">Private files</h3>
              </div>
              <div className="p-5">
                <p className="text-xs text-gray-500 mb-3">No files available</p>
                <button className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1.5 rounded border border-gray-300 transition-colors">
                  Manage private files...
                </button>
              </div>
            </div>
            
            {/* Help Block */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
                <h3 className="font-bold text-gray-800 text-sm">Support</h3>
              </div>
              <div className="p-5">
                 <p className="text-xs text-gray-600 mb-2">Need assistance with the platform?</p>
                 <a href="mailto:help@learnit.edu" className="text-sm text-emerald-700 hover:underline flex items-center gap-2">
                   <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                   Contact Help Desk
                 </a>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}