'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/lib/store';
import { studentApi, type ApiResponse } from '@/lib/api';

interface IUserSummary {
  _id: string;
  email: string;
}

interface IQuizSummary {
  _id: string;
  name: string;
}

interface IQuizResult {
  _id: string;
  marks: number;
  quizId?: IQuizSummary;
  userId?: IUserSummary;
  createdAt?: string;
}

interface ICourseGrade {
  registrationId: string;
  course: {
    _id: string;
    courseName: string;
    courseCode: string;
    courseCredit: number | null;
  } | null;
  group: {
    _id: string;
    name: string;
  } | null;
  assessments: {
    midSem: {
      obtained: number | null;
      outOf: number | null;
    };
    endSem: {
      obtained: number | null;
      outOf: number | null;
    };
    quizzes: Array<{
      quizId: string;
      name: string;
      marks: number;
      attemptedAt?: string;
    }>;
  };
  totals: {
    obtained: number;
    outOf: number;
    percentage: number | null;
  };
  grading?: {
    hasCompleteAssessment: boolean;
    finalGrade: string | null;
    finalPercentage: number | null;
    relativeRank: number | null;
  };
  approved?: boolean;
  status?: 'pending' | 'approved' | 'rejected';
  assessmentUpdatedAt?: string | null;
  assessmentUpdatedBy?: {
    _id?: string;
    email?: string;
  } | null;
}

export default function QuizResultsPage() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();

  const [loading, setLoading] = useState(true);
  const [resultsLoading, setResultsLoading] = useState(true);
  const [gradesLoading, setGradesLoading] = useState(true);
  const [error, setError] = useState('');
  const [gradesError, setGradesError] = useState('');
  const [results, setResults] = useState<IQuizResult[]>([]);
  const [courseGrades, setCourseGrades] = useState<ICourseGrade[]>([]);

  const formatComponentScore = (obtained: number | null | undefined, outOf: number | null | undefined) => {
    if (obtained === null || obtained === undefined) {
      return '—';
    }

    if (outOf === null || outOf === undefined || outOf === 0) {
      return `${obtained}`;
    }

    return `${obtained} / ${outOf}`;
  };

  const formatPercentage = (value: number | null | undefined) => {
    if (value === null || value === undefined) {
      return '—';
    }
    return `${value.toFixed(2)}%`;
  };

  const summarizeQuizMarks = (quizzes: ICourseGrade['assessments']['quizzes']) => {
    if (!quizzes || quizzes.length === 0) {
      return '—';
    }

    const total = quizzes.reduce((sum, quiz) => sum + (typeof quiz.marks === 'number' ? quiz.marks : 0), 0);
    const average = total / quizzes.length;
    const countLabel = `${quizzes.length} quiz${quizzes.length === 1 ? '' : 'zes'}`;
    return `${average.toFixed(1)}% avg (${countLabel})`;
  };

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/student');
      return;
    }

    if (user?.role !== 'student') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  useEffect(() => {
    if (!hydrationComplete || !isAuthenticated || user?.role !== 'student') {
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setError('');
      setGradesError('');
      setResultsLoading(true);
      setGradesLoading(true);
    });

    Promise.allSettled([studentApi.getMyCourseGrades(), studentApi.getMyQuizResults()])
      .then((responses) => {
        if (!isMounted) {
          return;
        }

        const [gradesResult, quizResult] = responses;

        if (gradesResult.status === 'fulfilled') {
          const gradeResponse = gradesResult.value as ApiResponse<ICourseGrade[]>;
          const gradeData = Array.isArray(gradeResponse.data) ? gradeResponse.data : [];
          setCourseGrades(gradeData);
          setGradesError('');
        } else {
          const message = gradesResult.reason instanceof Error
            ? gradesResult.reason.message
            : 'Failed to load course grades.';
          setGradesError(message);
          setCourseGrades([]);
        }

        if (quizResult.status === 'fulfilled') {
          const quizResponse = quizResult.value as ApiResponse<IQuizResult[]>;
          const quizData = Array.isArray(quizResponse.data) ? quizResponse.data : [];
          setResults(quizData);
          setError('');
        } else {
          const message = quizResult.reason instanceof Error
            ? quizResult.reason.message
            : 'Failed to load quiz results.';
          setError(message);
          setResults([]);
        }
      })
      .finally(() => {
        if (isMounted) {
          setResultsLoading(false);
          setGradesLoading(false);
        }
      });

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [hydrationComplete, isAuthenticated, user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-medium">Loading results...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/student/dashboard" className="hover:underline hover:text-emerald-700">Dashboard</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Results</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Results &amp; Grades</h1>
          <p className="text-sm text-gray-500 mt-1">Review your course grades and quiz performance in one place.</p>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12">
        {gradesError && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-200 mb-6">{gradesError}</p>}
        {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-200 mb-6">{error}</p>}

        <section className="mb-8">
          <div className="bg-white border border-gray-200 rounded-md shadow-sm">
            <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-800">Course Grades</h2>
                <p className="text-xs text-gray-500 mt-1">Mid-sem, end-sem, and quiz contributions for each enrolled course.</p>
              </div>
            </div>
            {gradesLoading ? (
              <div className="p-12 text-center text-gray-500">
                <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-sm font-medium">Fetching your course grades…</p>
              </div>
            ) : courseGrades.length === 0 ? (
              <div className="p-12 text-center text-gray-500">
                <h3 className="text-lg font-semibold text-gray-700">No graded courses yet.</h3>
                <p className="text-sm mt-2">Grades will appear here once your faculty publishes them.</p>
              </div>
            ) : (
              <div className="p-6 space-y-4">
                {courseGrades.map((grade) => {
                  const statusKey = (grade.status ?? (grade.approved ? 'approved' : 'pending')) as 'pending' | 'approved' | 'rejected';
                  const statusClasses =
                    statusKey === 'approved'
                      ? 'bg-emerald-100 text-emerald-700'
                      : statusKey === 'rejected'
                        ? 'bg-red-100 text-red-700'
                        : 'bg-yellow-100 text-yellow-700';
                  const statusLabel = statusKey.charAt(0).toUpperCase() + statusKey.slice(1);
                  const quizSummary = summarizeQuizMarks(grade.assessments.quizzes);
                  const lastUpdated = grade.assessmentUpdatedAt
                    ? new Date(grade.assessmentUpdatedAt).toLocaleString()
                    : null;
                  const hasComplete = grade.grading?.hasCompleteAssessment ?? false;
                  const finalGrade = hasComplete ? (grade.grading?.finalGrade ?? 'In Review') : 'Pending';
                  const finalPercentage = hasComplete
                    ? formatPercentage(
                        typeof grade.grading?.finalPercentage === 'number'
                          ? grade.grading.finalPercentage
                          : grade.totals.percentage
                      )
                    : 'Pending';
                  const rankLabel = hasComplete && typeof grade.grading?.relativeRank === 'number'
                    ? `#${grade.grading.relativeRank}`
                    : hasComplete
                      ? '—'
                      : 'Pending';

                  return (
                    <div key={grade.registrationId} className="border border-gray-200 rounded-md p-5 bg-gray-50">
                      <div className="flex flex-col gap-2 md:flex-row md:items-start md:justify-between">
                        <div>
                          <h3 className="text-base font-semibold text-gray-900">
                            {grade.course?.courseName ?? 'Course'}
                          </h3>
                          <p className="text-xs text-gray-500 mt-1">
                            {grade.course?.courseCode ?? '—'}
                            {grade.group ? ` • Group ${grade.group.name}` : ''}
                          </p>
                        </div>
                        <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${statusClasses}`}>
                          {statusLabel}
                        </span>
                      </div>

                      <div className="mt-4 grid gap-4 md:grid-cols-4 text-sm">
                        <div className="space-y-1">
                          <p className="text-xs uppercase text-gray-500">Mid-Semester</p>
                          <p className="text-sm font-semibold text-gray-800">{formatComponentScore(grade.assessments.midSem.obtained, grade.assessments.midSem.outOf)}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs uppercase text-gray-500">End-Semester</p>
                          <p className="text-sm font-semibold text-gray-800">{formatComponentScore(grade.assessments.endSem.obtained, grade.assessments.endSem.outOf)}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs uppercase text-gray-500">Quizzes</p>
                          <p className="text-sm font-semibold text-gray-800">{quizSummary}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs uppercase text-gray-500">Overall</p>
                          <p className="text-sm font-semibold text-emerald-700">{finalPercentage}</p>
                          <p className="text-xs text-gray-400">Total: {formatComponentScore(grade.totals.obtained, grade.totals.outOf)}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs uppercase text-gray-500">Final Grade</p>
                          <p className="text-sm font-semibold text-gray-800">{finalGrade}</p>
                          <p className="text-xs text-gray-400">Rank in Section: {rankLabel}</p>
                        </div>
                      </div>

                      {lastUpdated && (
                        <p className="mt-4 text-xs text-gray-500">
                          Updated on {lastUpdated}
                          {grade.assessmentUpdatedBy?.email ? ` by ${grade.assessmentUpdatedBy.email}` : ''}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>

        {resultsLoading ? (
          <div className="bg-white border border-gray-200 rounded-md shadow-sm p-12 text-center text-gray-500">
            <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-sm font-medium">Fetching your quiz results…</p>
          </div>
        ) : results.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-md shadow-sm p-12 text-center text-gray-500">
            <h2 className="text-lg font-semibold text-gray-700">No quiz results yet.</h2>
            <p className="text-sm mt-2">Attempt quizzes to see your performance breakdown here.</p>
          </div>
        ) : (
          <div className="bg-white border border-gray-200 rounded-md shadow-sm overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">Quiz</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">Score</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">Attempted On</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {results.map((result) => (
                  <tr key={result._id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{result.quizId?.name ?? 'Quiz'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{result.marks}%</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{result.createdAt ? new Date(result.createdAt).toLocaleString() : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
