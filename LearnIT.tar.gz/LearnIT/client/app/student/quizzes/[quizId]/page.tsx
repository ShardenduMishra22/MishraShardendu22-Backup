'use client';

import { useEffect, useMemo, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/lib/store';
import { studentApi, type ApiResponse } from '@/lib/api';

interface IQuizQuestion {
  _id: string;
  questionText: string;
  questionType: 'multiple-choice' | 'text';
  options: string[];
}

interface IQuizSummary {
  _id: string;
  name: string;
  groupId?: {
    _id: string;
    name: string;
    courseId?: {
      _id: string;
      courseName: string;
      courseCode: string;
    };
  };
  settings?: {
    timeLimitMinutes?: number | null;
    shuffleQuestions?: boolean;
    allowBackNavigation?: boolean;
    passingScore?: number | null;
    instructions?: string;
  };
}

export default function AttemptQuizPage() {
  const router = useRouter();
  const params = useParams<{ quizId: string }>();
  const quizId = useMemo(() => (Array.isArray(params?.quizId) ? params.quizId[0] : params?.quizId ?? ''), [params]);

  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();

  const [loading, setLoading] = useState(true);
  const [questionsLoading, setQuestionsLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [questions, setQuestions] = useState<IQuizQuestion[]>([]);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, string>>({});
  const [quizSummary, setQuizSummary] = useState<IQuizSummary | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState<number | null>(null);
  const [timerExpired, setTimerExpired] = useState(false);

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/student');
      return;
    }

    if (user?.role !== 'student') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  useEffect(() => {
    if (!quizId || !hydrationComplete || !isAuthenticated || user?.role !== 'student') {
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setError('');
      setSuccess('');
      setQuestionsLoading(true);
    });

    Promise.all([
      studentApi.getQuizQuestions(quizId),
      studentApi.getAvailableQuizzes(),
    ])
      .then(([questionsResponse, quizzesResponse]) => {
        if (!isMounted) {
          return;
        }

        const quizQuestions = (questionsResponse as ApiResponse<IQuizQuestion[]>).data ?? [];
        setQuestions(quizQuestions);

        const quizzes = (quizzesResponse as ApiResponse<IQuizSummary[]>).data ?? [];
        const summary = quizzes.find((quiz) => quiz._id === quizId) ?? null;
        setQuizSummary(summary);
        if (!summary) {
          setError('This quiz is no longer available to attempt or has already been completed.');
        }

        if (summary?.settings?.timeLimitMinutes && summary.settings.timeLimitMinutes > 0) {
          setTimerSeconds(summary.settings.timeLimitMinutes * 60);
        } else {
          setTimerSeconds(null);
        }
      })
      .catch((fetchError: unknown) => {
        if (!isMounted) {
          return;
        }
        const message = fetchError instanceof Error ? fetchError.message : 'Failed to load quiz questions.';
        setError(message);
      })
      .finally(() => {
        if (isMounted) {
          setQuestionsLoading(false);
        }
      });

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [quizId, hydrationComplete, isAuthenticated, user]);

  useEffect(() => {
    if (timerSeconds == null || timerSeconds <= 0 || submitting) {
      return;
    }

    const timerId = window.setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev == null) {
          return prev;
        }
        if (prev <= 1) {
          window.clearInterval(timerId);
          setTimerExpired(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => window.clearInterval(timerId);
  }, [timerSeconds, submitting]);

  useEffect(() => {
    if (timerExpired && !submitting) {
      setError('Time limit reached. Submitting your attempt...');
      handleSubmit({ bypassValidation: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timerExpired]);

  const handleSelectOption = (questionId: string, option: string) => {
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: option }));
  };

  const handleTextAnswerChange = (questionId: string, value: string) => {
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: value }));
  };

  const handleSubmit = async ({ bypassValidation = false }: { bypassValidation?: boolean } = {}) => {
    if (!quizId) {
      return;
    }

    if (questions.length === 0) {
      setError('No questions available for this quiz.');
      return;
    }

    if (!bypassValidation) {
      const unanswered = questions.filter((question) => !selectedAnswers[question._id] || selectedAnswers[question._id].trim() === '');
      if (unanswered.length > 0) {
        setError('Please answer all questions before submitting.');
        return;
      }
    }

    setSubmitting(true);
    setError('');
    setSuccess('');

    try {
      const payload = questions.map((question) => ({
        questionId: question._id,
        selectedAnswer: selectedAnswers[question._id] ?? '',
      }));

      const response = await studentApi.submitQuiz(quizId, payload);
      setSuccess(response.message || 'Quiz submitted successfully!');
      setTimerSeconds(null);
      setTimeout(() => {
        router.push('/student/quizzes');
      }, 1500);
    } catch (submitError) {
      const message = submitError instanceof Error ? submitError.message : 'Failed to submit quiz.';
      setError(message);
    } finally {
      setSubmitting(false);
    }
  };

  if (!quizId || loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-medium">Preparing your quiz…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/student/dashboard" className="hover:underline hover:text-emerald-700">Dashboard</Link>
            <span>/</span>
            <Link href="/student/quizzes" className="hover:underline hover:text-emerald-700">Quizzes</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Attempt</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">{quizSummary?.name ?? 'Quiz Attempt'}</h1>
          <p className="text-sm text-gray-500 mt-1">
            {quizSummary?.groupId?.courseId ? (
              <>
                {quizSummary.groupId.courseId.courseName}
                {' '}
                <span className="text-xs text-gray-400">({quizSummary.groupId.courseId.courseCode})</span>
                {' • '}
              </>
            ) : null}
            {quizSummary?.groupId ? `Group ${quizSummary.groupId.name} • ` : ''}
            Answer all questions and submit to record your attempt.
          </p>
          {quizSummary?.settings?.instructions ? (
            <p className="text-sm text-emerald-600 mt-2 bg-emerald-50 border border-emerald-200 rounded-md px-4 py-2">
              {quizSummary.settings.instructions}
            </p>
          ) : null}
          {timerSeconds != null && (
            <p className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 bg-white border border-emerald-200 rounded-md px-3 py-1">
              Time remaining: {Math.floor(timerSeconds / 60).toString().padStart(2, '0')}:{Math.floor(timerSeconds % 60).toString().padStart(2, '0')}
            </p>
          )}
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-4xl pb-12">
        {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-200 mb-6">{error}</p>}
        {success && <p className="text-sm text-green-600 bg-green-50 p-3 rounded-md border border-green-200 mb-6">{success}</p>}

        {questionsLoading ? (
          <div className="bg-white border border-gray-200 rounded-md shadow-sm p-12 text-center text-gray-500">
            <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-sm font-medium">Loading questions…</p>
          </div>
        ) : questions.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-md shadow-sm p-12 text-center text-gray-500">
            <h2 className="text-lg font-semibold text-gray-700">No questions found for this quiz.</h2>
            <p className="text-sm mt-2">Please contact your instructor for assistance.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {questions.map((question, index) => (
              <article key={question._id} className="bg-white border border-gray-200 rounded-md shadow-sm p-6">
                <header className="flex items-start gap-4">
                  <span className="text-sm font-semibold text-emerald-600">Q{index + 1}</span>
                  <h2 className="text-lg font-semibold text-gray-800">{question.questionText}</h2>
                </header>
                {question.questionType === 'multiple-choice' ? (
                  <div className="mt-4 space-y-2">
                    {question.options.map((option) => (
                      <label key={option} className="flex items-center gap-3 bg-gray-50 hover:bg-gray-100 rounded-md border border-gray-200 px-4 py-2 cursor-pointer">
                        <input
                          type="radio"
                          name={`question-${question._id}`}
                          value={option}
                          checked={selectedAnswers[question._id] === option}
                          onChange={() => handleSelectOption(question._id, option)}
                          className="text-emerald-600 focus:ring-emerald-500"
                        />
                        <span className="text-sm text-gray-700">{option}</span>
                      </label>
                    ))}
                  </div>
                ) : (
                  <div className="mt-4">
                    <textarea
                      name={`question-${question._id}`}
                      value={selectedAnswers[question._id] ?? ''}
                      onChange={(event) => handleTextAnswerChange(question._id, event.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500"
                      rows={4}
                      placeholder="Type your answer here"
                    />
                  </div>
                )}
              </article>
            ))}

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => router.push('/student/quizzes')}
                className="inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-300 rounded-md hover:bg-gray-100 transition-colors"
                disabled={submitting}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleSubmit()}
                disabled={submitting}
                className="inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md transition-colors disabled:bg-emerald-400"
              >
                {submitting ? 'Submitting…' : 'Submit Quiz'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
