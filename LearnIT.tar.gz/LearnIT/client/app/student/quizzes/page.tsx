'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/lib/store';
import { studentApi, type ApiResponse } from '@/lib/api';

interface IUserSummary {
  _id: string;
  email: string;
}

interface IGroupSummary {
  _id: string;
  name: string;
  courseId?: {
    _id: string;
    courseName: string;
    courseCode: string;
  };
}

interface IQuiz {
  _id: string;
  name: string;
  groupId?: IGroupSummary;
  facultyId?: IUserSummary;
  createdAt?: string;
  settings?: {
    timeLimitMinutes?: number | null;
    shuffleQuestions?: boolean;
    allowBackNavigation?: boolean;
    instructions?: string;
  };
}

export default function StudentQuizzesPage() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();

  const [loading, setLoading] = useState(true);
  const [quizzesLoading, setQuizzesLoading] = useState(true);
  const [error, setError] = useState('');
  const [quizzes, setQuizzes] = useState<IQuiz[]>([]);
  const [groupCount, setGroupCount] = useState(0);
  const [attemptedQuizCount, setAttemptedQuizCount] = useState(0);

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/student');
      return;
    }

    if (user?.role !== 'student') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  useEffect(() => {
    if (!hydrationComplete || !isAuthenticated || user?.role !== 'student') {
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setError('');
      setQuizzesLoading(true);
    });

    Promise.allSettled([
      studentApi.getAvailableQuizzes(),
      studentApi.getMyGroups(),
      studentApi.getMyQuizResults(),
    ])
      .then((responses) => {
        if (!isMounted) {
          return;
        }

        const [availableResult, groupsResult, attemptsResult] = responses;

        if (availableResult.status === 'fulfilled') {
          const quizData = (availableResult.value as ApiResponse<IQuiz[]>).data ?? [];
          setQuizzes(Array.isArray(quizData) ? quizData : []);
        } else {
          const reason = availableResult.reason instanceof Error
            ? availableResult.reason.message
            : 'Failed to load quizzes.';
          setError(reason);
        }

        if (groupsResult.status === 'fulfilled') {
          const groupData = (groupsResult.value as ApiResponse<unknown[]>).data ?? [];
          setGroupCount(Array.isArray(groupData) ? groupData.length : 0);
        } else {
          setGroupCount(0);
        }

        if (attemptsResult.status === 'fulfilled') {
          const quizAttempts = (attemptsResult.value as ApiResponse<unknown[]>).data ?? [];
          setAttemptedQuizCount(Array.isArray(quizAttempts) ? quizAttempts.length : 0);
        } else {
          setAttemptedQuizCount(0);
        }
      })
      .catch((fetchError: unknown) => {
        if (!isMounted) {
          return;
        }
        const message = fetchError instanceof Error ? fetchError.message : 'Failed to load quizzes.';
        setError(message);
      })
      .finally(() => {
        if (isMounted) {
          setQuizzesLoading(false);
        }
      });

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [hydrationComplete, isAuthenticated, user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-medium">Loading quizzes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/student/dashboard" className="hover:underline hover:text-emerald-700">Dashboard</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Quizzes</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Available Quizzes</h1>
          <p className="text-sm text-gray-500 mt-1">Attempt quizzes assigned within your registered groups.</p>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12">
        {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-200 mb-6">{error}</p>}

        {quizzesLoading ? (
          <div className="bg-white border border-gray-200 rounded-md shadow-sm p-12 text-center text-gray-500">
            <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-sm font-medium">Fetching quizzes…</p>
          </div>
        ) : quizzes.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-md shadow-sm p-12 text-center text-gray-500 space-y-3">
            <h2 className="text-lg font-semibold text-gray-700">
              {groupCount === 0
                ? 'Join a group to access quizzes.'
                : attemptedQuizCount > 0
                  ? 'You have completed all available quizzes.'
                  : 'No quizzes are available right now.'}
            </h2>
            <p className="text-sm mt-2 text-gray-500">
              {groupCount === 0
                ? 'Enroll in a course group first. Once a faculty member assigns a quiz to that group, it will appear here.'
                : attemptedQuizCount > 0
                  ? 'Great job! Your instructors have not posted any new quizzes yet. We will list them here as soon as they do.'
                  : 'Your instructors have not posted any quizzes for your registered groups yet. Check back later for updates.'}
            </p>
            <div className="flex justify-center gap-3 pt-2">
              {groupCount === 0 ? (
                <Link
                  href="/student/groups"
                  className="inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-white bg-emerald-600 rounded-md hover:bg-emerald-700 transition-colors"
                >
                  Browse Groups
                </Link>
              ) : attemptedQuizCount > 0 ? (
                <Link
                  href="/student/results"
                  className="inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-emerald-700 bg-emerald-50 rounded-md hover:bg-emerald-100 transition-colors"
                >
                  View Quiz History
                </Link>
              ) : null}
            </div>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            {quizzes.map((quiz) => (
              <article key={quiz._id} className="bg-white border border-gray-200 rounded-md shadow-sm p-6 flex flex-col justify-between hover:border-emerald-500 transition-colors">
                <div>
                  <h2 className="text-xl font-semibold text-gray-800">{quiz.name}</h2>
                  {quiz.groupId && (
                    <p className="text-sm text-gray-500 mt-1">
                      Group: <span className="font-medium">{quiz.groupId.name}</span>
                    </p>
                  )}
                  {quiz.groupId?.courseId && (
                    <p className="text-sm text-gray-500">
                      Course: <span className="font-medium">{quiz.groupId.courseId.courseName}</span>{' '}
                      <span className="text-xs text-gray-400">({quiz.groupId.courseId.courseCode})</span>
                    </p>
                  )}
                  {quiz.facultyId && (
                    <p className="text-xs text-gray-400 mt-1">Instructor: {quiz.facultyId.email}</p>
                  )}
                  {quiz.createdAt && (
                    <p className="text-xs text-gray-400 mt-2">Published {new Date(quiz.createdAt).toLocaleString()}</p>
                  )}
                  {quiz.settings && (
                    <div className="mt-3 text-xs text-gray-500 space-y-1">
                      <p>{quiz.settings.timeLimitMinutes ? `Time limit: ${quiz.settings.timeLimitMinutes} min` : 'No time limit'}</p>
                      <p>{quiz.settings.shuffleQuestions ? 'Questions shuffled' : 'Original order'}</p>
                      <p>{quiz.settings.allowBackNavigation ? 'Back navigation allowed' : 'Back navigation locked'}</p>
                      {quiz.settings.instructions ? (
                        <p className="truncate">Instructions: {quiz.settings.instructions}</p>
                      ) : null}
                    </div>
                  )}
                </div>
                <div className="mt-6 flex justify-end">
                  <button
                    type="button"
                    onClick={() => router.push(`/student/quizzes/${quiz._id}`)}
                    className="inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold px-4 py-2 rounded-md transition-colors"
                  >
                    Attempt Quiz
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
