'use client';

import { useEffect, useMemo, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/lib/store';
import { facultyApi, type ApiResponse } from '@/lib/api';

interface IQuizSettings {
  timeLimitMinutes: number | null;
  shuffleQuestions: boolean;
  allowBackNavigation: boolean;
  passingScore: number | null;
  instructions: string;
}

interface IQuizSummary {
  _id: string;
  name: string;
  settings?: Partial<IQuizSettings>;
}

export default function QuizSettingsPage() {
  const params = useParams();
  const quizId = useMemo(() => (Array.isArray(params?.quizId) ? params.quizId[0] : params?.quizId ?? ''), [params]);
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth } = useUserStore();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [quiz, setQuiz] = useState<IQuizSummary | null>(null);
  const [timeLimit, setTimeLimit] = useState<string>('');
  const [shuffleQuestions, setShuffleQuestions] = useState(false);
  const [allowBackNavigation, setAllowBackNavigation] = useState(true);
  const [passingScore, setPassingScore] = useState<string>('');
  const [instructions, setInstructions] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    initializeAuth();
  }, [initializeAuth]);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }

    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    if (!quizId) {
      setError('Quiz identifier is missing.');
      setLoading(false);
      return;
    }

    const fetchQuiz = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await facultyApi.getMyQuizzes();
        const quizzes = (response as ApiResponse<IQuizSummary[]>).data ?? [];
        const currentQuiz = quizzes.find((q) => q._id === quizId) ?? null;
        setQuiz(currentQuiz);

        const settings = currentQuiz?.settings ?? {};
        setTimeLimit(settings.timeLimitMinutes != null ? String(settings.timeLimitMinutes) : '');
        setShuffleQuestions(Boolean(settings.shuffleQuestions));
        setAllowBackNavigation(settings.allowBackNavigation !== false);
        setPassingScore(settings.passingScore != null ? String(settings.passingScore) : '');
        setInstructions(settings.instructions ?? '');
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to load quiz settings.';
        setError(message);
      } finally {
        setLoading(false);
      }
    };

    fetchQuiz();
  }, [quizId, isAuthenticated, user, router]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!quizId) {
      setError('Quiz identifier is missing.');
      return;
    }

    setSaving(true);
    setError('');
    setSuccess('');

    const parsedTimeLimit = timeLimit.trim() === '' ? null : Number(timeLimit);
    const parsedPassingScore = passingScore.trim() === '' ? null : Number(passingScore);

    if (parsedTimeLimit != null && (Number.isNaN(parsedTimeLimit) || parsedTimeLimit <= 0)) {
      setError('Time limit must be a positive number of minutes.');
      setSaving(false);
      return;
    }

    if (parsedPassingScore != null && (Number.isNaN(parsedPassingScore) || parsedPassingScore < 0 || parsedPassingScore > 100)) {
      setError('Passing score must be between 0 and 100.');
      setSaving(false);
      return;
    }

    try {
      await facultyApi.updateQuizSettings(quizId, {
        timeLimitMinutes: parsedTimeLimit,
        shuffleQuestions,
        allowBackNavigation,
        passingScore: parsedPassingScore,
        instructions,
      });
      setSuccess('Quiz settings updated successfully.');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to update settings.';
      setError(message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="bg-white border border-gray-200 rounded-md shadow-sm p-6 text-center">
          <p className="text-gray-700 font-medium">Quiz not found.</p>
          <button
            type="button"
            onClick={() => router.push('/faculty/quiz/view')}
            className="mt-4 inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-md"
          >
            Back to My Quizzes
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
            <span>/</span>
            <Link href="/faculty/quiz/view" className="hover:underline hover:text-purple-700">My Quizzes</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Settings</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Quiz Settings</h1>
          <p className="text-sm text-gray-500 mt-1">Configure how <span className="font-medium">{quiz.name}</span> behaves for students.</p>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-4xl pb-12">
        <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && <p className="text-sm text-red-600 bg-red-50 border border-red-200 p-3 rounded-md">{error}</p>}
            {success && <p className="text-sm text-green-600 bg-green-50 border border-green-200 p-3 rounded-md">{success}</p>}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Time limit (minutes)</label>
              <input
                type="number"
                min={1}
                value={timeLimit}
                onChange={(event) => setTimeLimit(event.target.value)}
                placeholder="Leave blank for no time limit"
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <label className="flex items-center gap-3 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={shuffleQuestions}
                  onChange={(event) => setShuffleQuestions(event.target.checked)}
                  className="h-4 w-4 text-purple-600 focus:ring-purple-500"
                />
                Shuffle question order
              </label>
              <label className="flex items-center gap-3 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={allowBackNavigation}
                  onChange={(event) => setAllowBackNavigation(event.target.checked)}
                  className="h-4 w-4 text-purple-600 focus:ring-purple-500"
                />
                Allow students to revisit earlier questions
              </label>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Passing score (%)</label>
              <input
                type="number"
                min={0}
                max={100}
                value={passingScore}
                onChange={(event) => setPassingScore(event.target.value)}
                placeholder="Leave blank to disable"
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Instructions</label>
              <textarea
                value={instructions}
                onChange={(event) => setInstructions(event.target.value)}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
                placeholder="Add any notes or directions students should read before attempting the quiz."
              />
            </div>

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => router.back()}
                className="px-4 py-2 text-sm font-semibold text-gray-600 border border-gray-300 rounded-md hover:bg-gray-100"
                disabled={saving}
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-4 py-2 text-sm font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-md disabled:bg-purple-400"
              >
                {saving ? 'Saving…' : 'Save Settings'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
