'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { facultyApi } from '@/lib/api';

interface IQuestion {
  _id: string;
  questionText: string;
  questionType: 'multiple-choice' | 'text';
  options: string[];
  answer: string;
}

export default function ViewQuizQuestions() {
  const router = useRouter();
  const params = useParams();
  const quizParam = Array.isArray(params.quizId) ? params.quizId[0] : params.quizId;
  const quizId = quizParam ?? '';
  const { user, isAuthenticated, initializeAuth } = useUserStore();
  
  const [loading, setLoading] = useState(true);
  const [questions, setQuestions] = useState<IQuestion[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    initializeAuth();
    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }
    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    const fetchQuestions = async () => {
      if (!quizId) {
        setError('Quiz identifier is missing.');
        setLoading(false);
        return;
      }
      try {
        const response = await facultyApi.getQuizQuestions(quizId);
        setQuestions((response.data as IQuestion[]) || []);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to fetch questions.';
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    fetchQuestions();
  }, [isAuthenticated, user, router, initializeAuth, quizId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
            <span>/</span>
            <Link href="/faculty/quiz/view" className="hover:underline hover:text-purple-700">My Quizzes</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">View Questions</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Quiz Questions</h1>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-4xl pb-12">
        {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md mb-6">{error}</p>}
        
        {questions.length === 0 && !error ? (
          <div className="text-center py-12 px-6 bg-white rounded-md border border-gray-200 shadow-sm">
            <h2 className="text-xl font-semibold text-gray-700">No questions found for this quiz.</h2>
            <Link href={`/faculty/quiz/${quizId}/questions/add`}>
                <button className="mt-4 bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors">
                    Add a Question
                </button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {questions.map((q, index) => (
              <div key={q._id} className="bg-white rounded-md border border-gray-200 shadow-sm p-6">
                <div className="flex items-start justify-between gap-4">
                  <p className="font-semibold text-gray-800 flex-1">{index + 1}. {q.questionText}</p>
                  <span className="text-xs uppercase tracking-wide px-2 py-1 rounded-full bg-purple-100 text-purple-700">{q.questionType === 'text' ? 'Text Response' : 'Multiple Choice'}</span>
                </div>
                {q.questionType === 'multiple-choice' ? (
                  <div className="mt-4 space-y-2">
                    {q.options.map((opt, i) => (
                      <p key={i} className={`text-sm p-2 rounded-md ${opt === q.answer ? 'bg-green-100 text-green-800 font-bold' : 'bg-gray-100 text-gray-700'}`}>
                        {opt}
                      </p>
                    ))}
                  </div>
                ) : (
                  <div className="mt-4 bg-gray-100 border border-gray-200 rounded-md p-3">
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Reference Answer</p>
                    <p className="text-sm text-gray-800 mt-1 whitespace-pre-wrap">{q.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
