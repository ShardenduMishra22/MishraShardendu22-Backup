'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { facultyApi } from '@/lib/api';

export default function AddQuizQuestion() {
  const router = useRouter();
  const params = useParams();
  const quizParam = Array.isArray(params.quizId) ? params.quizId[0] : params.quizId;
  const quizId = quizParam ?? '';
  const { user, isAuthenticated, initializeAuth } = useUserStore();
  
  const [loading, setLoading] = useState(true);
  const [questionText, setQuestionText] = useState('');
  const [questionType, setQuestionType] = useState<'multiple-choice' | 'text'>('multiple-choice');
  const [options, setOptions] = useState(['', '', '', '']);
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    initializeAuth();
  }, [initializeAuth]);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }
    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [isAuthenticated, user, router]);

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const filteredOptions = options.filter(opt => opt.trim() !== '');
    if (!questionText.trim()) {
      setError('Please enter a question prompt.');
      return;
    }

    if (questionType === 'multiple-choice') {
      if (filteredOptions.length < 2) {
        setError('Please provide at least two answer options.');
        return;
      }
      if (!filteredOptions.includes(answer)) {
        setError('Select a correct answer from the provided options.');
        return;
      }
    } else {
      if (!answer.trim()) {
        setError('Provide the expected answer for this text question.');
        return;
      }
    }

    if (!quizId) {
      setError('Quiz identifier is missing.');
      return;
    }

    try {
      const payloadOptions = questionType === 'multiple-choice' ? filteredOptions : [];
      await facultyApi.addQuizQuestion(quizId, questionText, payloadOptions, answer, questionType);
      setSuccess('Question added successfully!');
      setQuestionText('');
      setQuestionType('multiple-choice');
      setOptions(['', '', '', '']);
      setAnswer('');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to add question.';
      setError(errorMessage);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
            <span>/</span>
            <Link href="/faculty/quiz/view" className="hover:underline hover:text-purple-700">My Quizzes</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Add Question</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Add Quiz Question</h1>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-4xl pb-12">
        <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="questionText" className="block text-sm font-medium text-gray-700 mb-1">Question</label>
              <textarea
                id="questionText"
                value={questionText}
                onChange={(e) => setQuestionText(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
                rows={3}
                placeholder="Enter the question text"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="radio"
                  name="questionType"
                  value="multiple-choice"
                  checked={questionType === 'multiple-choice'}
                  onChange={() => {
                    setQuestionType('multiple-choice');
                    setAnswer('');
                  }}
                  className="h-4 w-4 text-purple-600 focus:ring-purple-500"
                />
                Multiple Choice
              </label>
              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="radio"
                  name="questionType"
                  value="text"
                  checked={questionType === 'text'}
                  onChange={() => {
                    setQuestionType('text');
                    setAnswer('');
                  }}
                  className="h-4 w-4 text-purple-600 focus:ring-purple-500"
                />
                Text Response
              </label>
            </div>

            {questionType === 'multiple-choice' ? (
              <div className="space-y-4">
                <label className="block text-sm font-medium text-gray-700">Options</label>
                {options.map((option, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <input
                      type="text"
                      value={option}
                      onChange={(e) => handleOptionChange(index, e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
                      placeholder={`Option ${index + 1}`}
                    />
                     <input
                      type="radio"
                      name="answer"
                      value={option}
                      checked={answer === option}
                      onChange={(e) => setAnswer(e.target.value)}
                      className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300"
                      disabled={!option.trim()}
                    />
                  </div>
                ))}
              </div>
            ) : (
              <div>
                <label htmlFor="textAnswer" className="block text-sm font-medium text-gray-700 mb-1">Expected Answer</label>
                <textarea
                  id="textAnswer"
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
                  rows={3}
                  placeholder="Provide the reference answer students should match."
                />
              </div>
            )}
            
            {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md">{error}</p>}
            {success && <p className="text-sm text-green-600 bg-green-50 p-3 rounded-md">{success}</p>}

            <div>
              <button
                type="submit"
                className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors"
              >
                Add Question
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
