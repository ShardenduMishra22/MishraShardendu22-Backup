'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { facultyApi, type ApiResponse } from '@/lib/api';

interface IResult {
  _id: string;
  studentId: {
    _id: string;
    email: string;
  } | null;
  score: number;
  totalQuestions: number;
  percentage: number;
  submittedAt: string;
}

export default function QuizResults() {
  const router = useRouter();
  const params = useParams();
  const { quizId } = params;
  const { user, isAuthenticated, initializeAuth } = useUserStore();
  
  const [loading, setLoading] = useState(true);
  const [results, setResults] = useState<IResult[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    initializeAuth();
    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }
    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    const fetchResults = async () => {
      if (!quizId) return;
      try {
        const normalizedQuizId = Array.isArray(quizId) ? quizId[0] : quizId;
        if (!normalizedQuizId) {
          setError('Invalid quiz identifier.');
          return;
        }

        const response = await facultyApi.getQuizResults(normalizedQuizId);
        const resultsData = (response as ApiResponse<IResult[]>).data ?? [];
        setResults(resultsData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch quiz results.');
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [isAuthenticated, user, router, initializeAuth, quizId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
            <span>/</span>
            <Link href="/faculty/quiz/view" className="hover:underline hover:text-purple-700">My Quizzes</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Quiz Results</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Quiz Results</h1>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12">
        {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md mb-6">{error}</p>}
        
        <div className="bg-white rounded-md border border-gray-200 shadow-sm overflow-x-auto">
          {results.length === 0 && !error ? (
            <div className="text-center py-12 px-6">
              <h2 className="text-xl font-semibold text-gray-700">No results found for this quiz yet.</h2>
              <p className="text-gray-500 mt-2">Results will appear here once students start taking the quiz.</p>
            </div>
          ) : (
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Correct</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Percentage</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Submitted On</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {results.map((result) => (
                  <tr key={result._id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{result?.studentId?.email ?? 'Unknown student'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{result.score} / {result.totalQuestions}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{result.percentage.toLocaleString(undefined, { maximumFractionDigits: 2, minimumFractionDigits: 0 })}%</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(result.submittedAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
