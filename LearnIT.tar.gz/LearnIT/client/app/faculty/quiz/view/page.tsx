'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { facultyApi } from '@/lib/api';

interface IQuiz {
  _id: string;
  name: string;
  groupId: {
    _id: string;
    name: string;
  };
  createdAt: string;
  settings?: {
    timeLimitMinutes?: number | null;
    shuffleQuestions?: boolean;
    allowBackNavigation?: boolean;
    passingScore?: number | null;
    instructions?: string;
  };
}

export default function MyQuizzes() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth } = useUserStore();
  const [loading, setLoading] = useState(true);
  const [quizzes, setQuizzes] = useState<IQuiz[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    initializeAuth();
    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }
    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }
    
    const fetchQuizzes = async () => {
      try {
        const response = await facultyApi.getMyQuizzes();
        setQuizzes((response.data as IQuiz[]) || []);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to fetch quizzes.';
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    fetchQuizzes();
  }, [isAuthenticated, user, router, initializeAuth]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
                <span>/</span>
                <span className="text-gray-800 font-semibold">My Quizzes</span>
              </div>
              <h1 className="text-3xl font-light text-gray-800">My Quizzes</h1>
            </div>
            <Link href="/faculty/quiz/create">
              <button className="bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors">
                Create New Quiz
              </button>
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12">
        {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md mb-6">{error}</p>}
        
        {quizzes.length === 0 && !error ? (
          <div className="text-center py-12 px-6 bg-white rounded-md border border-gray-200 shadow-sm">
            <h2 className="text-xl font-semibold text-gray-700">No quizzes found.</h2>
            <p className="text-gray-500 mt-2">Get started by creating a new quiz for one of your groups.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quizzes.map((quiz) => (
              <div key={quiz._id} className="bg-white rounded-md border border-gray-200 shadow-sm overflow-hidden hover:shadow-lg transition-shadow">
                <div className="p-6">
                  <h2 className="text-xl font-bold text-gray-900 truncate pr-4">{quiz.name}</h2>
                  <p className="text-sm text-gray-600 mt-1">Group: {quiz.groupId.name}</p>
                  <p className="text-xs text-gray-400 mt-4">Created: {new Date(quiz.createdAt).toLocaleDateString()}</p>
                  {quiz.settings && (
                    <div className="mt-4 text-xs text-gray-500 space-y-1">
                      {quiz.settings.timeLimitMinutes ? (
                        <p>Time limit: {quiz.settings.timeLimitMinutes} min</p>
                      ) : (
                        <p>No time limit</p>
                      )}
                      <p>{quiz.settings.shuffleQuestions ? 'Questions shuffled' : 'Original order'}</p>
                      <p>{quiz.settings.allowBackNavigation ? 'Back navigation allowed' : 'Back navigation locked'}</p>
                      {typeof quiz.settings.passingScore === 'number' ? (
                        <p>Passing score: {quiz.settings.passingScore}%</p>
                      ) : null}
                      {quiz.settings.instructions ? (
                        <p className="truncate">Instructions: {quiz.settings.instructions}</p>
                      ) : null}
                    </div>
                  )}
                </div>
                <div className="bg-gray-50 border-t border-gray-100 px-6 py-3 flex justify-end gap-4 flex-wrap">
                   <Link href={`/faculty/quiz/${quiz._id}/questions/add`}>
                    <button className="text-xs text-purple-700 hover:underline font-medium">Add Questions</button>
                  </Link>
                   <Link href={`/faculty/quiz/${quiz._id}/questions/view`}>
                    <button className="text-xs text-purple-700 hover:underline font-medium">View Questions</button>
                  </Link>
                  <Link href={`/faculty/quiz/${quiz._id}/results`}>
                    <button className="text-xs text-purple-700 hover:underline font-medium">View Results</button>
                  </Link>
                  <Link href={`/faculty/quiz/${quiz._id}/settings`}>
                    <button className="text-xs text-purple-700 hover:underline font-medium">Quiz Settings</button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
