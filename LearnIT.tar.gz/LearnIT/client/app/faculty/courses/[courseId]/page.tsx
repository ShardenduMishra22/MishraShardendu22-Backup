'use client';

import { useCallback, useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/lib/store';
import { facultyApi, type ApiResponse } from '@/lib/api';

interface FacultyCourse {
  _id: string;
  courseCode: string;
  courseCredit: number;
  courseName: string;
  createdAt?: string;
  updatedAt?: string;
}

interface FacultyGroup {
  _id: string;
  name: string;
  registrationOpen: boolean;
  createdAt?: string;
  updatedAt?: string;
  courseId?: {
    _id: string;
    courseCode: string;
    courseName: string;
  } | string;
}

interface FacultyQuiz {
  _id: string;
  name: string;
  createdAt?: string;
  groupId?: {
    _id: string;
    name: string;
    courseId?: {
      _id: string;
      courseCode: string;
      courseName: string;
    } | string;
  };
}

const extractId = (value: unknown): string => {
  if (!value) {
    return '';
  }

  if (typeof value === 'string') {
    return value;
  }

  if (typeof value === 'object') {
    const maybeId = (value as { _id?: unknown })._id;
    if (maybeId !== undefined) {
      return extractId(maybeId);
    }
  }

  if (typeof (value as { toString?: () => string }).toString === 'function') {
    return (value as { toString: () => string }).toString();
  }

  return '';
};

export default function FacultyCourseDetailPage() {
  const params = useParams<{ courseId: string }>();
  const router = useRouter();
  const {
    user,
    isAuthenticated,
    initializeAuth,
    hydrationComplete,
  } = useUserStore();

  const courseId = useMemo(
    () => (Array.isArray(params?.courseId) ? params.courseId[0] : params?.courseId ?? ''),
    [params]
  );

  const [pageLoading, setPageLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(true);
  const [dataError, setDataError] = useState('');
  const [course, setCourse] = useState<FacultyCourse | null>(null);
  const [groups, setGroups] = useState<FacultyGroup[]>([]);
  const [quizzes, setQuizzes] = useState<FacultyQuiz[]>([]);

  const [groupForm, setGroupForm] = useState({
    name: '',
    registrationOpen: true,
  });
  const [groupFormStatus, setGroupFormStatus] = useState<{ error: string; success: string }>({
    error: '',
    success: '',
  });
  const [creatingGroup, setCreatingGroup] = useState(false);

  const [quizForm, setQuizForm] = useState({
    name: '',
    groupId: '',
  });
  const [quizFormStatus, setQuizFormStatus] = useState<{ error: string; success: string }>({
    error: '',
    success: '',
  });
  const [creatingQuiz, setCreatingQuiz] = useState(false);

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }

    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setPageLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  const hydrateGroupsAndQuizzes = useCallback(async () => {
    if (!courseId) {
      return;
    }

    const normalizedCourseId = courseId.toString().trim();
    if (!normalizedCourseId) {
      return;
    }

    const [groupsResponse, quizzesResponse] = await Promise.all([
      facultyApi.getMyGroups(),
      facultyApi.getMyQuizzes(),
    ]);

    const rawGroups = (groupsResponse as ApiResponse<FacultyGroup[]>).data ?? [];
    const filteredGroups = rawGroups.filter((group) => extractId(group.courseId) === normalizedCourseId);
    filteredGroups.sort((a, b) => a.name.localeCompare(b.name));
    const courseGroupIds = new Set(filteredGroups.map((group) => group._id));

    const rawQuizzes = (quizzesResponse as ApiResponse<FacultyQuiz[]>).data ?? [];
    const filteredQuizzes = rawQuizzes.filter(
      (quiz) => {
        const quizCourseId = extractId(quiz.groupId?.courseId);
        if (quizCourseId === normalizedCourseId) {
          return true;
        }

        const quizGroupId = extractId(quiz.groupId);
        return quizGroupId ? courseGroupIds.has(quizGroupId) : false;
      }
    );
    filteredQuizzes.sort((a, b) => (b.createdAt ?? '').localeCompare(a.createdAt ?? ''));

    setGroups(filteredGroups);
    setQuizzes(filteredQuizzes);

    setQuizForm((prev) => {
      if (filteredGroups.length === 0) {
        return { ...prev, groupId: '' };
      }

      if (prev.groupId && filteredGroups.some((group) => group._id === prev.groupId)) {
        return prev;
      }

      return { ...prev, groupId: filteredGroups[0]._id };
    });
  }, [courseId]);

  useEffect(() => {
    if (!courseId || pageLoading) {
      return;
    }

    let isMounted = true;

    const loadData = async () => {
      setDataError('');
      setDataLoading(true);

      try {
        const coursesResponse = await facultyApi.getMyCourses();
        if (!isMounted) {
          return;
        }

        const facultyCourses = (coursesResponse as ApiResponse<FacultyCourse[]>).data ?? [];
        const currentCourse = facultyCourses.find((entry) => entry._id === courseId) ?? null;

        if (!currentCourse) {
          setCourse(null);
          setDataError('Course not found or you do not have access to it.');
          setGroups([]);
          setQuizzes([]);
          setQuizForm((prev) => ({ ...prev, groupId: '' }));
          return;
        }

        setCourse(currentCourse);
        await hydrateGroupsAndQuizzes();
      } catch (error) {
        if (!isMounted) {
          return;
        }
        const message = error instanceof Error ? error.message : 'Unable to load course details.';
        setDataError(message);
        setCourse(null);
        setGroups([]);
        setQuizzes([]);
      } finally {
        if (isMounted) {
          setDataLoading(false);
        }
      }
    };

    loadData();

    return () => {
      isMounted = false;
    };
  }, [courseId, pageLoading, hydrateGroupsAndQuizzes]);

  const handleGroupFormChange = (event: ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = event.target;
    setGroupForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleCreateGroup = async (event: FormEvent) => {
    event.preventDefault();
    setGroupFormStatus({ error: '', success: '' });

    if (!courseId) {
      setGroupFormStatus({ error: 'Missing course identifier.', success: '' });
      return;
    }

    if (!groupForm.name.trim()) {
      setGroupFormStatus({ error: 'Please provide a group name.', success: '' });
      return;
    }

    try {
      setCreatingGroup(true);
      await facultyApi.createGroup(groupForm.name.trim(), courseId, groupForm.registrationOpen);
      setGroupFormStatus({ error: '', success: 'Group created successfully.' });
      setGroupForm({ name: '', registrationOpen: true });
      await hydrateGroupsAndQuizzes();
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to create group.';
      setGroupFormStatus({ error: message, success: '' });
    } finally {
      setCreatingGroup(false);
    }
  };

  const handleQuizFormChange = (event: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = event.target;
    setQuizForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleCreateQuiz = async (event: FormEvent) => {
    event.preventDefault();
    setQuizFormStatus({ error: '', success: '' });

    if (!quizForm.name.trim() || !quizForm.groupId) {
      setQuizFormStatus({ error: 'Please provide a quiz name and select a group.', success: '' });
      return;
    }

    try {
      setCreatingQuiz(true);
      const response = await facultyApi.createQuiz(quizForm.name.trim(), quizForm.groupId);
      const quizName = (response.data as { name?: string })?.name ?? quizForm.name.trim();
      setQuizFormStatus({ error: '', success: `Quiz "${quizName}" created. You can now add questions.` });
      setQuizForm((prev) => ({ ...prev, name: '' }));
      await hydrateGroupsAndQuizzes();
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to create quiz.';
      setQuizFormStatus({ error: message, success: '' });
    } finally {
      setCreatingQuiz(false);
    }
  };

  if (!courseId || pageLoading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-medium">Loading course dashboard…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
                <span>/</span>
                <span className="text-gray-800 font-semibold">Course Manager</span>
              </div>
              <h1 className="text-3xl font-light text-gray-800">
                {course?.courseName ?? 'Course Overview'}
              </h1>
              {course && (
                <p className="text-sm text-gray-500 mt-1">
                  {course.courseCode} • {course.courseCredit} credit{course.courseCredit === 1 ? '' : 's'}
                </p>
              )}
            </div>
            <Link
              href="/faculty/group/create"
              className="inline-flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 text-white text-sm font-semibold px-4 py-2 rounded-md transition-colors"
            >
              Create Group
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12 space-y-8">
        {dataError && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-md px-4 py-3 text-sm">
            {dataError}
          </div>
        )}

        {dataLoading ? (
          <div className="bg-white border border-gray-200 rounded-md shadow-sm p-12 text-center text-gray-500">
            <div className="w-10 h-10 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-sm font-medium">Fetching course data…</p>
          </div>
        ) : course ? (
          <>
            <section className="bg-white rounded-md border border-gray-200 shadow-sm p-6">
              <h2 className="text-lg font-bold text-gray-800 mb-4">Course Snapshot</h2>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div className="border border-purple-100 rounded-md p-4 bg-purple-50">
                  <p className="text-xs font-semibold uppercase text-purple-500">Course Code</p>
                  <p className="text-xl font-semibold text-gray-900 mt-2">{course.courseCode}</p>
                </div>
                <div className="border border-purple-100 rounded-md p-4 bg-purple-50">
                  <p className="text-xs font-semibold uppercase text-purple-500">Credits</p>
                  <p className="text-xl font-semibold text-gray-900 mt-2">{course.courseCredit}</p>
                </div>
                <div className="border border-purple-100 rounded-md p-4 bg-purple-50">
                  <p className="text-xs font-semibold uppercase text-purple-500">Groups</p>
                  <p className="text-xl font-semibold text-gray-900 mt-2">{groups.length}</p>
                </div>
                <div className="border border-purple-100 rounded-md p-4 bg-purple-50">
                  <p className="text-xs font-semibold uppercase text-purple-500">Quizzes</p>
                  <p className="text-xl font-semibold text-gray-900 mt-2">{quizzes.length}</p>
                </div>
              </div>
            </section>

            <section className="bg-white rounded-md border border-gray-200 shadow-sm p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                <h2 className="text-lg font-bold text-gray-800">Groups for this Course</h2>
                <Link
                  href={`/faculty/group/create?courseId=${course._id}`}
                  className="inline-flex items-center justify-center gap-2 border border-purple-200 text-purple-700 px-3 py-1.5 text-xs font-semibold rounded-md hover:bg-purple-50 transition-colors"
                >
                  Add Group
                </Link>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                {groups.length === 0 ? (
                  <div className="col-span-2">
                    <div className="border border-dashed border-purple-200 rounded-md p-6 text-center text-sm text-gray-500">
                      No groups created for this course yet. Use the form below to create one and enroll your students.
                    </div>
                  </div>
                ) : (
                  groups.map((group) => (
                    <div key={group._id} className="border border-gray-200 rounded-md p-4 shadow-sm">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{group.name}</h3>
                          <p className="text-xs text-gray-400 mt-1">
                            Created {group.createdAt ? new Date(group.createdAt).toLocaleDateString() : 'recently'}
                          </p>
                        </div>
                        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${group.registrationOpen ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                          {group.registrationOpen ? 'Registration Open' : 'Registration Closed'}
                        </span>
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Link
                          href={`/faculty/group/${group._id}/registrations`}
                          className="text-xs text-purple-700 font-semibold hover:underline"
                        >
                          View Registrations
                        </Link>
                        <span className="text-xs text-gray-300">•</span>
                        <Link
                          href={`/faculty/group/${group._id}/edit`}
                          className="text-xs text-purple-700 font-semibold hover:underline"
                        >
                          Edit Group
                        </Link>
                        <span className="text-xs text-gray-300">•</span>
                        <button
                          type="button"
                          onClick={() => setQuizForm((prev) => ({ ...prev, groupId: group._id }))}
                          className="text-xs text-purple-700 font-semibold hover:underline"
                        >
                          Use for Quiz
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <form onSubmit={handleCreateGroup} className="mt-6 border border-purple-100 bg-purple-50 rounded-md p-4 space-y-4">
                <h3 className="text-sm font-semibold text-purple-700">Quick Create Group</h3>
                <div className="grid gap-3 md:grid-cols-[2fr_1fr]">
                  <div>
                    <label htmlFor="group-name" className="block text-xs font-semibold uppercase text-purple-600 mb-1">Group Name</label>
                    <input
                      id="group-name"
                      name="name"
                      type="text"
                      value={groupForm.name}
                      onChange={handleGroupFormChange}
                      placeholder="e.g., Section A"
                      className="w-full px-3 py-2 border border-purple-200 rounded-md focus:ring-purple-500 focus:border-purple-500 text-sm"
                    />
                  </div>
                  <label className="flex items-center gap-2 text-xs font-semibold text-purple-600 mt-6 md:mt-0">
                    <input
                      type="checkbox"
                      name="registrationOpen"
                      checked={groupForm.registrationOpen}
                      onChange={handleGroupFormChange}
                      className="w-4 h-4 text-purple-600 focus:ring-purple-500"
                    />
                    Registration open
                  </label>
                </div>
                {groupFormStatus.error && (
                  <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-md px-3 py-2">
                    {groupFormStatus.error}
                  </p>
                )}
                {groupFormStatus.success && (
                  <p className="text-xs text-green-600 bg-green-50 border border-green-200 rounded-md px-3 py-2">
                    {groupFormStatus.success}
                  </p>
                )}
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={creatingGroup}
                    className="inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-md transition-colors disabled:bg-purple-400"
                  >
                    {creatingGroup ? 'Creating…' : 'Create Group'}
                  </button>
                </div>
              </form>
            </section>

            <section className="bg-white rounded-md border border-gray-200 shadow-sm p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                <div>
                  <h2 className="text-lg font-bold text-gray-800">Quizzes for this Course</h2>
                  <p className="text-xs text-gray-500">Create quizzes for any group enrolled in the course and manage their questions.</p>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                {quizzes.length === 0 ? (
                  <div className="col-span-2">
                    <div className="border border-dashed border-purple-200 rounded-md p-6 text-center text-sm text-gray-500">
                      No quizzes created yet. Use the form below to publish the first quiz for this course.
                    </div>
                  </div>
                ) : (
                  quizzes.map((quiz) => (
                    <div key={quiz._id} className="border border-gray-200 rounded-md p-4 shadow-sm">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{quiz.name}</h3>
                          {quiz.groupId && (
                            <p className="text-xs text-gray-500 mt-1">
                              Group: <span className="font-semibold text-gray-800">{quiz.groupId.name}</span>
                            </p>
                          )}
                          <p className="text-xs text-gray-400 mt-2">
                            Created {quiz.createdAt ? new Date(quiz.createdAt).toLocaleString() : 'recently'}
                          </p>
                        </div>
                      </div>
                      <div className="mt-4 flex flex-wrap gap-3">
                        <Link
                          href={`/faculty/quiz/${quiz._id}/questions/add`}
                          className="text-xs font-semibold text-purple-700 hover:underline"
                        >
                          Add Questions
                        </Link>
                        <span className="text-xs text-gray-300">•</span>
                        <Link
                          href={`/faculty/quiz/${quiz._id}/questions/view`}
                          className="text-xs font-semibold text-purple-700 hover:underline"
                        >
                          View Questions
                        </Link>
                        <span className="text-xs text-gray-300">•</span>
                        <Link
                          href={`/faculty/quiz/${quiz._id}/results`}
                          className="text-xs font-semibold text-purple-700 hover:underline"
                        >
                          View Results
                        </Link>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <form onSubmit={handleCreateQuiz} className="mt-6 border border-purple-100 bg-purple-50 rounded-md p-4 space-y-4">
                <h3 className="text-sm font-semibold text-purple-700">Create Quiz</h3>
                {groups.length === 0 ? (
                  <p className="text-xs text-purple-600">
                    Create a group for the course before publishing quizzes. Students must be registered in the group to attempt the quiz.
                  </p>
                ) : (
                  <div className="grid gap-3 md:grid-cols-[2fr_1fr]">
                    <div>
                      <label htmlFor="quiz-name" className="block text-xs font-semibold uppercase text-purple-600 mb-1">Quiz Name</label>
                      <input
                        id="quiz-name"
                        name="name"
                        type="text"
                        value={quizForm.name}
                        onChange={handleQuizFormChange}
                        placeholder="e.g., Midterm Quiz"
                        className="w-full px-3 py-2 border border-purple-200 rounded-md focus:ring-purple-500 focus:border-purple-500 text-sm"
                      />
                    </div>
                    <div>
                      <label htmlFor="quiz-group" className="block text-xs font-semibold uppercase text-purple-600 mb-1">Assign to Group</label>
                      <select
                        id="quiz-group"
                        name="groupId"
                        value={quizForm.groupId}
                        onChange={handleQuizFormChange}
                        className="w-full px-3 py-2 border border-purple-200 rounded-md focus:ring-purple-500 focus:border-purple-500 text-sm bg-white"
                      >
                        {groups.map((group) => (
                          <option key={group._id} value={group._id}>
                            {group.name} {group.registrationOpen ? '(Open)' : '(Closed)'}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}
                {quizFormStatus.error && (
                  <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-md px-3 py-2">
                    {quizFormStatus.error}
                  </p>
                )}
                {quizFormStatus.success && (
                  <p className="text-xs text-green-600 bg-green-50 border border-green-200 rounded-md px-3 py-2">
                    {quizFormStatus.success}
                  </p>
                )}
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={creatingQuiz || groups.length === 0}
                    className="inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-md transition-colors disabled:bg-purple-400"
                  >
                    {creatingQuiz ? 'Creating…' : 'Create Quiz'}
                  </button>
                </div>
              </form>
            </section>
          </>
        ) : null}
      </div>
    </div>
  );
}
