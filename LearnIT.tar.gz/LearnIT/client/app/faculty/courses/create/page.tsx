'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { facultyApi } from '@/lib/api';

export default function CreateCourse() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    courseName: '',
    courseCode: '',
    courseCredit: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }
    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!formData.courseName || !formData.courseCode || !formData.courseCredit) {
      setError('All fields are required.');
      return;
    }

    try {
      const response = await facultyApi.createCourse(
        formData.courseCode,
        formData.courseName,
        Number(formData.courseCredit)
      );

      setSuccess(response.message || 'Course created successfully!');
      setFormData({ courseName: '', courseCode: '', courseCredit: '' });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create course.';
      setError(errorMessage);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Create Course</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Create a New Course</h1>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-4xl pb-12">
        <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="courseName" className="block text-sm font-medium text-gray-700 mb-1">Course Name</label>
              <input
                type="text"
                name="courseName"
                id="courseName"
                value={formData.courseName}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
                placeholder="e.g., Introduction to Computer Science"
              />
            </div>
            <div>
              <label htmlFor="courseCode" className="block text-sm font-medium text-gray-700 mb-1">Course Code</label>
              <input
                type="text"
                name="courseCode"
                id="courseCode"
                value={formData.courseCode}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
                placeholder="e.g., CS101"
              />
            </div>
            <div>
              <label htmlFor="courseCredit" className="block text-sm font-medium text-gray-700 mb-1">Course Credits</label>
              <input
                type="number"
                name="courseCredit"
                id="courseCredit"
                value={formData.courseCredit}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
                placeholder="e.g., 3"
                min="1"
              />
            </div>

            {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md">{error}</p>}
            {success && <p className="text-sm text-green-600 bg-green-50 p-3 rounded-md">{success}</p>}

            <div>
              <button
                type="submit"
                className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors"
              >
                Create Course
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
