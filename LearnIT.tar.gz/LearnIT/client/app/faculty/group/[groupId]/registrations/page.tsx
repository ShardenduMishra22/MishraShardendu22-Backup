'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { facultyApi, type ApiResponse } from '@/lib/api';

interface IRegistration {
  _id: string;
  userId: {
    _id: string;
    email: string;
  };
  groupId?: {
    _id: string;
    name: string;
  } | string;
  approved?: boolean;
  status?: 'pending' | 'approved' | 'rejected';
  midSemMarks?: number | null;
  endSemMarks?: number | null;
  midSemMaxMarks?: number | null;
  endSemMaxMarks?: number | null;
  assessmentUpdatedAt?: string | null;
  assessmentUpdatedBy?: {
    _id?: string;
    email?: string;
  } | null;
  createdAt: string;
  updatedAt?: string;
  totalEvaluatedScore?: number | null;
  totalEvaluatedMaxScore?: number | null;
  finalPercentage?: number | null;
  finalGrade?: string | null;
  relativeRank?: number | null;
  hasCompleteAssessment?: boolean;
  quizSummary?: {
    totalCorrect: number;
    totalQuestions: number;
    perQuiz: Array<{
      quizId: string;
      name: string;
      correctAnswers: number;
      totalQuestions: number;
    }>;
  } | null;
}

export default function GroupRegistrations() {
  const router = useRouter();
  const params = useParams();
  const groupParam = Array.isArray(params.groupId) ? params.groupId[0] : params.groupId;
  const groupId = groupParam ?? '';
  const { user, isAuthenticated, initializeAuth } = useUserStore();
  
  const [loading, setLoading] = useState(true);
  const [registrations, setRegistrations] = useState<IRegistration[]>([]);
  const [error, setError] = useState('');
  const [gradeDrafts, setGradeDrafts] = useState<Record<string, { midSem: string; endSem: string }>>({});
  const [gradeSaving, setGradeSaving] = useState<Record<string, boolean>>({});
  const [gradeMessages, setGradeMessages] = useState<Record<string, { error?: string; success?: string }>>({});

  useEffect(() => {
    initializeAuth();
    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }
    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    const fetchRegistrations = async () => {
      if (!groupId) {
        setLoading(false);
        return;
      }

      try {
        const response = await facultyApi.getGroupRegistrations(groupId);
        const registrationData = (response.data as IRegistration[]) || [];
        setRegistrations(registrationData);
        setGradeDrafts(
          registrationData.reduce<Record<string, { midSem: string; endSem: string }>>((acc, entry) => {
            acc[entry._id] = {
              midSem:
                entry.midSemMarks !== undefined && entry.midSemMarks !== null
                  ? String(entry.midSemMarks)
                  : '',
              endSem:
                entry.endSemMarks !== undefined && entry.endSemMarks !== null
                  ? String(entry.endSemMarks)
                  : '',
            };
            return acc;
          }, {})
        );
        setGradeMessages({});
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to fetch registrations.';
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    fetchRegistrations();
  }, [isAuthenticated, user, router, initializeAuth, groupId]);

  const parseMarkValue = (raw: string, label: string): number | null => {
    const trimmed = raw.trim();
    if (trimmed === '') {
      return null;
    }
    const numeric = Number(trimmed);
    if (Number.isNaN(numeric)) {
      throw new Error(`${label} must be a valid number`);
    }
    if (numeric < 0) {
      throw new Error(`${label} cannot be negative`);
    }
    return numeric;
  };

  const handleGradeInputChange = (registrationId: string, field: 'midSem' | 'endSem', value: string) => {
    setGradeDrafts((prev) => ({
      ...prev,
      [registrationId]: {
        midSem: field === 'midSem' ? value : prev[registrationId]?.midSem ?? '',
        endSem: field === 'endSem' ? value : prev[registrationId]?.endSem ?? '',
      },
    }));
  };

  const handleSaveMarks = async (registration: IRegistration) => {
    if (!groupId) {
      setGradeMessages((prev) => ({
        ...prev,
        [registration._id]: { error: 'Missing group identifier.' },
      }));
      return;
    }

    if (!registration.userId?._id) {
      setGradeMessages((prev) => ({
        ...prev,
        [registration._id]: { error: 'Student identifier is unavailable.' },
      }));
      return;
    }

    const draft = gradeDrafts[registration._id] ?? { midSem: '', endSem: '' };

    let midSemValue: number | null;
    let endSemValue: number | null;

    try {
      midSemValue = parseMarkValue(draft.midSem, 'Mid-semester marks');
      endSemValue = parseMarkValue(draft.endSem, 'End-semester marks');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Please enter valid marks.';
      setGradeMessages((prev) => ({
        ...prev,
        [registration._id]: { error: message },
      }));
      return;
    }

    try {
      setGradeSaving((prev) => ({ ...prev, [registration._id]: true }));
      setGradeMessages((prev) => ({
        ...prev,
        [registration._id]: { error: undefined, success: undefined },
      }));

      const response = await facultyApi.updateStudentMarks(groupId, registration.userId._id, {
        midSemMarks: midSemValue,
        endSemMarks: endSemValue,
      });

      const updated = ((response as ApiResponse<IRegistration>).data ?? registration) as IRegistration;

      setRegistrations((prev) =>
        prev.map((item) =>
          item._id === registration._id
            ? { ...item, ...updated, userId: updated.userId ?? item.userId }
            : item
        )
      );

      setGradeDrafts((prev) => ({
        ...prev,
        [registration._id]: {
          midSem:
            updated.midSemMarks !== undefined && updated.midSemMarks !== null
              ? String(updated.midSemMarks)
              : '',
          endSem:
            updated.endSemMarks !== undefined && updated.endSemMarks !== null
              ? String(updated.endSemMarks)
              : '',
        },
      }));

      setGradeMessages((prev) => ({
        ...prev,
        [registration._id]: { success: 'Saved' }, // Shortened message for UI
      }));
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to save marks right now.';
      setGradeMessages((prev) => ({
        ...prev,
        [registration._id]: { error: message },
      }));
    } finally {
      setGradeSaving((prev) => ({ ...prev, [registration._id]: false }));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      
      {/* Header Block - Moodle Style */}
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-7xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
            <span>/</span>
            <Link href="/faculty/group/view" className="hover:underline hover:text-purple-700">My Groups</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Assessment</span>
          </div>
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-800">Student Assessments & Grades</h1>
            <div className="text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full border border-gray-200">
               Total Students: <span className="font-bold text-gray-800">{registrations.length}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-7xl pb-12">
        {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r-md">
                <div className="flex">
                    <div className="ml-3">
                        <p className="text-sm text-red-700">{error}</p>
                    </div>
                </div>
            </div>
        )}
        
        {/* Main Table Card */}
        <div className="bg-white rounded-md border border-gray-200 shadow-sm">
          {registrations.length === 0 && !error ? (
            <div className="text-center py-16 px-6">
               <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
               </div>
              <h2 className="text-lg font-bold text-gray-800">No registrations found</h2>
              <p className="text-gray-500 mt-2">There are currently no students registered in this group.</p>
            </div>
          ) : (
            // Removed overflow-x-auto to force layout and remove scrollbar (use table-fixed if needed, but flex-col consolidation handles it)
            <div className="w-full">
              <table className="w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider w-[24%]">Student Details</th>
                    <th scope="col" className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider w-[12%]">Status</th>
                    <th scope="col" className="px-6 py-4 text-center text-xs font-bold text-gray-500 uppercase tracking-wider w-[12%]">Mid Sem</th>
                    <th scope="col" className="px-6 py-4 text-center text-xs font-bold text-gray-500 uppercase tracking-wider w-[12%]">End Sem</th>
                    <th scope="col" className="px-6 py-4 text-center text-xs font-bold text-gray-500 uppercase tracking-wider w-[14%]">Quiz</th>
                    <th scope="col" className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider w-[14%]">Performance</th>
                    <th scope="col" className="px-6 py-4 text-right text-xs font-bold text-gray-500 uppercase tracking-wider w-[12%]">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {registrations.map((reg) => {
                    const studentEmail = reg.userId?.email ?? 'Unknown';
                    const studentName = studentEmail !== 'Unknown' ? studentEmail.split('@')[0] : 'Unknown';
                    const statusKey = (reg.status ?? ((reg.approved ?? true) ? 'approved' : 'pending')) as 'pending' | 'approved' | 'rejected';
                    const statusLabel = statusKey.charAt(0).toUpperCase() + statusKey.slice(1);
                    const statusClasses =
                      statusKey === 'approved'
                        ? 'bg-green-100 text-green-700 border border-green-200'
                        : statusKey === 'rejected'
                          ? 'bg-red-100 text-red-700 border border-red-200'
                          : 'bg-yellow-100 text-yellow-700 border border-yellow-200';
                    const gradeDraft = gradeDrafts[reg._id] ?? { midSem: '', endSem: '' };
                    const midOutOf = reg.midSemMaxMarks ?? 100;
                    const endOutOf = reg.endSemMaxMarks ?? 100;
                    const lastUpdated = reg.assessmentUpdatedAt
                      ? new Date(reg.assessmentUpdatedAt).toLocaleDateString()
                      : 'Never';
                    const message = gradeMessages[reg._id];
                    const hasCompleteAssessment = reg.hasCompleteAssessment ?? false;
                    const finalPercentage = typeof reg.finalPercentage === 'number' ? `${reg.finalPercentage.toFixed(1)}%` : null;
                    const finalGrade = hasCompleteAssessment ? (reg.finalGrade ?? '-') : '-';
                    const relativeRank = hasCompleteAssessment && typeof reg.relativeRank === 'number'
                      ? `#${reg.relativeRank}`
                      : null;
                    const quizSummary = reg.quizSummary;
                    const quizEntries = quizSummary?.perQuiz ?? [];
                    const hasQuizData = quizEntries.length > 0;
                    const quizTotalCorrect = hasQuizData ? quizSummary?.totalCorrect ?? 0 : null;
                    const quizBreakdown = hasQuizData
                      ? quizEntries
                          .map((entry) => (typeof entry.correctAnswers === 'number' ? entry.correctAnswers : 0))
                          .join('/')
                      : '';
                    const quizMaxMarks = hasQuizData ? quizSummary?.totalQuestions ?? 0 : null;
                    const quizDisplay = hasQuizData && quizTotalCorrect !== null
                      ? `${quizTotalCorrect}${quizBreakdown ? `(${quizBreakdown})` : ''}`
                      : '—';

                    return (
                      <tr key={reg._id} className="hover:bg-[#fcfcfc] transition-colors group">
                        
                        {/* Student Details Column */}
                        <td className="px-6 py-4 whitespace-nowrap align-top">
                           <div className="flex items-start gap-3">
                              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center text-purple-700 font-bold shrink-0">
                                {studentName.charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <div className="text-sm font-bold text-gray-900">{studentName}</div>
                                <div className="text-xs text-gray-500 font-mono mt-0.5">{studentEmail}</div>
                              </div>
                           </div>
                        </td>

                        {/* Status Column */}
                        <td className="px-6 py-4 whitespace-nowrap align-top">
                          <span className={`px-2.5 py-0.5 inline-flex text-xs font-bold rounded-full ${statusClasses}`}>
                            {statusLabel}
                          </span>
                          <div className="text-[10px] text-gray-400 mt-2">
                             Reg: {new Date(reg.createdAt).toLocaleDateString()}
                          </div>
                        </td>

                        {/* Mid Sem Column */}
                        <td className="px-6 py-4 whitespace-nowrap align-top">
                           <div className="flex flex-col items-center">
                              <div className="relative">
                                  <input
                                    type="number"
                                    min={0}
                                    value={gradeDraft.midSem}
                                    onChange={(event) => handleGradeInputChange(reg._id, 'midSem', event.target.value)}
                                    className="w-20 text-center border border-gray-300 rounded-md px-2 py-1.5 text-sm font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all shadow-sm"
                                    placeholder="-"
                                  />
                              </div>
                              <span className="text-[10px] text-gray-400 mt-1 uppercase tracking-wider">Max {midOutOf}</span>
                           </div>
                        </td>

                        {/* End Sem Column */}
                        <td className="px-6 py-4 whitespace-nowrap align-top">
                           <div className="flex flex-col items-center">
                              <div className="relative">
                                  <input
                                    type="number"
                                    min={0}
                                    value={gradeDraft.endSem}
                                    onChange={(event) => handleGradeInputChange(reg._id, 'endSem', event.target.value)}
                                    className="w-20 text-center border border-gray-300 rounded-md px-2 py-1.5 text-sm font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all shadow-sm"
                                    placeholder="-"
                                  />
                              </div>
                              <span className="text-[10px] text-gray-400 mt-1 uppercase tracking-wider">Max {endOutOf}</span>
                           </div>
                        </td>

                            {/* Quiz Column */}
                            <td className="px-6 py-4 whitespace-nowrap align-top">
                              <div className="flex flex-col items-center text-center">
                                <span className="text-sm font-semibold text-gray-800">
                                  {quizDisplay}
                                </span>
                                <span className="text-[10px] text-gray-400 mt-1 uppercase tracking-wider">
                                  {hasQuizData && quizMaxMarks !== null ? `Max Marks ${quizMaxMarks}` : 'No quizzes'}
                                </span>
                              </div>
                            </td>

                        {/* Performance Column */}
                        <td className="px-6 py-4 whitespace-nowrap align-top">
                           <div className="flex flex-col">
                              <div className="flex items-center gap-2">
                                 <span className="text-xl font-bold text-gray-800">{finalGrade}</span>
                                 {finalPercentage && (
                                     <span className="text-xs text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded border border-gray-200">
                                       {finalPercentage}
                                     </span>
                                 )}
                              </div>
                              <div className="text-[10px] text-gray-400 mt-1">
                                 {relativeRank ? `Class Rank: ${relativeRank}` : 'Rank: Pending'}
                              </div>
                           </div>
                        </td>

                        {/* Actions Column */}
                        <td className="px-6 py-4 whitespace-nowrap text-right align-top">
                           <div className="flex flex-col items-end gap-1">
                             <button
                                type="button"
                                onClick={() => handleSaveMarks(reg)}
                                disabled={gradeSaving[reg._id] === true}
                                className="inline-flex items-center justify-center rounded-md bg-purple-700 px-4 py-1.5 text-xs font-bold text-white shadow-sm transition-all hover:bg-purple-800 hover:shadow disabled:cursor-not-allowed disabled:bg-purple-300 disabled:shadow-none min-w-[70px]"
                              >
                                {gradeSaving[reg._id] ? (
                                    <div className="w-3 h-3 border-2 border-white/50 border-t-white rounded-full animate-spin"></div>
                                ) : 'Save'}
                              </button>
                              
                              <div className="h-5 flex items-center justify-end">
                                {message?.error && (
                                    <span className="text-[10px] text-red-600 font-medium bg-red-50 px-1 rounded animate-pulse">{message.error}</span>
                                )}
                                {message?.success && (
                                    <span className="text-[10px] text-green-600 font-medium flex items-center gap-1">
                                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                                        {message.success}
                                    </span>
                                )}
                                {!message && lastUpdated !== 'Never' && (
                                    <span className="text-[10px] text-gray-300">Updated: {lastUpdated}</span>
                                )}
                              </div>
                           </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}