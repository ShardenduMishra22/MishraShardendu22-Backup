'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { facultyApi } from '@/lib/api';

interface IGroup {
  name: string;
  registrationOpen: boolean;
}

export default function EditGroup() {
  const router = useRouter();
  const params = useParams();
  const groupParam = Array.isArray(params.groupId) ? params.groupId[0] : params.groupId;
  const groupId = groupParam ?? '';
  const { user, isAuthenticated, initializeAuth } = useUserStore();
  
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({ name: '', registrationOpen: false });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    initializeAuth();
  }, [initializeAuth]);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }
    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [isAuthenticated, user, router]);

  useEffect(() => {
    if (!groupId) {
      return;
    }

    const fetchGroupDetails = async () => {
      try {
        const response = await facultyApi.getMyGroups();
        const groups = (response.data as Array<IGroup & { _id: string }>) || [];
        const group = groups.find((g) => g._id === groupId);

        if (group) {
          setFormData({ name: group.name, registrationOpen: group.registrationOpen });
        } else {
          setError('Unable to find the requested group.');
        }
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to load group details.';
        setError(errorMessage);
      }
    };

    fetchGroupDetails();
  }, [groupId]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      const response = await facultyApi.updateGroup(groupId, formData.name, formData.registrationOpen);
      setSuccess(response.message || 'Group updated successfully!');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update group.';
      setError(errorMessage);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
            <span>/</span>
            <Link href="/faculty/group/view" className="hover:underline hover:text-purple-700">My Groups</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Edit Group</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Edit Group</h1>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-4xl pb-12">
        <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Group Name</label>
              <input
                type="text"
                name="name"
                id="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
            
            <div className="flex items-center">
              <input
                id="registrationOpen"
                name="registrationOpen"
                type="checkbox"
                checked={formData.registrationOpen}
                onChange={handleChange}
                className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
              />
              <label htmlFor="registrationOpen" className="ml-2 block text-sm text-gray-900">
                Registration Open
              </label>
            </div>

            {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md">{error}</p>}
            {success && <p className="text-sm text-green-600 bg-green-50 p-3 rounded-md">{success}</p>}

            <div>
              <button
                type="submit"
                className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors"
              >
                Update Group
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
