'use client';

import { Suspense, useEffect, useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { facultyApi } from '@/lib/api';

function CreateGroupContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, isAuthenticated, initializeAuth } = useUserStore();
  const presetCourseId = useMemo(() => searchParams.get('courseId') ?? '', [searchParams]);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    courseId: presetCourseId,
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    initializeAuth();
  }, [initializeAuth]);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }
    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [isAuthenticated, user, router]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!formData.name || !formData.courseId) {
      setError('All fields are required.');
      return;
    }

    try {
      const response = await facultyApi.createGroup(formData.name, formData.courseId, true);
      setSuccess(response.message || 'Group created successfully!');
      setFormData({ name: '', courseId: '' });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create group. Make sure the Course ID is correct.';
      setError(errorMessage);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Create Group</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Create a New Group</h1>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-4xl pb-12">
        <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Group Name</label>
              <input
                type="text"
                name="name"
                id="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
                placeholder="e.g., Section A"
              />
            </div>
            <div>
              <label htmlFor="courseId" className="block text-sm font-medium text-gray-700 mb-1">Course ID</label>
              <input
                type="text"
                name="courseId"
                id="courseId"
                value={formData.courseId}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
                placeholder="Enter the ID of the course this group belongs to"
              />
               <p className="text-xs text-gray-500 mt-1">You can find the Course ID on the course page.</p>
            </div>

            {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md">{error}</p>}
            {success && <p className="text-sm text-green-600 bg-green-50 p-3 rounded-md">{success}</p>}

            <div>
              <button
                type="submit"
                className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors"
              >
                Create Group
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default function CreateGroup() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          </div>
        </div>
      }
    >
      <CreateGroupContent />
    </Suspense>
  );
}
