'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';
import { facultyApi } from '@/lib/api';

interface IGroup {
  _id: string;
  name: string;
  courseId: {
    _id: string;
    courseName: string;
    courseCode: string;
  };
  registrationOpen: boolean;
  createdAt: string;
}

export default function MyGroups() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth } = useUserStore();
  const [loading, setLoading] = useState(true);
  const [groups, setGroups] = useState<IGroup[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    initializeAuth();
    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }
    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }
    
    const fetchGroups = async () => {
      try {
        const response = await facultyApi.getMyGroups();
        setGroups((response.data as IGroup[]) || []);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to fetch groups.';
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    fetchGroups();
  }, [isAuthenticated, user, router, initializeAuth]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
                <span>/</span>
                <span className="text-gray-800 font-semibold">My Groups</span>
              </div>
              <h1 className="text-3xl font-light text-gray-800">My Groups</h1>
            </div>
            <Link href="/faculty/group/create">
              <button className="bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors">
                Create New Group
              </button>
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12">
        {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md mb-6">{error}</p>}
        
        {groups.length === 0 && !error ? (
          <div className="text-center py-12 px-6 bg-white rounded-md border border-gray-200 shadow-sm">
            <h2 className="text-xl font-semibold text-gray-700">No groups found.</h2>
            <p className="text-gray-500 mt-2">Get started by creating a new group for one of your courses.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groups.map((group) => (
              <div key={group._id} className="bg-white rounded-md border border-gray-200 shadow-sm overflow-hidden hover:shadow-lg transition-shadow">
                <div className="p-6">
                  <div className="flex justify-between items-start">
                    <h2 className="text-xl font-bold text-gray-900 truncate pr-4">{group.name}</h2>
                    <span className={`text-xs font-semibold px-2 py-1 rounded-full ${group.registrationOpen ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {group.registrationOpen ? 'Open' : 'Closed'}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{group.courseId.courseName} ({group.courseId.courseCode})</p>
                  <p className="text-xs text-gray-400 mt-4">Created: {new Date(group.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="bg-gray-50 border-t border-gray-100 px-6 py-3 flex justify-end gap-2">
                   <Link href={`/faculty/group/${group._id}/registrations`}>
                    <button className="text-xs text-purple-700 hover:underline font-medium">View Registrations</button>
                  </Link>
                  <Link href={`/faculty/group/${group._id}/edit`}>
                    <button className="text-xs text-purple-700 hover:underline font-medium">Edit</button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
