'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/lib/store';
import { facultyApi, type ApiResponse } from '@/lib/api';

type FacultyCourse = {
  _id: string;
  courseCode: string;
  courseCredit: number;
  courseName: string;
  createdAt?: string;
  updatedAt?: string;
};

type FacultyStats = {
  totalCourses: number;
  totalGroups: number;
  totalQuizzes: number;
  totalStudents: number;
  totalAssignments: number;
};

export default function FacultyDashboard() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, logout, hydrationComplete } = useUserStore();
  const [loading, setLoading] = useState(true);
  const [coursesLoading, setCoursesLoading] = useState(true);
  const [coursesError, setCoursesError] = useState('');
  const [courses, setCourses] = useState<FacultyCourse[]>([]);
  const [statsLoading, setStatsLoading] = useState(true);
  const [statsError, setStatsError] = useState('');
  const [stats, setStats] = useState<FacultyStats | null>(null);

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }

    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  useEffect(() => {
    if (!hydrationComplete || !isAuthenticated || user?.role !== 'faculty') {
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setCoursesError('');
      setCoursesLoading(true);
    });

    Promise.allSettled([
      facultyApi.getMyCourses(),
      facultyApi.getDashboardStats()
    ])
      .then((results) => {
        if (!isMounted) {
          return;
        }

        const [coursesResult, statsResult] = results;

        if (coursesResult.status === 'fulfilled') {
          const typedResponse = coursesResult.value as ApiResponse<FacultyCourse[]>;
          setCourses(Array.isArray(typedResponse.data) ? typedResponse.data : []);
          setCoursesError('');
        } else {
          const message = coursesResult.reason instanceof Error ? coursesResult.reason.message : 'Unable to load courses';
          setCoursesError(message);
          setCourses([]);
        }

        if (statsResult.status === 'fulfilled') {
          const typedStats = statsResult.value as ApiResponse<FacultyStats>;
          setStats(typedStats.data ?? null);
          setStatsError('');
        } else {
          const message = statsResult.reason instanceof Error ? statsResult.reason.message : 'Unable to load stats';
          setStatsError(message);
          setStats(null);
        }
      })
      .finally(() => {
        if (isMounted) {
          setCoursesLoading(false);
          setStatsLoading(false);
        }
      });

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [hydrationComplete, isAuthenticated, user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-medium">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const handleLogout = () => {
    logout();
    router.push('/');
  };

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      
      {/* Dashboard Control Bar - Moodle 4.0 Style */}
      <div className="bg-white border-b border-gray-300 px-6 py-4">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
             <h1 className="text-2xl font-bold text-gray-800">Faculty Dashboard</h1>
             <p className="text-sm text-gray-500">Welcome back, {user?.email}</p>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Visual "Edit Mode" Toggle - Iconic Moodle feature */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-gray-600">Edit mode</span>
              <div className="w-12 h-6 bg-gray-200 rounded-full relative cursor-pointer">
                <div className="w-6 h-6 bg-white border border-gray-300 rounded-full shadow-sm absolute left-0"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT COLUMN (Main Content - 2/3 width) */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* KPI Stats Row - Styled as "Overview Block" */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
               {/* Stat Card 1 */}
               <div className="bg-white p-4 rounded-md border border-gray-200 shadow-sm flex flex-col items-center justify-center text-center hover:border-purple-500 transition-colors">
                 <span className="text-3xl font-light text-purple-700 mb-1">{statsLoading ? '—' : (stats?.totalCourses ?? courses.length).toLocaleString()}</span>
                 <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Courses Taught</span>
               </div>
               
               {/* Stat Card 2 */}
               <div className="bg-white p-4 rounded-md border border-gray-200 shadow-sm flex flex-col items-center justify-center text-center hover:border-purple-500 transition-colors">
                 <span className="text-3xl font-light text-purple-700 mb-1">{statsLoading ? '—' : (stats?.totalStudents ?? 0).toLocaleString()}</span>
                 <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Students</span>
               </div>

               {/* Stat Card 3 */}
               <div className="bg-white p-4 rounded-md border border-gray-200 shadow-sm flex flex-col items-center justify-center text-center hover:border-purple-500 transition-colors">
                 <span className="text-3xl font-light text-purple-700 mb-1">{statsLoading ? '—' : (stats?.totalGroups ?? 0).toLocaleString()}</span>
                 <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Groups</span>
               </div>

               {/* Stat Card 4 */}
               <div className="bg-white p-4 rounded-md border border-gray-200 shadow-sm flex flex-col items-center justify-center text-center hover:border-purple-500 transition-colors">
                 <span className="text-3xl font-light text-purple-700 mb-1">{statsLoading ? '—' : (stats?.totalQuizzes ?? 0).toLocaleString()}</span>
                 <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Quizzes</span>
               </div>
            </div>
            {statsError && !statsLoading ? (
              <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-md px-3 py-2 mt-2">{statsError}</p>
            ) : null}

            {/* Course Overview / Quick Actions Grid */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
                <h2 className="text-lg font-bold text-gray-800">My Courses</h2>
                
                {/* Moodle Style Filter Dropdown (Visual) */}
                <div className="relative hidden sm:block">
                    <button className="flex items-center gap-2 text-sm font-medium text-gray-600 bg-white border border-gray-300 px-3 py-1 rounded">
                      <span>All</span>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                    </button>
                </div>
              </div>
              
              <div className="p-6">
                {coursesLoading ? (
                  <div className="text-center text-gray-500 py-12">
                    <div className="w-10 h-10 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-sm font-medium">Loading your courses...</p>
                  </div>
                ) : coursesError ? (
                  <div className="text-center text-red-600 bg-red-50 border border-red-200 rounded-md py-8 px-4">
                    <h3 className="text-lg font-semibold">Unable to load courses</h3>
                    <p className="mt-2 text-sm">{coursesError}</p>
                    <button
                      onClick={() => {
                        const frame = window.requestAnimationFrame(() => {
                          setCoursesLoading(true);
                          setCoursesError('');
                        });
                        facultyApi
                          .getMyCourses()
                          .then((response) => {
                            const typedResponse = response as ApiResponse<FacultyCourse[]>;
                            setCourses(Array.isArray(typedResponse.data) ? typedResponse.data : []);
                          })
                          .catch((error: unknown) => {
                            const message = error instanceof Error ? error.message : 'Unable to load courses';
                            setCoursesError(message);
                          })
                          .finally(() => {
                            window.cancelAnimationFrame(frame);
                            setCoursesLoading(false);
                          });
                      }}
                      className="mt-4 inline-flex items-center justify-center bg-purple-600 text-white font-semibold px-4 py-2 rounded-md hover:bg-purple-700 transition-colors"
                    >
                      Try Again
                    </button>
                  </div>
                ) : courses.length > 0 ? (
                  <div className="grid gap-6 md:grid-cols-2">
                    {courses.map((course) => (
                      // Moodle 4.0 Style Course Card
                      <div
                        key={course._id}
                        className="flex flex-col h-full bg-white border border-gray-200 rounded-md overflow-hidden hover:shadow-lg transition-shadow duration-200 group"
                      >
                        {/* Fake Course Image Header (Pattern) */}
                        <div className="h-28 bg-purple-50 border-b border-gray-100 flex items-center justify-center group-hover:bg-purple-100 transition-colors">
                           <svg className="w-12 h-12 text-purple-200" fill="currentColor" viewBox="0 0 20 20">
                             <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" />
                           </svg>
                        </div>

                        <div className="p-5 flex flex-col flex-grow">
                          <div className="mb-2">
                             <span className="text-xs font-bold text-gray-500 uppercase tracking-wider bg-gray-100 px-2 py-0.5 rounded border border-gray-200">
                              {course.courseCode}
                             </span>
                          </div>
                          
                          <Link href={`/faculty/courses/${course._id}`} className="block group-hover:underline decoration-2 decoration-purple-600 underline-offset-2">
                            <h3 className="text-lg font-bold text-gray-800 leading-tight mb-2 line-clamp-2 h-14">
                              {course.courseName}
                            </h3>
                          </Link>

                           <div className="mt-auto pt-4 border-t border-gray-100">
                             <div className="flex justify-between items-center text-xs text-gray-500 mb-3">
                                <span>Credit: {course.courseCredit}</span>
                                {course.updatedAt && (
                                  <span>Upd: {new Date(course.updatedAt).toLocaleDateString()}</span>
                                )}
                             </div>
                             
                             <div className="flex gap-2">
                                <Link
                                  href={`/faculty/courses/${course._id}`}
                                  className="flex-1 text-center text-sm font-bold text-white bg-purple-700 hover:bg-purple-800 py-2 rounded transition-colors"
                                >
                                  Manage
                                </Link>
                                <Link
                                  href={`/faculty/group/create?courseId=${course._id}`}
                                  className="px-3 py-2 text-sm font-bold text-gray-600 border border-gray-300 rounded hover:bg-gray-100 transition-colors"
                                  title="Create Group"
                                >
                                  + Group
                                </Link>
                             </div>
                           </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-gray-500 py-12">
                    <svg className="w-16 h-16 mx-auto text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                    <h3 className="mt-4 text-lg font-medium">No courses to display</h3>
                    <p className="mt-1 text-sm">You are not currently teaching any courses.</p>
                    <Link href="/faculty/courses/create" className="mt-6 inline-block bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors">
                      Create a New Course
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN (Blocks - 1/3 width) */}
          <div className="lg:col-span-1 space-y-8">
            
            {/* Timeline Block */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <h2 className="text-lg font-bold text-gray-800">Timeline</h2>
              </div>
              <div className="p-6">
                <div className="text-center text-gray-500 py-8">
                  <svg className="w-12 h-12 mx-auto text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                  <h3 className="mt-4 text-md font-medium">No upcoming deadlines</h3>
                  <p className="mt-1 text-sm">You have no assignments or quizzes due soon.</p>
                </div>
              </div>
            </div>

            {/* Private Files Block */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <h2 className="text-lg font-bold text-gray-800">Private Files</h2>
              </div>
              <div className="p-6">
                <div className="text-center text-gray-500 py-8">
                  <svg className="w-12 h-12 mx-auto text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg>
                  <h3 className="mt-4 text-md font-medium">Your private file storage is empty.</h3>
                   <button className="mt-4 text-sm text-purple-600 font-medium hover:underline">Manage private files...</button>
                </div>
              </div>
            </div>

            {/* Navigation Block */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <h2 className="text-lg font-bold text-gray-800">Navigation</h2>
              </div>
              <div className="p-6">
                <nav className="space-y-2">
                  <Link href="/faculty/dashboard" className="flex items-center gap-3 px-3 py-2 text-purple-700 bg-purple-50 rounded-md font-bold">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                    <span>Home</span>
                  </Link>
                  <Link href="/faculty/profile" className="flex items-center gap-3 px-3 py-2 text-gray-600 hover:bg-gray-100 rounded-md font-medium">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                    <span>Profile</span>
                  </Link>
                  <Link href="/faculty/settings" className="flex items-center gap-3 px-3 py-2 text-gray-600 hover:bg-gray-100 rounded-md font-medium">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                    <span>Settings</span>
                  </Link>
                  <button onClick={handleLogout} className="flex items-center gap-3 px-3 py-2 text-gray-600 hover:bg-gray-100 rounded-md font-medium w-full text-left">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                    <span>Logout</span>
                  </button>
                </nav>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}