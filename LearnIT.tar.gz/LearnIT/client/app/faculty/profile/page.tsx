'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';

export default function FacultyProfile() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/faculty');
      return;
    }

    if (user?.role !== 'faculty') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 text-sm font-medium">Loading user data...</p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      
      {/* Moodle-style Breadcrumb / Header Area */}
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-5xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
             <Link href="/faculty/dashboard" className="hover:underline hover:text-purple-700">Dashboard</Link>
             <span>/</span>
             <span className="text-gray-800 font-semibold">Profile</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">
            {user.email.split('@')[0]}
          </h1>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-5xl pb-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Left Column: User Card (Moodle "User details" block style) */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6 text-center">
              <div className="w-32 h-32 bg-gray-100 rounded-md border border-gray-200 mx-auto flex items-center justify-center mb-4">
                <svg className="w-16 h-16 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                </svg>
              </div>
              <h2 className="text-xl font-bold text-gray-800 break-all">{user.email}</h2>
              <span className="inline-block mt-2 px-3 py-1 bg-gray-100 text-gray-600 text-xs font-bold uppercase tracking-wider rounded border border-gray-200">
                {user.role}
              </span>
              
              <div className="mt-6 space-y-2">
                 <Link 
                   href="/faculty/settings"
                   className="block w-full py-2 px-4 bg-purple-700 text-white text-sm font-bold rounded hover:bg-purple-800 transition-colors"
                 >
                   Edit Profile
                 </Link>
                 <Link 
                   href="/faculty/dashboard"
                   className="block w-full py-2 px-4 bg-white border border-gray-300 text-gray-700 text-sm font-bold rounded hover:bg-gray-50 transition-colors"
                 >
                   Dashboard
                 </Link>
              </div>
            </div>
          </div>

          {/* Right Column: Details & Content */}
          <div className="md:col-span-2 space-y-6">
            
            {/* User Details Block */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50">
                <h3 className="text-lg font-bold text-gray-800">User Details</h3>
              </div>
              <div className="p-6">
                <dl className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                    <dt className="text-sm font-semibold text-gray-500">Email Address</dt>
                    <dd className="sm:col-span-2 text-sm text-gray-900">{user.email}</dd>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                    <dt className="text-sm font-semibold text-gray-500">System ID</dt>
                    <dd className="sm:col-span-2 text-sm font-mono text-gray-600 bg-gray-50 inline-block px-2 py-1 rounded w-fit">{user._id}</dd>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                    <dt className="text-sm font-semibold text-gray-500">Account Status</dt>
                    <dd className="sm:col-span-2 text-sm text-gray-900">
                      <span className="inline-flex items-center gap-1.5 text-purple-700 font-medium">
                        <span className="w-2 h-2 bg-purple-600 rounded-full"></span>
                        Active
                      </span>
                    </dd>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <dt className="text-sm font-semibold text-gray-500">Institution</dt>
                    <dd className="sm:col-span-2 text-sm text-gray-900">LearnIT University</dd>
                  </div>
                </dl>
              </div>
            </div>

            {/* Reports / Activity Block (Placeholder for future expansion) */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50">
                <h3 className="text-lg font-bold text-gray-800">Login Activity</h3>
              </div>
              <div className="p-6">
                <p className="text-sm text-gray-500 italic">
                  First access to site: <span className="text-gray-800 not-italic">Wednesday, 22 November 2023, 10:00 AM</span>
                </p>
                <p className="text-sm text-gray-500 italic mt-2">
                  Last access to site: <span className="text-gray-800 not-italic">Now</span>
                </p>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
