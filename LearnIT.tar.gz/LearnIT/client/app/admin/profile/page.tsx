'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import Link from 'next/link';

export default function AdminProfile() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/admin');
      return;
    }

    if (user?.role !== 'admin') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 text-sm font-medium">Loading user data...</p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      
      {/* Moodle-style Breadcrumb / Header Area */}
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-5xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
             <Link href="/admin/dashboard" className="hover:underline hover:text-blue-700">Dashboard</Link>
             <span>/</span>
             <span className="text-gray-800 font-semibold">Profile</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">
            {user.email.split('@')[0]}
          </h1>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-5xl pb-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Left Column: User Card */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6 text-center">
              <div className="w-32 h-32 bg-gray-100 rounded-md border border-gray-200 mx-auto flex items-center justify-center mb-4">
                <svg className="w-16 h-16 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h2 className="text-xl font-bold text-gray-800 break-all">{user.email}</h2>
              <span className="inline-block mt-2 px-3 py-1 bg-gray-100 text-gray-600 text-xs font-bold uppercase tracking-wider rounded border border-gray-200">
                {user.role}
              </span>
              
              <div className="mt-6 space-y-2">
                 <Link 
                   href="/admin/settings"
                   className="block w-full py-2 px-4 bg-blue-700 text-white text-sm font-bold rounded hover:bg-blue-800 transition-colors"
                 >
                   Edit Profile
                 </Link>
                 <Link 
                   href="/admin/dashboard"
                   className="block w-full py-2 px-4 bg-white border border-gray-300 text-gray-700 text-sm font-bold rounded hover:bg-gray-50 transition-colors"
                 >
                   Dashboard
                 </Link>
              </div>
            </div>
          </div>

          {/* Right Column: Details & Content */}
          <div className="md:col-span-2 space-y-6">
            
            {/* User Details Block */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50">
                <h3 className="text-lg font-bold text-gray-800">Administrator Details</h3>
              </div>
              <div className="p-6">
                <dl className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                    <dt className="text-sm font-semibold text-gray-500">Email Address</dt>
                    <dd className="sm:col-span-2 text-sm text-gray-900">{user.email}</dd>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                    <dt className="text-sm font-semibold text-gray-500">System ID</dt>
                    <dd className="sm:col-span-2 text-sm font-mono text-gray-600 bg-gray-50 inline-block px-2 py-1 rounded w-fit">{user._id}</dd>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                    <dt className="text-sm font-semibold text-gray-500">Account Status</dt>
                    <dd className="sm:col-span-2 text-sm text-gray-900">
                      <span className="inline-flex items-center gap-1.5 text-blue-700 font-medium">
                        <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                        Active
                      </span>
                    </dd>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <dt className="text-sm font-semibold text-gray-500">Privileges</dt>
                    <dd className="sm:col-span-2 text-sm text-gray-900">Full System Access</dd>
                  </div>
                </dl>
              </div>
            </div>

            {/* Security Notice Block */}
            <div className="bg-amber-50 border-l-4 border-amber-400 p-4">
                <div className="flex">
                    <div className="shrink-0">
                        <svg className="h-5 w-5 text-amber-500" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                        </svg>
                    </div>
                    <div className="ml-3">
                        <p className="text-sm text-amber-800">
                            You have full administrative access. Be careful with system-wide changes.
                        </p>
                    </div>
                </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
