"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useUserStore } from "@/lib/store";
import Link from "next/link";
import { adminApi, type ApiResponse } from "@/lib/api";
import Chart from "chart.js/auto";
import type { Chart as ChartJS } from "chart.js";

interface AnalyticsResponse {
  totalUsers: number;
  students: number;
  faculty: number;
  admins: number;
  courses: number;
  groups: number;
  quizzes: number;
  courseRegistrations: number;
  groupRegistrations: number;
}

export default function AdminDashboard() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();


  const [loading, setLoading] = useState(true);
  const [analyticsLoading, setAnalyticsLoading] = useState(true);
  const [analyticsError, setAnalyticsError] = useState("");
  const [analytics, setAnalytics] = useState<AnalyticsResponse | null>(null);
  const contentChartRef = useRef<HTMLCanvasElement | null>(null);
  const registrationChartRef = useRef<HTMLCanvasElement | null>(null);
  const userChartRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstances = useRef<{ content: ChartJS | null; registrations: ChartJS | null; users: ChartJS | null }>({
    content: null,
    registrations: null,
    users: null,
  });

  const resolveParsedValue = (parsed: unknown) => {
    if (typeof parsed === "number") {
      return parsed;
    }
    if (parsed && typeof parsed === "object") {
      const { x, y } = parsed as { x?: number; y?: number };
      if (typeof y === "number") {
        return y;
      }
      if (typeof x === "number") {
        return x;
      }
    }
    return 0;
  };

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push("/login/admin");
      return;
    }

    if (user?.role !== "admin") {
      router.push("/");
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  useEffect(() => {
    if (!hydrationComplete || !isAuthenticated || user?.role !== "admin") {
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setAnalyticsError("");
      setAnalyticsLoading(true);
    });

    adminApi
      .getAnalytics()
      .then((response) => {
        if (!isMounted) {
          return;
        }
        const analyticsData = (response as ApiResponse<AnalyticsResponse>).data;
        setAnalytics(analyticsData ?? null);
      })
      .catch((error: unknown) => {
        if (!isMounted) {
          return;
        }
        const message = error instanceof Error ? error.message : "Unable to load analytics";
        setAnalyticsError(message);
      })
      .finally(() => {
        if (isMounted) {
          setAnalyticsLoading(false);
        }
      });

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [hydrationComplete, isAuthenticated, user]);

  useEffect(() => {
    if (!analytics || analyticsLoading) {
      if (!analytics) {
        Object.values(chartInstances.current).forEach((chart) => chart?.destroy());
        chartInstances.current = { content: null, registrations: null, users: null };
      }
      return;
    }

    const { courses, groups, quizzes, courseRegistrations, groupRegistrations, students, faculty, admins, totalUsers } = analytics;

    if (contentChartRef.current) {
      chartInstances.current.content?.destroy();
      chartInstances.current.content = new Chart(contentChartRef.current, {
        type: "bar",
        data: {
          labels: ["Courses", "Groups", "Quizzes"],
          datasets: [
            {
              label: "Total",
              data: [courses, groups, quizzes],
              backgroundColor: ["#2563eb", "#16a34a", "#9333ea"],
              borderRadius: 6,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                label: (context) => `${context.dataset.label ?? "Total"}: ${resolveParsedValue(context.parsed)}`,
              },
            },
          },
          scales: {
            x: {
              grid: { display: false },
              ticks: { font: { weight: "bold" } },
            },
            y: {
              beginAtZero: true,
              ticks: {
                precision: 0,
              },
            },
          },
        },
      });
    }

    if (registrationChartRef.current) {
      chartInstances.current.registrations?.destroy();
      chartInstances.current.registrations = new Chart(registrationChartRef.current, {
        type: "bar",
        data: {
          labels: ["Course Registrations", "Group Registrations"],
          datasets: [
            {
              label: "Registrations",
              data: [courseRegistrations, groupRegistrations],
              backgroundColor: ["#0ea5e9", "#10b981"],
              borderRadius: 6,
            },
          ],
        },
        options: {
          indexAxis: "y",
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                label: (context) => `${resolveParsedValue(context.parsed)} registrations`,
              },
            },
          },
          scales: {
            x: {
              beginAtZero: true,
              ticks: { precision: 0 },
            },
            y: {
              grid: { display: false },
              ticks: { font: { weight: "bold" } },
            },
          },
        },
      });
    }

    if (userChartRef.current) {
      chartInstances.current.users?.destroy();
      chartInstances.current.users = new Chart(userChartRef.current, {
        type: "doughnut",
        data: {
          labels: ["Students", "Faculty", "Admins"],
          datasets: [
            {
              data: [students, faculty, admins],
              backgroundColor: ["#2563eb", "#8b5cf6", "#f97316"],
              borderWidth: 0,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: "bottom",
              labels: { usePointStyle: true },
            },
            tooltip: {
              callbacks: {
                label: (context) => {
                  const value = context.parsed;
                  if (typeof value !== "number" || totalUsers === 0) {
                    return `${context.label}: ${value ?? 0}`;
                  }
                  const percent = ((value / totalUsers) * 100).toFixed(1);
                  return `${context.label}: ${value} (${percent}%)`;
                },
              },
            },
          },
        },
      });
    }
  }, [analytics, analyticsLoading]);

  useEffect(() => {
    return () => {
      Object.values(chartInstances.current).forEach((chart) => chart?.destroy());
      chartInstances.current = { content: null, registrations: null, users: null };
    };
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-medium">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      {/* Header Bar */}
      <div className="bg-white border-b border-gray-300 px-6 py-4">
        <div className="container mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Admin Dashboard</h1>
            <p className="text-sm text-gray-500">Welcome, {user.email}</p>
            {analyticsError && (
              <p className="mt-2 text-xs text-red-600 bg-red-50 inline-block px-2 py-1 rounded">{analyticsError}</p>
            )}
          </div>
          <div className="flex items-center gap-4">
            <Link
              href="/admin/settings"
              className="text-sm font-medium text-gray-600 hover:text-blue-700 hover:bg-gray-100 px-3 py-2 rounded transition-colors"
            >
              Settings
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* Stats Grid - Key Metrics at Top */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Total Users */}
          <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-xs font-bold uppercase tracking-wider">
                  Total Users
                </p>
                <p className="text-3xl font-light text-gray-900 mt-1">
                  {analyticsLoading ? "—" : analytics?.totalUsers ?? 0}
                </p>
              </div>
              <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              </div>
            </div>
          </div>

          {/* Total Courses */}
          <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-xs font-bold uppercase tracking-wider">
                  Total Courses
                </p>
                <p className="text-3xl font-light text-gray-900 mt-1">
                  {analyticsLoading ? "—" : analytics?.courses ?? 0}
                </p>
              </div>
              <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
            </div>
          </div>

          {/* Total Groups */}
          <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-xs font-bold uppercase tracking-wider">
                  Total Groups
                </p>
                <p className="text-3xl font-light text-gray-900 mt-1">
                  {analyticsLoading ? "—" : analytics?.groups ?? 0}
                </p>
              </div>
              <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
            </div>
          </div>

          {/* System Status */}
          <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-xs font-bold uppercase tracking-wider">
                  System Status
                </p>
                <p className="text-xl font-medium text-green-700 mt-2 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse"></span>
                  Operational
                </p>
              </div>
              <div className="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center text-green-600">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Content Area (Left 2/3) */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Management Quick Actions */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <h2 className="text-lg font-bold text-gray-800">
                  Site Administration
                </h2>
              </div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <Link href="/admin/users" className="group p-4 border border-gray-200 rounded-md hover:border-blue-500 hover:shadow-md transition-all bg-white flex items-start gap-3">
                  <div className="mt-1">
                    <h3 className="font-bold text-gray-800 group-hover:text-blue-700">Manage Users</h3>
                    <p className="text-xs text-gray-500 mt-1">View, create, and edit all users</p>
                  </div>
                </Link>
                <Link href="/admin/courses" className="group p-4 border border-gray-200 rounded-md hover:border-blue-500 hover:shadow-md transition-all bg-white flex items-start gap-3">
                  <div className="mt-1">
                    <h3 className="font-bold text-gray-800 group-hover:text-blue-700">Manage Courses</h3>
                    <p className="text-xs text-gray-500 mt-1">Oversee all courses and content</p>
                  </div>
                </Link>
                <button className="group p-4 border border-gray-200 rounded-md hover:border-blue-500 hover:shadow-md transition-all bg-white flex items-start gap-3 text-left">
                  <div className="mt-1">
                    <h3 className="font-bold text-gray-800 group-hover:text-blue-700">System Settings</h3>
                    <p className="text-xs text-gray-500 mt-1">Configure platform-wide settings</p>
                  </div>
                </button>
                <button className="group p-4 border border-gray-200 rounded-md hover:border-blue-500 hover:shadow-md transition-all bg-white flex items-start gap-3 text-left">
                  <div className="mt-1">
                    <h3 className="font-bold text-gray-800 group-hover:text-blue-700">View Logs</h3>
                    <p className="text-xs text-gray-500 mt-1">Check system and error logs</p>
                  </div>
                </button>
              </div>
            </div>

            {/* Visual Insights Section */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
                <h2 className="text-lg font-bold text-gray-800">Platform Analytics</h2>
                {!analyticsLoading && analytics && (
                  <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide bg-white border border-gray-200 px-2 py-0.5 rounded">
                    Live Data
                  </span>
                )}
              </div>
              <div className="p-6">
                {analyticsLoading ? (
                  <div className="flex flex-col items-center justify-center gap-3 text-gray-500 text-sm py-12">
                    <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    <span>Loading data visualization…</span>
                  </div>
                ) : !analytics ? (
                  <div className="text-center py-12 text-gray-500">
                     <p>Analytics data is unavailable.</p>
                  </div>
                ) : (
                  <div className="grid gap-8 md:grid-cols-2">
                    
                    {/* Content Chart */}
                    <div className="border border-gray-100 rounded-lg p-4 bg-gray-50/50">
                      <div className="mb-4">
                        <h3 className="text-sm font-bold text-gray-700">Content Distribution</h3>
                        <p className="text-xs text-gray-500">Courses vs Groups vs Quizzes</p>
                      </div>
                      <div className="relative h-60 w-full">
                        <canvas ref={contentChartRef} />
                      </div>
                    </div>
                   
                    {/* User Roles Chart */}
                    <div className="border border-gray-100 rounded-lg p-4 bg-gray-50/50">
                      <div className="mb-4">
                        <h3 className="text-sm font-bold text-gray-700">User Demographics</h3>
                        <p className="text-xs text-gray-500">Breakdown by role type</p>
                      </div>
                      <div className="relative h-60 w-full flex justify-center">
                        <canvas ref={userChartRef} />
                      </div>
                    </div>

                  </div>
                )}
              </div>
            </div>

            {/* Registration Progress Bars */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                 <h2 className="text-lg font-bold text-gray-800">Registration Activity</h2>
              </div>
              <div className="p-6">
                {analyticsLoading ? (
                  <div className="h-20 flex items-center justify-center">
                     <span className="text-xs text-gray-400">Loading...</span>
                  </div>
                ) : analytics ? (
                    <div className="space-y-6">
                      {[
                        { label: 'Course Registrations', value: analytics.courseRegistrations, color: 'bg-blue-600', max: Math.max(analytics.courseRegistrations, analytics.groupRegistrations, 100) },
                        { label: 'Group Registrations', value: analytics.groupRegistrations, color: 'bg-emerald-600', max: Math.max(analytics.courseRegistrations, analytics.groupRegistrations, 100) },
                      ].map(({ label, value, color, max }) => {
                        const width = Math.max((value / max) * 100, 5);
                        return (
                          <div key={label}>
                            <div className="flex items-center justify-between text-xs font-bold text-gray-600 mb-2">
                              <span>{label}</span>
                              <span className="bg-gray-100 px-2 py-0.5 rounded text-gray-800">{value}</span>
                            </div>
                            <div className="h-3 w-full bg-gray-100 rounded-full overflow-hidden">
                              <div className={`${color} h-full rounded-full transition-all duration-1000 ease-out`} style={{ width: `${width}%` }}></div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                ) : (
                  <p className="text-xs text-gray-400">No data available.</p>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar Area (Right 1/3) */}
          <div className="space-y-6">
            
            {/* User Distribution Card */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm p-6">
              <h3 className="font-bold text-gray-800 text-sm mb-4 border-b border-gray-100 pb-2">
                User Breakdown
              </h3>
              {analyticsLoading ? (
                <div className="py-4 text-center text-xs text-gray-400">Loading...</div>
              ) : !analytics ? (
                <p className="text-xs text-gray-400">Unavailable</p>
              ) : (
                <div className="space-y-5">
                  {[
                    { label: "Students", value: analytics.students, color: "bg-blue-600", bg: "bg-blue-100" },
                    { label: "Faculty", value: analytics.faculty, color: "bg-purple-600", bg: "bg-purple-100" },
                    { label: "Admins", value: analytics.admins, color: "bg-orange-500", bg: "bg-orange-100" },
                  ].map(({ label, value, color, bg }) => {
                    const total = analytics.totalUsers || 1;
                    const width = Math.max((value / total) * 100, 2);
                    return (
                      <div key={label}>
                        <div className="flex items-center justify-between text-xs font-semibold text-gray-600 mb-1">
                          <span>{label}</span>
                          <span className="text-gray-900">{value}</span>
                        </div>
                        <div className={`h-2 w-full ${bg} rounded-full overflow-hidden`}>
                          <div className={`${color} h-full rounded-full`} style={{ width: `${width}%` }}></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
            
            {/* Admin Profile Card - Moodle Block Style */}
            <div className="bg-white rounded-md border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
                 <h3 className="font-bold text-gray-800 text-sm">Logged in user</h3>
              </div>
              <div className="p-5 flex items-center space-x-4">
                <div className="w-12 h-12 bg-gray-200 rounded flex items-center justify-center text-gray-500 font-bold text-lg">
                  {user.email.charAt(0).toUpperCase()}
                </div>
                <div className="overflow-hidden">
                  <p className="font-bold text-sm text-gray-800 truncate" title={user.email}>
                    {user.email}
                  </p>
                  <p className="text-xs text-gray-500 mb-2">Administrator</p>
                  <Link
                    href="/admin/profile"
                    className="text-xs text-blue-600 font-semibold hover:underline"
                  >
                    Edit profile
                  </Link>
                </div>
              </div>
            </div>

            {/* Quick Links Block */}
             <div className="bg-white rounded-md border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-200 bg-gray-50">
                 <h3 className="font-bold text-gray-800 text-sm">Quick Links</h3>
              </div>
              <div className="p-2">
                 <ul className="text-sm">
                   <li>
                     <a href="#" className="block px-3 py-2 text-gray-600 hover:bg-gray-50 hover:text-blue-700 rounded transition-colors">
                        Documentation
                     </a>
                   </li>
                   <li>
                     <a href="#" className="block px-3 py-2 text-gray-600 hover:bg-gray-50 hover:text-blue-700 rounded transition-colors">
                        Security Reports
                     </a>
                   </li>
                    <li>
                     <a href="#" className="block px-3 py-2 text-gray-600 hover:bg-gray-50 hover:text-blue-700 rounded transition-colors">
                        Server Status
                     </a>
                   </li>
                 </ul>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}