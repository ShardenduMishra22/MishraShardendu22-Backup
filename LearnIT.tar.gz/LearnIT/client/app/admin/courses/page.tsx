'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/lib/store';
import { adminApi, type ApiResponse } from '@/lib/api';

interface ICourse {
  _id: string;
  courseName: string;
  courseCode: string;
  courseCredit: number;
  createdAt?: string;
}

export default function ManageCoursesPage() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();

  const [loading, setLoading] = useState(true);
  const [coursesLoading, setCoursesLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [courses, setCourses] = useState<ICourse[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [processingId, setProcessingId] = useState('');

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/admin');
      return;
    }

    if (user?.role !== 'admin') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  useEffect(() => {
    if (!hydrationComplete || !isAuthenticated || user?.role !== 'admin') {
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setError('');
      setSuccess('');
      setCoursesLoading(true);
    });

    adminApi
      .getCourses()
      .then((response) => {
        if (!isMounted) {
          return;
        }
        const coursesData = (response as ApiResponse<ICourse[]>).data ?? [];
        setCourses(coursesData);
      })
      .catch((fetchError: unknown) => {
        if (!isMounted) {
          return;
        }
        const message = fetchError instanceof Error ? fetchError.message : 'Failed to load courses.';
        setError(message);
      })
      .finally(() => {
        if (isMounted) {
          setCoursesLoading(false);
        }
      });

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [hydrationComplete, isAuthenticated, user]);

  const filteredCourses = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    if (!term) {
      return courses;
    }
    return courses.filter((course) =>
      course.courseName.toLowerCase().includes(term) || course.courseCode.toLowerCase().includes(term)
    );
  }, [searchTerm, courses]);

  const handleDelete = async (courseId: string) => {
    if (!window.confirm('Delete this course? Related groups and registrations will also be removed.')) {
      return;
    }

    setProcessingId(courseId);
    setError('');
    setSuccess('');

    try {
      const response = await adminApi.deleteCourse(courseId);
      setSuccess(response.message || 'Course deleted successfully.');
      setCourses((prev) => prev.filter((course) => course._id !== courseId));
    } catch (deleteError) {
      const message = deleteError instanceof Error ? deleteError.message : 'Failed to delete course.';
      setError(message);
    } finally {
      setProcessingId('');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-medium">Loading courses...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/admin/dashboard" className="hover:underline hover:text-blue-700">Dashboard</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Manage Courses</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">Courses</h1>
          <p className="text-sm text-gray-500 mt-1">Review and manage all courses on the platform.</p>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12 space-y-6">
        {(error || success) && (
          <div>
            {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-200 mb-2">{error}</p>}
            {success && <p className="text-sm text-green-600 bg-green-50 p-3 rounded-md border border-green-200">{success}</p>}
          </div>
        )}

        <div className="bg-white border border-gray-200 rounded-md shadow-sm p-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-lg font-semibold text-gray-800">Course Catalogue</h2>
              <p className="text-sm text-gray-500">{coursesLoading ? 'Loading courses…' : `${filteredCourses.length} of ${courses.length} courses`}</p>
            </div>
            <div className="relative w-full md:w-72">
              <input
                type="search"
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
                placeholder="Search by name or code"
                className="w-full border border-gray-300 rounded-md px-4 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
              <svg
                className="w-5 h-5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>

          <div className="mt-6 overflow-x-auto">
            {coursesLoading ? (
              <div className="py-12 text-center text-gray-500 text-sm">Fetching courses…</div>
            ) : filteredCourses.length === 0 ? (
              <div className="py-12 text-center text-gray-500 text-sm">No courses found.</div>
            ) : (
              <table className="min-w-full divide-y divide-gray-200 text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 uppercase tracking-wide">Course</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 uppercase tracking-wide">Code</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 uppercase tracking-wide">Credits</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 uppercase tracking-wide">Created</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 uppercase tracking-wide">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-100">
                  {filteredCourses.map((course) => (
                    <tr key={course._id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 whitespace-nowrap text-gray-800">{course.courseName}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-gray-600">{course.courseCode}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-gray-600">{course.courseCredit}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-gray-500">{course.createdAt ? new Date(course.createdAt).toLocaleDateString() : '—'}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => handleDelete(course._id)}
                          disabled={processingId === course._id}
                          className="px-3 py-1 text-xs font-semibold text-red-600 border border-red-200 rounded-md hover:bg-red-50 disabled:opacity-60"
                        >
                          {processingId === course._id ? 'Deleting…' : 'Delete'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
