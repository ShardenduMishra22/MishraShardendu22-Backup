'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/lib/store';
import { adminApi, type ApiResponse } from '@/lib/api';

interface IUser {
  _id: string;
  email: string;
  role: 'student' | 'faculty' | 'admin';
}

export default function ManageUsersPage() {
  const router = useRouter();
  const { user, isAuthenticated, initializeAuth, hydrationComplete } = useUserStore();

  const [loading, setLoading] = useState(true);
  const [usersLoading, setUsersLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [users, setUsers] = useState<IUser[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [processingId, setProcessingId] = useState('');

  useEffect(() => {
    if (!hydrationComplete) {
      initializeAuth();
    }
  }, [initializeAuth, hydrationComplete]);

  useEffect(() => {
    if (!hydrationComplete) {
      return;
    }

    if (!isAuthenticated) {
      router.push('/login/admin');
      return;
    }

    if (user?.role !== 'admin') {
      router.push('/');
      return;
    }

    const frame = window.requestAnimationFrame(() => setLoading(false));
    return () => window.cancelAnimationFrame(frame);
  }, [hydrationComplete, isAuthenticated, user, router]);

  useEffect(() => {
    if (!hydrationComplete || !isAuthenticated || user?.role !== 'admin') {
      return;
    }

    let isMounted = true;
    const frame = window.requestAnimationFrame(() => {
      if (!isMounted) {
        return;
      }
      setError('');
      setSuccess('');
      setUsersLoading(true);
    });

    adminApi
      .getUsers()
      .then((response) => {
        if (!isMounted) {
          return;
        }
        const usersData = (response as ApiResponse<IUser[]>).data ?? [];
        setUsers(usersData);
      })
      .catch((fetchError: unknown) => {
        if (!isMounted) {
          return;
        }
        const message = fetchError instanceof Error ? fetchError.message : 'Failed to load users.';
        setError(message);
      })
      .finally(() => {
        if (isMounted) {
          setUsersLoading(false);
        }
      });

    return () => {
      isMounted = false;
      window.cancelAnimationFrame(frame);
    };
  }, [hydrationComplete, isAuthenticated, user]);

  const filteredUsers = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    if (!term) {
      return users;
    }
    return users.filter((item) => item.email.toLowerCase().includes(term) || item.role.toLowerCase().includes(term));
  }, [searchTerm, users]);

  const beginEdit = (target: IUser) => {
    setEditingId(target._id);
    setEditEmail(target.email);
    setError('');
    setSuccess('');
  };

  const cancelEdit = () => {
    setEditingId('');
    setEditEmail('');
  };

  const handleUpdate = async (userId: string) => {
    if (!editEmail.trim()) {
      setError('Email cannot be empty.');
      return;
    }

    setProcessingId(userId);
    setError('');
    setSuccess('');

    try {
      const response = await adminApi.updateUser(userId, editEmail.trim().toLowerCase());
      setSuccess(response.message || 'User updated successfully.');
      setUsers((prev) => prev.map((item) => (item._id === userId ? { ...item, email: editEmail.trim().toLowerCase() } : item)));
      cancelEdit();
    } catch (updateError) {
      const message = updateError instanceof Error ? updateError.message : 'Failed to update user.';
      setError(message);
    } finally {
      setProcessingId('');
    }
  };

  const handleDelete = async (userId: string) => {
    if (!window.confirm('Are you sure you want to remove this user? This action cannot be undone.')) {
      return;
    }

    setProcessingId(userId);
    setError('');
    setSuccess('');

    try {
      const response = await adminApi.deleteUser(userId);
      setSuccess(response.message || 'User deleted successfully.');
      setUsers((prev) => prev.filter((item) => item._id !== userId));
    } catch (deleteError) {
      const message = deleteError instanceof Error ? deleteError.message : 'Failed to delete user.';
      setError(message);
    } finally {
      setProcessingId('');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f2f2f2] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-medium">Loading users...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f2f2] font-sans text-gray-800">
      <div className="bg-white border-b border-gray-300 px-6 py-4 mb-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
            <Link href="/admin/dashboard" className="hover:underline hover:text-blue-700">Dashboard</Link>
            <span>/</span>
            <span className="text-gray-800 font-semibold">Manage Users</span>
          </div>
          <h1 className="text-3xl font-light text-gray-800">User Directory</h1>
          <p className="text-sm text-gray-500 mt-1">Search, update, or remove users across the platform.</p>
        </div>
      </div>

      <div className="container mx-auto px-6 max-w-6xl pb-12 space-y-6">
        {(error || success) && (
          <div>
            {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-200 mb-2">{error}</p>}
            {success && <p className="text-sm text-green-600 bg-green-50 p-3 rounded-md border border-green-200">{success}</p>}
          </div>
        )}

        <div className="bg-white border border-gray-200 rounded-md shadow-sm p-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-lg font-semibold text-gray-800">Users</h2>
              <p className="text-sm text-gray-500">{usersLoading ? 'Loading users…' : `${filteredUsers.length} of ${users.length} users`}</p>
            </div>
            <div className="relative w-full md:w-72">
              <input
                type="search"
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
                placeholder="Search by email or role"
                className="w-full border border-gray-300 rounded-md px-4 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
              <svg
                className="w-5 h-5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>

          <div className="mt-6 overflow-x-auto">
            {usersLoading ? (
              <div className="py-12 text-center text-gray-500 text-sm">Fetching users…</div>
            ) : filteredUsers.length === 0 ? (
              <div className="py-12 text-center text-gray-500 text-sm">No users found matching your criteria.</div>
            ) : (
              <table className="min-w-full divide-y divide-gray-200 text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 uppercase tracking-wide">Email</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 uppercase tracking-wide">Role</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 uppercase tracking-wide">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-100">
                  {filteredUsers.map((item) => {
                    const isEditing = editingId === item._id;
                    const isSelf = item._id === user?._id;

                    return (
                      <tr key={item._id} className="hover:bg-gray-50">
                        <td className="px-4 py-3 whitespace-nowrap text-gray-800">
                          {isEditing ? (
                            <input
                              type="email"
                              value={editEmail}
                              onChange={(event) => setEditEmail(event.target.value)}
                              className="border border-gray-300 rounded-md px-2 py-1 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 w-full"
                            />
                          ) : (
                            item.email
                          )}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-gray-600 capitalize">{item.role}</td>
                        <td className="px-4 py-3 whitespace-nowrap flex items-center gap-2">
                          {isEditing ? (
                            <>
                              <button
                                type="button"
                                onClick={() => handleUpdate(item._id)}
                                disabled={processingId === item._id}
                                className="px-3 py-1 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-md disabled:bg-blue-400"
                              >
                                {processingId === item._id ? 'Saving…' : 'Save'}
                              </button>
                              <button
                                type="button"
                                onClick={cancelEdit}
                                className="px-3 py-1 text-xs font-semibold text-gray-600 border border-gray-300 rounded-md hover:bg-gray-100"
                              >
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                type="button"
                                onClick={() => beginEdit(item)}
                                className="px-3 py-1 text-xs font-semibold text-blue-600 border border-blue-200 rounded-md hover:bg-blue-50"
                              >
                                Edit
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDelete(item._id)}
                                disabled={isSelf || processingId === item._id}
                                className="px-3 py-1 text-xs font-semibold text-red-600 border border-red-200 rounded-md hover:bg-red-50 disabled:opacity-60"
                              >
                                {processingId === item._id ? 'Removing…' : 'Remove'}
                              </button>
                            </>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
