import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#f2f2f2] text-gray-800 px-6 text-center">
      <div className="max-w-md space-y-6">
        <span className="text-6xl" role="img" aria-label="tractor">🚜</span>
        <div className="space-y-3">
          <h1 className="text-4xl font-semibold tracking-tight">Work Under Construction</h1>
          <p className="text-sm text-gray-600">
            Looks like you&apos;ve driven off the beaten path. We&apos;re still grading the road ahead, so check back soon or head back to safer ground.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/"
            className="inline-flex items-center justify-center rounded-md bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
          >
            Return to dashboard
          </Link>
          <Link
            href="/student/dashboard"
            className="inline-flex items-center justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 transition hover:bg-gray-100"
          >
            Student home
          </Link>
        </div>
      </div>
    </div>
  );
}
