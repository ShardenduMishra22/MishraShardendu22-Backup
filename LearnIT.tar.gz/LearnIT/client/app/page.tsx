import FeaturesSection from '@/components/Landing/FeaturesSection';
import HeroSection from '@/components/Landing/HeroSection';
import LoginSection from '@/components/Landing/LoginSection';
import StatsSection from '@/components/Landing/StatsSection'; 
import CtaSection from '@/components/Landing/CtaSection';

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 selection:bg-emerald-200">
      <HeroSection />
      <StatsSection />
      <div className="container mx-auto px-6 py-16 space-y-24">
        <LoginSection />
        <FeaturesSection />
      </div>
      <CtaSection />
    </div>
  );
}