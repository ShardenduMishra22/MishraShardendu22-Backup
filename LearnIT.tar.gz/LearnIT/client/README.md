# LearnIT Frontend

Learning Management System for IIIT Dharwad - Client Application

## 🎯 Overview

LearnIT is a comprehensive Learning Management System (LMS) with role-based access control for Students, Faculty, and Administrators. The frontend is built with Next.js 16, TypeScript, and Tailwind CSS, featuring a government/college website aesthetic inspired by IIIT Dharwad's official website.

## 🏗️ Architecture

### Frontend Stack
- **Framework**: Next.js 16 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS 4
- **State Management**: React Hooks + localStorage
- **API**: REST API with JWT Bearer Token authentication

### Backend Integration
- **Base URL**: `http://localhost:5000/api/v1`
- **Authentication**: JWT (30-day expiry)
- **Roles**: Student, Faculty, Admin

## 📂 Project Structure

```
client/
├── app/                          # Next.js App Router
│   ├── layout.tsx               # Root layout with Header/Footer
│   ├── page.tsx                 # Homepage with hero & features
│   ├── login/                   # Authentication pages
│   │   ├── student/page.tsx     # Student login/register
│   │   ├── faculty/page.tsx     # Faculty login/register
│   │   └── admin/page.tsx       # Admin login/register
│   └── student/                 # Student dashboard pages
│       └── dashboard/page.tsx   # Student dashboard
├── components/                   # Reusable components
│   ├── Header.tsx               # Navigation header
│   └── Footer.tsx               # Site footer
├── lib/                         # Utilities & helpers
│   ├── api.ts                   # API functions for all endpoints
│   └── auth.ts                  # Authentication helpers
├── .env.local                   # Environment variables
└── tailwind.config.ts           # Tailwind configuration
```

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ and pnpm
- MongoDB running locally
- Backend server running on port 5000

### Installation

1. **Install dependencies:**
```bash
cd client
pnpm install
```

2. **Configure environment:**
Create `.env.local`:
```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api/v1
```

3. **Run development server:**
```bash
pnpm dev
```

The app will be available at `http://localhost:3000`

## 🎨 Design System

### Color Palette (Government Website Style)
- **Primary**: Blue-900 to Blue-700 (Navigation, Headers)
- **Student**: Blue-600 (Student-specific features)
- **Faculty**: Green-600 (Faculty-specific features)
- **Admin**: Purple-600 (Admin-specific features)
- **Background**: Gray-50 with White cards
- **Accents**: Amber for warnings, Red for errors

### Typography
- **Headings**: Bold, Large sizes (3xl-6xl)
- **Body**: Regular, comfortable reading size
- **Labels**: Small, medium weight

### Components
- **Cards**: White background, rounded-xl, shadow-md/lg
- **Buttons**: Colored backgrounds, hover effects, shadows
- **Forms**: Clean inputs with focus rings
- **Icons**: Heroicons (outline style)

## 🔐 Authentication Flow

### User Roles

#### 1. **Student**
- **Email Format**: `##XXX###@iiitdwd.ac.in` (e.g., `23bec001@iiitdwd.ac.in`)
- **Features**:
  - Browse and register for courses
  - Join study groups
  - Take quizzes
  - View results

#### 2. **Faculty**
- **Email Format**: Any `@iiitdwd.ac.in` (except student ID format)
- **Features**:
  - Create courses
  - Manage groups
  - Create quizzes with questions
  - View student performance

#### 3. **Admin**
- **Email Format**: Any `@iiitdwd.ac.in`
- **Requires**: Admin secret password (ADMIN_PASSWORD from backend .env)
- **Features**:
  - Manage all users
  - Oversee courses and groups
  - View analytics
  - System administration

### Login Process
1. User enters credentials
2. Frontend calls `/api/v1/{role}/login`
3. Backend returns JWT token
4. Token stored in localStorage
5. User redirected to role-specific dashboard

## 📡 API Integration

### API Helper (`lib/api.ts`)

All API endpoints are wrapped in helper functions:

```typescript
// Example: Student login
const response = await authApi.studentLogin(email, password);
setAuth(response.data, userObject);

// Example: Get courses
const courses = await studentApi.getAllCourses();
```

### Available APIs

**Authentication**
- `authApi.studentLogin/Register()`
- `authApi.facultyLogin/Register()`
- `authApi.adminLogin/Register(adminPassword)`

**Student APIs** (14 endpoints)
- `studentApi.getAllCourses()`
- `studentApi.registerForCourse(courseId)`
- `studentApi.getMyCourses()`
- `studentApi.getAvailableGroups()`
- `studentApi.registerForGroup(groupId)`
- `studentApi.getMyGroups()`
- `studentApi.getAvailableQuizzes()`
- `studentApi.submitQuiz(quizId, answers)`
- `studentApi.getMyQuizResults()`

**Faculty APIs** (13 endpoints)
- `facultyApi.createCourse()`
- `facultyApi.createGroup()`
- `facultyApi.getMyGroups()`
- `facultyApi.createQuiz()`
- `facultyApi.addQuizQuestion()`
- `facultyApi.getQuizResults()`

**Admin APIs** (12 endpoints)
- `adminApi.getAnalytics()`
- `adminApi.getUsers()`
- `adminApi.deleteUser(userId)`
- `adminApi.getCourses()`
- `adminApi.getGroups()`
- `adminApi.getQuizzes()`

## 🎯 Current Features

### ✅ Completed
1. **Homepage**
   - Hero section with CTA buttons
   - Feature cards for each role
   - Quick access cards
   - Government-style information banner

2. **Authentication Pages**
   - Student login/register (Blue theme)
   - Faculty login/register (Green theme)
   - Admin login/register (Purple theme, requires secret password)
   - Email format validation
   - Password validation (6-20 characters)
   - Error handling
   - Role switcher links

3. **Layout Components**
   - Responsive header with navigation
   - Top bar with contact info (phone, email)
   - Logo section with IIIT Dharwad branding
   - Role-based navigation links
   - Quick links bar (About, Academics, Admissions, Research)
   - Comprehensive footer with 4 columns
   - Social media links (Instagram, LinkedIn, X, YouTube)

4. **Student Dashboard**
   - Protected route with auth check
   - User email display with logout
   - 4 Quick stats cards (My Courses, My Groups, Quizzes, Results)
   - 4 Quick action buttons (Browse, Join, Take Quiz, View Results)
   - Recent activity section
   - Sidebar with 3 cards:
     - Announcements
     - Profile card with avatar
     - Help & Support

### 🚧 To Be Implemented
1. **Student Features**
   - Course browsing page with filters
   - Course registration flow
   - My courses page with details
   - Group browsing and joining
   - Quiz taking interface with timer
   - Results viewing with charts

2. **Faculty Dashboard & Features**
   - Faculty dashboard (similar to student)
   - Course creation form
   - Group creation and management
   - Quiz builder with question types
   - Student performance analytics
   - Results management

3. **Admin Dashboard & Features**
   - Admin dashboard with system analytics
   - User management (view, delete, search)
   - Course management
   - Group management
   - Quiz management
   - System-wide reports

## 🛠️ Development Guide

### Adding New Pages

1. Create page in `app/` directory:
```typescript
// app/student/courses/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { studentApi } from '@/lib/api';

export default function CoursesPage() {
  const [courses, setCourses] = useState([]);
  
  useEffect(() => {
    studentApi.getAllCourses().then(setCourses);
  }, []);

  return <div>Courses: {courses.length}</div>;
}
```

2. Update navigation in `Header.tsx`

3. Add API calls in `lib/api.ts` if needed

### Adding New API Endpoints

```typescript
// In lib/api.ts
export const studentApi = {
  // Add new function
  newFunction: (param: string) =>
    apiCall('/student/new-endpoint', {
      method: 'POST',
      body: JSON.stringify({ param }),
    }),
};
```

### Styling Guidelines

1. **Use Tailwind utility classes**
2. **Follow government website color scheme**
3. **Maintain role-based color coding:**
   - Blue (`bg-blue-600`, `text-blue-600`) for students
   - Green (`bg-green-600`, `text-green-600`) for faculty
   - Purple (`bg-purple-600`, `text-purple-600`) for admin
4. **Use consistent spacing:**
   - Padding: `px-4`, `py-3`, `p-6`
   - Gaps: `gap-4`, `gap-6`, `gap-8`
   - Margins: `mb-4`, `mt-6`, etc.
5. **Add hover effects:** `hover:bg-blue-700`, `hover:shadow-lg`
6. **Responsive design:** Use `md:`, `lg:` prefixes

## 🔒 Security Considerations

1. **Token Storage**: JWT stored in localStorage
2. **Route Protection**: Dashboard pages check authentication and redirect
3. **API Calls**: Token automatically included in Authorization headers
4. **Logout**: Clears all auth data and redirects to home
5. **Admin Password**: Required for admin registration/login
6. **Email Validation**: Enforces `@iiitdwd.ac.in` domain
7. **Student ID Format**: Validated with regex for student registration

## 📱 Responsive Design

- **Mobile First**: Tailwind's mobile-first approach
- **Breakpoints**:
  - `sm`: 640px
  - `md`: 768px
  - `lg`: 1024px
  - `xl`: 1280px

- **Grid Layouts**: Responsive columns
  - Mobile: 1 column
  - Tablet: 2 columns
  - Desktop: 3-4 columns
- **Navigation**: Desktop nav bar, mobile menu (to be implemented)

## 🐛 Known Issues & TODOs

- [ ] Mobile hamburger navigation menu
- [ ] Protected routes middleware
- [ ] Loading states for API calls
- [ ] Error boundaries for better error handling
- [ ] Form validation improvements (real-time)
- [ ] Quiz taking interface with timer
- [ ] Results visualization with charts
- [ ] File upload for quiz questions
- [ ] Real-time notifications
- [ ] Dark mode support
- [ ] Pagination for lists
- [ ] Search and filter functionality
- [ ] Profile editing pages
- [ ] Password reset flow

## 🧪 Testing

```bash
# Run linter
pnpm lint

# Build for production
pnpm build

# Start production server
pnpm start
```

## 📚 Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [IIIT Dharwad Website](https://iiitdwd.ac.in/) (Design Reference)
- [MongoDB Documentation](https://www.mongodb.com/docs/)

## 👥 Contributing

When adding features:
1. Follow existing code style and patterns
2. Use TypeScript types properly
3. Add proper error handling
4. Test authentication flows
5. Maintain responsive design
6. Update this README with new features
7. Comment complex logic

## 📝 Notes

- This is a foundational setup with basic authentication and dashboard
- Many features show placeholder data and need full API integration
- Follow the step-by-step approach: dashboards → courses → groups → quizzes
- Always test with the backend server running

## 📄 License

Part of LearnIT LMS - Internal IIIT Dharwad Project

---

**Created with**: Next.js 16, TypeScript, Tailwind CSS  
**Inspired by**: IIIT Dharwad Official Website  
**Last Updated**: Current session - Basic setup complete
