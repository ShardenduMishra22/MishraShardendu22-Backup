import { useUserStore } from './store';

// API Configuration and Helper Functions
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api/v1';

export interface ApiResponse<T = unknown> {
  message: string;
  data: T;
  token?: string;
}

// Generic API call function
async function apiCall<T = unknown>(
  endpoint: string,
  options: RequestInit = {},
  customToken?: string
): Promise<ApiResponse<T>> {
  let token = customToken || useUserStore.getState().token;

  if (!token && typeof window !== 'undefined') {
    try {
      const persisted = localStorage.getItem('user-storage');
      if (persisted) {
        const parsed = JSON.parse(persisted) as { state?: { token?: string } };
        token = parsed?.state?.token ?? null;
      }
    } catch (error) {
      console.error('Error reading persisted token:', error);
    }

    if (!token) {
      token = localStorage.getItem('token');
    }
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (options.headers) {
    Object.assign(headers, options.headers);
  }

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const rawBody = await response.text();
  let data: ApiResponse<T> | null = null;

  if (rawBody) {
    try {
      data = JSON.parse(rawBody) as ApiResponse<T>;
    } catch (error) {
      console.warn('Non-JSON response received from API:', {
        endpoint,
        error,
        preview: rawBody.slice(0, 120),
      });
    }
  }

  if (!response.ok) {
    const message = data?.message || rawBody || response.statusText || 'An error occurred';
    throw new Error(message);
  }

  if (data) {
    return data;
  }

  return {
    message: rawBody || 'Success',
    data: undefined as T,
  };
}

// Auth APIs
export const authApi = {
  // Student Auth
  studentLogin: (email: string, password: string) =>
    apiCall('/student/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  studentRegister: (email: string, password: string) =>
    apiCall('/student/register', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  verifyStudent: (token?: string) => apiCall('/student/verify', {}, token),

  // Faculty Auth
  facultyLogin: (email: string, password: string) =>
    apiCall('/faculty/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  facultyRegister: (email: string, password: string) =>
    apiCall('/faculty/register', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  verifyFaculty: (token?: string) => apiCall('/faculty/verify', {}, token),

  // Admin Auth
  adminLogin: (email: string, password: string, adminPassword: string) =>
    apiCall('/admin/login', {
      method: 'POST',
      body: JSON.stringify({ email, password, adminPassword }),
    }),
  adminRegister: (email: string, password: string, adminPassword: string) =>
    apiCall('/admin/register', {
      method: 'POST',
      body: JSON.stringify({ email, password, adminPassword }),
    }),
  verifyAdmin: (token?: string) => apiCall('/admin/verify', {}, token),
};

// Student APIs
export const studentApi = {
  getAllCourses: () => apiCall('/student/courses'),
  registerForCourse: (courseId: string) =>
    apiCall('/student/course/register', {
      method: 'POST',
      body: JSON.stringify({ courseId }),
    }),
  getMyCourses: () => apiCall('/student/courses/my'),
  getAvailableGroups: () => apiCall('/student/groups/available'),
  registerForGroup: (groupId: string) =>
    apiCall('/student/group/register', {
      method: 'POST',
      body: JSON.stringify({ groupId }),
    }),
  getMyGroups: () => apiCall('/student/groups/my'),
  getMyCourseGrades: () => apiCall('/student/grades'),
  getAvailableQuizzes: () => apiCall('/student/quizzes/available'),
  getQuizQuestions: (quizId: string) => apiCall(`/student/quiz/${quizId}/questions`),
  submitQuiz: (quizId: string, answers: Array<{ questionId: string; selectedAnswer: string }>) =>
    apiCall('/student/quiz/submit', {
      method: 'POST',
      body: JSON.stringify({ quizId, answers }),
    }),
  getMyQuizResults: () => apiCall('/student/quiz/results'),
  updateProfile: (email: string) =>
    apiCall('/student/profile', {
      method: 'PUT',
      body: JSON.stringify({ email }),
    }),
  changePassword: (currentPassword: string, newPassword: string) =>
    apiCall('/student/change-password', {
      method: 'PUT',
      body: JSON.stringify({ currentPassword, newPassword }),
    }),
};

// Faculty APIs
export const facultyApi = {
  createCourse: (courseCode: string, courseName: string, courseCredit: number) =>
    apiCall('/faculty/course', {
      method: 'POST',
      body: JSON.stringify({ courseCode, courseName, courseCredit }),
    }),
  getMyCourses: () => apiCall('/faculty/courses'),
  getDashboardStats: () => apiCall('/faculty/dashboard/stats'),
  createGroup: (name: string, courseId: string, registrationOpen: boolean) =>
    apiCall('/faculty/group', {
      method: 'POST',
      body: JSON.stringify({ name, courseId, registrationOpen }),
    }),
  getMyGroups: () => apiCall('/faculty/groups'),
  updateGroup: (groupId: string, name?: string, registrationOpen?: boolean) =>
    apiCall('/faculty/group', {
      method: 'PUT',
      body: JSON.stringify({ groupId, name, registrationOpen }),
    }),
  getGroupRegistrations: (groupId: string) =>
    apiCall(`/faculty/group/${groupId}/registrations`),
  updateStudentMarks: (
    groupId: string,
    studentId: string,
    payload: {
      midSemMarks?: number | null;
      endSemMarks?: number | null;
      midSemMaxMarks?: number;
      endSemMaxMarks?: number;
    }
  ) =>
    apiCall(`/faculty/group/${groupId}/student/${studentId}/marks`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  createQuiz: (name: string, groupId: string, settings?: {
    timeLimitMinutes?: number | null;
    shuffleQuestions?: boolean;
    allowBackNavigation?: boolean;
    passingScore?: number | null;
    instructions?: string;
  }) =>
    apiCall('/faculty/quiz', {
      method: 'POST',
      body: JSON.stringify({ name, groupId, settings }),
    }),
  getMyQuizzes: () => apiCall('/faculty/quizzes'),
  updateQuizSettings: (
    quizId: string,
    settings: {
      timeLimitMinutes?: number | null;
      shuffleQuestions?: boolean;
      allowBackNavigation?: boolean;
      passingScore?: number | null;
      instructions?: string;
    }
  ) =>
    apiCall(`/faculty/quiz/${quizId}/settings`, {
      method: 'PUT',
      body: JSON.stringify(settings),
    }),
  addQuizQuestion: (
    quizId: string,
    questionText: string,
    options: string[],
    answer: string,
    questionType: 'multiple-choice' | 'text',
    questionImage?: string
  ) =>
    apiCall('/faculty/quiz/question', {
      method: 'POST',
      body: JSON.stringify({ quizId, questionText, options, answer, questionType, questionImage }),
    }),
  getQuizQuestions: (quizId: string) => apiCall(`/faculty/quiz/${quizId}/questions`),
  getQuizResults: (quizId: string) => apiCall(`/faculty/quiz/${quizId}/results`),
  updateProfile: (email: string) =>
    apiCall('/faculty/profile', {
      method: 'PUT',
      body: JSON.stringify({ email }),
    }),
  changePassword: (currentPassword: string, newPassword: string) =>
    apiCall('/faculty/change-password', {
      method: 'PUT',
      body: JSON.stringify({ currentPassword, newPassword }),
    }),
};

// Admin APIs
export const adminApi = {
  getAnalytics: () => apiCall('/admin/analytics'),
  getUsers: () => apiCall('/admin/users'),
  updateUser: (userId: string, email: string) =>
    apiCall('/admin/user', {
      method: 'PUT',
      body: JSON.stringify({ userId, email }),
    }),
  deleteUser: (userId: string) =>
    apiCall('/admin/user', {
      method: 'DELETE',
      body: JSON.stringify({ userId }),
    }),
  getCourses: () => apiCall('/admin/courses'),
  deleteCourse: (courseId: string) =>
    apiCall('/admin/course', {
      method: 'DELETE',
      body: JSON.stringify({ courseId }),
    }),
  getGroups: () => apiCall('/admin/groups'),
  deleteGroup: (groupId: string) =>
    apiCall('/admin/group', {
      method: 'DELETE',
      body: JSON.stringify({ groupId }),
    }),
  getQuizzes: () => apiCall('/admin/quizzes'),
  deleteQuiz: (quizId: string) =>
    apiCall('/admin/quiz', {
      method: 'DELETE',
      body: JSON.stringify({ quizId }),
    }),
  resetPassword: (email: string, password: string) =>
    apiCall('/admin/resetPassword', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  updateProfile: (email: string) =>
    apiCall('/admin/profile', {
      method: 'PUT',
      body: JSON.stringify({ email }),
    }),
  changePassword: (currentPassword: string, newPassword: string) =>
    apiCall('/admin/change-password', {
      method: 'PUT',
      body: JSON.stringify({ currentPassword, newPassword }),
    }),
};
