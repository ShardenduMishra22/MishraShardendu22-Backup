'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  _id: string;
  email: string;
  role: 'student' | 'faculty' | 'admin';
}

interface UserStore {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  hydrationComplete: boolean;
  setUser: (user: User | null, token?: string) => void;
  logout: () => void;
  initializeAuth: () => void;
}

export const useUserStore = create<UserStore>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      hydrationComplete: false,

      setUser: (user, token) => {
        const resolvedToken = token || get().token;

        set({ 
          user, 
          token: resolvedToken,
          isAuthenticated: !!user,
          hydrationComplete: true,
        });

        if (typeof window !== 'undefined') {
          if (user) {
            localStorage.setItem('user', JSON.stringify(user));
          } else {
            localStorage.removeItem('user');
          }

          if (resolvedToken) {
            localStorage.setItem('token', resolvedToken);
          } else {
            localStorage.removeItem('token');
          }
        }
      },

      logout: () => {
        set({ 
          user: null, 
          token: null, 
          isAuthenticated: false,
          hydrationComplete: true,
        });
        // Clear localStorage
        if (typeof window !== 'undefined') {
          localStorage.removeItem('token');
          localStorage.removeItem('user');
        }
      },

      initializeAuth: () => {
        if (get().hydrationComplete) {
          return;
        }

        if (typeof window !== 'undefined') {
          const token = localStorage.getItem('token');
          const userStr = localStorage.getItem('user');

          if (token && userStr) {
            try {
              const user = JSON.parse(userStr) as User;
              set({
                user,
                token,
                isAuthenticated: true,
                hydrationComplete: true,
              });
              return;
            } catch (error) {
              console.error('Error parsing user data:', error);
              get().logout();
              set({ hydrationComplete: true });
              return;
            }
          }
        }

        set({
          user: null,
          token: null,
          isAuthenticated: false,
          hydrationComplete: true,
        });
      },
    }),
    {
      name: 'user-storage',
      partialize: (state) => ({ 
        user: state.user, 
        token: state.token,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);
