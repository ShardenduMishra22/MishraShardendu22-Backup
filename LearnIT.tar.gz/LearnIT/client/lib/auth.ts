import { useUserStore } from './store';

// Authentication Helper Functions
export type UserRole = 'student' | 'faculty' | 'admin';

export interface User {
  _id: string;
  email: string;
  role: UserRole;
}

// Store token and user data (now uses Zustand)
export function setAuth(token: string, user: User) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    useUserStore.getState().setUser(user, token);
  }
}

// Get stored user data (now uses Zustand)
export function getUser(): User | null {
  if (typeof window !== 'undefined') {
    const storeUser = useUserStore.getState().user;
    if (storeUser) return storeUser;
    
    // Fallback to localStorage
    const userStr = localStorage.getItem('user');
    if (userStr) {
      try {
        return JSON.parse(userStr);
      } catch {
        return null;
      }
    }
  }
  return null;
}

// Get stored token (now uses Zustand)
export function getToken(): string | null {
  if (typeof window !== 'undefined') {
    const storeToken = useUserStore.getState().token;
    if (storeToken) return storeToken;
    
    // Fallback to localStorage
    return localStorage.getItem('token');
  }
  return null;
}

// Check if user is authenticated (now uses Zustand)
export function isAuthenticated(): boolean {
  if (typeof window !== 'undefined') {
    return useUserStore.getState().isAuthenticated || !!getToken();
  }
  return false;
}

// Clear authentication (now uses Zustand)
export function logout() {
  if (typeof window !== 'undefined') {
    useUserStore.getState().logout();
    window.location.href = '/';
  }
}

// Check if user has specific role
export function hasRole(role: UserRole): boolean {
  const user = getUser();
  return user?.role === role;
}

// Get dashboard path based on role
export function getDashboardPath(role: UserRole): string {
  switch (role) {
    case 'student':
      return '/student/dashboard';
    case 'faculty':
      return '/faculty/dashboard';
    case 'admin':
      return '/admin/dashboard';
    default:
      return '/';
  }
}
