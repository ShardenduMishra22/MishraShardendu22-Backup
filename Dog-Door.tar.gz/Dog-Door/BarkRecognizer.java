import java.util.ArrayList;

public class BarkRecognizer {
    private DogDoor dogDoor;
    private ArrayList<Bark> allowedBarks;

    public BarkRecognizer(DogDoor dogDoor) {
        this.dogDoor = dogDoor;
        this.allowedBarks = new ArrayList<>();
    }

    public void addAllowedBark(Bark bark) {
        allowedBarks.add(bark);
        System.out.println("Added allowed bark: " + bark);
    }

    public void removeAllowedBark(Bark bark) {
        if (allowedBarks.remove(bark)) {
            System.out.println("Removed allowed bark: " + bark);
        } else {
            System.out.println("Bark not found in allowed list: " + bark);
        }
    }

    public void recognize(Bark bark) {
        System.out.println("Sound detected: " + bark);
        String location = dogDoor.isDogInside() ? "inside" : "outside";
        System.out.println("Bark detected from " + location);
        
        // Check if the bark matches any of the allowed barks
        for (Bark allowedBark : allowedBarks) {
            if (bark.matches(allowedBark)) {
                System.out.println("Authorized bark recognized!");
                dogDoor.addRecognizedBark(bark);
                if (!dogDoor.isOpen()) {
                    dogDoor.open();
                } else {
                    System.out.println("Door is already open");
                }
                return;
            }
        }
        
        System.out.println("Unauthorized sound, ignoring...");
    }

    public ArrayList<Bark> getAllowedBarks() {
        return new ArrayList<>(allowedBarks);
    }

    public DogDoor getDogDoor() {
        return dogDoor;
    }

    public void setDogDoor(DogDoor dogDoor) {
        this.dogDoor = dogDoor;
    }
}
