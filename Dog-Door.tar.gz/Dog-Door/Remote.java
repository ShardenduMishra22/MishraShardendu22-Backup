public class Remote {
    private DogDoor dogDoor;

    public Remote(DogDoor dogDoor) {
        this.dogDoor = dogDoor;
    }

    public void pressOpenButton() {
        System.out.println("Remote OPEN button pressed!");
        if (!dogDoor.isOpen()) {
            dogDoor.openManually();
        } else {
            System.out.println("Door is already open");
        }
    }

    public void pressCloseButton() {
        System.out.println("Remote CLOSE button pressed!");
        if (dogDoor.isOpen()) {
            dogDoor.closeManually();
        } else {
            System.out.println("Door is already closed");
        }
    }

    // Legacy method for backward compatibility
    public void pressButton() {
        System.out.println("Remote button pressed!");
        if (!dogDoor.isOpen()) {
            dogDoor.openManually();
        } else {
            System.out.println("Door is already open");
        }
    }

    public DogDoor getDogDoor() {
        return dogDoor;
    }

    public void setDogDoor(DogDoor dogDoor) {
        this.dogDoor = dogDoor;
    }
}
