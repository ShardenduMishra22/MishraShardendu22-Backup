public class DogDoorSimulator {
    public static void main(String[] args) {
        // Create a dog door with dimensions
        DogDoor door = new DogDoor(30.0, 40.0);
        
        // Create remote and bark recognizer
        Remote remote = new Remote(door);
        BarkRecognizer barkRecognizer = new BarkRecognizer(door);
        
        System.out.println("=== Dog Door System Demo ===\n");
        
        // Configure allowed barks (only specific dog's bark)
        System.out.println("Configuring Bark Recognizer:");
        barkRecognizer.addAllowedBark(new Bark("Woof", 7, 600));
        barkRecognizer.addAllowedBark(new Bark("Woof Woof", 8, 650));
        System.out.println();
        
        // Test remote control
        System.out.println("Testing Remote Control (opens door):");
        remote.pressButton();  // Opens door
        System.out.println();
        
        remote.pressButton();  // Already open
        System.out.println();
        
        // Test bark recognition with unauthorized sounds
        System.out.println("Testing Bark Recognition:");
        barkRecognizer.recognize(new Bark("meow", 3, 400));  // Should ignore (cat)
        System.out.println();
        
        barkRecognizer.recognize(new Bark("bark", 5, 500));  // Should ignore (not in allowed list)
        System.out.println();
        
        // Test with authorized barks
        barkRecognizer.recognize(new Bark("Woof", 7, 600));  // Should open door (if closed) and store
        System.out.println();
        
        barkRecognizer.recognize(new Bark("WOOF WOOF", 8, 650));  // Already open, case-insensitive
        System.out.println();
        
        // Display recognized barks
        System.out.println("All recognized barks stored in DogDoor:");
        for (Bark bark : door.getRecognizedBarks()) {
            System.out.println("  - " + bark);
        }
        System.out.println();
        
        // Wait to demonstrate auto-close
        System.out.println("Waiting for auto-close demonstration...");
        try {
            Thread.sleep(6000);  // Wait 6 seconds to see auto-close
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("\nTesting another bark after auto-close:");
        barkRecognizer.recognize(new Bark("woof woof", 6, 620));  // Should open door again
        
        // Keep program running briefly to see final auto-close
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("\n=== Demo Complete ===");
    }
}
