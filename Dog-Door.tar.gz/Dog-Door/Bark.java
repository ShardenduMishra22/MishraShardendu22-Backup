public class Bark {
    private String sound;
    private int volume;      // 1-10 scale
    private int frequency;   // Hz
    private long timestamp;  // When the bark was detected
    
    public Bark(String sound) {
        this.sound = sound;
        this.volume = 5;     // Default medium volume
        this.frequency = 500; // Default frequency
        this.timestamp = System.currentTimeMillis();
    }
    
    public Bark(String sound, int volume, int frequency) {
        this.sound = sound;
        this.volume = volume;
        this.frequency = frequency;
        this.timestamp = System.currentTimeMillis();
    }
    
    public boolean matches(Bark other) {
        // Case-insensitive sound comparison
        return this.sound.equalsIgnoreCase(other.sound);
    }
    
    public String getSound() {
        return sound;
    }
    
    public void setSound(String sound) {
        this.sound = sound;
    }
    
    public int getVolume() {
        return volume;
    }
    
    public void setVolume(int volume) {
        this.volume = volume;
    }
    
    public int getFrequency() {
        return frequency;
    }
    
    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    @Override
    public String toString() {
        return sound + " (vol: " + volume + ", freq: " + frequency + "Hz)";
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Bark bark = (Bark) obj;
        return sound.equalsIgnoreCase(bark.sound);
    }
    
    @Override
    public int hashCode() {
        return sound.toLowerCase().hashCode();
    }
}
