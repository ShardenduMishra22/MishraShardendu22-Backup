import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class DogDoor {
    private double length;
    private double breadth;
    private boolean isOpen;
    private ArrayList<Bark> recognizedBarks;
    private Timer autoCloseTimer;
    private static final long AUTO_CLOSE_DELAY = 5000; // 5 seconds
    private boolean isDogInside; // Track if dog is inside or outside

    public DogDoor(double length, double breadth) {
        this.length = length;
        this.breadth = breadth;
        this.isOpen = false;
        this.recognizedBarks = new ArrayList<>();
        this.isDogInside = true; // Dog starts inside
    }

    public void open() {
        if (!isOpen) {
            isOpen = true;
            System.out.println("Dog door is now OPEN");
            scheduleAutoClose();
        } else {
            System.out.println("Dog door is already open");
        }
    }

    public void openManually() {
        if (!isOpen) {
            isOpen = true;
            System.out.println("Dog door MANUALLY opened");
            scheduleAutoClose();
        } else {
            System.out.println("Dog door is already open");
        }
    }

    private void scheduleAutoClose() {
        // Cancel any existing timer
        if (autoCloseTimer != null) {
            autoCloseTimer.cancel();
        }
        
        // Create a new timer for auto-close
        autoCloseTimer = new Timer();
        autoCloseTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (isOpen) {
                    close();
                    System.out.println("Door automatically closed after " + (AUTO_CLOSE_DELAY / 1000) + " seconds");
                }
            }
        }, AUTO_CLOSE_DELAY);
    }

    public void addRecognizedBark(Bark bark) {
        recognizedBarks.add(bark);
        System.out.println("Stored recognized bark: " + bark);
    }

    public ArrayList<Bark> getRecognizedBarks() {
        return new ArrayList<>(recognizedBarks);
    }

    public void close() {
        if (isOpen) {
            isOpen = false;
            // Toggle dog position when door closes (dog went through)
            isDogInside = !isDogInside;
            System.out.println("Dog door is now CLOSED");
            System.out.println("Dog is now " + (isDogInside ? "INSIDE" : "OUTSIDE"));
        } else {
            System.out.println("Dog door is already closed");
        }
    }

    public void closeManually() {
        if (isOpen) {
            isOpen = false;
            System.out.println("Dog door MANUALLY closed (dog position unchanged)");
            // Manual close doesn't change dog position - human intervention
        } else {
            System.out.println("Dog door is already closed");
        }
    }

    public boolean isOpen() {
        return isOpen;
    }

    public double getLength() {
        return length;
    }

    public double getBreadth() {
        return breadth;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public void setBreadth(double breadth) {
        this.breadth = breadth;
    }

    public boolean isDogInside() {
        return isDogInside;
    }

    public void setDogInside(boolean isDogInside) {
        this.isDogInside = isDogInside;
    }
}
